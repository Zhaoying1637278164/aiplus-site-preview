import sys,pathlib,zipfile
root=pathlib.Path.cwd();out=pathlib.Path(sys.argv[1]);version=out.name
with zipfile.ZipFile(out/f'D02-{version}-离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(out.iterdir()):
  if f.is_file() and f.suffix!='.zip':z.write(f,'D02/'+f.name)
with zipfile.ZipFile(out/f'D02-{version}-源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['package.json','package-lock.json','tsconfig.json','README.md','AGENTS.md','CLAUDE.md']:
  z.write(root/name,name)
 for folder in ['apps','packages','scripts','tests','docs','catalog','references','progress','tools/D02-双表核对助手']:
  for f in sorted((root/folder).rglob('*')):
   if f.is_file() and f.suffix!='.zip' and f.name not in ['finance-reconciliation.md','upstream-tree.json']:z.write(f,str(f.relative_to(root)))
 z.write(out/'THIRD_PARTY_NOTICES.md','THIRD_PARTY_NOTICES.md')
