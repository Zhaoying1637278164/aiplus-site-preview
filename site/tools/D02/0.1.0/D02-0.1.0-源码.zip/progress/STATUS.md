# 实际进度与接续

2026-10-03。本轮沿用现有独立工程；正式accepted仍为0/64。D02已从implementing推进到packaged，其余63款planned。

D02 0.1.0已实现React界面、左右CSV/XLSX页签/表头选择与预览、复合键/比较字段映射、范围确认、金额容差、文本设置、方案不含数据下载/恢复、清除换数据、六类核对、XLSX底稿与含数据JSON证据下载。成品自包含无外部资源请求，用户文件仅浏览器内存。

已执行：19/19 Node独立预期/异常/导入导出/方案/ZIP限额测试通过；TypeScript检查通过；Mac Chromium断网file://真实验收通过（六类预期、左7右6守恒、CSV和XLSX导入、页签、方案恢复、容差、清除换数据、底稿下载回读、JSON、移动宽度、无网络请求/无localStorage）。桌面与手机截图已检查。Windows实机未验证。

发布产物：release/D02/0.1.0/index.html、离线ZIP、同版本源码ZIP、CSV模板、CSV/XLSX虚构样例、中文说明、规则和THIRD_PARTY_NOTICES。从ExcelJS bare源码打包，禁用fs/crypto及ExcelJS CSV接口；实际运行依赖版本与许可均有清单。saxes缺失许可已从v5.0.1原tag补齐。

源码重建：在/private/tmp独立解压源码包，npm ci --offline --ignore-scripts、19/19测试、类型检查、构建通过；index.html SHA256与交付原件一致。证据在progress/evidence/D02/source-rebuild.json。重建说明docs/source-build.md。

官网：已读授权官网AGENTS.md；当前暂存integration/site-preview，保留原视觉及go()/render()，增加D02入口，精确?tool=D02白名单只加载一款HTML；七项同包下载。原requirements锁定Streamlit1.65.0当前包源不存在，本机未安装；暂存版本改用可获取1.50.0的components.html兼容接口并关闭遥测。原官网未修改/未推送。暂存真实浏览器验收已通过：旧76项导航、D02入口、新标签页运行、同结果、七项下载哈希、非法ID阻断及返回官网。证据site-local.json。

接续：完成暂存官网导航/同结果/下载/错误ID实测，然后备份/回退标记，同步官网工程，推送已有发布仓库并实际访问公开官网验证。仅在公开运行和下载有证据后计D02 accepted，再推进其余63款。持续64款目标有效，不逐款请求继续授权。
