# 架构与数据流

TypeScript 纯业务引擎 → React 页面 → esbuild IIFE 内联 → 独立 index.html。每款只打包自己的依赖和业务入口，官网与离线使用同一 SHA-256 程序。无需服务器计算或统一宿主。

浏览器本地 File → 大小/格式/页签/表头校验 → SourceRow（原始值、文件名、页签、行号）→ 显式字段规则 → validate → calculate → RunResult（版本、参数、分类、原值、差额、异常）→ 用户点击 XLSX/JSON 导出。JSON 方案默认仅规则，不含原始财务数据；用户自行重新导入来源文件。

packages/core 管理类型、金额、日期、CSV/XLSX 读取、限制、导出和方案；packages/ui 管理中文表格/错误/字段映射。tools/<编号-名称>/src 只实现该款业务，独立测试。

catalog/tools.json 是 64 款唯一登记，脚本生成工具总览、逐款目录说明、官网清单。catalog/site-map.json 保存 76 项原编号、对应 ID、关系和范围外能力；不以数量猜测对应。

官网保留现有视觉、go()/render()。app.py 读取 ?tool=ID，查本地登记白名单，st.iframe(Path) 只嵌当前自包含 HTML；未知 ID 友好错误且不路径拼接。详情提供版本、适用范围、来源、模板、示例和下载。程序仅虚构内置示例，文件选择和计算在 iframe 内浏览器完成。首页不嵌 64 个运行程序。

发布保留版本、清单与校验和，先验收再同步，官网发布验证成功后才 accepted。没有真实验证的系统和功能写明未验证。
