import {build} from 'esbuild';
import {mkdir,readFile,writeFile,copyFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync} from 'node:fs';
import {VERSION as D02_VERSION} from '../packages/core/types';
import {VERSION as D06_VERSION} from '../tools/D06-财务数据质量体检器/src/types';
import {example as qualityExample} from '../tools/D06-财务数据质量体检器/src/example';
import {sampleBytes} from '../tools/D06-财务数据质量体检器/src/sample-file';
import {workbookBytes} from '../packages/core/io';
import {leftExample,rightExample} from '../tools/D02-双表核对助手/src/example';
const id=process.argv[2]||'D02';if(!['D02','D06'].includes(id))throw Error('尚未实现该工具，不能生成占位成品');
const VERSION=id==='D02'?D02_VERSION:D06_VERSION;
const folder=id==='D02'?'tools/D02-双表核对助手':'tools/D06-财务数据质量体检器';
const name=id==='D02'?'双表核对助手':'财务数据质量体检器';
const out=path.resolve('release',id,VERSION);await mkdir(out,{recursive:true});
const bundled=await build({entryPoints:[id==='D02'?'apps/tool-shell/main.tsx':folder+'/src/main.tsx'],outfile:'bundle.js',bundle:true,write:false,platform:'browser',format:'iife',target:['es2022'],minify:true,define:{'process.env.NODE_ENV':'"production"'},metafile:true,alias:{exceljs:'exceljs/lib/exceljs.bare.js'},inject:['packages/core/browser-globals.ts'],plugins:[{name:'browser-io-boundary',setup(b){b.onResolve({filter:/^(fs|crypto)$/},()=>({path:path.resolve('packages/core/browser-disabled.cjs')}));b.onResolve({filter:/^\.\.\/csv\/csv$/},()=>({path:path.resolve('packages/core/browser-csv-disabled.cjs')}))}}]});
const js=bundled.outputFiles!.find(f=>f.path.endsWith('.js'))!.text;
const css=bundled.outputFiles!.find(f=>f.path.endsWith('.css'))!.text;
const html=`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; font-src 'none'; base-uri 'none'; form-action 'none'"><title>${id} ${name} · ${VERSION}</title><style>${css}</style></head><body><div id="root"></div><script>${js.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
const registry=JSON.parse(await readFile('catalog/tools.json','utf8')) as {id:string;status:string;version:string}[];
if(registry.some(t=>t.id===id&&t.status==='accepted'&&t.version===VERSION)&&existsSync(path.join(out,'index.html'))){
 const existing=await readFile(path.join(out,'index.html'),'utf8');
 if(createHash('sha256').update(existing).digest('hex')!==createHash('sha256').update(html).digest('hex'))throw Error('该版本已验收；程序变化必须发布新版本，不能覆盖既有交付包');
 console.log(`已重建并核对 ${id} ${VERSION}；既有验收版本包保持不变`);process.exit(0);
}
await writeFile(path.join(out,'index.html'),html);
if(id==='D02'){
await writeFile(path.join(out,'使用说明.md'),`# D02 双表核对助手 ${VERSION}\n\n双击 index.html 用现代 Chrome/Edge 打开，可断网使用。先体验虚构示例，再导入 UTF-8 CSV/XLSX，选择页签、表头行、左右匹配键和比较字段、币种列与容差，核对并下载 XLSX 底稿及 JSON 证据。示例预期：一致2组、差异1组、仅左1组、仅右1组、重复1组、无效1组；来源行左7右6。\n\n方案下载不包含财务数据，仅保存映射和规则；恢复后重新导入原文件。证据 JSON 和 XLSX 底稿包含数据，由用户自行保存。关闭或清除页面后内存数据清除。不上传、不遥测、不默认持久化。公式不执行，不采用缓存；不自动换汇。\n\n支持每文件10MB、解压30MB、20000数据行、200列。仅 UTF-8 CSV、XLSX；不支持宏、密码、xls/OCR。Windows未实机验证。官网验收状态查看项目progress/STATUS.md。\n`);
await copyFile(folder+'/财务规则.md',path.join(out,'财务规则.md'));
await copyFile(folder+'/参考来源.md',path.join(out,'参考来源.md'));
for(const [label,t] of [['左',leftExample],['右',rightExample]] as const){
 const csv='\uFEFF'+[t.headers,...t.rows.map(r=>t.headers.map(h=>r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
 await writeFile(path.join(out,`虚构${label}表.csv`),csv);
}
await writeFile(path.join(out,'空白模板.csv'),'\uFEFF单据号,金额,日期,币种\r\n');
await writeFile(path.join(out,'虚构样例.xlsx'),await workbookBytes([leftExample,rightExample].map((t,i)=>({name:i?'右表':'左表',headers:t.headers,rows:t.rows.map(r=>t.headers.map(h=>r.cells[h]))}))));
}else{
 await copyFile(folder+'/README.md',path.join(out,'使用说明.md'));
 for(const f of ['财务规则.md','参考来源.md'])await copyFile(folder+'/'+f,path.join(out,f));
 await writeFile(path.join(out,'空白模板.csv'),'\uFEFF'+qualityExample.headers.join(',')+'\r\n');
 const csv='\uFEFF'+[qualityExample.headers,...qualityExample.rows.map(r=>qualityExample.headers.map(h=>typeof r.cells[h]==='object'&&r.cells[h]!==null?'FORMULA_NOT_SUPPORTED':r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
 await writeFile(path.join(out,'虚构样例.csv'),csv);
 await writeFile(path.join(out,'虚构样例.xlsx'),await sampleBytes());
}
// Preserve notices from every runtime package actually included in the browser bundle.
const roots=new Set<string>();
for(const input of Object.keys(bundled.metafile!.inputs)){
 if(!input.startsWith('node_modules/'))continue;
 const parts=input.split('/');roots.add(parts.slice(0,parts[1].startsWith('@')?3:2).join('/'));
}
let notices='# 第三方声明\n\n本产品自主实现；以下从锁定源码构建的实际浏览器依赖。未使用ExcelJS预打包dist，故版本与打包输入逐项对应。\n';
for(const root of [...roots].sort()){
 const p=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));const files=(await readdir(root)).filter(n=>/^(licen[cs]e|copying|notice)(\.|$|-)/i.test(n));
 if(!files.length&&p.name!=='saxes')throw Error(`缺少依赖许可文本 ${root}`);
 notices+=`\n## ${p.name} ${p.version} (${p.license||'见文本'})\n`;
 if(p.name==='saxes')notices+=await readFile('references/saxes-5.0.1-LICENSE','utf8');
 for(const file of files)notices+=`\n### ${file}\n\n${await readFile(path.join(root,file),'utf8')}\n`;
}
notices+='\n## pako zlib port notice\n\n'+await readFile('node_modules/pako/lib/zlib/README','utf8');
await writeFile(path.join(out,'THIRD_PARTY_NOTICES.md'),notices);
await writeFile(path.join(out,'build-manifest.json'),JSON.stringify({tool:id,version:VERSION,inputs:Object.keys(bundled.metafile!.inputs),runtime_packages:[...roots].sort()},null,2));
execFileSync('python3',['scripts/package.py',out]);
console.log(`已构建 ${out}`);
