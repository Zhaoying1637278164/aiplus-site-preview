"""Stage/apply the registered tool integration to the authorized static website."""
import pathlib,json,sys,shutil
root=pathlib.Path(__file__).resolve().parents[1]
site=pathlib.Path('/Users/xiaoying/Library/Mobile Documents/com~apple~CloudDocs/codex/data_labs/aiplus-streamlit')
stage=root/'integration/site-preview'
mode=sys.argv[1] if len(sys.argv)>1 else 'stage'
if mode=='stage':
 stage.mkdir(parents=True,exist_ok=True);(stage/'site').mkdir(exist_ok=True)
 source=(site/'site/index.html').read_text()
 if 'r-tool-D02' not in source:
  tool=next(c for c in json.loads((root/'catalog/tools.json').read_text()) if c['id']=='D02')
  panel=f'''<template id="r-tool-D02"><section class="sec" style="padding:48px 0"><div class="wrap stack gap20" style="max-width:1120px"><p class="small">AI+ 财务工具箱 · {tool['id']}</p><h1 class="h1">{tool['name']}</h1><p class="body">明确关联键的双表核对；全部文件在浏览器本地处理。当前版本0.1.0，先体验虚构示例，再导入自己的CSV或XLSX。</p><p class="body">支持复合键、十进制容差、币种阻断、重复整组待确认、来源追溯、方案保存与XLSX底稿。无需账号或API Key。</p><div class="row gap16" style="margin:24px 0"><a class="btn btn-primary" href="?tool=D02" target="_blank" rel="noopener">打开 D02 双表核对助手及下载（新标签页）</a><a class="btn" href="#tools">返回工具库</a></div><p class="small">Mac Chromium离线已验证；Windows实机未验证。不做AI模糊匹配、银行核销或自动记账。</p></div></section></template>'''
  source=source.replace('<script>\nwindow.__initTools',panel+'\n<script>\nwindow.__initTools',1)
  # Add the catalog entry adjacent to the existing catalogue, preserving all existing routes.
  source=source.replace('<div id="tool-list"', '<div id="tool-list"',1)
  # Existing page templates are re-rendered: attach a stable entry in the tools initializer.
  marker="var list=document.getElementById('tool-list');if(!list)return;"
  addition="""var d02=document.createElement('div');d02.className='card';d02.style.cssText='padding:18px;margin-bottom:20px';var link=document.createElement('a');link.href='#tool-D02';link.textContent='D02 · 双表核对助手 — 在线运行 / 下载离线包与源码';d02.appendChild(link);list.insertAdjacentElement('beforebegin',d02);"""
  assert marker in source;source=source.replace(marker,marker+'\n  '+addition,1)
 if 'r-tool-D06' not in source:
  tool=next(c for c in json.loads((root/'catalog/tools.json').read_text()) if c['id']=='D06')
  panel=f'''<template id="r-tool-D06"><section class="sec" style="padding:48px 0"><div class="wrap stack gap20" style="max-width:1120px"><p class="small">AI+ 财务工具箱 · D06</p><h1 class="h1">{tool['name']}</h1><p class="body">可配置必填、唯一键、类型、允许值、金额范围和逐行勾稽，保留问题原行，导出独立检查报告。全部文件在浏览器本地处理。</p><div class="row gap16" style="margin:24px 0"><a class="btn btn-primary" href="?tool=D06" target="_blank" rel="noopener">打开 D06 财务数据质量体检器及下载（新标签页）</a><a class="btn" href="#tools">返回工具库</a></div><p class="small">版本0.1.0；Mac Chromium离线已验证，Windows实机未验证。无需账号或API Key。未提供AI/OCR能力。</p></div></section></template>'''
  assert '<script>\nwindow.__initTools' in source
  source=source.replace('<script>\nwindow.__initTools',panel+'\n<script>\nwindow.__initTools',1)
  marker="var list=document.getElementById('tool-list');if(!list)return;"
  addition="var d06=document.createElement('div');d06.className='card';d06.style.cssText='padding:18px;margin-bottom:20px';var link06=document.createElement('a');link06.href='#tool-D06';link06.textContent='D06 · 财务数据质量体检器 — 在线运行 / 下载离线包与源码';d06.appendChild(link06);list.insertAdjacentElement('beforebegin',d06);"
  assert marker in source;source=source.replace(marker,marker+'\n  '+addition,1)
 (stage/'site/index.html').write_text(source)
 app=(site/'app.py').read_text()
 if 'import base64' not in app:app=app.replace('from pathlib import Path','from pathlib import Path\nimport base64\nimport streamlit.components.v1 as components')
 # Regenerate the exact whitelist; never interpolate a query value into a file path.
 registry=json.loads((root/'catalog/tools.json').read_text())
 implemented=[t for t in registry if t['id'] in ['D02','D06'] and (root/'release'/t['id']/t['version']/'index.html').is_file()]
 paths=', '.join(f'{t["id"]!r}: ROOT / "site" / "tools" / {t["id"]!r} / {t["version"]!r}' for t in implemented)
 versions={t['id']:t['version'] for t in implemented}
 replacement=f'''ROOT = Path(__file__).parent
# Only exact registered IDs can select a program. Never form a path from user input.
TOOLS = {{{paths}}}
VERSIONS = {versions!r}
selected = st.query_params.get("tool", "")
if selected in TOOLS:
    folder = TOOLS[selected]
    version = VERSIONS[selected]
    html = (folder / "index.html").read_text(encoding="utf-8")
    names = [f"{{selected}}-{{version}}-离线包.zip", f"{{selected}}-{{version}}-源码.zip", "虚构样例.xlsx", "空白模板.csv", "使用说明.md", "财务规则.md", "THIRD_PARTY_NOTICES.md"]
    links = []
    for name in names:
        payload = base64.b64encode((folder / name).read_bytes()).decode("ascii")
        links.append(f'<a download="{{name}}" href="data:application/octet-stream;base64,{{payload}}" style="margin:8px;display:inline-block">{{name}}</a>')
    toolbar = '<nav style="padding:16px;background:white"><a href="?" target="_blank" rel="noopener">返回官网</a>' + f'<strong style="margin:12px">{{selected}} · {{version}} 下载</strong>' + "".join(links) + '</nav>'
    html = html.replace('<div id="root">', toolbar + '<div id="root">', 1)
    components.html(html, height=900, scrolling=True)
else:
    if selected:
        st.warning("该工具尚未开放，返回官网查看交付状态。")
    components.html((ROOT / "site" / "index.html").read_text(encoding="utf-8"), height=900, scrolling=True)'''
 anchor='ROOT = Path(__file__).parent' if 'TOOLS = ' in app else 'SITE = Path(__file__).parent'
 assert anchor in app;app=app[:app.index(anchor)]+replacement+'\n'
 (stage/'app.py').write_text(app)
 (stage/'requirements.txt').write_text('streamlit==1.50.0\n')
 (stage/'.streamlit').mkdir(exist_ok=True)
 shutil.copy2(site/'.streamlit/config.toml',stage/'.streamlit/config.toml')
 for t in implemented:
  target=stage/'site/tools'/t['id']/t['version'];target.mkdir(parents=True,exist_ok=True)
  for p in (root/'release'/t['id']/t['version']).iterdir():
   if p.is_file():shutil.copy2(p,target/p.name)
 print('官网接入已暂存',stage)
elif mode=='apply':
 assert (stage/'app.py').exists()
 for name in ['app.py','requirements.txt','site/index.html']:
  shutil.copy2(stage/name,site/name)
 shutil.copytree(stage/'site/tools',site/'site/tools',dirs_exist_ok=True)
 print('已同步到授权官网工程')
else:raise ValueError('仅支持stage/apply')
