# D02 双表核对助手

两份xlsx或UTF-8 CSV按文本复合键核对金额、文本、日期。输出一致、差异、仅左、仅右、重复歧义和无效输入，逐行保留来源并导出XLSX底稿。不是银行自动核销。

已实现React页面、复合键/字段映射、页签/表头选择、方案下载恢复、自包含HTML、CSV/XLSX导入、XLSX底稿及JSON证据下载。0.1.0已accepted；官网、源码重建与离线验证均有证据，Windows实机未验证。

[官网使用与下载](https://aiplus-guance.streamlit.app/~/+/?tool=D02) · [离线程序](../../release/D02/0.1.0/index.html) · [线上验收](../../progress/evidence/D02/site-live.json)。0.1.0版本包保持不变，后续程序修改须发布新版本。

每次导入或更换页签须确认两表主体、期间和金额单位一致，或已将相关字段映射为比较字段，之后才能计算。空值不当零、公式不执行；用户数据只在当前浏览器内存。方案不含数据，证据导出含数据。

[重建说明](../../docs/source-build.md) · [浏览器证据](../../progress/evidence/D02/browser.json)。Windows实机未验证。

[参考来源](参考来源.md) · [财务规则](财务规则.md) · [虚构样例源](src/example.ts) · [测试](tests/engine.test.ts)。开发者使用 `npm test` 运行真实验证；测试通过不等于离线/官网完成。
