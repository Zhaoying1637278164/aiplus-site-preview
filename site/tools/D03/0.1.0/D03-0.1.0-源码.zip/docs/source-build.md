# 同版本源码重建

解压对应 D02、D03 或 D06 的同版本源码.zip，在解压目录使用 Node.js 22+：

```sh
npm ci
npm test
npm run typecheck
npm run build -- D02
# D06 源码包也可运行：
npm run build -- D06
```

输出在 release/D02/0.1.0。业务计算位于 tools/D02-双表核对助手/src，React页面位于 apps/tool-shell，受限读写、金额和方案位于 packages/core。源码包含锁文件、计算与文件测试、浏览器验收脚本、所有实际浏览器依赖许可通知。没有 node_modules、凭据或业务数据。

浏览器验收先安装开发用 Chromium（`npx playwright install chromium`），再运行 `npm run test:browser`。也可通过 `AIPLUS_CHROME` 指定本机 Chromium可执行文件。开发安装可能需要网络，生成的成品不需要网络。

构建从 ExcelJS 4.4.0 的 lib/exceljs.bare.js 与锁定依赖源码打包，避免其dist内嵌版本无法核验的依赖；fs/crypto接口明确抛错，ExcelJS CSV入口停用，CSV只经过本项目PapaParse受限读取器。注入浏览器Buffer、微任务与事件接口；不加载网络polyfill或在线脚本。ExcelJS的密码/文件系统/CSV接口不在本产品能力中。

Mac Chromium已验证；Windows实机未验证。正式完成状态以progress/STATUS.md与官网验收证据为准。

D06业务与React位于tools/D06-财务数据质量体检器/src；验收脚本tests/d06-browser.ts。D06源码包含D02代码作为受影响回归及构建依赖，不含node_modules或业务数据。

D03业务与React在tools/D03-科目往来部门映射管理器/src，npm run build -- D03，浏览器tests/d03-browser.ts。D06 0.1.1补充tests/d06-sheet-regression.ts验证多页签及第二行表头；0.1.0旧包保留，不覆盖。
