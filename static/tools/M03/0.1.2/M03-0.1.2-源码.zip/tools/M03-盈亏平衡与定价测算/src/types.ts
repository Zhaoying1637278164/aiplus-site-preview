import type {Table,SourceRow} from '../../../packages/core/types';
export const VERSION='0.1.2';
export const RULE_VERSION='M03-2026-10-04.2';
export const HEADERS=['方案ID','方案名称','期间','币种','金额单位','数量单位','标价','折扣百分比','销量','单位变动成本','固定成本','目标利润','适用最低销量','适用最高销量','成本口径','假设依据'];
export interface Settings {display:number;tolerance:string;priceAxis:string;quantityAxis:string}
export const DEFAULT_SETTINGS:Settings={display:2,tolerance:'0.000001',priceAxis:'-10,-5,0,5,10',quantityAxis:'-20,-10,0,10,20'};
export interface Scenario {name:string;discount:string;volumeChange:string;variableChange:string;fixedChange:string;basis:string}
export interface Work {table:Table|null;overrides:Record<string,Record<string,string>>;settings:Settings;scenarios:Scenario[]}
export interface Issue {index:number;source:SourceRow;field:string;message:string;severity:'阻塞'|'提示'}
export interface Model {id:string;name:string;period:string;currency:string;price:string;discount:string;quantity:string;variable:string;fixed:string;target:string;min:string;max:string;basis:string;costBasis:string;source:SourceRow;index:number}
export interface Result {model:Model;netPrice:string;unitContribution:string;revenue:string;variableTotal:string;fixed:string;contribution:string;profit:string;residual:string;breakEven:string|null;breakEvenUnits:string|null;breakEvenRevenue:string|null;breakEvenProfit:string|null;targetUnits:string|null;targetUnitProfit:string|null;minNetPrice:string|null;minListPrice:string|null;maxDiscount:string|null;safetyUnits:string|null;safetyPercent:string|null;contributionPercent:string|null;targetGap:string;status:string;warnings:string[]}
