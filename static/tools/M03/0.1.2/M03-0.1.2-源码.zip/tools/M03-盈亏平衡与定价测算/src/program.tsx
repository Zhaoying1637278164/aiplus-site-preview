import React from 'react';
import {createRoot} from 'react-dom/client';
import type {ToolProgram} from '../../../packages/ui/tool-host';
import {App} from './app';
import {VERSION} from './types';
export const program:ToolProgram={id:'M03',name:'盈亏平衡与定价测算',version:VERSION,mount(context){const root=createRoot(context.container);let dirty=false,disposed=false;const requestExit=()=>!dirty||confirm('当前工作只在内存，请先下载含数据工作。确认离开并清空？');const before=(e:BeforeUnloadEvent)=>{if(dirty){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',before);const instance={requestExit,dispose(){if(disposed)return;disposed=true;window.removeEventListener('beforeunload',before);root.unmount();dirty=false;context.container.replaceChildren();}};root.render(<App onDirty={v=>{dirty=v;}} onExit={context.onExit?()=>{if(requestExit()){instance.dispose();context.onExit?.();}}:undefined}/>);return instance;}};
