import {workbookBytes} from '../../../packages/core/io';
import {VERSION,RULE_VERSION,HEADERS,type Work} from './types';
import {validate,calculate,applyScenario,sensitivity} from './engine';
export function csv(headers:string[],rows:unknown[][]){const safe=(v:unknown)=>{const s=String(v??'');return /^[\s]*[=+@-]/.test(s)&&! /^[+-]?\d+(?:\.\d+)?$/.test(s)?"'"+s:s;};return '\uFEFF'+[headers,...rows].map(r=>r.map(v=>'"'+safe(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');}
const fields=['净单价','单位贡献','收入','变动成本','固定成本','贡献','经营利润','勾稽差额','理论保本量(近似30位)','整件保本量','整件保本收入','整件保本利润','目标销量','目标量利润','最低净价(向上到分)','最低标价(向上到分)','最大折扣%(向下6位)','安全边际件(整件)','安全边际%','贡献率%','目标差距','状态','限制'];
const keys=['netPrice','unitContribution','revenue','variableTotal','fixed','contribution','profit','residual','breakEven','breakEvenUnits','breakEvenRevenue','breakEvenProfit','targetUnits','targetUnitProfit','minNetPrice','minListPrice','maxDiscount','safetyUnits','safetyPercent','contributionPercent','targetGap','status','warnings'] as const;
export function exportSheets(w:Work){const t=w.table;if(!t)throw Error('请先载入资料');const {models,issues}=validate(t,w.overrides),results=models.map(calculate);const provenance=['方案ID','方案名称','期间','币种','金额单位','数量单位','源文件','页签','原始行'];const pre=(m:typeof models[number])=>[m.id,m.name,m.period,m.currency,'元','件',m.source.file,m.source.sheet,m.source.row];
 const out=results.map(r=>[...pre(r.model),...keys.map(k=>Array.isArray(r[k])?(r[k] as string[]).join('；'):r[k])]);
 if(models.length*w.scenarios.length>100000)throw Error('情景组合超过100000，请分批导出');
 const scenarios=models.flatMap(m=>w.scenarios.map(s=>{try{const r=applyScenario(m,s);return [...pre(m),s.name,s.basis,r.model.quantity,r.netPrice,r.model.variable,r.fixed,r.profit,r.profit===undefined?'':r.status,r.warnings.join('；')];}catch(e){return [...pre(m),s.name,s.basis,'','','','','','阻塞',String((e as Error).message)];}}));
 const sensitive=models.slice(0,1).flatMap(m=>{try{return sensitivity(m,w.settings).map(s=>[...pre(m),s.priceChange,s.quantityChange,s.result.netPrice,s.result.model.quantity,s.result.profit,s.result.status,s.result.warnings.join('；')]);}catch(e){return [[...pre(m),'','','','','','阻塞',String((e as Error).message)]];}});
 return [{name:'结果全量',headers:[...provenance,...fields],rows:out},
 {name:'原始来源全量',headers:['源文件','页签','原始行',...t.headers],rows:t.rows.map(r=>[r.file,r.sheet,r.row,...t.headers.map(h=>r.cells[h])])},
 {name:'有效假设全量',headers:['源文件','页签','原始行',...HEADERS],rows:t.rows.map((r,i)=>[r.file,r.sheet,r.row,...HEADERS.map(h=>w.overrides[String(i)]?.[h]??r.cells[h])])},
 {name:'覆盖记录',headers:['源文件','页签','原始行','字段','原值','现值'],rows:Object.entries(w.overrides).flatMap(([i,o])=>Object.entries(o).map(([h,v])=>{const r=t.rows[Number(i)];return[r.file,r.sheet,r.row,h,r.cells[h],v];}))},
 {name:'异常与限制',headers:['源文件','页签','原始行','字段','级别','信息'],rows:[...issues.map(i=>[i.source.file,i.source.sheet,i.source.row,i.field,i.severity,i.message]),...results.flatMap(r=>r.warnings.map(x=>[r.model.source.file,r.model.source.sheet,r.model.source.row,'经营限制','提示',x]))]},
 {name:'情景全量',headers:[...provenance,'情景','依据','情景销量(向下整件)','净单价','单位变动成本','固定成本','利润','状态','限制'],rows:scenarios},
 {name:'敏感性首个有效方案',headers:[...provenance,'价格变动%','销量变动%','净单价','销量','利润','状态','限制'],rows:sensitive},
 {name:'参数与口径',headers:['参数','值'],rows:[['应用版本',VERSION],['规则版本',RULE_VERSION],['生效','2026-10-04起，非税务会计政策'],['有效方案',models.length],['阻塞原始行',t.rows.length-models.length],['数据行',t.rows.length],['显示位数',w.settings.display],['勾稽容差',w.settings.tolerance],['价格轴',w.settings.priceAxis],['数量轴',w.settings.quantityAxis],['敏感性导出范围','首个有效方案；页面所选方案另行下载'],['数量口径','整件；情景数量向下取整'],['价格口径','不含税；元/件；不自动换汇'],['公式','利润=标价×(1-折扣%)×销量-单位变动成本×销量-固定成本'],['预测边界','用户假设；无真实弹性、市场或竞争价格预测']]},
 {name:'情景假设',headers:['名称','折扣%','销量变动%','变动成本变动%','固定成本变动%','依据'],rows:w.scenarios.map(s=>[s.name,s.discount,s.volumeChange,s.variableChange,s.fixedChange,s.basis])}];}
export async function exportBytes(w:Work){return workbookBytes(exportSheets(w));}
