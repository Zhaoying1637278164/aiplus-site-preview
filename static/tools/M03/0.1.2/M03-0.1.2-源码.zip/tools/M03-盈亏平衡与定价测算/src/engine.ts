import Decimal from 'decimal.js';
import type {Cell,Table} from '../../../packages/core/types';
import {HEADERS,type Model,type Result,type Issue,type Settings,type Scenario} from './types';
export const D=Decimal.clone({precision:80,rounding:Decimal.ROUND_HALF_UP,toExpNeg:-80,toExpPos:80});
export function numeric(v:Cell,nonnegative=true):string{
 if(typeof v==='number'&&(!Number.isFinite(v)||Math.abs(v)>Number.MAX_SAFE_INTEGER))throw Error('数值超出安全精度，请用文本');
 if(v===null||v===undefined||typeof v==='object'||String(v).trim()==='')throw Error('缺失或公式，不按零处理');
 const s=String(v).trim();if(!/^[+-]?\d{1,12}(?:\.\d{1,6})?$/.test(s))throw Error('须为最多12位整数、6位小数的十进制静态值');
 const n=new D(s);if(nonnegative&&n.lt(0))throw Error('不得为负');return n.toFixed();
}
export function quantity(v:Cell):string{const s=numeric(v);if(!new D(s).isInteger()||new D(s).gt(1000000000))throw Error('销量须为0至10亿整件');return s;}
function str(v:Cell,max=500):string{if(v===null||v===undefined||typeof v==='object'||!String(v).trim())throw Error('必填静态文本缺失');const s=String(v).trim();if(s.length>max)throw Error('文本过长');return s;}
export function settingsCheck(s:Settings){if(!s||!Number.isInteger(s.display)||s.display<0||s.display>6)throw Error('显示位数须0至6');numeric(s.tolerance);axis(s.priceAxis);axis(s.quantityAxis);return s;}
export function axis(s:string):string[]{if(typeof s!=='string'||s.length>250)throw Error('敏感性轴无效');const a=s.split(',').map(x=>numeric(x,false));if(!a.length||a.length>11||new Set(a).size!==a.length||a.some(x=>new D(x).lt(-100)||new D(x).gt(1000)))throw Error('每轴1至11个不重复百分比，范围-100至1000');return a;}
export function scenarioCheck(s:Scenario){str(s?.name,80);str(s?.basis,500);if(new D(numeric(s.discount)).gt(100))throw Error('折扣范围0至100');for(const k of ['volumeChange','variableChange','fixedChange'] as const){const n=new D(numeric(s[k],false));if(n.lt(-100)||n.gt(1000))throw Error('变动范围-100至1000%');}return s;}
export function validate(t:Table,overrides:Record<string,Record<string,string>>={}):{models:Model[];issues:Issue[]}{
 if(t.rows.length>20000||t.headers.length>216)throw Error('资料超过20000行/216内部列（含原始列）');
 for(const h of HEADERS)if(!t.headers.includes(h))throw Error('缺少字段：'+h);
 const issues:Issue[]=[],models:Model[]=[];const ids=new Map<string,number[]>();
 t.rows.forEach((r,i)=>{const c={...r.cells,...overrides[String(i)]};try{const id=str(c['方案ID'],80);ids.set(id,[...(ids.get(id)||[]),i]);}catch{}});
 t.rows.forEach((r,index)=>{const c={...r.cells,...overrides[String(index)]};let bad=false;
 const read=(h:string,fn:(v:Cell)=>string)=>{try{return fn(c[h]);}catch(e){bad=true;issues.push({index,source:r,field:h,message:String((e as Error).message),severity:'阻塞'});return '';}};
 const id=read('方案ID',v=>str(v,80)),name=read('方案名称',v=>str(v,100)),period=read('期间',v=>{const s=str(v);if(!/^(19|20|21)\d{2}-(0[1-9]|1[0-2])$/.test(s))throw Error('期间须1900至2199的YYYY-MM');return s;}),currency=read('币种',v=>{const s=str(v);if(!/^[A-Z]{3}$/.test(s))throw Error('币种须三位大写代码');return s;});
 read('金额单位',v=>{if(str(v)!=='元')throw Error('仅接受元，不自动换算');return '元';});read('数量单位',v=>{if(str(v)!=='件')throw Error('仅接受整件');return '件';});
 const price=read('标价',numeric),discount=read('折扣百分比',v=>{const s=numeric(v);if(new D(s).gt(100))throw Error('折扣范围0至100');return s;}),q=read('销量',quantity),variable=read('单位变动成本',numeric),fixed=read('固定成本',numeric),target=read('目标利润',numeric),min=read('适用最低销量',quantity),max=read('适用最高销量',quantity),costBasis=read('成本口径',str),basis=read('假设依据',str);
 if(ids.get(id)?.length!>1){bad=true;issues.push({index,source:r,field:'方案ID',message:'重复ID全组阻塞，不合并成本',severity:'阻塞'});}
 if(min&&max&&new D(min).gt(max)){bad=true;issues.push({index,source:r,field:'适用最高销量',message:'最高销量小于最低销量',severity:'阻塞'});}
 if(!bad)models.push({id,name,period,currency,price,discount,quantity:q,variable,fixed,target,min,max,basis,costBasis,source:r,index});
 });return {models,issues};
}
// Exact rational ceiling for positive Decimal values; never ceil an approximate quotient.
export function ceilRatio(a:Decimal,b:Decimal,places=0):string{
 const scale=Math.max(a.decimalPlaces(),b.decimalPlaces());const factor=new D(10).pow(scale);
 const n=BigInt(a.mul(factor).toFixed(0))*10n**BigInt(places),den=BigInt(b.mul(factor).toFixed(0));if(n<0n||den<=0n)throw Error('向上取整仅接受非负分子、正分母');
 const units=(n+den-1n)/den;return new D(units.toString()).div(new D(10).pow(places)).toFixed(places);
}
export function floorRatio(a:Decimal,b:Decimal,places=6):string{const scale=Math.max(a.decimalPlaces(),b.decimalPlaces());const factor=new D(10).pow(scale);const n=BigInt(a.mul(factor).toFixed(0))*10n**BigInt(places),den=BigInt(b.mul(factor).toFixed(0));if(den<=0n)throw Error('分母须正');let units=n/den;if(n<0n&&n%den!==0n)units--;return new D(units.toString()).div(new D(10).pow(places)).toFixed();}
const ratio=(a:Decimal,b:Decimal)=>a.div(b).toDecimalPlaces(30).toFixed();
export function calculate(m:Model):Result{
 const p=new D(m.price).mul(new D(1).minus(new D(m.discount).div(100))),v=new D(m.variable),f=new D(m.fixed),q=new D(m.quantity),target=new D(m.target),c=p.minus(v),rev=p.mul(q),vt=v.mul(q),con=c.mul(q),profit=con.minus(f);
 const warnings:string[]=[];const range=(n:Decimal)=>n.lt(m.min)||n.gt(m.max);
 if(range(q))warnings.push('当前销量超出适用范围，利润仅线性外推，需确认成本');
 let be:string|null=null,beq:string|null=null,tq:string|null=null;
 if(c.gt(0)){be=ratio(f,c);beq=ceilRatio(f,c);tq=ceilRatio(f.plus(target),c);}
 else if(f.eq(0)){be='0';beq='0';if(target.eq(0))tq='0';warnings.push(c.lt(0)?'负贡献：仅零销量可保本，销售增加扩大亏损':'零贡献：无扩张利润，目标利润大于零不可达');}
 else warnings.push('单位贡献不为正，无法覆盖固定成本，无有限保本量');
 if(beq!==null&&range(new D(beq)))warnings.push('整件保本量超出适用范围，不能作为可实现经营目标');
 if(tq!==null&&range(new D(tq)))warnings.push('目标利润销量超出适用范围，需重估成本或产能');
 const needed=v.mul(q).plus(f).plus(target);
 const minNet=q.gt(0)?ceilRatio(needed,q,2):null;
 const remain=new D(1).minus(new D(m.discount).div(100));
 const minList=q.gt(0)&&remain.gt(0)?ceilRatio(needed,q.mul(remain),2):null;
 // Round allowable discount down to 6 decimals so it never weakens target coverage.
 const maxDiscount=q.gt(0)&&new D(m.price).gt(0)?floorRatio(q.mul(m.price).minus(needed).mul(100),q.mul(m.price),6):null;
 if(maxDiscount!==null&&new D(maxDiscount).lt(0))warnings.push('标价不折扣仍达不到目标利润，负折扣表示需要提价');
 const safety=beq!==null?q.minus(beq):null;
 return {model:m,netPrice:p.toFixed(),unitContribution:c.toFixed(),revenue:rev.toFixed(),variableTotal:vt.toFixed(),fixed:f.toFixed(),contribution:con.toFixed(),profit:profit.toFixed(),residual:rev.minus(vt).minus(f).minus(profit).toFixed(),breakEven:be,breakEvenUnits:beq,breakEvenRevenue:beq!==null?p.mul(beq).toFixed():null,breakEvenProfit:beq!==null?c.mul(beq).minus(f).toFixed():null,targetUnits:tq,targetUnitProfit:tq!==null?c.mul(tq).minus(f).toFixed():null,minNetPrice:minNet,minListPrice:minList,maxDiscount,safetyUnits:safety?.toFixed()??null,safetyPercent:safety&&q.gt(0)?ratio(safety.mul(100),q):null,contributionPercent:p.gt(0)?ratio(c.mul(100),p):null,targetGap:profit.minus(target).toFixed(),status:range(q)?'范围外外推':profit.gte(target)?'达到目标':profit.gte(0)?'保本未达目标':'亏损',warnings};
}
export function applyScenario(m:Model,s:Scenario):Result{scenarioCheck(s);const change=(base:string,pct:string)=>new D(base).mul(new D(1).plus(new D(pct).div(100)));const q=change(m.quantity,s.volumeChange).floor();if(q.gt(1000000000))throw Error('情景销量超过10亿上限');return calculate({...m,discount:s.discount,quantity:q.toFixed(),variable:change(m.variable,s.variableChange).toFixed(),fixed:change(m.fixed,s.fixedChange).toFixed(),basis:m.basis+'；情景：'+s.basis});}
export function sensitivity(m:Model,s:Settings){settingsCheck(s);return axis(s.priceAxis).flatMap(p=>axis(s.quantityAxis).map(q=>{const price=new D(m.price).mul(new D(1).plus(new D(p).div(100))),quantity=new D(m.quantity).mul(new D(1).plus(new D(q).div(100))).floor();if(quantity.gt(1000000000))throw Error('敏感性销量超过10亿');return {priceChange:p,quantityChange:q,result:calculate({...m,price:price.toFixed(),quantity:quantity.toFixed()})};}));}
