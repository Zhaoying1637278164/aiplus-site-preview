import {HEADERS} from './types';
import {example,initial} from './example';
import {csv} from './export';
import {sampleBytes} from './sample-file';
import {encodeWork} from './plan';
export async function releaseAssets(){return [{filename:'空白模板.csv',data:csv(HEADERS,[])},{filename:'虚构样例.csv',data:csv(HEADERS,example.rows.map(r=>HEADERS.map(h=>r.cells[h])))},{filename:'虚构样例.xlsx',data:await sampleBytes()},{filename:'无数据方案.json',data:encodeWork(initial(),false)},{filename:'虚构含数据工作.json',data:encodeWork({...initial(),table:example},true)}];}
