import type {Table} from '../../../packages/core/types';
import {HEADERS,type Work,DEFAULT_SETTINGS} from './types';
export const example:Table={file:'完全虚构样例.csv',sheet:'方案',headers:HEADERS,rows:[
 ['CASE-001','虚构标准产品','2026-10','CNY','元','件','20','0','1500','12','8000','4000','0','5000','不含税；期间固定成本；变动成本随整件销量线性变化','完全虚构，教学用'],
 ['CASE-002','虚构试销产品','2026-10','CNY','元','件','30','10','1000','15','9000','3000','200','3000','不含税；固定成本不含变动成本','完全虚构，未预测市场需求'],
 ['CASE-003','虚构低贡献方案','2026-10','USD','元','件','12','0','100','12','500','0','0','1000','不含税；同币种美元金额单位元','完全虚构，零贡献测试']
].map((values,i)=>({file:'完全虚构样例.csv',sheet:'方案',row:i+2,cells:Object.fromEntries(HEADERS.map((h,k)=>[h,values[k]]))}))};
export function initial():Work{return {table:null,overrides:{},settings:{...DEFAULT_SETTINGS},scenarios:[{name:'折扣促销假设',discount:'10',volumeChange:'20',variableChange:'0',fixedChange:'0',basis:'用户自定销量增加20%，不代表市场弹性'}]};}
