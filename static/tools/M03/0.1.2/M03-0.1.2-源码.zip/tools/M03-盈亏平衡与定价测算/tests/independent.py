"""Independent Fraction oracle: no imports from the application, integer division for executable bounds."""
from fractions import Fraction as F
from decimal import Decimal,localcontext,ROUND_HALF_UP
from pathlib import Path
import json,sys
H=['方案ID','方案名称','期间','币种','金额单位','数量单位','标价','折扣百分比','销量','单位变动成本','固定成本','目标利润','适用最低销量','适用最高销量','成本口径','假设依据']
def text(x):
 with localcontext() as ctx:
  ctx.prec=120
  d=Decimal(x.numerator)/Decimal(x.denominator)
  s=format(d,'f')
  return s.rstrip('0').rstrip('.') if '.' in s else s

def approx(x):
 with localcontext()as c:
  c.prec=120;d=(Decimal(x.numerator)/Decimal(x.denominator)).quantize(Decimal('1e-30'),rounding=ROUND_HALF_UP)
  return format(d,'f').rstrip('0').rstrip('.') or '0'
def ceil(x):return -(-x.numerator//x.denominator)
def cents(x):return f'{ceil(x*100)//100}.{ceil(x*100)%100:02d}'
def compute(c):
 p=F(c['标价'])*(1-F(c['折扣百分比'])/100);v=F(c['单位变动成本']);f=F(c['固定成本']);q=F(c['销量']);target=F(c['目标利润']);unit=p-v;rev=p*q;vt=v*q;con=rev-vt;profit=rev-vt-f
 warnings=[];outside=lambda n:n<F(c['适用最低销量'])or n>F(c['适用最高销量'])
 if outside(q):warnings.append('当前销量超出适用范围，利润仅线性外推，需确认成本')
 be=beq=tq=None
 if unit>0:be=approx(f/unit);beq=str(ceil(f/unit));tq=str(ceil((f+target)/unit))
 elif f==0:
  be=beq='0'
  if target==0:tq='0'
  warnings.append('负贡献：仅零销量可保本，销售增加扩大亏损' if unit<0 else '零贡献：无扩张利润，目标利润大于零不可达')
 else:warnings.append('单位贡献不为正，无法覆盖固定成本，无有限保本量')
 if beq is not None and outside(F(beq)):warnings.append('整件保本量超出适用范围，不能作为可实现经营目标')
 if tq is not None and outside(F(tq)):warnings.append('目标利润销量超出适用范围，需重估成本或产能')
 needed=vt+f+target;remain=1-F(c['折扣百分比'])/100
 maxd=text(F((100*(1-needed/(q*F(c['标价'])))*10**6).numerator//F((100*(1-needed/(q*F(c['标价'])))*10**6)).denominator,10**6)) if q>0 and F(c['标价'])>0 else None
 if maxd is not None and F(maxd)<0:warnings.append('标价不折扣仍达不到目标利润，负折扣表示需要提价')
 safety=q-F(beq)if beq is not None else None
 values=[text(p),text(unit),text(rev),text(vt),text(f),text(con),text(profit),'0',be,beq,text(p*F(beq))if beq is not None else None,text(unit*F(beq)-f)if beq is not None else None,tq,text(unit*F(tq)-f)if tq is not None else None,cents(needed/q)if q>0 else None,cents(needed/(q*remain))if q>0 and remain>0 else None,maxd,text(safety)if safety is not None else None,approx(safety*100/q)if safety is not None and q>0 else None,approx(unit*100/p)if p>0 else None,text(profit-target),'范围外外推'if outside(q)else '达到目标'if profit>=target else '保本未达目标'if profit>=0 else '亏损','；'.join(warnings)]
 return values

def fixture():
 rows=[]
 for i in range(604):
  values=[f'B-{i+1:04d}',f'虚构方案{i+1}','2026-10'if i%2==0 else '2026-11','CNY'if i%3 else 'USD','元','件',str(20+i%19),'0',str(1000+i),str(6+i%7),str(7000+i*13),str(i*11),'0','10000','不含税线性成本，同一期间币种；虚构','完全虚构独立输入']
  c=dict(zip(H,values))
  if i==0:c.update({'标价':'20','单位变动成本':'12','固定成本':'8000','销量':'1500','目标利润':'4000'})
  if i==1:c.update({'标价':'12','单位变动成本':'12'})
  if i==2:c.update({'标价':'10','单位变动成本':'12'})
  if i==3:c['销量']='0'
  if i==4:c['固定成本']='0'
  if i==5:c['折扣百分比']='100'
  if i==6:c['适用最高销量']='1'
  if i==7:c.update({'标价':'0.4','单位变动成本':'0.1','固定成本':'1','销量':'4','目标利润':'0'})
  if i==8:c.update({'标价':'999999999999.999999','单位变动成本':'0.000001','固定成本':'999999999999.999999'})
  rows.append({'file':'604独立虚构.xlsx','sheet':'两期方案','row':i+3,'cells':c})
 table={'file':'604独立虚构.xlsx','sheet':'两期方案','headers':H,'rows':rows}
 scenarios=[{'name':'折扣销量假设','discount':'10','volumeChange':'20','variableChange':'0','fixedChange':'0','basis':'虚构自定，无市场弹性'},{'name':'下行情景','discount':'30','volumeChange':'-20','variableChange':'15','fixedChange':'5','basis':'虚构成本压力'},{'name':'零销量情景','discount':'100','volumeChange':'-100','variableChange':'-100','fixedChange':'-100','basis':'虚构极端'}]
 w={'table':table,'overrides':{},'settings':{'display':2,'tolerance':'0.000001','priceAxis':'-100,-10,0,10,100','quantityAxis':'-100,-20,0,20,100'},'scenarios':scenarios}
 return w

def effective(w):
 return [{**r['cells'],**w['overrides'].get(str(i),{})} for i,r in enumerate(w['table']['rows'])]
def shifted(c,s):
 d=dict(c);d['折扣百分比']=s['discount']
 for k,sk in [('销量','volumeChange'),('单位变动成本','variableChange'),('固定成本','fixedChange')]:
  n=F(c[k])*(1+F(s[sk])/100);d[k]=str(n.numerator//n.denominator)if k=='销量'else text(n)
 return d
if __name__=='__main__':
 out=Path(sys.argv[1]if len(sys.argv)>1 else 'progress/evidence/M03/0.1.1/independent');out.mkdir(parents=True,exist_ok=True)
 w=fixture();(out/'input.json').write_text(json.dumps(w,ensure_ascii=False,indent=2));cs=effective(w)
 expected={'results':[compute(c)for c in cs],'scenarios':[[compute(shifted(c,s))for s in w['scenarios']]for c in cs],'sensitivity':[],'scenario_inputs':[[shifted(c,s)for s in w['scenarios']]for c in cs]}
 for c in cs:
  cells=[]
  for a in w['settings']['priceAxis'].split(','):
   for b in w['settings']['quantityAxis'].split(','):
    n=dict(c);n['标价']=text(F(c['标价'])*(1+F(a)/100));n['销量']=str((F(c['销量'])*(1+F(b)/100)).numerator//(F(c['销量'])*(1+F(b)/100)).denominator);cells.append(compute(n))
  expected['sensitivity'].append(cells)
 (out/'expected.json').write_text(json.dumps(expected,ensure_ascii=False));print({'independent_schemes':604,'scenarios':1812,'sensitivity_cells':15100,'method':'Python Fraction; exact integer ceilings/floors; 120 precision Decimal only formatted repeating ratios'})
