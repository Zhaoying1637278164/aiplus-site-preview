# coding: utf-8
from pathlib import Path
import json,csv,sys,openpyxl
from independent import compute,shifted,text,F,H
D=Path(sys.argv[1]);work=json.loads((D/'work.json').read_text())['work'];version='0.1.2';rule='M03-2026-10-04.2'
headers=[['方案ID','方案名称','期间','币种','金额单位','数量单位','源文件','页签','原始行','净单价','单位贡献','收入','变动成本','固定成本','贡献','经营利润','勾稽差额','理论保本量(近似30位)','整件保本量','整件保本收入','整件保本利润','目标销量','目标量利润','最低净价(向上到分)','最低标价(向上到分)','最大折扣%(向下6位)','安全边际件(整件)','安全边际%','贡献率%','目标差距','状态','限制'],['源文件','页签','原始行',*work['table']['headers']],['源文件','页签','原始行',*H],['源文件','页签','原始行','字段','原值','现值'],['源文件','页签','原始行','字段','级别','信息'],['方案ID','方案名称','期间','币种','金额单位','数量单位','源文件','页签','原始行','情景','依据','情景销量(向下整件)','净单价','单位变动成本','固定成本','利润','状态','限制'],['方案ID','方案名称','期间','币种','金额单位','数量单位','源文件','页签','原始行','价格变动%','销量变动%','净单价','销量','利润','状态','限制'],['参数','值'],['名称','折扣%','销量变动%','变动成本变动%','固定成本变动%','依据']]
names=['结果全量','原始来源全量','有效假设全量','覆盖记录','异常与限制','情景全量','敏感性首个有效方案','参数与口径','情景假设']
expected=[[]for _ in names];cs=[]
for i,r in enumerate(work['table']['rows']):
 c={**r['cells'],**work['overrides'].get(str(i),{})};cs.append(c);v=compute(c);prefix=[c['方案ID'],c['方案名称'],c['期间'],c['币种'],'元','件',r['file'],r['sheet'],r['row']]
 expected[0].append(prefix+v);expected[1].append([r['file'],r['sheet'],r['row'],*[r['cells'].get(h)for h in work['table']['headers']]]);expected[2].append([r['file'],r['sheet'],r['row'],*[c.get(h)for h in H]])
 for h,x in work['overrides'].get(str(i),{}).items():expected[3].append([r['file'],r['sheet'],r['row'],h,r['cells'][h],x])
 for warning in v[-1].split('；')if v[-1]else []:expected[4].append([r['file'],r['sheet'],r['row'],'经营限制','提示',warning])
 for s in work['scenarios']:
  sc=shifted(c,s);sv=compute(sc);expected[5].append(prefix+[s['name'],s['basis'],sc['销量'],sv[0],sc['单位变动成本'],sc['固定成本'],sv[6],sv[21],sv[22]])
 if i==0:
  for p in work['settings']['priceAxis'].split(','):
   for q in work['settings']['quantityAxis'].split(','):
    sc=dict(c);sc['标价']=text(F(c['标价'])*(1+F(p)/100));n=F(c['销量'])*(1+F(q)/100);sc['销量']=str(n.numerator//n.denominator);sv=compute(sc);expected[6].append(prefix+[p,q,sv[0],sc['销量'],sv[6],sv[21],sv[22]])
s=work['settings'];expected[7]=[['应用版本',version],['规则版本',rule],['生效','2026-10-04起，非税务会计政策'],['有效方案',len(cs)],['阻塞原始行',0],['数据行',len(cs)],['显示位数',s['display']],['勾稽容差',s['tolerance']],['价格轴',s['priceAxis']],['数量轴',s['quantityAxis']],['敏感性导出范围','首个有效方案；页面所选方案另行下载'],['数量口径','整件；情景数量向下取整'],['价格口径','不含税；元/件；不自动换汇'],['公式','利润=标价×(1-折扣%)×销量-单位变动成本×销量-固定成本'],['预测边界','用户假设；无真实弹性、市场或竞争价格预测']]
expected[8]=[[s[k]for k in ['name','discount','volumeChange','variableChange','fixedChange','basis']]for s in work['scenarios']]
normalize=lambda row:[''if v is None else json.dumps(v,ensure_ascii=False,separators=(',',':'))if isinstance(v,dict)else str(v)for v in row]
wb=openpyxl.load_workbook(D/'report.xlsx',data_only=False);assert wb.sheetnames==names;count=0
for i,name in enumerate(names):
 target=[headers[i],*expected[i]];actual=[list(r)for r in wb[name].values]
 # ExcelJS does not materialize trailing empty cells, but sheet dimensions hold the complete schema.
 assert len(actual)==len(target),(name,len(actual),len(target))
 for j,(a,b)in enumerate(zip(actual,target)):
  n=normalize(b);a=normalize(a);a=a[:len(n)];a+=['']*(len(n)-len(a));assert a==n,(name,j,a,n);count+=len(n)
 for row in wb[name]:
  for c in row:assert c.data_type!='f',(name,c.coordinate,'unexpected formula')
with open(D/'result.csv',encoding='utf-8-sig',newline='')as f:rows=list(csv.reader(f))
assert rows==[normalize(r)for r in [headers[0],*expected[0]]]
p=json.loads((D/'plan.json').read_text());assert p['contains_data']==False and p['work']['table']is None and p['work']['overrides']=={};assert p['work']['settings']==work['settings']and p['work']['scenarios']==work['scenarios']
assert json.loads((D/'restored-work.json').read_text())['work']==work
summary={'stage':D.name,'schemes':len(cs),'sheets':9,'xlsx_cells_checked':count,'csv_cells_checked':sum(len(r)for r in rows),'JSON_roundtrip_all_fields':True,'no_formula_cells':True,'method':'Independent Python Fraction + openpyxl raw static text cell comparison'};(D/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(summary)
