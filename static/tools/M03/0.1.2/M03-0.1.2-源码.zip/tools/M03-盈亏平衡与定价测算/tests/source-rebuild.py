from pathlib import Path
import json,shutil,zipfile,hashlib,subprocess,os,time
root=Path.cwd();tool=Path('tools/M03-盈亏平衡与定价测算');e=root/'progress/evidence/M03/0.1.2';base=e/'source-snapshot';dest=Path('/private/tmp')/('m03-source-rebuilt-'+str(time.time_ns()));
for d in [base,dest]:
 if d.exists():shutil.rmtree(d)
base.mkdir()
for f in ['package-lock.json']:
 shutil.copy2(root/f,base/f)
p=json.loads((root/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/M03-盈亏平衡与定价测算/tests/*.test.ts','typecheck':'tsc --noEmit','build':'node --import tsx tools/M03-盈亏平衡与定价测算/tests/build.ts'};(base/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(base/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','jsx':'react-jsx','strict':True,'esModuleInterop':True,'skipLibCheck':True,'lib':['ES2022','DOM'],'types':['node'],'noEmit':True},'include':['tools','packages']},indent=2))
shutil.copytree(root/tool,base/tool);
for name in ['independent','fixtures']:
 shutil.copytree(e/name,base/'progress/evidence/M03/0.1.2'/name)
shutil.copytree(root/'packages/core',base/'packages/core');(base/'packages/ui').mkdir(parents=True);shutil.copy2(root/'packages/ui/tool-host.ts',base/'packages/ui/tool-host.ts');(base/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',base/'references/saxes-5.0.1-LICENSE')
shutil.copy2(e/'candidate/THIRD_PARTY_NOTICES.md',base/'THIRD_PARTY_NOTICES.md')
(base/'构建说明.md').write_text('候选源码快照，只包含本款、已使用共享core与ToolHost接口、项目依赖和锁文件。Node22+。npm ci --ignore-scripts；npm test；npm run typecheck；npm run build。安装依赖需联网或完整npm缓存；成品断网可用。浏览器验收 npm exec -- node --import tsx tools/M03-盈亏平衡与定价测算/tests/browser.ts，需本机Chrome。输出progress/evidence/M03/0.1.2/candidate。原根package仅调整验证脚本和tsconfig作用域，依赖版本与锁文件未改。无业务数据/凭据/node_modules。正式包由总控负责。')
zip_path=e/'M03-0.1.2-候选源码.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED)as z:
 for f in sorted(base.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(base))
download=e/'downloaded-source'
r=subprocess.run(['node','--import','tsx',str(tool/'tests/download-archive.ts'),str(zip_path),str(download)],cwd=root,text=True,capture_output=True)
(e/'source-download.log').write_text(r.stdout+r.stderr)
assert r.returncode==0, 'actual source ZIP download failed'
with zipfile.ZipFile(download/'downloaded.zip')as z:
 assert z.testzip() is None
 assert all(not i.filename.startswith('/') and '..' not in Path(i.filename).parts for i in z.infolist())
 z.extractall(dest)
commands=[]
for cmd in [['npm','ci','--offline','--ignore-scripts','--cache',str(e/'npm-cache')],['npm','test'],['npm','run','typecheck'],['npm','run','build']]:
 # Use the existing user npm cache for offline installation; never read credentials/config contents.
 if cmd[1]=='ci':cmd=['npm','ci','--offline','--ignore-scripts','--audit=false','--fund=false']
 r=subprocess.run(cmd,cwd=dest,text=True,capture_output=True,env={**os.environ,'TSX_DISABLE_CACHE':'1'});log=e/('source-'+str(len(commands))+'.log');log.write_text(r.stdout+r.stderr);commands.append({'command':cmd,'exit':r.returncode,'log':str(log.relative_to(root)),'environment_overrides':{'TSX_DISABLE_CACHE':'1'}})
 if r.returncode:break
comparison={}
if all(c['exit']==0 for c in commands)and len(commands)==4:
 for f in sorted((e/'candidate').iterdir()):
  if f.is_file():
   other=dest/'progress/evidence/M03/0.1.2/candidate'/f.name
   comparison[f.name]={'original':hashlib.sha256(f.read_bytes()).hexdigest(),'rebuilt':hashlib.sha256(other.read_bytes()).hexdigest()}
result={'zip_sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'commands':commands,'files':comparison,'all_match':bool(comparison)and all(v['original']==v['rebuilt'] for v in comparison.values()),'platform':'Mac Node22','isolated_directory':str(dest),'Windows':'未验证'};(e/'source-rebuild.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
