import pathlib,zipfile,tempfile,subprocess,json,hashlib,os,time
root=pathlib.Path.cwd();folder=root/'tools/M02-量价结构差异分析';out=folder/'candidate/0.1.2';e=root/'progress/evidence/M02/0.1.2/source-rebuild';e.mkdir(parents=True,exist_ok=True)
source=pathlib.Path(os.environ.get('M02_SOURCE_ZIP',str(out/'M02-0.1.2-源码.zip')));tmp=pathlib.Path(tempfile.mkdtemp(prefix='m02-rebuild-',dir='/private/tmp'))
with zipfile.ZipFile(source) as z:z.extractall(tmp)
manifest=json.loads((tmp/'SOURCE-SHA256.json').read_text());assert all(hashlib.sha256((tmp/f).read_bytes()).hexdigest()==sha for f,sha in manifest.items())
commands=['npm ci','npm run typecheck','npm test','npm run build'];runs=[];env=dict(os.environ);env['npm_config_cache']=str(tmp/'npm-cache');env['npm_config_audit']='false';env['npm_config_fund']='false'
try:
 for n,cmd in enumerate(commands):
  start=time.time()
  with (e/f'{n+1}.log').open('w') as f:p=subprocess.run(cmd.split(),cwd=tmp,env=env,stdout=f,stderr=subprocess.STDOUT)
  runs.append({'command':cmd,'exit_code':p.returncode,'seconds':round(time.time()-start,3),'log':str(e/f'{n+1}.log')});print(json.dumps(runs[-1]),flush=True)
  assert p.returncode==0,cmd+' failed'
 rebuilt=tmp/'tools/M02-量价结构差异分析/candidate/0.1.2';checks=[]
 for f in sorted(out.iterdir()):
  if f.is_file() and f.suffix!='.zip':
   actual=hashlib.sha256((rebuilt/f.name).read_bytes()).hexdigest();expected=hashlib.sha256(f.read_bytes()).hexdigest();assert actual==expected,f.name;checks.append({'file':f.name,'sha256':actual})
 result={'status':'passed','source_zip_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_entries':len(manifest),'commands':runs,'exact_assets':checks,'directory':str(tmp),'platform':'Mac host; Windows unverified'}
except Exception as ex:
 result={'status':'failed','error':str(ex),'commands':runs,'directory':str(tmp)}
(e/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));assert result['status']=='passed',result
