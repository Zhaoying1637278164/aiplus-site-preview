import type {Table,SourceRow} from '../../../packages/core/types';
export const VERSION='0.1.2',RULE_VERSION='M02-2026-10-05.3';
export type Side='left'|'right';
export type Field='product'|'category'|'period'|'currency'|'moneyUnit'|'quantityUnit'|'basis'|'quantity'|'price'|'unitCost'|'revenue'|'cost';
export type Fields=Record<Field,string>;
export type Factor='总量'|'结构'|'价格'|'单位成本';
export interface Config {periods:Record<Side,string>;fields:Record<Side,Fields>;order:Factor[];population:'all'|'common';precision:number;tolerance:string;trim:boolean;confirmed:boolean;note:string}
export const defaultFields=():Fields=>({product:'产品ID',category:'分类',period:'期间',currency:'币种',moneyUnit:'金额单位',quantityUnit:'数量单位',basis:'口径',quantity:'数量',price:'单价',unitCost:'单位成本',revenue:'',cost:''});
export const defaultConfig=():Config=>({periods:{left:'2026-08',right:'2026-09'},fields:{left:defaultFields(),right:defaultFields()},order:['总量','结构','价格','单位成本'],population:'all',precision:6,tolerance:'0.000001',trim:false,confirmed:false,note:''});
export interface Work {config:Config;left:Table|null;right:Table|null}
export interface Parsed {side:Side;source:SourceRow;key:string|null;partition:string[];product:string;category:string;q:string|null;p:string|null;c:string|null;revenue:string|null;gross:string|null;modelRevenue:string|null;modelGross:string|null;errors:string[];excluded:boolean}
export interface Metric {old:string|null;next:string|null;delta:string|null;effects:Record<Factor,string>;added:string;exited:string;special:string;inputResidual:string;residual:string;blocked:boolean;reason:string}
export interface Item {key:string;partition:string[];product:string;category:string;status:string;left:Parsed[];right:Parsed[];revenue:Metric;gross:Metric}
export interface Bridge {partition:string[];metric:'收入'|'毛利';old:string;next:string;delta:string;effects:Record<Factor,string>;added:string;exited:string;special:string;inputResidual:string;residual:string;blockedOld:string;blockedNext:string;unknownOld:number;unknownNext:number;blockedItems:number;excludedItems:number;withinTolerance:boolean}
export interface Result {items:Item[];rows:Parsed[];bridges:Bridge[];config:Config;leftRows:number;rightRows:number}

export const orders:Factor[][]=(()=>{const perm=(a:Factor[]):Factor[][]=>a.length?a.flatMap((x,i)=>perm(a.filter((_,j)=>j!==i)).map(t=>[x,...t])):[[]];return perm(['总量','结构','价格','单位成本'])})();
