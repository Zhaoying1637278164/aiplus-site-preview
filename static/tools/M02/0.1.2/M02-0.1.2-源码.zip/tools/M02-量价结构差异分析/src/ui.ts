// Presentation only. Export schemas and financial values are untouched.
export const valueText=(v:unknown)=>v===null||v===undefined?'〈缺失/不适用〉':typeof v==='object'?JSON.stringify(v):String(v);
export interface BusinessView {headers:string[];rows:unknown[][];technical:{key:unknown;left:unknown;right:unknown}[]}
export function businessView(headers:string[],rows:unknown[][],partitions?:string[][]):BusinessView {
 const technical=headers[0]==='业务键';const partition=technical?1:headers[0]==='分区'||headers[0]==='币种/金额单位/数量单位/口径'?0:headers.slice(0,4).join(',')==='侧别,文件,页签,原行'&&headers[6]==='分区'?6:-1;
 const excluded=new Set(technical?['业务键','基期来源','本期来源']:[]);
 const priority=['产品','产品ID','分类','样本分类','指标','基期','基期纳入','本期','本期纳入','变化','收入','毛利','数量','单价','单位成本','检查'].filter(h=>h!=='单位成本'||!headers.includes('总量'));
 const names=headers.filter(h=>!excluded.has(h)&&h!==headers[partition]);const sorted=[...priority.filter(h=>names.includes(h)),...names.filter(h=>!priority.includes(h))];
 if(partition>=0){const pos=Math.min(sorted.length,technical?7:sorted.includes('变化')?sorted.indexOf('变化')+1:sorted.includes('毛利')?sorted.indexOf('毛利')+1:0);sorted.splice(pos,0,'币种','金额单位','数量单位','口径')}
 const project=(row:unknown[],index:number)=>sorted.map(h=>{if(partition>=0&&['币种','金额单位','数量单位','口径'].includes(h))return (partitions?.[index]??(technical?JSON.parse(String(row[0])).slice(0,4):String(row[partition]??'').split(' / ')))[['币种','金额单位','数量单位','口径'].indexOf(h)]??'';return row[headers.indexOf(h)]});
 return {headers:sorted,rows:rows.map(project),technical:technical?rows.map(r=>({key:r[0],left:r[headers.indexOf('基期来源')],right:r[headers.indexOf('本期来源')]})):[]};
}
