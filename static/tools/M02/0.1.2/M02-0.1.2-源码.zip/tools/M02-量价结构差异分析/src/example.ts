import type {Table,Cell} from '../../../packages/core/types';import {defaultConfig,type Work} from './types';
export const headers=['产品ID','分类','期间','币种','金额单位','数量单位','口径','数量','单价','单位成本'];
export function table(file:string,values:Cell[][]):Table{return {file,sheet:'业务',headers:[...headers],rows:values.map((v,i)=>({file,sheet:'业务',row:i+2,cells:Object.fromEntries(headers.map((h,j)=>[h,v[j]??null]))}))}}
export const left=table('虚构基期.csv',[['001','标准产品','2026-08','CNY','元','件','不含税',10,10,6],['002','标准产品','2026-08','CNY','元','件','不含税',10,20,12],['003','退出产品','2026-08','CNY','元','件','不含税',2,15,9]]);
export const right=table('虚构本期.csv',[['001','标准产品','2026-09','CNY','元','件','不含税',15,12,7],['002','标准产品','2026-09','CNY','元','件','不含税',5,22,13],['004','新增产品','2026-09','CNY','元','件','不含税',3,30,18]]);
export const exampleConfig={...defaultConfig(),confirmed:true};export const example:Work={left,right,config:exampleConfig};
