// tools/M02-量价结构差异分析/tests/selection-browser.ts
import { chromium } from "playwright";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import ExcelJS from "exceljs";

// packages/core/types.ts
var LIMITS = { bytes: 10 * 1024 * 1024, inflated: 30 * 1024 * 1024, rows: 2e4, columns: 200 };

// tools/M02-量价结构差异分析/src/engine.ts
import Decimal from "decimal.js";
var D = Decimal.clone({ precision: 70, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -100, toExpPos: 100 });
var required = ["product", "category", "period", "currency", "moneyUnit", "quantityUnit", "basis", "quantity", "price"];
var factors = ["\u603B\u91CF", "\u7ED3\u6784", "\u4EF7\u683C", "\u5355\u4F4D\u6210\u672C"];
function decimal(v) {
  if (v === null || v === void 0 || v === "") throw Error("\u7F3A\u5931");
  if (typeof v === "object") throw Error("\u516C\u5F0F/\u5BF9\u8C61\u7981\u6B62");
  const s = String(v);
  if (!/^-?(?:0|[1-9]\d{0,17})(?:\.\d{1,6})?$/.test(s)) throw Error("\u6570\u503C\u987B\u4E3A\u666E\u901A\u5341\u8FDB\u5236\uFF0C\u6700\u591A18\u4F4D\u6574\u65706\u4F4D\u5C0F\u6570");
  const x = new D(s);
  if (!x.isFinite()) throw Error("\u975E\u6709\u9650\u503C");
  return x.toFixed();
}
function validateConfig(c) {
  if (!c || !c.periods || !c.fields || typeof c.trim !== "boolean" || typeof c.confirmed !== "boolean" || typeof c.note !== "string" || c.note.length > 1e4) throw Error("\u53E3\u5F84\u53C2\u6570\u65E0\u6548");
  for (const s of ["left", "right"]) {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(c.periods[s]) || c.periods[s].startsWith("0000")) throw Error("\u671F\u95F4\u987B\u4E3AYYYY-MM");
    if (!c.fields[s]) throw Error("\u5B57\u6BB5\u5BF9\u5E94\u7F3A\u5931");
    for (const f2 of [...required, "unitCost", "revenue", "cost"]) {
      if (typeof c.fields[s][f2] !== "string" || c.fields[s][f2].length > 200 || required.includes(f2) && !c.fields[s][f2]) throw Error("\u5B57\u6BB5\u5BF9\u5E94\u65E0\u6548 " + f2);
    }
  }
  if (c.periods.left === c.periods.right) throw Error("\u4E24\u671F\u5FC5\u987B\u4E0D\u540C");
  if (!Array.isArray(c.order) || c.order.length !== 4 || new Set(c.order).size !== 4 || c.order.some((f2) => !factors.includes(f2))) throw Error("\u56E0\u7D20\u987A\u5E8F\u65E0\u6548");
  if (!["all", "common"].includes(c.population) || !Number.isInteger(c.precision) || c.precision < 0 || c.precision > 6) throw Error("\u8303\u56F4/\u7CBE\u5EA6\u65E0\u6548");
  if (new D(decimal(c.tolerance)).lt(0)) throw Error("\u5BB9\u5DEE\u4E0D\u5F97\u8D1F\u6570");
}
function validateTable(t) {
  if (!t || typeof t.file !== "string" || typeof t.sheet !== "string" || !t.file || !t.sheet || t.file.length > 1e4 || t.sheet.length > 1e4 || !Array.isArray(t.headers) || !t.headers.length || t.headers.length > LIMITS.columns || t.headers.some((h) => typeof h !== "string" || !h || h.length > 200) || new Set(t.headers).size !== t.headers.length || !Array.isArray(t.rows) || t.rows.length > LIMITS.rows) throw Error("\u539F\u8868\u7ED3\u6784/\u884C\u5217\u8D85\u9650");
  const seen = /* @__PURE__ */ new Set();
  for (const r of t.rows) {
    if (!r || r.file !== t.file || r.sheet !== t.sheet || !Number.isInteger(r.row) || r.row < 1 || seen.has(r.row) || !r.cells || Array.isArray(r.cells) || typeof r.cells !== "object" || Object.keys(r.cells).some((h) => !t.headers.includes(h))) throw Error("\u6765\u6E90\u884C\u7ED3\u6784\u65E0\u6548");
    seen.add(r.row);
    for (const v of Object.values(r.cells)) {
      if (v !== null && typeof v !== "string" && typeof v !== "number" && (typeof v !== "object" || typeof v.formula !== "string")) throw Error("\u5355\u5143\u683C\u7C7B\u578B\u65E0\u6548");
      if (typeof v === "string" && v.length > 1e4 || typeof v === "number" && !Number.isFinite(v)) throw Error("\u5355\u5143\u683C\u5185\u5BB9\u65E0\u6548");
    }
  }
}

// tools/M02-量价结构差异分析/src/types.ts
var VERSION = "0.1.2";
var RULE_VERSION = "M02-2026-10-05.3";
var orders = (() => {
  const perm = (a) => a.length ? a.flatMap((x, i) => perm(a.filter((_, j) => j !== i)).map((t) => [x, ...t])) : [[]];
  return perm(["\u603B\u91CF", "\u7ED3\u6784", "\u4EF7\u683C", "\u5355\u4F4D\u6210\u672C"]);
})();

// tools/M02-量价结构差异分析/src/plan.ts
function validateWork(w) {
  if (!w) throw Error("\u5DE5\u4F5C\u7F3A\u5931");
  validateConfig(w.config);
  if (w.left !== null) validateTable(w.left);
  if (w.right !== null) validateTable(w.right);
}
function encode(w, contains_data) {
  validateWork(w);
  const raw = JSON.stringify({ schema_version: 1, tool: "M02", app_version: VERSION, rule_version: RULE_VERSION, contains_data, work: { config: w.config, left: contains_data ? w.left : null, right: contains_data ? w.right : null } }, null, 2);
  if (new TextEncoder().encode(raw).length > LIMITS.bytes) throw Error("\u65B9\u6848\u8D85\u8FC710MB\uFF0C\u8BF7\u5206\u522B\u4E0B\u8F7D\u6E90\u8D44\u6599\u548C\u65E0\u6570\u636E\u65B9\u6848");
  return raw;
}

// tools/M02-量价结构差异分析/tests/selection-browser.ts
var dir = path.dirname(fileURLToPath(import.meta.url));
var out = path.resolve("progress/evidence/M02/0.1.2/selection-browser");
await mkdir(out, { recursive: true });
var work = JSON.parse(await readFile(dir + "/fixtures/work.json", "utf8"));
var wb = new ExcelJS.Workbook();
for (const side of ["left", "right"]) {
  const ws = wb.addWorksheet(side);
  ws.addRow(["\u5B8C\u5168\u865A\u6784\u8BF4\u660E"]);
  ws.addRow(work[side].headers);
  for (const r of work[side].rows) ws.addRow(work[side].headers.map((h) => r.cells[h] ?? null));
}
var f = out + "/selection.xlsx";
await writeFile(f, new Uint8Array(await wb.xlsx.writeBuffer()));
var browser = await chromium.launch({ headless: true, executablePath: "/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing" });
var ctx = await browser.newContext({ offline: true, acceptDownloads: true });
var page = await ctx.newPage();
page.on("dialog", (d) => d.accept());
var checks = [];
var nav = (i) => page.locator("nav button").nth(i).click();
var dump = async (name) => {
  await nav(8);
  const wait = page.waitForEvent("download");
  await page.getByRole("button", { name: "\u4E0B\u8F7D\u542B\u6570\u636E\u5DE5\u4F5C", exact: true }).click();
  const d = await wait;
  const file = out + "/" + name + ".json";
  await d.saveAs(file);
  return JSON.parse(await readFile(file, "utf8")).work;
};
try {
  await page.goto("file://" + path.resolve("tools/M02-\u91CF\u4EF7\u7ED3\u6784\u5DEE\u5F02\u5206\u6790/candidate/0.1.2/index.html"));
  const plan = out + "/work.json";
  await writeFile(plan, encode(work, true));
  await nav(8);
  await page.getByLabel("\u6062\u590D\u5DE5\u4F5C", { exact: true }).setInputFiles(plan);
  await page.getByRole("status").filter({ hasText: "\u6062\u590D\u5B8C\u6210" }).waitFor();
  for (const s of ["left", "right"]) {
    await nav(0);
    await page.getByLabel(s === "left" ? "\u57FA\u671F\u6587\u4EF6" : "\u672C\u671F\u6587\u4EF6", { exact: true }).setInputFiles(f);
    await page.getByRole("status").filter({ hasText: "\u6587\u4EF6\u5DF2\u5728\u672C\u673A\u8BFB\u53D6" }).waitFor();
    await page.getByLabel(s + "\u9875\u7B7E").selectOption(s);
    await page.locator(".m02-cards section").nth(s === "left" ? 0 : 1).locator("input[type=number]").fill("2");
    await page.getByRole("button", { name: s === "left" ? "\u786E\u8BA4\u57FA\u671F\u8D44\u6599" : "\u786E\u8BA4\u672C\u671F\u8D44\u6599", exact: true }).click();
  }
  await nav(1);
  await page.getByRole("button", { name: "\u8BA1\u7B97\u91CF\u4EF7\u7ED3\u6784", exact: true }).click();
  await page.getByRole("status").filter({ hasText: "\u8BA1\u7B97\u5B8C\u6210" }).waitFor();
  await nav(0);
  await page.getByLabel("left\u9875\u7B7E").selectOption("right");
  await nav(4);
  assert.match(await page.locator("main").innerText(), /清除旧结果/);
  assert.equal((await dump("sheet-change")).left, null);
  checks.push("\u6539\u53D8\u5DF2\u8BA1\u7B97\u8D44\u6599\u9875\u7B7E\u7ACB\u5373\u6E05\u65E7\u7ED3\u679C/\u539F\u4FA7\u786E\u8BA4\uFF0C\u5BFC\u51FA\u5168\u90E8\u53E6\u4E00\u4FA7\u539F\u8D44\u6599");
  await nav(0);
  await page.getByLabel("left\u9875\u7B7E").selectOption("left");
  await page.getByRole("button", { name: "\u786E\u8BA4\u57FA\u671F\u8D44\u6599", exact: true }).click();
  await nav(1);
  await page.getByRole("button", { name: "\u8BA1\u7B97\u91CF\u4EF7\u7ED3\u6784", exact: true }).click();
  await nav(0);
  await page.locator(".m02-cards section").nth(0).locator("input[type=number]").fill("1");
  await nav(5);
  assert.match(await page.locator("main").innerText(), /清除旧结果/);
  const w = await dump("header-change");
  assert.equal(w.left, null);
  assert.equal(w.right.rows.length, work.right.rows.length);
  checks.push("\u6539\u53D8\u5DF2\u8BA1\u7B97\u8D44\u6599\u8868\u5934\u7ACB\u5373\u6E05\u65E7\u7ED3\u679C\u53CA\u539F\u4FA7\u786E\u8BA4\uFF0C\u5B8C\u6574JSON\u65E0\u65E7\u8D44\u6599\u590D\u6302");
  await nav(0);
  await page.getByRole("button", { name: "\u786E\u8BA4\u57FA\u671F\u8D44\u6599", exact: true }).click();
  assert.match(await page.getByRole("status").innerText(), /无表头/);
  checks.push("\u9519\u8BEF\u8868\u5934\u62D2\u7EDD\uFF0C\u4E0D\u9690\u5F0F\u53D6\u7B2C\u4E00\u884C");
  await page.locator(".m02-cards section").nth(0).locator("input[type=number]").fill("2");
  await page.getByRole("button", { name: "\u786E\u8BA4\u57FA\u671F\u8D44\u6599", exact: true }).click();
  await nav(1);
  await page.getByRole("button", { name: "\u8BA1\u7B97\u91CF\u4EF7\u7ED3\u6784", exact: true }).click();
  await page.getByRole("status").filter({ hasText: "\u8BA1\u7B97\u5B8C\u6210" }).waitFor();
  checks.push("\u9009\u62E9\u6B63\u786E\u8868\u5934\u91CD\u65B0\u786E\u8BA4\u53EF\u8BA1\u7B97");
  await writeFile(out + "/result.json", JSON.stringify({ status: "passed", checks, html_sha256: createHash("sha256").update(await readFile("tools/M02-\u91CF\u4EF7\u7ED3\u6784\u5DEE\u5F02\u5206\u6790/candidate/0.1.2/index.html")).digest("hex"), scope: "local fictional actual Mac Chromium offline; public/Windows unverified" }, null, 2));
} finally {
  await browser.close();
}
