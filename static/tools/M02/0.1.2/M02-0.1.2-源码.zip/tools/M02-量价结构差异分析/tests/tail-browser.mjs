// tools/M02-量价结构差异分析/tests/tail-browser.ts
import { chromium } from "playwright";
import assert from "node:assert/strict";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";

// packages/core/types.ts
var LIMITS = { bytes: 10 * 1024 * 1024, inflated: 30 * 1024 * 1024, rows: 2e4, columns: 200 };

// tools/M02-量价结构差异分析/src/engine.ts
import Decimal from "decimal.js";
var D = Decimal.clone({ precision: 70, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -100, toExpPos: 100 });
var required = ["product", "category", "period", "currency", "moneyUnit", "quantityUnit", "basis", "quantity", "price"];
var factors = ["\u603B\u91CF", "\u7ED3\u6784", "\u4EF7\u683C", "\u5355\u4F4D\u6210\u672C"];
function decimal(v) {
  if (v === null || v === void 0 || v === "") throw Error("\u7F3A\u5931");
  if (typeof v === "object") throw Error("\u516C\u5F0F/\u5BF9\u8C61\u7981\u6B62");
  const s = String(v);
  if (!/^-?(?:0|[1-9]\d{0,17})(?:\.\d{1,6})?$/.test(s)) throw Error("\u6570\u503C\u987B\u4E3A\u666E\u901A\u5341\u8FDB\u5236\uFF0C\u6700\u591A18\u4F4D\u6574\u65706\u4F4D\u5C0F\u6570");
  const x = new D(s);
  if (!x.isFinite()) throw Error("\u975E\u6709\u9650\u503C");
  return x.toFixed();
}
function validateConfig(c) {
  if (!c || !c.periods || !c.fields || typeof c.trim !== "boolean" || typeof c.confirmed !== "boolean" || typeof c.note !== "string" || c.note.length > 1e4) throw Error("\u53E3\u5F84\u53C2\u6570\u65E0\u6548");
  for (const s of ["left", "right"]) {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(c.periods[s]) || c.periods[s].startsWith("0000")) throw Error("\u671F\u95F4\u987B\u4E3AYYYY-MM");
    if (!c.fields[s]) throw Error("\u5B57\u6BB5\u5BF9\u5E94\u7F3A\u5931");
    for (const f of [...required, "unitCost", "revenue", "cost"]) {
      if (typeof c.fields[s][f] !== "string" || c.fields[s][f].length > 200 || required.includes(f) && !c.fields[s][f]) throw Error("\u5B57\u6BB5\u5BF9\u5E94\u65E0\u6548 " + f);
    }
  }
  if (c.periods.left === c.periods.right) throw Error("\u4E24\u671F\u5FC5\u987B\u4E0D\u540C");
  if (!Array.isArray(c.order) || c.order.length !== 4 || new Set(c.order).size !== 4 || c.order.some((f) => !factors.includes(f))) throw Error("\u56E0\u7D20\u987A\u5E8F\u65E0\u6548");
  if (!["all", "common"].includes(c.population) || !Number.isInteger(c.precision) || c.precision < 0 || c.precision > 6) throw Error("\u8303\u56F4/\u7CBE\u5EA6\u65E0\u6548");
  if (new D(decimal(c.tolerance)).lt(0)) throw Error("\u5BB9\u5DEE\u4E0D\u5F97\u8D1F\u6570");
}
function validateTable(t) {
  if (!t || typeof t.file !== "string" || typeof t.sheet !== "string" || !t.file || !t.sheet || t.file.length > 1e4 || t.sheet.length > 1e4 || !Array.isArray(t.headers) || !t.headers.length || t.headers.length > LIMITS.columns || t.headers.some((h) => typeof h !== "string" || !h || h.length > 200) || new Set(t.headers).size !== t.headers.length || !Array.isArray(t.rows) || t.rows.length > LIMITS.rows) throw Error("\u539F\u8868\u7ED3\u6784/\u884C\u5217\u8D85\u9650");
  const seen = /* @__PURE__ */ new Set();
  for (const r of t.rows) {
    if (!r || r.file !== t.file || r.sheet !== t.sheet || !Number.isInteger(r.row) || r.row < 1 || seen.has(r.row) || !r.cells || Array.isArray(r.cells) || typeof r.cells !== "object" || Object.keys(r.cells).some((h) => !t.headers.includes(h))) throw Error("\u6765\u6E90\u884C\u7ED3\u6784\u65E0\u6548");
    seen.add(r.row);
    for (const v of Object.values(r.cells)) {
      if (v !== null && typeof v !== "string" && typeof v !== "number" && (typeof v !== "object" || typeof v.formula !== "string")) throw Error("\u5355\u5143\u683C\u7C7B\u578B\u65E0\u6548");
      if (typeof v === "string" && v.length > 1e4 || typeof v === "number" && !Number.isFinite(v)) throw Error("\u5355\u5143\u683C\u5185\u5BB9\u65E0\u6548");
    }
  }
}

// tools/M02-量价结构差异分析/src/types.ts
var VERSION = "0.1.2";
var RULE_VERSION = "M02-2026-10-05.3";
var orders = (() => {
  const perm = (a) => a.length ? a.flatMap((x, i) => perm(a.filter((_, j) => j !== i)).map((t) => [x, ...t])) : [[]];
  return perm(["\u603B\u91CF", "\u7ED3\u6784", "\u4EF7\u683C", "\u5355\u4F4D\u6210\u672C"]);
})();

// tools/M02-量价结构差异分析/src/plan.ts
function validateWork(w) {
  if (!w) throw Error("\u5DE5\u4F5C\u7F3A\u5931");
  validateConfig(w.config);
  if (w.left !== null) validateTable(w.left);
  if (w.right !== null) validateTable(w.right);
}
function encode(w, contains_data) {
  validateWork(w);
  const raw = JSON.stringify({ schema_version: 1, tool: "M02", app_version: VERSION, rule_version: RULE_VERSION, contains_data, work: { config: w.config, left: contains_data ? w.left : null, right: contains_data ? w.right : null } }, null, 2);
  if (new TextEncoder().encode(raw).length > LIMITS.bytes) throw Error("\u65B9\u6848\u8D85\u8FC710MB\uFF0C\u8BF7\u5206\u522B\u4E0B\u8F7D\u6E90\u8D44\u6599\u548C\u65E0\u6570\u636E\u65B9\u6848");
  return raw;
}

// tools/M02-量价结构差异分析/tests/tail-browser.ts
var dir = path.dirname(fileURLToPath(import.meta.url));
var out = path.resolve("progress/evidence/M02/0.1.2/tail-browser");
await mkdir(out, { recursive: true });
var work = JSON.parse(await readFile(dir + "/fixtures/work.json", "utf8"));
work.right.rows.at(-1).cells["\u6570\u91CF"] = "7.000001";
work.right.rows.at(-1).cells["\u5355\u4EF7"] = "31.125";
work.config.note = "\u672B\u884C\u6E90\u8D44\u6599\u4FEE\u6B63\u3001\u539F\u59CB\u6536\u5165\u4ECD\u4FDD\u7559";
var expected = JSON.parse(execFileSync("python3", [dir + "/oracle.py", "input"], { input: JSON.stringify(work), maxBuffer: 20 * 1024 * 1024 }).toString());
var target = out + "/corrected.json";
await writeFile(target, encode(work, true));
var browser = await chromium.launch({ headless: true, executablePath: "/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing" });
var ctx = await browser.newContext({ offline: true, viewport: { width: 320, height: 1e3 } });
var page = await ctx.newPage();
page.on("dialog", (d) => d.accept());
var ui = (g) => JSON.parse(execFileSync("python3", [dir + "/ui-oracle.py"], { input: JSON.stringify(g), maxBuffer: 20 * 1024 * 1024 }).toString());
var uiExpected = ui(expected);
var checks = [];
try {
  await page.goto("file://" + path.resolve("tools/M02-\u91CF\u4EF7\u7ED3\u6784\u5DEE\u5F02\u5206\u6790/candidate/0.1.2/index.html"));
  await page.locator("nav button").nth(8).click();
  await page.getByLabel("\u6062\u590D\u5DE5\u4F5C", { exact: true }).setInputFiles(target);
  await page.getByRole("status").filter({ hasText: "\u6062\u590D\u5B8C\u6210" }).waitFor();
  await page.locator("nav button").nth(1).click();
  await page.getByRole("button", { name: "\u8BA1\u7B97\u91CF\u4EF7\u7ED3\u6784", exact: true }).click();
  const last = expected.result.items.find((i) => i.product === "P0603");
  for (const n of [4, 5]) {
    await page.locator("nav button").nth(n).click();
    const id = n === 4 ? "\u6536\u5165\u660E\u7EC6" : "\u6BDB\u5229\u660E\u7EC6", grid = page.locator(`[data-grid="${id}"]`);
    await grid.getByRole("textbox").fill("P0603");
    const want = uiExpected[id].rows.filter((r) => r[0] === "P0603");
    const actual = await grid.locator("tbody tr").evaluateAll((rows) => rows.map((r) => Array.from(r.querySelectorAll("td[data-business]")).map((c) => c.textContent)));
    assert.deepEqual(actual, want.map((r) => r.map((x) => x == null ? "\u3008\u7F3A\u5931/\u4E0D\u9002\u7528\u3009" : String(x))));
    await grid.locator("[data-card] details").first().evaluate((e) => e.open = true);
    await grid.locator("[data-card]").first().scrollIntoViewIfNeeded();
    await page.screenshot({ path: out + `/tail-${id}-320.png`, fullPage: true });
    checks.push(id + "\u672B\u884C\u5168\u90E8\u56E0\u7D20/\u539F\u989D\u504F\u79BB/\u6B8B\u5DEE\u72EC\u7ACB\u9884\u671F");
  }
  await page.locator("nav button").nth(7).click();
  await page.getByLabel("\u8FFD\u67E5\u9879\u76EE").selectOption(last.key);
  for (const side of ["left", "right"]) {
    const grid = page.locator(`[data-grid="${side}\u6765\u6E90"]`), t = work[side], rows = last[side].map((r) => [r.source.file, r.source.sheet, r.source.row, ...t.headers.map((h) => r.source.cells[h])]);
    assert.deepEqual(await grid.locator("tbody tr").evaluateAll((trs) => trs.map((tr) => Array.from(tr.querySelectorAll("td[data-business]")).map((c) => c.textContent))), ui({ headers: ["\u6587\u4EF6", "\u9875\u7B7E", "\u539F\u884C", ...t.headers], rows }).rows.map((r) => r.map((x) => x == null ? "\u3008\u7F3A\u5931/\u4E0D\u9002\u7528\u3009" : String(x))));
    await grid.locator(".m02-scroll").evaluate((el) => el.scrollLeft = el.scrollWidth);
  }
  await page.locator("[data-grid=right\u6765\u6E90] [data-card]").first().scrollIntoViewIfNeeded();
  await page.locator("[data-grid=right\u6765\u6E90] [data-card] details").first().evaluate((e) => e.open = true);
  await page.screenshot({ path: out + "/tail-source-right-320.png", fullPage: true });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true);
  checks.push("\u672B\u884C\u4E24\u671F\u5B8C\u6574\u6765\u6E90/\u4FEE\u6539\u6570\u91CF\u5355\u4EF7/\u4FDD\u7559\u539F\u989D/\u8868\u5185\u53F3\u6EDA\uFF0C\u6587\u6863\u4E0D\u6A2A\u6EA2");
  await writeFile(out + "/result.json", JSON.stringify({ status: "passed", checks, html_sha256: createHash("sha256").update(await readFile("tools/M02-\u91CF\u4EF7\u7ED3\u6784\u5DEE\u5F02\u5206\u6790/candidate/0.1.2/index.html")).digest("hex"), scope: "Mac Chromium local offline; Windows and original/public site unverified" }, null, 2));
} finally {
  await browser.close();
}
