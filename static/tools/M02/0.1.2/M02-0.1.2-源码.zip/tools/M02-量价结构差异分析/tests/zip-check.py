import zipfile,pathlib,hashlib,json,sys,io
source=pathlib.Path(sys.argv[1]);dest=pathlib.Path(sys.argv[2]);result=pathlib.Path(sys.argv[3]);dest.mkdir(parents=True,exist_ok=True)
def scan(data,allow_unsafe_fixture=False):
 out=[]
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  assert z.testzip() is None
  for i in z.infolist():
   safe='..' not in pathlib.PurePosixPath(i.filename).parts and not i.filename.startswith('/')
   assert safe or allow_unsafe_fixture
   raw=z.read(i.filename);assert len(raw)==i.file_size
   item={'path':i.filename,'bytes':len(raw),'crc32':format(i.CRC,'08x'),'sha256':hashlib.sha256(raw).hexdigest(),'safe_path':safe,'intentional_unsafe_fixture':allow_unsafe_fixture}
   if raw[:4]==b'PK\x03\x04':item['nested']=scan(raw,i.filename.endswith('tests/fixtures/danger.xlsx'))
   out.append(item)
 return out
raw=source.read_bytes();members=scan(raw)
with zipfile.ZipFile(source) as z:z.extractall(dest)
result.write_text(json.dumps({'status':'passed','source':str(source),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'members':members},ensure_ascii=False,indent=2))
