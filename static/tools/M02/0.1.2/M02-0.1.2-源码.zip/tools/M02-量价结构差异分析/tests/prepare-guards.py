import pathlib,json,zipfile,io,csv
from oracle import fixture,js
p=pathlib.Path(__file__).parent/'fixtures';w=fixture()
for side in ['left','right']:
 t=w[side]
 with (p/t['file']).open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.writer(f);writer.writerow(t['headers']);writer.writerows([[r['cells'][h] for h in t['headers']] for r in t['rows']])
(p/'oversize.csv').write_bytes(b'0'*(10*1024*1024+1))
(p/'columns.csv').write_text(','.join('c'+str(i) for i in range(201))+'\n'+','.join('1' for i in range(201)))
(p/'rows.csv').write_text('x\n'+'1\n'*20102)
for name,extra in [('inflated.xlsx',{'xl/large.xml':b'x'*(30*1024*1024+1)}),('macro.xlsx',{'xl/vbaProject.bin':b'fake'}),('external.xlsx',{'xl/externalLinks/link.xml':b'fake'}),('danger.xlsx',{'../escape':b'fake'})]:
 with zipfile.ZipFile(p/name,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('[Content_Types].xml',b'<Types/>')
  for key,data in extra.items():z.writestr(key,data)
