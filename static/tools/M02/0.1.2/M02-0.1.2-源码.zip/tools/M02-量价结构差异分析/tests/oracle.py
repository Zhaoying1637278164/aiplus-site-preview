"""Independent exact Fraction oracle. Inputs are fictional; never import TS engine/results."""
from fractions import Fraction as F
from itertools import permutations
from pathlib import Path
import json,hashlib,sys,re,copy
HERE=Path(__file__).parent
FACTORS=['总量','结构','价格','单位成本'];VERSION='0.1.2';RULE='M02-2026-10-05.3'
HEAD=['产品ID','分类','期间','币种','金额单位','数量单位','口径','数量','单价','单位成本','原收入','原成本','备注']
FIELDS=dict(zip(['product','category','period','currency','moneyUnit','quantityUnit','basis','quantity','price','unitCost','revenue','cost'],HEAD[:12]))
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def sha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode()).hexdigest()
def text(x):
 if x is None:return None
 n,d=x.numerator,x.denominator; sign='-' if n<0 else '';n=abs(n)
 integer,n=divmod(n,d);s=str(integer)
 if n:
  s+='.'
  while n:n*=10;k,n=divmod(n,d);s+=str(k)
 return sign+s

def rounded(x,p):
 scale=10**p;v=x*scale;n,d=abs(v.numerator),v.denominator;q,rem=divmod(n,d);q+=2*rem>=d
 return F((-q if v<0 else q),scale)
def num(v):
 if v is None or v=='':return None,'缺失'
 if isinstance(v,dict):return None,'公式/对象禁止'
 if not re.fullmatch(r'-?(?:0|[1-9]\d{0,17})(?:\.\d{1,6})?',str(v)):return None,'数值须为普通十进制，最多18位整数6位小数'
 return F(str(v)),None

def table(name,rows,sheet='CSV',start=2):return {'file':name,'sheet':sheet,'headers':HEAD[:],'rows':[{'file':name,'sheet':sheet,'row':i+start,'cells':dict(zip(HEAD,r))} for i,r in enumerate(rows)]}
def fixture():
 values={'left':[],'right':[]}
 for i in range(604):
  typ=i%31
  for side in ['left','right']:
   if typ==1 and side=='left' or typ==2 and side=='right':continue
   q=F((i%17+1)*1000+(i%9)*17,1000)+(F(3,7) if False else 0)
   if side=='right':q+=F((i%5+1)*73,1000)
   price=F((i%23+8)*100+(i%9),100)+(F(37,100) if side=='right' else 0)
   cost=F((i%7+3)*100+(i%11),100)+(F(9,100) if side=='right' else 0)
   if typ==3 and side=='left':q=F(0)
   if typ==4 and side=='right':q=-q
   if typ==5 and side=='left':price=F(0)
   revenue=q*price+F((i%7)-3,1000);expense=q*cost+F((i%5)-2,1000)
   row=[f'P{i:04}',f'虚构分类{i%6}',('2026-08' if side=='left' else '2026-09'),('USD' if i%4==1 else 'CNY'),('万元' if i%4==2 else '元'),('千克' if i%4==3 else '件'),'不含税',text(q),text(price),text(cost),text(revenue),text(expense),f'完全虚构来源{i}-{side}']
   if typ==6 and side=='left':row[9]=None
   if typ==7 and side=='right':row[7]=None
   if typ==8 and side=='left':row[2]='2026-07'
   if typ==9 and side=='right':row[10]=None
   if typ==10 and side=='right':row[11]=None
   values[side].append(row)
   if typ==11 and side=='left':values[side].append(row[:])
 config={'periods':{'left':'2026-08','right':'2026-09'},'fields':{'left':FIELDS.copy(),'right':FIELDS.copy()},'order':FACTORS[:],'population':'all','precision':6,'tolerance':'0.000001','trim':False,'confirmed':True,'note':'604产品独立Fraction逐字段虚构验收'}
 return {'config':config,'left':table('604基期.csv',values['left']),'right':table('604本期.csv',values['right'])}

def compute(w):
 c=w['config'];rows=[];items={}
 for side in ['left','right']:
  m=c['fields'][side]
  for source in w[side]['rows']:
   cells=source['cells'];errors=[]
   def txt(f):
    v=cells.get(m[f])
    if v is None or isinstance(v,dict):errors.append(m[f]+'缺失/公式');return ''
    s=str(v).strip() if c['trim'] else str(v)
    if not s:errors.append(m[f]+'缺失')
    return s
   product,cat,period=txt('product'),txt('category'),txt('period');part=[txt(f) for f in ['currency','moneyUnit','quantityUnit','basis']]
   def read(f):
    if not m[f]:return None
    n,e=num(cells.get(m[f]))
    if e:errors.append(m[f]+': '+e)
    return n
   q,p,cost=read('quantity'),read('price'),read('unitCost')
   modelR=q*p if q is not None and p is not None else None
   modelG=q*(p-cost) if q is not None and p is not None and cost is not None else None
   rev=read('revenue') if m['revenue'] else modelR
   amtC=read('cost') if m['cost'] else (q*cost if q is not None and cost is not None else None)
   gross=rev-amtC if rev is not None and amtC is not None else None
   key=js(part+[cat,product]) if product and cat and all(part) else None
   for h,v in cells.items():
    if isinstance(v,dict) and not any(e.startswith(h) for e in errors):errors.append(h+': 公式禁止')
   if period and not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',period):errors.append('期间格式无效')
   r={'side':side,'source':source,'key':key,'partition':part,'product':product,'category':cat,'q':q,'p':p,'c':cost,'revenue':rev,'gross':gross,'modelRevenue':modelR,'modelGross':modelG,'errors':errors,'excluded':bool(period and period!=c['periods'][side])};rows.append(r)
   if r['excluded']:continue
   k=key or js(['无效来源',side,source['file'],source['sheet'],source['row']])
   if k not in items:items[k]={'key':k,'partition':part,'product':product,'category':cat,'status':'','left':[],'right':[]}
   items[k][side].append(r)
 for i in items.values():
  a=i['left'][0] if i['left'] else None;b=i['right'][0] if i['right'] else None
  invalid=len(i['left'])>1 or len(i['right'])>1 or any(not r['key'] or r['q'] is None or r['p'] is None or any('公式' in e or e=='期间格式无效' or e==c['fields'][r['side']]['period']+'缺失' for e in r['errors']) for r in i['left']+i['right'])
  i['status']='待复核' if invalid else '新增' if a is None else '退出' if b is None else '共同' if all(x is not None and x>0 for x in [a['q'],b['q'],a['p'],b['p']]) else '零负值'
  for metric in ['revenue','gross']:
   blocked=invalid or any(r[metric] is None or metric=='gross' and r['c'] is None for r in i['left']+i['right'])
   old=sum((r[metric] for r in i['left']),F(0)) if all(r[metric] is not None for r in i['left']) else None
   nxt=sum((r[metric] for r in i['right']),F(0)) if all(r[metric] is not None for r in i['right']) else None
   m={'old':old,'next':nxt,'delta':nxt-old if old is not None and nxt is not None else None,'effects':dict.fromkeys(FACTORS,F(0)),'added':F(0),'exited':F(0),'special':F(0),'inputResidual':F(0),'residual':F(0),'blocked':blocked,'reason':'重复、关键字段、数量单价或对应金额/成本缺失，请检查来源' if blocked else ''};i[metric]=m
   if blocked:continue
   if c['population']=='common' and i['status']!='共同':m['reason']='共同样本范围外，金额单列不计桥接';continue
   if i['status']=='新增':m['added']=nxt
   if i['status']=='退出':m['exited']=-old
   if i['status']=='零负值':m['special']=nxt-old
 groups={}
 for i in items.values():groups.setdefault(js(i['partition']),[]).append(i)
 bridges=[]
 for partition,g in groups.items():
  for metric in ['revenue','gross']:
   eligible=[i for i in g if not i[metric]['blocked'] and (c['population']=='all' or i['status']=='共同')];common=[i for i in eligible if i['status']=='共同'];Q=[sum((i[s][0]['q'] for i in common),F(0)) for s in ['left','right']]
   for i in common:
    a,b=i['left'][0],i['right'][0];m=i[metric]
    state={'总量':Q[0],'结构':a['q']/Q[0],'价格':a['p'],'单位成本':a['c'] if metric=='gross' else F(0)}
    newer={'总量':Q[1],'结构':b['q']/Q[1],'价格':b['p'],'单位成本':b['c'] if metric=='gross' else F(0)}
    prior=a['modelRevenue' if metric=='revenue' else 'modelGross']
    for f in c['order']:
     state[f]=newer[f];after=state['总量']*state['结构']*(state['价格']-state['单位成本']);m['effects'][f]=rounded(after-prior,c['precision']);prior=after
    model='modelRevenue' if metric=='revenue' else 'modelGross';m['inputResidual']=(b[metric]-b[model])-(a[metric]-a[model]);m['residual']=m['delta']-sum(m['effects'].values(),F(0))-m['inputResidual']
   sums={k:sum((i[metric][k] for i in eligible),F(0)) for k in ['old','next','added','exited','special','inputResidual']};effects={f:sum((i[metric]['effects'][f] for i in eligible),F(0)) for f in FACTORS};delta=sums['next']-sums['old'];res=delta-sum(effects.values(),F(0))-sum((sums[k] for k in ['added','exited','special','inputResidual']),F(0));blocked=[i for i in g if i[metric]['blocked']]
   vals={s:[r[metric] for i in blocked for r in i[s]] for s in ['left','right']}
   bridges.append({'partition':json.loads(partition),'metric':'收入' if metric=='revenue' else '毛利',**sums,'delta':delta,'effects':effects,'residual':res,'blockedOld':sum((x for x in vals['left'] if x is not None),F(0)),'blockedNext':sum((x for x in vals['right'] if x is not None),F(0)),'unknownOld':sum(x is None for x in vals['left']),'unknownNext':sum(x is None for x in vals['right']),'blockedItems':len(blocked),'excludedItems':len(g)-len(eligible)-len(blocked),'withinTolerance':abs(res)<=F(c['tolerance'])})
 def convert(x):
  if isinstance(x,F):return text(x)
  if isinstance(x,dict):return {k:convert(v) for k,v in x.items()}
  if isinstance(x,list):return [convert(v) for v in x]
  return x
 return convert({'items':list(items.values()),'rows':rows,'bridges':bridges,'config':c,'leftRows':len(w['left']['rows']),'rightRows':len(w['right']['rows'])})
BH=['币种/金额单位/数量单位/口径','指标','基期','本期','变化']+FACTORS+['新增','退出(带符号)','零负值变化','原始金额偏离变化','舍入残差','容差检查','阻塞已知基期','阻塞已知本期','阻塞未知基期行数','阻塞未知本期行数','阻塞项目数','范围外项目数']
IH=['业务键','分区','分类','产品','样本分类','指标','基期','本期','变化']+FACTORS+['新增','退出','零负值变化','原始金额偏离变化','残差','说明','基期来源','本期来源']
CH=['侧别','文件','页签','原行','产品','分类','分区','范围','数量','单价','单位成本','收入','毛利','检查']
HH=['分区','分类','指标','基期纳入','本期纳入','变化']+FACTORS+['新增','退出','零负值变化','原始金额偏离变化','舍入残差','阻塞项目数','范围外项目数']
def matrices(w,r):
 label=lambda x:' / '.join(x)
 def ir(items,metric):
  out=[]
  for i in items:
   m=i[metric];out.append([i['key'],label(i['partition']),i['category'],i['product'],i['status'],'收入' if metric=='revenue' else '毛利']+[m[x] for x in ['old','next','delta']]+[m['effects'][f] for f in FACTORS]+[m[x] for x in ['added','exited','special','inputResidual','residual']]+['阻塞：'+m['reason'] if m['blocked'] else m['reason']]+['；'.join(f"{a['source']['file']}/{a['source']['sheet']}/行{a['source']['row']}" for a in i[s]) for s in ['left','right']])
  return out
 br=[[label(b['partition']),b['metric']]+[b[x] for x in ['old','next','delta']]+[b['effects'][f] for f in FACTORS]+[b[x] for x in ['added','exited','special','inputResidual','residual']]+['通过' if b['withinTolerance'] else '超容差']+[b[x] for x in ['blockedOld','blockedNext','unknownOld','unknownNext','blockedItems','excludedItems']] for b in r['bridges']]
 cr=[['基期' if x['side']=='left' else '本期',x['source']['file'],x['source']['sheet'],x['source']['row'],x['product'],x['category'],label(x['partition']),'期间外排除' if x['excluded'] else '选定期间']+[x[f] for f in ['q','p','c','revenue','gross']]+['；'.join(x['errors']) or '静态字段通过'] for x in r['rows']]
 groups={}
 for i in r['items']:groups.setdefault(js(i['partition']+[i['category']]),[]).append(i)
 hr=[]
 for g in groups.values():
  for metric in ['revenue','gross']:
   eg=[i for i in g if not i[metric]['blocked'] and (r['config']['population']=='all' or i['status']=='共同')]
   summ=lambda k:text(sum((F(i[metric][k]) for i in eg),F(0)))
   old,nxt=summ('old'),summ('next');hr.append([label(g[0]['partition']),g[0]['category'],'收入' if metric=='revenue' else '毛利',old,nxt,text(F(nxt)-F(old))]+[text(sum((F(i[metric]['effects'][f]) for i in eg),F(0))) for f in FACTORS]+[summ(k) for k in ['added','exited','special','inputResidual','residual']]+[sum(i[metric]['blocked'] for i in g),len(g)-len(eg)-sum(i[metric]['blocked'] for i in g)])
 raw={s:[[x['file'],x['sheet'],x['row']]+[x['cells'].get(h) for h in w[s]['headers']] for x in w[s]['rows']] for s in ['left','right']}
 sh=[{'name':'分类贡献','headers':HH,'rows':hr},{'name':'桥接汇总','headers':BH,'rows':br},{'name':'收入产品贡献','headers':IH,'rows':ir(r['items'],'revenue')},{'name':'毛利产品贡献','headers':IH,'rows':ir(r['items'],'gross')},{'name':'来源检查','headers':CH,'rows':cr},{'name':'口径与版本','headers':['参数','值'],'rows':[['应用版本',VERSION],['规则版本',RULE],['含数据',True],['公式','顺序替换 Q*s*(p-c)，收入 c=0；数学贡献不代表因果']]+[[k,js(v)] for k,v in w['config'].items()]}]
 for s in ['left','right']:sh.append({'name':'基期原始资料' if s=='left' else '本期原始资料','headers':['文件','页签','行号']+w[s]['headers'],'rows':raw[s]})
 grids={'left登记':{'headers':['文件','页签','原行']+w['left']['headers'],'rows':raw['left']},'right登记':{'headers':['文件','页签','原行']+w['right']['headers'],'rows':raw['right']},'检查':{'headers':CH,'rows':cr},'覆盖':{'headers':BH,'rows':br},'样本':{'headers':IH,'rows':ir(r['items'],'revenue')},'收入汇总':{'headers':BH,'rows':[x for x in br if x[1]=='收入']},'毛利汇总':{'headers':BH,'rows':[x for x in br if x[1]=='毛利']},'收入明细':{'headers':IH,'rows':ir(r['items'],'revenue')},'毛利明细':{'headers':IH,'rows':ir(r['items'],'gross')},'分类汇总':{'headers':HH,'rows':hr},'层级产品':{'headers':IH,'rows':ir(r['items'],'revenue')+ir(r['items'],'gross')},'left来源':{'headers':['文件','页签','原行']+w['left']['headers'],'rows':raw['left']},'right来源':{'headers':['文件','页签','原行']+w['right']['headers'],'rows':raw['right']}}
 return {'sheets':sh,'grids':grids,'csv':[IH]+ir(r['items'],'revenue')+ir(r['items'],'gross')}

def stages():
 w=fixture();yield 'base',w
 # every permutation with all precisions/tolerances represented; additional exhaustive precision/population/tolerance coverage
 for n,order in enumerate(permutations(FACTORS)):
  c=copy.deepcopy(w);c['config'].update(order=list(order),precision=n%7,tolerance='0' if n%2 else '0.000001',population='common' if n%3==0 else 'all');yield 'order-'+str(n),c
 for p in range(7):
  for population in ['all','common']:
   for tol in ['0','0.000001']:
    c=copy.deepcopy(w);c['config'].update(precision=p,population=population,tolerance=tol);yield f'precision-{p}-{population}-{tol}',c
 c=copy.deepcopy(w);c['right']['rows'][-1]['cells']['数量']='7.000001';c['right']['rows'][-1]['cells']['单价']='31.125';c['config']['note']='末行源资料修正、原始收入仍保留';yield 'tail-corrected',c
 c=copy.deepcopy(w);c['config']['fields']['left']['revenue']=c['config']['fields']['right']['revenue']='';c['config']['fields']['left']['cost']=c['config']['fields']['right']['cost']='';yield 'model-amounts',c
 c=copy.deepcopy(w);c['right']['rows'][-1]['cells']['单位成本']=None;yield 'tail-cost-missing',c
 c=copy.deepcopy(w);c['config']['periods']['left']='2026-07';yield 'period-change',c
if __name__=='__main__':
 mode=sys.argv[1] if len(sys.argv)>1 else 'generate'
 if mode=='suite':
  for name,w in stages():
   r=compute(w);m=matrices(w,r);print(js({'name':name,'config':w['config'],'sheets_sha256':sha(m['sheets']),'projection':sha({'items':r['items'],'rows':r['rows'],'bridges':r['bridges']})}),flush=True)
 elif mode=='input':
  w=json.load(sys.stdin);r=compute(w);print(js({'result':r,**matrices(w,r)}))
 else:
  target=HERE/'fixtures';target.mkdir(exist_ok=True)
  w=fixture();(target/'work.json').write_text(js(w));r=compute(w);(target/'expected.json').write_text(js({'result':r,**matrices(w,r)}))
  (target/'metadata.json').write_text(js({'products':604,'left_rows':len(w['left']['rows']),'right_rows':len(w['right']['rows']),'oracle':'Python Fraction exact rational; ROUND_HALF_UP independently integer quotient; no engine import','expected_sha256':hashlib.sha256((target/'expected.json').read_bytes()).hexdigest(),'expected_semantic_sha256':sha({'result':r,**matrices(w,r)})}))
