// tools/M02-量价结构差异分析/tests/full-browser.ts
import { chromium } from "playwright";
import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import path from "node:path";
import ExcelJS from "exceljs";
import Papa from "papaparse";

// packages/core/types.ts
var LIMITS = { bytes: 10 * 1024 * 1024, inflated: 30 * 1024 * 1024, rows: 2e4, columns: 200 };

// tools/M02-量价结构差异分析/src/engine.ts
import Decimal from "decimal.js";
var D = Decimal.clone({ precision: 70, rounding: Decimal.ROUND_HALF_UP, toExpNeg: -100, toExpPos: 100 });
var required = ["product", "category", "period", "currency", "moneyUnit", "quantityUnit", "basis", "quantity", "price"];
var factors = ["\u603B\u91CF", "\u7ED3\u6784", "\u4EF7\u683C", "\u5355\u4F4D\u6210\u672C"];
function decimal(v) {
  if (v === null || v === void 0 || v === "") throw Error("\u7F3A\u5931");
  if (typeof v === "object") throw Error("\u516C\u5F0F/\u5BF9\u8C61\u7981\u6B62");
  const s = String(v);
  if (!/^-?(?:0|[1-9]\d{0,17})(?:\.\d{1,6})?$/.test(s)) throw Error("\u6570\u503C\u987B\u4E3A\u666E\u901A\u5341\u8FDB\u5236\uFF0C\u6700\u591A18\u4F4D\u6574\u65706\u4F4D\u5C0F\u6570");
  const x = new D(s);
  if (!x.isFinite()) throw Error("\u975E\u6709\u9650\u503C");
  return x.toFixed();
}
function validateConfig(c) {
  if (!c || !c.periods || !c.fields || typeof c.trim !== "boolean" || typeof c.confirmed !== "boolean" || typeof c.note !== "string" || c.note.length > 1e4) throw Error("\u53E3\u5F84\u53C2\u6570\u65E0\u6548");
  for (const s of ["left", "right"]) {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(c.periods[s]) || c.periods[s].startsWith("0000")) throw Error("\u671F\u95F4\u987B\u4E3AYYYY-MM");
    if (!c.fields[s]) throw Error("\u5B57\u6BB5\u5BF9\u5E94\u7F3A\u5931");
    for (const f of [...required, "unitCost", "revenue", "cost"]) {
      if (typeof c.fields[s][f] !== "string" || c.fields[s][f].length > 200 || required.includes(f) && !c.fields[s][f]) throw Error("\u5B57\u6BB5\u5BF9\u5E94\u65E0\u6548 " + f);
    }
  }
  if (c.periods.left === c.periods.right) throw Error("\u4E24\u671F\u5FC5\u987B\u4E0D\u540C");
  if (!Array.isArray(c.order) || c.order.length !== 4 || new Set(c.order).size !== 4 || c.order.some((f) => !factors.includes(f))) throw Error("\u56E0\u7D20\u987A\u5E8F\u65E0\u6548");
  if (!["all", "common"].includes(c.population) || !Number.isInteger(c.precision) || c.precision < 0 || c.precision > 6) throw Error("\u8303\u56F4/\u7CBE\u5EA6\u65E0\u6548");
  if (new D(decimal(c.tolerance)).lt(0)) throw Error("\u5BB9\u5DEE\u4E0D\u5F97\u8D1F\u6570");
}
function validateTable(t) {
  if (!t || typeof t.file !== "string" || typeof t.sheet !== "string" || !t.file || !t.sheet || t.file.length > 1e4 || t.sheet.length > 1e4 || !Array.isArray(t.headers) || !t.headers.length || t.headers.length > LIMITS.columns || t.headers.some((h) => typeof h !== "string" || !h || h.length > 200) || new Set(t.headers).size !== t.headers.length || !Array.isArray(t.rows) || t.rows.length > LIMITS.rows) throw Error("\u539F\u8868\u7ED3\u6784/\u884C\u5217\u8D85\u9650");
  const seen = /* @__PURE__ */ new Set();
  for (const r of t.rows) {
    if (!r || r.file !== t.file || r.sheet !== t.sheet || !Number.isInteger(r.row) || r.row < 1 || seen.has(r.row) || !r.cells || Array.isArray(r.cells) || typeof r.cells !== "object" || Object.keys(r.cells).some((h) => !t.headers.includes(h))) throw Error("\u6765\u6E90\u884C\u7ED3\u6784\u65E0\u6548");
    seen.add(r.row);
    for (const v of Object.values(r.cells)) {
      if (v !== null && typeof v !== "string" && typeof v !== "number" && (typeof v !== "object" || typeof v.formula !== "string")) throw Error("\u5355\u5143\u683C\u7C7B\u578B\u65E0\u6548");
      if (typeof v === "string" && v.length > 1e4 || typeof v === "number" && !Number.isFinite(v)) throw Error("\u5355\u5143\u683C\u5185\u5BB9\u65E0\u6548");
    }
  }
}

// tools/M02-量价结构差异分析/src/types.ts
var VERSION = "0.1.2";
var RULE_VERSION = "M02-2026-10-05.3";
var orders = (() => {
  const perm = (a) => a.length ? a.flatMap((x, i) => perm(a.filter((_, j) => j !== i)).map((t) => [x, ...t])) : [[]];
  return perm(["\u603B\u91CF", "\u7ED3\u6784", "\u4EF7\u683C", "\u5355\u4F4D\u6210\u672C"]);
})();

// tools/M02-量价结构差异分析/src/plan.ts
function validateWork(w) {
  if (!w) throw Error("\u5DE5\u4F5C\u7F3A\u5931");
  validateConfig(w.config);
  if (w.left !== null) validateTable(w.left);
  if (w.right !== null) validateTable(w.right);
}
function encode(w, contains_data) {
  validateWork(w);
  const raw = JSON.stringify({ schema_version: 1, tool: "M02", app_version: VERSION, rule_version: RULE_VERSION, contains_data, work: { config: w.config, left: contains_data ? w.left : null, right: contains_data ? w.right : null } }, null, 2);
  if (new TextEncoder().encode(raw).length > LIMITS.bytes) throw Error("\u65B9\u6848\u8D85\u8FC710MB\uFF0C\u8BF7\u5206\u522B\u4E0B\u8F7D\u6E90\u8D44\u6599\u548C\u65E0\u6570\u636E\u65B9\u6848");
  return raw;
}

// tools/M02-量价结构差异分析/tests/full-browser.ts
import { createServer } from "node:http";
var dir = path.dirname(fileURLToPath(import.meta.url));
var base = path.resolve(process.env.M02_FULL_CANDIDATE || "tools/M02-\u91CF\u4EF7\u7ED3\u6784\u5DEE\u5F02\u5206\u6790/candidate/0.1.2");
var out = path.resolve(process.env.M02_FULL_EVIDENCE || "progress/evidence/M02/0.1.2/full-browser");
await mkdir(out + "/downloads", { recursive: true });
var fixture = JSON.parse(await readFile(dir + "/fixtures/work.json", "utf8"));
var stages = execFileSync("python3", [dir + "/oracle.py", "suite"]).toString().trim().split("\n").map((x) => JSON.parse(x));
var work = structuredClone(fixture);
var expected;
var cells = 0;
var domCells = 0;
var pagesCount = 0;
var shotCount = 0;
var checks = [];
var downloads = [];
var requests = [];
var errors = [];
var hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
var oracle = (w) => JSON.parse(execFileSync("python3", [dir + "/oracle.py", "input"], { input: JSON.stringify(w), maxBuffer: 20 * 1024 * 1024 }).toString());
var display = (x) => x == null ? "\u3008\u7F3A\u5931/\u4E0D\u9002\u7528\u3009" : typeof x === "object" ? JSON.stringify(x) : String(x);
var exportDisplay = (x) => x == null ? "" : typeof x === "object" ? JSON.stringify(x) : String(x);
var uiSpec = (e) => JSON.parse(execFileSync("python3", [dir + "/ui-oracle.py"], { input: JSON.stringify(e), maxBuffer: 20 * 1024 * 1024 }).toString());
var uiProject = (g) => uiSpec(g);
var browser = await chromium.launch({ headless: true, executablePath: process.env.M02_CHROMIUM || "/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing" });
var ctx = await browser.newContext({ acceptDownloads: true, viewport: { width: 1440, height: 1e3 } });
await ctx.addInitScript(() => {
  const t = { writes: 0, idb: 0 };
  window.__audit = t;
  for (const method of ["setItem", "removeItem", "clear"]) {
    const old = Storage.prototype[method];
    Storage.prototype[method] = function(...args) {
      t.writes++;
      return old.apply(this, args);
    };
  }
  const op = indexedDB.open.bind(indexedDB);
  indexedDB.open = (...args) => {
    t.idb++;
    return op(...args);
  };
});
var page = await ctx.newPage();
var accept = true;
page.on("dialog", (d) => accept ? d.accept() : d.dismiss());
page.on("pageerror", (e) => errors.push(e.message));
page.on("request", (r) => requests.push(r.url()));
var nav = (i) => page.locator("nav button").nth(i).click();
async function download(button, name) {
  const waiting = page.waitForEvent("download");
  await page.getByRole("button", { name: button, exact: true }).click();
  const d = await waiting;
  assert.equal(await d.failure(), null);
  const target = out + "/downloads/" + name;
  await d.saveAs(target);
  const bytes = await readFile(target);
  downloads.push({ name, actual_name: d.suggestedFilename(), bytes: bytes.length, sha256: hash(bytes) });
  return bytes;
}
async function run() {
  await nav(1);
  await page.getByRole("button", { name: "\u8BA1\u7B97\u91CF\u4EF7\u7ED3\u6784", exact: true }).click();
  await page.getByRole("status").filter({ hasText: "\u8BA1\u7B97\u5B8C\u6210" }).waitFor();
}
async function restore(w, name, ok = true) {
  const target = out + "/" + name + ".json";
  await writeFile(target, encode(w, true));
  accept = ok;
  await nav(8);
  await page.getByLabel("\u6062\u590D\u5DE5\u4F5C", { exact: true }).setInputFiles(target);
  await page.getByRole("status").filter({ hasText: ok ? "\u6062\u590D\u5B8C\u6210" : "\u5DF2\u53D6\u6D88\u6062\u590D" }).waitFor();
  accept = true;
}
async function compareExports(name, w, e) {
  await nav(8);
  const bytes = await download("\u4E0B\u8F7D\u5168\u91CFExcel\u5E95\u7A3F", name + ".xlsx");
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(bytes);
  assert.deepEqual(wb.worksheets.map((s) => s.name), e.sheets.map((s) => s.name));
  for (const s of e.sheets) {
    const ws = wb.getWorksheet(s.name);
    const rows = [s.headers, ...s.rows];
    assert.equal(ws.rowCount, rows.length, s.name);
    assert.equal(ws.columnCount, s.headers.length, s.name);
    for (let i = 0; i < rows.length; i++) {
      const actual = Array.from({ length: s.headers.length }, (_, j) => ws.getRow(i + 1).getCell(j + 1).value ?? "");
      assert.deepEqual(actual, rows[i].map(exportDisplay), name + " " + s.name + " row " + i);
      cells += actual.length;
    }
  }
  const csv = await download("\u4E0B\u8F7D\u5168\u91CF\u4EA7\u54C1CSV", name + ".csv");
  const parsed = Papa.parse(csv.toString("utf8").replace(/^\uFEFF/, ""), { skipEmptyLines: true });
  assert.deepEqual(parsed.errors, []);
  assert.deepEqual(parsed.data, e.csv.map((r) => r.map(display)), name + " CSV");
  cells += parsed.data.reduce((n, r) => n + r.length, 0);
  const full = await download("\u4E0B\u8F7D\u542B\u6570\u636E\u5DE5\u4F5C", name + "-work.json");
  assert.deepEqual(JSON.parse(full.toString()).work, w);
  assert.equal(full.toString(), encode(w, true));
  const plan = await download("\u4E0B\u8F7D\u65E0\u6570\u636E\u65B9\u6848", name + "-plan.json");
  assert.equal(plan.toString(), encode(w, false));
  assert.equal(JSON.parse(plan.toString()).work.left, null);
  assert.equal(JSON.parse(plan.toString()).work.right, null);
  checks.push({ name, all_sheet_cells: wb.worksheets.reduce((n, s) => n + s.rowCount * s.columnCount, 0), csv_fields: parsed.data.reduce((n, r) => n + r.length, 0), json_raw: true });
}
async function compareAllPages(w, e, width) {
  await page.setViewportSize({ width, height: 1e3 });
  const grids = uiSpec(e);
  for (let i = 0; i < 9; i++) {
    await nav(i);
    if (i === 7) await page.getByLabel("\u8FFD\u67E5\u9879\u76EE").selectOption("");
    const list = await page.locator("[data-grid]").all();
    for (const grid of list) {
      const id = await grid.getAttribute("data-grid");
      const spec = grids[id];
      assert.ok(spec, id);
      await grid.getByRole("textbox").fill("");
      await grid.getByRole("button", { name: "\u9996\u9875", exact: true }).click();
      assert.deepEqual(await grid.locator("th[data-business]").allTextContents(), spec.headers);
      const batch = Math.max(1, Math.ceil(spec.rows.length / 50));
      for (let n = 0; n < batch; n++) {
        const rows = await grid.locator("tbody tr").all();
        const want = spec.rows.slice(n * 50, n * 50 + 50);
        assert.equal(rows.length, want.length, id + " row count");
        for (let j = 0; j < rows.length; j++) {
          const actual = await rows[j].locator("td[data-business]").allTextContents();
          assert.deepEqual(actual, want[j].map(display), id + " page " + n + " row " + j);
          domCells += actual.length;
          const card = grid.locator("[data-card]").nth(j);
          assert.deepEqual(await card.locator("[data-value]").allTextContents(), want[j].map(display), id + " card " + n + " row " + j);
          const tech = spec.technical[n * 50 + j];
          if (tech) {
            assert.deepEqual(await rows[j].locator("[data-tech]").allTextContents(), tech.map(display));
            assert.deepEqual(await card.locator("[data-tech]").allTextContents(), tech.map(display));
          }
        }
        pagesCount++;
        const scroll = grid.locator(".m02-scroll");
        const sc = await scroll.evaluate((el) => {
          el.scrollLeft = el.scrollWidth;
          return { left: el.scrollLeft, max: el.scrollWidth - el.clientWidth };
        });
        assert.ok(sc.max <= 1 || Math.abs(sc.left - sc.max) < 2, id + " right scroll");
        if (n + 1 < batch) await grid.getByRole("button", { name: "\u4E0B\u9875", exact: true }).click();
      }
      assert.equal(await grid.getByRole("button", { name: "\u4E0B\u9875", exact: true }).isDisabled(), true);
      await grid.getByRole("button", { name: "\u9996\u9875", exact: true }).click();
    }
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true, "document overflow " + i + " width" + width);
    await page.locator(".m02-scroll").evaluateAll((els) => els.forEach((el) => el.scrollLeft = 0));
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({ path: out + `/page-${i + 1}-${width}.png`, fullPage: false });
    if (width === 320 && i === 3) {
      const first = page.locator("[data-card]").first();
      assert.equal(await first.isVisible(), true);
      const box = await first.locator(".m02-key-amounts").boundingBox();
      assert.ok(box.y >= 0 && box.y + box.height <= 1e3, "sample full key amounts above fold");
    }
    ;
    shotCount++;
  }
  checks.push({ name: "all nine pages full pagination all columns", width, domPages: pagesCount, domCells });
}
async function importFile(side, f, sheet, header) {
  await nav(0);
  await page.getByLabel(side === "left" ? "\u57FA\u671F\u6587\u4EF6" : "\u672C\u671F\u6587\u4EF6", { exact: true }).setInputFiles(f);
  await page.getByRole("status").filter({ hasText: "\u6587\u4EF6\u5DF2\u5728\u672C\u673A\u8BFB\u53D6" }).waitFor();
  if (sheet) await page.getByLabel(side + "\u9875\u7B7E").selectOption(sheet);
  if (header) await page.locator(".m02-cards section").nth(side === "left" ? 0 : 1).locator("input[type=number]").fill(String(header));
  await page.getByRole("button", { name: side === "left" ? "\u786E\u8BA4\u57FA\u671F\u8D44\u6599" : "\u786E\u8BA4\u672C\u671F\u8D44\u6599", exact: true }).click();
}
var server;
try {
  if (process.env.M02_DOWNLOAD_ZIP === "1") {
    const zip = path.resolve("tools/M02-\u91CF\u4EF7\u7ED3\u6784\u5DEE\u5F02\u5206\u6790/candidate/0.1.2/M02-0.1.2-\u79BB\u7EBF\u5305.zip");
    server = createServer(async (req, res) => {
      if (!["/M02.zip", "/M02-source.zip"].includes(req.url)) {
        res.writeHead(404).end();
        return;
      }
      res.setHeader("Content-Disposition", req.url === "/M02-source.zip" ? 'attachment; filename="M02-source.zip"' : 'attachment; filename="M02.zip"');
      res.end(await readFile(req.url === "/M02-source.zip" ? zip.replace("\u79BB\u7EBF\u5305", "\u6E90\u7801") : zip));
    });
    await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
    const port = server.address().port;
    await page.setContent(`<a href="http://127.0.0.1:${port}/M02.zip" download>\u672C\u673AM02\u5019\u9009\u79BB\u7EBFZIP</a>`);
    const pending = page.waitForEvent("download");
    await page.getByRole("link").click();
    const d = await pending;
    assert.equal(await d.failure(), null);
    const downloaded = out + "/M02-downloaded.zip";
    await d.saveAs(downloaded);
    assert.deepEqual(await readFile(downloaded), await readFile(zip));
    execFileSync("python3", [dir + "/zip-check.py", downloaded, out + "/unpacked", out + "/zip-audit.json"]);
    checks.push({ name: "actual local browser complete ZIP download and every member SHA CRC path size", sha256: hash(await readFile(downloaded)) });
    await page.setContent(`<a href="http://127.0.0.1:${port}/M02-source.zip" download>\u672C\u673AM02\u5019\u9009\u6E90\u7801ZIP</a>`);
    const sourcePending = page.waitForEvent("download");
    await page.getByRole("link").click();
    const sd = await sourcePending;
    assert.equal(await sd.failure(), null);
    const sourceDownloaded = out + "/M02-source-downloaded.zip";
    await sd.saveAs(sourceDownloaded);
    assert.deepEqual(await readFile(sourceDownloaded), await readFile(zip.replace("\u79BB\u7EBF\u5305", "\u6E90\u7801")));
    execFileSync("python3", [dir + "/zip-check.py", sourceDownloaded, out + "/source-unpacked", out + "/source-zip-audit.json"]);
    checks.push({ name: "actual local browser complete SOURCE ZIP download every member/nested CRC SHA size", sha256: hash(await readFile(sourceDownloaded)) });
    server.close();
    await ctx.setOffline(true);
    await page.goto("file://" + out + "/unpacked/index.html");
  } else {
    await ctx.setOffline(true);
    await page.goto("file://" + base + "/index.html");
  }
  const initial = await page.evaluate(() => ({ ...window.__audit, local: localStorage.length, session: sessionStorage.length }));
  assert.deepEqual(initial, { writes: 0, idb: 0, local: 0, session: 0 });
  expected = oracle(work);
  await restore(work, "base");
  await run();
  await compareAllPages(work, expected, 1440);
  await compareAllPages(work, expected, 320);
  await compareExports("base", work, expected);
  for (const stage of stages.filter((s) => s.name !== "base")) {
    work = structuredClone(fixture);
    work.config = stage.config;
    if (stage.name === "tail-corrected") {
      work.right.rows.at(-1).cells["\u6570\u91CF"] = "7.000001";
      work.right.rows.at(-1).cells["\u5355\u4EF7"] = "31.125";
    }
    if (stage.name === "tail-cost-missing") work.right.rows.at(-1).cells["\u5355\u4F4D\u6210\u672C"] = null;
    expected = oracle(work);
    await restore(work, stage.name);
    if (stage.name.startsWith("order-")) {
      await nav(1);
      await page.getByLabel("\u5206\u89E3\u987A\u5E8F", { exact: true }).selectOption(work.config.order.join(","));
      await nav(4);
      assert.match(await page.locator("main").innerText(), /清除旧结果/);
      await nav(1);
      await page.getByLabel("\u5DF2\u786E\u8BA4\u4E24\u671F\u671F\u95F4\u3001\u6700\u7EC6\u7C92\u5EA6\u3001\u5E01\u79CD\u5355\u4F4D\u548C\u53E3\u5F84\u4E00\u81F4\u6027").check();
    }
    await run();
    await compareExports(stage.name, work, expected);
  }
  work = structuredClone(fixture);
  expected = oracle(work);
  await restore(work, "back-base");
  await run();
  await nav(3);
  for (const st of ["\u5168\u90E8", "\u5171\u540C", "\u65B0\u589E", "\u9000\u51FA", "\u96F6\u8D1F\u503C", "\u5F85\u590D\u6838"]) {
    await page.getByRole("button", { name: new RegExp("^" + st + " ") }).click();
    const grid = page.locator('[data-grid="\u6837\u672C"]');
    await grid.getByRole("button", { name: "\u9996\u9875", exact: true }).click();
    const want = uiSpec(expected)["\u6837\u672C"].rows.filter((r) => st === "\u5168\u90E8" || r[2] === st);
    for (let offset = 0; offset < Math.max(1, want.length); offset += 50) {
      assert.deepEqual(await grid.locator("tbody tr").evaluateAll((trs) => trs.map((tr) => Array.from(tr.querySelectorAll("td[data-business]")).map((x) => x.textContent))), want.slice(offset, offset + 50).map((r) => r.map(display)));
      if (offset + 50 < want.length) await grid.getByRole("button", { name: "\u4E0B\u9875", exact: true }).click();
    }
  }
  await page.getByRole("button", { name: /^共同 / }).click();
  const sample = page.locator('[data-grid="\u6837\u672C"]');
  await sample.getByRole("textbox").fill("P0603");
  const subset = uiSpec(expected)["\u6837\u672C"].rows.filter((r) => r[2] === "\u5171\u540C" && r.some((x) => display(x).includes("P0603")));
  assert.deepEqual(await sample.locator("tbody tr").evaluateAll((trs) => trs.map((tr) => Array.from(tr.querySelectorAll("td[data-business]")).map((x) => x.textContent))), subset.map((r) => r.map(display)));
  await compareExports("filtered-full-export", work, expected);
  checks.push({ name: "status and search filter does not truncate exports" });
  await run();
  await restore({ ...structuredClone(work), config: { ...work.config, note: "\u4E0D\u5E94\u6062\u590D\u7684\u8D44\u6599" } }, "cancel-full", false);
  await compareExports("restore-cancel-retained", work, expected);
  await run();
  const nd = out + "/no-data.json";
  await writeFile(nd, encode(work, false));
  accept = false;
  await nav(8);
  await page.getByLabel("\u6062\u590D\u5DE5\u4F5C", { exact: true }).setInputFiles(nd);
  await page.getByRole("status").filter({ hasText: "\u5DF2\u53D6\u6D88\u6062\u590D" }).waitFor();
  accept = true;
  await compareExports("no-data-cancel-retained", work, expected);
  await run();
  await nav(8);
  await page.getByLabel("\u6062\u590D\u5DE5\u4F5C", { exact: true }).setInputFiles(nd);
  await page.getByRole("status").filter({ hasText: "\u6062\u590D\u5B8C\u6210" }).waitFor();
  await nav(0);
  assert.equal(await page.locator("[data-grid]").count(), 0);
  await nav(4);
  assert.match(await page.locator("main").innerText(), /清除旧结果/);
  await nav(8);
  const empty = await download("\u4E0B\u8F7D\u542B\u6570\u636E\u5DE5\u4F5C", "empty-after-no-data.json");
  assert.equal(JSON.parse(empty.toString()).work.left, null);
  checks.push({ name: "contains/no-data restore cancel retains full values and confirm clears full source and result" });
  for (const side of ["left", "right"]) await importFile(side, dir + "/fixtures/" + work[side].file);
  await run();
  await compareExports("csv-import", work, expected);
  const wb = new ExcelJS.Workbook();
  for (const side of ["left", "right"]) {
    const ws = wb.addWorksheet(side === "left" ? "\u57FA\u671F\u660E\u7EC6" : "\u672C\u671F\u660E\u7EC6");
    ws.addRow(["\u5B8C\u5168\u865A\u6784\u8BF4\u660E"]);
    const hs = work[side].headers.map((h) => h === "\u5355\u4EF7" ? "\u5BFC\u5165\u5355\u4EF7" : h);
    ws.addRow(hs);
    for (const row of work[side].rows) ws.addRow(work[side].headers.map((h) => row.cells[h] ?? null));
  }
  const xlsx = out + "/604-two-sheet.xlsx";
  await writeFile(xlsx, new Uint8Array(await wb.xlsx.writeBuffer()));
  for (const side of ["left", "right"]) {
    await importFile(side, xlsx, side === "left" ? "\u57FA\u671F\u660E\u7EC6" : "\u672C\u671F\u660E\u7EC6", 2);
    await nav(4);
    assert.match(await page.locator("main").innerText(), /清除旧结果/);
  }
  await nav(1);
  for (const side of ["left", "right"]) await page.getByLabel(side + "-price", { exact: true }).selectOption("\u5BFC\u5165\u5355\u4EF7");
  await page.getByLabel("\u5DF2\u786E\u8BA4\u4E24\u671F\u671F\u95F4\u3001\u6700\u7EC6\u7C92\u5EA6\u3001\u5E01\u79CD\u5355\u4F4D\u548C\u53E3\u5F84\u4E00\u81F4\u6027").check();
  for (const side of ["left", "right"]) {
    const t = work[side];
    t.file = "604-two-sheet.xlsx";
    t.sheet = side === "left" ? "\u57FA\u671F\u660E\u7EC6" : "\u672C\u671F\u660E\u7EC6";
    t.headers = t.headers.map((h) => h === "\u5355\u4EF7" ? "\u5BFC\u5165\u5355\u4EF7" : h);
    t.rows.forEach((r, i) => {
      r.file = t.file;
      r.sheet = t.sheet;
      r.row = i + 3;
      const values = r.cells;
      r.cells = Object.fromEntries(t.headers.map((h) => [h, h === "\u5BFC\u5165\u5355\u4EF7" ? values["\u5355\u4EF7"] : values[h]]));
    });
    work.config.fields[side].price = "\u5BFC\u5165\u5355\u4EF7";
  }
  expected = oracle(work);
  await run();
  await compareExports("xlsx-mapped-header2", work, expected);
  await nav(7);
  const last = expected.result.items.find((i) => i.product === "P0603");
  await page.getByLabel("\u8FFD\u67E5\u9879\u76EE").selectOption(last.key);
  for (const side of ["left", "right"]) {
    const grid = page.locator(`[data-grid="${side}\u6765\u6E90"]`);
    const spec = { ...expected.grids[side + "\u6765\u6E90"], rows: work[side].rows.filter((r) => last[side].some((x) => x.source.row === r.row)).map((r) => [r.file, r.sheet, r.row, ...work[side].headers.map((h) => r.cells[h])]) };
    assert.deepEqual(await grid.locator("tbody tr").evaluateAll((trs) => trs.map((tr) => Array.from(tr.querySelectorAll("td[data-business]")).map((x) => x.textContent))), uiProject({ headers: spec.headers, rows: spec.rows }).rows.map((r) => r.map(display)));
    const scroll = grid.locator(".m02-scroll");
    await scroll.evaluate((el) => el.scrollLeft = el.scrollWidth);
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true);
  }
  checks.push({ name: "actual CSV/XLSX two sheets header2 renamed mapping and last-source full-column chain" });
  const rawHeaders = ["\u4EA7\u54C1ID", "\u5206\u7C7B", "\u4E1A\u52A1\u952E", "\u5206\u533A", "\u57FA\u671F\u6765\u6E90", "\u672C\u671F\u6765\u6E90"];
  const rawRow = ["P/RAW", "\u865A\u6784\u5206\u7C7B", "\u666E\u901A\u975EJSON\u503C", "\u539F\u53E3\u5F84 / \u539F\u503C", "\u539F\u59CB\u5907\u6CE8\u5DE6", "\u539F\u59CB\u5907\u6CE8\u53F3"];
  const rawCsv = out + "/raw-names.csv";
  await writeFile(rawCsv, rawHeaders.join(",") + "\n" + rawRow.join(",") + "\n");
  await importFile("left", rawCsv);
  await nav(0);
  const rawGrid = page.locator('[data-grid="left\u767B\u8BB0"]');
  const rawSpec = uiProject({ headers: ["\u6587\u4EF6", "\u9875\u7B7E", "\u539F\u884C", ...rawHeaders], rows: [["raw-names.csv", "CSV", 2, ...rawRow]] });
  assert.deepEqual(await rawGrid.locator("tbody tr td[data-business]").allTextContents(), rawSpec.rows[0].map(display));
  assert.deepEqual(await rawGrid.locator("[data-card] [data-value]").allTextContents(), rawSpec.rows[0].map(display));
  assert.equal(await rawGrid.locator("[data-tech]").count(), 0);
  checks.push({ name: "actual CSV reserved raw column names preserved completely; not internal key parsing" });
  for (const [name, message] of [["oversize.csv", "10MB"], ["columns.csv", "200\u5217"], ["rows.csv", "20000\u884C"], ["inflated.xlsx", "30MB"], ["macro.xlsx", "\u5B8F"], ["external.xlsx", "\u5916\u94FE"], ["danger.xlsx", "\u5371\u9669"]]) {
    await nav(0);
    await page.getByLabel("\u57FA\u671F\u6587\u4EF6", { exact: true }).setInputFiles(dir + "/fixtures/" + name);
    await page.getByRole("status").filter({ hasText: message }).waitFor();
    checks.push({ name: "guard " + name, message });
  }
  const formulaWb = new ExcelJS.Workbook(), fw = formulaWb.addWorksheet("\u516C\u5F0F");
  fw.addRow(fixture.left.headers);
  fw.addRow(fixture.left.headers.map((h) => h === "\u6570\u91CF" ? { formula: "10+10", result: 20 } : fixture.left.rows[0].cells[h]));
  const ff = out + "/formula.xlsx";
  await writeFile(ff, new Uint8Array(await formulaWb.xlsx.writeBuffer()));
  await importFile("left", ff, "\u516C\u5F0F");
  await nav(1);
  await page.getByLabel("left-price", { exact: true }).selectOption("\u5355\u4EF7");
  await page.getByLabel("\u5DF2\u786E\u8BA4\u4E24\u671F\u671F\u95F4\u3001\u6700\u7EC6\u7C92\u5EA6\u3001\u5E01\u79CD\u5355\u4F4D\u548C\u53E3\u5F84\u4E00\u81F4\u6027").check();
  await run();
  await nav(2);
  assert.match(await page.locator('[data-grid="\u68C0\u67E5"]').innerText(), /公式/);
  checks.push({ name: "actual formula workbook cache never executed as input, row blocked" });
  const formulaWork = structuredClone(work);
  formulaWork.config.fields.left.price = "\u5355\u4EF7";
  formulaWork.left = { file: "formula.xlsx", sheet: "\u516C\u5F0F", headers: [...fixture.left.headers], rows: [{ file: "formula.xlsx", sheet: "\u516C\u5F0F", row: 2, cells: { ...fixture.left.rows[0].cells, "\u6570\u91CF": { formula: "10+10", cached: 20 } } }] };
  await compareExports("formula-blocked", formulaWork, oracle(formulaWork));
  await nav(8);
  for (const name of ["\u7A7A\u767D\u6A21\u677F.csv", "\u865A\u6784\u57FA\u671F.csv", "\u865A\u6784\u672C\u671F.csv", "\u865A\u6784\u6837\u4F8B.xlsx", "\u865A\u6784\u5DE5\u4F5C.json", "\u65E0\u6570\u636E\u65B9\u6848.json"]) {
    const bytes = await download("\u4E0B\u8F7D" + name, "asset-" + name);
    assert.deepEqual(bytes, await readFile(base + "/" + name));
  }
  checks.push({ name: "six complete program assets raw exact bytes including XLSX ZIP dates" });
  const before = await page.evaluate(() => ({ ...window.__audit, local: localStorage.length, session: sessionStorage.length }));
  assert.deepEqual(before, initial);
  await page.getByRole("button", { name: "\u6E05\u9664\u5185\u5B58", exact: true }).click();
  await nav(0);
  assert.equal(await page.locator("[data-grid]").count(), 0);
  const after = await page.evaluate(() => ({ ...window.__audit, local: localStorage.length, session: sessionStorage.length }));
  assert.deepEqual(after, initial);
  assert.deepEqual(errors, []);
  assert.equal(requests.filter((x) => /^https?:/.test(x) && !/^http:\/\/127.0.0.1:\d+\/M02(?:-source)?\.zip$/.test(x)).length, 0);
  await writeFile(out + "/result.json", JSON.stringify({ status: "passed", platform: "Mac host actual Chromium; Windows unverified", candidate_html_sha256: hash(await readFile(base + "/index.html")), candidate_runtime_sha256: hash(await readFile(base + "/runtime.json")), products: 604, source_rows: { left: fixture.left.rows.length, right: fixture.right.rows.length }, stages: stages.length, exportCells: cells, domCells, domPages: pagesCount, screenshots: shotCount, uiScope: "13 separate UI literal grid specifications; full desktop business cells and all mobile card fields/technical keys; Financial Fraction outputs separate", checks, downloads, initial, before, after, requests, errors, scope: process.env.M02_DOWNLOAD_ZIP === "1" ? "local browser ZIP download then extracted file://; no original/public website" : "candidate actual file:// offline; no original/public website" }, null, 2));
} catch (e) {
  await writeFile(out + "/failure-" + Date.now() + ".json", JSON.stringify({ error: String(e), checks, downloads, cells, domCells, pagesCount, errors, requests }, null, 2));
  throw e;
} finally {
  server?.close();
  await browser.close();
}
