"""UI literal column specification, independent of the React presentation code.
Financial values arrive from the separate Fraction oracle; no financial recalculation here.
"""
import json,sys
D=['币种','金额单位','数量单位','口径']
ITEM=['产品','分类','样本分类','指标','基期','本期','变化']+D+['总量','结构','价格','单位成本','新增','退出','零负值变化','原始金额偏离变化','残差','说明']
BRIDGE=['指标','基期','本期','变化']+D+['总量','结构','价格','单位成本','新增','退出(带符号)','零负值变化','原始金额偏离变化','舍入残差','容差检查','阻塞已知基期','阻塞已知本期','阻塞未知基期行数','阻塞未知本期行数','阻塞项目数','范围外项目数']
CHECK=['产品','分类','收入','毛利']+D+['数量','单价','单位成本','检查','侧别','文件','页签','原行','范围']
HIER=['分类','指标','基期纳入','本期纳入','变化']+D+['总量','结构','价格','单位成本','新增','退出','零负值变化','原始金额偏离变化','舍入残差','阻塞项目数','范围外项目数']
def project(headers,rows,partitions=None):
 if headers[0]=='业务键':target=ITEM
 elif headers[0]=='币种/金额单位/数量单位/口径':target=BRIDGE
 elif headers[:4]==['侧别','文件','页签','原行']:target=CHECK
 elif headers[0]=='分区':target=HIER
 else:
  prefix=[h for h in ['产品','产品ID','分类','样本分类','指标','基期','基期纳入','本期','本期纳入','变化','收入','毛利','数量','单价','单位成本','检查'] if h in headers];target=prefix+[h for h in headers if h not in prefix]
 partition='分区' if headers[0]=='分区' or headers[0]=='业务键' or headers[:4]==['侧别','文件','页签','原行'] else '币种/金额单位/数量单位/口径' if headers[0]=='币种/金额单位/数量单位/口径' else None
 values=[];tech=[]
 for i,row in enumerate(rows):
  if partition in headers:
   dims=partitions[i] if partitions is not None else json.loads(row[0])[:4] if '业务键' in headers else row[headers.index(partition)].split(' / ')
  else:dims=None
  values.append([dims[D.index(h)] if dims is not None and h in D else row[headers.index(h)] for h in target])
  if headers[0]=='业务键':tech.append([row[0],row[-2],row[-1]])
 return {'headers':target,'rows':values,'technical':tech}
def main(e):
 r=e['result'];groups={}
 for item in r['items']:groups.setdefault(json.dumps(item['partition']+[item['category']]),item['partition'])
 out={}
 for name,g in e['grids'].items():
  ps=None
  if name=='检查':ps=[x['partition'] for x in r['rows']]
  if name in ['覆盖','收入汇总','毛利汇总']:ps=[x['partition'] for x in r['bridges'] if name=='覆盖' or x['metric']==name[:2]]
  if name=='分类汇总':ps=[p for p in groups.values() for _ in range(2)]
  out[name]=project(g['headers'],g['rows'],ps)
 return out
if __name__=='__main__':
 data=json.load(sys.stdin);print(json.dumps(main(data) if 'grids' in data else project(**data),ensure_ascii=False,separators=(',',':')))
