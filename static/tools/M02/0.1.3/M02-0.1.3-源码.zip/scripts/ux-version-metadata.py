"""Repair patch-version compatibility and update independent oracle metadata only."""
from pathlib import Path
import json,re,hashlib
r=Path.cwd();e=r/'progress/evidence/2026-10-07-ux-repair';versions=json.loads((e/'versions.json').read_text());changes=[]
for c in versions:
 src=r/'tools'/c['folder']/'src'
 for p in src.glob('*.ts'):
  s=p.read_text();new=re.sub(r'(\b\w+(?:\?\.)?\.(?:app_version|appVersion))\s*!==\s*VERSION',lambda m:'('+m[1]+"!==VERSION&&"+m[1]+"!=="+repr(c['old'])+')',s)
  # Guard syntax optional chaining is normally p?.app_version (one dot).
  new=re.sub(r'(\b\w+\?\.(?:app_version|appVersion))\s*!==\s*VERSION',lambda m:'('+m[1]+"!==VERSION&&"+m[1]+"!=="+repr(c['old'])+')',new)
  if new!=s:p.write_text(new);changes.append({'file':str(p.relative_to(r)),'change':'accept previous public app patch only; schema/rule validation unchanged'})
(e/'version-compatibility.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
