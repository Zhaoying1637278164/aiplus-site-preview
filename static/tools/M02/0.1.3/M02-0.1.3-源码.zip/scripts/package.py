import sys,pathlib,zipfile,json,hashlib
root=pathlib.Path.cwd();out=pathlib.Path(sys.argv[1]);version=out.name;tool=out.parent.name
catalog=json.loads((root/'catalog/tools.json').read_text())
entry=next(t for t in catalog if t['id']==tool)
locks=json.loads((root/'catalog/release-locks.json').read_text())
if any(r['tool']==tool and r['version']==version for r in locks['releases']):
 raise SystemExit('冻结版本禁止重新打包；变更须发布新版本。')
if entry['version']!=version or entry['status'] not in ['tested','packaged']:
 raise SystemExit('仅可打包当前已测试且未冻结的版本。')
threads={t['tool_id']:t for t in json.loads((root/'catalog/threads.json').read_text())['tools']}
def source_locked(t):
 return t['status']=='accepted' or threads.get(t['id'],{}).get('thread_status')=='handed_off_formal_integration' or t.get('delivery',{}).get('source_locked_version')==t['version']
if not source_locked(entry):
 raise SystemExit('工具源码仍活动或待修正；正式交接锁定后才可打包。')
stable=[t for t in catalog if t['status'] in ['tested','packaged','accepted']
        and source_locked(t) and (root/'tools'/t['folder']/'src/main.tsx').is_file()]
stable_ids={t['id'] for t in stable}
excluded=[t['id'] for t in catalog if t['id'] not in stable_ids
          and ((root/'tools'/t['folder']/'src/main.tsx').is_file() or threads.get(t['id'],{}).get('thread_status','').startswith('active_'))]
stage_registry=root/'integration/native-site/site/registry.json'
current_suite='-'.join(e['id'] for e in json.loads(stage_registry.read_text())) if stage_registry.exists() else None
# E03 source contains every stable source/test dependency, original independent
# fixtures and this tool's full formal proof. Other tools' generated raw replay
# batches stay in the evidence repository; retain their receipts/policy sources.
e03_formal=root/'progress/evidence/E03/0.1.1/root-formal-offline'
e03_condense=tool=='E03' and (e03_formal/'root-full-command.json').is_file() and json.loads((e03_formal/'root-full-command.json').read_text()).get('passed') is True
e03_duplicates={}
if e03_condense:
 for directory in ['bulk-downloads','snapshots']:
  seen={}
  for p in sorted((e03_formal/directory).iterdir()):
   if not p.is_file() or p.suffix=='.zip':continue
   digest=hashlib.sha256(p.read_bytes()).hexdigest()
   if digest in seen:e03_duplicates[str(p.relative_to(root))]=seen[digest]
   else:seen[digest]=str(p.relative_to(root))
e03_omitted={}
e04_inventory=root/'progress/evidence/E04/0.1.1/root-formal-preparation/source-duplicate-inventory.json'
e04_condense=tool=='E04' and version=='0.1.1' and e04_inventory.is_file()
e04_duplicates={};e04_omitted={}
if e04_condense:
 inventory=json.loads(e04_inventory.read_text())
 preserved=root/'progress/evidence/E04/0.1.1/root-formal-preparation/history/first-completed-package/E04-0.1.1-源码.zip'
 if preserved.is_file():
  assert hashlib.sha256(preserved.read_bytes()).hexdigest()==inventory['source_zip_sha256']
 else:
  # Distributed source omits superseded giant ZIPs. Its inventory is already
  # bound by the delivered source snapshot; each omission still checks the
  # canonical/current file size and SHA below, rather than requiring history.
  delivered=json.loads((root/'source-snapshot.json').read_text())
  assert delivered['tool']==tool and delivered['version']==version
  inventory_path=str(e04_inventory.relative_to(root))
  assert delivered['file_sha256'][inventory_path]==hashlib.sha256(e04_inventory.read_bytes()).hexdigest()
 e04_duplicates={x['file']:x for x in inventory['exact_duplicates']}
def source_file(f):
 # Keep source/tests/current public evidence; omit duplicate generated candidates and
 # superseded evidence snapshots. These stay in the repository, not in every ZIP.
 parts=f.relative_to(root).parts
 if parts[:2]==('progress','history'):return False
 # Whole-site replay outputs are generated integration evidence, not source or
 # rebuild fixtures. Keep their replay scripts and authoritative repository data;
 # duplicating these growing batches in every source ZIP breaks bounded downloads.
 if parts[:3]==('progress','evidence','site-integration'):return False
 # Extracted rebuild checkouts and raw platform WebSocket captures are generated
 # diagnostics. Keep source-rebuild receipts and replay code, not copied sources.
 if parts[:2]==('progress','evidence') and any(p in ['source-rebuild','source','rebuilt-source','source-stage','source-snapshot','extracted'] for p in parts[2:]):return False
 # Formal QA replaces candidate replay outputs. Keep source fixtures/oracles,
 # actual formal outputs once, and every structured receipt; duplicate candidate,
 # failed-run and unpacked-repeat exports remain in the evidence repository.
 if parts[:2]==('progress','evidence') and len(parts)>4:
  owner=parts[2];version_root=root.joinpath(*parts[:4])
  generated={'browser','large','large-browser','zip-large-browser','bulk-browser','zip-bulk-browser','tail-visual','native-interface','native-host'}
  duplicate_candidate=any(parts[4]==g or parts[4].startswith(g+'-') for g in generated) and (version_root/'root-formal-offline').is_dir()
  failed_replay=any('-failed' in p for p in parts[4:])
  duplicate_zip=parts[4]=='root-formal-offline' and len(parts)>5 and parts[5] in ['zip-large-browser','zip-bulk-browser']
  if duplicate_candidate or failed_replay or duplicate_zip:
   if f.name not in ['result.json','command.json','root-command.json','check.json'] and not f.name.endswith(('-cell-check.json','-all-cells.json')) and f.suffix not in ['.log']:return False
 if parts[:2]==('progress','evidence') and f.suffix=='.protobuf':return False
 # Boundary suites generate these all-space oversized files themselves. Retain
 # generators and rejection receipts, not hundreds of MiB of repeated padding.
 if parts[:2]==('progress','evidence') and f.stem=='oversize':return False
 # Sibling public-site export workbooks duplicate formal/local export evidence.
 # They stay in the repository; retain this tool's actual outputs and all source
 # fixtures, tests, independent answers and structured public receipts.
 if parts[:2]==('progress','evidence') and len(parts)>2 and parts[2]!=tool and 'site-public' in parts and f.suffix=='.xlsx':return False
 # B01 full/diagnostic exports are byte-identical per stage, independently
 # checked before omission. Keep one actual workbook, both hash/cell receipts,
 # source fixtures and Fraction oracle; all raw copies remain in repository.
 if parts[:2]==('progress','evidence') and len(parts)>5 and parts[2]=='B01' and parts[4]=='root-formal-offline':
  if f.name.endswith('-expected.json'):return False
  if f.name.endswith('-B01-诊断底稿.xlsx'):
   twin=f.with_name(f.name.replace('-B01-诊断底稿.xlsx','-B01-预算底稿.xlsx'))
   if twin.is_file() and twin.read_bytes()==f.read_bytes():return False
 # B03 four-mode raw replay copies stay in the repository. One actual direct
 # run plus all per-mode result/hash receipts and independent oracle suffice in
 # the source bundle; every mode is reproducible by included browser tests.
 if parts[:5]==('progress','evidence','B03','0.1.1','root-formal-offline') and len(parts)>6 and parts[5]=='large' and parts[6] in ['direct-2','zip-1','zip-2']:
  if f.name!='result.json' and f.suffix!='.log':return False
 # B04 candidate bulk/preview replay files and formal unpacked raw duplicates
 # stay in the evidence repository. Keep formal direct inputs/outputs once,
 # all run/hash receipts and the included Python oracle/fixture generator.
 if parts[:4]==('progress','evidence','B04','0.1.1') and len(parts)>4:
  candidate_replay=parts[4].startswith(('bulk-','preview-'))
  unpacked_replay=len(parts)>5 and parts[4]=='root-formal-offline' and parts[5]=='bulk-unpacked'
  if candidate_replay or unpacked_replay:
   if f.name!='result.json' and f.suffix!='.log':return False
  if parts[4]=='root-formal-offline' and f.name.endswith('-expected.json'):return False
 # B05 supplement owner browser repetitions are superseded by actual formal
 # direct/downloaded-ZIP replay; retain every result/log and original fixture
 # oracle under tools, with all formal raw outputs. Old raw replays stay in repo.
 if parts[:4]==('progress','evidence','B05','supplement') and len(parts)>4 and parts[4] in ['browser','final-browser','verified-browser']:
  if f.name!='result.json' and f.suffix!='.log':return False
 # E02 former candidate direct/ZIP raw exports are superseded by root actual
 # formal direct and downloaded-ZIP replays. Preserve all structured receipts
 # and logs, source fixtures/oracle/tests and formal outputs; old raw copies
 # remain in the repository. Do not duplicate three candidate replay batches.
 if parts[:4]==('progress','evidence','E02','0.2.0') and len(parts)>4 and parts[4] in ['direct','direct-final','extracted-browser-final'] and (version_root/'root-formal-offline/large-direct/result.json').is_file():
  if f.name not in ['result.json','command.json','root-command.json','check.json'] and f.suffix!='.log':return False
 # Other tools' generated workbook outputs are reproduced by their included
 # browser tests. Keep source fixtures under tools/fixtures and structured
 # result/hash receipts; do not duplicate every sibling's export in this ZIP.
 if parts[:2]==('progress','evidence') and len(parts)>2 and parts[2]!=tool and f.suffix=='.xlsx':return False
 # Large sibling generated work/exports duplicate replay outputs. Original fixtures
 # and independent oracles stay under tools; result/hash receipts remain included.
 if parts[:2]==('progress','evidence') and len(parts)>2 and parts[2]!=tool and f.suffix=='.json' and f.stat().st_size>256*1024 and f.name not in ['result.json','handoff.json','check.json','oracle.json']:return False
 # Superseded stage-suite replay outputs remain in the repository; current suite stays.
 if parts[:3]==('progress','evidence','site-integration') and len(parts)>3 and parts[3].startswith('D02') and parts[3]!=current_suite:return False
 if len(parts)>2 and parts[:2]==('progress','evidence') and parts[2] in excluded:return False
 if parts[0]=='fixtures' and len(parts)>1 and parts[1] in excluded:return False
 # Root validation scripts importing active tool code must not make that tool a
 # hidden source-build dependency. Shared infrastructure without imports stays.
 if parts[0] in ['tests','scripts'] and f.is_file() and f.suffix in ['.ts','.tsx','.py']:
  text=f.read_text()
  if any('tools/'+t['folder']+'/' in text for t in catalog if t['id'] in excluded):return False
 # Screenshots remain in the evidence repository; source downloads retain code,
 # independent expected answers, structured results and actual input/output files.
 if 'evidence' in parts and f.suffix.lower() in ['.png','.jpg','.jpeg','.webp']:return False
 # Legacy D03 rendered UI checks live beside tests, not input fixtures.
 # Keep their replay code/results; generated screenshots remain in the repository.
 # Candidate programs are generated duplicates; retain their source/build/tests.
 if parts[0]=='tools' and 'candidate' in parts:return False
 if parts[0]=='tools' and 'ui-preflight' in parts and f.suffix.lower() in ['.png','.jpg','.jpeg','.webp']:return False
 # Rendered HTML is generated evidence, not a source dependency; retain hashes and replay scripts.
 if 'evidence' in parts and f.suffix.lower()=='.html':return False
 if 'evidence' in parts and 'history' in parts:return False
 if 'evidence' in parts and 'candidate' in parts:return False
 # Repeated extracted/site-fixture program bundles are rebuilt from included
 # tools/shared source. Retain their hash receipts and replay code, not bundles.
 if 'evidence' in parts and f.name in ['runtime.json','build-manifest.json']:return False
 # Formal test program mirrors are generated release bytes; source and fixtures
 # are already included under tools, so do not duplicate runtime bundles.
 if 'evidence' in parts and 'root-formal' in parts and 'program' in parts:return False
 if (e03_condense or e04_condense) and parts[:2]==('progress','evidence'):
  omit=False;reason=''
  if len(parts)>2 and parts[2]!=tool:
   receipt=f.suffix=='.json' and (f.name in ['result.json','handoff.json','check.json','oracle.json','source-rebuild.json','source-rebuild-assets.json','independent-expected.json'] or f.name.startswith(('root-','manifest','command')) or f.name.endswith(('-command.json','-check.json','-readback.json','-audit.json','-verification.json','-all-cells.json')))
   keep=receipt or f.suffix in ['.log','.md'] or 'references' in parts
   if f.is_file() and ((f.suffix=='.log' and f.stat().st_size>64*1024) or f.suffix=='.pdf'):keep=False
   if not keep:omit=True;reason='Other tool generated evidence; stable source/tests/fixtures and structured receipts retained.'
  if parts[:4]==('progress','evidence','E03','0.1.1') and len(parts)>4:
   if parts[4].startswith('history-') or parts[4]=='bulk-downloads' or (parts[4]=='bulk' and (f.name.startswith('snapshot-') or f.name.endswith('-actual.json'))):
    if f.suffix!='.log' and f.name not in ['result.json','command.json','root-command.json','check.json']:omit=True;reason='Superseded candidate/failed replay, retained in repository and replaced by actual formal replay.'
  rel=str(f.relative_to(root))
  if rel in e03_duplicates:omit=True;reason='Exact same SHA256 and bytes as '+e03_duplicates[rel]
  if e04_condense and rel in e04_duplicates:
   duplicate=e04_duplicates[rel];canonical=root/duplicate['identical_to']
   assert hashlib.sha256(f.read_bytes()).hexdigest()==hashlib.sha256(canonical.read_bytes()).hexdigest()==duplicate['sha256']
   assert f.stat().st_size==canonical.stat().st_size==duplicate['bytes']
   omit=True;reason='Exact same SHA256 and bytes as '+duplicate['identical_to']
  if e04_condense and parts[:4]==('progress','evidence','E04','0.1.1') and len(parts)>4 and parts[4] in ['downloaded-source-extracted','offline-extracted','downloaded-offline-extracted']:
   omit=True;reason='Extracted source/program copy; original tool/shared source, templates and rebuild receipts retained.'
  if omit:
   if f.is_file():(e04_omitted if e04_condense else e03_omitted)[rel]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size,'reason':reason}
   return False
 return (f.is_file() and f.suffix not in ['.zip','.pyc','.pyo']
         and not any(p in ['node_modules','__pycache__','.git'] for p in f.parts)
         and f.name not in ['.DS_Store','finance-reconciliation.md','upstream-tree.json'])
with zipfile.ZipFile(out/f'{tool}-{version}-离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(out.iterdir()):
  if f.is_file() and f.suffix!='.zip':z.write(f,tool+'/'+f.name)
with zipfile.ZipFile(out/f'{tool}-{version}-源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 snapshot={}
 for name in ['package.json','package-lock.json','tsconfig.json','README.md','工具总览.md','AGENTS.md','CLAUDE.md']:
  content=(root/name).read_bytes();snapshot[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
 implemented=['tools/'+t['folder'] for t in stable]
 for folder in ['apps','packages','scripts','tests','fixtures','docs','catalog','references','progress','website']+implemented:
  for f in sorted((root/folder).rglob('*')):
   if source_file(f):
    relative=str(f.relative_to(root));content=f.read_bytes()
    snapshot[relative]=hashlib.sha256(content).hexdigest();z.writestr(relative,content)
 content=(out/'THIRD_PARTY_NOTICES.md').read_bytes()
 snapshot['THIRD_PARTY_NOTICES.md']=hashlib.sha256(content).hexdigest()
 z.writestr('THIRD_PARTY_NOTICES.md',content)
 z.writestr('source-snapshot.json',json.dumps({'schema_version':1,'tool':tool,'version':version,
  'included_tools':sorted(stable_ids),'excluded_active_tools':excluded,
  'excluded_generated_media':'Evidence screenshots are retained in the project repository, not duplicated in source ZIPs.',
  'reason':'Include stable regression dependencies; active tool source/evidence is not a delivery dependency.',
  'omitted_generated_evidence':e04_omitted if e04_condense else e03_omitted if e03_condense else {},'file_sha256':snapshot},ensure_ascii=False,indent=2)+'\n')
