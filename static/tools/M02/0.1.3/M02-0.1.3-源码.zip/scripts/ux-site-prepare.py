from pathlib import Path
import json,re,hashlib,shutil,os,base64
r=Path.cwd();e=r/'progress/evidence/2026-10-07-ux-repair';old=Path('/private/tmp/aiplus-official-all64-publish');stage=r/'integration/native-site-ux-20261007'
def raw(p):
 with p.open('rb')as f:b=f.read(p.stat().st_size)
 assert len(b)==p.stat().st_size,p
 return b
def sha(p):return hashlib.sha256(raw(p)).hexdigest()
assert (e/'packages.json').exists();cards={c['id']:c for c in json.loads(raw(r/'catalog/tools.json'))};reg=json.loads(raw(old/'site/registry.json'));s=raw(old/'site/index.html').decode();original=s
assert not stage.exists();stage.mkdir();(stage/'site').mkdir()
for n in ['app.py','requirements.txt']:shutil.copyfile(old/n,stage/n)
shutil.copytree(old/'.streamlit',stage/'.streamlit');shutil.copytree(old/'static',stage/'static',copy_function=os.link)
links=[];removed_obsolete=[]
for entry in reg:
 id=entry['id'];oldver=entry['version'];ver=cards[id]['version'];folder=r/'release'/id/ver;target=stage/'static/tools'/id/ver;shutil.copytree(folder,target)
 entry.update(version=ver,runtime=f'app/static/tools/{id}/{ver}/runtime.json',sha256=sha(folder/'runtime.json'),bytes=(folder/'runtime.json').stat().st_size)
 entry['offlineSize']=f"{(folder/(id+'-'+ver+'-离线包.zip')).stat().st_size/1024/1024:.1f} MB"
 pattern=r'<template id="r-'+re.escape(entry['detailRoute'])+r'">.*?</template>';m=re.search(pattern,s,re.S);assert m,id
 t=m[0].replace(f'/tools/{id}/{oldver}/',f'/tools/{id}/{ver}/').replace(f'{id}-{oldver}-',f'{id}-{ver}-');t=t.replace(oldver,ver)
 def anchor(m):
  tag=m[0];name=re.search(r'download="([^"]+)"',tag)[1];p=folder/name;
  if not p.exists():
   assert id=='M01' and name in ['M01-604业务.csv','M01-604组合.xlsx','M01-64费用池.csv','base604-work.json'];removed_obsolete.append({'id':id,'filename':name});return ''
  b=raw(p);n=int(re.search(r'/download-(\d+)\.json',tag)[1]);q=target/f'download-{n}.json';q.write_text(json.dumps({'schema_version':1,'filename':name,'base64':base64.b64encode(b).decode()},ensure_ascii=False)+'\n');digest=hashlib.sha256(b).hexdigest()
  tag=re.sub(r'data-download-sha="[^"]+"',f'data-download-sha="{digest}"',tag);tag=re.sub(r'data-download-bytes="[^"]+"',f'data-download-bytes="{len(b)}"',tag);links.append({'id':id,'filename':name,'sha256':digest,'bytes':len(b)});return tag
 t=re.sub(r'<a\b[^>]*\bdata-program-download\b[^>]*>',anchor,t)
 if id in ['E05','F05']:t=t.replace('单点工具','分析看板')
 s=s[:m.start()]+t+s[m.end():]
 # Change only the actual product row's type; preserve original site layout and routing.
 if id in ['E05','F05']:
  row=re.search(r'<div class="trow" data-tool\b[^>]*data-q="'+re.escape(entry['name'])+r'[^\n]*?\n.*?(?=<div class="trow"|</div></div>\s*</section>)',s,re.S)
  # Restrict replacement to the row ending at its workspace link.
  row=re.search(r'<div class="trow" data-tool\b[^>]*data-q="'+re.escape(entry['name'])+r'[^>]*>.*?href="#'+re.escape(entry['workspaceRoute'])+r'".*?</div></div>',s,re.S);assert row,id
  q=row[0].replace('data-type="T"','data-type="B"').replace('<span class="pill">单点工具</span>','<span class="pill">分析看板</span>');s=s[:row.start()]+q+s[row.end():]
s,n=re.subn(r'window\.__AIPlusRegistry=\[.*?\];',lambda m:'window.__AIPlusRegistry='+json.dumps(reg,ensure_ascii=False).replace('<','\\u003c')+';',s,count=1);assert n==1
assert re.findall(r'data-mod="([^"]+)"',s)==re.findall(r'data-mod="([^"]+)"',original)
assert len(re.findall(r'\bdata-tool\s',s))==113
(stage/'site/index.html').write_text(s);(stage/'site/registry.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')
files={}
for entry in reg:
 for leaf in ['runtime.json',entry['id']+'-'+entry['version']+'-离线包.zip',entry['id']+'-'+entry['version']+'-源码.zip']:
  p=stage/'static/tools'/entry['id']/entry['version']/leaf;files[str(p.relative_to(stage))]={'sha256':sha(p),'bytes':p.stat().st_size}
(e/'site-stage.json').write_text(json.dumps({'stage':str(stage),'prior_site_sha256':sha(old/'site/index.html'),'site_sha256':sha(stage/'site/index.html'),'tools':64,'rows':113,'go_render_preserved':True,'download_anchors':len(links),'files':files,'links':links,'public_verified':False,'removed_obsolete_large_downloads':removed_obsolete},ensure_ascii=False,indent=2)+'\n');print('prepared',len(reg),len(links),flush=True)
