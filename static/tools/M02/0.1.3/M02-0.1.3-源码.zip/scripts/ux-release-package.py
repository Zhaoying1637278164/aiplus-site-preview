"""One identical regression source snapshot, paired with each versioned offline package."""
from pathlib import Path
import json,zipfile,hashlib,shutil
r=Path.cwd();e=r/'progress/evidence/2026-10-07-ux-repair';cards=json.loads((r/'catalog/tools.json').read_text());cache=Path('/private/tmp/aiplus-ux-20261007-source-base.zip');hashes={}
def raw(p):
 with p.open('rb')as f:b=f.read(p.stat().st_size)
 assert len(b)==p.stat().st_size,p
 return b
files=[]
for name in ['package.json','package-lock.json','tsconfig.json','README.md','AGENTS.md','CLAUDE.md','工具总览.md']:files.append(r/name)
for folder in ['apps','packages','scripts','tests','fixtures','docs','catalog','references','tools']:
 for p in (r/folder).rglob('*'):
  if folder=='scripts' and not(p.name in ['build.ts','package.py','catalog.py','stabilize-xlsx-container.py','stabilize-x01-sample.py']or p.name.startswith('ux-')or 'oracle' in p.name):continue
  if folder=='tests' and not(p.name.endswith('.test.ts')or p.suffix=='.py'or p.name.startswith('ux-')):continue
  if not p.is_file() or any(x in p.relative_to(r).parts for x in ['node_modules','__pycache__','.git','candidate','ui-preflight']):continue
  if p.suffix.lower() in ['.zip','.html','.png','.jpg','.jpeg','.webp','.pyc','.pyo']:continue
  if p.name in ['.DS_Store','finance-reconciliation.md','upstream-tree.json']:continue
  assert not any(x in p.name.lower()for x in ['.env','credentials']);files.append(p)
# Exact independent fixtures referenced by regression tests, including rejection ZIPs.
files.append(r/'progress/evidence/A04/independent-expected.json')
for folder in ['progress/evidence/M03/0.1.2/independent','progress/evidence/M03/0.1.2/fixtures']:
 files.extend(p for p in (r/folder).iterdir() if p.is_file())
# Retain the current repair receipts; historical generated replays stay in the repository.
for name in ['source-lock.json','read-ledger.json','versions.json','offline-browser.json','demo-tests.log','unit-tests-final.log','repair-report.md']:
 if (e/name).exists():files.append(e/name)
with zipfile.ZipFile(cache,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in sorted(set(files)):
  if len(hashes)%50==0:print('source files',len(hashes),str(p.relative_to(r)),flush=True)
  b=raw(p);n=str(p.relative_to(r));hashes[n]=hashlib.sha256(b).hexdigest();z.writestr(n,b)
 assert sum(i.file_size for i in z.infolist())<250*1024*1024
print('source snapshot',len(hashes),cache.stat().st_size,flush=True)
results=[]
for c in cards:
 folder=r/'release'/c['id']/c['version'];assert (folder/'index.html').exists();off=folder/(c['id']+'-'+c['version']+'-离线包.zip');src=folder/(c['id']+'-'+c['version']+'-源码.zip')
 with zipfile.ZipFile(off,'w',zipfile.ZIP_DEFLATED)as z:
  for p in sorted(folder.iterdir()):
   if p.is_file() and p.suffix!='.zip':z.writestr(c['id']+'/'+p.name,raw(p))
 shutil.copyfile(cache,src)
 with zipfile.ZipFile(src,'a',zipfile.ZIP_DEFLATED)as z:
  n=raw(folder/'THIRD_PARTY_NOTICES.md');z.writestr('THIRD_PARTY_NOTICES.md',n)
  z.writestr('source-snapshot.json',json.dumps({'schema_version':1,'tool':c['id'],'version':c['version'],'included_tools':[x['id']for x in cards],'file_sha256':{**hashes,'THIRD_PARTY_NOTICES.md':hashlib.sha256(n).hexdigest()},'excluded_generated_media':'Older generated replay bundles and screenshots retained in project evidence; independent fixtures and all regression source included.'},ensure_ascii=False,indent=2)+'\n');assert z.testzip()is None
 for p in [off,src]:assert 0<p.stat().st_size<=24*1024*1024,(p,p.stat().st_size)
 results.append({'id':c['id'],'version':c['version'],'files':{p.name:{'sha256':hashlib.sha256(raw(p)).hexdigest(),'bytes':p.stat().st_size}for p in folder.iterdir()if p.is_file()}});print(c['id'],'packaged',flush=True)
(e/'packages.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
