from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json
r=Path.cwd();e=r/'progress/evidence/2026-10-07-ux-repair';cards=json.loads((r/'catalog/tools.json').read_text())
def build(c):
 with (e/(c['id']+'-release-build.log')).open('w')as f:p=subprocess.run(['node','--import','tsx','scripts/build.ts',c['id'],'--no-package'],stdout=f,stderr=subprocess.STDOUT)
 print(c['id'],p.returncode,flush=True);return {'id':c['id'],'version':c['version'],'exit':p.returncode}
with ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(build,cards))
(e/'release-build.json').write_text(json.dumps(results,indent=2)+'\n');assert all(x['exit']==0 for x in results)
