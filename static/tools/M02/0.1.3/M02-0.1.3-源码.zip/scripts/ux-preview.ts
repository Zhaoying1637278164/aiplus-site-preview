import {build} from 'esbuild';import fs from 'node:fs/promises';import path from 'node:path';
const registry=JSON.parse(await fs.readFile('catalog/tools.json','utf8'));
const root='progress/evidence/2026-10-07-ux-repair/preview';await fs.mkdir(root,{recursive:true});
for(const t of registry){
 const entry='tools/'+t.folder+'/src/main.tsx';
 const result=await build({entryPoints:[entry],bundle:true,write:false,outfile:'bundle.js',platform:'browser',format:'iife',target:['es2022'],minify:true,define:{'process.env.NODE_ENV':'"production"'},alias:{exceljs:'exceljs/lib/exceljs.bare.js'},inject:['packages/core/browser-globals.ts'],plugins:[{name:'browser-io-boundary',setup(b){b.onResolve({filter:/^(fs|crypto)$/},()=>({path:path.resolve('packages/core/browser-disabled.cjs')}));b.onResolve({filter:/^\.\.\/csv\/csv$/},()=>({path:path.resolve('packages/core/browser-csv-disabled.cjs')}))}}]});
 const js=result.outputFiles.find(f=>f.path.endsWith('.js'))!.text,css=result.outputFiles.find(f=>f.path.endsWith('.css'))?.text||'';
 const out=root+'/'+t.id;await fs.mkdir(out,{recursive:true});await fs.writeFile(out+'/index.html',`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; font-src 'none'; base-uri 'none'; form-action 'none'"><title>${t.name} 修复预览</title><style>body{margin:0;background:white;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',sans-serif}${css}</style></head><body><div id="root"></div><script>${js.replace(/<\/script/gi,'<\\/script')}</script></body></html>`);
 console.log(t.id);
}
