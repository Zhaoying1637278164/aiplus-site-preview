"""Version the reviewed UX repair; leave frozen releases and old public proof intact."""
from pathlib import Path
import json,re,hashlib
r=Path.cwd();e=r/'progress/evidence/2026-10-07-ux-repair';h=e/'history';h.mkdir(exist_ok=True)
p=r/'catalog/tools.json';raw=p.read_bytes();(h/'catalog-before-version.json').write_bytes(raw) if not (h/'catalog-before-version.json').exists() else None;cards=json.loads((h/'catalog-before-version.json').read_bytes());changes=[]
for c in cards:
 folder=r/'tools'/c['folder']/'src';old=c['version'];parts=old.split('.');parts[-1]=str(int(parts[-1])+1);new='.'.join(parts)
 for name in ['version','types','model','engine']:
  module=folder/(name+'.ts')
  if not module.exists():continue
  s=module.read_text();m=re.search(r"export const VERSION\s*=\s*(['\"])(\d+\.\d+\.\d+)\1",s)
  if m:break
 assert m,module
 assert m[2] in [old,new],(module,m[2],old,new)
 backup=h/(c['id']+'-version.txt')
 if not backup.exists():backup.write_text(s)
 assert not any(x['tool']==c['id'] and x['version']==new for x in json.loads((r/'catalog/release-locks.json').read_text())['releases'])
 module.write_text(s[:m.start(2)]+new+s[m.end(2):])
 c['version']=new;c['status']='tested';previous=c.get('delivery',{});c['delivery']={'previous_public_version':old,'previous_public_commit':previous.get('public_commit'),'ux_repair_evidence':str(e.relative_to(r)),'unit_tests':'3098 passed','offline_browser':'64 sample replay passed; final new release replay pending','website_verified':False,'public_verified':False,'accepted':False,'windows_verified':False,'windows_real_machine':'unverified','formal_rebuild_required':True}
 changes.append({'id':c['id'],'folder':c['folder'],'old':old,'new':new,'version_file':str(module.relative_to(r))})
p.write_text(json.dumps(cards,ensure_ascii=False,indent=2)+'\n');(e/'versions.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
