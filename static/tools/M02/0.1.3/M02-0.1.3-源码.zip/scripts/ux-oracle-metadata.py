"""Only application version metadata changes; amounts, rules and expected answers retained."""
from pathlib import Path
import json,re,hashlib
# iCloud files can delay EOF: read exactly the declared byte length.
def bounded_text(p,*args,**kwargs):
 with p.open('rb')as f:b=f.read(p.stat().st_size)
 assert len(b)==p.stat().st_size,p
 return b.decode(kwargs.get('encoding')or'utf-8')
Path.read_text=bounded_text
r=Path.cwd();e=r/'progress/evidence/2026-10-07-ux-repair';changes=[]
def metadata(x,old,new,parent=''):
 if isinstance(x,list):
  if len(x)>=2 and x[0] in ['应用','应用版本','app_version','appVersion','App版本'] and isinstance(x[1],str) and x[1].strip('"')==old:x=[x[0],x[1].replace(old,new),*x[2:]]
  return [metadata(v,old,new,parent)for v in x]
 if isinstance(x,dict):
  x=dict(x)
  if x.get('name') in ['应用版本','app_version'] and x.get('value')==old:x['value']=new
  if isinstance(x.get('headers'),list) and isinstance(x.get('rows'),list):
   cols=[i for i,h in enumerate(x['headers'])if h in ['应用版本','app_version','appVersion']]
   if cols:x['rows']=[[new if i in cols and v==old else v for i,v in enumerate(row)]if isinstance(row,list)else row for row in x['rows']]
  return {k:new if isinstance(v,str)and v==old and (k in ['app_version','appVersion','应用版本']or k=='app'and parent=='versions')else metadata(v,old,new,k)for k,v in x.items()}
 return x
for c in json.loads((e/'versions.json').read_text()):
 if c['id'] not in ['A04','B05','C04','D01','D03','E02','F01','F03','K01','K04','M01','M02','X01','X02','X03','X04']:continue
 folder=r/'tools'/c['folder'];old,new=c['old'],c['new'];print(c['id'],flush=True)
 for p in folder.rglob('*.json'):
  if 'candidate'in p.parts or 'src'in p.parts or 'evidence'in p.parts:continue
  if not any(k in p.name.lower() for k in ['oracle','expected']) and not(c['id']=='M01'and 'independent'in p.parts):continue
  try:x=json.loads(p.read_text())
  except (ValueError,UnicodeError):continue
  y=metadata(x,old,new)
  if x!=y:
   before=p.read_bytes();backup=e/'history/oracle-metadata'/p.relative_to(r);backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(before) if not backup.exists() else None;p.write_text(json.dumps(y,ensure_ascii=False,indent=2)+'\n');assert metadata(x,old,new)==y;changes.append({'file':str(p.relative_to(r)),'before_sha256':hashlib.sha256(before).hexdigest(),'change':'app version metadata only'})
 for p in list(folder.rglob('*.py'))+list((folder/'tests').glob('*.ts')):
  if 'candidate'in p.parts or (p.suffix=='.py'and not any(k in p.name for k in ['oracle','generate'])) or (p.suffix=='.ts'and not (p.name.endswith('.test.ts')or p.name=='oracle.ts')):continue
  print(str(p),flush=True);s=p.read_text();lines=[]
  for l in s.splitlines(keepends=True):
   if p.suffix=='.py'and any(k in l for k in ['VERSION','app_version','应用版本',"'应用'"]):l=l.replace("'"+old+"'","'"+new+"'").replace('"'+old+'"','"'+new+'"')
   if p.name=='oracle.ts'and '应用版本'in l:l=l.replace("'"+old+"'","'"+new+"'")
   lines.append(l)
  out=''.join(lines)
  if p.name.endswith('.test.ts'):
   # Positive exported version assertions. Assignments testing old/future input are retained.
   out=re.sub(r"(assert\.equal\([^;\n]*?,)(['\"])"+re.escape(old)+r"\2(\))",lambda m:m[1]+m[2]+new+m[2]+m[3],out)
  if out!=s:p.write_text(out);changes.append({'file':str(p.relative_to(r)),'change':'current application metadata expectation; financial oracle formulas unchanged'})
(e/'oracle-metadata-changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n');print('metadata files',len(changes))
