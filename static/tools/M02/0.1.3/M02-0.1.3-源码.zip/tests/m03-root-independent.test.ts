/** Root fixtures and rational oracle. Expected values never come from the tested code. */
import test from 'node:test';
import assert from 'node:assert/strict';
import {calculate,validate,applyScenario,sensitivity,settingsCheck,D} from '../tools/M03-盈亏平衡与定价测算/src/engine';
import {encodeWork,decodeWork} from '../tools/M03-盈亏平衡与定价测算/src/plan';
import {HEADERS,DEFAULT_SETTINGS,type Model,type Work,type Result} from '../tools/M03-盈亏平衡与定价测算/src/types';
import type {Table,Cell} from '../packages/core/types';

type F={n:bigint;d:bigint};
const f=(x:string):F=>{const neg=x.startsWith('-'),s=x.replace(/^[+-]/,'').split('.');return {n:BigInt(s.join(''))*(neg?-1n:1n),d:10n**BigInt(s[1]?.length??0)}};
const add=(a:F,b:F):F=>({n:a.n*b.d+b.n*a.d,d:a.d*b.d});
const sub=(a:F,b:F):F=>({n:a.n*b.d-b.n*a.d,d:a.d*b.d});
const mul=(a:F,b:F):F=>({n:a.n*b.n,d:a.d*b.d});
const div=(a:F,b:F):F=>{assert(b.n!==0n);return {n:a.n*b.d*(b.n<0n?-1n:1n),d:a.d*(b.n<0n?-b.n:b.n)}};
const cmp=(a:F,b:F)=>a.n*b.d-b.n*a.d;
function decimal(x:F,places=30,round:'nearest'|'up'|'down'='nearest',fixed=false):string{
 const negative=x.n<0n,n=negative?-x.n:x.n,scale=10n**BigInt(places),num=n*scale,whole=num/x.d,rem=num%x.d;
 const increment=round==='up'?(negative?false:rem!==0n):round==='down'?(negative&&rem!==0n):rem*2n>=x.d;
 const digits=(whole+(increment?1n:0n)).toString().padStart(places+1,'0');
 let s=places?digits.slice(0,-places)+'.'+digits.slice(-places):digits;
 if(!fixed&&places)s=s.replace(/0+$/,'').replace(/\.$/,'');return (negative&&s!=='0'?'-':'')+s;
}
const Z=f('0'),ONE=f('1'),HUNDRED=f('100');
function fixture(c:Record<string,Cell>={},row=19):Table{
 const cells:Record<string,Cell>={'方案ID':'ROOT-A','方案名称':'完全虚构根测算','期间':'2026-04','币种':'CNY','金额单位':'元','数量单位':'件','标价':'17.5','折扣百分比':'20','销量':'37','单位变动成本':'5.25','固定成本':'96.25','目标利润':'35','适用最低销量':'0','适用最高销量':'1000000000','成本口径':'虚构不含税线性成本','假设依据':'根独立字面假设',...c};
 return {file:'root-fiction.xlsx',sheet:'根业绩',headers:[...HEADERS],rows:[{file:'root-fiction.xlsx',sheet:'根业绩',row,cells}]};
}
function model(t=fixture()):Model{const d=validate(t);assert.equal(d.issues.length,0);assert.equal(d.models.length,1);return d.models[0]}
const keys=['netPrice','unitContribution','revenue','variableTotal','fixed','contribution','profit','residual','breakEven','breakEvenUnits','breakEvenRevenue','breakEvenProfit','targetUnits','targetUnitProfit','minNetPrice','minListPrice','maxDiscount','safetyUnits','safetyPercent','contributionPercent','targetGap'] as const;
function expected(m:Model):Record<typeof keys[number],string|null>{
 const list=f(m.price),remain=sub(ONE,div(f(m.discount),HUNDRED)),p=mul(list,remain),q=f(m.quantity),v=f(m.variable),fc=f(m.fixed),t=f(m.target),c=sub(p,v),profit=sub(mul(c,q),fc),needed=add(add(mul(v,q),fc),t);
 let be:F|null=null,bq:string|null=null,tq:string|null=null;
 if(cmp(c,Z)>0n){be=div(fc,c);bq=decimal(be,0,'up');tq=decimal(div(add(fc,t),c),0,'up')}
 else if(cmp(fc,Z)===0n){be=Z;bq='0';if(cmp(t,Z)===0n)tq='0'}
 const safety=bq!==null?sub(q,f(bq)):null;
 return {netPrice:decimal(p),unitContribution:decimal(c),revenue:decimal(mul(p,q)),variableTotal:decimal(mul(v,q)),fixed:decimal(fc),contribution:decimal(mul(c,q)),profit:decimal(profit),residual:'0',breakEven:be?decimal(be):null,breakEvenUnits:bq,breakEvenRevenue:bq!==null?decimal(mul(p,f(bq))):null,breakEvenProfit:bq!==null?decimal(sub(mul(c,f(bq)),fc)):null,targetUnits:tq,targetUnitProfit:tq!==null?decimal(sub(mul(c,f(tq)),fc)):null,minNetPrice:cmp(q,Z)>0n?decimal(div(needed,q),2,'up',true):null,minListPrice:cmp(q,Z)>0n&&cmp(remain,Z)>0n?decimal(div(needed,mul(q,remain)),2,'up',true):null,maxDiscount:cmp(q,Z)>0n&&cmp(list,Z)>0n?decimal(mul(div(sub(mul(q,list),needed),mul(q,list)),HUNDRED),6,'down'):null,safetyUnits:safety?decimal(safety):null,safetyPercent:safety&&cmp(q,Z)>0n?decimal(mul(div(safety,q),HUNDRED)):null,contributionPercent:cmp(p,Z)>0n?decimal(mul(div(c,p),HUNDRED)):null,targetGap:decimal(sub(profit,t))};
}
function compare(m:Model,r:Result=calculate(m)){const e=expected(m);for(const k of keys)assert.equal(r[k],e[k],m.id+'/'+k);assert.equal(r.model.source,m.source);assert.equal(r.model.index,m.index);return r}

test('ROOT literal discounted price, contribution, target, cent ceiling and source row19',()=>{
 const m=model(),r=compare(m);assert.deepEqual({price:r.netPrice,unit:r.unitContribution,revenue:r.revenue,variable:r.variableTotal,profit:r.profit,be:r.breakEvenUnits,target:r.targetUnits,minNet:r.minNetPrice,minList:r.minListPrice,discount:r.maxDiscount,safety:r.safetyUnits,gap:r.targetGap},{price:'14',unit:'8.75',revenue:'518',variable:'194.25',profit:'227.5',be:'11',target:'15',minNet:'8.80',minList:'11.00',discount:'49.729729',safety:'26',gap:'192.5'});assert.equal(r.model.source.row,19);assert.equal(r.residual,'0');
});
test('ROOT exact quantity/cent minima, recurring ratios and safe discount floor',()=>{
 for(const cells of [{'标价':'1','单位变动成本':'0.7','固定成本':'1','目标利润':'1','销量':'3','折扣百分比':'0'},{'标价':'1.000001','单位变动成本':'0','固定成本':'1','目标利润':'0','销量':'1','折扣百分比':'0'},{'标价':'0.000002','单位变动成本':'0.000001','固定成本':'0.000001','目标利润':'0.000001','销量':'1','折扣百分比':'0'}]){
  const m=model(fixture(cells)),r=compare(m),c=f(r.unitContribution),fc=f(m.fixed),t=f(m.target);
  assert(cmp(mul(c,f(r.breakEvenUnits!)),fc)>=0n);if(r.breakEvenUnits!=='0')assert(cmp(mul(c,sub(f(r.breakEvenUnits!),ONE)),fc)<0n);
  assert(cmp(mul(c,f(r.targetUnits!)),add(fc,t))>=0n);if(r.targetUnits!=='0')assert(cmp(mul(c,sub(f(r.targetUnits!),ONE)),add(fc,t))<0n);
  const need=add(add(mul(f(m.variable),f(m.quantity)),fc),t);assert(cmp(mul(f(r.minNetPrice!),f(m.quantity)),need)>=0n);
  assert(cmp(mul(sub(f(r.minNetPrice!),f('0.01')),f(m.quantity)),need)<0n);
  const coverage=mul(mul(f(m.price),sub(ONE,div(f(r.maxDiscount!),HUNDRED))),f(m.quantity));assert(cmp(coverage,need)>=0n);
  const next=mul(mul(f(m.price),sub(ONE,div(add(f(r.maxDiscount!),f('0.000001')),HUNDRED))),f(m.quantity));assert(cmp(next,need)<0n);
 }
});
test('ROOT zero/missing, zero/negative contribution, impossible goals and zero-price inverse',()=>{
 const zeroCases:Record<string,Cell>[]=[{'销量':'0'},{'标价':'5.25','折扣百分比':'0'},{'标价':'1','折扣百分比':'0','固定成本':'0','目标利润':'1'},{'标价':'5.25','折扣百分比':'0','固定成本':'0','目标利润':'0'},{'标价':'0','固定成本':'0','目标利润':'0','折扣百分比':'100'}];
 for(const cells of zeroCases)compare(model(fixture(cells)));
 const noSale=compare(model(fixture({'销量':'0'})));assert.equal(noSale.profit,'-96.25');assert.equal(noSale.minNetPrice,null);assert.equal(noSale.safetyPercent,null);
 assert.equal(validate(fixture({'固定成本':null})).models.length,0);assert.equal(validate(fixture({'固定成本':'0'})).models.length,1);
});
test('ROOT 607 independent rational cases, extreme amounts and six-place inputs',()=>{
 for(let i=0;i<607;i++){
  const dec=(n:number)=>`${Math.floor(n/1000)}.${String(n%1000).padStart(3,'0')}`;
  const t=fixture({'方案ID':'ROOT-'+i,'标价':dec(600+(i*811)%97000),'单位变动成本':dec((i*317)%49000),'折扣百分比':String(i%101),'销量':String((i*941)%13000),'固定成本':dec((i*1973)%910000),'目标利润':dec((i*127)%88000),'期间':i%2?'2026-04':'2026-05','币种':i%3?'CNY':'USD'},19+i*17);
  compare(model(t));
 }
 const big=compare(model(fixture({'标价':'999999999999.999999','单位变动成本':'999999999999.999998','固定成本':'999999999999.999999','目标利润':'999999999999.999999','折扣百分比':'0','销量':'1000000000'})));assert.equal(big.unitContribution,'0.000001');assert.equal(big.profit,'-999999998999.999999');
});
test('ROOT duplicate IDs block every duplicate, periods/currencies remain independent and invalid scope blocks',()=>{
 const a=fixture(),b=fixture({'方案ID':'ROOT-B','期间':'2026-05','币种':'USD'},27);a.rows.push(b.rows[0]);const valid=validate(a);assert.equal(valid.models.length,2);valid.models.forEach(m=>compare(m));assert.equal(valid.models[1].source.row,27);
 a.rows[1].cells['方案ID']='ROOT-A';const duplicate=validate(a);assert.equal(duplicate.models.length,0);assert.deepEqual(duplicate.issues.filter(x=>x.field==='方案ID').map(x=>x.source.row),[19,27]);
 const invalidCases:Record<string,Cell>[]=[{'期间':'2026-13'},{'币种':'cny'},{'金额单位':'万元'},{'数量单位':'千件'},{'销量':'1.5'},{'销量':'1000000001'},{'折扣百分比':'100.000001'},{'标价':'-1'},{'固定成本':{formula:'1+1',cached:2}},{'目标利润':'0.0000001'},{'成本口径':''},{'假设依据':''},{'适用最低销量':'100','适用最高销量':'50'}];
 for(const c of invalidCases)assert.equal(validate(fixture(c)).models.length,0,JSON.stringify(c));
});
test('ROOT source overrides preserve originals and range warnings never turn into feasibility claims',()=>{
 const t=fixture({'适用最低销量':'20','适用最高销量':'30'}),raw=JSON.stringify(t);const {models}=validate(t,{'0':{'标价':'20'}});assert.equal(models.length,1);compare(models[0]);assert.equal(JSON.stringify(t),raw);assert.equal(models[0].source.row,19);
 const r=compare(model(t));assert.equal(r.status,'范围外外推');assert(r.warnings.some(x=>x.includes('当前销量')));assert(r.warnings.some(x=>x.includes('保本量')));assert(r.warnings.some(x=>x.includes('目标利润销量')));
});
test('ROOT named scenario applies absolute discount, floors fractional quantities and preserves source',()=>{
 const m=model(),s={name:'根虚构扩量',discount:'10',volumeChange:'15',variableChange:'20',fixedChange:'-10',basis:'根字面情景'};const r=applyScenario(m,s);
 const transformed={...m,discount:'10',quantity:'42',variable:'6.3',fixed:'86.625',basis:m.basis+'；情景：根字面情景'};compare(transformed,r);assert.equal(r.netPrice,'15.75');assert.equal(r.profit,'310.275');assert.equal(m.quantity,'37');
});
test('ROOT sensitivity all Cartesian cells, display/tolerance never change raw numeric answers',()=>{
 const m=model(),s={...DEFAULT_SETTINGS,priceAxis:'-100,0,25',quantityAxis:'-100,0,15',display:0,tolerance:'0'};const grid=sensitivity(m,s);assert.equal(grid.length,9);
 for(const g of grid){const pm=mul(f(m.price),add(ONE,div(f(g.priceChange),HUNDRED))),qm=mul(f(m.quantity),add(ONE,div(f(g.quantityChange),HUNDRED)));compare({...m,price:decimal(pm),quantity:decimal(qm,0,'down')},g.result)}
 const changed=sensitivity(m,{...s,display:6,tolerance:'999999'});assert.deepEqual(grid,changed);assert.throws(()=>settingsCheck({...s,priceAxis:'0,0'}));assert.throws(()=>settingsCheck({...s,display:7}));
 const before=D.precision;assert.equal(before,80);
});
test('ROOT schema-versioned work/no-data restoration keeps exact source and rejects stale version or incompatible payload',()=>{
 const t=fixture(),w:Work={table:t,overrides:{'0':{'标价':'20'}},settings:{...DEFAULT_SETTINGS},scenarios:[{name:'根情景',discount:'0',volumeChange:'0',variableChange:'0',fixedChange:'0',basis:'完全虚构'}]};
 const raw=JSON.stringify(w),full=encodeWork(w,true);assert.deepEqual(decodeWork(full),w);assert.equal(JSON.parse(full).contains_data,true);assert.equal(JSON.parse(full).schema_version,1);
 const no=encodeWork(w,false),restored=decodeWork(no);assert.equal(restored.table,null);assert.deepEqual(restored.overrides,{});assert.deepEqual(restored.scenarios,w.scenarios);assert.equal(JSON.stringify(w),raw);
 const p=JSON.parse(full);p.app_version='0.1.0';assert.throws(()=>decodeWork(JSON.stringify(p)),/版本/);
 const wrong=JSON.parse(no);wrong.work.table=t;assert.throws(()=>decodeWork(JSON.stringify(wrong)),/携带资料/);
});
