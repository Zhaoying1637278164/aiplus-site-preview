import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const host=process.env.AIPLUS_HOST||'http://localhost:8519',root=process.env.AIPLUS_STAGE||process.cwd()+'/integration/native-site-ux-20261007',out=process.cwd()+'/progress/evidence/2026-10-07-ux-repair/'+(host.startsWith('https:')?'public-contract':'local-contract');
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
await mkdir(out,{recursive:true});
const registry=JSON.parse(await readFile(root+'/site/registry.json','utf8'));
assert.equal(registry.length,64);const site=sha(await readFile(root+'/site/index.html'));
const snapshot=JSON.parse(await readFile('progress/evidence/2026-10-07-ux-repair/site-stage.json','utf8'));
assert.equal(Object.keys(snapshot.files).length,192);
async function formalBytes(entry:any,filename:string){
 const key='static/tools/'+entry.id+'/'+entry.version+'/'+filename,record=snapshot.files[key];assert(record,key);
 const bytes=await readFile(root+'/'+key);assert.equal(bytes.length,record.bytes);assert.equal(sha(bytes),record.sha256);return bytes;
}
for(const entry of registry){const bytes=await formalBytes(entry,'runtime.json');assert.equal(sha(bytes),entry.sha256);}

async function siteFrame(p:any){
 const end=Date.now()+120000;while(Date.now()<end){for(const f of p.frames())if(await f.locator('.logo').count())return f;await p.waitForTimeout(300)}throw Error('original website srcdoc missing');
}
async function verifyDoc(f:any){const h=await f.frameElement();const doc=await h.getAttribute('srcdoc');assert(doc);const normalized=doc.replace(/<script>window\.__AIPlusAssetPrefix=[\s\S]*?<\/script>/,'').replace(/<script>window\.__AIPlusInitialRoute=[\s\S]*?<\/script>/,'');assert.equal(sha(Buffer.from(normalized)),site,'actual public HTML exact reviewed stage');}
const browser=await chromium.launch({executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
const checks:any[]=[],downloads:any[]=[],external:string[]=[],errors:string[]=[];
try{
 const context=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}});
 context.setDefaultTimeout(60000);
 context.on('request',r=>{const u=new URL(r.url());if(/^https?:/.test(u.protocol)&&u.origin!==host)external.push(u.origin+u.pathname)});
 const p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));p.on('dialog',d=>d.accept());
 let runtimeTasks:Promise<{url:string;sha256:string;status:number}>[]=[];
 p.on('response',r=>{if(/\/runtime\.json$/.test(new URL(r.url()).pathname))runtimeTasks.push((async()=>({url:r.url(),sha256:sha(await r.body()),status:r.status()}))())});
 for(const entry of registry){
  runtimeTasks=[];
  await p.goto(host+'/?tool='+entry.id,{waitUntil:'domcontentloaded'});
  const f=await siteFrame(p),w=f.locator('#tool-workspace');await verifyDoc(f);
  // The original site breadcrumb carries the registered name; an App h1 may
  // name its current financial task (R04: 截止余额与催收复核).
  await f.getByText(entry.name,{exact:true}).first().waitFor();
  await w.getByRole('heading').first().waitFor();
  const workHeadings=await w.getByRole('heading').allInnerTexts();
  assert.equal(await w.count(),1);assert.equal(await w.locator('iframe').count(),0);
  const runtimes=await Promise.all(runtimeTasks);assert.equal(runtimes.length,1,entry.id+' only current runtime');
  assert.equal(new URL(runtimes[0].url).origin,host);assert(new URL(runtimes[0].url).pathname.endsWith('/component/app.aiplus_tool_assets/tools/'+entry.id+'/'+entry.version+'/runtime.json'));
  assert.equal(runtimes[0].status,200);assert.equal(runtimes[0].sha256,entry.sha256);
  assert.equal(sha(await formalBytes(entry,'runtime.json')),entry.sha256);
  const demo=w.getByRole('button',{name:/^(载入样例|载入虚构样例|载入完全虚构样例|体验虚构样例|体验虚构示例|查看虚构样例|载入虚构资料|换入虚构样例|装入虚构样例|载入虚构PDF|体验虚构合同|查看完全虚构样例)$/}).first();
  await demo.click();await f.waitForFunction(()=>!document.body.innerText.includes('正在本机解析PDF')&&!document.body.innerText.includes('正在本地处理…'));
  if(entry.id==='D04')await w.getByText('Sales',{exact:true}).first().waitFor();
  if(entry.id==='R04')await w.getByText('3780000.00',{exact:true}).first().waitFor();
  if(entry.id==='D05')await w.getByRole('heading',{name:'问题定位与复核',exact:true}).waitFor();
  if(['T02','M01','K02'].includes(entry.id))assert(await w.locator('svg[role="img"]').count()>0);
  await f.locator('.nav a[href="#tools"]').click();
  const row=f.locator('[data-tool]').filter({has:f.getByRole('link',{name:entry.name,exact:true})});
  assert.equal(await row.count(),1);await row.getByRole('link',{name:'详情',exact:true}).click();
  await f.getByRole('heading',{name:entry.name,exact:true}).waitFor();
  for(const kind of ['离线包','源码']){
   const filename=entry.id+'-'+entry.version+'-'+kind+'.zip';
   const link=f.locator('[data-program-download][download="'+filename+'"]');assert(await link.count()>0,filename);
   const pending=p.waitForEvent('download');await link.first().click();const d=await pending;
   const target=out+'/'+filename;await d.saveAs(target);assert.equal(await d.failure(),null);
   const actual=await readFile(target),expected=await formalBytes(entry,filename);
   assert.equal(expected.length,snapshot.files['static/tools/'+entry.id+'/'+entry.version+'/'+filename].bytes,filename+' formal file read must be complete');
   assert(expected.length>0,filename+' formal ZIP cannot be empty');
   assert.equal(sha(actual),sha(expected),filename);assert(actual.length<=24*1024*1024);
   downloads.push({id:entry.id,filename,target,bytes:actual.length,sha256:sha(actual)});
  }
  checks.push({id:entry.id,name:entry.name,version:entry.version,visible_registered_finance_name:true,work_headings:workHeadings,only_current_runtime:true,runtime:runtimes[0],native_no_nested_iframe:true});
  await writeFile(out+'/partial.json',JSON.stringify({site_sha256:site,checks,downloads,scope:'Actual completed tools only; entire run not yet passed'},null,2));
  console.log(entry.id+' current runtime and both version ZIP downloads passed');
 }
 runtimeTasks=[];await p.goto(host+'/?tool=NOT_REGISTERED',{waitUntil:'domcontentloaded'});
 const sf=await siteFrame(p);await sf.parentFrame()!.getByText('该工具尚未开放，请从工具库选择已交付的工具。',{exact:true}).waitFor();
 await sf.locator('.logo').waitFor();
 assert.equal(await sf.locator('#tool-workspace').count(),0);assert.equal(runtimeTasks.length,0);
 // Original Cloud host requests allowed by explicit user exception.
assert.deepEqual(errors,[]);assert.equal(sha(await readFile(root+'/site/index.html')),site);
 await writeFile(out+'/result.json',JSON.stringify({passed:true,formal_input_snapshot_sha256:sha(await readFile('progress/evidence/2026-10-07-ux-repair/site-stage.json')),site_sha256:site,checks,downloads,unknown_tool_blocked:true,external,errors,scope:'Actual user-facing public original URL: 64 current runtime SHA, exact deployed srcdoc, 128 actual ZIP downloads, unknown whitelist blocked; platform requests authorized; financial flows separate.'},null,2));
 console.log('All64 host contract and128 actual downloads passed');
}catch(error){await writeFile(out+'/failure.json',JSON.stringify({error:String(error),checks,downloads,external,errors},null,2));throw error}finally{await browser.close()}
