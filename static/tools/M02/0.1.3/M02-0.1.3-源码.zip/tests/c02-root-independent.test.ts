import test from 'node:test';
import assert from 'node:assert/strict';
import {calculate} from '../tools/C02-计提与冲回/src/engine';
import {makeTable} from '../tools/C02-计提与冲回/src/example';
import {confirmWork,emptyWork,decode,encode} from '../tools/C02-计提与冲回/src/work';

function data(mode='手工',amount='1200.00',ratio='1'){
 return {
  expenses:makeTable('expenses',[['ROOT','虚构部门','2026-01',amount,'CNY','元','ROOT-R','虚构服务依据','计提']],'根虚构费用.csv'),
  rules:makeTable('rules',[['ROOT-R','独立v1','2026-01','2026-12',ratio,mode,'6602','2241','1','1','CNY','元','虚构规则依据']],'根虚构规则.csv'),
  reversals:null as ReturnType<typeof makeTable>|null,
  changes:null as ReturnType<typeof makeTable>|null,
 };
}
test('root independent integer rounding at large value and six-place proportion',()=>{
 const d=data('次期全额','9999999999999.99','0.123456');
 // Integer cents * millionths; HALF_UP from quotient/remainder, independent of Decimal.
 const cents=(999999999999999n*123456n+500000n)/1000000n;
 const expected=(cents/100n).toString()+'.'+(cents%100n).toString().padStart(2,'0');
 const r=calculate(d);assert.equal(r.canConfirm,true);
 assert.equal(r.events[0].amount,expected);assert.equal(r.events[1].amount,'-'+expected);
 assert.equal(r.totals[0].balance,'0.00');assert.equal(r.totals[0].difference,'0.00');
});
test('root same-month change applied before reversal and complete later balance',()=>{
 const d=data();
 d.reversals=makeTable('reversals',[
  ['R02','ROOT','2026-02','部分','400.00','CNY','元','虚构02依据'],
  ['R03','ROOT','2026-03','部分','1000.00','CNY','元','虚构03依据'],
  ['R04','ROOT','2026-04','全额',null,'CNY','元','虚构04依据'],
 ]);
 d.changes=makeTable('changes',[['C03','ROOT','2026-03','1500.00','CNY','元','虚构变更依据']]);
 const r=calculate(d);assert.equal(r.canConfirm,true);
 assert.deepEqual(r.balances.map(b=>[b.period,b.opening,b.accrual,b.reversal,b.closing]),[
  ['2026-01','0.00','1200.00','0.00','1200.00'],
  ['2026-02','1200.00','0.00','400.00','800.00'],
  ['2026-03','800.00','300.00','1000.00','100.00'],
  ['2026-04','100.00','0.00','100.00','0.00'],
 ]);
 assert.equal(r.events.find(e=>e.id==='冲回:R04')?.amount,'-100.00');
 assert.equal(r.totals[0].debit,'3000.00');assert.equal(r.totals[0].credit,'3000.00');
});
test('root negative future change reverses mapping and preserves exact running balance',()=>{
 const d=data();d.changes=makeTable('changes',[['C02','ROOT','2026-02','900.00','CNY','元','虚构减少依据']]);
 d.reversals=makeTable('reversals',[['R03','ROOT','2026-03','全额',null,'CNY','元','虚构结清依据']]);
 const r=calculate(d);assert.equal(r.canConfirm,true);
 assert.equal(r.events.find(e=>e.id==='变更:C02')?.amount,'-300.00');
 assert.deepEqual(r.entries.filter(e=>e.event==='变更:C02').map(e=>[e.account,e.debit,e.credit]),[['6602','0.00','300.00'],['2241','300.00','0.00']]);
 assert.equal(r.balances[1].closing,'900.00');assert.equal(r.totals[0].balance,'0.00');
 assert.equal(r.totals[0].debit,'2400.00');
});
test('root duplicate same-period reversal blocks both applications without losing initial accrual',()=>{
 const d=data();d.reversals=makeTable('reversals',[
  ['R01','ROOT','2026-02','部分','200.00','CNY','元','虚构依据1'],
  ['R02','ROOT','2026-02','部分','100.00','CNY','元','虚构依据2'],
 ]);
 const r=calculate(d);assert.equal(r.canConfirm,false);assert.equal(r.events.length,1);
 assert.equal(r.totals[0].balance,'1200.00');
 assert.equal(r.issues.filter(i=>i.message.includes('同事项同期间重复冲回')).length,2);
});
test('root confirmed snapshot survives later source change; tampering cannot restore',()=>{
 const w=confirmWork({...emptyWork(),data:data('次期全额')},'虚构复核人','虚构复核依据');
 const prior=JSON.stringify(w.history[0]);w.data.expenses!.rows[0].cells['金额']='1400.00';
 assert.equal(JSON.stringify(w.history[0]),prior);
 assert.equal(calculate(w.data).totals[0].accrual,'1400.00');
 assert.equal(w.history[0].result.totals[0].accrual,'1200.00');
 assert.equal(decode(encode(w,true)).history[0].result.totals[0].accrual,'1200.00');
 const raw=JSON.parse(encode(w,true));raw.work.history[0].result.events[0].amount='1199.00';
 assert.throws(()=>decode(JSON.stringify(raw)),/篡改/);
});
test('root missing amount blocks while explicit zero remains traceable without journal',()=>{
 const zero=data('次期全额','0.00');const r=calculate(zero);
 assert.equal(r.canConfirm,true);assert.equal(r.entries.length,0);
 assert.equal(r.events[0].expenseSource,'根虚构费用.csv / CSV / 第2行');
 assert.equal(r.events[0].ruleSource,'根虚构规则.csv / CSV / 第2行');
 assert.equal(r.events[0].ruleVersion,'独立v1');
 const missing=data();missing.expenses.rows[0].cells['金额']=null;
 const m=calculate(missing);assert.equal(m.canConfirm,false);assert.equal(m.events.length,0);
 assert.ok(m.issues.some(i=>i.message.includes('金额缺失')));
});
