import {chromium} from 'playwright';import fs from 'node:fs/promises';import path from 'node:path';import {pathToFileURL} from 'node:url';
const root=path.resolve('progress/evidence/2026-10-07-ux-repair'),registry=JSON.parse(await fs.readFile('catalog/tools.json','utf8'));
const browser=await chromium.launch({executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
const results=[];const high=new Set(['U03','R04','E05','T03','D04','C01','M02','T02','M01','K02']);
try{
 for(const t of registry){const context=await browser.newContext({offline:true,acceptDownloads:true,viewport:{width:1440,height:1000}}),page=await context.newPage(),errors:string[]=[],network:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))network.push(r.url())});page.on('dialog',d=>d.accept());
 const row:any={id:t.id,errors,network};try{
  await page.goto(pathToFileURL((process.env.AIPLUS_RELEASE_REPLAY?path.resolve('release/'+t.id+'/'+t.version):root+'/preview/'+t.id)+'/index.html').href);await page.locator('h1').waitFor();
  const demo=page.getByRole('button',{name:/^(载入样例|载入虚构样例|载入完全虚构样例|体验虚构样例|体验虚构示例|查看虚构样例|载入虚构资料|换入虚构样例|装入虚构样例|载入虚构PDF|体验虚构合同|查看完全虚构样例)$/}).first();
  row.sampleButton=await demo.count();if(!row.sampleButton)throw Error('Sample button not found');await demo.click();
  await page.waitForFunction(()=>!document.body.innerText.includes('正在本机解析PDF')&&!document.body.innerText.includes('正在本地处理…'));await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  if(t.id==='D05')await page.getByRole('heading',{name:'问题定位与复核',exact:true}).waitFor();
  row.title=await page.locator('h1').innerText();row.heading=await page.locator('h2').allTextContents();row.charts=await page.locator('svg[role="img"]').count();row.text=await page.locator('body').innerText();
  if(t.id==='R04'&&!row.text.includes('3780000.00'))throw Error('Aging independent balance missing');
  if(t.id==='D04'){await page.getByText('Sales',{exact:true}).first().waitFor();row.text=await page.locator('body').innerText();}
  if(t.id==='T02'&&!row.text.includes('1630000'))throw Error('Cash demo independent closing balance missing');
  if(['M01','K02','T02'].includes(t.id)&&!row.charts)throw Error('Result chart missing');
  if(t.id==='D05'&&!row.text.includes('静态检查'))throw Error('Formula sample did not check');
  if(high.has(t.id)){
   await page.screenshot({path:root+'/'+t.id+'-desktop.png',fullPage:true});await page.setViewportSize({width:390,height:844});await page.screenshot({path:root+'/'+t.id+'-mobile.png',fullPage:true});
   row.mobileOverflow=await page.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth+2);
  }
  row.pass=errors.length===0&&network.length===0;await fs.writeFile(root+'/'+t.id+'-sample.txt',row.text);delete row.text;
 }catch(e){row.pass=false;row.failure=(e as Error).message}finally{results.push(row);await context.close();await fs.writeFile(root+'/offline-browser.json',JSON.stringify(results,null,2));console.log(t.id,row.pass?'PASS':row.failure||errors.join(';'));}
 }
}finally{await browser.close()}
if(results.some(r=>!r.pass))process.exitCode=1;
