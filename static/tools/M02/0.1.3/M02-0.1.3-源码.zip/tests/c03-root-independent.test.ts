import test from 'node:test';
import assert from 'node:assert/strict';
import {headers,emptyState,parseTable,schedule,reconcile,confirmPeriod,addChange,addActual,encodePlan,decodePlan,type State} from '../tools/C03-待摊费用排程/src/engine';

function state(total='100.00',start='2026-01-01',end='2026-03-31',actual='0.00',through='2025-12'):State{
 const s=emptyState(),values=['ROOT','虚构服务',total,start,end,'CNY','元',actual,through,'管理费用','待摊费用','完全虚构依据'];
 s.items=parseTable({file:'根独立虚构台账.csv',sheet:'台账',headers,rows:[{file:'根独立虚构台账.csv',sheet:'台账',row:204,cells:Object.fromEntries(headers.map((h,i)=>[h,values[i]]))}]},s.rule);
 return s;
}
test('root three-month100 tail33.34 and negative credit use signed exact conservation',()=>{
 for(const [total,expected] of [['100.00',['33.33','33.33','33.34']],['-100.00',['-33.33','-33.33','-33.34']]] as const){
  const s=state(total);const lines=schedule(s);assert.deepEqual(lines.map(x=>x.amount),expected);
  assert.equal(lines[2].cumulative,total);assert.equal(lines[2].remaining,'0.00');
  assert.ok(lines.every(x=>x.source==='根独立虚构台账.csv / 台账 / 行204'));
 }
});
test('root leap calendar uses inclusive January31 February29; boundaries28/29/1 count2+1',()=>{
 const a=state('60.00','2024-01-01','2024-02-29');a.rule.method='day';
 assert.deepEqual(schedule(a).map(x=>[x.period,x.weight,x.amount]),[['2024-01',31,'31.00'],['2024-02',29,'29.00']]);
 const b=state('3.00','2024-02-28','2024-03-01');b.rule.method='day';
 assert.deepEqual(schedule(b).map(x=>[x.period,x.weight,x.amount]),[['2024-02',2,'2.00'],['2024-03',1,'1.00']]);
 b.rule.first=false;assert.deepEqual(schedule(b).map(x=>[x.period,x.amount]),[['2024-03','3.00']]);
});
test('root locked first six months survive18000 future remaining allocation',()=>{
 const s=confirmPeriod(state('12000.00','2026-01-01','2026-12-31','5900.00','2026-06'),'2026-06');
 const prior=JSON.stringify(s.confirmed);
 const changed=addChange(s,{id:'ROOT',period:'2026-07',total:'18000.00',mode:'remaining',reason:'虚构变更依据'});
 const rows=schedule(changed);
 assert.deepEqual(rows.slice(0,6).map(x=>x.amount),Array(6).fill('1000.00'));
 assert.deepEqual(rows.slice(6).map(x=>x.amount),Array(6).fill('2000.00'));
 assert.equal(rows.at(-1)?.cumulative,'18000.00');assert.equal(rows.at(-1)?.remaining,'0.00');
 assert.equal(JSON.stringify(changed.confirmed),prior);
 assert.throws(()=>addChange(s,{id:'ROOT',period:'2026-06',total:'18000.00',mode:'remaining',reason:'虚构依据'}),/晚于/);
});
test('root actual5900 does not become confirmed6000; future actual7000 has independent evidence',()=>{
 const s=confirmPeriod(state('12000.00','2026-01-01','2026-12-31','5900.00','2026-06'),'2026-06');
 assert.deepEqual(reconcile(s).map(x=>[x.planned,x.actual,x.difference,x.remaining]),[['6000.00','5900.00','-100.00','6100.00']]);
 const updated=addActual(s,{id:'ROOT',period:'2026-07',amount:'7000.00',reason:'虚构账务复核'});
 assert.deepEqual(reconcile(updated).map(x=>[x.planned,x.actual,x.difference,x.remaining]),[['7000.00','7000.00','0.00','5000.00']]);
 assert.equal(updated.items[0].actual,'5900.00');assert.equal(updated.items[0].source.cells['已摊金额'],'5900.00');
 assert.equal(updated.actualUpdates[0].reason,'虚构账务复核');assert.equal(JSON.stringify(updated.confirmed),JSON.stringify(s.confirmed));
});
test('root future settlement emits remaining6000 once; later months zero',()=>{
 const s=confirmPeriod(state('12000.00','2026-01-01','2026-12-31','5900.00','2026-06'),'2026-06');
 const settled=addChange(s,{id:'ROOT',period:'2026-07',total:'12000.00',mode:'settle',reason:'虚构提前终止'});
 const rows=schedule(settled);assert.equal(rows[6].amount,'6000.00');
 assert.deepEqual(rows.slice(7).map(x=>x.amount),Array(5).fill('0.00'));
 assert.equal(rows[6].remaining,'0.00');assert.equal(rows.at(-1)?.cumulative,'12000.00');
});
test('root restored state retains source and locks; tampered confirmation rejected',()=>{
 const s=confirmPeriod(state('12000.00','2026-01-01','2026-12-31'),'2026-06');
 const encoded=encodePlan(s,true),restored=decodePlan(encoded);
 assert.deepEqual(restored,s);assert.equal(restored.items[0].source.row,204);
 const tampered=JSON.parse(encoded);tampered.state.confirmed[0].lines[0].amount='999.00';
 assert.throws(()=>decodePlan(JSON.stringify(tampered)),/快照不一致/);
 const plan=decodePlan(encodePlan(s,false));assert.equal(plan.items.length,0);assert.equal(plan.confirmed.length,0);
});
