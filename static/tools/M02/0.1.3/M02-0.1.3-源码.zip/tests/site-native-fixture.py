"""Prepare an isolated navigation fixture; never a released finance program."""
from pathlib import Path
import importlib.util, json, hashlib, subprocess, shutil

root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('native_site',root/'scripts/site.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
subprocess.run(['node','--import','tsx','scripts/build-site-host.ts'],cwd=root,check=True)
js='''window.__aiPlusLoadedProgram={id:'D02',version:'9.9.9',name:'账表对账',mount(context){
 const heading=document.createElement('h2');heading.textContent='原生整合测试（非财务成品）';
 const input=document.createElement('input');input.setAttribute('aria-label','完全虚构的测试事项');
 const back=document.createElement('button');back.textContent='返回账表对账详情';back.onclick=context.onExit;
 context.container.append(heading,input,back);
 return {requestExit(){return !input.value||confirm('虚构测试记录未保存，确认离开？')},dispose(){context.container.replaceChildren()}};
}};'''
payload=json.dumps({'schema_version':1,'id':'D02','version':'9.9.9','name':'账表对账','js':js,'css':'h2{font-size:24px;font-weight:600}input,button{font:inherit;padding:10px;margin:12px;border:1px solid #CFD2D7;border-radius:6px}'},ensure_ascii=False).encode()
entry={'id':'D02','name':'账表对账','version':'9.9.9','detailRoute':'tool-D02','workspaceRoute':'work-D02','runtime':'app/static/tools/D02/9.9.9/runtime.json','sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload),'offlineSize':'测试样例，非成品'}
files=['D02-9.9.9-离线包.zip','D02-9.9.9-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md']
source=module.native_document((root.parent/'aiplus-streamlit/site/index.html').read_text(),entry,files,(root/'integration/native-host.js').read_text())
folder=root/'integration/native-fixture';folder.mkdir(exist_ok=True)
(folder/'index.html').write_text(source)
target=folder/'app/static/tools/D02/9.9.9';target.mkdir(parents=True,exist_ok=True)
(target/'runtime.json').write_bytes(payload)
(folder/'registry.json').write_text(json.dumps([entry],ensure_ascii=False))
(folder/'app.py').write_text(module.native_streamlit_app((root.parent/'aiplus-streamlit/app.py').read_text(),index='index.html',registry='registry.json'))
shutil.copytree(folder/'app/static',folder/'static',dirs_exist_ok=True)
(folder/'.streamlit').mkdir(exist_ok=True)
(folder/'.streamlit/config.toml').write_text('[server]\nenableStaticServing=true\n[browser]\ngatherUsageStats=false\n')
print('Native navigation fixture only; not staged or published')
