import test from 'node:test';
import assert from 'node:assert/strict';
import {blank,binding,calculate,itemHeaders,planHeaders,validReview,type Work} from '../tools/X02-税会差异底稿/src/engine';
import {encode,decode} from '../tools/X02-税会差异底稿/src/work';
import type {Table,Cell} from '../packages/core/types';
// Literal fictitious cases calculated manually; no author sample or oracle imported.
function table(headers:string[],rows:Record<string,Cell>[]):Table{return {file:'根虚构.csv',sheet:'手算',headers,rows:rows.map((cells,i)=>({file:'根虚构.csv',sheet:'手算',row:i+9,cells}))};}
function work(patch:Record<string,Cell>={}):Work{
 const w=blank();w.rule={entity:'根虚构企业',period:'2026-09',currency:'CNY',unit:'元',tolerance:'0.01'};
 w.tables.items=table(itemHeaders,[{差异ID:'00007',事项:'根虚构事项',科目:'虚构科目',主体:'根虚构企业',期间:'2026-09',币种:'CNY',单位:'元',性质:'应纳税暂时',期初:'100.25',新增:'30.10',转回:'20.05',期末:'110.30',账面价值:null,计税基础:null,会计依据:'根虚构依据',税务依据:'根虚构依据',适用条件:'仅测试',规则版本:'根虚构1',生效期:'2026-01',失效期:'2026-12',来源引用:'虚构原表第9行',...patch}]);
 w.confirmations['00007']=binding(w,w.tables.items.rows[0]);return w;
}
function plans(w:Work,amounts:string[],periods=['2026-10','2026-11']){
 w.tables.plans=table(planHeaders,amounts.map((amount,i)=>({计划ID:'P'+i,差异ID:'00007',主体:'根虚构企业',期间:periods[i],币种:'CNY',单位:'元',转回金额:amount,计划依据:'根虚构未来计划'})));return w;
}
test('manual110.30 conservation, full future70.10+40.20 and original source',()=>{
 const r=calculate(plans(work(),['70.10','40.20']));assert.equal(r.items[0].computed,'110.30');assert.equal(r.items[0].residual,'0.00');assert.equal(r.items[0].planned,'110.30');assert.equal(r.items[0].unplanned,'0.00');assert.equal(r.items[0].id,'00007');assert.equal(r.items[0].row.row,9);assert.deepEqual(r.periods.map(p=>p['应纳税暂时']),['70.10','40.20']);
});
test('partial plan retains60.30; over-plan blocks every candidate without netting',()=>{
 assert.equal(calculate(plans(work(),['50.00'])).items[0].unplanned,'60.30');const r=calculate(plans(work(),['100.00','20.00']));assert.equal(r.items[0].unplanned,'-9.70');assert.ok(r.plans.every(p=>!p.ready&&p.issues.includes('计划合计超过事项期末')));assert.deepEqual(r.periods,[]);
});
test('literal missing/formula/negative/third decimal blocked, explicit zero retained',()=>{
 for(const value of [null,'-1','0.001',{formula:'1+2',cached:30.10}])assert.equal(calculate(work({新增:value})).items[0].ready,false);
 const r=calculate(work({期初:'0',新增:'0',转回:'0',期末:'0'}));assert.equal(r.items[0].ready,true);assert.equal(r.items[0].computed,'0.00');
});
test('permanent current3.25, no plan and excess reversal negative computation blocked',()=>{
 const r=calculate(plans(work({性质:'永久',期初:'0',新增:'3.25',转回:'0',期末:'3.25'}),['1']));assert.equal(r.items[0].ready,true);assert.equal(r.items[0].computed,'3.25');assert.equal(r.plans[0].ready,false);assert.equal(r.items[0].unplanned,null);
 const q=calculate(work({期初:'1',新增:'2',转回:'4',期末:'0'}));assert.equal(q.items[0].computed,'-1.00');assert.equal(q.items[0].ready,false);
});
test('basis pair absolute gap110.30 does not infer eligibility or classification',()=>{
 assert.equal(calculate(work({账面价值:'200.00',计税基础:'89.70'})).items[0].ready,true);
 assert.equal(calculate(work({账面价值:'89.70',计税基础:'200.00'})).items[0].nature,'应纳税暂时');
 assert.equal(calculate(work({账面价值:'200',计税基础:null})).items[0].ready,false);
 const w=work();w.confirmations={};assert.equal(calculate(w).totals[0].closing,'0.00');
});
test('currency/unit/period/effective scope and duplicate source IDs block',()=>{
 const patches:Record<string,Cell>[]=[{币种:'USD'},{单位:'万元'},{期间:'2026-08'},{生效期:'2026-10'},{性质:'未知'}];
 for(const patch of patches)assert.equal(calculate(work(patch)).items[0].ready,false);
 const w=work();w.tables.items!.rows.push({...w.tables.items!.rows[0],row:10});assert.ok(calculate(w).items.every(i=>!i.ready));
 const q=calculate(plans(work(),['10','10'],['2026-10','2026-10']));assert.ok(q.plans.every(p=>!p.ready));
});
test('tolerance preserves residual, review cannot waive finance error or changed data',()=>{
 const w=work({期末:'110.31'});w.rule.tolerance='1';w.confirmations['00007']=binding(w,w.tables.items!.rows[0]);assert.equal(calculate(w).items[0].residual,'0.01');
 const bad=work({期末:'115'});bad.reviews['00007']={preparer:'虚构编制',reviewer:'虚构复核',date:'2026-10-04',note:'根虚构复核',binding:binding(bad,bad.tables.items!.rows[0])};assert.equal(calculate(bad).items[0].reviewed,true);assert.equal(calculate(bad).items[0].ready,false);bad.tables.items!.rows[0].cells.新增='31';assert.equal(calculate(bad).items[0].reviewed,false);assert.equal(calculate(bad).items[0].ready,false);
 assert.equal(validReview({...bad.reviews['00007'],date:'2026-02-30'}),false);
});
test('data/no-data plans restored distinctly, unknown schema rejected',()=>{
 const w=plans(work(),['70.10','40.20']);assert.equal(calculate(decode(encode(w,true))).items[0].computed,'110.30');const clean=decode(encode(w,false));assert.equal(clean.tables.items,null);assert.deepEqual(clean.confirmations,{});const raw=JSON.parse(encode(w,true));raw.schema_version=999;assert.throws(()=>decode(JSON.stringify(raw)));const hidden=JSON.parse(encode(w,false));hidden.tables=w.tables;assert.throws(()=>decode(JSON.stringify(hidden)));
});
