import assert from 'node:assert/strict';
import test from 'node:test';
import {siteAssetURL} from '../packages/ui/site-asset-url';
const base='https://finance.example/';
const prefix='component/app.aiplus_tool_assets/tools/';
test('original static route remains exact without component configuration',()=>{
 for(const file of ['runtime.json','download-0.json','download-99.json']){
  const url=new URL('app/static/tools/E02/0.2.0/'+file,base);
  assert.equal(siteAssetURL(url,base).href,url.href);
 }
});
test('all64 stable IDs and versions preserve exact relative resource names',()=>{
 for(const group of ['D','R','P','T','K','A','C','X','B','E','M','F','U'])
 for(let i=1;i<=6;i++)for(const file of ['runtime.json','download-0.json','download-99.json']){
  const path=group+String(i).padStart(2,'0')+'/0.1.1/'+file;
  assert.equal(siteAssetURL(new URL('app/static/tools/'+path,base),base,prefix).href,base+prefix+path);
 }
});
test('deployment base path and original first-party origin are preserved',()=>{
 const b=base+'finance/';
 assert.equal(siteAssetURL(new URL('app/static/tools/M02/0.1.1/runtime.json',b),b,prefix).href,b+prefix+'M02/0.1.1/runtime.json');
});
test('external origins, arbitrary code/files, query and encoded path escapes rejected',()=>{
 for(const url of ['https://outside.example/app/static/tools/E02/0.2.0/runtime.json',base+'app/static/tools/E02/0.2.0/runtime.json?data=1',base+'app/static/tools/E02/0.2.0/runtime.json#x',base+'app/static/tools/E02/0.2.0/../../secret.json',base+'app/static/tools/E02/0.2.0/%2e%2e/secret.json',base+'app/static/tools/E02/0.2.0/index.html',base+'app/static/tools/E02/0.2.0/download-100.json'])assert.throws(()=>siteAssetURL(new URL(url),base,prefix));
});
test('component configuration rejects external URLs and directory escapes',()=>{
 const url=new URL('app/static/tools/E02/0.2.0/runtime.json',base);
 for(const p of [null,42,'https://outside.example/','//outside.example/','component/../tools/','component/app.aiplus_tool_assets/../../','component/app.aiplus_tool_assets/tools/?x=','component/arbitrary/tools/'])assert.throws(()=>siteAssetURL(url,base,p));
});
