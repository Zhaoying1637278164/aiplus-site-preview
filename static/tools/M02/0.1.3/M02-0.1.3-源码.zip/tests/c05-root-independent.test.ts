import {test} from 'node:test';
import assert from 'node:assert/strict';
import {calculate,fields,defaultMapping,defaults,type Tables,type Config} from '../tools/C05-凭证编制与核对/src/engine';
import type {Cell,Table} from '../packages/core/types';

function table(kind:keyof Tables,rows:Record<string,Cell>[]):Table {
 return {file:'虚构根凭证.xlsx',sheet:kind,headers:fields[kind],rows:rows.map((cells,i)=>({file:'虚构根凭证.xlsx',sheet:kind,row:i+7,cells:Object.fromEntries(fields[kind].map(f=>[f,cells[f]??null]))}))};
}
function tables():Tables {
 const business=table('business',[{'业务ID':'0007','凭证组':'V-根','主体':'虚构甲','期间':'2026-09','币种':'CNY','单位':'元','模板ID':'TPL-根','金额':'100.01','税额':'13.00','摘要':'虚构业务','部门':'虚构部门','依据':'完全虚构依据'}]);
 const templates=table('templates',[['成本','借','金额'],['税','借','税额'],['应付','贷','金额'],['应付','贷','税额']].map(([account,side,field],i)=>({'模板ID':'TPL-根','模板行号':String(i+1),'科目键':account,'方向':side,'金额字段':field,'系数':'1','开始期间':'2026-01','结束期间':'2026-12'})));
 const accounts=table('accounts',['成本','税','应付'].map((account,i)=>({'主体':'虚构甲','科目键':account,'科目编码':'000'+(i+1),'科目名称':'虚构'+account,'必填部门':'否','必填客商':'否','必填项目':'否','开始期间':'2026-01','结束期间':'2026-12'})));
 return {business,templates,accounts};
}
const run=(t=tables(),c:Config={...defaults})=>calculate(t,defaultMapping(),c);
test('manual 100.01 plus 13 gives 113.01; four original static entries and source rows',()=>{
 const r=run();assert.deepEqual(r.groups.map(g=>[g.debit,g.credit,g.difference,g.status]),[['113.01','113.01','0','检查通过·待人工审批']]);
 assert.deepEqual(r.entries.map(x=>[x.account,x.debit,x.credit]),[['0001','100.01','0'],['0002','13','0'],['0003','0','100.01'],['0003','0','13']]);
 assert.ok(r.entries.every(x=>x.businessId==='0007'&&x.source.row===7));assert.match(r.entries[3].templateSource,/第10行/);
});
test('direct difference0.01 remains blocked even within tolerance1',()=>{
 const t=tables();const base=t.business!.rows[0].cells;t.business=table('business',[{...base,'分录行号':'1','科目键':'成本','借方':'100','贷方':'0'},{...base,'分录行号':'2','科目键':'应付','借方':'0','贷方':'99.99'}]);
 const r=run(t,{...defaults,mode:'direct',tolerance:'1'});assert.equal(r.groups[0].difference,'0.01');assert.equal(r.groups[0].withinTolerance,true);assert.equal(r.groups[0].status,'阻塞');
});
test('explicit red retains negative debit/credit; without permission blocked',()=>{
 const t=tables();t.business!.rows[0].cells['金额']='-100.01';t.business!.rows[0].cells['税额']='-13';
 assert.equal(run(t).groups[0].status,'阻塞');const r=run(t,{...defaults,allowRed:true});assert.equal(r.groups[0].debit,'-113.01');assert.equal(r.groups[0].credit,'-113.01');assert.equal(r.groups[0].status,'检查通过·待人工审批');
});
for(const v of [null,'', '0', {formula:'100+0.01',cached:100.01}] as Cell[])
 test('missing/zero/formula amount cannot create approved voucher: '+JSON.stringify(v),()=>{
  const t=tables();t.business!.rows[0].cells['金额']=v;const r=run(t);assert.equal(r.groups[0].status,'阻塞');assert.ok(r.inputIssues[0].issues.length>0||r.groups[0].issues.length>0);
 });
test('unknown and duplicate account mappings cannot approve even balanced amounts',()=>{
 const t=tables();t.accounts!.rows.pop();assert.equal(run(t).groups[0].status,'阻塞');
 const u=tables();u.accounts!.rows.push({...structuredClone(u.accounts!.rows[0]),row:23});assert.equal(run(u).groups[0].status,'阻塞');
});
test('closed period and mandatory department independently block',()=>{
 const t=tables();assert.equal(run(t,{...defaults,openPeriods:['2026-10']}).groups[0].status,'阻塞');
 t.accounts!.rows[0].cells['必填部门']='是';t.business!.rows[0].cells['部门']=null;assert.equal(run(t).groups[0].status,'阻塞');
});
test('same voucher mixed currency/unit never presented as valid net',()=>{
 const t=tables();const row=structuredClone(t.business!.rows[0]);row.row=19;row.cells['业务ID']='0008';row.cells['币种']='USD';row.cells['单位']='万元';t.business!.rows.push(row);
 const r=run(t);assert.equal(r.groups[0].status,'阻塞');assert.deepEqual(r.groups[0].currencies,['CNY','USD']);assert.deepEqual(r.groups[0].units,['元','万元']);
});
