import {test} from 'node:test';
import assert from 'node:assert/strict';
import {compare} from '../tools/B05-预算版本与假设对比/src/engine';
import {defaultConfig} from '../tools/B05-预算版本与假设对比/src/types';
import {encode,decode} from '../tools/B05-预算版本与假设对比/src/plan';
import type {Table,Cell} from '../packages/core/types';
const headers=['项目','部门','期间','币种','单位','金额','口径版本','人数'];
const row=(id:string,amount:Cell,other:Record<string,Cell>={})=>({'项目':id,'部门':'虚构研发','期间':'2027-01','币种':'CNY','单位':'元','金额':amount,'口径版本':'v1','人数':'2',...other});
const table=(file:string,rows:Record<string,Cell>[]):Table=>({file,sheet:'虚构预算',headers,rows:rows.map((cells,i)=>({file,sheet:'虚构预算',row:i+2,cells}))});
const calc=(l:Record<string,Cell>[],r:Record<string,Cell>[],options={})=>compare(table('原.csv',l),table('新.csv',r),{...defaultConfig(),...options});
test('root independent: 100+40-30+25=135; source rows preserved',()=>{
 const x=calc([row('共同','70'),row('删除','30')],[row('共同','95'),row('新增','40')]);
 assert.deepEqual(x.bridges,[{partition:'["2027-01","CNY","元"]',old:'100',added:'40',deleted:'30',change:'25',next:'135',residual:'0',blockedOld:'0',blockedNew:'0',blockedRows:0}]);
 assert.deepEqual(x.items.map(i=>[i.status,i.delta]),[['金额变化','25'],['删除','-30'],['新增','40']]);assert.equal(x.items[0].left[0].row,2);assert.equal(x.items[2].right[0].row,3);assert.equal(x.leftRows+x.rightRows,4);
});
test('root independent: tolerance retains micro amount bridge; materiality does not hide',()=>{
 const x=calc([row('A','0.100001')],[row('A','0.100003')],{tolerance:'0.01',materiality:'0.000001'});
 assert.equal(x.items[0].status,'相同');assert.equal(x.items[0].delta,'0.000002');assert.equal(x.items[0].material,true);assert.equal(x.bridges[0].change,'0.000002');assert.equal(x.bridges[0].next,'0.100003');assert.equal(x.bridges[0].residual,'0');
});
test('root independent: null blocks both sides; zero and negative remain comparable',()=>{
 const x=calc([row('空',null),row('零','0'),row('负','-10')],[row('空','8'),row('零','0'),row('负','-13')]);
 assert.deepEqual(x.items.map(i=>[i.status,i.delta]),[['待复核',null],['相同','0'],['金额变化','-3']]);assert.equal(x.bridges[0].old,'-10');assert.equal(x.bridges[0].next,'-13');assert.equal(x.bridges[0].blockedOld,'0');assert.equal(x.bridges[0].blockedNew,'8');assert.equal(x.bridges[0].blockedRows,2);
});
test('root independent: duplicate group blocks all three; explicit aggregate compares 3 to 5',()=>{
 const l=[row('A','1'),row('A','2')],r=[row('A','5')];const b=calc(l,r);assert.equal(b.items[0].status,'待复核');assert.equal(b.bridges[0].blockedRows,3);assert.equal(b.bridges[0].blockedOld,'3');assert.equal(b.bridges[0].blockedNew,'5');
 const a=calc(l,r,{duplicates:'aggregate' as const});assert.equal(a.items[0].delta,'2');assert.equal(a.items[0].left.length,2);assert.equal(a.bridges[0].residual,'0');
});
test('root independent: policy change excluded; aggregate assumption conflict blocks',()=>{
 const x=calc([row('A','10')],[row('A','12',{'口径版本':'v2'})]);assert.equal(x.items[0].status,'口径变化');assert.equal(x.items[0].delta,null);assert.equal(x.bridges[0].old,'0');assert.equal(x.bridges[0].blockedOld,'10');assert.equal(x.bridges[0].blockedNew,'12');
 const c=calc([row('A','1'),row('A','2',{'人数':'3'})],[row('A','5')],{duplicates:'aggregate' as const,assumptions:[{left:'人数',right:'人数'}]});assert.equal(c.items[0].status,'待复核');assert.equal(c.bridges[0].blockedRows,3);
});
test('root independent: period currency unit are four separate partitions',()=>{
 const x=calc([row('A','10')],[row('A','11',{'期间':'2027-02'}),row('A','12',{'币种':'USD'}),row('A','13',{'单位':'万元'})]);assert.equal(x.bridges.length,4);assert.deepEqual(x.items.map(i=>i.status),['删除','新增','新增','新增']);assert.ok(x.bridges.every(b=>b.residual==='0'));assert.deepEqual(x.bridges.map(b=>b.next),['0','11','12','13']);
});
test('root independent: invalid period precision and formula blocked; no invented assumptions',()=>{
 for(const extra of ([{'期间':'2027-13'},{'金额':'1.0000001'},{'金额':{formula:'1+1',cached:2}}] as Record<string,Cell>[])){const x=calc([row('A','1',extra)],[row('A','2')]);assert.equal(x.items[0].status,'待复核');assert.equal(x.items[0].delta,null)}
 const a=calc([row('A','1')],[row('A','3')]);assert.deepEqual(a.items[0].assumptions,[]);assert.equal(a.items[0].delta,'2');
});
test('root independent: full recovery recomputes; no-data removes inputs; unknown schema rejected',()=>{
 const w={config:defaultConfig(),left:table('原.csv',[row('A','8')]),right:table('新.csv',[row('A','9')])};const d=decode(encode(w,true));assert.equal(compare(d.left!,d.right!,d.config).bridges[0].change,'1');assert.deepEqual(d.left,w.left);const n=decode(encode(w,false));assert.equal(n.left,null);assert.equal(n.right,null);const p=JSON.parse(encode(w,true));p.schema_version=7;assert.throws(()=>decode(JSON.stringify(p)),/版本/);
});
