import assert from 'node:assert/strict';
import test from 'node:test';
import ExcelJS from 'exceljs';
import {validateReleaseAssets,type ReleaseAsset,type TemplateFilename} from '../packages/core/release-assets';

const csv:ReleaseAsset={filename:'空白模板.csv',data:'字段\r\n'};
const sample:ReleaseAsset={filename:'虚构样例.xlsx',data:new Uint8Array([1])};
test('existing CSV contract remains strict; XLSX requires explicit registration',()=>{
 assert.doesNotThrow(()=>validateReleaseAssets([csv,sample]));
 const xlsx={filename:'空白模板.xlsx',data:new Uint8Array([1])};
 assert.throws(()=>validateReleaseAssets([xlsx,sample]),/缺少/);
 assert.throws(()=>validateReleaseAssets([csv,sample],'空白模板.xlsx'),/缺少/);
 assert.throws(()=>validateReleaseAssets([csv,sample],'未登记' as TemplateFilename),/未登记/);
});
test('explicit XLSX template retains real workbook formula text and sheet structure',async()=>{
 const wb=new ExcelJS.Workbook();const sheet=wb.addWorksheet('完全虚构检查模板');
 sheet.getCell('A1').value='金额';sheet.getCell('A2').value=0;
 sheet.getCell('B2').value={formula:'A2+1',result:1};
 const data=new Uint8Array(await wb.xlsx.writeBuffer());
 assert.doesNotThrow(()=>validateReleaseAssets([{filename:'空白模板.xlsx',data},sample],'空白模板.xlsx'));
 const readback=new ExcelJS.Workbook();await readback.xlsx.load(data as unknown as Parameters<typeof readback.xlsx.load>[0]);
 assert.equal(readback.getWorksheet(1)?.getCell('A2').value,0);
 assert.equal(readback.getWorksheet(1)?.getCell('B2').formula,'A2+1');
 assert.equal(readback.getWorksheet(1)?.getCell('B2').result,1);
});
test('both template formats keep duplicate, traversal, size and content gates',()=>{
 for(const filename of ['空白模板.csv','空白模板.xlsx'] as const){
  const asset={filename,data:'完全虚构'};
  assert.throws(()=>validateReleaseAssets([asset,asset,sample],filename),/重复/);
  assert.throws(()=>validateReleaseAssets([asset,{filename:'../escape',data:''},sample],filename),/文件名/);
  assert.throws(()=>validateReleaseAssets([asset,{filename:'超限',data:new Uint8Array(10*1024*1024+1)},sample],filename),/上限/);
  assert.throws(()=>validateReleaseAssets([asset,{filename:'错误',data:null} as unknown as ReleaseAsset,sample],filename),/内容/);
  assert.throws(()=>validateReleaseAssets([asset],filename),/缺少/);
 }
});
