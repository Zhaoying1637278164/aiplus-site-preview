import test from 'node:test';
import assert from 'node:assert/strict';
import {calculate} from '../tools/M02-量价结构差异分析/src/engine';
import {defaultConfig,type Factor,type Config} from '../tools/M02-量价结构差异分析/src/types';
import type {Table,Cell} from '../packages/core/types';
type F={n:bigint;d:bigint};
const f=(v:string):F=>{const [a,b='']=v.replace('-','').split('.');return {n:BigInt(a+b)*(v.startsWith('-')?-1n:1n),d:10n**BigInt(b.length)}};
const add=(a:F,b:F):F=>({n:a.n*b.d+b.n*a.d,d:a.d*b.d});
const sub=(a:F,b:F):F=>({n:a.n*b.d-b.n*a.d,d:a.d*b.d});
const mul=(a:F,b:F):F=>({n:a.n*b.n,d:a.d*b.d});
const div=(a:F,b:F):F=>{assert(b.n>0n);return {n:a.n*b.d,d:a.d*b.n}};
const zero=f('0');
function rounded(a:F,p:number):F{const scale=10n**BigInt(p),abs=a.n<0n?-a.n:a.n,num=abs*scale;return {n:(num/a.d+(num%a.d*2n>=a.d?1n:0n))*(a.n<0n?-1n:1n),d:scale}}
function text(a:F):string{const v=rounded(a,6),neg=v.n<0n,s=(neg?-v.n:v.n).toString().padStart(7,'0');const out=(s.slice(0,-6)+'.'+s.slice(-6)).replace(/0+$/,'').replace(/\.$/,'');return (neg&&out!=='0'?'-':'')+out}
const factors:Factor[]=['总量','结构','价格','单位成本'];
function permutations(a:Factor[]):Factor[][]{return a.length?a.flatMap((x,i)=>permutations(a.filter((_,j)=>j!==i)).map(rest=>[x,...rest])):[[]]}
const headers=['产品ID','分类','期间','币种','金额单位','数量单位','口径','数量','单价','单位成本','原始收入','原始成本'];
type Value={id:string;q:string;p:string;c:Cell;extra?:Record<string,Cell>};
function table(period:string,values:Value[],file:string):Table{return {file,sheet:'虚构根资料',headers,rows:values.map((v,i)=>({file,sheet:'虚构根资料',row:19+i*17,cells:{'产品ID':v.id,'分类':'虚构品类','期间':period,'币种':'CNY','金额单位':'元','数量单位':'件','口径':'根独立不含税模型','数量':v.q,'单价':v.p,'单位成本':v.c,'原始收入':null,'原始成本':null,...v.extra}}))}}
const config=(patch:Partial<Config>={}):Config=>({...defaultConfig(),confirmed:true,note:'完全虚构根独立假设',...patch});
const simple=()=>({left:table('2026-08',[{id:'000A',q:'10',p:'10',c:'4'},{id:'000B',q:'20',p:'20',c:'8'}],'root-old.csv'),right:table('2026-09',[{id:'000A',q:'20',p:'12',c:'5'},{id:'000B',q:'10',p:'18',c:'7'}],'root-new.csv')});
test('ROOT literal two-product income and gross bridges with source row19/36',()=>{
 const {left,right}=simple(),raw=JSON.stringify([left,right]),r=calculate(left,right,config());
 const income=r.bridges.find(b=>b.metric==='收入')!,gross=r.bridges.find(b=>b.metric==='毛利')!;
 assert.deepEqual([income.old,income.next,income.delta,income.effects,income.residual],['500','420','-80',{'总量':'0','结构':'-100','价格':'20','单位成本':'0'},'0']);
 assert.deepEqual([gross.old,gross.next,gross.delta,gross.effects,gross.residual],['300','250','-50',{'总量':'0','结构':'-60','价格':'20','单位成本':'-10'},'0']);
 assert.equal(r.items[0].left[0].source.row,19);assert.equal(r.items[1].right[0].source.row,36);assert.equal(JSON.stringify([left,right]),raw);
});
test('ROOT own rational oracle for all24 factor orders and seven precisions',()=>{
 const a=[{id:'ROOT-X',q:'7',p:'12.13',c:'5.77'},{id:'ROOT-Y',q:'11',p:'18.43',c:'8.91'},{id:'ROOT-Z',q:'3',p:'2.17',c:'1.03'}];
 const b=[{id:'ROOT-X',q:'13',p:'13.89',c:'6.11'},{id:'ROOT-Y',q:'5',p:'16.19',c:'7.87'},{id:'ROOT-Z',q:'9',p:'2.59',c:'1.07'}];
 const left=table('2026-08',a,'root-rational-old.xlsx'),right=table('2026-09',b,'root-rational-new.xlsx');
 const Q0=a.map(x=>f(x.q)).reduce(add,zero),Q1=b.map(x=>f(x.q)).reduce(add,zero);
 for(const order of permutations(factors))for(let precision=0;precision<=6;precision++){
  const result=calculate(left,right,config({order,precision}));
  for(const metric of ['收入','毛利'] as const){
   const totals=Object.fromEntries(factors.map(k=>[k,zero])) as Record<Factor,F>;
   let old=zero,next=zero;
   for(let i=0;i<a.length;i++){
    const x=a[i],y=b[i],c0=metric==='毛利'?f(String(x.c)):zero,c1=metric==='毛利'?f(String(y.c)):zero;
    const oldItem=mul(f(x.q),sub(f(x.p),c0)),nextItem=mul(f(y.q),sub(f(y.p),c1));old=add(old,oldItem);next=add(next,nextItem);
    let quantity=Q0,share=div(f(x.q),Q0),price=f(x.p),cost=c0,before=oldItem;
    const item=result.items.find(v=>v.product===x.id)![metric==='收入'?'revenue':'gross'];
    for(const factor of order){if(factor==='总量')quantity=Q1;if(factor==='结构')share=div(f(y.q),Q1);if(factor==='价格')price=f(y.p);if(factor==='单位成本')cost=c1;
     const after=mul(mul(quantity,share),sub(price,cost)),effect=rounded(sub(after,before),precision);before=after;
     assert.equal(item.effects[factor],text(effect),order.join('/')+'/'+precision+'/'+metric+'/'+x.id+'/'+factor);totals[factor]=add(totals[factor],effect);
    }
   }
   const bridge=result.bridges.find(x=>x.metric===metric)!;
   assert.equal(bridge.old,text(old));assert.equal(bridge.next,text(next));assert.equal(bridge.delta,text(sub(next,old)));
   const effects=Object.fromEntries(factors.map(k=>[k,text(totals[k])]));assert.deepEqual(bridge.effects,effects);
   assert.equal(bridge.residual,text(sub(sub(next,old),Object.values(totals).reduce(add,zero))));
  }
 }
});
test('ROOT missing cost blocks gross alone; missing and zero remain different',()=>{
 const {left,right}=simple();right.rows[0].cells['单位成本']=null;const r=calculate(left,right,config()),i=r.items.find(x=>x.product==='000A')!;
 assert.equal(i.revenue.blocked,false);assert.equal(i.gross.blocked,true);assert.equal(i.gross.next,null);
 const income=r.bridges.find(b=>b.metric==='收入')!,gross=r.bridges.find(b=>b.metric==='毛利')!;assert.equal(income.delta,'-80');assert.equal(gross.unknownNext,1);assert.equal(gross.blockedOld,'60');assert.equal(gross.next,'110');
 right.rows[0].cells['单位成本']='0';const zeroCost=calculate(left,right,config()).items.find(x=>x.product==='000A')!;assert.equal(zeroCost.gross.blocked,false);assert.equal(zeroCost.gross.next,'240');
});
test('ROOT original amount deviations stay separate from factor contribution',()=>{
 const {left,right}=simple();left.rows[0].cells['原始收入']='101';left.rows[1].cells['原始收入']='399';right.rows[0].cells['原始收入']='242';right.rows[1].cells['原始收入']='183';
 const c=config();c.fields.left.revenue=c.fields.right.revenue='原始收入';const r=calculate(left,right,c),b=r.bridges.find(x=>x.metric==='收入')!;
 assert.equal(b.old,'500');assert.equal(b.next,'425');assert.equal(b.delta,'-75');assert.equal(b.inputResidual,'5');assert.equal(b.residual,'0');
 assert.equal(r.items.find(x=>x.product==='000A')!.revenue.inputResidual,'1');assert.equal(r.items.find(x=>x.product==='000B')!.revenue.inputResidual,'4');
});
test('ROOT duplicate groups, formula objects and period exclusions retain every source',()=>{
 const {left,right}=simple();left.rows.push({...left.rows[0],row:91,cells:{...left.rows[0].cells}});const duplicate=calculate(left,right,config());
 const i=duplicate.items.find(x=>x.product==='000A')!;assert(i.revenue.blocked&&i.gross.blocked);assert.deepEqual(i.left.map(x=>x.source.row),[19,91]);
 const clean=simple();clean.right.rows[0].cells['单价']={formula:'1+1',cached:999};assert.equal(calculate(clean.left,clean.right,config()).items[0].status,'待复核');
 const outside=simple();outside.right.rows.push({...outside.right.rows[0],row:101,cells:{...outside.right.rows[0].cells,'期间':'2026-10'}});const excluded=calculate(outside.left,outside.right,config());assert.equal(excluded.rows.length,5);assert.equal(excluded.rows[4].excluded,true);assert.equal(excluded.bridges[0].delta,'-80');
});
test('ROOT currency partitions and structural absence never merge or fabricate source rows',()=>{
 const {left,right}=simple();left.rows[1].cells['币种']='USD';right.rows[1].cells['币种']='USD';right.rows.push({file:right.file,sheet:right.sheet,row:91,cells:{...right.rows[0].cells,'产品ID':'NEW','数量':'2','单价':'3','单位成本':'1'}});
 const r=calculate(left,right,config());assert.equal(r.bridges.length,4);const n=r.items.find(x=>x.product==='NEW')!;assert.equal(n.status,'新增');assert.equal(n.left.length,0);assert.equal(n.revenue.added,'6');assert.equal(n.right[0].source.row,91);
 const usd=r.bridges.find(x=>x.partition[0]==='USD'&&x.metric==='收入')!;assert.equal(usd.old,'400');assert.equal(usd.next,'180');assert.equal(usd.delta,'-220');
});
