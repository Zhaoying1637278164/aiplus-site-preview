import {test} from 'node:test';
import assert from 'node:assert/strict';
import {reconcile,defaultRule,fields,type Side,type Data,type Rule} from '../tools/C06-总账明细账对账/src/engine';
import type {Cell,Table} from '../packages/core/types';

function table(side:Side,values:Record<string,Cell>[]):Table {
 const file='完全虚构根'+side+'.xlsx',sheet=side;
 return {file,sheet,headers:fields(side),rows:values.map((v,i)=>({file,sheet,row:i+7,cells:Object.fromEntries(fields(side).map(h=>[h,v[h]??null]))}))};
}
function data():Data {
 const key={'主体':'虚构根甲','科目':'001','期间':'2026-09','币种':'CNY','单位':'元','辅助维度':'合计'};
 return {gl:table('gl',[{...key,'期初借方':'100.10','期初贷方':'0','本期借方':'20.20','本期贷方':'5.05','期末借方':'115.25','期末贷方':'0'}]),
 tx:table('tx',[{...key,'辅助维度':'甲','行ID':'0001','摘要':'虚构第一条','本期借方':'12.12','本期贷方':'1.01'},
                {...key,'辅助维度':'乙','行ID':'0002','摘要':'虚构第二条','本期借方':'8.08','本期贷方':'4.04'}]),
 balance:table('balance',[{...key,'辅助维度':'甲','期初借方':'60.06','期初贷方':'0','期末借方':'69.09','期末贷方':'0'},
                         {...key,'辅助维度':'乙','期初借方':'40.04','期初贷方':'0','期末借方':'46.16','期末贷方':'0'}])};
}
const run=(d=data(),r:Rule=defaultRule())=>reconcile(d,r);
test('independent 100.10+20.20-5.05=115.25; separate totals and original composition',()=>{
 const r=run();assert.equal(r.groups.length,1);const g=r.groups[0];
 assert.deepEqual(g.left,['100.1','20.2','5.05','115.25']);assert.deepEqual(g.right,g.left);
 assert.deepEqual(g.delta,['0','0','0','0']);assert.equal(g.glResidual,'0');assert.equal(g.detailResidual,'0');assert.equal(g.status,'容差内一致');
 assert.deepEqual(g.tx.map(s=>[s.file,s.sheet,s.row,s.cells['行ID']]),[['完全虚构根tx.xlsx','tx',7,'0001'],['完全虚构根tx.xlsx','tx',8,'0002']]);
 assert.deepEqual(g.balance.map(s=>s.cells['期末借方']),['69.09','46.16']);
});
test('missing auxiliary balances retain null opening/closing; never infer zeros',()=>{
 const d=data();d.balance=null;const g=run(d).groups[0];assert.equal(g.status,'缺辅助余额');
 assert.deepEqual(g.right,[null,'20.2','5.05',null]);assert.deepEqual(g.delta,[null,'0','0',null]);assert.equal(g.detailResidual,null);
});
test('explicit zero is a valid provided amount on every side',()=>{
 const d=data();for(const side of ['gl','tx','balance'] as const)for(const row of d[side]!.rows)
  for(const h of fields(side).filter(h=>h.includes('借方')||h.includes('贷方')))row.cells[h]='0';
 const g=run(d).groups[0];assert.deepEqual(g.right,['0','0','0','0']);assert.equal(g.status,'容差内一致');
});
test('blank/null/formula amount blocks all four differences without using cache',()=>{
 for(const value of [null,'',{formula:'100+15.25',cached:115.25},'0.0000001'] as Cell[]){
  const d=data();d.gl!.rows[0].cells['期末借方']=value;const g=run(d).groups[0];
  assert.equal(g.status,'数据异常阻塞');assert.deepEqual(g.delta,[null,null,null,null]);
 }
});
test('duplicate total balances are preserved and blocked, not summed away',()=>{
 const d=data();d.gl!.rows.push({...structuredClone(d.gl!.rows[0]),row:19});const g=run(d).groups[0];
 assert.equal(g.gl.length,2);assert.equal(g.status,'数据异常阻塞');assert.deepEqual(g.left,[null,null,null,null]);
});
test('currency and unit mismatch stays in separate groups',()=>{
 const d=data();d.tx!.rows[1].cells['币种']='USD';d.tx!.rows[1].cells['单位']='万元';const r=run(d);
 assert.equal(r.groups.length,2);const a=r.groups.find(g=>g.dimensions[3]==='CNY')!,b=r.groups.find(g=>g.dimensions[3]==='USD')!;
 assert.deepEqual(a.right,['100.1','12.12','1.01','115.25']);assert.deepEqual(b.right,[null,'8.08','4.04',null]);assert.equal(b.status,'缺总账');
});
test('out-of-period source is explicit; current residual reflects only included rows',()=>{
 const d=data();d.tx!.rows[0].cells['期间']='2026-08';const r=run(d);assert.equal(r.coverage.tx.excluded,1);
 assert.deepEqual(r.groups[0].right,['100.1','8.08','4.04','115.25']);assert.equal(r.groups[0].detailResidual,'-11.11');assert.equal(r.groups[0].status,'勾稽异常');
 assert.ok(r.issues.some(i=>i.kind==='范围外'&&i.source.row===7));
});
test('explicit mapping required when identity is disabled; original values remain',()=>{
 const d=data(),r=defaultRule();r.identity=false;assert.equal(run(d,r).globalBlocked,true);
 for(const side of ['gl','tx','balance'] as const)for(const field of ['主体','科目','期间'] as const)
  r.mapping.push({side,field,from:String(d[side]!.rows[0].cells[field]),to:field==='主体'?'虚构映射后甲':field==='科目'?'099':'2026-09'});
 const out=run(d,r);assert.equal(out.groups[0].status,'容差内一致');assert.equal(out.groups[0].dimensions[0],'虚构映射后甲');assert.equal(out.groups[0].gl[0].cells['主体'],'虚构根甲');
});
test('tolerance preserves actual hundredth-yuan difference and never rounds amounts',()=>{
 const d=data();d.gl!.rows[0].cells['期初借方']='100.11';d.gl!.rows[0].cells['期末借方']='115.26';
 let g=run(d).groups[0];assert.deepEqual(g.delta,['0.01','0','0','0.01']);assert.equal(g.status,'存在差异');
 const r=defaultRule();r.tolerance='0.01';g=run(d,r).groups[0];assert.deepEqual(g.delta,['0.01','0','0','0.01']);assert.equal(g.status,'容差内一致');
});
test('negative movement retains sign and source warning with independent residual',()=>{
 const d=data();d.tx!.rows[0].cells['本期借方']='-1.01';const r=run(d),g=r.groups[0];
 assert.equal(g.right[1],'7.07');assert.equal(g.detailResidual,'-13.13');assert.equal(g.status,'勾稽异常');
 assert.ok(r.issues.some(i=>i.kind==='复核'&&i.source.row===7&&i.source.cells['本期借方']==='-1.01'));
});
