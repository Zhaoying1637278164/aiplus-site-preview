import {test} from 'node:test';
import assert from 'node:assert/strict';
import * as close from '../tools/C01-月结工作台/src/engine';
import * as aging from '../tools/R04-应收账龄与逾期分析/src/example';
import {calculate} from '../tools/R04-应收账龄与逾期分析/src/engine';
test('monthly close demo has four completed tasks, retained fictitious evidence and no overdue tasks',()=>{
 const fn=(close as any).demoSample;assert.equal(typeof fn,'function');
 const w=fn(new Date('2026-10-07T00:00:00Z'));const p=w.periods[0];
 assert.equal(p.id,'2026-09');assert.equal(p.asOf,'2026-10-02');
 assert.equal(p.tasks.filter((t:any)=>t.status==='已完成').length,4);
 assert.equal(p.evidence.length,4);
 assert.ok(p.tasks.filter((t:any)=>t.status!=='已完成').every((t:any)=>close.due(p.id,t.offset)>=p.asOf));
});
test('aging demo independent expected balance 3780000 across 24 invoices, all overdue, same currency',()=>{
 const fn=(aging as any).demoExample;assert.equal(typeof fn,'function');
 const w=fn();const r=calculate(w);
 assert.equal(r.groups.length,1);assert.equal(r.groups[0].positive,'3780000');
 assert.equal(r.groups[0].overdue,'3780000');assert.equal(r.groups[0].residual,'0');
 assert.equal(r.tickets.length,26);assert.equal(r.groups[0].negative,'-20000');
 assert.equal(r.issues.filter(i=>i.severity==='blocking').length,0);
});
import * as pdfDemo from '../tools/D04-PDF财务表格整理/src/demo';
import {extract,check} from '../tools/D04-PDF财务表格整理/src/engine';
test('PDF demo arrives with both page regions and five extracted rows; missing value remains visible',async()=>{
 const w=await pdfDemo.demoWork();const r=extract(w);
 assert.equal(w.areas.length,2);assert.equal(r.rows.length,5);
 assert.equal(r.rows[0].cells[0].raw,'Sales');assert.equal(r.rows[0].cells[1].raw,'1,200.10');
 assert.equal(r.rows[2].cells[1].raw,'');assert.equal(check(w).ready,false);
});
import {demoExample as lossDemo} from '../tools/R05-坏账计提表/src/example';
import {calculate as lossCalc} from '../tools/R05-坏账计提表/src/engine';
import {defaultConfig as lossConfig} from '../tools/R05-坏账计提表/src/types';
import {approvedDemo} from '../tools/T02-资金日报/src/example';
import {analyze as cashAnalyze} from '../tools/T02-资金日报/src/engine';
import {demoExample as weekDemo} from '../tools/T03-13周资金预测/src/example';
import {analyze as weekAnalyze} from '../tools/T03-13周资金预测/src/engine';
import {demoExample as fxDemo} from '../tools/T06-外币敞口与汇兑测算/src/example';
import {calculate as fxCalc} from '../tools/T06-外币敞口与汇兑测算/src/engine';
test('loss demo independent 24 balances sum to 12m and loss target is 1.2m',()=>{
 const d=lossDemo(),r=lossCalc(d,lossConfig);assert.equal(d.receivables!.rows.length,24);
 assert.equal(r.summaries[0].positive,'12000000');assert.equal(r.summaries[0].target,'1200000.00');
});
test('cash demo keeps currencies separate and approves only fictitious accounts',()=>{
 const w=approvedDemo(),r=cashAnalyze(w);assert.ok(r.days.every(d=>d.approved));
 assert.equal(w.accounts.find(a=>a.currency==='USD')!.unit,'元');
 assert.equal(r.days.find(d=>d.account==='A')!.closing,'1080000');
});
test('13 week demo independent first two CNY closing balances 1050000 and 950000',()=>{
 const r=weekAnalyze(weekDemo());const weeks=r.weeks.filter(w=>w.level==='主体'&&w.currency==='CNY');
 assert.equal(weeks.length,13);assert.equal(weeks[0].closing,'1050000');assert.equal(weeks[1].closing,'950000');
});
test('FX demo USD 600000 net at 7.1 equals CNY 4260000, gain 60000',()=>{
 const r=fxCalc(fxDemo());assert.equal(r.exposures[0].net,'600000');assert.equal(r.exposures[0].endNet,'4260000.00');assert.equal(r.exposures[0].gain,'60000.00');
});
import {encode as cashEncode,decode as cashDecode} from '../tools/T02-资金日报/src/work';
import {example as bridgeDemo} from '../tools/M02-量价结构差异分析/src/example';
import {encode as bridgeEncode,decode as bridgeDecode} from '../tools/M02-量价结构差异分析/src/plan';
import {demoExamples} from '../tools/C05-凭证编制与核对/src/example';
import {calculate as voucherCalc,defaultMapping as voucherMapping,defaults as voucherDefaults} from '../tools/C05-凭证编制与核对/src/engine';
test('cash sample passes encode guard and previous public patch restores independent CNY balance',()=>{
 const p=JSON.parse(cashEncode(approvedDemo(),true));p.app_version='0.1.0';const w=cashDecode(JSON.stringify(p)).work;
 assert.equal(cashAnalyze(w).days.find(d=>d.account==='A')!.closing,'1080000');
 p.app_version='9.0.0';assert.throws(()=>cashDecode(JSON.stringify(p)));
});
test('bridge previous public patch restores, incompatible prior rule and future versions still reject',()=>{
 const p=JSON.parse(bridgeEncode(bridgeDemo,true));p.app_version='0.1.2';assert.deepEqual(bridgeDecode(JSON.stringify(p)),bridgeDemo);
 p.app_version='9.0.0';assert.throws(()=>bridgeDecode(JSON.stringify(p)));
});
test('positive voucher demo keeps red gate closed and independently balances 318 and 53000',()=>{
 const r=voucherCalc(demoExamples(),voucherMapping(),voucherDefaults);assert.equal(voucherDefaults.allowRed,false);
 assert.deepEqual(r.groups.map(g=>[g.debit,g.credit,g.difference]),[['318','318','0'],['53000','53000','0']]);assert.ok(r.groups.every(g=>g.issues.length===0));
});
