import test from 'node:test';
import assert from 'node:assert/strict';
import {compare,encode,decode,type Settings,type Mapping} from '../tools/E02-工资变动核对/src/engine';
import type {Table,Cell} from '../packages/core/types';
// Root literals and hand arithmetic. No author examples, exported results, or generated oracles.
const columns=['员工稳定ID','姓名','期间','工资项目','金额','部门','币种','单位'];
const maps=():[Mapping,Mapping]=>[Object.fromEntries(columns.map(c=>[c,c])),Object.fromEntries(columns.map(c=>[c,c]))];
const settings=():Settings=>({previous:'2026-02',current:'2026-03',currency:'CNY',unit:'元',threshold:'10',tolerance:'0.01',policySource:'完全虚构的已批准工资核对依据',effective:'2026-01',policyVersion:'ROOT-CHECK-v1',projects:{}});
const table=(side:0|1,items:Cell[][]):Table=>({file:side?'虚构本期.csv':'虚构上期.csv',sheet:'工资',headers:columns,rows:items.map((v,i)=>({file:side?'虚构本期.csv':'虚构上期.csv',sheet:'工资',row:i+2,cells:Object.fromEntries(columns.map((c,j)=>[c,v[j]]))}))});
const row=(side:0|1,id:string,amount:Cell,project='工资',other:Record<string,Cell>={}):Cell[]=>{const values:Record<string,Cell>={员工稳定ID:id,姓名:'虚构同名',期间:side?'2026-03':'2026-02',工资项目:project,金额:amount,部门:'虚构研发',币种:'CNY',单位:'元',...other};return columns.map(c=>values[c]);};
const run=(a:Cell[][],b:Cell[][],s=settings())=>compare([table(0,a),table(1,b)],maps(),s);

test('root:250→265=15，新增70退出-60同人5，稳定ID区分同名',()=>{
 const r=run([row(0,'0001','100'),row(0,'0001','10','奖金'),row(0,'0002','80'),row(0,'0003','60')],[row(1,'0001','110'),row(1,'0001','5','奖金'),row(1,'0002','80'),row(1,'0004','70')]);
 assert.equal(r.complete,true);assert.equal(r.rows.length,5);assert.equal(r.personnel.length,4);
 assert.deepEqual(r.totals,{previous:'250.00',current:'265.00',delta:'15.00',residual:'0.00',factors:{新增:'70.00',退出:'-60.00',同人薪项:'5.00'},raw:['250.00','265.00'],excluded:['0.00','0.00'],unknown:[0,0]});
 assert.equal(r.rows.filter(v=>v.important).length,3);assert.equal(r.rows.find(v=>v.id==='0002')!.delta,'0.00');
 assert.deepEqual(r.rows.find(v=>v.id==='0001'&&v.project==='奖金')!.sources.map(v=>[v.file,v.sheet,v.row]),[['虚构上期.csv','工资',3],['虚构本期.csv','工资',3]]);
 assert.match(r.personnel.find(v=>v.id==='0004')!.status,/不等于入职/);assert.match(r.personnel.find(v=>v.id==='0003')!.status,/不等于离职/);
});
test('root:零与负数不遗漏，24位金额相差一分且阈值含边界',()=>{
 const r=run([row(0,'0001','0')],[row(1,'0001','-0.03')]);assert.equal(r.rows[0].previous,'0.00');assert.equal(r.rows[0].delta,'-0.03');assert.equal(r.totals.residual,'0.00');
 const s=settings();s.threshold='0.01';const large=run([row(0,'0001','1234567890123456789012.98')],[row(1,'0001','1234567890123456789012.99')],s);
 assert.equal(large.totals.previous,'1234567890123456789012.98');assert.equal(large.totals.current,'1234567890123456789012.99');assert.equal(large.totals.delta,'0.01');assert.equal(large.rows[0].important,true);assert.equal(large.totals.residual,'0.00');
});
test('root:缺失金额阻塞双边键，不能把缺失当零或员工退出',()=>{
 const r=run([row(0,'A','100'),row(0,'B','5'),row(0,'C','0')],[row(1,'A',null),row(1,'B','7'),row(1,'C','0')]);
 assert.equal(r.complete,false);assert.deepEqual(r.rows.map(v=>v.id),['B','C']);assert.equal(r.totals.previous,'5.00');assert.equal(r.totals.current,'7.00');assert.equal(r.totals.delta,'2.00');assert.deepEqual(r.totals.excluded,['100.00','0.00']);assert.deepEqual(r.totals.unknown,[0,1]);assert.equal(r.personnel.find(v=>v.id==='A')!.status,'两期均出现');assert.equal(r.issues[0].source.row,2);
});
test('root:重复整组双边排除，保留两个原始行',()=>{
 const r=run([row(0,'A','100'),row(0,'A','40'),row(0,'B','5')],[row(1,'A','110'),row(1,'B','7')]);
 assert.deepEqual(r.rows.map(v=>v.id),['B']);assert.deepEqual(r.totals.excluded,['140.00','110.00']);assert.equal(r.totals.delta,'2.00');assert.deepEqual(r.issues.map(v=>v.source.row),[2,3]);assert.equal(r.totals.residual,'0.00');
});
test('root:错期间币种单位与公式不进可比金额，源定位原金额明确另列',()=>{
 const r=run([row(0,'P','10'),row(0,'F','20'),row(0,'U','30'),row(0,'X','40'),row(0,'OK','5')],[row(1,'P','11','工资',{期间:'2026-04'}),row(1,'F','21','工资',{币种:'USD'}),row(1,'U','31','工资',{单位:'万元'}),row(1,'X',{formula:'1+1',cached:2}),row(1,'OK','7')]);
 assert.deepEqual(r.rows.map(v=>v.id),['OK']);assert.equal(r.totals.previous,'5.00');assert.equal(r.totals.current,'7.00');assert.equal(r.totals.delta,'2.00');assert.equal(r.totals.residual,'0.00');assert.equal(r.issues.length,4);assert.deepEqual(r.totals.unknown,[0,1]);assert.deepEqual(r.totals.excluded,['100.00','63.00']);
});
test('root:薪项映射后的重复阻塞，列映射碰撞不能覆盖字段',()=>{
 const s=settings();s.projects={旧工资:'工资',基本薪资:'工资'};
 const r=run([row(0,'A','100','旧工资'),row(0,'A','40','基本薪资'),row(0,'B','5')],[row(1,'A','110'),row(1,'B','7')],s);assert.deepEqual(r.rows.map(v=>v.id),['B']);assert.equal(r.issues.length,2);
 const m=maps();m[0]['金额']='姓名';assert.throws(()=>compare([table(0,[row(0,'A','1')]),table(1,[row(1,'A','2')])],m,settings()),/字段映射碰撞/);
});
test('root:含数据恢复保留来源复核并同结果，无数据方案不含工资和复核',()=>{
 const t:[Table,Table]=[table(0,[row(0,'0007','100')]),table(1,[row(1,'0007','101')])];t[0].rows[0].row=19;t[1].rows[0].row=27;
 const restored=decode(encode(settings(),maps(),t,true,{虚构复核:'差额1元已核对'}));const r=compare(restored.tables,restored.maps,restored.settings);assert.equal(r.totals.delta,'1.00');assert.deepEqual(r.rows[0].sources.map(v=>v.row),[19,27]);assert.deepEqual(restored.reviews,{虚构复核:'差额1元已核对'});
 const no=decode(encode(settings(),maps(),t,false,{虚构复核:'不应携带'}));assert.equal(no.contains_data,false);assert.deepEqual(no.tables,[null,null]);assert.deepEqual(no.reviews,{});assert.equal(no.settings.policyVersion,'ROOT-CHECK-v1');
});
test('root:不兼容版本与无效生效期、期间、金额精度必须阻塞',()=>{
 const t:[Table,Table]=[table(0,[row(0,'0007','100')]),table(1,[row(1,'0007','101')])];const p=JSON.parse(encode(settings(),maps(),t,true));p.app_version='0.1.0';assert.throws(()=>decode(JSON.stringify(p)),/版本不兼容/);
 for(const edit of [{previous:'2026-03'},{effective:'2026-03'},{threshold:'-1'},{policySource:''}])assert.throws(()=>compare(t,maps(),{...settings(),...edit}));
 const r=run([row(0,'A','1.001')],[row(1,'A','1.00')]);assert.equal(r.complete,false);assert.equal(r.rows.length,0);assert.deepEqual(r.totals.unknown,[1,0]);
});
