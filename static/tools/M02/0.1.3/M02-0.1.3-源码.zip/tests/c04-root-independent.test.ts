import {test} from 'node:test';
import assert from 'node:assert/strict';
import {check,fields,mappingDefault,defaults} from '../tools/C04-科目余额核查/src/engine';
import type {Table,Cell} from '../packages/core/types';

// Independently specified amounts: 100.10 + 20.20 - 5.05 = 115.25.
// Credit counterpart: -100.10 + 7.07 - 22.22 = -115.25.
function table():Table {
  return {file:'虚构根核查.xlsx',sheet:'余额',headers:[...fields],rows:[
    {file:'虚构根核查.xlsx',sheet:'余额',row:7,cells:{'主体':'虚构甲','期间':'2026-09','币种':'CNY','单位':'元','科目编码':'001','科目名称':'虚构资产','期初借方':'100.10','期初贷方':'0','发生借方':'20.20','发生贷方':'5.05','期末借方':'115.25','期末贷方':'0','正常方向':'借'}},
    {file:'虚构根核查.xlsx',sheet:'余额',row:11,cells:{'主体':'虚构甲','期间':'2026-09','币种':'CNY','单位':'元','科目编码':'002','科目名称':'虚构负债','期初借方':'0','期初贷方':'100.10','发生借方':'7.07','发生贷方':'22.22','期末借方':'0','期末贷方':'115.25','正常方向':'贷'}}]};
}
const run=(t=table())=>check(t,mappingDefault,{...defaults,complete:true,directions:{}});
test('independent decimal amounts, gross sums, signed net and original rows',()=>{
  const r=run();assert.deepEqual(r.groups[0].sums,['100.1','100.1','27.27','27.27','115.25','115.25']);
  assert.deepEqual(r.groups[0].diffs,['0','0','0']);
  assert.deepEqual(r.lines.map(x=>[x.opening,x.movement,x.closing,x.difference,x.source.row]),[['100.1','15.15','115.25','0',7],['-100.1','-15.15','-115.25','0',11]]);
  assert.equal(r.lines[0].account,'001');
});
test('opposite ten-yuan errors remain visible despite balanced ledger',()=>{
  const t=table();t.rows[0].cells['期末借方']='125.25';t.rows[1].cells['期末贷方']='125.25';const r=run(t);
  assert.equal(r.groups[0].diffs[2],'0');assert.deepEqual(r.lines.map(x=>x.difference),['10','-10']);
  assert.ok(r.lines.every(x=>x.reconcile==='勾稽差异'));
});
for(const v of [null,'', '-1', {formula:'100+15.25',cached:115.25}] as Cell[])
  test('missing/negative/formula blocks aggregate: '+JSON.stringify(v),()=>{
    const t=table();t.rows[0].cells['期末借方']=v;const r=run(t);assert.equal(r.lines[0].closing,null);
    assert.ok(r.groups[0].status.every(x=>x.startsWith('未执行')));assert.equal(r.groups[0].valid,1);
  });
test('duplicate original account rows all blocked',()=>{
  const t=table();t.rows.push({...structuredClone(t.rows[0]),row:19});const r=run(t);
  assert.equal(r.lines[0].closing,null);assert.equal(r.lines[2].closing,null);assert.equal(r.groups[0].valid,1);
});
test('next month source is traceable; missing month never crosses gap',()=>{
  const t=table();const x=structuredClone(t.rows[0]);x.row=23;x.cells['期间']='2026-10';x.cells['期初借方']='115.25';x.cells['发生借方']='0';x.cells['发生贷方']='0';t.rows.push(x);
  let r=run(t);assert.equal(r.lines[2].continuityDifference,'0');assert.equal(r.lines[2].priorSource,'虚构根核查.xlsx / 余额 / 第7行');
  x.cells['期间']='2026-11';r=run(t);assert.equal(r.lines[2].continuityDifference,null);assert.equal(r.lines[2].continuity,'未执行：期间不连续');
});
test('currency and unit groups remain separate; unknown group blocks all conclusions',()=>{
  const t=table();t.rows[1].cells['币种']='USD';t.rows[1].cells['单位']='万元';let r=run(t);assert.equal(r.groups.length,2);assert.deepEqual(r.groups.map(x=>x.diffs[2]),['115.25','-115.25']);
  t.rows.push({...structuredClone(t.rows[0]),row:29,cells:{...t.rows[0].cells,'主体':null}});r=run(t);assert.equal(r.unknownGroup,true);assert.ok(r.groups.every(g=>g.status.every(x=>x.startsWith('未执行'))));
});
test('zero is valid; missing direction is unexecuted; undeclared ledger does not conclude totals',()=>{
  const t=table();for(const row of t.rows){for(const f of fields.slice(6,12))row.cells[f]='0';row.cells['正常方向']='';}
  const r=check(t,mappingDefault,{...defaults,directions:{}});assert.ok(r.lines.every(x=>x.difference==='0'&&x.direction.startsWith('未执行')));assert.ok(r.groups[0].status.every(x=>x.startsWith('未执行')));
});
