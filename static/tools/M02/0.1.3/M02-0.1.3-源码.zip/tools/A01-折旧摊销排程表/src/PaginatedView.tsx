import React,{useState,useRef,useLayoutEffect} from 'react';
/** Only selects the displayed rows. Calculation, evidence and exports always retain the full result. */
export function PaginatedView({rows,cols,labels,title='复核明细'}:{rows:object[];cols?:string[];labels:Record<string,string>;title?:string}){
 const tableRef=useRef<HTMLDivElement>(null);
 const [state,setState]=useState({rows,page:1,size:25});
 const size=state.size,total=rows.length,pages=Math.max(1,Math.ceil(total/size));
 // Dataset identity changes on a filter, import, restore or recalculation. Derive
 // the first page immediately, so no render contains an out-of-range old page.
 const page=state.rows===rows?Math.min(state.page,pages):1;
 const start=total?(page-1)*size:0,end=Math.min(start+size,total),headers=cols||Object.keys(rows[0]||{});
 useLayoutEffect(()=>{if(tableRef.current)tableRef.current.scrollTop=0},[rows,page,size]);
 const go=(next:number)=>setState({rows,size,page:Math.max(1,Math.min(next,pages))});
 const controls=<div className="a01-pagination" aria-label={`${title}分页`}>
  <div className="a01-page-summary" role="status">共 {total} 行 · 当前第 {total?start+1:0}–{end} 行 · 第 {page}/{pages} 页</div>
  <div className="a01-page-buttons"><label>每页<select aria-label={`${title}每页行数`} value={size} onChange={e=>setState({rows,page:1,size:Number(e.target.value)})}><option value={25}>25行</option><option value={50}>50行</option></select></label>
  <button aria-label={`${title}首页`} disabled={page===1} onClick={()=>go(1)}>首页</button><button aria-label={`${title}上一页`} disabled={page===1} onClick={()=>go(page-1)}>上一页</button><button aria-label={`${title}下一页`} disabled={page===pages} onClick={()=>go(page+1)}>下一页</button><button aria-label={`${title}末页`} disabled={page===pages} onClick={()=>go(pages)}>末页</button></div>
 </div>;
 return <section className="a01-result" aria-label={title}>{controls}{total>0&&<p className="a01-table-help">表内上下滚动复核本页，左右滚动查看全部字段与来源；完整底稿始终包含全部行。</p>}<div ref={tableRef} className="a01-table"><table><thead><tr>{headers.map(k=><th key={k}>{labels[k]||k}</th>)}</tr></thead><tbody>{rows.slice(start,end).map((r,i)=><tr key={start+i}>{headers.map(k=><td key={k}>{String((r as any)[k]??'')}</td>)}</tr>)}</tbody></table>{!total&&<p>暂无记录</p>}</div>{total>size&&controls}</section>;
}
