import {schemas,type Data,type Kind} from './engine';import type {Table} from '../../../packages/core/types';
export function table(kind:Kind,rows:unknown[][],file='虚构资料.xlsx'):Table {return {file,sheet:kind,headers:[...schemas[kind]],rows:rows.map((r,i)=>({file,sheet:kind,row:i+2,cells:Object.fromEntries(schemas[kind].map((h,j)=>[h,r[j]===undefined||r[j]===''?null:String(r[j])]))}))}}
export const example:Data={assets:table('assets',[
 ['FA01','虚构生产设备','虚构星河公司','固定资产','生产设备','CNY','元','2025-12-15','2026-01','12000','0','0','1200','12','直线法','','','董事会政策FA-01'],
 ['IA01','虚构软件许可','虚构星河公司','无形资产','有限寿命','CNY','元','2026-01-01','2026-01','6000','0','0','0','12','直线法','','','合同许可12月'],
 ['FA02','虚构运输设备','虚构星河公司','固定资产','运输设备','CNY','元','2025-12-20','2026-01','36000','0','0','0','36','年数总和法','','','收益前高后低/虚构批准'],
 ['IA02','虚构不确定寿命商标','虚构星河公司','无形资产','不确定寿命','CNY','元','2026-01-01','2026-01','5000','0','0','0','12','不折摊','','','不确定寿命判断/逐期复核']
]),events:table('events',[['EV01','FA01','2026-07','变更','','12','1200','直线法','虚构财务负责人','收益方式与寿命复核批准']]),usage:null,ledger:table('ledger',[['FA01','2026-01','11100'],['IA01','2026-01','5500']])};
