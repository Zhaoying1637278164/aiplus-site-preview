from pathlib import Path
import subprocess,json,hashlib
out=Path('progress/evidence/A01/0.1.1/candidate/commands');out.mkdir(parents=True,exist_ok=True)
folder='tools/A01-折旧摊销排程表'
commands=[['node','--import','tsx','--test',folder+'/tests/engine.test.ts'],['./node_modules/.bin/tsc','--noEmit','-p',folder+'/tsconfig.json'],['node','--import','tsx',folder+'/scripts/build-candidate.ts'],['node','--import','tsx',folder+'/tests/browser.ts'],['node','--import','tsx',folder+'/tests/native.ts'],['node','--import','tsx',folder+'/tests/pagination-browser.ts'],['python3',folder+'/scripts/rebuild.py']]
results=[]
for i,cmd in enumerate(commands):
 log=out/f'{i+1}.log'
 with log.open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'exit_code':p.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 print(json.dumps(results[-1],ensure_ascii=False),flush=True)
 if p.returncode:break
(out/'result.json').write_text(json.dumps({'passed':len(results)==len(commands) and all(x['exit_code']==0 for x in results),'commands':results},ensure_ascii=False,indent=2))
raise SystemExit(0 if len(results)==len(commands) and all(x['exit_code']==0 for x in results) else 1)
