"""A01 isolated candidate source proof. No shared catalog/site/release writes."""
from pathlib import Path
import json, shutil, tempfile, hashlib, subprocess, zipfile
ROOT=Path.cwd();FOLDER=Path('tools/A01-折旧摊销排程表');OUT=ROOT/'progress/evidence/A01/0.1.1/candidate/source-rebuild';OUT.mkdir(parents=True,exist_ok=True)
WORK=Path(tempfile.mkdtemp(prefix='A01-source-',dir='/private/tmp'))
files=['package.json','package-lock.json','tsconfig.json','references/saxes-5.0.1-LICENSE']
for prefix in ['packages/core','packages/ui',str(FOLDER)]:
 files += [str(p) for p in Path(prefix).rglob('*') if p.is_file() and not any(x in p.parts for x in ['candidate','node_modules'])]
files=sorted(set(files));manifest={}
for f in files:
 src=ROOT/f;dst=WORK/f;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);manifest[f]=hashlib.sha256(src.read_bytes()).hexdigest()
with zipfile.ZipFile(OUT/'A01-candidate-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(WORK/f,f)
# Execute from an actual extraction of the candidate source ZIP, not the staging copy.
EXTRACT=Path(tempfile.mkdtemp(prefix='A01-unzipped-source-',dir='/private/tmp'))
with zipfile.ZipFile(OUT/'A01-candidate-source.zip') as z:
 assert sorted(z.namelist())==files
 for name in z.namelist():
  assert not Path(name).is_absolute() and '..' not in Path(name).parts
 z.extractall(EXTRACT)
for name,expected in manifest.items():
 assert hashlib.sha256((EXTRACT/name).read_bytes()).hexdigest()==expected,name
WORK=EXTRACT
commands=[['npm','ci','--offline','--ignore-scripts'],['node','--import','tsx','--test',str(FOLDER/'tests/engine.test.ts')],['./node_modules/.bin/tsc','--noEmit','-p',str(FOLDER/'tsconfig.json')],['node','--import','tsx',str(FOLDER/'scripts/build-candidate.ts')]]
results=[]
for i,cmd in enumerate(commands):
 with (OUT/f'{i+1}.log').open('w') as log:p=subprocess.run(cmd,cwd=WORK,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'exit_code':p.returncode})
 if p.returncode:break
compared={}
if len(results)==4 and all(r['exit_code']==0 for r in results):
 for original in sorted((ROOT/FOLDER/'candidate/0.1.1').iterdir()):
  if not original.is_file():continue
  rebuilt=WORK/FOLDER/'candidate/0.1.1'/original.name
  compared[original.name]={'original':hashlib.sha256(original.read_bytes()).hexdigest(),'rebuilt':hashlib.sha256(rebuilt.read_bytes()).hexdigest() if rebuilt.exists() else None}
report={'workspace':str(WORK),'commands':results,'compared':compared,'sourceFiles':manifest,'sourceZipSHA':hashlib.sha256((OUT/'A01-candidate-source.zip').read_bytes()).hexdigest(),'source_zip_extracted_and_member_SHA_checked':True,'scope':'候选源码ZIP实际解压后隔离安装/类型/测试/重建，非正式源码ZIP验收'}
report['passed']=len(results)==4 and all(r['exit_code']==0 for r in results) and bool(compared) and all(v['original']==v['rebuilt'] for v in compared.values())
(OUT/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'passed':report['passed'],'commands':results,'mismatches':[f for f,v in compared.items() if v['original']!=v['rebuilt']]},ensure_ascii=False));raise SystemExit(0 if report['passed'] else 1)
