import pathlib,zipfile,hashlib,json,shutil
p=pathlib.Path('progress/evidence/A04/0.1.1');zpath=p/'A04-0.1.1-候选离线包.zip';dest=p/'extracted/A04';dest.mkdir(parents=True,exist_ok=True)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted((p/'candidate').iterdir()):z.write(f,'A04/'+f.name)
with zipfile.ZipFile(zpath) as z:z.extractall(p/'extracted')
files={f.name:sha(f) for f in (p/'candidate').iterdir()};assert all(sha(dest/k)==v for k,v in files.items())
(p/'zip-readback.json').write_text(json.dumps({'zip_sha256':sha(zpath),'extracted':str(dest),'members':files,'all_equal':True},ensure_ascii=False,indent=2));print('Candidate ZIP/extraction exact',len(files),'members')
