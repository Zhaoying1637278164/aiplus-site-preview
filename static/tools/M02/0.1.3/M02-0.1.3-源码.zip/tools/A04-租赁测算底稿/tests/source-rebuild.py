import pathlib,tempfile,shutil,subprocess,json,hashlib,zipfile
root=pathlib.Path.cwd();e=root/'progress/evidence/A04/0.1.1';work=pathlib.Path(tempfile.mkdtemp(prefix='a04-source-',dir='/private/tmp'));source=work/'source';source.mkdir()
for f in ['package.json','package-lock.json','tsconfig.json']:
 shutil.copy2(root/f,source/f)
for d in ['packages','tools/A04-租赁测算底稿']:
 shutil.copytree(root/d,source/d)
(source/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',source/'references/saxes-5.0.1-LICENSE')
(source/'tests').mkdir();shutil.copy2(root/'tests/io.test.ts',source/'tests/io.test.ts')
(source/'progress/evidence/A04').mkdir(parents=True);shutil.copy2(root/'progress/evidence/A04/independent-expected.json',source/'progress/evidence/A04/independent-expected.json')
commands=[]
for cmd in [['npm','ci','--offline','--ignore-scripts'],['npm','test'],['npm','run','typecheck'],['node','--import','tsx','tools/A04-租赁测算底稿/tests/build-candidate.ts']]:
 p=subprocess.run(cmd,cwd=source,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);name='source-'+str(len(commands)+1)+'.txt';(e/name).write_text(p.stdout);commands.append(dict(command=cmd,exit=p.returncode,log=name))
 if p.returncode: raise RuntimeError(f'Failed {cmd}; see {name}')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=e/'candidate';rebuilt=source/'progress/evidence/A04/0.1.1/candidate';compare=[]
for p in sorted(original.iterdir()):
 if p.name in ['SHA256.json']:continue
 other=rebuilt/p.name;match=p.read_bytes()==other.read_bytes();compare.append(dict(file=p.name,original=sha(p),rebuilt=sha(other),equal=match))
 if not match:raise RuntimeError('Rebuild mismatch '+p.name)
# Candidate archive made before node_modules and build evidence. Includes locked source, shared interfaces/tests and independent expected.
archive=e/'A04-0.1.1-候选源码.zip';members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(source.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(source)
  if 'node_modules' in rel.parts or ('progress' in rel.parts and p.name!='independent-expected.json'):continue
  z.write(p,str(rel));members.append(dict(file=str(rel),sha256=sha(p)))
(e/'source-rebuild.json').write_text(json.dumps(dict(status='passed',workspace=str(source),commands=commands,compared=compare,archive=str(archive.relative_to(root)),archive_sha256=sha(archive),members=members,limitation='候选源码隔离重建；正式源码包由总控制作核验'),ensure_ascii=False,indent=2));print('Isolated source',len(compare),'candidate assets exact /',len(members),'source files / ZIP',sha(archive))
