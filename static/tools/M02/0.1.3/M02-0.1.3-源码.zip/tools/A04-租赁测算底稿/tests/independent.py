from decimal import Decimal as Q,getcontext
from datetime import date
import json,pathlib
getcontext().prec=50
cases=[('L001','2025-01-01','0.10',365,1,'effective',[('2026-01-01','1100'),('2027-01-01','1210')]),('L002','2025-01-01','0.10',365,1,'effective',[('2026-01-01','1100')]),('L003','2025-01-01','0.06',360,12,'nominal',[('2025-01-31','1005'),('2025-03-02','1010.025')])]
out={}
for cid,start,rate,basis,freq,mode,flows in cases:
 def g(a,b):
  time=Q((date.fromisoformat(b)-date.fromisoformat(a)).days)/Q(basis)
  return (1+Q(rate))**time if mode=='effective' else (1+Q(rate)/freq)**(time*freq)
 pvs=[Q(v)/g(start,d) for d,v in flows];bal=sum(pvs);prev=start;rows=[]
 for d,v in flows:
  interest=bal*(g(prev,d)-1);opening=bal;bal+=interest-Q(v);rows.append(dict(opening=str(opening),interest=str(interest),payment=v,closing=str(bal)));prev=d
 out[cid]=dict(pvs=list(map(str,pvs)),liability=str(sum(pvs)),rows=rows)
out['change']={'oldBalance':'1100','newPV':'1210','delta':'110','newInterest':'121'}
pathlib.Path('progress/evidence/A04/independent-expected.json').write_text(json.dumps(out,indent=2))
print('Independent Python decimal50: 3 contracts / 6 PV and balance rows + change expected written')
