import {workbookBytes} from '../../../packages/core/io';import {VERSION,RULE_VERSION,fields,labels,type Work,type Result} from './types';
export function csv(headers:string[],rows:unknown[][]){const esc=(v:unknown)=>{let s=v===null||v===undefined?'':String(v);if(/^\s*[=+@-]/.test(s)&&!/^[-+]?\d+(\.\d+)?$/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};return '\uFEFF'+[headers,...rows].map(r=>r.map(esc).join(',')).join('\r\n')}
export function sourceCSV(w:Work){return csv(fields.map(f=>labels[f]),w.rows.map(r=>fields.map(f=>r[f])))}
export const detailKeys=['id','dept','job','status','month','capacity','actual','planned','vacant','personDays','fte','days','monthDays','segments','salaryRaw','salary','allowanceRaw','allowance','bonusRaw','bonus','benefitRaw','benefit','total','rounding','source','basis'] as const;
export const detailLabels=['岗位组ID','部门','岗位','状态','期间','月末编制','月末实岗','月末计划到岗','月末未填编制','人数日','折算人数','覆盖日','自然月日数','计薪分段','未舍入薪资','薪资','未舍入津贴','津贴','未舍入奖金','奖金','未舍入福利','福利','人工总额','组件舍入差合计','原始来源','假设依据'];
export function resultCSV(r:Result){return csv(detailLabels,r.details.map(d=>detailKeys.map(k=>d[k])))}
export function origins(w:Work){const rows=[...(w.original?.rows||[])];const keys=new Set(rows.map(s=>JSON.stringify([s.file,s.sheet,s.row])));for(const r of w.rows){const key=JSON.stringify([r.source.file,r.source.sheet,r.source.row]);if(!keys.has(key)){rows.push(r.source);keys.add(key)}}return rows}
export function sheets(w:Work,r:Result){const sk=['dept','month','capacity','actual','planned','vacant','personDays','fte','salary','allowance','bonus','benefit','total'] as const;return [
{name:'范围与版本',headers:['项目','值'],rows:[['工具','B04 编制与人工预算'],['应用',VERSION],['规则',RULE_VERSION],['完整性',r.complete?'无阻塞':'仅部分诊断，不能确认完整预算'],...Object.entries(w.scope),['金额舍入','每组件HALF_UP后相加'],['说明','福利率与计薪假设均为用户输入，非税法/社保实算']]},
{name:'岗位计划',headers:[...fields.map(f=>labels[f]),'原文件','原页签','原行'],rows:w.rows.map(x=>[...fields.map(f=>x[f]),x.source.file,x.source.sheet,x.source.row])},
{name:'月度人数',headers:['部门','期间','月末编制','月末实岗','月末计划到岗','月末未填编制','人数日','折算人数'],rows:r.summaries.map(s=>sk.slice(0,8).map(k=>s[k]))},
{name:'人工预算汇总',headers:['部门','期间','薪资','津贴','月奖金','福利附加','人工总额'],rows:r.summaries.map(s=>[s.dept,s.month,s.salary,s.allowance,s.bonus,s.benefit,s.total])},
{name:'岗位月度明细',headers:detailLabels,rows:r.details.map(d=>detailKeys.map(k=>d[k]))},
{name:'异常清单',headers:['岗位组ID','来源','级别','原因'],rows:r.issues.map(i=>[i.id,i.source,i.level,i.message])},
{name:'勾稽',headers:['检查','差额','结果'],rows:r.checks.map(c=>[c.name,c.difference,c.pass?'通过':'失败'])},
{name:'原始资料',headers:['文件','页签','行','单元格JSON'],rows:origins(w).map(s=>[s.file,s.sheet,s.row,JSON.stringify(s.cells)])},
{name:'修改记录',headers:['时间','操作','岗位组','修改前','修改后'],rows:w.logs.map(l=>[l.time,l.action,l.id,l.before,l.after])},
{name:'复核记录',headers:['经办','复核意见','时间','含阻塞'],rows:w.review?[[w.review.owner,w.review.note,w.review.time,r.complete?'否':'是，复核失效']]:[]}
]}
export async function resultWorkbook(w:Work,r:Result){const b=await workbookBytes(sheets(w,r));if(b.length>10*1024*1024)throw Error('导出超过10MB');return b}
