import type {SourceRow,Table} from '../../../packages/core/types';
export const VERSION='0.1.2',RULE_VERSION='B04-2026-10-04.1';
export const MAX={rows:1000,months:36,logs:4000};
export const fields=['id','dept','job','status','capacity','count','start','end','hire','leave','salary','allowance','bonus','rate','raiseDate','raiseSalary','currency','unit','basis'] as const;
export type Field=typeof fields[number];
export const labels:Record<Field,string>={id:'岗位组ID',dept:'部门',job:'岗位',status:'岗位状态',capacity:'编制人数',count:'计划人数',start:'岗位开始日',end:'岗位结束日',hire:'到岗日期',leave:'离岗日期',salary:'月薪',allowance:'月津贴',bonus:'月奖金',rate:'福利附加率百分数',raiseDate:'调薪日期',raiseSalary:'新月薪',currency:'币种',unit:'金额单位',basis:'假设依据'};
export type Row=Record<Field,string>&{source:SourceRow};
export interface Scope {start:string;end:string;currency:string;unit:string;method:'自然日折算'|'整月预算';precision:number;tolerance:string;basis:string;confirmed:boolean}
export interface Log {time:string;action:string;id:string;before:string;after:string}
export interface Work {scope:Scope;rows:Row[];original:Table|null;logs:Log[];review:{owner:string;note:string;time:string}|null}
export interface Issue {id:string;source:string;level:'阻塞'|'提示';message:string}
export interface Detail {id:string;dept:string;job:string;status:string;month:string;capacity:number;actual:number;planned:number;vacant:number;personDays:number;fte:string;days:number;monthDays:number;segments:string;salaryRaw:string;salary:string;allowanceRaw:string;allowance:string;bonusRaw:string;bonus:string;benefitRaw:string;benefit:string;total:string;rounding:string;source:string;basis:string}
export interface Summary {dept:string;month:string;capacity:number;actual:number;planned:number;vacant:number;personDays:number;fte:string;salary:string;allowance:string;bonus:string;benefit:string;total:string}
export interface Result {details:Detail[];summaries:Summary[];issues:Issue[];complete:boolean;checks:{name:string;difference:string;pass:boolean}[]}
