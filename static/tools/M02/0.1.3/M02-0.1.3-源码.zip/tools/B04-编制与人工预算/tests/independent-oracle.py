# -*- coding: utf-8 -*-
"""Independent B04 QA: Python Decimal daily enumeration, no production modules.
Input is independently generated fixture/operation ledger, never exported result cells.
"""
import json,sys,calendar,datetime,decimal
from decimal import Decimal as Q
decimal.getcontext().prec=50
F='id dept job status capacity count start end hire leave salary allowance bonus rate raiseDate raiseSalary currency unit basis'.split()
H=['岗位组ID','部门','岗位','岗位状态','编制人数','计划人数','岗位开始日','岗位结束日','到岗日期','离岗日期','月薪','月津贴','月奖金','福利附加率百分数','调薪日期','新月薪','币种','金额单位','假设依据']
DK='id dept job status month capacity actual planned vacant personDays fte days monthDays segments salaryRaw salary allowanceRaw allowance bonusRaw bonus benefitRaw benefit total rounding source basis'.split()
DH=['岗位组ID','部门','岗位','状态','期间','月末编制','月末实岗','月末计划到岗','月末未填编制','人数日','折算人数','覆盖日','自然月日数','计薪分段','未舍入薪资','薪资','未舍入津贴','津贴','未舍入奖金','奖金','未舍入福利','福利','人工总额','组件舍入差合计','原始来源','假设依据']
def plain(v):
 s=format(v,'f');return s.rstrip('0').rstrip('.') if '.' in s else s

def fixture():
 rows=[]
 for i in range(1,605):
  p=dict(zip(F,[f'HC{i:04}','虚构部门'+str((i-1)%40+1).zfill(2),'虚构岗位'+str(i),'实岗','2','1','2027-01-01','2027-12-31','2026-12-01','','3100','100','50','25','','','CNY','元','全虚构604岗位预算，非政策参数']))
  if i==601:p.update(status='空岗',hire='2027-01-16',leave='2027-03-15',salary='86800',allowance='868',bonus='868',raiseDate='2027-02-15',raiseSalary='173600')
  if i==602:p.update(status='空岗',hire='',salary='86800',allowance='868',bonus='868')
  if i==603:p.update(salary='0.005',allowance='0',bonus='0',rate='100')
  if i==604:p.update(salary='86800',allowance='868',bonus='868',raiseDate='2027-03-16',raiseSalary='173600')
  rows.append(p)
 return {'fields':F,'headers':H,'rows':rows,'scope':{'start':'2027-01','end':'2027-03','currency':'CNY','unit':'元','method':'自然日折算','precision':2,'tolerance':'0','basis':'604岗位独立日历预算，福利率为虚构用户参数','confirmed':True}}

def oracle(w):
 s=w['scope'];ms=['2027-01','2027-02','2027-03'];details=[];issues=[];precision=s['precision'];unit=Q(1).scaleb(-precision)
 def rounded(v):return format(Q(v).quantize(unit,rounding=decimal.ROUND_HALF_UP),'f')
 if not w['rows']:issues.append(['资料','岗位计划','阻塞','没有岗位计划'])
 duplicates={p['id']:sum(v['id']==p['id'] for v in w['rows']) for p in w['rows']}
 for p in w['rows']:
  src=p['source'];source=f"{src['file']} / {src['sheet']} / 第{src['row']}行";error=None
  if duplicates[p['id']]!=1:error='重复岗位组ID：全部重复行阻塞'
  elif p['currency']!=s['currency'] or p['unit']!=s['unit']:error='币种或单位与预算范围不一致'
  elif p['salary']=='':error='必填值为空'
  elif Q(p['salary'])<0:error='金额/费率不得负'
  if error:issues.append([p['id'],source,'阻塞',error]);continue
  n=int(p['count']);sal=Q(p['salary']);new=Q(p['raiseSalary']) if p['raiseDate'] else sal
  if not p['hire']:issues.append([p['id'],source,'提示','空岗到岗时间待定，未形成成本预算'])
  if n==0:issues.append([p['id'],source,'提示','计划人数为零'])
  if sal==0:issues.append([p['id'],source,'提示','月薪为零，请复核假设'])
  if Q(p['rate'])==0:issues.append([p['id'],source,'提示','福利附加率为零，用户假设不是法定值'])
  for month in ms:
   y,m=map(int,month.split('-'));md=calendar.monthrange(y,m)[1];end=f'{month}-{md}';covered=[];oldDays=0;newDays=0;dailyS=Q(0);dailyA=Q(0);dailyB=Q(0)
   for d in range(1,md+1):
    date=f'{month}-{d:02}'
    if p['hire'] and p['start']<=date<=p['end'] and p['hire']<=date and (not p['leave'] or date<=p['leave']):
     covered.append(date);isNew=p['raiseDate'] and date>=p['raiseDate'];oldDays+=not bool(isNew);newDays+=bool(isNew);dailyS+=(new if isNew else sal)*n;dailyA+=Q(p['allowance'])*n;dailyB+=Q(p['bonus'])*n
   days=len(covered);pd=days*n;cap=int(p['capacity']) if p['start']<=end<=p['end'] else 0;working=cap and p['hire'] and p['hire']<=end and (not p['leave'] or p['leave']>=end);actual=n if working and p['status']=='实岗' else 0;planned=n if working and p['status']=='空岗' else 0
   raw=[dailyS/Q(md),dailyA/Q(md),dailyB/Q(md)];segments='无在岗覆盖'
   if s['method']=='整月预算':
    if covered:raw=[(new if p['raiseDate'] and covered[-1]>=p['raiseDate'] else sal)*n,Q(p['allowance'])*n,Q(p['bonus'])*n];segments=f'最后覆盖日月薪{plain(raw[0]/n)} × {n}人，整月预算'
   elif covered:segments=f'旧月薪{plain(sal)} × {oldDays}日 + 新月薪{plain(new)} × {newDays}日；× {n}人 / {md}日'
   raw.append(raw[0]*Q(p['rate'])/100);rr=[Q(rounded(x)) for x in raw];total=sum(rr);diff=sum(rr)-sum(raw)
   v=dict(id=p['id'],dept=p['dept'],job=p['job'],status=p['status'],month=month,capacity=cap,actual=actual,planned=planned,vacant=cap-actual-planned,personDays=pd,fte=plain((Q(pd)/md).quantize(Q('0.000000000001'),rounding=decimal.ROUND_HALF_UP)),days=days,monthDays=md,segments=segments,salaryRaw=plain(raw[0]),salary=rounded(raw[0]),allowanceRaw=plain(raw[1]),allowance=rounded(raw[1]),bonusRaw=plain(raw[2]),bonus=rounded(raw[2]),benefitRaw=plain(raw[3]),benefit=rounded(raw[3]),total=rounded(total),rounding=plain(diff),source=source,basis=p['basis']);details.append(v)
 groups={}
 for d in details:groups.setdefault((d['dept'],d['month']),[]).append(d)
 summaries=[]
 for (dept,month),ds in groups.items():
  sums={f:sum(d[f] for d in ds) for f in ['capacity','actual','planned','vacant','personDays']};sums.update({f:rounded(sum(Q(d[f]) for d in ds)) for f in ['salary','allowance','bonus','benefit','total']});sums['fte']=plain((Q(sums['personDays'])/ds[0]['monthDays']).quantize(Q('0.000000000001'),rounding=decimal.ROUND_HALF_UP));summaries.append(dict(dept=dept,month=month,**sums))
 complete=not any(i[2]=='阻塞' for i in issues) and bool(w['rows']);checknames=['岗位明细=月部门汇总','人工总额=四项舍入成本','月末编制=实岗+计划到岗+未填','源行=有效组+阻塞组'];checks=[[c,'0','通过'] for c in checknames]
 origins=list(w['original']['rows']) if w['original'] else [p['source'] for p in w['rows']]
 j=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'))
 sheets=[('范围与版本',['项目','值'],[['工具','B04 编制与人工预算'],['应用','0.1.1'],['规则','B04-2026-10-04.1'],['完整性','无阻塞' if complete else '仅部分诊断，不能确认完整预算']]+list(map(list,s.items()))+[['金额舍入','每组件HALF_UP后相加'],['说明','福利率与计薪假设均为用户输入，非税法/社保实算']]),('岗位计划',H+['原文件','原页签','原行'],[[p[f] for f in F]+[p['source']['file'],p['source']['sheet'],p['source']['row']] for p in w['rows']]),('月度人数',['部门','期间','月末编制','月末实岗','月末计划到岗','月末未填编制','人数日','折算人数'],[[d[f] for f in ['dept','month','capacity','actual','planned','vacant','personDays','fte']] for d in summaries]),('人工预算汇总',['部门','期间','薪资','津贴','月奖金','福利附加','人工总额'],[[d[f] for f in ['dept','month','salary','allowance','bonus','benefit','total']] for d in summaries]),('岗位月度明细',DH,[[d[f] for f in DK] for d in details]),('异常清单',['岗位组ID','来源','级别','原因'],issues),('勾稽',['检查','差额','结果'],checks),('原始资料',['文件','页签','行','单元格JSON'],[[x['file'],x['sheet'],x['row'],j(x['cells'])] for x in origins]),('修改记录',['时间','操作','岗位组','修改前','修改后'],[[x[f] for f in ['time','action','id','before','after']] for x in w['logs']]),('复核记录',['经办','复核意见','时间','含阻塞'],[[w['review']['owner'],w['review']['note'],w['review']['time'],'否' if complete else '是，复核失效']] if w['review'] else [])]
 def cell(v):return 'true' if v is True else 'false' if v is False else str(v)
 return {'sheets':[{ 'name':name,'matrix':[[cell(c) for c in h]]+[[cell(c) for c in row] for row in rows]} for name,h,rows in sheets],'details':details,'summaries':summaries,'issues':issues,'total':rounded(sum(Q(d['total']) for d in details)),'monthTotals':{m:rounded(sum(Q(d['total']) for d in details if d['month']==m)) for m in ms},'complete':complete}
if __name__=='__main__':
 if sys.argv[1]=='fixture':out=fixture()
 else:out=oracle(json.load(open(sys.argv[2])))
 json.dump(out,open(sys.argv[-1],'w'),ensure_ascii=False,indent=2)
