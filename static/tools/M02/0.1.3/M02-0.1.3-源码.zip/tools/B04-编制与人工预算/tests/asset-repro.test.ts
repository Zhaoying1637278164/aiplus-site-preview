import test from 'node:test';import assert from 'node:assert/strict';import {releaseAssets} from '../src/release-assets';
test('构建资产跨时间原始字节一致，含XLSX',async()=>{const a=await releaseAssets();await new Promise(r=>setTimeout(r,2100));const b=await releaseAssets();assert.deepEqual(a.map(x=>[x.filename,Buffer.from(x.data)]),b.map(x=>[x.filename,Buffer.from(x.data)]))});
