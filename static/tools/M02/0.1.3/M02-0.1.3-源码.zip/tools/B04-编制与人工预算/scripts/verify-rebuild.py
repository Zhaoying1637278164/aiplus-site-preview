"""Run the four real source rebuild commands against the extracted candidate ZIP."""
import pathlib,zipfile,json,subprocess,tempfile,hashlib,datetime
root=pathlib.Path.cwd();e=root/'progress/evidence/B04/0.1.1';z=e/'candidate/B04-0.1.1-候选源码.zip';target=pathlib.Path(tempfile.mkdtemp(prefix='b04-rebuild-final-'));records=[]
with zipfile.ZipFile(z) as archive:
 assert archive.testzip() is None;archive.extractall(target)
 snapshot=json.loads((target/'source-snapshot.json').read_text())
 for name,expected in snapshot['files'].items():assert hashlib.sha256((target/name).read_bytes()).hexdigest()==expected
for label,cmd in [('ci',['npm','ci']),('test',['npm','test']),('typecheck',['npm','run','typecheck']),('build',['npm','run','build'])]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();log=e/f'final-rebuild-{label}.txt'
 with log.open('w') as f:proc=subprocess.run(cmd,cwd=target,stdout=f,stderr=subprocess.STDOUT)
 records.append({'command':' '.join(cmd),'cwd':str(target),'started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':proc.returncode,'log':str(log)})
 if proc.returncode:raise RuntimeError(f'{label} failed; see {log}')
original=e/'candidate/program';rebuilt=target/'progress/evidence/B04/0.1.1/candidate/program';files={}
for f in original.iterdir():
 expected=hashlib.sha256(f.read_bytes()).hexdigest();actual=hashlib.sha256((rebuilt/f.name).read_bytes()).hexdigest();assert expected==actual,f.name;files[f.name]=expected
report={'status':'passed','source_zip':str(z),'source_zip_sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'source_files_verified':len(snapshot['files']),'extracted_to':str(target),'commands':records,'program_files_exact':files,'all_assets_raw_bytes_equal':True,'platform':'macOS Node22; Windows real machine unverified'};(e/'source-rebuild-final.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'status':'passed','target':str(target),'four_commands':[r['exit_code'] for r in records],'exact_assets':len(files)}))
