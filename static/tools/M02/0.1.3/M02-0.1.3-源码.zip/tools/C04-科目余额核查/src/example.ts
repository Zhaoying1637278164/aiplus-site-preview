import type {Table} from '../../../packages/core/types';import {fields} from './engine';
export const example:Table={file:'完全虚构余额.csv',sheet:'CSV',headers:[...fields],rows:[
 ['虚构公司','2026-09','CNY','元','1001','现金','100','0','30','20','110','0','借'],
 ['虚构公司','2026-09','CNY','元','2202','应付','0','100','20','30','0','110','贷'],
 ['虚构公司','2026-10','CNY','元','1001','现金','110','0','10','5','115','0','借'],
 ['虚构公司','2026-10','CNY','元','2202','应付','0','110','5','10','0','115','贷']
 ].map((r,i)=>({file:'完全虚构余额.csv',sheet:'CSV',row:i+2,cells:Object.fromEntries(fields.map((f,j)=>[f,r[j]]))}))};
