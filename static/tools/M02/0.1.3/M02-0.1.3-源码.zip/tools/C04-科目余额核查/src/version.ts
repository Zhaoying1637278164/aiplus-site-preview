export const VERSION='0.1.1';export const RULE_VERSION='C04-2026-10-04.1';
