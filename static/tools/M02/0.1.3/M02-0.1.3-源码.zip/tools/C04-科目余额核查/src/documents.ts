import {readFile} from 'node:fs/promises';
export async function releaseAssets(){return Promise.all(['空白模板.csv','虚构样例.csv','虚构样例.xlsx','无数据规则方案.json','虚构含数据方案.json'].map(async filename=>({filename,data:await readFile(new URL('../examples/'+filename,import.meta.url))})));}
