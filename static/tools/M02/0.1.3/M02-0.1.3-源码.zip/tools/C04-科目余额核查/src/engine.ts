import Decimal from 'decimal.js';
import {amount,text} from '../../../packages/core/value';
import type {SourceRow,Table} from '../../../packages/core/types';
import {VERSION,RULE_VERSION} from './version';
export const fields=['主体','期间','币种','单位','科目编码','科目名称','期初借方','期初贷方','发生借方','发生贷方','期末借方','期末贷方','正常方向'] as const;
export type Direction='借'|'贷'|'不限'|'未设置';
export interface Config {precision:number;tolerance:string;materiality:string;continuity:boolean;complete:boolean;directions:Record<string,Direction>}
export const defaults:Config={precision:2,tolerance:'0.01',materiality:'0',continuity:true,complete:false,directions:{}};
export type Mapping=Record<string,string>;
export const mappingDefault=Object.fromEntries(fields.map(f=>[f,f]));
export interface Line {index:number;source:SourceRow;group:string[]|null;account:string;name:string;values:string[];opening:string|null;movement:string|null;closing:string|null;expected:string|null;difference:string|null;reconcile:string;direction:string;continuity:string;priorSource:string;continuityDifference:string|null;issues:string[]}
export interface Group {key:string[];count:number;valid:number;sums:string[];diffs:string[];status:string[];sources:string[]}
export const sourceLabel=(s:SourceRow)=>`${s.file} / ${s.sheet} / 第${s.row}行`;
const fmt=(v:Decimal)=>v.toFixed().replace(/^-0$/,'0');
const month=(s:string)=>{if(!/^(?:19\d{2}|[2-9]\d{3})-(?:0[1-9]|1[0-2])$/.test(s))throw Error('期间须为1900–9999年YYYY-MM');const [y,m]=s.split('-').map(Number);return y*12+m-1};
export function validateConfig(c:Config){if(!Number.isInteger(c.precision)||c.precision<0||c.precision>6)throw Error('金额精度须0–6');if(typeof c.continuity!=='boolean'||typeof c.complete!=='boolean'||!c.directions||typeof c.directions!=='object'||Array.isArray(c.directions))throw Error('配置结构无效');for(const d of Object.values(c.directions))if(!['借','贷','不限','未设置'].includes(d))throw Error('方向无效');for(const x of [c.tolerance,c.materiality])if(amount(x).isNegative())throw Error('容差及阈值须非负');}
export function check(table:Table,map:Mapping,c:Config){validateConfig(c);const tol=amount(c.tolerance),threshold=amount(c.materiality);
 if(table.rows.length>20000||table.headers.length>200)throw Error('超过行列限制');
 const required=fields.filter(f=>f!=='正常方向');if(required.some(f=>!map[f]||!table.headers.includes(map[f])))throw Error('必需字段映射不完整');if(new Set(required.map(f=>map[f])).size!==required.length)throw Error('必需字段不能重复映射');
 const lines:Line[]=table.rows.map((s,index)=>{const l:Line={index,source:s,group:null,account:'',name:'',values:[],opening:null,movement:null,closing:null,expected:null,difference:null,reconcile:'未执行',direction:'未执行',continuity:'未执行',priorSource:'',continuityDifference:null,issues:[]};
 const get=(f:string)=>s.cells[map[f]];
 try{l.group=['主体','期间','币种','单位'].map(f=>text(get(f),true));month(l.group[1]);}catch(e){l.group=null;l.issues.push(String((e as Error).message));}
 try{l.account=text(get('科目编码'),true);l.name=text(get('科目名称'),true);}catch(e){l.issues.push('科目资料：'+(e as Error).message)}
 for(const f of fields.slice(6,12)){try{const raw=get(f),v=amount(raw);const digits=String(raw).trim().split('.')[1]?.length??0;if(v.isNegative())throw Error('借贷栏须非负');if(digits>c.precision)throw Error('超过所设金额精度');l.values.push(fmt(v));}catch(e){l.values.push('');l.issues.push(f+'：'+(e as Error).message)}}
 const d=get('正常方向');if(d!==null&&d!==undefined&&d!==''){try{const str=text(d,true);if(!['借','贷','不限','未设置'].includes(str))throw Error('正常方向须借/贷/不限/未设置');}catch(e){l.issues.push((e as Error).message)}}return l;});
 const keys=new Map<string,Line[]>();for(const l of lines)if(l.group&&l.account){const k=JSON.stringify([...l.group,l.account]);keys.set(k,[...(keys.get(k)??[]),l]);}for(const ls of keys.values())if(ls.length>1)for(const l of ls)l.issues.push('主体/期间/币种/单位/科目重复，全部阻塞');
 for(const l of lines){if(l.issues.length)continue;const v=l.values.map(x=>new Decimal(x));l.opening=fmt(v[0].minus(v[1]));l.movement=fmt(v[2].minus(v[3]));l.closing=fmt(v[4].minus(v[5]));l.expected=fmt(new Decimal(l.opening).plus(l.movement));l.difference=fmt(new Decimal(l.closing).minus(l.expected));l.reconcile=new Decimal(l.difference).abs().lte(tol)?'容差内':'勾稽差异';
 const raw=l.source.cells[map['正常方向']],d=(Object.hasOwn(c.directions,l.account)?c.directions[l.account]:undefined)??(raw==null||raw===''?'未设置':String(raw).trim());const close=new Decimal(l.closing);l.direction=d==='未设置'?'未执行：未设置方向':d==='不限'?'不限方向':((d==='借'&&close.isNegative())||(d==='贷'&&close.isPositive()))&&close.abs().gt(threshold)?'反向余额复核线索':'无超阈方向线索';
 for(const i of [0,4])if(v[i].gt(0)&&v[i+1].gt(0))l.issues.push(['期初','发生','期末'][i/2]+'借贷同时非零（复核线索）');}
 const grouped=new Map<string,Line[]>();for(const l of lines)if(l.group){const k=JSON.stringify(l.group);grouped.set(k,[...(grouped.get(k)??[]),l]);}
 const unknown=lines.some(l=>!l.group);const groups:Group[]=[...grouped.values()].map(ls=>{const sums=Array.from({length:6},()=>new Decimal(0));for(const l of ls)if(l.closing!==null)l.values.forEach((v,i)=>sums[i]=sums[i].plus(v));const diffs=[0,2,4].map(i=>sums[i].minus(sums[i+1]));const valid=ls.filter(l=>l.closing!==null).length;const blocked=unknown||valid!==ls.length||!c.complete;return {key:ls[0].group!,count:ls.length,valid,sums:sums.map(fmt),diffs:diffs.map(fmt),status:diffs.map(d=>blocked?'未执行：资料或完整表声明不足':d.abs().lte(tol)?'容差内':'借贷差异'),sources:ls.map(l=>sourceLabel(l.source))}});
 const series=new Map<string,Line[]>();for(const l of lines)if(l.group&&l.account){const k=JSON.stringify([l.group[0],l.group[2],l.group[3],l.account]);series.set(k,[...(series.get(k)??[]),l]);}
 for(const ls of series.values()){ls.sort((a,b)=>month(a.group![1])-month(b.group![1]));for(let i=0;i<ls.length;i++){const l=ls[i],prev=ls[i-1];if(!c.continuity){l.continuity='未执行：规则关闭';continue}if(l.closing===null){l.continuity='未执行：本期资料异常';continue}if(!prev){l.continuity='未执行：无前期资料';continue}l.priorSource=sourceLabel(prev.source);if(month(l.group![1])-month(prev.group![1])!==1){l.continuity='未执行：期间不连续';continue}if(prev.closing===null){l.continuity='未执行：前期资料异常';continue}l.continuityDifference=fmt(new Decimal(l.opening!).minus(prev.closing));l.continuity=new Decimal(l.continuityDifference).abs().lte(tol)?'容差内':'连续性差异';}}
 return {version:VERSION,rule_version:RULE_VERSION,config:c,mapping:map,groups,lines,unknownGroup:unknown};
}
