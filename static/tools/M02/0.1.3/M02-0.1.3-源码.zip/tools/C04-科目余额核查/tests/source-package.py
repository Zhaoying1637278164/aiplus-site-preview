from pathlib import Path
import shutil,json,zipfile,hashlib
root=Path.cwd();out=root/'progress/evidence/C04/source'
if out.exists():shutil.rmtree(out)
out.mkdir(parents=True)
for name in ['packages','tools/C04-科目余额核查']:shutil.copytree(root/name,out/name,ignore=shutil.ignore_patterns('node_modules','.DS_Store','candidate','fixtures-generated'))
for name in ['package.json','package-lock.json','AGENTS.md','tsconfig.json']:shutil.copy2(root/name,out/name)
p=json.loads((out/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/C04-科目余额核查/tests/engine.test.ts','typecheck':'tsc -p tools/C04-科目余额核查/tsconfig.json --noEmit','build':'node --import tsx tools/C04-科目余额核查/tests/build.ts'};(out/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(out/'references').mkdir();
for ref in ['finance-reconciliation.md','anthropic-finance-8444efcd-LICENSE','D02-reconciliation-version-check.json']:shutil.copy2(root/'references'/ref,out/'references'/ref)
shutil.copy2(root/'references/saxes-5.0.1-LICENSE',out/'references/saxes-5.0.1-LICENSE');shutil.copy2(root/'tools/C04-科目余额核查/candidate/0.1.0/THIRD_PARTY_NOTICES.md',out/'THIRD_PARTY_NOTICES.md')
(out/'BUILD.md').write_text('# C04源码重建\nNode22+；npm ci；npm test；npm run typecheck；npm run build。产物tools/C04-科目余额核查/candidate/0.1.0。锁文件、共享包、工具代码、虚构测试夹具与独立算法预期、模板和说明、第三方声明齐备；不含node_modules、凭据或业务数据。浏览器脚本依赖本机Chrome，官网部署由总控。\n')
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
(root/'progress/evidence/C04/source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));archive=root/'progress/evidence/C04/C04-0.1.0-候选源码.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n in manifest:z.write(out/n,n)
print(json.dumps({'archive':str(archive.relative_to(root)),'files':len(manifest),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},ensure_ascii=False))
