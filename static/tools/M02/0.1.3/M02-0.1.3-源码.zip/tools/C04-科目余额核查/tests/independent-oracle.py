from decimal import Decimal
from pathlib import Path
import json
root=Path('tools/C04-科目余额核查');fields=['主体','期间','币种','单位','科目编码','科目名称','期初借方','期初贷方','发生借方','发生贷方','期末借方','期末贷方','正常方向'];rows=[];expected=[];groups={}
for i in range(48):
 group=['虚构主体'+str(i%3),'2026-09' if i<24 else '2026-10','CNY' if i%2 else 'USD','元' if i%4 else '万元']
 vals=[Decimal(str((i+1)*(k+2))) / Decimal('1000000') for k in range(6)]
 if i==0:vals=[Decimal('123456789012345678.123456'),Decimal('0'),Decimal('0.000001'),Decimal('0'),Decimal('123456789012345678.123457'),Decimal('0')]
 account='A'+str(i);data=group+[account,'完全虚构'+str(i)]+[str(v) for v in vals]+['借'];rows.append({'file':'独立虚构.csv','sheet':'CSV','row':i+2,'cells':dict(zip(fields,data))})
 opening=vals[0]-vals[1];movement=vals[2]-vals[3];closing=vals[4]-vals[5];expected.append([str(opening),str(movement),str(closing),str(opening+movement),str(closing-opening-movement)])
 key=json.dumps(group);groups.setdefault(key,[Decimal('0')]*6);groups[key]=[a+b for a,b in zip(groups[key],vals)]
(root/'examples/独立算法预期.json').write_text(json.dumps({'generator':'Python decimal independently computed; not importing target','table':{'file':'独立虚构.csv','sheet':'CSV','headers':fields,'rows':rows},'expected':expected,'groups':[{ 'key':json.loads(k),'sums':[str(v) for v in vs],'diffs':[str(vs[j]-vs[j+1]) for j in [0,2,4]]} for k,vs in groups.items()]},ensure_ascii=False,indent=2))
print('Independent Python oracle 48 rows',len(groups),'groups')
