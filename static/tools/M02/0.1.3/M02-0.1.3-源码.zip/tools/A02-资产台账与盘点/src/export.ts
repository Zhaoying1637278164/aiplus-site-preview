import {calculate,roles,names,VERSION,RULE_VERSION,reviewed,active,type State} from './engine';import {workbookBytes} from '../../../packages/core/io';
export function csv(headers:string[],rows:unknown[][]){const escape=(v:unknown)=>{let s=v===null||v===undefined?'':typeof v==='object'?JSON.stringify(v):String(v);if(/^[=+@-]/.test(s)&&!/^-[0-9]+(\.[0-9]+)?$/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};return '\uFEFF'+[headers,...rows].map(r=>r.map(escape).join(',')).join('\r\n')}
export function sheets(s:State){const b=active(s),r=calculate(b);return [
 {name:'批次参数',headers:['参数','值'],rows:[['应用版本',VERSION],['规则版本',RULE_VERSION],['批次状态',b.confirmed?'已确认（个人底稿）':'草稿'],...Object.entries(b.rule),['字段对应',b.fields],['说明','净值是账面金额；盘盈价值未知；未盘不当盘亏；非企业审批或分录']]},
 ...roles.map(role=>({name:'原始'+names[role],headers:['文件','页签','原行',...(b.data[role]?.headers??[])],rows:(b.data[role]?.rows??[]).map(l=>[l.file,l.sheet,l.row,...b.data[role]!.headers.map(h=>l.cells[h])])})),
 {name:'资产卡片与差异',headers:['唯一键','资产ID','名称','分类','账面位置','账面责任人','实物位置','实物责任人','账面净值','实盘存在','件数差','异常','复核状态'],rows:r.items.map(i=>[i.key,i.id,i.name,i.status,i.book[0]?.location,i.book[0]?.owner,i.chosen?.location,i.chosen?.owner,i.net,i.actual,i.difference,i.errors,reviewed(b,i)?'已复核':'待复核'])},
 {name:'原行去向与追查',headers:['资料','文件','页签','原行','唯一键','原ID','处理状态','范围内','异常','对应源行'],rows:r.lines.map(l=>[names[l.role],l.source.file,l.source.sheet,l.source.row,l.key,l.id,l.disposition,l.scope?'是':'否',l.errors,l.mappingSource])},
 {name:'ID对应结果',headers:['实物ID','资产ID','状态','文件','页签','原行','依据','异常'],rows:r.lines.filter(l=>l.role==='mapping').map(l=>[l.id,l.source.cells[b.fields.mapping['资产ID']],l.disposition,l.source.file,l.source.sheet,l.source.row,l.source.cells[b.fields.mapping['对应依据']],l.errors])},
 {name:'重复盘点选择',headers:['唯一键','采用来源','人员','依据'],rows:Object.entries(b.selections).map(([k,v])=>[k,v.source,v.reviewer,v.basis])},
 {name:'逐项复核',headers:['唯一键','分类','结论','人员','依据'],rows:Object.entries(b.reviews).map(([k,v])=>[k,r.items.find(i=>i.key===k)?.status,v.conclusion,v.reviewer,v.basis])},
 {name:'复核撤销历史',headers:['动作','键','人员','依据','时间'],rows:b.events.map(e=>[e.action,e.key,e.reviewer,e.basis,e.at])},
 {name:'勾稽与覆盖',headers:['检查','结果'],rows:[...Object.entries(r.totals),...Object.entries(r.coverage),...Object.entries(r.categories),...r.errors.map(e=>['参数异常',e])]},
 {name:'历史批次索引',headers:['批次','主体','期间','币种','单位','状态','台账行数','盘点行数','确认人','确认依据'],rows:s.batches.map(x=>[x.rule.batchId,x.rule.entity,x.rule.period,x.rule.currency,x.rule.unit,x.confirmed?'已确认':'草稿',x.data.book?.rows.length??0,x.data.count?.rows.length??0,x.confirmed?.reviewer,x.confirmed?.basis])}
 ]}
export async function exportWorkbook(s:State){return workbookBytes(sheets(s))}
