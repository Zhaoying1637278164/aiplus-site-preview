# Actual参考已读记录

2026-10-04读取 https://actualbudget.org/docs/transactions/importing/ 的Import CSV Files和Avoiding duplicate transactions。网页有字段选择、导入预览、稳定交易ID排重；其日期金额名称相似匹配和自动更新旧交易不适用于本款资产卡片，不采用。页面无固定commit，Copyright2026；不复制代码。上游未运行。A02自主实现严格重复阻塞和明确一对一ID对应。
