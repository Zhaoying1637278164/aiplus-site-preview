import {build} from 'esbuild';
import {mkdir,writeFile,readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {releaseAssets} from '../src/release-assets';
import {VERSION} from '../src/types';
const folder='tools/D01-财务台账合并拆分',out=`progress/evidence/D01/${VERSION}/candidate`;await mkdir(out,{recursive:true});
const options={bundle:true,write:false,platform:'browser' as const,format:'iife' as const,target:['es2022'],minify:true,metafile:true,outfile:'bundle.js',define:{'process.env.NODE_ENV':'"production"'},alias:{exceljs:'exceljs/lib/exceljs.bare.js'},inject:['packages/core/browser-globals.ts'],plugins:[{name:'browser-boundary',setup(b:import('esbuild').PluginBuild){b.onResolve({filter:/^(fs|crypto)$/},()=>({path:path.resolve('packages/core/browser-disabled.cjs')}));b.onResolve({filter:/^\.\.\/csv\/csv$/},()=>({path:path.resolve('packages/core/browser-csv-disabled.cjs')}))}}]};
const standalone=await build({...options,entryPoints:[folder+'/src/main.tsx']}),native=await build({...options,entryPoints:[folder+'/src/program.tsx'],globalName:'__AIPlusProgram'});
const js=standalone.outputFiles![0].text;
const html=`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; font-src 'none'; base-uri 'none'; form-action 'none'"><title>D01 财务台账合并拆分 ${VERSION}</title></head><body style="margin:0"><div id="root"></div><script>${js.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
const runtime=JSON.stringify({schema_version:1,id:'D01',name:'财务台账合并拆分',version:VERSION,css:'',js:`(()=>{${native.outputFiles![0].text};window.__aiPlusLoadedProgram=__AIPlusProgram.program;})();`});
await writeFile(out+'/index.html',html);await writeFile(out+'/runtime.json',runtime);for(const a of await releaseAssets())await writeFile(out+'/'+a.filename,a.data);
const inputs=Object.keys(standalone.metafile!.inputs),roots=new Set(inputs.filter(x=>x.startsWith('node_modules/')).map(x=>{const parts=x.split('/');return parts.slice(0,parts[1].startsWith('@')?3:2).join('/')}));
let notices='# D01 候选第三方声明\n\nOpenRefine 方法参考：https://openrefine.org/docs/manual/cellediting 和 exporting，CC BY 4.0，不复制代码或全文。JSZip选择MIT。\n';
for(const root of [...roots].sort()){const p=JSON.parse(await readFile(root+'/package.json','utf8'));notices+=`\n## ${p.name} ${p.version}\n`;const licenses=(await readdir(root)).filter(n=>/^(licen[cs]e|copying|notice)(\.|$|-)/i.test(n));if(!licenses.length&&p.name!=='saxes')throw Error('许可缺失 '+root);for(const f of licenses)notices+=await readFile(root+'/'+f,'utf8')+'\n';if(p.name==='saxes')notices+=await readFile('references/saxes-5.0.1-LICENSE','utf8')}
notices+=await readFile('node_modules/pako/lib/zlib/README','utf8');await writeFile(out+'/THIRD_PARTY_NOTICES.md',notices);
const sourceFiles=(await readdir(folder+'/src')).map(f=>folder+'/src/'+f);const hashes:Record<string,string>={};for(const f of [...sourceFiles,...['index.html','runtime.json','空白模板.csv','虚构样例.xlsx','虚构乙台账.xlsx','THIRD_PARTY_NOTICES.md'].map(f=>out+'/'+f)])hashes[f]=createHash('sha256').update(await readFile(f)).digest('hex');
await writeFile(out+'/manifest.json',JSON.stringify({tool:'D01',version:VERSION,candidate:true,inputs,hashes},null,2));console.log(JSON.stringify({out,version:VERSION,hashes},null,2));
