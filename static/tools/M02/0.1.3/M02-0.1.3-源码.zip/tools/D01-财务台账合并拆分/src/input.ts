import {asTable,type LoadedFile} from '../../../packages/core/io';
import type {Table} from '../../../packages/core/types';
/** Keep inner blank rows as explicit records; shared asTable supplies header safety checks. */
export function tableFrom(f:LoadedFile,sheet:string,header:number):Table{
 const t=asTable(f,sheet,header),matrix=f.sheets.find(x=>x.name===sheet)!.matrix;
 const existing=new Map(t.rows.map(r=>[r.row,r]));
 t.rows=[];for(let n=header;n<matrix.length;n++)t.rows.push(existing.get(n+1)||{file:f.file,sheet,row:n+1,cells:Object.fromEntries(t.headers.map(h=>[h,null]))});
 if(t.rows.length>20000)throw Error('页签数据行超过20000');return t;
}
