import {program} from './program';
const container=document.getElementById('root');if(!container)throw Error('缺少工作区');
const instance=program.mount({container,mode:'offline'});
window.addEventListener('pagehide',()=>instance.dispose(),{once:true});
