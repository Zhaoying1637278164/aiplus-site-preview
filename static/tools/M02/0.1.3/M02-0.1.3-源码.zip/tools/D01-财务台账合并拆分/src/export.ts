import JSZip from 'jszip';
import {workbookBytes} from '../../../packages/core/io';
import type {Result,Row} from './types';
const MAX=30*1024*1024;
export function rowSheet(name:string,rows:Row[],r:Result){const cols=r.plan.columns.map(c=>c.name);return {name,headers:[...cols,'来源槽','来源文件','来源页签','来源行号','分类','原因','重复首行','原始行JSON','变化JSON'],rows:rows.map(x=>[...cols.map(c=>x.values[c]),x.slot,x.source.file,x.source.sheet,x.source.row,x.status,x.reasons.join('；'),x.duplicateOf||'',JSON.stringify(x.source.cells),JSON.stringify(x.changes)])}}
function processingLog(r:Result){return {name:'处理日志',headers:['项目','内容'],rows:[['应用版本',r.version],['规则版本',r.rule_version],['输入行数',r.rows.length],...Object.entries(r.stats),['数量勾稽',`${r.rows.length} = ${Object.values(r.stats).join(' + ')}`],['数据说明','此底稿含全部原始数据；金额为精确十进制文本，不执行公式'],['处理参数JSON',JSON.stringify(r.plan)]]}}
export function workSheets(r:Result){return [processingLog(r),...(['有效','异常','重复移出','空行移出'] as const).map(status=>rowSheet(status,r.rows.filter(x=>x.status===status),r))]}
function guard(sheets:ReturnType<typeof workSheets>){if(new TextEncoder().encode(JSON.stringify(sheets)).length>MAX)throw Error('导出原始内容超过30MB，请缩小资料范围');for(const sheet of sheets)for(const row of sheet.rows)for(const cell of row)if(String(cell??'').length>32767)throw Error('底稿单元格内容超过Excel的32767字符限制，请减少目标列或拆小来源资料')}
export async function exportWork(r:Result){const sheets=workSheets(r);guard(sheets);return workbookBytes(sheets)}
function groupSheets(r:Result,index:number){const g=r.groups[index];if(!g)throw Error('分拆组不存在');const log=processingLog(r);return [rowSheet('台账',g.rows,r),{...log,rows:[...log.rows,['分拆文件',g.filename],['分拆字段值',JSON.stringify(g.values)],['本组行数',g.rows.length],['导出范围','此文件仅本组有效记录；异常及移出原行请查看完整处理底稿或分拆ZIP。']]}]}
export async function exportGroup(r:Result,index:number){const sheets=groupSheets(r,index);guard(sheets);return workbookBytes(sheets)}
export async function exportZip(r:Result){const all=workSheets(r);guard([...all,...r.groups.flatMap((_,i)=>groupSheets(r,i))]);const zip=new JSZip();let total=0;
 const add=(name:string,data:Uint8Array|string)=>{total+=typeof data==='string'?new TextEncoder().encode(data).length:data.length;if(total>MAX)throw Error('分拆包文件内容超过30MB');zip.file(name,data)};
 add('完整处理底稿.xlsx',await exportWork(r));
 for(let i=0;i<r.groups.length;i++)add(r.groups[i].filename,await exportGroup(r,i));
 add('分拆清单.json',JSON.stringify({schema_version:1,tool:'D01',version:r.version,rule_version:r.rule_version,contains_data:true,splitKeys:r.plan.splitKeys,stats:r.stats,groups:r.groups.map(g=>({filename:g.filename,values:g.values,rows:g.rows.length})),plan:r.plan},null,2));
 const bytes=await zip.generateAsync({type:'uint8array',compression:'DEFLATE'});if(bytes.length>MAX)throw Error('ZIP超过30MB');return bytes;
}
