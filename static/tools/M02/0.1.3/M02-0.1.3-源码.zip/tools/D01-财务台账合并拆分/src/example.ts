import {initial} from './engine';
import type {Session} from './types';
import type {Cell,Table} from '../../../packages/core/types';
export function example():Session{
 const s=initial();const names=s.columns.map(c=>c.name),other=['票号','组织','数额','货币','月份','注记'];
 const a:Cell[][]=[['A001',' 研发  部 ',0,'CNY','2026-09','虚构'],['A002','销售','-2.50','CNY','2026-09','虚构'],['A003','研发部',null,'CNY','2026-09','虚构'],['A004','研发部',{formula:'1+1',cached:2},'CNY','2026-09','虚构'],['A002','销售','-2.50','CNY','2026-09','虚构']];
 const b:Cell[][]=[['B001','销售','10','USD','2026-09','虚构'],['B002','研发部','0.1','CNY','2026-08','虚构'],['A002','销售','-2.50','CNY','2026-09','虚构'],['B003',null,'5','CNY','2026-09','虚构']];
 const table=(file:string,headers:string[],data:Cell[][]):Table=>({file,sheet:'台账',headers,rows:data.map((r,i)=>({file,sheet:'台账',row:i+2,cells:Object.fromEntries(headers.map((h,k)=>[h,r[k]]))}))});
 s.slots=[{id:'S1',label:'虚构甲台账.xlsx',sheet:'台账',header:1,mapping:Object.fromEntries(names.map(n=>[n,n])),table:table('虚构甲台账.xlsx',names,a),error:''},{id:'S2',label:'虚构乙台账.xlsx',sheet:'台账',header:1,mapping:Object.fromEntries(names.map((n,i)=>[n,other[i]])),table:table('虚构乙台账.xlsx',other,b),error:''}];
 s.duplicateKeys=['单号','币种','期间'];s.removeDuplicates=true;s.splitKeys=['币种','期间','部门'];return s;
}
