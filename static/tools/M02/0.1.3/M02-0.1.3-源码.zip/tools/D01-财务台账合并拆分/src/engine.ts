import {amount,date} from '../../../packages/core/value';
import type {Cell} from '../../../packages/core/types';
import {VERSION,RULE_VERSION,type Session,type Plan,type Result,type Row} from './types';
export {VERSION};
export const clone=<T,>(x:T):T=>JSON.parse(JSON.stringify(x));
export function initial():Session{return {columns:['单号','部门','金额','币种','期间','备注'].map(name=>({name,type:name==='金额'?'amount':'text',required:name!=='备注',trim:true,collapse:name==='部门',case:'keep'})),slots:[],duplicateKeys:[],removeDuplicates:false,removeBlank:false,splitKeys:[],prefix:'台账'}}
export function plan(s:Session):Plan{return {schema_version:1,tool:'D01',app_version:VERSION,rule_version:RULE_VERSION,contains_data:false,columns:clone(s.columns),slots:s.slots.map(({id,label,sheet,header,mapping})=>({id,label,sheet,header,mapping:clone(mapping)})),duplicateKeys:[...s.duplicateKeys],removeDuplicates:s.removeDuplicates,removeBlank:s.removeBlank,splitKeys:[...s.splitKeys],prefix:s.prefix}}
const safe=(s:unknown,max=100):s is string=>typeof s==='string'&&s.length>0&&s.length<=max&&!/[\u0000-\u001f]/.test(s);
export function validate(s:Session){
 if(!Array.isArray(s.columns)||!s.columns.length||s.columns.length>100)throw Error('目标列须为1–100列');
 const names=s.columns.map(c=>c.name);
 if(new Set(names).size!==names.length||names.some(n=>!safe(n)||n!==n.trim()||['__proto__','constructor','prototype'].includes(n)))throw Error('目标列名为空、重复或无效');
 for(const c of s.columns)if(Object.keys(c).some(k=>!['name','type','required','trim','collapse','case'].includes(k))||!['text','amount','date'].includes(c.type)||!['keep','upper','lower'].includes(c.case)||[c.required,c.trim,c.collapse].some(v=>typeof v!=='boolean'))throw Error('字段清理规则无效');
 if(!Array.isArray(s.slots)||s.slots.length>20||new Set(s.slots.map(x=>x.id)).size!==s.slots.length)throw Error('资料槽须唯一且最多20个');
 for(const slot of s.slots){if(!/^S\d+$/.test(slot.id)||!safe(slot.label,200)||typeof slot.sheet!=='string'||slot.sheet.length>100||!Number.isInteger(slot.header)||slot.header<1||slot.header>20100||!slot.mapping||typeof slot.mapping!=='object'||Array.isArray(slot.mapping))throw Error('资料槽设置无效');for(const [k,v] of Object.entries(slot.mapping))if(!names.includes(k)||typeof v!=='string'||v.length>10000)throw Error('字段对应设置无效')}
 for(const keys of [s.duplicateKeys,s.splitKeys])if(!Array.isArray(keys)||keys.some(k=>!names.includes(k))||new Set(keys).size!==keys.length)throw Error('复合键须使用目标字段且不可重复');
 if(typeof s.removeDuplicates!=='boolean'||typeof s.removeBlank!=='boolean'||(s.removeDuplicates&&!s.duplicateKeys.length))throw Error('重复移出需设置重复键');
 if(!safe(s.prefix,60)||/[\\/:*?"<>|.]/.test(s.prefix)||/^(con|prn|aux|nul|com\d|lpt\d)$/i.test(s.prefix))throw Error('输出前缀须为安全文件名，不含路径或点');
}
export function restore(raw:string):Session{
 if(new TextEncoder().encode(raw).length>1024*1024)throw Error('方案超过1MB');
 const p=JSON.parse(raw) as Plan;
 if(p.schema_version!==1||p.tool!=='D01'||p.contains_data!==false||(p.app_version!==VERSION&&p.app_version!=='0.1.0')||p.rule_version!==RULE_VERSION)throw Error('方案版本或数据标记不支持');
 const allowed=['schema_version','tool','app_version','rule_version','contains_data','columns','slots','duplicateKeys','removeDuplicates','removeBlank','splitKeys','prefix'];
 if(Object.keys(p).some(k=>!allowed.includes(k))||!Array.isArray(p.slots)||p.slots.some(x=>Object.keys(x).some(k=>!['id','label','sheet','header','mapping'].includes(k))))throw Error('方案含非配置字段');
 const s:Session={columns:p.columns,slots:p.slots.map(x=>({...x,table:null,error:''})),duplicateKeys:p.duplicateKeys,removeDuplicates:p.removeDuplicates,removeBlank:p.removeBlank,splitKeys:p.splitKeys,prefix:p.prefix};validate(s);return clone(s);
}
export function run(s:Session):Result{
 validate(s);if(!s.slots.length)throw Error('请先导入资料');
 if(s.slots.some(x=>!x.table||x.error))throw Error('有未载入或错误资料，请修正或显式移除');
 if(s.slots.reduce((n,x)=>n+x.table!.rows.length,0)>20000)throw Error('总数据行超过20000');
 const rows:Row[]=[];
 for(const slot of s.slots){const t=slot.table!;for(const c of s.columns){const source=slot.mapping[c.name];if(source&&!t.headers.includes(source))throw Error(`${slot.id} 对应源列不存在：${source}`);if(c.required&&!source)throw Error(`${slot.id} 必填字段未对应：${c.name}`)}
 for(const source of t.rows){
 const row:Row={id:`${slot.id}:${source.row}`,slot:slot.id,source:clone(source),values:Object.create(null),status:'有效',reasons:[],changes:[]};
 for(const c of s.columns){const v:Cell=source.cells[slot.mapping[c.name]]??null;let out:string|null=null;
 try{if(v&&typeof v==='object')throw Error('公式或错误单元格，未采用缓存');
 if(v!==null){out=String(v);if(c.trim)out=out.trim();if(c.collapse)out=out.replace(/\s+/g,' ');if(c.case==='upper')out=out.toUpperCase();if(c.case==='lower')out=out.toLowerCase();if(out.trim()==='')out=null;}
 if(out===null){if(c.required)throw Error('必填值为空')}else if(c.type==='amount')out=amount(typeof v==='number'?v:out).toFixed();else if(c.type==='date')out=date(out);
 }catch(e){row.reasons.push(c.name+'：'+(e as Error).message);out=null}
 row.values[c.name]=out;if(v!==out)row.changes.push({field:c.name,before:v,after:out});
 }
 const mapped=s.columns.map(c=>source.cells[slot.mapping[c.name]]??null);
 const rawBlank=mapped.every(v=>v===null||typeof v==='string'&&v.trim()==='');
 if(s.removeBlank&&rawBlank){row.status='空行移出';row.reasons=['按显式规则移出目标列全空行']}
 else {for(const k of new Set([...s.splitKeys,...s.duplicateKeys]))if(row.values[k]===null)row.reasons.push(k+'：复合键缺值');if(row.reasons.length)row.status='异常'}
 rows.push(row);
 }}
 if(s.duplicateKeys.length){const map=new Map<string,Row[]>();for(const r of rows.filter(x=>x.status==='有效')){const k=JSON.stringify(s.duplicateKeys.map(c=>r.values[c]));if(!map.has(k))map.set(k,[]);map.get(k)!.push(r)}
 for(const group of map.values()){if(group.length<2)continue;const signatures=new Set(group.map(r=>JSON.stringify(s.columns.map(c=>r.values[c.name]))));
 if(signatures.size>1)for(const r of group){r.status='异常';r.reasons.push('相同重复键存在不同目标值，整组待确认')}
 else if(s.removeDuplicates)for(const r of group.slice(1)){r.status='重复移出';r.duplicateOf=group[0].id;r.reasons.push('与首行目标值完全相同，按规则移出')}
 }}
 const groupMap=new Map<string,Row[]>();for(const r of rows.filter(x=>x.status==='有效')){const key=JSON.stringify(s.splitKeys.map(k=>r.values[k]));if(!groupMap.has(key))groupMap.set(key,[]);groupMap.get(key)!.push(r)}
 if(groupMap.size>100)throw Error('拆分超过100组，请减少分拆键或资料范围');
 const groups=[...groupMap].map(([key,rs],i)=>({key,values:JSON.parse(key),rows:rs,filename:`${s.prefix}-${String(i+1).padStart(3,'0')}.xlsx`}));
 const stats={'有效':0,'异常':0,'重复移出':0,'空行移出':0};for(const r of rows)stats[r.status]++;
 return {rows,stats,groups,version:VERSION,rule_version:RULE_VERSION,plan:plan(s)};
}
