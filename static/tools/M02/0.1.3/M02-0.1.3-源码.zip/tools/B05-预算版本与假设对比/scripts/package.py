import pathlib,zipfile,json,hashlib
root=pathlib.Path.cwd();folder=root/'tools/B05-预算版本与假设对比';out=folder/'candidate/0.1.0'
base=json.loads((root/'package.json').read_text());base['scripts']={'test':'node --import tsx --test tools/B05-预算版本与假设对比/tests/*.test.ts','typecheck':'tsc --noEmit -p tools/B05-预算版本与假设对比/tsconfig.json','build':'node --import tsx tools/B05-预算版本与假设对比/scripts/build.ts'}
files={}
for name in ['package-lock.json','tsconfig.json']:
 files[name]=(root/name).read_bytes()
files['package.json']=(json.dumps(base,ensure_ascii=False,indent=2)+'\n').encode()
files['BUILD.md']='Node.js22+。解压到空目录，执行 npm ci、npm test、npm run typecheck、npm run build -- B05。产物tools/B05-预算版本与假设对比/candidate/0.1.0。本包仅本款和共享依赖，未含node_modules/凭据/业务数据。\n'.encode()
for basepath in [folder,root/'packages/core',root/'packages/ui']:
 for p in sorted(basepath.rglob('*')):
  if p.is_file() and not any(x in p.parts for x in ['candidate','node_modules','__pycache__']):files[str(p.relative_to(root))]=p.read_bytes()
files['references/saxes-5.0.1-LICENSE']=(root/'references/saxes-5.0.1-LICENSE').read_bytes()
files['THIRD_PARTY_NOTICES.md']=(out/'THIRD_PARTY_NOTICES.md').read_bytes()
with zipfile.ZipFile(out/'B05-0.1.0-源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
 z.writestr('source-snapshot.json',json.dumps({'schema_version':1,'tool':'B05','version':'0.1.0','file_sha256':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}},ensure_ascii=False,indent=2))
with zipfile.ZipFile(out/'B05-0.1.0-离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.iterdir()):
  if p.is_file() and p.suffix!='.zip':z.write(p,'B05/'+p.name)
print('isolated source and offline candidates packaged')
