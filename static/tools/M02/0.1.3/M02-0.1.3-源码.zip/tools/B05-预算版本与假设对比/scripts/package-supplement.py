import pathlib,zipfile,json,hashlib,shutil
root=pathlib.Path.cwd();folder=root/'tools/B05-预算版本与假设对比';old=folder/'candidate/0.1.0';out=folder/'candidate/0.1.0-supplement';out.mkdir(exist_ok=True)
for p in old.iterdir():
 if p.is_file() and p.suffix!='.zip':shutil.copyfile(p,out/p.name)
for src,dst in [('README.md','使用说明.md'),('财务规则.md','财务规则.md'),('参考来源.md','参考来源.md')]:shutil.copyfile(folder/src,out/dst)
base=json.loads((root/'package.json').read_text());base['scripts']={'test':'node --import tsx --test tools/B05-预算版本与假设对比/tests/*.test.ts','typecheck':'tsc --noEmit -p tools/B05-预算版本与假设对比/tsconfig.json','build':'node --import tsx tools/B05-预算版本与假设对比/scripts/build.ts'}
files={n:(root/n).read_bytes() for n in ['package-lock.json','tsconfig.json']};files['package.json']=(json.dumps(base,ensure_ascii=False,indent=2)+'\n').encode();files['BUILD.md']='Node22+，在空目录执行 npm ci、npm test、npm run typecheck、npm run build -- B05，输出candidate/0.1.0。仅本款隔离，无node_modules/凭据/业务数据。新增独立预期：python3 tools/B05-预算版本与假设对比/tests/supplement/oracle.py；浏览器：node --import tsx tools/B05-预算版本与假设对比/tests/supplement/browser.ts，B05_CHROMIUM指定本机Chromium，B05_SUPPLEMENT_PROGRAM指定程序目录，B05_SUPPLEMENT_OUT指定证据输出。620键十类显式Python Decimal预期，无产品实现导入。\n'.encode()
for bp in [folder,root/'packages/core',root/'packages/ui']:
 for p in bp.rglob('*'):
  if p.is_file() and not any(n in p.parts for n in ['candidate','node_modules','__pycache__']):files[str(p.relative_to(root))]=p.read_bytes()
files['references/saxes-5.0.1-LICENSE']=(root/'references/saxes-5.0.1-LICENSE').read_bytes();files['THIRD_PARTY_NOTICES.md']=(out/'THIRD_PARTY_NOTICES.md').read_bytes()
with zipfile.ZipFile(out/'B05-0.1.0-补验源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,d in sorted(files.items()):z.writestr(n,d)
 z.writestr('source-snapshot.json',json.dumps({'schema_version':1,'tool':'B05','version':'0.1.0','file_sha256':{n:hashlib.sha256(d).hexdigest() for n,d in sorted(files.items())}},ensure_ascii=False,indent=2))
with zipfile.ZipFile(out/'B05-0.1.0-离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.iterdir()):
  if p.is_file() and p.suffix!='.zip':z.write(p,'B05/'+p.name)
print('Supplement packaged; original candidate files untouched')
