import type {Table} from '../../../packages/core/types';import {defaultConfig} from './types';
export const headers=['项目','部门','期间','币种','单位','金额','口径版本','销量','单价'];
export function table(name:string,rows:unknown[][]):Table{return {file:name,sheet:'预算',headers,rows:rows.map((v,i)=>({file:name,sheet:'预算',row:i+2,cells:Object.fromEntries(headers.map((h,j)=>[h,v[j]??null])) as any}))}}
export const left=table('虚构原预算.csv',[['A','销售','2026-10','CNY','元','1000','v1','10','100'],['B','销售','2026-10','CNY','元','200','v1',null,null],['C','销售','2026-10','CNY','元','-50','v1',null,null],['E','销售','2026-10','CNY','元','80','v1',null,null],['Z','销售','2026-10','CNY','元','0','v1',null,null]]);
export const right=table('虚构新预算.csv',[['A','销售','2026-10','CNY','元','1320','v1','12','110'],['C','销售','2026-10','CNY','元','-60','v1',null,null],['D','销售','2026-10','CNY','元','300','v1',null,null],['E','销售','2026-10','CNY','元','90','v2',null,null],['Z','销售','2026-10','CNY','元','0','v1',null,null]]);
export const exampleConfig={...defaultConfig(),assumptions:[{left:'销量',right:'销量'},{left:'单价',right:'单价'}]};
