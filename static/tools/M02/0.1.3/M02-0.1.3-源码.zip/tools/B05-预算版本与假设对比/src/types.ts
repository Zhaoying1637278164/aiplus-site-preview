import type {Table,SourceRow} from '../../../packages/core/types';
export const VERSION='0.1.1';export const RULE_VERSION='B05-2026-10-04.1';
export interface Pair {left:string;right:string}
export interface Config {dimensions:Pair[];amount:Pair;period:Pair;currency:Pair;unit:Pair;basis:Pair;assumptions:Pair[];trim:boolean;duplicates:'block'|'aggregate';tolerance:string;materiality:string;oldName:string;newName:string;note:string}
export type Status='新增'|'删除'|'金额变化'|'相同'|'口径变化'|'待复核';
export interface Item {key:string;partition:string;status:Status;oldAmount:string|null;newAmount:string|null;delta:string|null;material:boolean;reason:string;assumptions:{field:string;old:string|null;next:string|null;status:string}[];left:SourceRow[];right:SourceRow[]}
export interface Result {items:Item[];bridges:{partition:string;old:string;added:string;deleted:string;change:string;next:string;residual:string;blockedOld:string;blockedNew:string;blockedRows:number}[];leftRows:number;rightRows:number;config:Config;app_version:string;rule_version:string}
export interface Work {config:Config;left:Table|null;right:Table|null}
export const defaultConfig=():Config=>({dimensions:[{left:'项目',right:'项目'},{left:'部门',right:'部门'}],amount:{left:'金额',right:'金额'},period:{left:'期间',right:'期间'},currency:{left:'币种',right:'币种'},unit:{left:'单位',right:'单位'},basis:{left:'口径版本',right:'口径版本'},assumptions:[],trim:false,duplicates:'block',tolerance:'0',materiality:'100',oldName:'原预算',newName:'新预算',note:''});
