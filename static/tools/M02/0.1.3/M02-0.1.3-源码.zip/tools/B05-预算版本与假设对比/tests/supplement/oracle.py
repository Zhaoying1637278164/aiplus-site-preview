# Independent Python Decimal oracle: constructs labelled cases; never imports product modules.
import pathlib,json,csv,decimal
D=decimal.Decimal; decimal.getcontext().prec=50
root=pathlib.Path(__file__).resolve().parent;out=root/'fixtures';out.mkdir(exist_ok=True)
H=['项目','部门','期间','币种','单位','金额','口径版本','销量','单价']
config={'dimensions':[{'left':'项目','right':'项目'},{'left':'部门','right':'部门'}],'amount':{'left':'金额','right':'金额'},'period':{'left':'期间','right':'期间'},'currency':{'left':'币种','right':'币种'},'unit':{'left':'单位','right':'单位'},'basis':{'left':'口径版本','right':'口径版本'},'assumptions':[{'left':'销量','right':'销量'},{'left':'单价','right':'单价'}],'trim':False,'duplicates':'block','tolerance':'0.01','materiality':'100','oldName':'原预算','newName':'新预算','note':''}
def j(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def n(x):return format(x,'f').rstrip('0').rstrip('.') if '.' in format(x,'f') else str(x)
L=[];R=[];groups=[]
for i in range(620):
 id=f'P{i:04}';mode=i%10;part=['2026-10' if i%3 else '2026-11','CNY' if i%2 else 'USD','元' if i%5 else '万元'];a=str(i+1);b=a;lx=[[id,'虚构部门',*part,a,'v1','10','2']];rx=[[id,'虚构部门',*part,b,'v1','10','2']]
 if mode==1:rx[0][5]=str(i+151);rx[0][7]='12'
 if mode==2:rx=[]
 if mode==3:lx=[]
 if mode==4:rx[0][6]='v2'
 if mode==5:lx[0][5]=None
 if mode==6:lx[0][5]='-5';rx[0][5]='-7'
 if mode==7:lx[0][5]='0.100001';rx[0][5]='0.100002'
 if mode==8:lx[0][5]='1';lx.append([id,'虚构部门',*part,'2','v1','10','2']);rx[0][5]='4'
 if mode==9:lx[0][5]='1';lx.append([id,'虚构部门',*part,'2','v1','11','2']);rx[0][5]='4'
 lrefs=[];rrefs=[]
 for row in lx:L.append(row);lrefs.append(['大批原版本.csv','CSV',len(L)+1])
 for row in rx:R.append(row);rrefs.append(['大批新版本.csv','CSV',len(R)+1])
 groups.append({'id':id,'part':part,'mode':mode,'l':lx,'r':rx,'lr':lrefs,'rr':rrefs})
# Order defined by first appearance in old file, then new-only keys.
groups.sort(key=lambda g:(not bool(g['l']),g['id']))
for name,rows in [('大批原版本.csv',L),('大批新版本.csv',R)]:
 with open(out/name,'w',encoding='utf-8-sig',newline='') as f:csv.writer(f).writerows([H,*rows])
headers=[['业务键','分区','状态','原金额','新金额','差额','重要','说明','原来源','新来源'],['期间币种单位','原可比','新增','删除','共同变动','新可比','残差','阻塞原金额','阻塞新金额','阻塞来源行数'],['业务键','假设字段','原假设','新假设','比较状态','提示'],['文件','页签','行号',*H],['文件','页签','行号',*H],['项目','内容']]
names=['变化明细','金额桥接','假设对比','原来源','新来源','参数与版本']
def expected(aggregate=False,no_assumptions=False):
 c=dict(config);c['duplicates']='aggregate' if aggregate else 'block';c['assumptions']=[] if no_assumptions else config['assumptions'];changes=[];assumptions=[];bridges={};anomalies=[]
 for g in groups:
  p=' / '.join(g['part']);key=p+' · '+g['id']+' · 虚构部门';mode=g['mode'];reason='';status='相同';a=None if not g['l'] or mode==5 else sum((D(row[5]) for row in g['l']),D(0));b=None if not g['r'] else sum((D(row[5]) for row in g['r']),D(0));delta=None
  if mode==5:status='待复核';reason='缺失值或公式单元格，须提供静态值'
  elif mode in [8,9] and not aggregate:status='待复核';reason='重复比较键，整组待复核'
  elif mode==9 and aggregate and not no_assumptions:status='待复核';reason='汇总组口径或假设冲突'
  elif mode==4:status='口径变化';reason='口径版本不同，金额不可比'
  elif mode==2:status='删除';delta=-a
  elif mode==3:status='新增';delta=b
  else:delta=b-a;status='金额变化' if abs(delta)>D('.01') else '相同'
  row=[key,p,status,None if a is None else n(a),None if b is None else n(b),None if delta is None else n(delta),'是' if delta is not None and abs(delta)>=100 else '否',reason,j(g['lr']),j(g['rr'])];changes.append(row)
  if reason:anomalies.append(row)
  if not no_assumptions:
   for idx,field in [(7,'销量'),(8,'单价')]:
    def vals(rows):return ' | '.join(dict.fromkeys(r[idx] if r[idx] is not None else '〈缺失〉' for r in rows)) if rows else None
    av=vals(g['l']);bv=vals(g['r']);st='缺失/不适用' if av is None or bv is None else '相同' if av==bv else '变化';assumptions.append([key,field+' → '+field,av,bv,st,'假设变化不等于金额归因'])
  z=bridges.setdefault(p,[D(0)]*8+[0])
  if status in ['待复核','口径变化']:z[6]+=sum((D(r[5]) for r in g['l'] if r[5] is not None),D(0));z[7]+=b or D(0);z[8]+=len(g['l'])+len(g['r'])
  else:
   z[0]+=a or D(0);z[4]+=b or D(0)
   if status=='新增':z[1]+=b
   elif status=='删除':z[2]+=a
   else:z[3]+=delta
 bridge_rows=[]
 for p,z in bridges.items():z[5]=z[4]-(z[0]+z[1]-z[2]+z[3]);assert z[5]==0;bridge_rows.append([p,*[n(x) for x in z[:8]],str(z[8])])
 sources=lambda rows,name:[[name,'CSV',str(i+2),*r] for i,r in enumerate(rows)]
 params=[['应用',j('0.1.1')],['规则',j('B05-2026-10-04.1')],['来源行数',j([len(L),len(R)])],['参数',j(c)]]
 matrices=[[headers[i],*rows] for i,rows in enumerate([changes,bridge_rows,assumptions,sources(L,'大批原版本.csv'),sources(R,'大批新版本.csv'),params])]
 normalize=lambda x: '' if x is None else str(x)
 return {'config':c,'sheet_names':names,'matrices':[[[normalize(x) for x in r] for r in mat] for mat in matrices],'anomalies':[[normalize(x) for x in r] for r in anomalies],'item_status':[r[2] for r in changes],'comparison_keys':len(groups),'source_counts':[len(L),len(R)]}
allcases={name:expected(agg,noa) for name,agg,noa in [('block',False,False),('aggregate',True,False),('no-assumptions',True,True)]}
(out/'expected.json').write_text(json.dumps(allcases,ensure_ascii=False,indent=2))
(out/'plan.json').write_text(json.dumps({'schema_version':1,'tool':'B05','app_version':'0.1.1','rule_version':'B05-2026-10-04.1','contains_data':False,'work':{'config':config,'left':None,'right':None}},ensure_ascii=False))
print(json.dumps({'keys':620,'source_rows':[len(L),len(R)],'oracle':'Python Decimal explicit ten-case fixtures, no product imports','export_cells_each':{k:sum(len(r) for mat in v['matrices'] for r in mat) for k,v in allcases.items()}}))
