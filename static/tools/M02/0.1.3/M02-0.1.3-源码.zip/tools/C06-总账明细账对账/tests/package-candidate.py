from pathlib import Path
import zipfile,json,hashlib
root=Path.cwd();folder=root/'tools/C06-总账明细账对账';out=folder/'candidate/0.1.0'
files=[p for p in out.iterdir() if p.is_file() and p.suffix!='.zip']
archive=out/'C06-0.1.0-候选离线包.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.name)
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'progress/evidence/C06/candidate-package.json').write_text(json.dumps({'version':'0.1.0','archive':str(archive.relative_to(root)),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest,'formal_release':False},ensure_ascii=False,indent=2));print('candidate offline zip',len(files),'files',archive.stat().st_size,'bytes')
