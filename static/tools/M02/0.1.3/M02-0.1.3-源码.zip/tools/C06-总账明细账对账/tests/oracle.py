from pathlib import Path
import random,json
random.seed(61004)
def fmt(x):
 sign='-' if x<0 else '';x=abs(x);return sign+str(x//10**6)+('.'+str(x%10**6).zfill(6).rstrip('0') if x%10**6 else '')
def base(a,aux):return {'主体':'虚构算法公司','科目':a,'期间':'2026-09','币种':'CNY','单位':'元','辅助维度':aux}
gl=[];tx=[];bal=[];expected=[]
for i in range(100):
 a='Q'+str(i);opening=random.randint(0,10**9);debits=[random.randint(0,10**7) for j in range(3)];credits=[random.randint(0,10**7) for j in range(3)];db=sum(debits);cr=sum(credits);close=opening+db-cr
 # independent extreme value with a micro-unit difference
 if i==99:opening=999999999999999999000000;db=1;cr=0;debits=[1,0,0];credits=[0,0,0];close=opening+db
 shift=(i%7)*100001;lgclose=close+shift;lgdb=db+shift
 gl.append({**base(a,'汇总'),'期初借方':fmt(max(opening,0)),'期初贷方':fmt(max(-opening,0)),'本期借方':fmt(lgdb),'本期贷方':fmt(cr),'期末借方':fmt(max(lgclose,0)),'期末贷方':fmt(max(-lgclose,0))})
 for j in range(3):tx.append({**base(a,'A'),'行ID':f'{a}-{j}','摘要':'虚构独立算法','本期借方':fmt(debits[j]),'本期贷方':fmt(credits[j])})
 bal.append({**base(a,'A'),'期初借方':fmt(max(opening,0)),'期初贷方':fmt(max(-opening,0)),'期末借方':fmt(max(close,0)),'期末贷方':fmt(max(-close,0))})
 expected.append({'account':a,'right':[fmt(opening),fmt(db),fmt(cr),fmt(close)],'delta':['0',fmt(shift),'0',fmt(shift)],'residual':'0'})
p=Path('tools/C06-总账明细账对账/examples/独立算法预期.json');p.write_text(json.dumps({'algorithm':'Python integer micro-units, seed61004, no TS/Decimal import','gl':gl,'tx':tx,'balance':bal,'expected':expected},ensure_ascii=False,indent=2));print('independent 100 groups generated')
