from pathlib import Path
import subprocess,json,hashlib,time,sys,zipfile,re,shutil
root=Path.cwd();src=root/'progress/evidence/C06/rebuilt-source';log=root/'progress/evidence/C06/source-rebuild.json';results=[]
if src.exists():shutil.rmtree(src)
src.mkdir(parents=True)
with zipfile.ZipFile(root/'progress/evidence/C06/C06-0.1.0-候选源码.zip') as z:
 for n in z.namelist():
  assert not n.startswith('/') and '..' not in Path(n).parts and 'node_modules' not in Path(n).parts,n
 z.extractall(src)
manifest=json.loads((root/'progress/evidence/C06/source-manifest.json').read_text())
assert sorted(manifest)==sorted(str(p.relative_to(src)) for p in src.rglob('*') if p.is_file())
for n,h in manifest.items():assert hashlib.sha256((src/n).read_bytes()).hexdigest()==h,n
print('actual ZIP extraction and all source SHA passed',len(manifest),flush=True)
for command in [['npm','ci','--ignore-scripts','--no-audit','--no-fund','--offline'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]:
 start=time.time();p=subprocess.run(command,cwd=src,capture_output=True,text=True);results.append({'command':command,'cwd':str(src),'exit_code':p.returncode,'seconds':round(time.time()-start,2),'stdout':p.stdout,'stderr':p.stderr});log.write_text(json.dumps({'status':'running' if p.returncode==0 else 'failed','commands':results},ensure_ascii=False,indent=2));print(command,'actual exit',p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
a=root/'tools/C06-总账明细账对账/candidate/0.1.0';b=src/'tools/C06-总账明细账对账/candidate/0.1.0';comparisons=[]
for p in a.iterdir():
 if not p.is_file() or p.suffix=='.zip':continue
 q=b/p.name
 if p.suffix=='.xlsx':
  with zipfile.ZipFile(p) as z1,zipfile.ZipFile(q) as z2:
   assert sorted(z1.namelist())==sorted(z2.namelist());m=[]
   for n in z1.namelist():
    x,y=z1.read(n),z2.read(n)
    assert x==y,n;m.append(n)
  comparisons.append({'file':p.name,'match':'all ZIP member bytes identical; ZIP container timestamps may differ','members':len(m)})
 elif p.name=='build-manifest.json':
  x=json.loads(p.read_text());y=json.loads(q.read_text());x['files'].pop('虚构样例.xlsx');y['files'].pop('虚构样例.xlsx');assert x==y
  comparisons.append({'file':p.name,'match':'manifest identical excluding separately checked XLSX container hash'})
 else:
  h=lambda v:hashlib.sha256(v.read_bytes()).hexdigest()
  assert h(p)==h(q),p.name;comparisons.append({'file':p.name,'sha256':h(p),'byte_identical':True})
log.write_text(json.dumps({'status':'passed','commands':results,'comparisons':comparisons,'scope':'isolated candidate source snapshot; formal package/website by root','windows':'unverified'},ensure_ascii=False,indent=2));print('source rebuild passed',len(comparisons),'assets')
