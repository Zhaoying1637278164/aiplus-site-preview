from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
p=Path('tools/C06-总账明细账对账/tests/fixtures');p.mkdir(exist_ok=True)
for name,entry,content in [('macro','xl/vbaProject.bin',b'fictional'),('external','xl/externalLinks/externalLink1.xml',b'fictional'),('inflate-overlimit','xl/huge.xml',b'X'*(30*1024*1024+1))]:
 with ZipFile(p/(name+'.xlsx'),'w',ZIP_DEFLATED) as z:z.writestr('[Content_Types].xml','fictional');z.writestr(entry,content)
print('three bounded fake safety fixtures')
