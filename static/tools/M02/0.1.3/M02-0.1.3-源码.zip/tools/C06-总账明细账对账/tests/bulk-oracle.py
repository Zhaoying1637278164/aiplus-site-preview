from pathlib import Path
import json,csv,io
out=Path('tools/C06-总账明细账对账/examples/bulk');out.mkdir(exist_ok=True)
def fmt(n):
 s='-' if n<0 else '';n=abs(n);return s+str(n//1000000)+('.'+str(n%1000000).zfill(6).rstrip('0') if n%1000000 else '')
dims=['主体','科目','期间','币种','单位','辅助维度'];headers={'gl':dims+['期初借方','期初贷方','本期借方','本期贷方','期末借方','期末贷方'],'tx':dims+['行ID','摘要','本期借方','本期贷方'],'balance':dims+['期初借方','期初贷方','期末借方','期末贷方']}
data={s:{'file':f'虚构大批-{s}.csv','sheet':'CSV','headers':h,'rows':[]} for s,h in headers.items()};expected=[];issues=[]
def add(s,c):
 t=data[s];r={'file':t['file'],'sheet':'CSV','row':len(t['rows'])+2,'cells':c};t['rows'].append(r);return r
for i in range(604):
 account=f'B{i:04d}';base={'主体':'虚构大批公司','科目':account,'期间':'2026-09','币种':'USD' if i%3==1 else 'CNY','单位':'万元' if i%5==1 else '元','辅助维度':'辅助A'}
 opening=(i+1)*100000001*(-1 if i%4==1 else 1);ds=[(i+2)*10001,(i+3)*20003];cs=[(i+1)*3001,(i+4)*7003]
 if i%11==0:ds[0]=-ds[0]
 debit=sum(ds);credit=sum(cs);closing=opening+debit-credit
 # four independent deltas, sometimes zero; deliberately nonzero GL residuals
 delta=[((i%7)-3)*100001,((i%9)-4)*70001,((i%5)-2)*30001,((i%13)-6)*10001]
 if i%17==0:delta=[0,0,0,0]
 left=[opening+delta[0],debit+delta[1],credit+delta[2],closing+delta[3]];right=[opening,debit,credit,closing]
 g=add('gl',{**base,'期初借方':fmt(max(left[0],0)),'期初贷方':fmt(max(-left[0],0)),'本期借方':fmt(left[1]),'本期贷方':fmt(left[2]),'期末借方':fmt(max(left[3],0)),'期末贷方':fmt(max(-left[3],0))})
 tx=[add('tx',{**base,'行ID':f'T{i:04d}-{j}','摘要':f'虚构流水尾部定位{i}-{j}','本期借方':fmt(ds[j]),'本期贷方':fmt(cs[j])}) for j in range(2)]
 b=add('balance',{**base,'期初借方':fmt(max(opening,0)),'期初贷方':fmt(max(-opening,0)),'期末借方':fmt(max(closing,0)),'期末贷方':fmt(max(-closing,0))})
 dimensions=[base[h] for h in dims[:5]];key=json.dumps(dimensions,ensure_ascii=False,separators=(',',':'));res=left[0]+left[1]-left[2]-left[3]
 negative=left[1]<0 or left[2]<0 or any(v<0 for v in ds+cs)
 status='勾稽异常' if res else '存在差异' if any(delta) else '金额一致待复核' if negative else '容差内一致'
 expected.append({'key':key,'dimensions':dimensions,'status':status,'left':list(map(fmt,left)),'right':list(map(fmt,right)),'delta':list(map(fmt,delta)),'glResidual':fmt(res),'detailResidual':'0','sources':{'gl':[g],'tx':tx,'balance':[b]}})
 for s,rows in [('gl',[g]),('tx',tx)]:
  for r in rows:
   if any(r['cells'][h].startswith('-') for h in ['本期借方','本期贷方']):issues.append([s,r])
# independent lexicographic order matches padded account keys and single org
issues.sort(key=lambda v:(['gl','tx','balance'].index(v[0]),v[1]['row']))
obj={'algorithm':'Python integer micro-units,604 groups/1208 flows; no engine imports','data':data,'expected':expected,'issues':issues}
(out/'oracle.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2))
for s,t in data.items():
 buf=io.StringIO();w=csv.writer(buf);w.writerow(t['headers']);w.writerows([r['cells'][h] for h in t['headers']] for r in t['rows']);(out/t['file']).write_text('\ufeff'+buf.getvalue())
print('independent604 groups,1208 flows,',len(issues),'warnings generated before execution')
