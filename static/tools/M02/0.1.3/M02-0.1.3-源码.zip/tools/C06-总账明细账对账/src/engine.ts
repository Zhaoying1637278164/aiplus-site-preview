import Decimal from 'decimal.js';
import {amount,text} from '../../../packages/core/value';
import {LIMITS,type Table,type SourceRow} from '../../../packages/core/types';
export type Side='gl'|'tx'|'balance';
export const sides:Side[]=['gl','tx','balance'];
export const labels:Record<Side,string>={gl:'总账余额表',tx:'明细流水',balance:'辅助余额'};
export const dims=['主体','科目','期间','币种','单位','辅助维度'] as const;
export const money={gl:['期初借方','期初贷方','本期借方','本期贷方','期末借方','期末贷方'],tx:['本期借方','本期贷方'],balance:['期初借方','期初贷方','期末借方','期末贷方']};
export const fields=(s:Side)=>[...dims,...(s==='tx'?['行ID','摘要']:[]),...money[s]];
export interface MapRow {side:Side;field:'主体'|'科目'|'期间';from:string;to:string}
export interface Rule {period:string;orgs:string[];accounts:string[];aux:boolean;identity:boolean;tolerance:string;mapping:MapRow[];columns:Record<Side,Record<string,string>>}
export interface Data {gl:Table|null;tx:Table|null;balance:Table|null}
export interface Issue {side:Side;source:SourceRow;message:string;key:string|null;kind:'错误'|'复核'|'范围外'}
export interface Group {key:string;dimensions:string[];status:string;gl:SourceRow[];tx:SourceRow[];balance:SourceRow[];left:(string|null)[];right:(string|null)[];delta:(string|null)[];glResidual:string|null;detailResidual:string|null;issues:Issue[]}
export interface Result {groups:Group[];issues:Issue[];globalBlocked:boolean;coverage:Record<Side,{input:number;included:number;excluded:number;invalid:number}>}
export const indicators=['期初净额','本期借方','本期贷方','期末净额'];
export function defaultRule():Rule{return {period:'2026-09',orgs:[],accounts:[],aux:false,identity:true,tolerance:'0.00',mapping:[],columns:Object.fromEntries(sides.map(s=>[s,Object.fromEntries(fields(s).map(h=>[h,h]))])) as Rule['columns']}}
export function validateRule(r:Rule){
 if(!r||!/^\d{4}-(0[1-9]|1[0-2])$/.test(r.period)||typeof r.aux!=='boolean'||typeof r.identity!=='boolean'||!Array.isArray(r.orgs)||!Array.isArray(r.accounts)||[...r.orgs,...r.accounts].some(v=>typeof v!=='string'||!v.trim()||v.length>1000)||r.orgs.length+r.accounts.length>1000)throw Error('核对范围参数无效');
 if(typeof r.tolerance!=='string'||amount(r.tolerance).isNegative())throw Error('容差须为非负十进制');
 if(!Array.isArray(r.mapping)||r.mapping.length>5000)throw Error('映射最多5000条');
 const seen=new Set<string>();for(const m of r.mapping){if(!m||!sides.includes(m.side)||!['主体','科目','期间'].includes(m.field)||typeof m.from!=='string'||typeof m.to!=='string'||!m.from.trim()||!m.to.trim()||m.from.length>1000||m.to.length>1000)throw Error('映射原值目标必填');const k=JSON.stringify([m.side,m.field,m.from.trim()]);if(seen.has(k))throw Error('映射重复或存在多目标');seen.add(k)}
 for(const s of sides){if(!r.columns?.[s])throw Error('字段映射缺失');const cols=fields(s).filter(h=>h!=='摘要'&&(h!=='辅助维度'||r.aux||s==='balance'));for(const h of cols)if(typeof r.columns[s][h]!=='string'||!r.columns[s][h])throw Error(labels[s]+'字段映射缺失 '+h);if(new Set(cols.map(h=>r.columns[s][h])).size!==cols.length)throw Error(labels[s]+'多个字段映射同一列')}
}
export function validateTable(t:Table){
 if(!t||typeof t.file!=='string'||typeof t.sheet!=='string'||!Array.isArray(t.headers)||!t.headers.length||t.headers.length>LIMITS.columns||t.headers.some(h=>typeof h!=='string'||!h.trim()||h.length>10000)||new Set(t.headers).size!==t.headers.length||!Array.isArray(t.rows)||t.rows.length>LIMITS.rows)throw Error('表格格式或行列超限');
 const seen=new Set<number>();for(const r of t.rows){if(!r||r.file!==t.file||r.sheet!==t.sheet||!Number.isInteger(r.row)||r.row<1||seen.has(r.row)||!r.cells||typeof r.cells!=='object'||Array.isArray(r.cells)||Object.keys(r.cells).some(k=>!t.headers.includes(k)))throw Error('原始来源格式无效');seen.add(r.row);for(const h of t.headers){const v=r.cells[h];if(v===undefined||!(v===null||typeof v==='string'||typeof v==='number'||(typeof v==='object'&&typeof v.formula==='string')))throw Error('单元格类型无效');if(typeof v==='string'&&v.length>10000)throw Error('单元格文本超限');}}
}
export function reconcile(data:Data,rule:Rule):Result{
 validateRule(rule);const tol=amount(rule.tolerance),issues:Issue[]=[],groups=new Map<string,Group>(),valid=new Map<string,Record<Side,{source:SourceRow;v:Decimal[];aux:string;dup:string}[]>>(),coverage=Object.fromEntries(sides.map(s=>[s,{input:0,included:0,excluded:0,invalid:0}])) as Result['coverage'];let globalBlocked=false;
 for(const side of sides){const table=data[side];if(!table)continue;validateTable(table);coverage[side].input=table.rows.length;const get=(row:SourceRow,h:string)=>row.cells[rule.columns[side][h]];
 const normalized=(row:SourceRow,h:'主体'|'科目'|'期间')=>{const v=text(get(row,h),true),m=rule.mapping.find(m=>m.side===side&&m.field===h&&m.from.trim()===v);if(m)return m.to.trim();if(rule.identity)return v;throw Error(h+'未映射：'+v)};
 for(const source of table.rows){let key:string|null=null,g:Group|undefined;const add=(message:string,kind:Issue['kind']='错误')=>{const i={side,source,message,key,kind};issues.push(i);g?.issues.push(i)};
 try{
 if(Object.values(source.cells).some(v=>v!==null&&typeof v==='object'))throw Error('存在公式/错误单元格，请提供静态值');
 const org=normalized(source,'主体'),acct=normalized(source,'科目'),period=normalized(source,'期间');if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(period))throw Error('期间须为YYYY-MM');
 if(period!==rule.period||(rule.orgs.length&&!rule.orgs.includes(org))||(rule.accounts.length&&!rule.accounts.includes(acct))){add('不在本次核对范围','范围外');coverage[side].excluded++;continue}
 const curr=text(get(source,'币种'),true),unit=text(get(source,'单位'),true),aux=(rule.aux||side==='balance')?text(get(source,'辅助维度'),true):'';const dimensions=[org,acct,period,curr,unit,...(rule.aux?[aux]:[])];key=JSON.stringify(dimensions);g=groups.get(key);if(!g){g={key,dimensions,status:'',gl:[],tx:[],balance:[],left:[null,null,null,null],right:[null,null,null,null],delta:[null,null,null,null],glResidual:null,detailResidual:null,issues:[]};groups.set(key,g);valid.set(key,{gl:[],tx:[],balance:[]})}g[side].push(source);
 const v=money[side].map(h=>{const raw=get(source,h);if(typeof raw==='number'&&String(raw).replace(/[^0-9]/g,'').length>15)throw Error(h+'数值超过15位可靠精度，请使用文本金额');const n=amount(raw);if(!h.startsWith('本期')&&n.isNegative())throw Error(h+'余额不得负数');return n});
 if(side!=='tx'){const q=side==='gl'?[0,1,4,5]:[0,1,2,3];if((!v[q[0]].isZero()&&!v[q[1]].isZero())||(!v[q[2]].isZero()&&!v[q[3]].isZero()))throw Error('同一原行余额借贷双边非零')}
 if(v.some((n,i)=>money[side][i].startsWith('本期')&&n.isNegative()))add('负发生额/冲销，请复核原凭证','复核');
 const dup=side==='tx'?JSON.stringify([text(get(source,'主体'),true),text(get(source,'期间'),true),text(get(source,'行ID'),true)]):side==='balance'?JSON.stringify([org,acct,period,curr,unit,aux]):key;
 valid.get(key)![side].push({source,v,aux,dup});coverage[side].included++;
 }catch(e){coverage[side].invalid++;if(!key)globalBlocked=true;add(e instanceof Error?e.message:String(e));}}
 }
 for(const side of sides){const all=new Map<string,{g:Group;source:SourceRow}[]>();for(const g of groups.values())for(const r of valid.get(g.key)![side]){const bucket=all.get(r.dup)||[];bucket.push({g,source:r.source});all.set(r.dup,bucket)}for(const bucket of all.values())if(bucket.length>1)for(const b of bucket){const i:Issue={side,source:b.source,key:b.g.key,kind:'错误',message:side==='gl'?'总账统一粒度重复':side==='tx'?'流水行ID重复':'辅助余额完整粒度重复'};issues.push(i);b.g.issues.push(i)}}
 for(const g of groups.values()){
 const v=valid.get(g.key)!,sum=(s:Side,i:number)=>v[s].reduce((a,r)=>a.plus(r.v[i]),new Decimal(0));
 if(v.gl.length===1){const a=v.gl[0].v;g.left=[a[0].minus(a[1]).toFixed(),a[2].toFixed(),a[3].toFixed(),a[4].minus(a[5]).toFixed()];g.glResidual=new Decimal(g.left[0]!).plus(g.left[1]!).minus(g.left[2]!).minus(g.left[3]!).toFixed()}
 if(v.tx.length){g.right[1]=sum('tx',0).toFixed();g.right[2]=sum('tx',1).toFixed()}
 if(v.balance.length){g.right[0]=sum('balance',0).minus(sum('balance',1)).toFixed();g.right[3]=sum('balance',2).minus(sum('balance',3)).toFixed()}
 if(g.right.every(x=>x!==null))g.detailResidual=new Decimal(g.right[0]!).plus(g.right[1]!).minus(g.right[2]!).minus(g.right[3]!).toFixed();
 const blocked=globalBlocked||g.issues.some(i=>i.kind==='错误');if(!blocked)g.delta=g.left.map((l,i)=>l!==null&&g.right[i]!==null?new Decimal(l).minus(g.right[i]!).toFixed():null);
 g.status=blocked?'数据异常阻塞':!g.gl.length?'缺总账':!g.tx.length?'缺明细流水':!g.balance.length?'缺辅助余额':(g.glResidual!==null&&amount(g.glResidual).abs().gt(tol))||(g.detailResidual!==null&&amount(g.detailResidual).abs().gt(tol))?'勾稽异常':g.delta.some(x=>x!==null&&amount(x).abs().gt(tol))?'存在差异':g.issues.some(i=>i.kind==='复核')?'金额一致待复核':'容差内一致';
 }
 return {groups:[...groups.values()].sort((a,b)=>a.key.localeCompare(b.key)),issues,globalBlocked,coverage};
}
