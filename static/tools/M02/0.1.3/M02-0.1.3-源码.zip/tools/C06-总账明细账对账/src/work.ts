import {LIMITS} from '../../../packages/core/types';import {validateRule,validateTable,sides,type Rule,type Data} from './engine';import {VERSION,RULE_VERSION} from './version';
export interface Review {category:string;note:string;preparer:string;reviewer:string;state:string}
export interface Work {rule:Rule;data:Data;reviews:Record<string,Review>}
export function encodeWork(w:Work,contains_data:boolean){return JSON.stringify({schema_version:1,tool:'C06',app_version:VERSION,rule_version:RULE_VERSION,contains_data,rule:w.rule,...(contains_data?{data:w.data,reviews:w.reviews}:{})},null,2)}
export function decodeWork(raw:string):Work{
 if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MiB');const x=JSON.parse(raw);if(x?.schema_version!==1||x?.tool!=='C06'||(x.app_version!==VERSION&&x.app_version!=='0.1.0')||x.rule_version!==RULE_VERSION||typeof x.contains_data!=='boolean')throw Error('方案版本不兼容');validateRule(x.rule);
 const data:Data={gl:null,tx:null,balance:null},reviews:Record<string,Review>={};
 if(x.contains_data){if(!x.data||!x.reviews||typeof x.reviews!=='object'||Array.isArray(x.reviews))throw Error('含数据方案资料/复核无效');for(const s of sides){if(x.data[s]!==null){validateTable(x.data[s]);data[s]=x.data[s]}}if(Object.keys(x.reviews).length>60000)throw Error('复核记录超限');for(const [k,v] of Object.entries(x.reviews) as [string,Review][]){if(k.length>10000||!v||typeof v!=='object'||!['category','note','preparer','reviewer','state'].every(f=>typeof (v as any)[f]==='string'&&(v as any)[f].length<=10000)||!['未复核','处理中','已复核'].includes(v.state)||!['待查','期间差异','漏记/重复','映射问题','其他'].includes(v.category)||v.state==='已复核'&&(!v.note.trim()||!v.preparer.trim()||!v.reviewer.trim()||v.preparer.trim()===v.reviewer.trim()))throw Error('复核格式或职责分离无效');reviews[k]=v}}
 else if('data' in x||'reviews' in x)throw Error('无数据方案不允许夹带资料');
 return {rule:JSON.parse(JSON.stringify(x.rule)),data,reviews};
}
