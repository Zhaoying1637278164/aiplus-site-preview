import {headings} from './labels';
import {workbookBytes} from '../../../packages/core/io';
import {schemas,calculate,type Kind} from './engine';import {differences,inputDifferences,type Work} from './work';
export function sheets(w:Work){const r=calculate(w.data,w.tolerance);const tab=(name:string,rows:object[],headers?:string[])=>({name,headers:(headers||Object.keys(rows[0]||{说明:''})).map(x=>headings[x]||x),rows:rows.map(x=>(headers||Object.keys(rows[0]||{})).map(h=>(x as any)[h]))});return [
 ...(['expenses','rules','reversals','changes'] as Kind[]).map((k,i)=>({name:['费用依据','规则','冲回申请','变更依据'][i],headers:[...schemas[k],'来源文件','来源页签','来源行'],rows:(w.data[k]?.rows||[]).map(x=>[...schemas[k].map(h=>x.cells[h]),x.file,x.sheet,x.row])})),
 tab('计划事件',r.events),tab('逐期余额',r.balances),tab('分录',r.entries),tab('异常',r.issues),tab('币种单位勾稽',r.totals),tab('版本差异',differences(w.history.at(-1)?.result,r)),tab('原始资料规则变更',inputDifferences(w.history.at(-1)?.data,w.data)),tab('确认索引',w.history.map(s=>({版本:s.id,确认人:s.reviewer,依据:s.basis,时间:s.time}))),tab('参数版本',[{应用:r.appVersion,规则:r.ruleVersion,容差:w.tolerance,金额精度:2,入账:'不自动入账'}])]}
export const exportWorkbook=(w:Work)=>workbookBytes(sheets(w));
