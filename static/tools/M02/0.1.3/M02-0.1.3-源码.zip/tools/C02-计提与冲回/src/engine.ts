import DecimalJS from 'decimal.js';
const Decimal=DecimalJS.clone({precision:40,rounding:DecimalJS.ROUND_HALF_UP});
type Decimal=DecimalJS;
import type {Table,SourceRow} from '../../../packages/core/types';
import {VERSION,RULE_VERSION} from './version';
export const schemas={expenses:['事项ID','部门','期间','金额','币种','单位','规则ID','依据','计提决定'],rules:['规则ID','规则版本','生效起','生效止','比例','冲回方式','借方科目','贷方科目','借方比例','贷方比例','币种','单位','依据'],reversals:['冲回ID','事项ID','期间','方式','金额','币种','单位','依据'],changes:['变更ID','事项ID','生效期','新计提总额','币种','单位','依据']} as const;
export type Kind=keyof typeof schemas;
export type Data=Record<Kind,Table|null>;
export const emptyData=():Data=>({expenses:null,rules:null,reversals:null,changes:null});
export const text=(r:SourceRow,k:string)=>{const v=r.cells[k];return typeof v==='string'||typeof v==='number'?String(v).trim():''};
export const location=(r:SourceRow)=>`${r.file} / ${r.sheet} / 第${r.row}行`;
export const period=(s:string)=>/^\d{4}-(0[1-9]|1[0-2])$/.test(s)&&s>='1900-01'&&s<='9998-12';
export function next(s:string){const [y,m]=s.split('-').map(Number);return `${m===12?y+1:y}-${String(m===12?1:m+1).padStart(2,'0')}`}
export function number(s:string,scale=2){if(!new RegExp(`^\\d+(?:\\.\\d{1,${scale}})?$`).test(s)||s.length>22)throw Error('缺失、负数或精度不合规');const d=new Decimal(s);if(d.gt('999999999999999'))throw Error('金额超限');return d}
const money=(d:Decimal)=>d.toDecimalPlaces(2,Decimal.ROUND_HALF_UP).toFixed(2);
export interface Issue {level:'阻塞'|'提醒';kind:string;id:string;message:string;source:string}
export interface Event {id:string;item:string;period:string;type:string;amount:string;currency:string;unit:string;rule:string;ruleVersion:string;basis:string;source:string;expenseSource:string;ruleSource:string}
export interface Entry {event:string;item:string;period:string;account:string;debit:string;credit:string;currency:string;unit:string;source:string}
export interface Balance {item:string;period:string;currency:string;unit:string;opening:string;accrual:string;reversal:string;closing:string;residual:string}
export interface Result {events:Event[];entries:Entry[];balances:Balance[];issues:Issue[];totals:{currency:string;unit:string;accrual:string;reversal:string;balance:string;debit:string;credit:string;difference:string}[];canConfirm:boolean;appVersion:string;ruleVersion:string}
export function calculate(data:Data,tolerance='0.00'):Result {
 const issues:Issue[]=[],events:Event[]=[],entries:Entry[]=[],balances:Balance[]=[];
 const issue=(kind:string,r:SourceRow,message:string,level:Issue['level']='阻塞')=>issues.push({level,kind,id:text(r,schemas[kind as Kind]?.[0]||'事项ID'),message,source:location(r)});
 try{number(tolerance)}catch{issues.push({level:'阻塞',kind:'参数',id:'',message:'容差无效',source:'用户参数'})}
 const duplicate=new Map<Kind,Set<string>>();
 for(const kind of Object.keys(schemas) as Kind[]){const t=data[kind];const bad=new Set<string>();duplicate.set(kind,bad);if(!t)continue;
 if(schemas[kind].some(h=>!t.headers.includes(h))){issues.push({level:'阻塞',kind,id:'',message:'表头缺少：'+schemas[kind].filter(h=>!t.headers.includes(h)).join('、'),source:t.file});continue}
 const seen=new Set<string>();for(const r of t.rows){const id=text(r,schemas[kind][0]);if(!id||seen.has(id))bad.add(id);seen.add(id);if(Object.values(r.cells).some(v=>v!==null&&typeof v==='object')){bad.add(id);issue(kind,r,'包含公式或错误单元格，禁止使用缓存值')} }
 for(const r of t.rows)if(bad.has(text(r,schemas[kind][0])))issue(kind,r,'缺失或重复ID/公式行，整组阻塞');
 }
 const rules=new Map<string,SourceRow>();
 for(const r of data.rules?.rows||[]){const id=text(r,'规则ID');if(duplicate.get('rules')!.has(id))continue;let valid=true;
 const fail=(s:string)=>{valid=false;issue('rules',r,s)};
 if(!text(r,'规则版本')||!text(r,'依据'))fail('规则版本及依据必填');
 if(!period(text(r,'生效起'))||!period(text(r,'生效止'))||text(r,'生效起')>text(r,'生效止'))fail('规则生效期无效');
 if(!['手工','次期全额'].includes(text(r,'冲回方式')))fail('冲回方式仅手工或次期全额');
 if(!/^[A-Z]{3}$/.test(text(r,'币种'))||!text(r,'单位'))fail('币种须三位大写且单位必填');
 for(const k of ['比例','借方比例','贷方比例'])try{const n=number(text(r,k),6);if(n.gt(k==='比例'?1:10)||k!=='比例'&&n.lte(0))fail(k+'超出允许范围（借贷比例必须正数）')}catch{fail(k+'缺失或负值/精度超限')}
 if(!text(r,'借方科目')||!text(r,'贷方科目')||text(r,'借方科目')===text(r,'贷方科目'))fail('未映射科目或借贷科目相同');
 if(valid)rules.set(id,r);
 }
 const known=new Set((data.expenses?.rows||[]).map(r=>text(r,'事项ID')));
 for(const kind of ['reversals','changes'] as Kind[])for(const r of data[kind]?.rows||[])if(!known.has(text(r,'事项ID')))issue(kind,r,'找不到费用事项');
 for(const r of data.expenses?.rows||[]){const item=text(r,'事项ID');if(duplicate.get('expenses')!.has(item))continue;
 const fail=(s:string)=>issue('expenses',r,s),decision=text(r,'计提决定');
 if(!['计提','不计提'].includes(decision)){fail('用户尚未决定是否计提');continue}
 if(!text(r,'依据')||!text(r,'部门')){fail('依据和部门必填');continue}
 if(decision==='不计提'){for(const kind of ['reversals','changes'] as Kind[])for(const x of data[kind]?.rows||[])if(text(x,'事项ID')===item)issue(kind,x,'事项用户决定不计提，不能冲回或变更');continue;}
 const rule=rules.get(text(r,'规则ID')),p=text(r,'期间'),currency=text(r,'币种'),unit=text(r,'单位');
 if(!rule){fail('规则缺失或无效');continue}
 if(!period(p)||p<text(rule,'生效起')||p>text(rule,'生效止')){fail('计提期无效或规则尚未生效/已失效');continue}
 if(currency!==text(rule,'币种')||unit!==text(rule,'单位')){fail('币种单位与规则不一致；不换汇/不换算');continue}
 let total:Decimal;try{total=new Decimal(money(number(text(r,'金额')).mul(number(text(rule,'比例'),6))))}catch{fail('金额缺失、负值或精度超限');continue}
 if(total.isZero())issue('expenses',r,'零计提金额，不生成分录','提醒');
 const own:Event[]=[];const push=(id:string,date:string,type:string,amount:Decimal,origin:SourceRow,basis:string)=>{own.push({id,item,period:date,type,amount:money(amount),currency,unit,rule:text(rule,'规则ID'),ruleVersion:text(rule,'规则版本'),basis,source:location(origin),expenseSource:location(r),ruleSource:location(rule)})};
 push('计提:'+item,p,'计提',total,r,text(r,'依据'));
 const rs=(data.reversals?.rows||[]).filter(x=>text(x,'事项ID')===item),cs=(data.changes?.rows||[]).filter(x=>text(x,'事项ID')===item);
 if(text(rule,'冲回方式')==='次期全额'){
 if(rs.length||cs.length){for(const x of rs)issue('reversals',x,'次期全额规则不得叠加手工请求');for(const x of cs)issue('changes',x,'次期全额规则不得叠加变更，请改为手工规则')}
 else push('自动冲回:'+item,next(p),'冲回',total.neg(),r,'规则次期全额：'+text(rule,'依据'));
 }else{
 const repeated=(rows:SourceRow[],key:string)=>{const count=new Map<string,number>();for(const x of rows)count.set(text(x,key),(count.get(text(x,key))||0)+1);return rows.some(x=>(count.get(text(x,key))||0)>1)};
 const badRS=repeated(rs,'期间'),badCS=repeated(cs,'生效期');if(badRS)rs.forEach(x=>issue('reversals',x,'同事项同期间重复冲回，整组阻塞'));if(badCS)cs.forEach(x=>issue('changes',x,'同事项同生效期重复变更，整组阻塞'));
 let reversed=new Decimal(0),target=total;
 const ops=[...(!badCS?cs.map(x=>({x,kind:'changes' as const,date:text(x,'生效期')})):[]),...(!badRS?rs.map(x=>({x,kind:'reversals' as const,date:text(x,'期间')})):[])].sort((a,b)=>a.date.localeCompare(b.date)||(a.kind===b.kind?0:a.kind==='changes'?-1:1));
 for(const {x,kind,date} of ops){if(duplicate.get(kind)!.has(text(x,schemas[kind][0])))continue;
 if(!period(date)||date<=p){issue(kind,x,'冲回/变更期必须晚于计提期');continue}
 if(text(x,'币种')!==currency||text(x,'单位')!==unit||!text(x,'依据')){issue(kind,x,'币种单位不一致或依据缺失');continue}
 try{
 if(kind==='changes'){const n=number(text(x,'新计提总额'));if(target.eq(reversed)||n.lt(reversed))throw Error('已冲完或新总额低于累计冲回');push('变更:'+text(x,'变更ID'),date,'变更',n.minus(target),x,text(x,'依据'));target=n}
 else{const mode=text(x,'方式');if(!['部分','全额'].includes(mode))throw Error('冲回方式无效');if(mode==='全额'&&text(x,'金额'))throw Error('全额冲回金额须留空');const n=mode==='全额'?target.minus(reversed):number(text(x,'金额'));if(n.lte(0)||n.gt(target.minus(reversed)))throw Error('零、超额或重复冲回');push('冲回:'+text(x,'冲回ID'),date,'冲回',n.neg(),x,text(x,'依据'));reversed=reversed.plus(n)}
 }catch(e){issue(kind,x,String(e instanceof Error?e.message:e))}
 }
 }
 events.push(...own);
 let opening=new Decimal(0);const dates=own.map(x=>x.period).sort();if(dates.length){let date=dates[0],last=dates.at(-1)!;let count=0;while(date<=last){if(++count>1200){fail('期间跨度超过100年');break}const group=own.filter(x=>x.period===date),ac=group.filter(x=>x.type!=='冲回').reduce((a,x)=>a.plus(x.amount),new Decimal(0)),rev=group.filter(x=>x.type==='冲回').reduce((a,x)=>a.minus(x.amount),new Decimal(0)),closing=opening.plus(ac).minus(rev);balances.push({item,period:date,currency,unit,opening:money(opening),accrual:money(ac),reversal:money(rev),closing:money(closing),residual:'0.00'});opening=closing;date=next(date)}}
 for(const e of own){const amt=new Decimal(e.amount);if(amt.isZero())continue;const d=money(amt.abs().mul(text(rule,'借方比例'))),c=money(amt.abs().mul(text(rule,'贷方比例'))),positive=amt.gt(0);entries.push({event:e.id,item,period:e.period,account:text(rule,'借方科目'),debit:positive?d:'0.00',credit:positive?'0.00':d,currency,unit,source:e.source},{event:e.id,item,period:e.period,account:text(rule,'贷方科目'),debit:positive?'0.00':c,credit:positive?c:'0.00',currency,unit,source:e.source});if(d!==c)issue('expenses',r,`事件${e.id}借贷不平衡：${money(new Decimal(d).minus(c))}`)}
 }
 events.sort((a,b)=>a.period.localeCompare(b.period)||a.id.localeCompare(b.id));
 const keys=[...new Set(events.map(e=>JSON.stringify([e.currency,e.unit])))];const totals=keys.map(k=>{const [currency,unit]=JSON.parse(k) as [string,string],es=events.filter(x=>x.currency===currency&&x.unit===unit),js=entries.filter(x=>x.currency===currency&&x.unit===unit),sum=(xs:any[],f:string)=>xs.reduce((a,x)=>a.plus(x[f]),new Decimal(0)),ac=sum(es.filter(x=>x.type!=='冲回'),'amount'),rev=sum(es.filter(x=>x.type==='冲回'),'amount').neg(),d=sum(js,'debit'),c=sum(js,'credit');return {currency,unit,accrual:money(ac),reversal:money(rev),balance:money(ac.minus(rev)),debit:money(d),credit:money(c),difference:money(d.minus(c))}});
 if(!data.expenses?.rows.length||!data.rules?.rows.length)issues.push({level:'阻塞',kind:'资料',id:'',message:'请导入费用依据及规则',source:'资料入口'});
 return {events,entries,balances,issues,totals,canConfirm:!issues.some(x=>x.level==='阻塞'),appVersion:VERSION,ruleVersion:RULE_VERSION};
}
