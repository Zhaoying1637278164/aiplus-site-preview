import {schemas,type Kind,type Data} from './engine';
import type {Table} from '../../../packages/core/types';
export function makeTable(kind:Kind,rows:(string|null)[][],file='虚构'+kind+'.csv'):Table {const headers=[...schemas[kind]];return {file,sheet:'CSV',headers,rows:rows.map((line,i)=>({file,sheet:'CSV',row:i+2,cells:Object.fromEntries(headers.map((h,k)=>[h,line[k]??null]))}))}}
export function example():Data{return {
 expenses:makeTable('expenses',[['F001','行政部','2026-01','1200','CNY','元','AUTO','虚构服务验收单001','计提'],['F002','研发部','2026-01','1200','CNY','元','MANUAL','虚构合同002','计提'],['F003','行政部','2026-01','100','USD','美元','USD','虚构合同003','计提']]),
 rules:makeTable('rules',[['AUTO','v1','2026-01','2026-12','1','次期全额','6602','2241','1','1','CNY','元','虚构已批准规则A'],['MANUAL','v1','2026-01','2026-12','1','手工','6601','2241','1','1','CNY','元','虚构已批准规则B'],['USD','v1','2026-01','2026-12','1','次期全额','6602','2241','1','1','USD','美元','虚构已批准规则C']]),
 reversals:makeTable('reversals',[['R001','F002','2026-02','部分','400','CNY','元','虚构复核001'],['R002','F002','2026-04','全额',null,'CNY','元','虚构结清002']]),
 changes:makeTable('changes',[['V001','F002','2026-03','1500','CNY','元','虚构变更003']])}}
