from pathlib import Path
import shutil,json,zipfile,hashlib
root=Path.cwd();out=root/'progress/evidence/C02/source'
if out.exists():shutil.rmtree(out)
out.mkdir(parents=True)
for name in ['packages','tools/C02-计提与冲回']:
 shutil.copytree(root/name,out/name,ignore=shutil.ignore_patterns('node_modules','.DS_Store'))
for name in ['package.json','package-lock.json','AGENTS.md','tsconfig.json']:
 shutil.copy2(root/name,out/name)
p=json.loads((out/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/C02-计提与冲回/tests/*.test.ts','typecheck':'tsc -p tools/C02-计提与冲回/tsconfig.json --noEmit','build':'node --import tsx tools/C02-计提与冲回/tests/build.ts'};(out/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(out/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',out/'references/saxes-5.0.1-LICENSE');shutil.copy2(root/'progress/evidence/C02/candidate/0.1.0/THIRD_PARTY_NOTICES.md',out/'THIRD_PARTY_NOTICES.md')
(out/'BUILD.md').write_text('# C02候选源码重建\nNode22+，npm ci，npm test，npm run typecheck，npm run build。产物progress/evidence/C02/candidate/0.1.0。锁文件、共享包、本款源码、模板、虚构样例、测试、第三方声明齐备；不含node_modules、凭据或业务数据。浏览器测试需本机Chrome；macOS路径见tests/browser.ts。正式源码及官网集成归总控。\n')
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
(root/'progress/evidence/C02/source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
archive=root/'progress/evidence/C02/C02-0.1.0-候选源码.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n in manifest:z.write(out/n,n)
print(json.dumps({'archive':str(archive.relative_to(root)),'files':len(manifest),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},ensure_ascii=False))
