from pathlib import Path
import zipfile,json,hashlib,shutil
root=Path.cwd();out=root/'progress/evidence/C02';base=out/'candidate/0.1.0'
archive=out/'C02-0.1.0-候选离线包.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in base.iterdir():
  if p.is_file():z.write(p,p.name)
extracted=out/'extracted'
if extracted.exists():shutil.rmtree(extracted)
with zipfile.ZipFile(archive) as z:z.extractall(extracted)
files=[]
for p in base.iterdir():
 if p.is_file():
  a=p.read_bytes();b=(extracted/p.name).read_bytes();assert a==b
  files.append({'file':p.name,'sha256':hashlib.sha256(a).hexdigest(),'bytes':len(a),'extracted_identical':True})
(out/'offline-package.json').write_text(json.dumps({'status':'passed','archive':str(archive.relative_to(root)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':files},ensure_ascii=False,indent=2))
print('Offline archive/extracted bytes passed',len(files),'members')
