import {releaseAssets} from '../src/release-assets';import {writeFile} from 'node:fs/promises';for(const a of await releaseAssets())await writeFile('tools/C02-计提与冲回/examples/'+a.filename,a.data);
