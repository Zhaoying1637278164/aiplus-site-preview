from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();base=root/'progress/evidence/C02';tool=root/'tools/C02-计提与冲回'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((base/n).read_text())
def write(n,v):(base/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
code={str(p.relative_to(tool)):sha(p) for p in sorted((tool/'src').glob('*')) if p.is_file()}
assert code['src/engine.ts']==read('root-candidate-review/result.json')['engine_sha256']
commands=[]
for name in ['unit','typecheck','build','browser','native','extracted-browser','pagination-browser','independent-oracle']:
 d=read('commands/'+name+'.json');assert d['exit_code']==0,name
 commands.append({'name':name,'command':d['command'],'exit_code':d['exit_code']})
for n in ['browser/result.json','native/result.json','extracted-browser/result.json','pagination-browser/result.json','independent-oracle.json','source-rebuild.json','offline-package.json','visual-review.json']:
 assert read(n)['status']=='passed',n
rebuild=read('source-rebuild.json');assert len(rebuild['commands'])==4 and all(c['exit_code']==0 for c in rebuild['commands']);assert len(rebuild['comparisons'])==18
source=read('source-manifest.json');sourcezip=base/'C02-0.1.0-候选源码.zip'
with zipfile.ZipFile(sourcezip) as z:
 assert sorted(z.namelist())==sorted(source)
 for n,h in source.items():assert hashlib.sha256(z.read(n)).hexdigest()==h and sha(base/'source'/n)==h,n
assets={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted((base/'candidate/0.1.0').iterdir()) if p.is_file()};assert len(assets)==18
offline=base/'C02-0.1.0-候选离线包.zip'
with zipfile.ZipFile(offline) as z:
 assert sorted(z.namelist())==sorted(assets)
 for n,v in assets.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] and sha(base/'extracted'/n)==v['sha256']
evidence=['commands/'+c['name']+'.json' for c in commands]+['browser/result.json','native/result.json','extracted-browser/result.json','pagination-browser/result.json','independent-oracle.json','engine-result.json','source-rebuild.json','source-manifest.json','offline-package.json','visual-review.json','reference-recheck.json','root-candidate-review/result.json']
write('handoff-manifest.json',{'tool':'C02','version':'0.1.0','date':'2026-10-04','revision':'pagination-repair','status':'tested_candidate_handoff_frozen_not_accepted','owner':'C02 unique tool thread','write_scope':['tools/C02-计提与冲回/**','progress/evidence/C02/**'],'tool_code_files':code,'tool_code_sha256':hashlib.sha256(json.dumps(code,sort_keys=True).encode()).hexdigest(),'engine_unchanged_from_root_review':True,'isolated_source_manifest_sha256':sha(base/'source-manifest.json'),'source_zip':{'file':str(sourcezip.relative_to(root)),'sha256':sha(sourcezip),'bytes':sourcezip.stat().st_size,'members':len(source),'all_members_match_rebuilt_snapshot':True},'offline_zip':{'file':str(offline.relative_to(root)),'sha256':sha(offline),'bytes':offline.stat().st_size,'members':18},'assets':assets,'actual_commands':commands,'source_four_commands':[{'command':c['command'],'exit_code':c['exit_code']} for c in rebuild['commands']],'evidence_files':{n:sha(base/n) for n in evidence},'tested':{'unit_tests':48,'independent_fields':104,'currency_groups':2,'browser_groups':13,'browser_downloads':26,'extracted_browser_groups':13,'native_groups':4,'large_pagination_groups':11,'actual_reviewed_images':len(read('visual-review.json')['files'])},'independent_large_result':read('root-candidate-review/result.json')['expected'],'prior_failure_preserved':['root-candidate-review/result.json','history/pre-pagination','history/pagination-test-failures'],'unverified':['真实官网原结账模块/列表/详情及公开完整工作','总控正式包/整站回归和公开版本下载','Windows实机','实体手机'],'next':'总控独立验收与官网发布；本线程候选交接停写'})
print(json.dumps({'manifest':str((base/'handoff-manifest.json').relative_to(root)),'sha256':sha(base/'handoff-manifest.json'),'source_sha256':sha(sourcezip),'offline_sha256':sha(offline)},ensure_ascii=False))
