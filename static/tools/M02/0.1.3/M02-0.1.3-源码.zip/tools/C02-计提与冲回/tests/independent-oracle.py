# Independently enumerated handwritten expected events, no TS engine imported.
from pathlib import Path
import json
from decimal import Decimal as D
root=Path('progress/evidence/C02');r=json.loads((root/'engine-result.json').read_text())
expected=[('计提:F001','F001','2026-01','1200.00'),('计提:F002','F002','2026-01','1200.00'),('计提:F003','F003','2026-01','100.00'),('冲回:R001','F002','2026-02','-400.00'),('自动冲回:F001','F001','2026-02','-1200.00'),('自动冲回:F003','F003','2026-02','-100.00'),('变更:V001','F002','2026-03','300.00'),('冲回:R002','F002','2026-04','-1100.00')]
assert [(e['id'],e['item'],e['period'],e['amount']) for e in r['events']]==expected
closing={'F001':['1200.00','0.00'],'F002':['1200.00','800.00','1100.00','0.00'],'F003':['100.00','0.00']}
for item,values in closing.items():assert [b['closing'] for b in r['balances'] if b['item']==item]==values
for e in r['events']:
 entries=[j for j in r['entries'] if j['event']==e['id']];assert len(entries)==2
 amount=D(e['amount']);debit=sum(D(j['debit']) for j in entries);credit=sum(D(j['credit']) for j in entries)
 assert debit==credit==abs(amount)
 expected_account='6601' if e['item']=='F002' else '6602'
 expense=next(x for x in entries if x['account']==expected_account);liability=next(x for x in entries if x['account']=='2241')
 assert D(expense['debit'])==(amount if amount>0 else 0);assert D(expense['credit'])==(-amount if amount<0 else 0)
 assert D(liability['credit'])==D(expense['debit']);assert D(liability['debit'])==D(expense['credit'])
for currency,accrual,debit in [('CNY','2700.00','5400.00'),('USD','100.00','200.00')]:
 t=next(x for x in r['totals'] if x['currency']==currency);assert t['accrual']==t['reversal']==accrual;assert t['debit']==t['credit']==debit;assert t['balance']==t['difference']=='0.00'
assert r['canConfirm']
(root/'independent-oracle.json').write_text(json.dumps({'status':'passed','method':'Handwritten event/closing values plus Python Decimal independent journal direction and amounts','expected_events':expected,'expected_closing':closing,'event_fields':32,'balance_fields':8,'journal_amount_fields':64,'groups':2},ensure_ascii=False,indent=2))
print('Independent oracle passed 32 event + 8 balance + 64 journal amount fields, 2 currency groups')
