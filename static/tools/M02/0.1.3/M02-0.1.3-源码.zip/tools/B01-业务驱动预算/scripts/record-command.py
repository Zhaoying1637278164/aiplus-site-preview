# coding: utf-8
"""B01-owned command log with actual child exit status; never infer success from parent."""
import sys,pathlib,subprocess,datetime,json,hashlib
out=pathlib.Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);label=sys.argv[2];cmd=sys.argv[3:];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(label+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
report={'command':cmd,'cwd':str(pathlib.Path.cwd()),'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':str(out/(label+'.log')),'log_sha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()};(out/(label+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False));sys.exit(r.returncode)
