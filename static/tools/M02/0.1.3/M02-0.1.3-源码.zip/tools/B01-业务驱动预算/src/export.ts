import {workbookBytes} from './workbook';import {fields,labels,VERSION,RULE_VERSION,type Work,type Result} from './types';
export function csv(headers:string[],rows:unknown[][]){const escape=(v:unknown)=>{let s=v===null||v===undefined?'':String(v);if(/^[\s]*[=+@-]/.test(s)&&!/^[-+]?\d+(\.\d+)?$/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};return '\uFEFF'+[headers,...rows].map(r=>r.map(escape).join(',')).join('\r\n')}
export function sourceCSV(w:Work){return csv(fields.map(f=>labels[f]),w.rows.map(r=>fields.map(f=>r[f])))}
export const detailFields=['scenarioName','rowId','kind','label','dept','month','formula','parameters','raw','rounded','rounding','adjustment','final','payment','unpaid','depreciable','outsideDep','source'] as const;
export const detailHeaders=['情景','驱动ID','类别','项目','部门','期间','算式','实际参数','未舍入金额','舍入金额','舍入差','人工调整差','最终预算','当月付款','未付假设额','折旧基数','范围外折旧','来源'];
export function resultCSV(r:Result){return csv(detailHeaders,r.details.map(d=>detailFields.map(f=>d[f])))}
export function sheets(w:Work,r:Result){const sf=['name','month','dept','income','expense','people','contribution','depreciation','afterDep','capex','payment','count'] as const;return [
{name:'范围与版本',headers:['项目','值'],rows:[['工具','B01 业务驱动预算'],['应用',VERSION],['规则',RULE_VERSION],['完整性',r.complete?'无阻塞':'不完整：仅诊断，不可作为预算'],...Object.entries(w.scope),['说明','经营贡献非政策利润；税额未测算。所有预算/折旧/付款为自行确认假设。']]},
{name:'当前驱动',headers:[...fields.map(f=>labels[f]),'源文件','源页签','源行'],rows:w.rows.map(x=>[...fields.map(f=>x[f]),x.source.file,x.source.sheet,x.source.row])},
{name:'情景假设',headers:['ID','名称','数量乘数','价格乘数','附加乘数','基数乘数','费率百分点','依据'],rows:w.scenarios.map(s=>[s.id,s.name,s.a,s.b,s.c,s.base,s.rate,s.reason])},
{name:'逐行覆盖',headers:['情景','驱动ID','变量','值','理由'],rows:w.scenarios.flatMap(s=>s.overrides.map(o=>[s.name,o.rowId,o.variable,o.value,o.reason]))},
{name:'人工调整',headers:['ID','情景','驱动ID','方式','金额','理由','经办','时间','生效'],rows:w.adjustments.map(a=>[a.id,a.scenario,a.rowId,a.mode,a.amount,a.reason,a.owner,a.time,a.active?'生效':'撤销'])},
{name:'预算明细',headers:detailHeaders,rows:r.details.map(d=>detailFields.map(f=>d[f]))},
{name:'月度部门汇总',headers:['情景','期间','部门','收入','费用','人力','经营贡献','折旧','折旧后贡献','CAPEX','当月付款','驱动行数'],rows:r.summaries.map(s=>sf.map(f=>s[f]))},
{name:'全寿命折旧',headers:['情景','驱动ID','部门','期间','折旧','范围内','尾期'],rows:r.depreciation.map(d=>[d.scenario,d.rowId,d.dept,d.month,d.amount,d.inScope?'是':'否',d.last?'是':'否'])},
{name:'异常',headers:['情景','驱动ID','来源','阻塞原因'],rows:r.issues.map(i=>[i.scenario,i.rowId,i.source,i.message])},
{name:'勾稽',headers:['情景','检查','差额'],rows:r.checks.map(c=>[c.scenario,c.check,c.difference])},
{name:'修改留痕',headers:['时间','操作','目标','修改前','修改后','理由'],rows:w.logs.map(l=>[l.time,l.action,l.target,l.before,l.after,l.reason])},
{name:'原始资料',headers:['文件','页签','行','原始单元格JSON'],rows:w.original?w.original.rows.map(s=>[s.file,s.sheet,s.row,JSON.stringify(s.cells)]):w.rows.map(r=>[r.source.file,r.source.sheet,r.source.row,JSON.stringify(r.source.cells)])}
]}
export async function resultWorkbook(w:Work,r:Result){const data=await workbookBytes(sheets(w,r));if(data.length>10*1024*1024)throw Error('底稿超过10MB，请拆分预算');return data}
