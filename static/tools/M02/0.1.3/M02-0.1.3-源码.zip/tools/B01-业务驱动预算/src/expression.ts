import Decimal from 'decimal.js';import {vars,type Variable} from './types';
const D=Decimal.clone({precision:40,rounding:Decimal.ROUND_HALF_UP});
export function expressionVariables(input:string):Variable[]{return parse(input,Object.fromEntries(vars.map(v=>[v,new D(1)])),true).used}
export function expression(input:string,values:Record<string,Decimal>):Decimal{return parse(input,values,false).value}
function parse(input:string,values:Record<string,Decimal>,inspect:boolean){
 if(typeof input!=='string'||input.length>300||!input.trim())throw Error('组合算式须1–300字符');
 const tokens=input.match(/(?:\d+(?:\.\d{1,6})?|[a-z]+|[()+*/-])/g)||[];
 if(tokens.join('')!==input.replace(/\s/g,'')||tokens.length>100)throw Error('算式仅允许十进制、a/b/c/base/rate、四则和括号，最多100项');
 let p=0;const used=new Set<Variable>();
 function primary(depth:number):Decimal{if(depth>12)throw Error('算式嵌套超过12层');const t=tokens[p++];if(t==='+'||t==='-'){const n=primary(depth+1);return t==='-'?n.neg():n}if(t==='('){const n=sum(depth+1);if(tokens[p++]!==')')throw Error('括号不完整');return n}if(vars.includes(t as Variable)){used.add(t as Variable);if(!values[t])throw Error('缺失参数 '+t);return new D(values[t].toString())}if(t&&/^\d/.test(t))return new D(t);throw Error('未知变量或算式结构无效')}
 function product(depth:number):Decimal{let n=primary(depth);while(tokens[p]==='*'||tokens[p]==='/'){const op=tokens[p++],r=primary(depth);if(op==='/'&&r.isZero()&&!inspect)throw Error('算式除零');n=op==='*'?n.mul(r):inspect&&r.isZero()?new D(1):n.div(r);guard(n)}return n}
 function sum(depth:number):Decimal{let n=product(depth);while(tokens[p]==='+'||tokens[p]==='-'){const op=tokens[p++],r=product(depth);n=op==='+'?n.add(r):n.sub(r);guard(n)}return n}
 const value=sum(0);if(p!==tokens.length)throw Error('算式有多余项');guard(value);return {value,used:[...used]};
}
export function guard(n:Decimal){if(!n.isFinite()||n.abs().gte('1e24'))throw Error('计算结果超过24位整数限额')}
