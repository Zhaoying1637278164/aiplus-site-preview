import type {SourceRow,Table} from '../../../packages/core/types';
export const VERSION='0.1.2';export const RULE_VERSION='B01-2026-10-04.1';
export const MAX={rows:2000,months:36,scenarios:8,adjustments:1000,logs:4000};
export const kinds=['收入','费用','人力','CAPEX'] as const;export type Kind=typeof kinds[number];
export const methods=['量价','固定额','历史增幅','人力成本','收入比例','组合'] as const;export type Method=typeof methods[number];
export const vars=['a','b','c','base','rate'] as const;export type Variable=typeof vars[number];
export const fields=['id','kind','label','dept','month','currency','unit','method','a','b','c','base','rate','expression','life','residual','service','payment'] as const;
export const labels:Record<typeof fields[number],string>={id:'驱动ID',kind:'类别',label:'预算项目',dept:'部门',month:'期间',currency:'币种',unit:'金额单位',method:'方法',a:'数量或FTE',b:'单价或月薪',c:'附加金额',base:'基数金额',rate:'费率百分数',expression:'组合算式',life:'寿命月数',residual:'残值百分数',service:'启用月',payment:'付款百分数'};
export type Row=Record<typeof fields[number],string>&{source:SourceRow};
export interface Scope {start:string;end:string;currency:string;unit:string;note:string}
export interface Scenario {id:string;name:string;a:string;b:string;c:string;base:string;rate:string;reason:string;overrides:{rowId:string;variable:Variable;value:string;reason:string}[]}
export interface Adjustment {id:string;scenario:string;rowId:string;mode:'差额'|'替换';amount:string;reason:string;owner:string;time:string;active:boolean}
export interface Log {time:string;action:string;target:string;before:string;after:string;reason:string}
export interface Work {scope:Scope;rows:Row[];original:Table|null;scenarios:Scenario[];adjustments:Adjustment[];logs:Log[]}
export interface Issue {scenario:string;rowId:string;source:string;message:string}
export interface Detail {scenario:string;scenarioName:string;rowId:string;kind:Kind;label:string;dept:string;month:string;formula:string;parameters:string;raw:string;rounded:string;rounding:string;adjustment:string;final:string;payment:string;unpaid:string;depreciable:string;outsideDep:string;source:string}
export interface Dep {scenario:string;rowId:string;dept:string;month:string;amount:string;inScope:boolean;last:boolean}
export interface Summary {scenario:string;name:string;month:string;dept:string;income:string;expense:string;people:string;contribution:string;depreciation:string;afterDep:string;capex:string;payment:string;count:number}
export interface Result {details:Detail[];depreciation:Dep[];summaries:Summary[];issues:Issue[];checks:{scenario:string;check:string;difference:string}[];complete:boolean}
