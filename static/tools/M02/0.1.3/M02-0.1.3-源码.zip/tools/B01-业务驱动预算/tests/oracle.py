# coding: utf-8
"""Independent B01 oracle: Python Fraction, no production imports or copied results."""
from fractions import Fraction as Q
from pathlib import Path
import json,csv,sys,ast
FIELDS=['id','kind','label','dept','month','currency','unit','method','a','b','c','base','rate','expression','life','residual','service','payment']
LABELS=['驱动ID','类别','预算项目','部门','期间','币种','金额单位','方法','数量或FTE','单价或月薪','附加金额','基数金额','费率百分数','组合算式','寿命月数','残值百分数','启用月','付款百分数']
KINDS=['收入','费用','人力','CAPEX']
DH=['情景','驱动ID','类别','项目','部门','期间','算式','实际参数','未舍入金额','舍入金额','舍入差','人工调整差','最终预算','当月付款','未付假设额','折旧基数','范围外折旧','来源']
DF=['scenarioName','rowId','kind','label','dept','month','formula','parameters','raw','rounded','rounding','adjustment','final','payment','unpaid','depreciable','outsideDep','source']
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def idx(m):y,n=map(int,m.split('-'));return y*12+n-1
def mn(n):return f'{n//12:04}-{n%12+1:02}'
def cent(x):
 sign=-1 if x<0 else 1;x=abs(x)*100;return sign*((x.numerator*2+x.denominator)//(2*x.denominator))
def money(x):
 c=cent(x);return ('-' if c<0 else '')+f'{abs(c)//100}.{abs(c)%100:02}'
def rounded(x):return Q(cent(x),100)
def dec(x):
 # All raw values in this fixture have terminating decimal expansions.
 if x==0:return '0'
 sign='-' if x<0 else '';x=abs(x);a=x.numerator//x.denominator;rem=x.numerator%x.denominator;out=''
 while rem:
  rem*=10;out+=str(rem//x.denominator);rem%=x.denominator
  if len(out)>80:raise ValueError('Nonterminating raw decimal outside oracle fixture')
 return sign+str(a)+('.'+out if out else '')
def expr(src,p):
 def visit(n):
  if isinstance(n,ast.Expression):return visit(n.body)
  if isinstance(n,ast.Name):return p[n.id]
  if isinstance(n,ast.Constant):return Q(str(n.value))
  if isinstance(n,ast.UnaryOp):return -visit(n.operand) if isinstance(n.op,ast.USub) else visit(n.operand)
  if isinstance(n,ast.BinOp):
   a,b=visit(n.left),visit(n.right)
   if isinstance(n.op,ast.Add):return a+b
   if isinstance(n.op,ast.Sub):return a-b
   if isinstance(n.op,ast.Mult):return a*b
   if isinstance(n.op,ast.Div):return a/b
  raise ValueError('Oracle restricted arithmetic')
 return visit(ast.parse(src,mode='eval'))
def fixture():
 rows=[]
 for k,prefix in zip(KINDS,['R','F','H','A']):
  for i in range(1,152):
   month=f'2027-{(i-1)%12+1:02}';r=dict.fromkeys(FIELDS,'');r.update(id=f'{prefix}{i:04}',kind=k,label=f'完全虚构{k}事项{i:04}',dept=f'虚构部门{(i-1)%4+1}',month=month,currency='CNY',unit='元',a=str(i%9+1),b=f'{100+i}.125',c='0.015',base=f'{1000+i}.005',rate='5',method='量价',expression='a*b+c',life=str(i%5+2),residual='10',service=mn(idx(month)+1),payment='50')
   if k=='收入':r['method']=['量价','固定额','历史增幅','组合'][(i-1)%4]
   elif k=='费用':r['method']=['收入比例','固定额','历史增幅','组合'][(i-1)%4]
   elif k=='人力':r['method']=['人力成本','固定额','组合'][(i-1)%3]
   else:r['method']=['量价','固定额'][(i-1)%2]
   r['source']={'file':'B01-604.csv','sheet':'CSV','row':len(rows)+2,'cells':dict(zip(LABELS,[r[f] for f in FIELDS]))};rows.append(r)
 return {'scope':{'start':'2027-01','end':'2027-12','currency':'CNY','unit':'元','note':'604项完全虚构、多公司方法测试；无真实企业数据'},'rows':rows,'original':{'file':'B01-604.csv','sheet':'CSV','headers':LABELS,'rows':[r['source'] for r in rows]},'scenarios':[{'id':id,'name':name,'a':a,'b':b,'c':c,'base':base,'rate':rate,'reason':'完全虚构情景假设','overrides':[]} for id,name,a,b,c,base,rate in [('base','基准','1','1','1','1','0'),
('up','乐观','1.1','1.05','1.2','1.03','1'),
('down','保守','0.9','0.95','0.8','0.97','-1')]],'adjustments':[],'logs':[]}
def calculate(w,version='0.1.1'):
 ms=[mn(i) for i in range(idx(w['scope']['start']),idx(w['scope']['end'])+1)];ds=[];deps=[];sums=[];checks=[]
 for s in w['scenarios']:
  inc={m:Q(0) for m in ms}
  for kind in KINDS:
   for r in [x for x in w['rows'] if x['kind']==kind]:
    method=r['method'];need={'量价':['a','b'],'固定额':['base'],'历史增幅':['base','rate'],'人力成本':['a','b','rate','c'],'收入比例':['rate']}.get(method)
    if method=='组合':need=list(dict.fromkeys(n.id for n in ast.walk(ast.parse(r['expression'],mode='eval')) if isinstance(n,ast.Name)))
    # JS expressionVariables visits text order. This fixture expression a*b+c is fixed.
    if method=='组合':need=['a','b','c']
    p={}
    for v in need:
     o=next((o for o in s['overrides'] if o['rowId']==r['id'] and o['variable']==v),None);n=Q(o['value'] if o else r[v]);p[v]=n+Q(s[v]) if v=='rate' else n*Q(s[v])
    if method=='量价':raw=p['a']*p['b']
    elif method=='固定额':raw=p['base']
    elif method=='历史增幅':raw=p['base']*(1+p['rate']/100)
    elif method=='人力成本':raw=p['a']*p['b']*(1+p['rate']/100)+p['c']
    elif method=='收入比例':raw=inc[r['month']]*p['rate']/100
    else:raw=expr(r['expression'],p)
    rd=rounded(raw);final=rd
    for a in w['adjustments']:
     if a['active'] and a['rowId']==r['id'] and a['scenario']==s['id']:final=rounded(final+Q(a['amount']) if a['mode']=='差额' else Q(a['amount']))
    d=dict(scenario=s['id'],scenarioName=s['name'],rowId=r['id'],kind=kind,label=r['label'],dept=r['dept'],month=r['month'],formula={'量价':'a × b','固定额':'base','历史增幅':'base × (1 + rate / 100)','人力成本':'a × b × (1 + rate / 100) + c','收入比例':'当月调整后收入 × rate / 100'}.get(method,r['expression']),parameters=js({v:dec(n) for v,n in p.items()}),raw=dec(raw),rounded=money(rd),rounding=dec(rd-raw),adjustment=money(final-rd),final=money(final),payment='0.00',unpaid='0.00',depreciable='0.00',outsideDep='0.00',source=f"{r['source']['file']} / {r['source']['sheet']} / 第{r['source']['row']}行")
    if kind=='收入':inc[r['month']]+=final
    if kind=='CAPEX':
     life=int(r['life']);basis=rounded(final*(1-Q(r['residual'])/100));step=rounded(basis/life);outside=Q(0)
     for i in range(life):
      m=mn(idx(r['service'])+i);amt=basis-step*(life-1) if i==life-1 else step;inside=m in ms
      deps.append(dict(scenario=s['id'],rowId=r['id'],dept=r['dept'],month=m,amount=money(amt),inScope=inside,last=i==life-1))
      if not inside:outside+=amt
     d.update(payment=money(final*Q(r['payment'])/100),depreciable=money(basis),outsideDep=money(outside));d['unpaid']=money(final-Q(d['payment']))
    ds.append(d)
  sc=[d for d in ds if d['scenario']==s['id']];dp=[d for d in deps if d['scenario']==s['id'] and d['inScope']]
  for m in ms:
   for dept in ['全部部门',*dict.fromkeys(r['dept'] for r in w['rows'])]:
    rows=[d for d in sc if d['month']==m and (dept=='全部部门' or d['dept']==dept)];values={key:sum((Q(d['final']) for d in rows if d['kind']==k),Q(0)) for k,key in zip(KINDS,['income','expense','people','capex'])};dep=sum((Q(d['amount']) for d in dp if d['month']==m and (dept=='全部部门' or d['dept']==dept)),Q(0));con=values['income']-values['expense']-values['people'];sums.append(dict(scenario=s['id'],name=s['name'],month=m,dept=dept,**{k:money(v) for k,v in values.items()},depreciation=money(dep),contribution=money(con),afterDep=money(con-dep),payment=money(sum((Q(d['payment']) for d in rows),Q(0))),count=len(rows)))
  checks.extend(dict(scenario=s['name'],check=k+'明细与月汇总',difference='0.00') for k in KINDS);checks.extend(dict(scenario=s['name'],check=d['rowId']+'折旧全寿命回勾',difference='0.00') for d in sc if d['kind']=='CAPEX');checks.append(dict(scenario=s['name'],check='经营贡献勾稽',difference='0.00'))
 result=dict(details=ds,depreciation=deps,summaries=sums,issues=[],checks=checks,complete=True)
 spec=[
('范围与版本',['项目','值'],[['工具','B01 业务驱动预算'],['应用',version],['规则','B01-2026-10-04.1'],['完整性','无阻塞'],*[[k,v] for k,v in w['scope'].items()],['说明','经营贡献非政策利润；税额未测算。所有预算/折旧/付款为自行确认假设。']]),
('当前驱动',LABELS+['源文件','源页签','源行'],[[*[r[f] for f in FIELDS],r['source']['file'],r['source']['sheet'],r['source']['row']] for r in w['rows']]),
('情景假设',['ID','名称','数量乘数','价格乘数','附加乘数','基数乘数','费率百分点','依据'],[[s[k] for k in ['id','name','a','b','c','base','rate','reason']] for s in w['scenarios']]),
('逐行覆盖',['情景','驱动ID','变量','值','理由'],[[s['name'],o['rowId'],o['variable'],o['value'],o['reason']] for s in w['scenarios'] for o in s['overrides']]),
('人工调整',['ID','情景','驱动ID','方式','金额','理由','经办','时间','生效'],[[*[a[k] for k in ['id','scenario','rowId','mode','amount','reason','owner','time']],'生效' if a['active'] else '撤销'] for a in w['adjustments']]),
('预算明细',DH,[[d[f] for f in DF] for d in ds]),
('月度部门汇总',['情景','期间','部门','收入','费用','人力','经营贡献','折旧','折旧后贡献','CAPEX','当月付款','驱动行数'],[[s[f] for f in ['name','month','dept','income','expense','people','contribution','depreciation','afterDep','capex','payment','count']] for s in sums]),
('全寿命折旧',['情景','驱动ID','部门','期间','折旧','范围内','尾期'],[[*[d[f] for f in ['scenario','rowId','dept','month','amount']],'是' if d['inScope'] else '否','是' if d['last'] else '否'] for d in deps]),
('异常',['情景','驱动ID','来源','阻塞原因'],[]),
('勾稽',['情景','检查','差额'],[[c['scenario'],c['check'],c['difference']] for c in checks]),
('修改留痕',['时间','操作','目标','修改前','修改后','理由'],[[l[k] for k in ['time','action','target','before','after','reason']] for l in w['logs']]),
('原始资料',['文件','页签','行','原始单元格JSON'],[[r['file'],r['sheet'],r['row'],js(r['cells'])] for r in w['original']['rows']])]
 return {'result':result,'sheets':[{'name':name,'matrix':[[str(c) for c in row] for row in [heads,*rows]]} for name,heads,rows in spec]}
if __name__=='__main__':
 if sys.argv[1]=='fixture':
  out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);w=fixture();(out/'fixture-work.json').write_text(json.dumps(w,ensure_ascii=False,indent=2));(out/'oracle.json').write_text(json.dumps(calculate(w),ensure_ascii=False));
  with (out/'B01-604.csv').open('w',encoding='utf-8-sig',newline='') as f:writer=csv.writer(f);writer.writerow(LABELS);writer.writerows([r[f] for f in FIELDS] for r in w['rows'])
  (out/'restore.json').write_text(json.dumps(dict(schema_version=1,tool='B01',app_version='0.1.1',rule_version='B01-2026-10-04.1',contains_data=True,work=w),ensure_ascii=False))
 else:
  w=json.loads(Path(sys.argv[1]).read_text())['work'];Path(sys.argv[2]).write_text(json.dumps(calculate(w),ensure_ascii=False))
