import {stableFixture} from './deterministic';
import {fields} from './types';import {demoExample} from './example';import {csv} from './export';import {workbookBytes} from '../../../packages/core/io';
export async function releaseAssets(){const t=demoExample().original!,rows=t.rows.map(r=>fields.map(f=>r.cells[f]));return [{filename:'空白模板.csv',data:new TextEncoder().encode(csv([...fields],[]))},{filename:'虚构样例.csv',data:new TextEncoder().encode(csv([...fields],rows))},{filename:'虚构样例.xlsx',data:await stableFixture(await workbookBytes([{name:'预测资料',headers:[...fields],rows}]))}]}
