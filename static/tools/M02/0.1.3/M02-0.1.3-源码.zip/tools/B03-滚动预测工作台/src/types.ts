import type {SourceRow,Table} from '../../../packages/core/types';
export const VERSION='0.1.2',RULE_VERSION='B03-2026-10-04.1';
export const fields=['组织编码','组织名称','科目编码','科目名称','期间','类型','情景','金额','币种','单位','依据'] as const;
export type Field=typeof fields[number];
export interface Row extends Record<Field,string>{id:string;source:SourceRow}
export interface Scope {year:string;cutoff:string;currency:string;unit:string;scenario:string;strategy:'严格实际'|'允许暂估'|'允许沿用预测'}
export interface Adjustment {id:string;entity:string;account:string;start:string;end:string;mode:'差额'|'替换';amount:string;reason:string;owner:string;active:boolean}
export interface Lock {key:string;row:Row;reason:string;time:string}
export interface Log {time:string;action:string;target:string;reason:string;before?:string;after?:string}
export interface Inputs {scope:Scope;rows:Row[];locks:Lock[];adjustments:Adjustment[];original:Table|null}
export interface Snapshot {id:string;name:string;time:string;reason:string;inputs:Inputs}
export interface Work extends Inputs {snapshots:Snapshot[];logs:Log[]}
export interface Detail {key:string;entity:string;account:string;name:string;period:string;kind:string;base:string|null;adjustment:string|null;amount:string|null;forecast:string|null;difference:string|null;source:string;reason:string;locked:boolean}
export interface Issue {code:string;target:string;message:string;source:string}
export interface Result {details:Detail[];issues:Issue[];warnings:Issue[];totals:{entity:string;account:string;name:string;actual:string;estimate:string;forecast:string;adjustment:string;total:string|null;baseline:string;difference:string|null;residual:string|null}[];complete:boolean}
export const key=(e:string,a:string,p:string)=>JSON.stringify([e,a,p]);
