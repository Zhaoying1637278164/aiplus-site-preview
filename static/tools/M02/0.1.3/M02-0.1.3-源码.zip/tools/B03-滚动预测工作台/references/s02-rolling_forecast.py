#!/usr/bin/env python3
"""
Rolling forecast builder: blends actuals-to-date with a forward forecast
for remaining months, and bridges the resulting full-year view against the
original budget/plan.

Usage:
    python3 rolling_forecast.py --config forecast.json

forecast.json shape:
{
  "metric_name": "Revenue",
  "original_annual_plan": 24000000,
  "actuals_by_month": [1800000, 1750000, 1900000, 2100000, 1950000],
  "forecast_remaining_months": [2050000, 2200000, 2150000, 2300000, 2250000, 2400000, 2350000]
}
actuals_by_month + forecast_remaining_months should together cover all 12 months.
"""
import argparse
import json


def money(x):
    return f"${x:,.0f}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = json.load(f)

    actuals = cfg["actuals_by_month"]
    forecast = cfg["forecast_remaining_months"]
    plan = cfg["original_annual_plan"]
    total_months = len(actuals) + len(forecast)

    print(f"=== Rolling Forecast: {cfg['metric_name']} ===\n")
    print(f"{'Month':<7}{'Type':<10}{'Value':>14}{'Cumulative':>16}")
    print("-" * 47)

    cum = 0
    for i, v in enumerate(actuals, start=1):
        cum += v
        print(f"{i:<7}{'Actual':<10}{money(v):>14}{money(cum):>16}")
    for i, v in enumerate(forecast, start=len(actuals) + 1):
        cum += v
        print(f"{i:<7}{'Forecast':<10}{money(v):>14}{money(cum):>16}")

    full_year_forecast = sum(actuals) + sum(forecast)
    bridge = full_year_forecast - plan
    bridge_pct = bridge / plan * 100 if plan else 0

    print("-" * 47)
    print(f"\nOriginal annual plan: {money(plan)}")
    print(f"Latest full-year forecast ({len(actuals)} actual + {len(forecast)} forecast months): {money(full_year_forecast)}")
    print(f"Bridge vs. plan: {money(bridge)} ({bridge_pct:+.1f}%)")

    run_rate_actual = sum(actuals) / len(actuals) if actuals else 0
    run_rate_forecast = sum(forecast) / len(forecast) if forecast else 0
    print(f"\nActual monthly run rate: {money(run_rate_actual)}")
    print(f"Forecast monthly run rate: {money(run_rate_forecast)}")
    if run_rate_forecast > run_rate_actual * 1.15:
        print(">>> FLAG: forecast run rate is more than 15% above the actual run rate")
        print("    achieved so far. Confirm this acceleration has a specific, named driver")
        print("    (a launch, a signed deal, a seasonal pattern) rather than optimism.")
    if total_months != 12:
        print(f"\n>>> NOTE: actuals + forecast cover {total_months} months, not 12. Check inputs.")


if __name__ == "__main__":
    main()
