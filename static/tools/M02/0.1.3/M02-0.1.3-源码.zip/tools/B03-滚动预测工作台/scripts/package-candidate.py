"""Candidate packaging, isolated B03 only. Does not mutate registration or formal releases."""
import pathlib,json,zipfile,hashlib
root=pathlib.Path.cwd();tool=root/'tools/B03-滚动预测工作台';e=root/'progress/evidence/B03/0.1.1';out=e/'candidate';program=out/'program';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(out/'B03-0.1.1-候选离线.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(program.iterdir()):
  if f.is_file():z.write(f,'B03/'+f.name)
with zipfile.ZipFile(out/'B03-0.1.1-候选源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 files={}
 def put(name,data):files[name]=sha(data);z.writestr(name,data)
 p=json.loads((root/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/B03-滚动预测工作台/tests/*.test.ts','typecheck':'tsc --noEmit','build':'node --import tsx tools/B03-滚动预测工作台/scripts/build-candidate.ts'};put('package.json',(json.dumps(p,ensure_ascii=False,indent=2)+'\n').encode());put('package-lock.json',(root/'package-lock.json').read_bytes())
 config=json.loads((root/'tsconfig.json').read_text());config['include']=['packages','tools/B03-滚动预测工作台'];put('tsconfig.json',json.dumps(config,indent=2).encode())
 put('README.md',('B03候选源码包，Node22+。依次执行npm ci、npm test、npm run typecheck、npm run build。\n候选写入progress/evidence/B03/0.1.1/candidate/program，未包含其他工具与业务数据。\n').encode())
 for folder in ['packages','tools/B03-滚动预测工作台']:
  for f in sorted((root/folder).rglob('*')):
   if f.is_file() and not any(p in ['__pycache__','node_modules','candidate'] for p in f.parts):put(str(f.relative_to(root)),f.read_bytes())
 put('references/saxes-5.0.1-LICENSE',(root/'references/saxes-5.0.1-LICENSE').read_bytes());put('THIRD_PARTY_NOTICES.md',(program/'THIRD_PARTY_NOTICES.md').read_bytes());z.writestr('source-snapshot.json',json.dumps({'tool':'B03','version':'0.1.1','candidate':True,'files':files},ensure_ascii=False,indent=2))
report={}
for f in sorted(out.glob('*.zip')):
 with zipfile.ZipFile(f) as z:assert z.testzip() is None;report[f.name]={'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size,'files':len(z.namelist())}
(e/'candidate-archives.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
