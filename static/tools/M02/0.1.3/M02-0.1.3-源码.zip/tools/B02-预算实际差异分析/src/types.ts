import type {Table,SourceRow} from '../../../packages/core/types';
export const VERSION='0.1.2';
export const RULE_VERSION='B02-2026-10-04.1';
export type Side='budget'|'actual';
export type Field='id'|'period'|'org'|'account'|'amount'|'version'|'currency'|'unit';
export type Fields=Record<Field,string>;
export type Nature='收入'|'费用'|'其他';
export type Direction='增加有利'|'减少有利'|'中性';
export interface OrgMap {side:Side;from:string;to:string}
export interface AccountMap extends OrgMap {nature:Nature;direction:Direction}
export interface Config {start:string;end:string;budgetVersion:string;actualVersion:string;currency:string;unit:string;basis:string;confirmed:boolean;amountThreshold:string;percentThreshold:string;tolerance:string;fields:Record<Side,Fields>;orgs:OrgMap[];accounts:AccountMap[]}
export interface Review {key:string;owner:string;reason:string;evidence:string;action:string;status:'待复核'|'已复核'}
export interface Audit {side:Side;source:SourceRow;status:'已汇总'|'范围外'|'异常';issues:string[];key:string|null;value:string|null}
export interface Variance {key:string;period:string;org:string;account:string;nature:Nature;direction:Direction;budget:string|null;actual:string|null;difference:string|null;percent:string|null;rateBasis:string;favorable:string;important:boolean;status:string;budgetSources:SourceRow[];actualSources:SourceRow[]}
export interface Result {app_version:string;rule_version:string;config:Config;rows:Variance[];audit:Audit[];complete:boolean;coverage:Record<Side,{input:number;grouped:number;excluded:number;invalid:number}>}
export interface Work {config:Config;budget:Table|null;actual:Table|null;reviews:Review[]}
export const defaultFields:Fields={id:'记录ID',period:'期间',org:'组织',account:'科目',amount:'金额',version:'版本',currency:'币种',unit:'单位'};
export const defaultConfig:Config={start:'2026-01',end:'2026-02',budgetVersion:'批准预算V1',actualVersion:'月结批次A',currency:'CNY',unit:'元',basis:'请填写主体范围、核算基础及含税口径',confirmed:false,amountThreshold:'10',percentThreshold:'10',tolerance:'0.01',fields:{budget:{...defaultFields},actual:{...defaultFields,version:'批次'}},orgs:[],accounts:[]};
