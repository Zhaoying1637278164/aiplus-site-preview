import Decimal from 'decimal.js';
import {amount,text} from '../../../packages/core/value';
import {LIMITS,type Table,type Cell,type SourceRow} from '../../../packages/core/types';
import {VERSION,RULE_VERSION,type Config,type Side,type Audit,type Variance,type Result,type Nature,type Direction} from './types';
export {VERSION,RULE_VERSION} from './types';
export function month(v:Cell):string {const s=text(v).trim();if(!/^(19|20|21)\d{2}-(0[1-9]|1[0-2])$/.test(s))throw Error('期间须为YYYY-MM（1900–2199）');return s}
function required(v:unknown):string {if(typeof v!=='string'||!v.trim()||v.length>1000)throw Error('配置必填文本无效');return v.trim()}
export function validateConfig(c:Config){
 if(!c||typeof c!=='object')throw Error('缺少配置');month(c.start);month(c.end);if(c.start>c.end)throw Error('开始期间不得晚于结束期间');
 for(const v of [c.budgetVersion,c.actualVersion,c.currency,c.unit,c.basis])required(v);
 if(typeof c.confirmed!=='boolean')throw Error('确认参数无效');
 for(const v of [c.amountThreshold,c.percentThreshold,c.tolerance])if(amount(v).isNegative())throw Error('阈值与容差须非负');
 for(const side of ['budget','actual'] as const){if(!c.fields?.[side])throw Error('缺少字段映射');const cols=Object.values(c.fields[side]);if(cols.length!==8||new Set(cols).size!==8)throw Error('字段映射须为八个不同列');for(const field of ['id','period','org','account','amount','version','currency','unit'] as const)required(c.fields[side][field]);}
 if(!Array.isArray(c.orgs)||!Array.isArray(c.accounts)||c.orgs.length>20000||c.accounts.length>20000)throw Error('映射超限或无效');
 for(const list of [c.orgs,c.accounts]){const used=new Set<string>();for(const m of list){if(!['budget','actual'].includes(m.side))throw Error('映射来源无效');required(m.from);required(m.to);const k=JSON.stringify([m.side,m.from.trim()]);if(used.has(k))throw Error('同侧原编码重复映射');used.add(k)}}
 const meta=new Map<string,string>();for(const m of c.accounts){if(!['收入','费用','其他'].includes(m.nature)||!['增加有利','减少有利','中性'].includes(m.direction))throw Error('科目性质或有利方向无效');const k=m.to.trim(),v=JSON.stringify([m.nature,m.direction]);if(meta.has(k)&&meta.get(k)!==v)throw Error('共同科目的性质或方向冲突');meta.set(k,v)}
}
export function validateTable(t:Table){
 if(!t||typeof t.file!=='string'||typeof t.sheet!=='string'||!Array.isArray(t.headers)||!Array.isArray(t.rows)||!t.rows.length||t.rows.length>LIMITS.rows||t.headers.length>LIMITS.columns||!t.headers.length||new Set(t.headers).size!==t.headers.length)throw Error('资料结构为空或超限');
 for(const h of t.headers)if(typeof h!=='string'||!h.trim()||h.length>10000)throw Error('无效表头');
 const loc=new Set<number>();for(const r of t.rows){if(!r||r.file!==t.file||r.sheet!==t.sheet||!Number.isInteger(r.row)||r.row<1||loc.has(r.row)||!r.cells||typeof r.cells!=='object'||Array.isArray(r.cells))throw Error('来源行无效或重复');loc.add(r.row);if(Object.keys(r.cells).length>LIMITS.columns)throw Error('来源列超限');for(const [k,v] of Object.entries(r.cells)){if(!t.headers.includes(k))throw Error('来源存在无表头列');if(v!==null&&typeof v!=='string'&&typeof v!=='number'&&!(typeof v==='object'&&typeof v.formula==='string'))throw Error('单元格无效');if(typeof v==='string'&&v.length>10000)throw Error('单元格文本超限')}}
}
export function metrics(b:string|null,a:string|null,direction:Direction,c:Config){
 if(b===null||a===null)return {difference:null,percent:null,rateBasis:'单边缺失，不补零',favorable:'待补资料',important:false};
 const bd=amount(b),ad=amount(a),delta=ad.minus(bd),pct=bd.isZero()?null:delta.div(bd.abs()).mul(100),equal=delta.abs().lte(amount(c.tolerance));
 return {difference:delta.toFixed(),percent:pct?.toFixed(6)??null,rateBasis:bd.isZero()?'零预算，不计算百分比':bd.isNegative()?'差额 / 绝对预算 × 100':'差额 / 预算 × 100',favorable:equal?'一致':direction==='中性'?'中性':(delta.isPositive()===(direction==='增加有利')?'有利':'不利'),important:!equal&&(delta.abs().gte(amount(c.amountThreshold))||(pct!==null&&pct.abs().gte(amount(c.percentThreshold))))};
}
export function calculate(budget:Table,actual:Table,config:Config):Result {
 validateConfig(config);if(!config.confirmed)throw Error('请确认预算与实际口径可比');validateTable(budget);validateTable(actual);
 const c=structuredClone(config),audit:Audit[]=[],groups=new Map<string,{period:string;org:string;account:string;nature:Nature;direction:Direction;budget:SourceRow[];actual:SourceRow[];bs:Decimal;as:Decimal}>(),tainted=new Set<string>();
 const orgs=new Map(c.orgs.map(m=>[JSON.stringify([m.side,m.from.trim()]),m.to.trim()]));const accounts=new Map(c.accounts.map(m=>[JSON.stringify([m.side,m.from.trim()]),m]));
 for(const [side,t] of [['budget',budget],['actual',actual]] as const){const f=c.fields[side];for(const h of Object.values(f))if(!t.headers.includes(h))throw Error(`${side==='budget'?'预算':'实际'}缺少映射列：${h}`);
 const ids=new Map<string,number>();for(const r of t.rows){try{const id=text(r.cells[f.id]).trim();ids.set(id,(ids.get(id)??0)+1)}catch{}}
 for(const source of t.rows){const issues:string[]=[],get=(field:keyof typeof f)=>{try{return text(source.cells[f[field]]).trim()}catch(e){issues.push(`${f[field]}：${(e as Error).message}`);return null}};
 const id=get('id'),periodRaw=get('period'),orgRaw=get('org'),accountRaw=get('account'),version=get('version'),currency=get('currency'),unit=get('unit');let period:string|null=null,value:string|null=null;
 if(Object.values(source.cells).some(v=>v!==null&&typeof v==='object'))issues.push('原始行含公式/Excel错误，须提供静态值');
 if(id&&ids.get(id)!>1)issues.push('记录ID重复，整组排除');if(periodRaw)try{period=month(periodRaw)}catch(e){issues.push((e as Error).message)}
 try{value=amount(source.cells[f.amount]).toFixed()}catch(e){issues.push(`金额：${(e as Error).message}`)}
 const org=orgRaw?orgs.get(JSON.stringify([side,orgRaw])):undefined,account=accountRaw?accounts.get(JSON.stringify([side,accountRaw])):undefined;
 if(!org)issues.push('组织未映射');if(!account)issues.push('科目未映射');
 if(currency&&currency!==c.currency.trim())issues.push('币种与比较范围不一致');if(unit&&unit!==c.unit.trim())issues.push('单位与比较范围不一致');
 const key=period&&org&&account?JSON.stringify([period,org,account.to.trim()]):null;
 const inScope=period!==null&&period>=c.start&&period<=c.end&&version===(side==='budget'?c.budgetVersion.trim():c.actualVersion.trim());
 const status:Audit['status']=issues.length?'异常':!inScope?'范围外':'已汇总';audit.push({side,source:structuredClone(source),status,issues,key,value});
 if(status==='异常'){if(key&&inScope)tainted.add(key);continue}if(status==='范围外')continue;
 if(!groups.has(key!))groups.set(key!,{period:period!,org:org!,account:account!.to.trim(),nature:account!.nature,direction:account!.direction,budget:[],actual:[],bs:new Decimal(0),as:new Decimal(0)});
 const g=groups.get(key!)!;g[side].push(structuredClone(source));if(side==='budget')g.bs=g.bs.plus(value!);else g.as=g.as.plus(value!);
 }}
 const rows:Variance[]=[...groups].map(([key,g])=>{const b=g.budget.length?g.bs.toFixed():null,a=g.actual.length?g.as.toFixed():null,broken=tainted.has(key);return {key,period:g.period,org:g.org,account:g.account,nature:g.nature,direction:g.direction,budget:b,actual:a,...metrics(broken?null:b,broken?null:a,g.direction,c),...(broken?{rateBasis:'相关行异常，不计算差额和百分比',favorable:'待复核异常'}:{}),status:broken?'相关行异常':b===null?'缺预算':a===null?'缺实际':'可比较',budgetSources:g.budget,actualSources:g.actual}}).sort((a,b)=>a.key.localeCompare(b.key));
 const coverage={} as Result['coverage'];for(const side of ['budget','actual'] as const){const list=audit.filter(a=>a.side===side);coverage[side]={input:list.length,grouped:list.filter(a=>a.status==='已汇总').length,excluded:list.filter(a=>a.status==='范围外').length,invalid:list.filter(a=>a.status==='异常').length}}
 return {app_version:VERSION,rule_version:RULE_VERSION,config:c,rows,audit,coverage,complete:!audit.some(a=>a.status==='异常')&&rows.length>0&&rows.every(r=>r.status==='可比较')};
}
export function summarize(r:Result,by:'期间'|'责任组织'|'科目'){
 const groups=new Map<string,{label:string;nature:Nature;direction:Direction;budget:Decimal;actual:Decimal;count:number}>();
 for(const v of r.rows){if(v.status!=='可比较')continue;const label=by==='期间'?v.period:by==='责任组织'?v.org:v.account,key=JSON.stringify([label,v.nature,v.direction]);if(!groups.has(key))groups.set(key,{label,nature:v.nature,direction:v.direction,budget:new Decimal(0),actual:new Decimal(0),count:0});const g=groups.get(key)!;g.budget=g.budget.plus(v.budget!);g.actual=g.actual.plus(v.actual!);g.count++}
 return [...groups.values()].map(g=>({...g,budget:g.budget.toFixed(),actual:g.actual.toFixed(),...metrics(g.budget.toFixed(),g.actual.toFixed(),g.direction,r.config)}));
}
