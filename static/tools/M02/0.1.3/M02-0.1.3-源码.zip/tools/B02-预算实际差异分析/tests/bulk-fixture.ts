// Independent fictitious input and integer oracle. No imports from engine/export.
import type {Table} from '../../../packages/core/types';import type {Work,Review} from '../src/types';
export function bulk(){
 const headers=['记录ID','期间','组织','科目','金额','版本','币种','单位'];const budget:Table={file:'虚构批量预算.csv',sheet:'CSV',headers,rows:[]},actual:Table={file:'虚构批量实际.csv',sheet:'CSV',headers:headers.map(h=>h==='版本'?'批次':h),rows:[]};
 const config:Work['config']={start:'2026-01',end:'2026-01',budgetVersion:'批量批准V1',actualVersion:'批量月结A',currency:'CNY',unit:'元',basis:'完全虚构主体；权责发生制；不含税；604个责任组织',confirmed:true,amountThreshold:'10',percentThreshold:'10',tolerance:'0.01',fields:{budget:{id:'记录ID',period:'期间',org:'组织',account:'科目',amount:'金额',version:'版本',currency:'币种',unit:'单位'},actual:{id:'记录ID',period:'期间',org:'组织',account:'科目',amount:'金额',version:'批次',currency:'币种',unit:'单位'}},orgs:[],accounts:[{side:'budget',from:'收入',to:'营业收入',nature:'收入',direction:'增加有利'},{side:'actual',from:'主营收入',to:'营业收入',nature:'收入',direction:'增加有利'}]};
 const expected:{key:string;org:string;b:string;a:string;delta:string;pct:string;basis:string;important:boolean;favorable:string}[]=[];
 for(let i=1;i<=604;i++){
 const n=String(i).padStart(4,'0'),org='虚构责任'+n,b=i===601?'0':i===602?'-100':i===603?'0.3':'100',a=i===601?'30':i===602?'-80':i===603?'0.3':i===604?'140':'120';
 for(const [side,t,value,from,account,version] of [['budget',budget,b,'预算部'+n,'收入','批量批准V1'],['actual',actual,a,'实际部'+n,'主营收入','批量月结A']] as const){const vals=[(side==='budget'?'B':'A')+n,'2026-01',from,account,value,version,'CNY','元'];t.rows.push({file:t.file,sheet:'CSV',row:i+1,cells:Object.fromEntries(t.headers.map((h,k)=>[h,vals[k]]))});config.orgs.push({side,from,to:org})}
 // cents BigInt: 100=10000, zero=0, negative=-10000; 0.3=30.
 const bc=i===601?0n:i===602?-10000n:i===603?30n:10000n,ac=i===601?3000n:i===602?-8000n:i===603?30n:i===604?14000n:12000n,dc=ac-bc;
 const delta=dc%100n===0n?String(dc/100n):(Number(dc)/100).toString();const pct=bc===0n?'':((dc*100000000n+(bc<0n?-bc:bc)/2n)/(bc<0n?-bc:bc)).toString().padStart(7,'0').replace(/(\d{6})$/,'.$1');
 expected.push({key:JSON.stringify(['2026-01',org,'营业收入']),org,b,a,delta,pct,basis:bc===0n?'零预算，不计算百分比':bc<0n?'差额 / 绝对预算 × 100':'差额 / 预算 × 100',important:i!==603,favorable:i===603?'一致':'有利'});
 }
 return {work:{config,budget,actual,reviews:[]} as Work,expected};
}
export const tailReview:Review={key:JSON.stringify(['2026-01','虚构责任0604','营业收入']),owner:'虚构尾部负责人',reason:'人工核验虚构订单资料',evidence:'虚构证据TAIL-604',action:'虚构跟踪事项',status:'已复核'};
export function oracleSheets(work:Work,reviewed=false){const {expected}=bulk(),c=work.config,b=work.budget!,a=work.actual!;const rows=(headers:string[],data:unknown[][])=>[headers,...data];return [
 {name:'参数与版本',matrix:rows(['参数','值'],[['应用','0.1.1'],['规则','B02-2026-10-04.1'],['期间','2026-01 至 2026-01'],['预算版本','批量批准V1'],['实际批次','批量月结A'],['币种','CNY'],['单位','元'],['可比基础',c.basis],['范围确认',true],['金额阈值','10'],['百分比阈值','10'],['容差','0.01'],['完整性','完整可比较'],['公式','实际减预算；负预算以绝对预算为分母；零预算无百分比']])},
 {name:'字段映射',matrix:rows(['来源','业务字段','原列'],(['budget','actual'] as const).flatMap(s=>Object.entries(c.fields[s]).map(([k,v])=>[s,k,v])))},
 {name:'组织映射',matrix:rows(['来源','原组织','责任组织'],c.orgs.map(m=>[m.side,m.from,m.to]))},
 {name:'科目与方向',matrix:rows(['来源','原科目','共同科目','性质','方向'],[['budget','收入','营业收入','收入','增加有利'],['actual','主营收入','营业收入','收入','增加有利']])},
 {name:'差异结果',matrix:rows(['比较键','期间','责任组织','科目','性质','方向','预算','实际','差额','差异率%','分母说明','有利方向','重要差异','状态','预算来源','实际来源'],expected.map((v,i)=>[v.key,'2026-01',v.org,'营业收入','收入','增加有利',v.b,v.a,v.delta,v.pct,v.basis,v.favorable,v.important,'可比较',b.file+'/CSV/'+(i+2),a.file+'/CSV/'+(i+2)]))},
 {name:'重要差异复核',matrix:rows(['比较键','负责人','人工原因','证据引用','行动','状态'],expected.filter(v=>v.important).map(v=>reviewed&&v.key===tailReview.key?[v.key,tailReview.owner,tailReview.reason,tailReview.evidence,tailReview.action,'已复核']:[v.key,'','','','','待复核']))},
 ...[b,a].map((t,i)=>({name:i?'原始实际':'原始预算',matrix:rows(['来源文件','页签','原行',...t.headers],t.rows.map(r=>[r.file,'CSV',r.row,...t.headers.map(h=>r.cells[h])]))})),
 {name:'来源行分类',matrix:rows(['来源侧','文件','页签','原行','分类','比较键','金额','异常','原始值'],[b,a].flatMap((t,i)=>t.rows.map((r,j)=>[i?'actual':'budget',t.file,'CSV',r.row,'已汇总',expected[j].key,i?expected[j].a:expected[j].b,'',r.cells])))},
 {name:'行数与金额勾稽',matrix:rows(['对象','输入或预算','汇总或差额','范围外或实际','异常或残差','行数守恒'],[['budget',604,604,0,0,true],['actual',604,604,0,0,true],...expected.map(v=>[v.key,v.b,v.delta,v.a,'0','预算+差额=实际'])])}
 ];}
