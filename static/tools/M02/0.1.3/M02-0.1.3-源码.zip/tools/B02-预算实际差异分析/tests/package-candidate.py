from pathlib import Path
import zipfile,json,hashlib,shutil
root=Path.cwd();tool=root/'tools/B02-预算实际差异分析';out=root/'progress/evidence/B02/0.1.1/candidate'
for src,dest in [('README.md','使用说明.md'),('参考来源.md','参考来源.md'),('财务规则.md','财务规则.md')]:shutil.copy2(tool/src,out/dest)
files=['index.html','runtime.json','host-harness.html','空白模板.csv','实际空白模板.csv','虚构预算.csv','虚构实际.csv','虚构样例.xlsx','无数据方案.json','使用说明.md','财务规则.md','参考来源.md','THIRD_PARTY_NOTICES.md']
with zipfile.ZipFile(out/'B02-0.1.1-候选离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(out/f,f)
pkg=json.loads((root/'package.json').read_text());pkg['scripts']={'test':'node --import tsx --test tools/B02-预算实际差异分析/tests/*.test.ts','typecheck':'tsc --noEmit -p tools/B02-预算实际差异分析/tests/tsconfig.json','build':'node --import tsx tools/B02-预算实际差异分析/tests/build-candidate.ts'}
with zipfile.ZipFile(out/'B02-0.1.1-候选源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in ['package-lock.json','tsconfig.json']:z.write(root/f,f)
 z.writestr('package.json',json.dumps(pkg,ensure_ascii=False,indent=2))
 for sub in ['packages/core','tools/B02-预算实际差异分析']:
  for f in sorted((root/sub).rglob('*')):
   if f.is_file() and '.DS_Store' not in f.name:z.write(f,str(f.relative_to(root)))
 z.write(root/'packages/ui/tool-host.ts','packages/ui/tool-host.ts')
 for f in ['saxes-5.0.1-LICENSE','anthropic-finance-8444efcd-LICENSE']:z.write(root/'references'/f,'references/'+f)
 z.writestr('BUILD.md','# B02候选源码重建\nNode.js22+，依次npm ci、npm test、npm run typecheck、npm run build。依赖安装需网络或预热npm缓存；成品断网file://运行。产物progress/evidence/B02/0.1.1/candidate。此包不含node_modules、凭据或业务数据，非正式release。Windows未验证。\n')
records={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in out.iterdir() if f.is_file() and f.name not in ['manifest.json','package-manifest.json']}
(out/'package-manifest.json').write_text(json.dumps({'candidate':True,'formal':False,'version':'0.1.1','files':records},ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in records.items() if k.endswith('.zip')},ensure_ascii=False))
