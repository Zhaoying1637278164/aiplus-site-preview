from pathlib import Path
import zipfile,json,hashlib,subprocess,os,tempfile
root=Path.cwd();out=root/'progress/evidence/B02/0.1.1';archive=out/'candidate/B02-0.1.1-候选源码.zip';dest=Path(tempfile.mkdtemp(prefix='b02-source-rebuild-',dir='/private/tmp'));sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 members={i.filename:sha(z.read(i)) for i in z.infolist()}
 assert not any('node_modules' in n or n.endswith('.env') for n in members)
 z.extractall(dest)
commands=[['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build','--','B02']]
results=[]
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=dest,capture_output=True,text=True);log=r.stdout+r.stderr;(out/f'rebuild-{i+1}.txt').write_text(log);results.append({'command':cmd,'exit_code':r.returncode,'log':f'rebuild-{i+1}.txt','log_sha256':sha(log.encode())})
 if r.returncode:raise RuntimeError(f'{cmd}: {r.returncode}')
rebuilt=dest/'progress/evidence/B02/0.1.1/candidate';equal={}
for name in ['index.html','runtime.json','host-harness.html','THIRD_PARTY_NOTICES.md','空白模板.csv','实际空白模板.csv','虚构预算.csv','虚构实际.csv','无数据方案.json','虚构样例.xlsx','使用说明.md','财务规则.md','参考来源.md']:
 a=(out/'candidate'/name).read_bytes();b=(rebuilt/name).read_bytes();assert a==b,name;equal[name]=sha(a)
xlsx_members={}
with zipfile.ZipFile(out/'candidate/虚构样例.xlsx') as original,zipfile.ZipFile(rebuilt/'虚构样例.xlsx') as second:
 for name in original.namelist():
  assert original.read(name)==second.read(name);xlsx_members[name]=sha(original.read(name))
record={'xlsx_non_timestamp_members':xlsx_members,'passed':True,'candidate':True,'formal':False,'source_archive_sha256':sha(archive.read_bytes()),'source_members':members,'source_dir':str(dest),'commands':results,'exact_equal_assets':equal,'xlsx':'all assets including XLSX and document/ZIP timestamps exactly equal','network':'npm ci uses existing offline npm cache; no node_modules in archive','windows':'未验证'}
(out/'source-rebuild.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));print(json.dumps({'passed':True,'source_sha256':record['source_archive_sha256'],'commands':results,'exact_asset_count':len(equal)},ensure_ascii=False))
