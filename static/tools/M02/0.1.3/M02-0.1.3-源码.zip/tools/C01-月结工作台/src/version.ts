export const VERSION='0.1.1';
export const RULE_VERSION='C01-CLOSE-20261004.1';
