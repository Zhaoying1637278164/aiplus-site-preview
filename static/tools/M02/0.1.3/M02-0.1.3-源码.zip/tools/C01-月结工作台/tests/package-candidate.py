import pathlib,json,zipfile,hashlib
root=pathlib.Path.cwd();folder=root/'tools/C01-月结工作台';out=folder/'candidate/0.1.0'
with zipfile.ZipFile(out/'C01-0.1.0-离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(out.iterdir()):
  if f.is_file() and f.suffix!='.zip':z.write(f,'C01/'+f.name)
snapshot={}
with zipfile.ZipFile(out/'C01-0.1.0-源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 def add(name,data):
  snapshot[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
 pkg=json.loads((root/'package.json').read_text());pkg['scripts']={'test':'node --import tsx --test tools/C01-月结工作台/tests/*.test.ts','typecheck':'tsc --noEmit -p tools/C01-月结工作台/tsconfig.json','build':'node --import tsx tools/C01-月结工作台/tests/build.ts'}
 add('package.json',(json.dumps(pkg,ensure_ascii=False,indent=2)+'\n').encode())
 for name in ['package-lock.json','tsconfig.json','AGENTS.md']:add(name,(root/name).read_bytes())
 add('README.md',(folder/'README.md').read_bytes());add('THIRD_PARTY_NOTICES.md',(out/'THIRD_PARTY_NOTICES.md').read_bytes())
 for base in [root/'packages',folder]:
  for f in sorted(base.rglob('*')):
   if f.is_file() and not any(x in ['candidate','node_modules','__pycache__'] for x in f.relative_to(base).parts) and f.suffix not in ['.zip','.png','.pyc'] and f.name!='.DS_Store':add(str(f.relative_to(root)),f.read_bytes())
 for name in ['references/saxes-5.0.1-LICENSE','references/anthropic-finance-8444efcd-LICENSE']:add(name,(root/name).read_bytes())
 z.writestr('source-snapshot.json',json.dumps({'schema_version':1,'tool':'C01','version':'0.1.0','scope':'Only C01 and unchanged shared packages; package scripts narrowed to C01 candidate. No formal release/site/catalog mutation.','files':snapshot},ensure_ascii=False,indent=2))
manifest={f.name:{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in sorted(out.iterdir()) if f.is_file()}
(root/'progress/evidence/C01/0.1.0/package-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(manifest),'source_bytes':manifest['C01-0.1.0-源码.zip']['bytes']},ensure_ascii=False))
