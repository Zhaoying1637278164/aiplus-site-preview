from PIL import Image,ImageDraw
from pathlib import Path
import hashlib,json
p=Path('progress/evidence/C01/0.1.0/browser');names=['月结总览','期间建档','任务模板','依赖与日程','本期执行','证据管理','未结事项','变更记录','封板与恢复'];files={}
for width in [1440,768,320]:
 for group in range(3):
  pics=[]
  for name in names[group*3:group*3+3]:
   f=p/f'{width}-{name}.png';files[str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'dimensions':Image.open(f).size};im=Image.open(f);target=600 if width!=320 else 320;im=im.resize((target,round(im.height*target/im.width)));canvas=Image.new('RGB',(target,im.height+36),'white');canvas.paste(im,(0,36));ImageDraw.Draw(canvas).text((6,8),f'{width} / {names.index(name)+1}',fill='black');pics.append(canvas)
  canvas=Image.new('RGB',(sum(im.width for im in pics),max(im.height for im in pics)), '#ddd');x=0
  for im in pics:canvas.paste(im,(x,0));x+=im.width
  canvas.save(p/f'contact-{width}-{group}.png')
(p/'screenshots.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
