import pathlib,subprocess,json,datetime
p=pathlib.Path('progress/evidence/C01/0.1.0');p.mkdir(parents=True,exist_ok=True);result=[]
for name,cmd in [('unit-tests',['node','--import','tsx','--test','tools/C01-月结工作台/tests/engine.test.ts','tools/C01-月结工作台/tests/io.test.ts']),('typecheck',['node','node_modules/typescript/bin/tsc','--noEmit','-p','tools/C01-月结工作台/tsconfig.json']),('build',['node','--import','tsx','tools/C01-月结工作台/tests/build.ts'])]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(p/(name+'.log')).write_text(r.stdout);result.append({'name':name,'command':' '.join(cmd),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':str(p/(name+'.log'))})
 if r.returncode:break
(p/'commands.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if len(result)==3 and all(r['exit_code']==0 for r in result) else 1)
