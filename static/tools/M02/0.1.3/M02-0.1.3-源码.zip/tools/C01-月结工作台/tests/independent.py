# Independent oracle: Python XML/ZIP/Decimal/hashlib; never imports the tested TS engine.
from pathlib import Path
from decimal import Decimal
import json,zipfile,xml.etree.ElementTree as ET,hashlib,base64
root=Path.cwd();p=root/'progress/evidence/C01/0.1.0';o=root/'tools/C01-月结工作台/candidate/0.1.0';b=json.loads((p/'browser/result.json').read_text());checks=[]
def check(name,condition):
 assert condition,name
 checks.append(name)
ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def sheets(file):
 with zipfile.ZipFile(file) as z:
  ss=[]
  if 'xl/sharedStrings.xml' in z.namelist():ss=[''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml'))]
  out=[]
  for f in sorted(n for n in z.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')):
   rows=[]
   for row in ET.fromstring(z.read(f)).findall('x:sheetData/x:row',ns):
    vals={}
    for c in row:
     col=0
     for ch in ''.join(x for x in c.attrib['r'] if x.isalpha()):col=col*26+ord(ch)-64
     assert c.find('x:f',ns) is None
     v=c.find('x:v',ns);val=v.text if v is not None else ''
     if c.attrib.get('t')=='s':val=ss[int(val)]
     if c.attrib.get('t')=='inlineStr':val=''.join(c.find('x:is',ns).itertext())
     vals[col-1]=val
    rows.append([vals.get(i,'') for i in range(max(vals.keys(),default=-1)+1)])
   out.append(rows)
  return out
report=next(Path(d['path']) for d in b['downloads'] if d['name'].endswith('.xlsx'));r=sheets(report)
check('独立XML六页底稿',len(r)==6)
expected=['2026-09-30','2026-10-01','2026-10-01','2026-10-02','2026-10-03','2026-10-05']
for i,day in enumerate(expected):
 check('人工截止行'+str(i+2),r[1][i+1][4]==day);check('人工完成状态行'+str(i+2),r[1][i+1][7]=='已完成');check('逐行保留模板来源'+str(i+2),'行' in r[1][i+1][10])
check('人工事项关联CUT',r[3][1][2]=='CUT');check('负事项精度',Decimal(r[3][1][6])==Decimal('-10.25'));check('事项已处理与说明',r[3][1][9]=='已处理' and bool(r[3][1][10]));
full=next(Path(d['path']) for d in b['downloads'] if d['name']=='C01-完整工作.json');zfile=next(Path(d['path']) for d in b['downloads'] if d['name']=='C01-完整归档.zip')
with zipfile.ZipFile(zfile) as z:check('完整JSON与下载ZIP同字节',z.read('work.json')==full.read_bytes())
x=json.loads(full.read_text());period=x['work']['periods'][0]
for e in period['evidence']:check('原字节SHA独立核对 '+e['task'],hashlib.sha256(base64.b64decode(e['content'])).hexdigest()==e['sha'] and len(base64.b64decode(e['content']))==e['bytes'])
no=next(Path(d['path']) for d in b['downloads'] if d['name']=='C01-无数据方案.json');n=json.loads(no.read_text());check('无数据仅模板独立核对',n['contains_data'] is False and not n['work']['periods'] and not n['work']['logs'] and len(n['work']['templates'])==6)
with zipfile.ZipFile(o/'C01-0.1.0-离线包.zip') as z:
 check('离线ZIP12文件完整',len(z.namelist())==12)
 for member in z.namelist():check('离线成员字节 '+member,z.read(member)==(o/Path(member).name).read_bytes())
with zipfile.ZipFile(o/'C01-0.1.0-源码.zip') as z:
 snap=json.loads(z.read('source-snapshot.json'));check('源码无node_modules/凭据',not any('node_modules/' in n or '/.env' in n or '/.aws/' in n for n in z.namelist()))
 check('源码锁/共享/C01/测试齐备',all(n in z.namelist() for n in ['package-lock.json','packages/core/io.ts','packages/ui/tool-host.ts','tools/C01-月结工作台/src/engine.ts','tools/C01-月结工作台/tests/engine.test.ts']))
 check('源码快照每文件SHA',all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in snap['files'].items()))
result={'passed':True,'method':'Hand-written expected rows; independent Python XML/Decimal/hashlib/ZIP; no tested engine imports','checks':checks,'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest()};(p/'independent-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':True,'checks':len(checks)}))
