import pathlib,zipfile,subprocess,json,hashlib,os
root=pathlib.Path.cwd();out=root/'tools/C01-月结工作台/candidate/0.1.0';dest=root/'progress/evidence/C01/0.1.0/source-rebuild';dest.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out/'C01-0.1.0-源码.zip') as z:z.extractall(dest)
# Offline, clean lock installation using the machine npm cache. No symlink to the development node_modules.
env=dict(os.environ);env['npm_config_offline']='true';commands=[['npm','ci'],['npm','test'],['npm','run','typecheck'],['npm','run','build','--','C01']];results=[]
for i,c in enumerate(commands):
 p=subprocess.run(c,cwd=dest,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(dest/f'command-{i+1}.log').write_text(p.stdout);results.append({'command':' '.join(c),'exit_code':p.returncode,'log':str(dest/f'command-{i+1}.log')})
 if p.returncode:break
same={}
if len(results)==4 and all(r['exit_code']==0 for r in results):
 for f in sorted(out.iterdir()):
  if f.suffix=='.zip':continue
  rebuilt=dest/'tools/C01-月结工作台/candidate/0.1.0'/f.name
  same[f.name]={'original_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'rebuilt_sha256':hashlib.sha256(rebuilt.read_bytes()).hexdigest(),'same':f.read_bytes()==rebuilt.read_bytes()}
result={'passed':len(results)==4 and all(r['exit_code']==0 for r in results) and all(v['same'] for v in same.values()),'commands':results,'files':same}
(root/'progress/evidence/C01/0.1.0/source-rebuild-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if result['passed'] else 1)
