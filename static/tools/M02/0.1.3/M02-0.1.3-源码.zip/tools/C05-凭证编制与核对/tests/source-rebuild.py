from pathlib import Path
import subprocess,json,hashlib,time,sys,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();src=root/'progress/evidence/C05/source';log=root/'progress/evidence/C05/source-rebuild.json';results=[]
for command in [['npm','ci','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]:
 start=time.time();p=subprocess.run(command,cwd=src,capture_output=True,text=True);results.append({'command':command,'cwd':str(src),'exit_code':p.returncode,'seconds':round(time.time()-start,2),'stdout':p.stdout,'stderr':p.stderr});log.write_text(json.dumps({'status':'running' if p.returncode==0 else 'failed','commands':results},ensure_ascii=False,indent=2));print(command,'actual exit',p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
a=root/'tools/C05-凭证编制与核对/candidate/0.1.0';b=src/'tools/C05-凭证编制与核对/candidate/0.1.0';comparisons=[]
for p in a.iterdir():
 if not p.is_file():continue
 q=b/p.name
 if p.suffix=='.zip':continue
 q=b/p.name
 h=lambda v:hashlib.sha256(v.read_bytes()).hexdigest()
 assert h(p)==h(q),p.name
 comparisons.append({'file':p.name,'sha256':h(p),'byte_identical':True})
log.write_text(json.dumps({'status':'passed','commands':results,'comparisons':comparisons,'scope':'isolated candidate source snapshot; final package by root','windows':'unverified'},ensure_ascii=False,indent=2));print('source rebuild passed',len(comparisons),'assets')
