"""Independent Python Decimal answers; never imports the TypeScript engine."""
from decimal import Decimal
from pathlib import Path
import json
cases=[]
for amounts in [['0.10','0.20'],['123456789012345678.12','0.88'],['-10.11','-0.29'],['1.000001','2.000002'],['7.55','6.44','2.01']]:
 total=sum(map(Decimal,amounts),Decimal(0));cases.append({'debits':amounts,'credit':format(total,'f'),'expected_debit':format(total,'f'),'expected_credit':format(total,'f'),'expected_difference':'0'})
out=Path(__file__).parent/'fixtures';out.mkdir(exist_ok=True);(out/'independent.json').write_text(json.dumps({'author':'Python decimal sum, independent of tested program','cases':cases},indent=2))
print('5 independent cases written')
