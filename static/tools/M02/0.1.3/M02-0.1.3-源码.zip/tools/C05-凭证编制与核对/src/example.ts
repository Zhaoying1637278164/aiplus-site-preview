import type {Table} from '../../../packages/core/types';import {fields,type Tables,type Kind} from './engine';
export function makeTable(kind:Kind,rows:unknown[][],file='完全虚构-'+kind+'.csv'):Table{return {file,sheet:kind,headers:fields[kind],rows:rows.map((r,i)=>({file,sheet:kind,row:i+2,cells:Object.fromEntries(fields[kind].map((f,j)=>[f,(r[j]??null) as string|number|null]))}))};}
export const examples:Tables={
 business:makeTable('business',[
 ['B001','V001','虚构甲公司','2026-09','CNY','元','费用含税','100','6','虚构服务费','财务部','虚构供应商','P001','虚构合同001'],
 ['B002','V001','虚构甲公司','2026-09','CNY','元','费用含税','200','12','虚构服务费','财务部','虚构供应商','P001','虚构合同002'],
 ['B003','V002','虚构甲公司','2026-09','CNY','元','费用含税','-50','-3','虚构红冲','财务部','虚构供应商','P001','虚构红冲依据']]),
 templates:makeTable('templates',[
 ['费用含税','1','费用','借','金额','1','2026-01','2026-12'],['费用含税','2','进项','借','税额','1','2026-01','2026-12'],['费用含税','3','应付','贷','金额','1','2026-01','2026-12'],['费用含税','4','应付','贷','税额','1','2026-01','2026-12']]),
 accounts:makeTable('accounts',[
 ['虚构甲公司','费用','6602001','虚构费用','是','否','是','2026-01','2026-12'],['虚构甲公司','进项','2221001','虚构进项税底稿','否','否','否','2026-01','2026-12'],['虚构甲公司','应付','2202001','虚构应付款','否','是','否','2026-01','2026-12']])};

export function demoExamples():Tables{const x=structuredClone(examples);const r=x.business!.rows[2];r.cells["金额"]="50000";r.cells["税额"]="3000";r.cells["摘要"]="虚构服务费";return x;}
