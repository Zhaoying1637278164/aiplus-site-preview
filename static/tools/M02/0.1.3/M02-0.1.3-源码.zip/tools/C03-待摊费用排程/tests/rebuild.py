# coding: utf-8
from pathlib import Path
import tempfile,zipfile,subprocess,json,hashlib,os,re
root=Path.cwd();out=root/'tools/C03-待摊费用排程/candidate/0.1.0';evidence=root/'progress/evidence/C03/0.1.0';dest=Path(tempfile.mkdtemp(prefix='C03-source-rebuild-',dir='/private/tmp'))
with zipfile.ZipFile(out/'C03-0.1.0-源码.zip') as z:
 z.extractall(dest)
 snap=json.loads(z.read('source-snapshot.json'));assert all(hashlib.sha256((dest/n).read_bytes()).hexdigest()==h for n,h in snap['files'].items())
env=dict(os.environ);env['npm_config_offline']='true';results=[]
for n,cmd in enumerate([['npm','ci'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]):
 proc=subprocess.run(cmd,cwd=dest,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);log=evidence/f'rebuild-command-{n+1}.txt';log.write_text(proc.stdout);results.append({'command':' '.join(cmd),'exit_code':proc.returncode,'log':str(log.relative_to(root))})
 if proc.returncode:break
files={};passed=len(results)==4 and all(r['exit_code']==0 for r in results)
if passed:
 rebuilt=dest/'tools/C03-待摊费用排程/candidate/0.1.0'
 for f in sorted(out.iterdir()):
  if f.suffix=='.zip':continue
  b=rebuilt/f.name;entry={'original_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'rebuilt_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'byte_equal':f.read_bytes()==b.read_bytes()}
  if f.suffix=='.xlsx':
   with zipfile.ZipFile(f) as a,zipfile.ZipFile(b) as z:
    assert a.namelist()==z.namelist();members={};ignored=[]
    for name in a.namelist():
     aa,bb=a.read(name),z.read(name)
     if name=='docProps/core.xml':
      def dates(x):return re.sub(rb'<dcterms:(created|modified)[^>]*>.*?</dcterms:\1>',b'<date>BUILD_TIMESTAMP</date>',x)
      if aa!=bb:ignored.append('docProps/core.xml created/modified only')
      aa,bb=dates(aa),dates(bb)
     members[name]=aa==bb
    entry.update(content_equal=all(members.values()),members=members,allowed_metadata_difference=ignored)
  elif f.name=='build-manifest.json':
   a=json.loads(f.read_text());bman=json.loads(b.read_text());a['files'].pop('虚构样例.xlsx');bman['files'].pop('虚构样例.xlsx');entry['content_equal']=a==bman;entry['allowed_metadata_difference']='Only generated XLSX file hash after timestamp comparison'
  else:entry['content_equal']=entry['byte_equal']
  files[f.name]=entry
 passed=passed and all(x['content_equal'] for x in files.values())
result={'passed':passed,'destination':str(dest),'clean_lock_install':True,'snapshot_hash_verified':True,'commands':results,'files':files,'platform':os.uname().sysname,'windows':'not run','method':'HTML/runtime and non-XLSX assets exact bytes; XLSX compares every archive member with only created/modified timestamps excluded; build-manifest excludes that XLSX hash only'}
(evidence/'source-rebuild-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':passed,'commands':len(results),'files':len(files),'destination':str(dest)}));raise SystemExit(0 if passed else 1)
