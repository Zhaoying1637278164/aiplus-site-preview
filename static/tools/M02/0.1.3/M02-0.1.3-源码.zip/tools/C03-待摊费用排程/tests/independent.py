# coding: utf-8
from fractions import Fraction
from datetime import date,timedelta
from pathlib import Path
import json
out=Path('tools/C03-待摊费用排程/examples/independent-expected.json')
def half(x):
 sign=-1 if x<0 else 1
 x=abs(x); q,r=divmod(x.numerator,x.denominator)
 return sign*(q+(r*2>=x.denominator))
def expected(total,weights,tail):
 values=[half(Fraction(total*w,sum(weights))) for w in weights]
 values[0 if tail=='first' else -1]+=total-sum(values)
 return values
cases=[]
for months in [1,2,3,7,12,24]:
 for total in [0,1,100,99999,1200000,-100,-1200000]:
  for tail in ['first','last']:
   vals=expected(total,[1]*months,tail)
   if any(x*total<0 for x in vals):continue
   start=date(2026,1,1);lastYear=2026+(months-1)//12;lastMonth=(months-1)%12+1
   end=(date(lastYear+1,1,1) if lastMonth==12 else date(lastYear,lastMonth+1,1))-timedelta(days=1)
   cases.append(dict(total=f'{total/100:.2f}',start=str(start),end=str(end),method='month',tail=tail,expected=[f'{v/100:.2f}' for v in vals]))
for start,end,total in [('2024-02-28','2024-03-01',30000),('2026-01-16','2026-02-15',31000),('2024-01-01','2024-12-31',366000),('2026-01-01','2026-12-31',365000),('2026-12-31','2027-01-01',10001)]:
 d=date.fromisoformat(start);finish=date.fromisoformat(end);counts={}
 while d<=finish:
  k=str(d)[:7];counts[k]=counts.get(k,0)+1;d+=timedelta(days=1)
 vals=expected(total,list(counts.values()),'last')
 cases.append(dict(total=f'{total/100:.2f}',start=start,end=end,method='day',tail='last',expected=[f'{v/100:.2f}' for v in vals],weights=list(counts.values())))
out.write_text(json.dumps({'method':'Independent integer cents/Fraction and Python datetime; no engine imports','cases':cases},ensure_ascii=False,indent=2)+'\n')
print('independent cases',len(cases))
