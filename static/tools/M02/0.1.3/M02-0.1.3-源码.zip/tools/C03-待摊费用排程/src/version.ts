export const VERSION='0.1.1'; export const RULE_VERSION='C03-2026-10-04.1';
