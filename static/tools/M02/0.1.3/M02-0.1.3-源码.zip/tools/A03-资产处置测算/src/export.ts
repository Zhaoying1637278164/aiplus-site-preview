import {workbookBytes} from '../../../packages/core/io';import {calculate,canExport,kinds,names,VERSION,RULE_VERSION,type State} from './engine';
export function csv(headers:string[],rows:unknown[][]){return '\uFEFF'+[headers,...rows].map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n')}
export function sheets(s:State){const r=calculate(s);const vals=['original','oldDep','addition','totalDep','impairment','totalNet','allocatedCost','allocatedDep','allocatedImp','net','remainingCost','remainingDep','remainingImp','remainingNet','revenue','vat','gross','costs','inputVat','feeGross','gain','allocationResidual'];const labels=['整项原值','原累计折摊','本次补提','截止累计折摊','整项减值','整项截止净值','处置原值','处置累计折摊','处置减值','处置净值','保留原值','保留累计折摊','保留减值','保留净值','不含税收入','销项税','应收对价总额','损益税费','抵扣税','应付费用总额','处置损益','分配勾稽差'];return [
 {name:'参数与版本',headers:['参数','值'],rows:[['应用',VERSION],['规则',RULE_VERSION],['方案schema','1'],['状态',canExport(s,r)?'已复核测算底稿':'诊断草稿'],...Object.entries(s.rule).map(([k,v])=>[k,JSON.stringify(v)]),['有效处置',r.valid],['阻塞处置',r.blocked],...Object.entries(r.totals)]},
 {name:'处置测算',headers:['处置ID','资产ID','名称','状态','处置日','截止日','截止口径','处置范围','对价口径',...labels,'提示','来源'],rows:r.items.map(i=>[i.id,i.asset,i.name,i.errors.length?'阻塞':'有效',i.values.day,i.values.cut,i.values.cutMode,i.values.range,i.values.priceMode,...vals.map(k=>i.values[k]),i.warnings.join('；'),i.sources.map(x=>`${x.file}/${x.sheet}/${x.row}`).join('；')])},
 {name:'借贷分录',headers:['处置ID','阶段','科目','借方','贷方','来源','规则'],rows:r.entries.map(e=>[e.disposal,e.stage,e.account,e.debit,e.credit,e.source,RULE_VERSION])},
 {name:'异常与待办',headers:['处置ID','问题'],rows:[...r.errors.map(x=>['整批',x]),...r.items.flatMap(i=>[...i.errors,...i.warnings].map(x=>[i.id,x]))]},
 {name:'复核',headers:['处置ID','复核人','依据'],rows:Object.entries(s.reviews).map(([k,v])=>[k,v.reviewer,v.basis])},
 ...kinds.filter(k=>s.data[k]).map(k=>{const t=s.data[k]!;return {name:'来源-'+names[k],headers:['文件','页签','原行',...t.headers],rows:t.rows.map(x=>[x.file,x.sheet,x.row,...t.headers.map(h=>x.cells[h])])}}),
 ...kinds.filter(k=>s.originals[k]).map(k=>{const t=s.originals[k]!;return {name:'导入原件-'+names[k],headers:['文件','页签','原行',...t.headers],rows:t.rows.map(x=>[x.file,x.sheet,x.row,...t.headers.map(h=>x.cells[h])])}}),
 {name:'字段映射',headers:['资料','标准字段','来源字段'],rows:kinds.flatMap(k=>Object.entries(s.mapping[k]).map(([a,b])=>[names[k],a,b]))}
 ]}
export async function exportWorkbook(s:State,diagnostic=false){if(!diagnostic&&!canExport(s))throw Error('仍有阻塞或未完成逐项复核/科目确认');return workbookBytes(sheets(s))}
