from pathlib import Path
import shutil,json,zipfile,hashlib
root=Path.cwd();out=root/'progress/evidence/A03/source';
if out.exists():shutil.rmtree(out)
out.mkdir(parents=True,exist_ok=True)
for name in ['packages','tools/A03-资产处置测算']:
 target=out/name
 if target.exists():shutil.rmtree(target)
 shutil.copytree(root/name,target,ignore=shutil.ignore_patterns('node_modules','.DS_Store'))
for name in ['package.json','package-lock.json','AGENTS.md']:
 shutil.copy2(root/name,out/name)
p=json.loads((out/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/A03-资产处置测算/tests/engine.test.ts','typecheck':'tsc --noEmit','build':'node --import tsx tools/A03-资产处置测算/tests/build-candidate.ts'};(out/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(out/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','jsx':'react-jsx','strict':True,'esModuleInterop':True,'skipLibCheck':True,'lib':['ES2022','DOM'],'types':['node'],'noEmit':True},'include':['packages','tools']},indent=2))
shutil.copy2(root/'progress/evidence/A03/candidate/0.1.0/THIRD_PARTY_NOTICES.md',out/'THIRD_PARTY_NOTICES.md')
(out/'references').mkdir(exist_ok=True);shutil.copy2(root/'references/saxes-5.0.1-LICENSE',out/'references/saxes-5.0.1-LICENSE')
(out/'BUILD.md').write_text('# A03候选源码重建\nNode22+，npm ci，npm test，npm run typecheck，npm run build。产物在progress/evidence/A03/candidate/0.1.0。需要网络安装锁定依赖；成品无网络。测试浏览器使用本机Chrome，按本款tests/browser.ts路径配置。无业务数据、凭据、node_modules。公共包为当前读取快照，正式集成由总控验证。\n')
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and 'node_modules' not in p.parts}
(root/'progress/evidence/A03/source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
archive=root/'progress/evidence/A03/A03-0.1.0-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n in manifest:z.write(out/n,n)
print(json.dumps({'archive':str(archive.relative_to(root)),'files':len(manifest),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},ensure_ascii=False))
