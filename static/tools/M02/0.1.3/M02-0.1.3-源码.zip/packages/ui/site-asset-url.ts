/** Resolve only registered, first-party program/download JSON; never user files. */
export function siteAssetURL(url:URL,baseURI:string,prefix?:unknown):URL{
 const base=new URL(baseURI);
 const match=url.pathname.match(/\/app\/static\/tools\/([A-Z]\d{2}\/\d+\.\d+\.\d+\/(?:runtime|download-\d{1,2})\.json)$/);
 if(url.origin!==base.origin||!match||url.search||url.hash)throw Error('程序资源来源无效');
 if(prefix===undefined)return url;
 if(typeof prefix!=='string'||!/^component\/[A-Za-z_][A-Za-z0-9_.]*\.aiplus_tool_assets\/tools\/$/.test(prefix))throw Error('程序资源入口无效');
 const target=new URL(prefix+match[1],base);
 if(target.origin!==base.origin)throw Error('程序资源来源无效');
 return target;
}
export function websiteAssetURL(url:URL):URL{
 return siteAssetURL(url,document.baseURI,(window as Window&{__AIPlusAssetPrefix?:unknown}).__AIPlusAssetPrefix);
}
