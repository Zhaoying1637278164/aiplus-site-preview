/** Native website/standalone mount boundary. No financial data crosses this boundary. */
export type ToolId = string;
export interface ToolHostContext {
  /** A dedicated node in the website workspace or the offline document. */
  container: HTMLElement;
  mode: 'website' | 'offline';
  /** Return to the business detail page; never sends user data to the host. */
  onExit?: () => void;
}
export interface ToolInstance {
  /** Synchronously confirm leaving when this tool contains unsaved work. */
  requestExit(): boolean;
  /** Must release React state, file buffers, object URLs and listeners. */
  dispose(): void;
}
export interface ToolProgram {
  id: ToolId;
  version: string;
  name: string;
  /** Mount the tool's own business workflow, without another document or iframe. */
  mount(context: ToolHostContext): ToolInstance;
}
