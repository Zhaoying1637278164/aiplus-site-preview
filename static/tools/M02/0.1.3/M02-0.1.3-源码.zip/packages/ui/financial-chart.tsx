import {userText} from './user-text';
import React from 'react';
export interface ChartPoint {label:string;value:string|null}
/** Visual projection only. Exact strings remain in labels and the financial engine. */
export function FinancialChart({title,unit,points,kind='bar'}:{title:string;unit:string;points:ChartPoint[];kind?:'bar'|'line'}){
 unit=String(userText(unit));
 const values=points.map(p=>p.value===null?null:Number(p.value));
 if(!points.length||values.some(v=>v!==null&&!Number.isFinite(v)))return null;
 const low=Math.min(0,...values.filter((v):v is number=>v!==null)),high=Math.max(1,...values.filter((v):v is number=>v!==null));
 const y=(v:number)=>205-(v-low)/(high-low)*170,step=650/Math.max(1,points.length),x=(i:number)=>65+step*(i+.5);
 // Separate contiguous runs: missing values never become zero or bridge a line.
 const runs:string[]=[];let run:string[]=[];values.forEach((v,i)=>{if(v===null){if(run.length)runs.push(run.join(' '));run=[]}else run.push(`${x(i)},${y(v)}`)});if(run.length)runs.push(run.join(' '));
 return <figure style={{margin:'16px 0',padding:16,border:'1px solid #dbe4ed',borderRadius:12,background:'#fff'}}><figcaption style={{fontWeight:600}}>{title} <small>（{unit}）</small></figcaption><svg viewBox="0 0 760 290" role="img" aria-label={title} style={{width:'100%',height:'auto'}}><line x1="65" x2="715" y1={y(0)} y2={y(0)} stroke="#a9bac8"/><text x="5" y="35" fontSize="12">{high.toLocaleString('zh-CN')}</text>{kind==='line'&&runs.map((r,i)=><polyline key={i} points={r} fill="none" stroke="#1571c9" strokeWidth="3"/>)}{points.map((p,i)=>{const v=values[i];return <g key={i}><title>{p.label}：{p.value??'无资料'} {unit}</title>{v!==null&&(kind==='bar'?<rect x={x(i)-step*.3} y={Math.min(y(0),y(v))} width={step*.6} height={Math.max(1,Math.abs(y(v)-y(0)))} fill={v<0?'#d75b50':'#1571c9'}/>:<circle cx={x(i)} cy={y(v)} r="4" fill="#1571c9"/>)}<text x={x(i)} y="230" textAnchor="middle" fontSize="12">{p.label}</text><text x={x(i)} y="252" textAnchor="middle" fontSize="10">{p.value??'无资料'}</text></g>})}</svg></figure>
}
export function FinancialLines({title,unit,labels,series}:{title:string;unit:string;labels:string[];series:{name:string;values:string[]}[]}){
 unit=String(userText(unit));
 const values=series.flatMap(s=>s.values.map(Number));if(!values.length||values.some(v=>!Number.isFinite(v)))return null;
 const low=Math.min(0,...values),high=Math.max(1,...values),y=(v:number)=>205-(v-low)/(high-low)*170,x=(i:number)=>65+i*650/Math.max(1,labels.length-1),colors=['#1571c9','#d75b50','#23855a'];
 return <figure style={{margin:'16px 0',padding:16,border:'1px solid #dbe4ed',borderRadius:12,background:'#fff'}}><figcaption>{title}（{unit}）</figcaption><svg viewBox="0 0 760 285" role="img" aria-label={title} style={{width:'100%'}}><line x1="65" x2="715" y1={y(0)} y2={y(0)} stroke="#a9bac8"/>{series.map((s,j)=><g key={s.name}><polyline points={s.values.map((v,i)=>`${x(i)},${y(Number(v))}`).join(' ')} fill="none" stroke={colors[j%3]} strokeWidth="3"/><text x={65+j*220} y="270" fill={colors[j%3]}>{s.name}</text>{s.values.map((v,i)=><circle key={i} cx={x(i)} cy={y(Number(v))} r="3" fill={colors[j%3]}><title>{labels[i]} · {s.name}：{v} {unit}</title></circle>)}</g>)}{labels.map((label,i)=>i%Math.max(1,Math.floor(labels.length/8))===0&&<text key={i} x={x(i)} y="232" textAnchor="middle" fontSize="11">{label}</text>)}</svg></figure>
}
/** A view of exact engine factors; the final total comes from the engine. */
export function FinancialWaterfall({title,unit,start,factors,end}:{title:string;unit:string;start:ChartPoint;factors:ChartPoint[];end:ChartPoint}){
 unit=String(userText(unit));
 if([start,end,...factors].some(p=>p.value===null))return null;
 let total=Number(start.value);const steps=[{...start,from:0,to:total,total:true},...factors.map(p=>{const from=total;total+=Number(p.value);return {...p,from,to:total,total:false}}),{...end,from:0,to:Number(end.value),total:true}];
 if(steps.some(p=>!Number.isFinite(p.from)||!Number.isFinite(p.to)))return null;
 const lo=Math.min(0,...steps.flatMap(p=>[p.from,p.to])),hi=Math.max(1,...steps.flatMap(p=>[p.from,p.to])),y=(n:number)=>205-(n-lo)/(hi-lo)*170,w=650/steps.length;
 return <figure style={{margin:'16px 0',padding:16,border:'1px solid #dbe4ed',borderRadius:12,background:'#fff'}}><figcaption>{title}（{unit}）</figcaption><svg viewBox="0 0 760 275" role="img" aria-label={title} style={{width:'100%'}}><line x1="65" x2="715" y1={y(0)} y2={y(0)} stroke="#a9bac8"/>{steps.map((p,i)=><g key={i}><title>{p.label}：{p.value} {unit}</title><rect x={65+w*(i+.2)} y={Math.min(y(p.from),y(p.to))} width={w*.6} height={Math.max(1,Math.abs(y(p.from)-y(p.to)))} fill={p.total?'#1571c9':Number(p.value)<0?'#23855a':'#d75b50'}/><text x={65+w*(i+.5)} y="230" textAnchor="middle" fontSize="11">{p.label}</text></g>)}</svg><p style={{fontSize:12,margin:0}}>完整金额与来源见下方明细。</p></figure>
}
