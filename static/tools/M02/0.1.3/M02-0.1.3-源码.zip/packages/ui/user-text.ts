import type {ReactNode} from 'react';
/** Presentation only: identifiers, financial values and saved settings are unchanged. */
export function userText(value:ReactNode):ReactNode {
 if(typeof value!=='string')return value;
 return value.replace(/USD\s*(?:\/\s*)?元/g,'USD / 美元').replace(/EUR\s*(?:\/\s*)?元/g,'EUR / 欧元').replace(/JPY\s*(?:\/\s*)?元/g,'JPY / 日元').replace(/不补零/g,'空值不当作0').replace(/阻塞/g,'待处理').replace(/守恒/g,'合计核对').replace(/残差/g,'未解释差额').replace(/容差/g,'允许差额').replace(/种子/g,'随机编号').replace(/方案/g,'设置文件');
}
