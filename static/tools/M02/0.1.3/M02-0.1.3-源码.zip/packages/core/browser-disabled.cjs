module.exports=new Proxy({}, {get(){return function(){throw new Error('此浏览器工具不支持文件系统、密码保护和系统API')}}});
