import Decimal from 'decimal.js';
import type {Cell} from './types';
Decimal.set({ precision: 40, rounding: Decimal.ROUND_HALF_UP });
export function text(v: Cell, trim = false, ignoreCase = false): string {
 if(v === null || v === undefined || typeof v === 'object') throw Error('缺失值或公式单元格，须提供静态值');
 let s = String(v); if(trim) s=s.trim(); if(ignoreCase) s=s.toLocaleLowerCase('zh-CN');
 if(s.trim()==='') throw Error('必填值为空'); return s;
}
export function amount(v: Cell): Decimal {
 if(typeof v==='number'&&(!Number.isFinite(v)||Math.abs(v)>Number.MAX_SAFE_INTEGER))throw Error('数值金额超过安全精度，请以文本提供原始十进制值');
 const s=text(v).trim();
 if(!/^[+-]?\d+(?:\.\d{1,6})?$/.test(s)) throw Error('金额须为十进制数字（最多6位小数，不含千分位/括号）');
 if(s.replace(/\D/g,'').length>24) throw Error('金额超过24位数字');
 return new Decimal(s);
}
export function date(v: Cell): string {
 const s=text(v); if(!/^\d{4}-\d{2}-\d{2}$/.test(s)) throw Error('日期须为 YYYY-MM-DD');
 const [y,m,d]=s.split('-').map(Number); const x=new Date(Date.UTC(y,m-1,d));
 if(y<1900 || x.getUTCFullYear()!==y || x.getUTCMonth()!==m-1 || x.getUTCDate()!==d) throw Error('日期无效'); return s;
}
