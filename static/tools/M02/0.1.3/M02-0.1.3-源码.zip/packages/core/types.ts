export type Cell = string | number | null | { formula: string; cached: unknown };
export interface SourceRow { file: string; sheet: string; row: number; cells: Record<string, Cell> }
export interface Table { file: string; sheet: string; headers: string[]; rows: SourceRow[] }
export interface Mapping { left: string; right: string; type: 'text' | 'amount' | 'date' }
export interface Rule { schema_version: 1; tool: 'D02'; keys: Mapping[]; fields: Mapping[]; currency: { left: string; right: string }; tolerance: string; trim: boolean; ignoreCase: boolean }
export const VERSION = '0.1.0';
export const RULE_VERSION = 'D02-2026-10-03.1';
export const LIMITS = { bytes: 10 * 1024 * 1024, inflated: 30 * 1024 * 1024, rows: 20000, columns: 200 };
