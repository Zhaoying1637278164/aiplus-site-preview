module.exports=class DisabledCSV {constructor(){throw new Error('CSV由本工具的受限读取器处理')}};
