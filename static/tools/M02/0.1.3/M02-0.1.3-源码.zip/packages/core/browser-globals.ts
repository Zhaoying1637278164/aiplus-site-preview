import {Buffer} from 'buffer';
const global=globalThis;
const process={browser:true,version:'',env:{NODE_ENV:'production'},nextTick:(fn:(...args:unknown[])=>void,...args:unknown[])=>queueMicrotask(()=>fn(...args))};
const setImmediate=(fn:(...args:unknown[])=>void,...args:unknown[])=>setTimeout(()=>fn(...args),0);
const clearImmediate=(id:number)=>clearTimeout(id);
export {Buffer,global,process,setImmediate,clearImmediate};
