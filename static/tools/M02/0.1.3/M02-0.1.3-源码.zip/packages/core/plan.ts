import {LIMITS, VERSION, RULE_VERSION, type Rule} from './types';
export function encodePlan(rule:Rule):string {
 return JSON.stringify({schema_version:1,tool:'D02',contains_data:false,app_version:VERSION,rule_version:RULE_VERSION,rule},null,2);
}
export function decodePlan(raw:string):Rule {
 if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MB');
 const p=JSON.parse(raw);
 if(p?.schema_version!==1||p?.tool!=='D02'||p?.contains_data!==false||p?.app_version!==VERSION||p?.rule_version!==RULE_VERSION)throw Error('方案版本不兼容或包含数据；仅接受当前版本无数据方案');
 const r=p.rule;
 if(r?.schema_version!==1||r?.tool!=='D02'||!Array.isArray(r.keys)||!Array.isArray(r.fields)||!r.keys.length||!r.fields.length||r.keys.length+r.fields.length>30)throw Error('方案映射无效');
 for(const m of [...r.keys,...r.fields])if(!m||typeof m.left!=='string'||typeof m.right!=='string'||!['text','amount','date'].includes(m.type))throw Error('方案字段无效');
 if(r.keys.some((m:Rule['keys'][number])=>m.type!=='text')||typeof r.trim!=='boolean'||typeof r.ignoreCase!=='boolean'||typeof r.tolerance!=='string'||typeof r.currency?.left!=='string'||typeof r.currency?.right!=='string')throw Error('方案参数无效');
 return {schema_version:1,tool:'D02',keys:r.keys.map((m:Rule['keys'][number])=>({...m})),fields:r.fields.map((m:Rule['fields'][number])=>({...m})),currency:{...r.currency},trim:r.trim,ignoreCase:r.ignoreCase,tolerance:r.tolerance};
}
