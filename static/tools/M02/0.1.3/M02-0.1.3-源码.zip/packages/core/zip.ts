import pako from 'pako';
import {LIMITS} from './types';
// Validate the directory and actual inflation with a bounded chunk sink before ExcelJS.
export function guardZip(bytes:Uint8Array){
 const d=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let end=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(d.getUint32(i,true)===0x06054b50){end=i;break}
 if(end<0)throw Error('xlsx不是有效ZIP工作簿');
 if(d.getUint16(end+4,true)||d.getUint16(end+6,true))throw Error('不支持分卷ZIP');
 const count=d.getUint16(end+10,true),offset=d.getUint32(end+16,true),length=d.getUint32(end+12,true);
 if(count>2000||!count||offset+length!==end)throw Error('工作簿结构超限或目录损坏');
 let p=offset,declared=0,actual=0;const names=new Set<string>();
 for(let i=0;i<count;i++){
 if(p+46>end||d.getUint32(p,true)!==0x02014b50)throw Error('工作簿目录损坏');
 const flags=d.getUint16(p+8,true),method=d.getUint16(p+10,true),compressed=d.getUint32(p+20,true),size=d.getUint32(p+24,true),local=d.getUint32(p+42,true);
 const nameLen=d.getUint16(p+28,true),extra=d.getUint16(p+30,true),comment=d.getUint16(p+32,true);
 if(p+46+nameLen+extra+comment>end||local+30>offset||size===0xffffffff||compressed===0xffffffff)throw Error('ZIP64或ZIP目录无效');
 const name=new TextDecoder().decode(bytes.subarray(p+46,p+46+nameLen));
 if(names.has(name)||name.includes('..')||name.startsWith('/')||/vbaProject|externalLinks/i.test(name))throw Error('不支持宏、外链、重复或危险ZIP条目');names.add(name);
 if(flags&1||![0,8].includes(method))throw Error('不支持加密或压缩格式');
 declared+=size;if(declared>LIMITS.inflated)throw Error('工作簿解压后超过30MB限制');
 if(d.getUint32(local,true)!==0x04034b50||d.getUint16(local+8,true)!==method)throw Error('ZIP本地目录损坏');
 const start=local+30+d.getUint16(local+26,true)+d.getUint16(local+28,true);
 if(start+compressed>offset)throw Error('ZIP压缩数据越界');
 let entry=0;
 const accept=(chunk:Uint8Array)=>{entry+=chunk.length;actual+=chunk.length;if(actual>LIMITS.inflated)throw Error('工作簿实际解压超过30MB限制');if(entry>size)throw Error('ZIP解压体积与声明不一致')};
 const input=bytes.subarray(start,start+compressed);
 if(method===0)accept(input);else{const inflater=new pako.Inflate({raw:true,chunkSize:16384});inflater.onData=accept;inflater.push(input,true);if(inflater.err||!inflater.ended)throw Error('ZIP压缩数据损坏')}
 if(entry!==size)throw Error('ZIP解压体积与声明不一致');
 p+=46+nameLen+extra+comment;
 }
 if(p!==end||!names.has('[Content_Types].xml'))throw Error('非标准XLSX工作簿');
}
