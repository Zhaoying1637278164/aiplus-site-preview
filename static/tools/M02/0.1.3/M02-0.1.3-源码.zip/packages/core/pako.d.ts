declare module 'pako' {
 const pako:{Inflate:new(options:{raw:boolean;chunkSize:number})=>{onData:(chunk:Uint8Array)=>void;push:(input:Uint8Array,last:boolean)=>boolean;err:number;ended:boolean}};
 export default pako;
}
