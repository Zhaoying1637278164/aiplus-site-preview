/** Build-time fictitious examples and blank templates; never browser user files. */
export interface ReleaseAsset {filename:string;data:string|Uint8Array}
export type TemplateFilename='空白模板.csv'|'空白模板.xlsx';
export function validateReleaseAssets(assets:ReleaseAsset[],templateFilename:TemplateFilename='空白模板.csv',sampleFilename:'虚构样例.xlsx'|'虚构样例.csv'='虚构样例.xlsx'):void{
 if(templateFilename!=='空白模板.csv'&&templateFilename!=='空白模板.xlsx')throw Error('模板格式未登记');
 if(!['虚构样例.xlsx','虚构样例.csv'].includes(sampleFilename))throw Error('样例格式未登记');
 const names=new Set<string>();
 for(const asset of assets){
  if(!asset||typeof asset.filename!=='string'||!asset.filename||asset.filename.includes('/')||asset.filename.includes('\\')||asset.filename.startsWith('.')||asset.filename.endsWith('.zip'))throw Error('交付文件名无效');
  if(names.has(asset.filename))throw Error('交付文件名重复');names.add(asset.filename);
  if(typeof asset.data!=='string'&&!(asset.data instanceof Uint8Array))throw Error('交付文件内容无效');
  const size=typeof asset.data==='string'?new TextEncoder().encode(asset.data).length:asset.data.byteLength;
  if(size>10*1024*1024)throw Error('模板或虚构样例超过浏览器单文件上限');
 }
 if(!names.has(templateFilename)||!names.has(sampleFilename))throw Error('缺少统一登记的空白模板或虚构样例');
}
