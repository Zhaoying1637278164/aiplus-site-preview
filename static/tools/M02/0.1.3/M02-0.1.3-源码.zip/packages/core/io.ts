import ExcelJS from 'exceljs';
import Papa from 'papaparse';
import type {Cell,Table,SourceRow} from './types';
import {LIMITS} from './types';
export interface LoadedFile { file: string; sheets: {name:string; matrix:Cell[][]}[] }
function guardMatrix(matrix: Cell[][]) {
 if(matrix.length>LIMITS.rows+100) throw Error('超过20000行限制');
 for(const row of matrix) { if(row.length>LIMITS.columns) throw Error('超过200列限制');
 for(const c of row) if(typeof c==='string' && c.length>10000) throw Error('单元格文本超过10000字限制'); }
}
import {guardZip} from './zip';
export async function readFileData(file:string,bytes:Uint8Array):Promise<LoadedFile>{
 if(bytes.length>LIMITS.bytes)throw Error('文件超过10MB限制');
 if(/\.csv$/i.test(file)) {
 const content=new TextDecoder('utf-8',{fatal:true}).decode(bytes).replace(/^\uFEFF/,'');
 const result=Papa.parse<string[]>(content,{skipEmptyLines:false,delimiter:','});
 if(result.errors.length)throw Error('CSV格式错误：'+result.errors[0].message);
 const matrix:Cell[][]=result.data.map(r=>r.map(v=>v===''?null:v));
 while(matrix.length && matrix[matrix.length-1].every(v=>v===null))matrix.pop();
 guardMatrix(matrix); return {file,sheets:[{name:'CSV',matrix}]};
 }
 if(!/\.xlsx$/i.test(file))throw Error('仅支持xlsx和UTF-8 CSV，不支持xls/xlsm/密码文件');
 guardZip(bytes);const wb=new ExcelJS.Workbook();
 try{await wb.xlsx.load(bytes as any);}catch{throw Error('xlsx损坏、加密或格式不支持');}
 const sheets=wb.worksheets.map(ws=>{
 if(ws.rowCount>LIMITS.rows+100||ws.columnCount>LIMITS.columns)throw Error('页签超过20000行或200列限制');
 const matrix:Cell[][]=[];
 for(let n=1;n<=ws.rowCount;n++){
 const line:Cell[]=[];
 for(let k=1;k<=ws.columnCount;k++){
 const c=ws.getRow(n).getCell(k);const v=c.value;let value:Cell=null;
 if(v instanceof Date)value=v.toISOString().slice(0,10);
 else if(v && typeof v==='object'){
 if('formula' in v || 'sharedFormula' in v)value={formula:c.formula||'共享公式',cached:c.result??null};
 else if('richText' in v)value=v.richText.map(x=>x.text).join('');
 else if('text' in v)value=v.text;
 else if('error' in v)value={formula:'Excel错误 '+v.error,cached:null};
 }else if(typeof v==='number')value=/^0+$/.test(c.numFmt)&&Number.isInteger(v)?String(v).padStart(c.numFmt.length,'0'):v;
 else if(typeof v==='string')value=v;
 else if(typeof v==='boolean')value=String(v);
 line.push(value);
 }matrix.push(line);
 }guardMatrix(matrix);return {name:ws.name,matrix};
 });
 if(!sheets.length)throw Error('没有可读取的页签');return {file,sheets};
}
export function asTable(loaded:LoadedFile,sheet:string,headerRow=1):Table{
 const matrix=loaded.sheets.find(s=>s.name===sheet)?.matrix;
 if(!matrix || !Number.isInteger(headerRow)||headerRow<1||headerRow>matrix.length)throw Error('表头行无效或空页签');
 const header=matrix[headerRow-1];let last=header.length;while(last&&header[last-1]===null)last--;
 const headers=header.slice(0,last).map(x=>typeof x==='string'||typeof x==='number'?String(x).trim():'');
 if(!headers.length||headers.some(x=>!x))throw Error('表头存在空列/公式，请选择完整表头');
 if(new Set(headers).size!==headers.length)throw Error('表头存在重复列名');
 const rows:SourceRow[]=[];
 for(let i=headerRow;i<matrix.length;i++){
 const cells=matrix[i];if(cells.every(c=>c===null))continue;
 if(cells.slice(last).some(c=>c!==null))throw Error('第'+(i+1)+'行有无表头数据列');
 rows.push({file:loaded.file,sheet,row:i+1,cells:Object.fromEntries(headers.map((h,k)=>[h,cells[k]??null]))});
 }if(rows.length>LIMITS.rows)throw Error('数据超过20000行');if(!rows.length)throw Error('页签没有数据行');
 return {file:loaded.file,sheet,headers,rows};
}
export function save(name:string,data:BlobPart,type='application/json'){
 const a=document.createElement('a'),url=URL.createObjectURL(new Blob([data],{type}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
export async function workbookBytes(sheets:{name:string;headers:string[];rows:unknown[][]}[]):Promise<Uint8Array>{
 const wb=new ExcelJS.Workbook();for(const spec of sheets){const ws=wb.addWorksheet(spec.name.slice(0,31));ws.addRow(spec.headers);
 for(const r of spec.rows)ws.addRow(r.map(v=>v===null||v===undefined?'':typeof v==='object'?JSON.stringify(v):String(v)));
 ws.getRow(1).font={bold:true};ws.views=[{state:'frozen',ySplit:1}];ws.columns.forEach(c=>{c.width=24});}
 return new Uint8Array(await wb.xlsx.writeBuffer());
}
