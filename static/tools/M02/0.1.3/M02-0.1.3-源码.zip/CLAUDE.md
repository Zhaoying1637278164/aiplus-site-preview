# Claude 工作入口

请先阅读并遵守 [AGENTS.md](AGENTS.md)，这是所有助手唯一共同规范。再读 [README.md](README.md)、[工具总览.md](工具总览.md)、[progress/STATUS.md](progress/STATUS.md)，进入目标工具目录检查参考来源、财务规则和测试证据。不要在此重复维护另一套规则。
