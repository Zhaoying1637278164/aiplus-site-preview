// Original AP and funds catalogue/detail preservation on the actual staged website.
import {chromium} from 'playwright';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const registry=JSON.parse(await readFile('integration/native-site/site/registry.json','utf8'));
const ids=registry.map((x:any)=>x.id),out='progress/evidence/site-integration/'+ids.join('-');
await mkdir(out,{recursive:true});
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex'),site=await readFile('integration/native-site/site/index.html');
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),programs:string[]=[],errors:string[]=[],checks:string[]=[];
page.on('request',r=>{if(r.url().endsWith('runtime.json'))programs.push(r.url())});page.on('pageerror',e=>errors.push(e.message));
const defs=[{module:'ap',total:9,original:[['tool-ap-01','应付管理台'],['tool-ap-02','应付分析看板'],['tool-ap-03','采购合同台账'],['tool-ap-04','应付账龄表'],['tool-ap-07','合同到期提醒']],tools:['P01','P02','P03','P04']},{module:'fund',total:7,original:[['tool-fund-01','资金管理平台'],['tool-fund-02','资金分析看板'],['tool-fund-03','银行流水导入归集'],['tool-fund-05','现金流预测表'],['tool-fund-06','现金流量表编制']],tools:['T01','T02']}];
if(ids.includes('T03')){defs[1].original=defs[1].original.filter(([route])=>route!=='tool-fund-05');defs[1].tools.push('T03')}
if(ids.includes('T05')){defs[1].total=8;defs[1].tools.push('T05')}
if(ids.includes('K01'))defs.push({module:'cost',total:6,original:[['tool-cost-01','成本核算台'],['tool-cost-02','成本分析看板'],['tool-cost-04','产品损益测算表'],['tool-cost-05','存货台账周转表'],['tool-cost-06','定价测算表']],tools:['K01']});
const total=ids.includes('T05')?84:83;
try{
 await page.goto('http://127.0.0.1:8515/');const frame=page.frameLocator('iframe').first();await frame.locator('.bignum').waitFor();assert.equal(await frame.locator('.bignum').innerText(),String(total));
 for(const d of defs){
  const catalogue=async()=>{await frame.locator('.nav a[href="#tools"]').click();await frame.locator('[data-f="mod"][data-v="'+d.module+'"]').click();assert.equal(await frame.locator('[data-total]').innerText(),String(d.total));assert.equal(await frame.locator('[data-tool]:visible').count(),d.total)};
  await catalogue();await page.screenshot({path:out+'/original-'+d.module+'-module.png',fullPage:true});
  for(const [route,name] of d.original){
   const row=frame.locator('[data-tool]:visible').filter({has:frame.getByRole('link',{name,exact:true})});assert.equal(await row.count(),1);await row.getByRole('link',{name:'详情',exact:true}).click();await frame.getByRole('heading',{name,exact:true,level:1}).waitFor();
   assert.equal(await frame.locator('template#r-'+route).count(),1);assert.equal(await frame.getByText('工具信息',{exact:true}).count(),1);assert.ok(await frame.getByText('工具包即将上线',{exact:true}).count()>=1);assert.equal(await frame.locator('[data-program-download]').count(),0);assert.equal(await frame.locator('[data-program-start]').count(),0);assert.deepEqual(programs,[]);
   await page.screenshot({path:out+'/'+route+'-detail.png',fullPage:true});checks.push(route+' original name/detail/style preserved and unimplemented');await catalogue();
  }
  for(const id of d.tools){const entry=registry.find((x:any)=>x.id===id);assert(entry);const row=frame.locator('[data-tool]:visible').filter({has:frame.getByRole('link',{name:entry.name,exact:true})});assert.equal(await row.count(),1);await row.getByRole('link',{name:'详情',exact:true}).click();await frame.getByRole('heading',{name:entry.name,exact:true,level:1}).waitFor();assert.equal(await frame.locator('template#r-'+entry.detailRoute).count(),1);assert.ok(await frame.locator('[data-program-download]').count()>0);assert.deepEqual(programs,[]);checks.push(id+' financial module same-site detail without program load');await catalogue()}
 }
 assert.deepEqual(errors,[]);assert.deepEqual(programs,[]);
 await writeFile(out+'/original-financial-modules.json',JSON.stringify({site_sha256:sha(site),test_sha256:sha(await readFile('tests/original-financial-modules.ts')),passed:true,total,ap_total:9,fund_total:defs[1].total,cost_total:defs[2]?.total,cost_original_unimplemented:defs[2]?.original.length,ap_original_unimplemented:5,fund_original_unimplemented:defs[1].original.length,programs,errors,checks,scope:'Actual original staged Streamlit catalogue and detail; all original remaining AP/fund tools preserved; no executable on detail'},null,2)+'\n');console.log('Original AP9/funds7,',defs.reduce((n,d)=>n+d.original.length,0),'preserved details,',defs.reduce((n,d)=>n+d.tools.length,0),'delivered details passed');
}catch(e){await page.screenshot({path:out+'/original-financial-modules-failure.png',fullPage:true});await writeFile(out+'/original-financial-modules-failure.json',JSON.stringify({site_sha256:sha(site),error:String(e),programs,errors,checks},null,2));throw e}finally{await browser.close()}
