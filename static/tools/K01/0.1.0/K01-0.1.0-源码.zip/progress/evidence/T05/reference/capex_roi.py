#!/usr/bin/env python3
"""
Capex ROI evaluator: NPV, IRR, payback, and ROIC vs. WACC hurdle check for
a capital project. Distinct from a general business case: purpose-built for
a capital expenditure decision with a hurdle rate comparison.

Usage:
    python3 capex_roi.py --config capex.json

capex.json shape:
{
  "wacc_pct": 9,
  "hurdle_rate_pct": 12,
  "initial_capex": 1500000,
  "useful_life_years": 5,
  "annual_cash_flows": [350000, 420000, 480000, 480000, 480000]
}
"""
import argparse
import json


def npv(flows, rate_pct):
    r = rate_pct / 100
    return sum(cf / ((1 + r) ** t) for t, cf in enumerate(flows))


def irr(flows, lo=-0.99, hi=5.0, tol=1e-6, max_iter=200):
    def f(rate):
        return sum(cf / ((1 + rate) ** t) for t, cf in enumerate(flows))
    f_lo, f_hi = f(lo), f(hi)
    if f_lo * f_hi > 0:
        return None
    for _ in range(max_iter):
        mid = (lo + hi) / 2
        f_mid = f(mid)
        if abs(f_mid) < tol:
            return mid * 100
        if f_lo * f_mid < 0:
            hi = mid
        else:
            lo, f_lo = mid, f_mid
    return mid * 100


def payback_period(flows):
    cumulative = 0
    for t, cf in enumerate(flows):
        cumulative += cf
        if cumulative >= 0:
            if t == 0:
                return 0
            prior = cumulative - cf
            fraction = -prior / cf if cf != 0 else 0
            return (t - 1) + fraction
    return None


def money(x):
    return f"${x:,.0f}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = json.load(f)

    flows = [-cfg["initial_capex"]] + cfg["annual_cash_flows"]
    wacc = cfg["wacc_pct"]
    hurdle = cfg["hurdle_rate_pct"]

    project_npv_wacc = npv(flows, wacc)
    project_npv_hurdle = npv(flows, hurdle)
    project_irr = irr(flows)
    pb = payback_period(flows)

    total_cash_flow = sum(cfg["annual_cash_flows"])
    avg_annual_return = total_cash_flow / cfg["useful_life_years"]
    roic = avg_annual_return / cfg["initial_capex"] * 100

    print("=== Capex ROI Evaluation ===\n")
    print(f"Initial capex: {money(cfg['initial_capex'])}")
    print(f"Useful life: {cfg['useful_life_years']} years")
    print(f"Annual cash flows: {[money(c) for c in cfg['annual_cash_flows']]}\n")

    print(f"NPV at WACC ({wacc}%): {money(project_npv_wacc)}")
    print(f"NPV at hurdle rate ({hurdle}%): {money(project_npv_hurdle)}")
    print(f"IRR: {project_irr:.1f}%" if project_irr else "IRR: not found in range")
    print(f"Payback period: {pb:.1f} years" if pb is not None else "Payback: does not pay back")
    print(f"Simple average ROIC: {roic:.1f}%")

    print("\n=== Hurdle Rate Check ===")
    if project_irr is not None:
        if project_irr >= hurdle:
            print(f"IRR ({project_irr:.1f}%) clears the hurdle rate ({hurdle}%). Project passes.")
        else:
            print(f">>> IRR ({project_irr:.1f}%) is BELOW the hurdle rate ({hurdle}%).")
            print("    This project destroys value relative to the required return, even")
            print("    though NPV at WACC may still look positive. Do not approve on NPV alone")
            print("    without checking IRR against the hurdle explicitly.")

    if project_npv_hurdle < 0 < project_npv_wacc:
        print("\n>>> FLAG: NPV is positive at WACC but negative at the hurdle rate.")
        print("    WACC and hurdle rate are different numbers for a reason, the hurdle")
        print("    usually includes a risk premium above WACC. Using WACC alone would")
        print("    have approved a project that doesn't clear the actual bar this company sets.")


if __name__ == "__main__":
    main()
