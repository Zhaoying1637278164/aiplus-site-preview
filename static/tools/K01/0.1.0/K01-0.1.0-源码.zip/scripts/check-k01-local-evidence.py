"""K01 exact formal/local delivery gate. Public acceptance remains separate."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();ev=root/'progress/evidence/K01/0.1.0';release=root/'release/K01/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
for folder,script,groups,downloads,geometries in [('formal-browser','k01-formal-browser.ts',19,21,48),('site-local','k01-native-site.ts',22,31,24)]:
 d=read(ev/folder/'result.json');c=read(ev/folder/'root-command.json')
 assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(root/'tests'/script)
 assert d['passed'] and d['candidate_only'] is False and d['official_website'] is False
 assert d['html_sha256']==html and d['runtime_sha256']==runtime and d['version']=='0.1.0'
 assert d['errors']==[] and d['requests']==[]
 assert len(d['checks'])==groups and len(d['downloads'])==downloads and len(d['geometry'])==geometries and d['cells']==436
 assert {g['width'] for g in d['geometry']}=={1440,390,320}
 assert '16张完整底稿独立逐格手算及原始来源/参数回读' in d['checks']
 if folder=='site-local':
  assert c['site_sha256']==d['site_sha256']==site
  assert d['programs'] and all('/K01/0.1.0/runtime.json' in x for x in d['programs'])
  assert '原官网桌面及两手机菜单离页取消保留/确认dispose清空' in d['checks']
 for item in d['downloads']:
  p=ev/folder/item['file'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
directory=ev/'K01/downloads';d=read(directory/'result.json');c=read(directory/'root-command.json')
assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(root/'tests/k01-native-downloads.ts')
assert d['passed'] and d['errors']==[] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==18 and set(d['downloads'])==expected and d['clicks']==20
for name,h in d['downloads'].items():assert sha(directory/'site-local-downloads'/name)==h==sha(release/name)
with zipfile.ZipFile(release/'K01-0.1.0-离线包.zip') as z:
 names={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
 assert set(z.namelist())=={'K01/'+n for n in names}
 for n in names:assert z.read('K01/'+n)==(release/n).read_bytes()
source=release/'K01-0.1.0-源码.zip';assert source.stat().st_size<=24*1024*1024
r=read(ev/'source-rebuild.json');assert r['source_zip_sha256']==sha(source) and r['actual_root_exit_code']==0
assert len(r['commands'])==4 and all(c['exit_code']==0 for c in r['commands'])
for name in ['index.html','runtime.json']:assert r['files'][name]['identical'] and r['files'][name]['release_sha256']==sha(release/name)
assets=read(ev/'source-rebuild-assets.json');assert assets['source_zip_sha256']==sha(source)
assert set(assets['files'])=={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
for name,row in assets['files'].items():assert row['release_sha256']==sha(release/name) and (row['bytes_identical'] or row.get('content_identical_except_created_modified'))
independent=read(root/'progress/evidence/K01/root-independent-review.json')
assert independent['passed'] and independent['groups']==10 and independent['engine_sha256']==sha(root/'tools/K01-成本分摊表/src/engine.ts') and independent['test_sha256']==sha(root/'tests/k01-independent-review.ts')
visual=read(ev/'root-visual-review.json');assert visual['actual_review'] and visual['site_sha256']==site
for name,h in visual['files'].items():assert sha(ev/'site-local'/name)==h
for p in release.iterdir():
 if p.is_file():assert sha(root/'integration/native-site/static/tools/K01/0.1.0'/p.name)==sha(p)
result={'tool':'K01','version':'0.1.0','local_exact_gates_passed':True,'html_sha256':html,'runtime_sha256':runtime,'site_sha256':site,'source_zip_sha256':sha(source),'accepted':False,'windows_verified':False}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
