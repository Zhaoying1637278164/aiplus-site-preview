"""Explicit count-only adaptation for frozen validators on reviewed 16-tool stage.
Original validator source stays immutable; executed bytes are separately recorded.
"""
import pathlib,hashlib,json,tempfile,subprocess,os
root=pathlib.Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def adapted_download(script,args,log):
 source=root/'tests'/script;text=source.read_text();needle="id==='P04'?'9':'7'";assert text.count(needle)==1
 original=text;text=text.replace(needle,"id==='P04'?'9':'8'")
 text=text.replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
 archive=root/'progress/evidence/shared/current-stage-adapters';archive.mkdir(parents=True,exist_ok=True)
 executed=archive/(script.removesuffix('.ts')+'-fund8.mts');executed.write_text(text)
 with log.open('w') as handle:r=subprocess.run(['node','--import',str(root/'node_modules/tsx/dist/loader.mjs'),str(executed),*args],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
 return {'script':script,'exit_code':r.returncode,'test_sha256':sha(source),'executed_test_sha256':sha(executed),'executed_test':str(executed.relative_to(root)),'adaptation':'fund catalogue count 7 -> 8; absolute Playwright import only; all financial assertions retained'}
def verify_adapter_row(row):
 source=root/'tests'/row['script'];needle="id==='P04'?'9':'7'";text=source.read_text();assert text.count(needle)==1
 expected=text.replace(needle,"id==='P04'?'9':'8'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
 executed=root/row['executed_test'];assert executed.read_text()==expected
 assert row['exit_code']==0 and row['test_sha256']==sha(source) and row['executed_test_sha256']==sha(executed)
