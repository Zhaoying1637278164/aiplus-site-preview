import {chromium} from 'playwright';
import {createServer} from 'node:http';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve('integration/native-fixture');
const requests:string[]=[];
const server=createServer(async(req,res)=>{
 const requested=decodeURIComponent((req.url||'/').split('?')[0]);requests.push(requested);
 const file=path.resolve(root,'.'+(requested==='/'?'/index.html':requested));
 if(!file.startsWith(root+path.sep)){res.statusCode=404;res.end();return}
 try{const bytes=await readFile(file);res.setHeader('Content-Type',file.endsWith('.html')?'text/html; charset=utf-8':'application/json');res.end(bytes)}catch{res.statusCode=404;res.end()}
});
await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
const port=(server.address() as {port:number}).port;
const browser=await chromium.launch({executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}});
 await page.route('**/*',route=>new URL(route.request().url()).hostname==='127.0.0.1'?route.continue():route.abort());
 await page.goto(`http://127.0.0.1:${port}`);
 await page.locator('a[href="#tools"]').first().click();assert.equal(await page.locator('[data-total]').innerText(),'77');
 assert.equal(await page.locator('[data-tool]').count(),77);
 await page.locator('[data-f="mod"][data-v="close"]').click();assert.equal(await page.locator('[data-total]').innerText(),'13');
 const row=page.locator('[data-tool]').filter({has:page.getByRole('link',{name:'账表对账',exact:true})});
 assert.equal(await row.getByText('结账',{exact:true}).count(),1);
 await row.getByRole('link',{name:'详情',exact:true}).click();
 await page.getByRole('heading',{name:'账表对账',exact:true}).waitFor();
 assert.equal(await page.getByRole('heading',{name:'它能做什么',exact:true}).count(),1);
 assert.equal(await page.getByText('工具信息',{exact:true}).count(),1);
 assert.equal(await page.getByText('下载与说明',{exact:true}).count(),1);
 assert.equal(requests.filter(r=>r.endsWith('runtime.json')).length,0);
 const evidence='progress/evidence/product-reset';await mkdir(evidence,{recursive:true});
 await page.screenshot({path:evidence+'/native-detail-fixture.png',fullPage:true});
 await page.getByRole('link',{name:'开始账表对账',exact:true}).click();
 await page.getByRole('heading',{name:'原生整合测试（非财务成品）'}).waitFor();
 assert.equal(await page.locator('iframe').count(),0);assert.equal(page.context().pages().length,1);
 assert.equal(requests.filter(r=>r.endsWith('runtime.json')).length,1);
 await page.getByLabel('完全虚构的测试事项').fill('完全虚构');
 page.once('dialog',dialog=>void dialog.dismiss());await page.locator('.nav a[href="#tools"]').click();
 assert.equal(await page.getByLabel('完全虚构的测试事项').inputValue(),'完全虚构');
 page.once('dialog',dialog=>void dialog.accept());await page.getByRole('button',{name:'返回账表对账详情',exact:true}).click();
 await page.getByRole('heading',{name:'账表对账',exact:true}).waitFor();assert.equal(await page.getByLabel('完全虚构的测试事项').count(),0);
 await page.getByRole('link',{name:'开始账表对账',exact:true}).click();await page.getByLabel('完全虚构的测试事项').waitFor();
 assert.equal(await page.getByLabel('完全虚构的测试事项').inputValue(),'');
 await page.getByRole('button',{name:'返回账表对账详情',exact:true}).click();
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:evidence+'/native-detail-mobile-fixture.png',fullPage:true});
 const width=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,view:innerWidth}));assert.ok(width.scroll<=width.view+1);
 await writeFile(evidence+'/native-navigation.json',JSON.stringify({date:'2026-10-03',scope:'Native website navigation fixture only; no finance/UI product acceptance',browser:await browser.version(),catalog_count:77,closing_count:13,checks:['existing_module_row_style','original_detail_structure','no_program_load_in_catalog_or_detail','one_program_on_workspace_entry','no_tool_iframe_or_new_tab','site_go_render_navigation','cancel_exit_preserves','confirmed_exit_clears','reentry_empty','mobile_detail_no_overflow']},null,2));
 console.log('官网原导航/模块/详情/原生工作区边界验证通过（仅测试样例）');
}finally{await browser.close();await new Promise<void>(resolve=>server.close(()=>resolve()))}
