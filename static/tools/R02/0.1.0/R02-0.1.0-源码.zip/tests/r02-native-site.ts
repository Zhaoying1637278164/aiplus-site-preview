import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import ExcelJS from 'exceljs';
const out=path.resolve(process.env.AIPLUS_EVIDENCE_DIR||'progress/evidence/R02/0.1.0/site-local');
const release=path.resolve('release/R02/0.1.0'),offline=path.resolve('progress/evidence/R02/0.1.0/formal-browser');
await mkdir(out,{recursive:true});
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const checks:string[]=[],geometry:unknown[]=[],errors:string[]=[],requests:string[]=[];let processingRequests:string[]|null=null;
const browser=await chromium.launch({headless:true,executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
try{
 const ctx=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}}),shell=await ctx.newPage();
 shell.on('pageerror',e=>errors.push(e.message));
 await shell.goto((process.env.AIPLUS_NATIVE_SITE_URL||'http://127.0.0.1:8514')+'/?tool=R02');
 const handle=await shell.locator('iframe').first().elementHandle();assert.ok(handle);
 const loaded=await handle.contentFrame();assert.ok(loaded);const page=loaded!;shell.setDefaultTimeout(15000);
 await page.getByRole('heading',{name:'收入确认排程表',exact:true}).waitFor();
 assert.equal(await page.locator('iframe').count(),0);
 const navigation=page.getByRole('navigation',{name:'收入工作导航',exact:true});assert.equal(await navigation.getByRole('button').count(),8);
 const storage=()=>page.evaluate(()=>JSON.stringify({local:Object.fromEntries(Object.keys(localStorage).map(k=>[k,localStorage.getItem(k)])),session:Object.fromEntries(Object.keys(sessionStorage).map(k=>[k,sessionStorage.getItem(k)]))}));
 const before=await storage();shell.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});
 const nav=async(name:string)=>{console.log('navigate',name);await navigation.getByRole('button',{name,exact:true}).click();await page.getByRole('heading',{name,exact:true}).waitFor()};
 const dl=async(button:string,name:string)=>{const event=shell.waitForEvent('download');await page.getByRole('button',{name:button,exact:true}).click();const d=await event;assert.equal(await d.failure(),null);const file=path.join(out,name);await d.saveAs(file);return file};
 const restore=async(file:string,accept=true)=>{await nav('工作总览');shell.once('dialog',d=>accept?d.accept():d.dismiss());await page.getByLabel('恢复工作或方案',{exact:true}).setInputFiles(file)};
 checks.push('real_registered_Streamlit_same_document_eight_pages_no_inner_iframe');
 await page.getByRole('button',{name:'体验虚构合同',exact:true}).click();await nav('工作总览');await page.getByRole('button',{name:'生成收入排程',exact:true}).click();
 await nav('工作总览');const text=await page.locator('.r02 main').innerText();for(const amount of ['25000.00','15000.00','6000.00','19000.00'])assert.ok(text.includes(amount),amount);
 checks.push('manual_25000_allocation_15000_due_6000_actual_19000_remaining');
 await restore(offline+'/work.json');await page.getByText('含数据工作已恢复并重算，待处理异常仍保留。',{exact:true}).waitFor();
 await nav('异常与底稿');const work=await dl('保存含数据完整工作','native-work.json');
 assert.deepEqual(JSON.parse(await readFile(work,'utf8')),JSON.parse(await readFile(offline+'/work.json','utf8')));
 const file=await dl('下载完整收入底稿','native-work.xlsx');
 const actual=new ExcelJS.Workbook(),expected=new ExcelJS.Workbook();await actual.xlsx.load(await readFile(file) as any);await expected.xlsx.load(await readFile(offline+'/work.xlsx') as any);
 assert.deepEqual(actual.worksheets.map(s=>s.name),expected.worksheets.map(s=>s.name));
 for(const sheet of expected.worksheets){const found=actual.getWorksheet(sheet.name)!;assert.equal(found.rowCount,sheet.rowCount);for(let row=1;row<=sheet.rowCount;row++)assert.deepEqual(found.getRow(row).values,sheet.getRow(row).values,sheet.name+'/'+row)}
 checks.push('actual_offline_whole_work_and_every_XLSX_cell_equal');
 const scheme=await dl('保存不含数据方案','native-scheme.json');assert.deepEqual(JSON.parse(await readFile(scheme,'utf8')),JSON.parse(await readFile(offline+'/scheme.json','utf8')));
 await restore(scheme,false);await nav('合同与履约事项');assert.ok((await page.locator('.r02 main').innerText()).includes('HT-001'));
 await restore(scheme);await page.getByText('无数据方案已恢复，原资料清空；请重新导入。',{exact:true}).waitFor();await nav('合同与履约事项');assert.ok(!(await page.locator('.r02 main').innerText()).includes('HT-001'));
 checks.push('cancel_restore_preserves_and_nodata_restore_clears');
 for(const [title,label,sheet] of [['合同与履约事项','合同','合同'],['合同与履约事项','履约事项','履约事项'],['里程碑','里程碑','里程碑'],['已确认收入','已确认收入','已确认收入'],['变更与调整','变更与调整','变更与调整']]){
  await nav(title);await page.getByLabel('导入'+label+' CSV/XLSX',{exact:true}).setInputFiles(release+'/虚构样例.xlsx');const modal=page.getByRole('dialog',{name:'选择导入资料'});await modal.getByRole('combobox',{name:'导入页签',exact:true}).selectOption(sheet);await modal.getByRole('button',{name:'确认导入',exact:true}).click();await modal.waitFor({state:'hidden'});
 }
 await nav('工作总览');await page.getByRole('button',{name:'生成收入排程',exact:true}).click();assert.ok((await page.locator('.r02 main').innerText()).includes('11000.00'));checks.push('five_actual_XLSX_imports_manual_due_11000');
 const titles=['工作总览','合同与履约事项','排程口径','里程碑','已确认收入','月度排程','变更与调整','异常与底稿'];
 async function inspect(title:string,width:number,stage:string){
  await page.waitForTimeout(120);const box=await page.getByRole('heading',{name:title,exact:true}).boundingBox(),n=await navigation.boundingBox(),active=await navigation.getByRole('button',{name:title,exact:true}).boundingBox(),header=await page.locator('header').first().boundingBox();assert.ok(box&&n&&active&&header);
  assert.ok(n.y>=header.y+header.height+4,'navigation below original header');assert.ok(box.y>=n.y+n.height-1&&box.y+box.height<(width===1440?1000:844),'heading visible below navigation');assert.ok(active.x>=n.x-1&&active.x+active.width<=n.x+n.width+1,'full current tab visible');assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  geometry.push({width,title,stage,heading:box,navigation:n,active,header});
 }
 for(const width of [1440,320,390]){
  await shell.setViewportSize({width,height:width===1440?1000:844});
  for(const title of titles){await page.evaluate(()=>window.scrollTo(0,document.body.scrollHeight));await nav(title);await inspect(title,width,'long_page_ordinary_click');await shell.screenshot({path:path.join(out,width+'-'+title+'.png'),fullPage:false})}
  await restore(offline+'/work.json');await page.getByText('含数据工作已恢复并重算，待处理异常仍保留。',{exact:true}).waitFor();await inspect('工作总览',width,'same_page_restore');await page.evaluate(()=>window.scrollTo(0,document.body.scrollHeight));await nav('异常与底稿');await inspect('异常与底稿',width,'after_restore_ordinary_click');
 }
 checks.push('30_real_original_header_long_page_navigation_restore_geometry_no_forced_click');
 await shell.setViewportSize({width:1440,height:1000});await nav('已确认收入');await page.getByLabel('导入已确认收入 CSV/XLSX',{exact:true}).setInputFiles(path.resolve('progress/evidence/R02/fixtures/31笔虚构收入.csv'));const picker=page.getByRole('dialog',{name:'选择导入资料'});shell.once('dialog',d=>d.accept());await picker.getByRole('button',{name:'确认导入',exact:true}).click();await page.getByText('共 31 行 · 每页15行 · 第 1/3 页',{exact:true}).waitFor();await page.getByRole('button',{name:'下一页',exact:true}).click();await page.getByRole('button',{name:'查看原行 17',exact:true}).click();assert.ok((await page.getByRole('dialog',{name:'完整原行来源'}).innerText()).includes('LONG-016'));await page.getByRole('button',{name:'关闭来源',exact:true}).click();await nav('月度排程');await page.getByRole('button',{name:'重新生成排程',exact:true}).click();for(const amount of ['310.00','10690.00'])assert.ok((await page.locator('.r02 main').innerText()).includes(amount));checks.push('actual_31_CSV_rows_pagination_source17_manual_310_10690');
 processingRequests=[...requests];assert.deepEqual(processingRequests,[]);assert.deepEqual(errors,[]);assert.equal(await storage(),before);checks.push('no_processing_HTTP_storage_writes_or_page_errors');
 shell.once('dialog',d=>d.dismiss());await page.getByRole('button',{name:'返回工具详情',exact:true}).click();await nav('已确认收入');assert.ok((await page.locator('.r02 main').innerText()).includes('LONG-'));checks.push('cancel_exit_preserves_imported_work');shell.once('dialog',d=>d.accept());await page.getByRole('button',{name:'返回工具详情',exact:true}).click();await page.getByRole('link',{name:'开始收入排程',exact:true}).waitFor();await page.getByRole('link',{name:'开始收入排程',exact:true}).click();await page.getByRole('heading',{name:'收入确认排程表',exact:true}).waitFor();await page.getByRole('button',{name:'合同与履约事项',exact:true}).click();assert.ok(!(await page.locator('.r02 main').innerText()).includes('HT-001'));checks.push('exit_to_original_detail_and_reenter_empty');
 await ctx.close();
}catch(e){await writeFile(out+'/failure.txt',String((e as Error).stack));throw e}
finally{await browser.close();await writeFile(out+'/result.json',JSON.stringify({tool:'R02',version:'0.1.0',html_sha256:sha(await readFile(release+'/index.html')),runtime_sha256:sha(await readFile(release+'/runtime.json')),site_sha256:sha(await readFile('integration/native-site/site/index.html')),checks,geometry,errors,processing_requests:processingRequests,all_requests_including_reentry:requests,forced_clicks:0,public_site_verified:false},null,2))}
