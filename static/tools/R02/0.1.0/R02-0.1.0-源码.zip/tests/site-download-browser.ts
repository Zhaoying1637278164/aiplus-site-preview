import {chromium} from 'playwright';
import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const file='integration/native-site/static/tools/D02/0.2.0/download-6.json';
const original=await readFile(file,'utf8');
const browser=await chromium.launch({executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:8514/?tool=D02');const frame=page.frameLocator('iframe').first();
 await frame.getByRole('button',{name:'返回工具详情',exact:true}).click();let downloads=0;page.on('download',()=>downloads++);
 const payload=JSON.parse(original);payload.base64=(payload.base64[0]==='A'?'B':'A')+payload.base64.slice(1);await writeFile(file,JSON.stringify(payload));
 await frame.getByRole('link',{name:'第三方声明',exact:true}).click();await frame.getByRole('alert').filter({hasText:'下载校验失败'}).waitFor();assert.equal(downloads,0);
 await frame.locator('a[data-program-download][aria-busy="true"]') .waitFor({state:'detached'});
 await writeFile(file,original);const pending=page.waitForEvent('download');await frame.getByRole('link',{name:'第三方声明',exact:true}).click();await pending;assert.equal(downloads,1);
 await writeFile('progress/evidence/D02/0.2.0/download-transport.json',JSON.stringify({transport:'first-party ASCII JSON to verified local Blob',checks:['tampered_bytes_rejected_without_download','original_bytes_download_after_restore'],platform:'Mac Chromium',windows:'not verified'},null,2));
 console.log('Download transport rejects tampered bytes and recovers after original restored');
}finally{await writeFile(file,original);await browser.close()}
