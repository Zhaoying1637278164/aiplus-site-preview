import {build} from 'esbuild';
import {chromium} from 'playwright';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {mkdir,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';

// Isolated host contract fixture: never a finance tool or a published version.
const host=await build({entryPoints:['apps/site-host/main.ts'],bundle:true,write:false,format:'iife',platform:'browser'});
const program=`window.__aiPlusLoadedProgram={id:'D02',version:'9.9.9',name:'测试挂载',mount(context){
 let changed=false;
 const input=document.createElement('input');input.setAttribute('aria-label','虚构测试事项');input.addEventListener('input',()=>{changed=true});
 const back=document.createElement('button');back.textContent='返回详情';back.onclick=context.onExit;
 context.container.append(input,back);
 return {requestExit(){return !changed||confirm('本次虚构测试事项未保存，确认离开？')},dispose(){context.container.replaceChildren();window.fixtureDisposals=(window.fixtureDisposals||0)+1}};
}};`;
const runtime=Buffer.from(JSON.stringify({schema_version:1,id:'D02',version:'9.9.9',name:'测试挂载',js:program,css:'button{color:rgb(255, 0, 0)}'}));
const hash=createHash('sha256').update(runtime).digest('hex');
const entries=[{id:'D02',version:'9.9.9',name:'测试挂载',detailRoute:'tool-test',workspaceRoute:'work-test',runtime:'app/static/tools/D02/9.9.9/runtime.json',sha256:hash,bytes:runtime.length},
 {id:'D03',version:'9.9.9',name:'拒绝篡改',detailRoute:'tool-tamper',workspaceRoute:'work-tamper',runtime:'app/static/tools/D03/9.9.9/runtime.json',sha256:'0'.repeat(64),bytes:runtime.length}];
let requests:string[]=[],oversizeNext=false,delayNext=false;
const html=`<!doctype html><meta charset="utf-8"><style>button{color:rgb(0,0,255)}</style><button id="outside">官网按钮</button><div id="workspace"></div><script>window.__AIPlusRegistry=${JSON.stringify(entries)}</script><script>${host.outputFiles[0].text}</script><script>window.fixtureExit=()=>{if(window.__AIPlusHost.requestExit())window.__AIPlusHost.dispose()}</script>`;
const server=createServer((req,res)=>{
 requests.push(req.url||'');
 if(req.url==='/'||req.url==='/?tool=D02'){res.setHeader('Content-Type','text/html');res.end(html)}
 else if(req.url?.endsWith('runtime.json')){
  res.setHeader('Content-Type','application/json');
  const bytes=oversizeNext?Buffer.concat([runtime,Buffer.from('extra')]):runtime;oversizeNext=false;
  if(delayNext){delayNext=false;setTimeout(()=>res.end(bytes),150)}else res.end(bytes);
 }
 else {res.statusCode=404;res.end()}
});
await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));
const port=(server.address() as {port:number}).port;
const browser=await chromium.launch({executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
try{
 const page=await browser.newPage();await page.goto(`http://127.0.0.1:${port}/?tool=D02`);
 const open=()=>page.evaluate(()=>{const w=window as any;return w.__AIPlusHost.open('work-test',document.getElementById('workspace'),w.fixtureExit)});
 await open();assert.equal(await page.locator('iframe').count(),0);
 assert.equal(await page.locator('#outside').evaluate(e=>getComputedStyle(e).color),'rgb(0, 0, 255)');
 assert.equal(await page.getByRole('button',{name:'返回详情'}).evaluate(e=>getComputedStyle(e).color),'rgb(255, 0, 0)');
 await page.getByLabel('虚构测试事项').fill('完全虚构的未保存记录');
 page.once('dialog',d=>void d.dismiss());await page.getByRole('button',{name:'返回详情'}).click();
 assert.equal(await page.getByLabel('虚构测试事项').inputValue(),'完全虚构的未保存记录');
 page.once('dialog',d=>void d.accept());await page.getByRole('button',{name:'返回详情'}).click();assert.equal(await page.getByLabel('虚构测试事项').count(),0);
 assert.equal(await page.evaluate(()=>(window as any).fixtureDisposals),1);
 await open();assert.equal(await page.getByLabel('虚构测试事项').inputValue(),'');
 const before=requests.filter(p=>p.endsWith('runtime.json')).length;
 const unknown=await page.evaluate(async()=>{try{await (window as any).__AIPlusHost.open('work-UNKNOWN',document.getElementById('workspace'),()=>{});return false}catch{return true}});
 assert.equal(unknown,true);assert.equal(requests.filter(p=>p.endsWith('runtime.json')).length,before);
 await page.evaluate(()=>(window as any).__AIPlusHost.open('work-tamper',document.getElementById('workspace'),()=>{}));
 assert.equal(await page.getByRole('alert').innerText(),'工具程序版本校验失败');assert.equal(await page.getByLabel('虚构测试事项').count(),0);
 assert.equal(await page.evaluate(()=>'__aiPlusLoadedProgram' in window),false);
 await open();await page.evaluate(()=>(window as any).__AIPlusHost.dispose());assert.equal(await page.locator('#workspace').innerText(),'');
 oversizeNext=true;await open();assert.equal(await page.getByRole('alert').innerText(),'工具程序体积超过登记上限');
 delayNext=true;const request=page.waitForRequest('**/runtime.json');const pending=open();await request;
 await page.evaluate(()=>(window as any).__AIPlusHost.dispose());await pending;
 assert.equal(await page.locator('#workspace').innerText(),'');
 assert.equal(await page.evaluate(()=>localStorage.length),0);
 const evidence='progress/evidence/product-reset';await mkdir(evidence,{recursive:true});
 await writeFile(evidence+'/native-host.json',JSON.stringify({date:'2026-10-03',browser:await browser.version(),platform:'Mac Chromium',scope:'Native host boundary fixture; no D02 financial/UI acceptance claim',checks:['same_document_no_tool_iframe','scoped_CSS','cancel_exit_preserves_work','confirm_exit_disposes','reentry_empty','unknown_route_no_fetch','tamper_hash_rejected_before_execution','runtime_global_released','bounded_program_body','cancel_pending_load_no_late_mount','no_persistence'],program_requests:requests.filter(p=>p.endsWith('runtime.json'))},null,2));
 console.log('原生挂载边界浏览器验证通过；不代表财务工具验收');
}finally{await browser.close();await new Promise<void>(resolve=>server.close(()=>resolve()))}
