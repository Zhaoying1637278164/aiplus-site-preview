import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {restore,execute} from '../tools/D06-财务明细核查/src/workflow';
const base='progress/evidence/D06/0.2.0/';
const proof:string[]=[];
const artifacts:any[]=[];
async function compare(publicName:string,offlineName:string){
 const bytes=await readFile(base+'site-public/'+publicName);
 const actual=restore(bytes.toString());
 const expected=restore(await readFile(base+offlineName,'utf8'));
 assert.deepEqual(actual,expected);
 assert.deepEqual(execute(actual),execute(expected));
 const r=execute(actual);
 artifacts.push({filename:publicName,sha256:createHash('sha256').update(bytes).digest('hex'),input:r.input,included:r.report.stats.input_rows,excluded:r.excluded.map(x=>x.source.row),issues:r.report.issues.length,review_events:Object.values(actual.reviews).flat().length});
 proof.push(publicName+': complete session and run exactly equal to offline');
}
for(const ext of ['csv','xlsx'])for(const scope of ['完整','范围'])await compare(ext+'-'+scope+'工作.json','input/'+ext+'-'+scope+'工作.json');
await compare('离线工作恢复再下载.json','browser/含数据工作.json');
assert.match(await readFile(base+'site-public/chrome-取消退出.txt','utf8'),/8行/);
assert.match(await readFile(base+'site-public/chrome-确认退出.txt','utf8'),/开始核查明细/);
assert.match(await readFile(base+'site-public/chrome-重进清空.txt','utf8'),/尚未导入资料/);
await writeFile(base+'site-public/workflows-final.json',JSON.stringify({date:'2026-10-03',tool:'D06',version:'0.2.0',commit:'701542fd5d9077a622c0e0e3d0190ae2c4d9c409',scope:'Actual public CUA file chooser and browser downloads, no injected application state',proof,artifacts,passed:true,exit_reentry:'passed native Chrome cancel, accept, reentry empty; raw AX observations retained',supplementary_validation:'Supplement recorded separately in supplement.json; historical pre-supplement checkpoint retained',windows:'未验证'},null,2)+'\n');
console.log('PASS: five actual public downloads; complete sessions and runs exactly equal to offline.');
