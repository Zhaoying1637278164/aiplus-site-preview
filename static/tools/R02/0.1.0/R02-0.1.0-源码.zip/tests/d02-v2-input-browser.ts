import {chromium} from 'playwright';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import {createHash} from 'node:crypto';
const evidence=path.resolve('progress/evidence/D02/0.2.0'),fixtures=path.join(evidence,'input-fixtures');
await mkdir(fixtures,{recursive:true});
// Independent expected case: 30 identical unique documents; zero and negative are legitimate.
const headers=['单据号','金额','日期','币种'];
const rows=Array.from({length:30},(_,i)=>[String(i+1).padStart(3,'0'),i===0?'0':i===1?'-12.34':`${i+1}.10`,`2026-09-${String(i+1).padStart(2,'0')}`,'CNY']);
const csv=path.join(fixtures,'虚构三十笔.csv');await writeFile(csv,[headers,...rows].map(r=>r.join(',')).join('\n'));
const wb=new ExcelJS.Workbook();
for(const name of ['正常表','第二行表头','公式资料']){
 const sheet=wb.addWorksheet(name);if(name==='第二行表头')sheet.addRow(['完全虚构测试说明']);
 sheet.addRow(headers);sheet.addRows(rows);if(name==='公式资料')sheet.getCell('B4').value={formula:'1+998',result:999};
}
const xlsx=path.join(fixtures,'虚构多页签.xlsx');await wb.xlsx.writeFile(xlsx);
const browser=await chromium.launch({executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
try{
 const context=await browser.newContext({offline:true,acceptDownloads:true,viewport:{width:1440,height:1000}}),page=await context.newPage();
 const requests:string[]=[];page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});
 await page.goto(pathToFileURL(path.resolve('release/D02/0.2.0/index.html')).href);
 await page.getByRole('button',{name:'体验虚构示例',exact:true}).click();
 await page.getByLabel('导入第1方',{exact:true}).setInputFiles(csv);
 await page.getByText(/虚构三十笔.csv.*30行/).waitFor();
 await page.getByLabel('导入第2方',{exact:true}).setInputFiles(xlsx);
 await page.getByText(/虚构多页签.xlsx \/ 正常表.*30行/).waitFor();
 async function generate(){await page.getByRole('button',{name:'范围与口径',exact:true}).click();await page.getByLabel('确认本次范围口径').check();await page.getByRole('button',{name:'生成差异',exact:true}).click();await page.getByRole('heading',{name:'差异总览',exact:true}).waitFor()}
 async function work(name:string){await page.getByRole('button',{name:'结果底稿',exact:true}).click();const pending=page.waitForEvent('download');await page.getByRole('button',{name:'保存本次工作底稿（含数据）',exact:true}).click();const d=await pending;assert.equal(await d.failure(),null);const file=path.join(evidence,name);await d.saveAs(file);return JSON.parse(await readFile(file,'utf8'))}
 await generate();let data=await work('新导入三十笔.json');assert.deepEqual(data.run.input,[30,30]);assert.equal(data.run.result.counts['匹配一致'].groups,30);assert.equal(data.tables[0].rows[0].cells.单据号,'001');assert.equal(data.tables[0].rows[0].cells.金额,'0');assert.equal(data.tables[0].rows[1].cells.金额,'-12.34');
 await page.getByRole('button',{name:'逐项复核',exact:true}).click();await page.getByText('第1/2页 · 每页25组',{exact:true}).waitFor();await page.getByRole('button',{name:'下一页',exact:true}).click();await page.getByText('第2/2页 · 每页25组',{exact:true}).waitFor();
 await page.getByLabel('搜索全部核对结果').fill('030');await page.getByText('第1/1页 · 每页25组',{exact:true}).waitFor();assert.equal(await page.locator('.d02-review tbody tr').count(),1);
 await page.getByRole('button',{name:'范围与口径',exact:true}).click();await page.getByLabel('筛选字段').selectOption('单据号');await page.getByLabel('纳入字段值').selectOption(['001','002','003']);await page.getByRole('button',{name:'加入范围条件',exact:true}).click();
 await page.getByRole('button',{name:'差异总览',exact:true}).click();await page.getByRole('heading',{name:'旧结果已失效',exact:true}).waitFor();assert.equal(await page.getByRole('button',{name:'保存本次工作底稿（含数据）',exact:true}).count(),0);
 await generate();data=await work('单方范围.json');assert.deepEqual(data.run.included,[3,30]);assert.equal(data.run.excluded.length,27);assert.equal(data.run.result.counts['匹配一致'].groups,3);assert.equal(data.run.result.counts['仅右侧'].groups,27);
 await page.getByRole('button',{name:'范围与口径',exact:true}).click();await page.getByLabel('筛选来源').selectOption('1');await page.getByLabel('筛选字段').selectOption('日期');
 await page.locator('select').filter({has:page.locator('option[value="date"]', {hasText:'日期区间'})}).selectOption('date');
 await page.getByLabel('范围开始日').fill('2026-09-01');await page.getByLabel('范围结束日').fill('2026-09-03');await page.getByRole('button',{name:'加入范围条件',exact:true}).click();await generate();
 data=await work('双方范围.json');assert.deepEqual(data.run.included,[3,3]);assert.equal(data.run.excluded.length,54);assert.equal(data.run.result.counts['匹配一致'].groups,3);
 await page.screenshot({path:evidence+'/范围筛选-desktop.png',fullPage:true});
 await page.getByRole('button',{name:'两方资料',exact:true}).click();const second=page.locator('.d02-two > article').nth(1);
 await second.getByLabel(/^页签/).selectOption('第二行表头');await second.getByLabel('表头行',{exact:true}).fill('2');await page.getByText(/虚构多页签.xlsx \/ 第二行表头.*30行.*4列/).waitFor();
 await page.getByRole('button',{name:'差异总览',exact:true}).click();await page.getByRole('heading',{name:'旧结果已失效',exact:true}).waitFor();await generate();data=await work('第二行表头.json');assert.equal(data.tables[1].rows[0].row,3);assert.equal(data.tables[1].sheet,'第二行表头');assert.equal(data.run.result.counts['匹配一致'].groups,3);
 await page.getByRole('button',{name:'两方资料',exact:true}).click();await second.getByLabel(/^页签/).selectOption('公式资料');await second.getByLabel('表头行',{exact:true}).fill('1');await page.getByText(/虚构多页签.xlsx \/ 公式资料.*30行.*4列/).waitFor();await generate();data=await work('公式拒绝.json');assert.equal(data.run.result.counts['无效输入'].groups,1);assert.equal(data.run.result.counts['匹配一致'].groups,2);assert.equal(data.tables[1].rows[2].cells.金额.formula,'1+998');
 await page.getByRole('button',{name:'两方资料',exact:true}).click();await page.getByLabel('导入第2方',{exact:true}).setInputFiles(csv);await page.getByText(/虚构三十笔.csv.*30行/).nth(1).waitFor();await page.getByRole('button',{name:'逐项复核',exact:true}).click();await page.getByRole('heading',{name:'旧结果已失效',exact:true}).waitFor();
 assert.equal(requests.length,0);assert.equal(await page.evaluate(()=>localStorage.length),0);
 await writeFile(path.join(evidence,'browser-input.json'),JSON.stringify({date:'2026-10-03',version:'0.2.0',html_sha256:createHash('sha256').update(await readFile('release/D02/0.2.0/index.html')).digest('hex'),browser:await browser.version(),platform:'Mac Chromium',windows:'未验证',independent_expected:'30 unique equal rows; left first3 => 3 equal/27 right-only; right dates01..03 =>3 equal/54 excluded; formula in doc003 =>2 equal/1 invalid',checks:['actual_csv_xlsx_import','text_leading_zero_zero_negative','full_search_and_pagination','value_date_filters_excluded_rows','parameter_sheet_header_source_invalidate','second_sheet_second_header_source_row','formula_cache_not_calculated','no_http_storage']},null,2));
 console.log('D02真实新文件/分页搜索/范围筛选/换资料失效/公式拒绝通过');
}finally{await browser.close()}
