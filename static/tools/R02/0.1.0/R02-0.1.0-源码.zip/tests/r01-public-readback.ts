import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import ExcelJS from 'exceljs';
import {decode} from '../tools/R01-合同开票回款台账/src/work';
import {calculate} from '../tools/R01-合同开票回款台账/src/engine';

const base=path.resolve('progress/evidence/R01/0.1.0');
const out=path.join(base,'site-public');
const offline=decode(await readFile(path.join(base,'formal-browser/基线含数据工作.json'),'utf8'));
const sample=decode(await readFile(path.join(out,'公开样例工作.json'),'utf8'));
const notes=decode(await readFile(path.join(out,'公开含备注工作.json'),'utf8'));
assert.deepEqual(notes,offline,'Entire public notes work must equal actual offline work');
const result=calculate(sample);
assert.equal(result.totals.receivable,'350');
assert.equal(result.totals.unreceived,'1150');
assert.equal(result.totals.invoicesTotal,'800');
assert.equal(result.totals.receiptsTotal,'650');
assert.ok(Object.values(result.reconciliation).every(v=>v==='0'));
assert.deepEqual(calculate(notes),calculate(offline));
async function cells(file:string){
  const b=new ExcelJS.Workbook();await b.xlsx.readFile(file);
  return b.worksheets.map(s=>({name:s.name,rows:Array.from({length:s.rowCount},(_,i)=>Array.from({length:s.columnCount},(_,j)=>s.getRow(i+1).getCell(j+1).value))}));
}
const actual=await cells(path.join(out,'公开完整结果底稿.xlsx'));
assert.equal(actual.length,8);
assert.deepEqual(actual,await cells(path.join(base,'formal-browser/结果底稿.xlsx')),'Every cell of all eight actual public/offline worksheets');
const restored=decode(await readFile(path.join(out,'公开恢复后工作.json'),'utf8'));
assert.deepEqual(restored,offline,'Actual public restoration retains entire offline work');
const xlsx=decode(await readFile(path.join(out,'公开五表导入工作.json'),'utf8'));
const importedResult=calculate(xlsx);
assert.deepEqual(importedResult.totals,result.totals);
assert.deepEqual(importedResult.flows,result.flows);
assert.deepEqual(importedResult.reconciliation,result.reconciliation);
assert.equal(xlsx.history.length,5);
for(const [kind,rows] of Object.entries(xlsx.tables)){
  assert.equal(rows.length,offline.tables[kind as keyof typeof offline.tables].length);
  assert.ok(rows.every(r=>r.file==='r01-public-sample.xlsx'&&r.row>=2&&r.sheet));
}
const csv=decode(await readFile(path.join(out,'公开CSV换入工作.json'),'utf8'));
const csvResult=calculate(csv);
assert.equal(csv.tables.contracts[0].file,'r01-public-contracts.csv');
assert.equal(csv.tables.contracts[0].row,3);
assert.equal(csvResult.contracts.length,1);
assert.equal(csvResult.contracts[0].contract,'0');
assert.equal(csvResult.issues.filter(i=>i.kind==='contracts'&&i.level==='错误').length,3);
assert.equal(csvResult.totals.receivable,'800');
assert.equal(csvResult.totals.linkedReceivable,'0');
assert.equal(csvResult.totals.receiptsUnallocated,'650');
assert.ok(Object.values(csvResult.reconciliation).every(v=>v==='0'));
for(const file of ['公开无数据恢复后工作.json','公开退出重进工作.json']){
  const empty=decode(await readFile(path.join(out,file),'utf8'));
  assert.ok(Object.values(empty.tables).every(rows=>rows.length===0));
  assert.deepEqual(empty.notes,{});assert.equal(empty.history.length,0);
}
const hashes:Record<string,string>={};
for(const f of ['公开样例工作.json','公开含备注工作.json','公开完整结果底稿.xlsx','公开恢复后工作.json','公开五表导入工作.json','公开CSV换入工作.json','公开无数据恢复后工作.json','公开退出重进工作.json'])hashes[f]=createHash('sha256').update(await readFile(path.join(out,f))).digest('hex');
await writeFile(path.join(out,'downloaded-work-readback.json'),JSON.stringify({schema_version:1,scope:'Actual Chrome public UI downloads captured by exact output filename and post-click mtime; full offline/public work and workbook readback',status:'passed',hashes,worksheets:actual.map(s=>({name:s.name,rows:s.rows.length})),manual_totals:result.totals,all_reconciliation_zero:true,entire_notes_work_equal:true,entire_calculation_equal:true,all_eight_worksheet_cells_equal:true,restored_entire_work_equal:true,five_actual_xlsx_imports_finance_equal:true,actual_csv_original_row3_zero_valid_duplicate_and_empty_blocked:true,no_data_restore_all_five_tables_notes_history_empty:true,exit_reentry_all_five_tables_notes_history_empty:true,html_sha256:createHash('sha256').update(await readFile('release/R01/0.1.0/index.html')).digest('hex'),remaining:'Final evidence aggregation; Windows real machine unverified'},null,2));
console.log('R01 public work and all eight workbook sheets equal actual offline downloads');
