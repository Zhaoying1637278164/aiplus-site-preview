import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {calculate} from '../tools/R02-收入确认排程表/src/engine';
import {table} from '../tools/R02-收入确认排程表/src/example';
import {emptyData,defaultConfig,type Data} from '../tools/R02-收入确认排程表/src/types';
import {protectFrozen} from '../tools/R02-收入确认排程表/src/transition';
const rows:unknown[]=[];
const fixture=(amount:string,start:string,end:string,method='按日'):Data=>({...emptyData(),contracts:table('contracts',[['C','K','完全虚构客户',amount,amount,'CNY','元']]),obligations:table('obligations',[['C','O','完全虚构服务',amount,start,end,method,'是',method==='里程碑'?'时点':'时段','总额','虚构人工已批准']])});
function check(name:string,d:Data,cutoff:string,expected:Record<string,unknown>){const r=calculate(d,{...defaultConfig,cutoff});const actual=Object.fromEntries(Object.keys(expected).map(k=>[k,k==='monthly'?r.lines.map(l=>l.plan):r.summaries[0]?.[k as keyof typeof r.summaries[0]]]));assert.deepEqual(actual,expected,name);rows.push({name,cutoff,input:d,expected,actual});}
// Expected values are manual date fractions/decimal arithmetic, independent of the engine.
check('31日93元，前15日45元',fixture('93','2026-01-01','2026-01-31'),'2026-01-15',{plan:'93.00',due:'45.00',remaining:'93.00',unfulfilled:'0.00'});
check('4个闰年日8元：2日每月各4元',fixture('8','2024-02-28','2024-03-02'),'2024-02-29',{monthly:['4.00','4.00'],due:'4.00'});
check('分为3期的1分钱只在累计达到半分后入中期',fixture('0.01','2026-01-01','2026-03-31','月份等额'),'2026-02-28',{monthly:['0.00','0.01','0.00'],due:'0.01'});
const book=fixture('93','2026-01-01','2026-01-31');book.actuals=table('actuals',[['A','C','O','K','2026-01-10','20','CNY','元','虚构凭证A'],['B','C','O','K','2026-01-20','73','CNY','元','虚构凭证B']]);
check('未来账面73单列；当前计划45减实际20差25',book,'2026-01-15',{due:'45.00',actual:'20.00',pending:'25.00',remaining:'73.00'});
const milestone=fixture('100','2026-01-01','2026-12-31','里程碑');milestone.milestones=table('milestones',[['M1','C','O','2026-02-01','40','2026-02-01','虚构验收'],['M2','C','O','2026-03-01','60','','']]);
check('40完成60未完成，完成并非已记账',milestone,'2026-03-31',{plan:'100.00',due:'40.00',actual:'0.00',pending:'40.00',remaining:'100.00',unfulfilled:'60.00'});
const terminate=fixture('1200','2026-01-01','2026-12-31','月份等额');terminate.actuals=table('actuals',[['A','C','O','K','2026-03-31','300','CNY','元','虚构凭证']]);terminate.changes=table('changes',[['G','C','O','V2','2026-04-01','250','2026-04-01','2026-12-31','-50','终止','虚构终止批准']]);
check('终止250保留原实际300，负差50待冲回',terminate,'2026-04-30',{plan:'250.00',due:'250.00',actual:'300.00',pending:'-50.00',remaining:'-50.00'});
for(const field of ['客户ID','币种','单位']){const d=structuredClone(book);d.actuals!.rows[0].cells[field]='不同';const r=calculate(d,{...defaultConfig,cutoff:'2026-01-15'});assert.equal(r.summaries.length,0);assert.ok(r.issues.some(i=>i.severity==='阻塞'));rows.push({name:field+'不一致整事项阻塞',expected:'0有效事项',actual:r});}
const frozen=fixture('1200','2026-01-01','2026-12-31','月份等额');assert.throws(()=>protectFrozen(frozen,fixture('2400','2026-01-01','2026-12-31','月份等额'),{...defaultConfig,frozenThrough:'2026-03'}),/冻结/);rows.push({name:'冻结一季度阻止资料替换翻倍历史',passed:true});
const engineSha=createHash('sha256').update(await readFile('tools/R02-收入确认排程表/src/engine.ts')).digest('hex');await mkdir('progress/evidence/shared',{recursive:true});await writeFile('progress/evidence/shared/2026-10-03-R02-independent-review.json',JSON.stringify({tool:'R02',passed:true,checks:rows.length,engine_sha256:engineSha,expected_method:'manual fractions and decimal arithmetic; not copied from engine',results:rows,scope:'source business audit only; formal artifacts/offline/website/source ZIP still unverified'},null,2));console.log('R02 root independent '+rows.length+' cases passed');
