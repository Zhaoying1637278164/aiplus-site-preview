import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
const base=process.env.AIPLUS_NATIVE_FIXTURE_URL||'http://127.0.0.1:8513';
const browser=await chromium.launch({executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
try{
 const page=await browser.newPage();const programRequests:string[]=[];
 page.on('request',r=>{if(r.url().endsWith('runtime.json'))programRequests.push(r.url())});
 await page.goto(base+'/?tool=D02',{waitUntil:'domcontentloaded'});
 const frame=page.frameLocator('iframe').first();
 await frame.getByRole('heading',{name:'原生整合测试（非财务成品）'}).waitFor({timeout:20000});
 assert.equal(await frame.locator('iframe').count(),0);
 assert.equal(programRequests.length,1);assert.ok(programRequests[0].includes('/app/static/tools/D02/9.9.9/runtime.json'));
 await frame.getByRole('button',{name:'返回账表对账详情',exact:true}).click();
 await frame.getByRole('heading',{name:'账表对账',exact:true}).waitFor();
 await frame.getByRole('link',{name:'开始账表对账',exact:true}).click();
 await frame.getByLabel('完全虚构的测试事项').waitFor();
 await page.goto(base+'/?tool=../../app.py',{waitUntil:'domcontentloaded'});
 await page.getByText('该工具尚未开放，请从工具库选择已交付的工具。',{exact:true}).waitFor();
 await page.frameLocator('iframe').first().locator('a[href="#tools"]').first().click();
 assert.equal(await page.frameLocator('iframe').first().locator('[data-total]').innerText(),'77');
 await writeFile('progress/evidence/product-reset/native-streamlit.json',JSON.stringify({date:'2026-10-03',scope:'Native mounting fixture in actual Streamlit 1.50.0; no financial acceptance',base,browser:await browser.version(),checks:['same_website_under_existing_streamlit_wrapper','srcdoc_first_party_program_load','query_exact_registry_lookup','native_workspace_and_detail_roundtrip','unknown_query_no_file_path_interpolation'],programRequests},null,2));
 console.log('真实Streamlit承载的原生挂载样例验证通过');
}finally{await browser.close()}
