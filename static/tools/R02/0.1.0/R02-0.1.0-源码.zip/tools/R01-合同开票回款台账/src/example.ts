import {emptyWork,type Work,type Kind,fields,names} from './model';
import type {SourceRow} from '../../../packages/core/types';
export function makeRow(k:Kind,v:Record<string,string|number|null>,row=2,file='完全虚构样例.xlsx'):SourceRow{return {file,sheet:names[k],row,cells:Object.fromEntries(fields[k].map(f=>[f,v[f]??null]))}}
export function example():Work{const w=emptyWork();w.config.complete=true;
 const base={日期:'2026-09-05',币种:'CNY',单位:'元',口径:'含税',状态:'有效',依据:'完全虚构演示'};
 w.tables.contracts=[['C1','A','1000'],['C2','A','500'],['C3','B','200']].map(([ID,客户ID,金额],i)=>makeRow('contracts',{...base,ID,客户ID,金额,客户名称:'虚构北辰',名称:'演示合同'+ID},i+2));
 w.tables.invoices=[['I1','600','正票',''],['I2','300','正票',''],['I3','-100','红字','I1']].map(([ID,金额,类型,原单ID],i)=>makeRow('invoices',{...base,ID,金额,类型,原单ID,客户ID:'A',日期:'2026-09-10'},i+2));
 w.tables.receipts=[['P1','500','收款',''],['P2','200','收款',''],['P3','-50','退款','P1']].map(([ID,金额,类型,原单ID],i)=>makeRow('receipts',{...base,ID,金额,类型,原单ID,客户ID:'A',日期:'2026-09-15'},i+2));
 w.tables.allocations=[['A1','开票','I1','C1','','400'],['A2','开票','I1','C2','','200'],['A3','开票','I2','C1','','300'],['A4','开票','I3','C1','','-100'],['A5','回款','P1','C1','I1','300'],['A6','回款','P1','C2','I1','200'],['A7','回款','P2','C1','','100'],['A8','回款','P3','C1','I1','-50']].map(([ID,分配类型,单据ID,合同ID,发票ID,金额],i)=>makeRow('allocations',{ID,分配类型,单据ID,合同ID,发票ID,金额,日期:分配类型==='开票'?'2026-09-10':'2026-09-15',依据:'虚构经办指定分配'},i+2));
 w.tables.revenue=[makeRow('revenue',{...base,ID:'N1',客户ID:'A',合同ID:'C1',金额:'250',口径:'不含税',依据:'虚构独立收入底稿'})];return w}
