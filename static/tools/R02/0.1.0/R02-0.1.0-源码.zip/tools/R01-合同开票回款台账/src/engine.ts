import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';
import type {SourceRow} from '../../../packages/core/types';
import {checkConfig,validateRows,kinds,type Kind,type Work} from './model';
import {VERSION,RULE_VERSION} from './version';
export interface Issue {key:string;kind:Kind;index:number;level:'错误'|'排除'|'复核';message:string;source:SourceRow}
interface Doc {id:string;customer:string;name:string;day:string;n:Decimal;row:SourceRow;index:number;ref:string;type:string}
interface Alloc {id:string;kind:'invoices'|'receipts';doc:string;contract:string;invoice:string;day:string;n:Decimal;row:SourceRow;index:number}
export interface Balance {id:string;customer:string;name:string;contract:string;invoiced:string;received:string;settled:string;advance:string;unbilled:string;unreceived:string;receivable:string;revenue:string|null;status:string}
export interface CustomerBalance extends Balance {linkedReceivable:string;unallocatedInvoiced:string}
export interface DocumentBalance {kind:'invoices'|'receipts';id:string;customer:string;amount:string;allocated:string;unallocated:string;settled:string;outstanding:string;source:SourceRow}
export interface Result {app_version:string;rule_version:string;contracts:Balance[];customers:CustomerBalance[];documents:DocumentBalance[];allocations:{id:string;kind:string;doc:string;contract:string;invoice:string;amount:string;source:SourceRow}[];issues:Issue[];totals:Record<string,string|null>;flows:Record<string,string>;reconciliation:Record<string,string>;sources:{kind:Kind;index:number;status:string;source:SourceRow}[]}
const sum=(items:Decimal[])=>items.reduce((a,b)=>a.plus(b),new Decimal(0));
const opt=(r:SourceRow,k:string)=>r.cells[k]===null||r.cells[k]===undefined||r.cells[k]===''?'':text(r.cells[k]);
export function calculate(w:Work):Result{
 checkConfig(w.config);for(const k of kinds)validateRows(w.tables[k]);
 const issues:Issue[]=[];const status=new Map<string,string>();
 const issue=(kind:Kind,index:number,level:Issue['level'],message:string)=>{issues.push({key:`${kind}:${index}:${message}`,kind,index,level,message,source:w.tables[kind][index]});if(level!=='复核')status.set(`${kind}:${index}`,level)};
 const docs={contracts:new Map<string,Doc>(),invoices:new Map<string,Doc>(),receipts:new Map<string,Doc>(),revenue:new Map<string,Doc>()};
 const duplicates=(k:Kind)=>{const m=new Map<string,number>();for(const r of w.tables[k]){let id='';try{id=opt(r,'ID')}catch{continue}m.set(id,(m.get(id)||0)+1)}return m};
 for(const k of ['contracts','invoices','receipts','revenue'] as const){const dup=duplicates(k);w.tables[k].forEach((r,index)=>{try{
 if(Object.values(r.cells).some(c=>typeof c==='object'&&c!==null||typeof c==='string'&&/^\s*[=]/.test(c)))throw Error('含公式/缓存，须全部改为静态值');
 const id=text(r.cells.ID);if(dup.get(id)!==1)throw Error('稳定ID重复，全部重复行阻塞');
 const customer=text(r.cells['客户ID']),day=date(r.cells['日期']),n=amount(r.cells['金额']);
 const currency=text(r.cells['币种']),unit=text(r.cells['单位']),basis=text(r.cells['口径']),state=text(r.cells['状态']);
 if(!['有效','撤销'].includes(state))throw Error('状态须为有效或撤销');
 if(state==='撤销'){const cancel=date(r.cells['撤销日期']);if(cancel<day)throw Error('撤销日期早于单据日期');if(cancel<=w.config.cutoff){issue(k,index,'排除','截止日前已撤销');return}}
 if(day>w.config.cutoff){issue(k,index,'排除','截止日后记录');return}
 if(currency!==w.config.currency||unit!==w.config.unit||basis!==w.config.basis){issue(k,index,'排除','币种/单位/含税口径与本次范围不同');return}
 const type=k==='invoices'?text(r.cells['类型']):k==='receipts'?text(r.cells['类型']):'',ref=opt(r,'原单ID');
 if(k==='contracts'&&n.lt(0))throw Error('合同金额不能为负');
 if(k==='invoices'||k==='receipts'){const normal=k==='invoices'?'正票':'收款',negative=k==='invoices'?'红字':'退款';if(![normal,negative].includes(type))throw Error('单据类型无效');if(type===normal&&(n.lt(0)||ref))throw Error('正单金额须非负且不引用原单');if(type===negative&&(!n.lt(0)||!ref))throw Error('冲减须负金额及原单ID')}
 if(k==='revenue'){text(r.cells['依据']);text(r.cells['合同ID'])}
 docs[k].set(id,{id,customer,name:opt(r,'名称')||opt(r,'客户名称'),day,n,row:r,index,ref,type});
 }catch(e){issue(k,index,'错误',(e as Error).message)}})}
 for(const k of ['invoices','receipts'] as const){const bad=new Set<string>();const groups=new Map<string,Doc[]>();for(const d of docs[k].values())if(d.ref){const o=docs[k].get(d.ref);if(!o||o.ref||o.customer!==d.customer||o.day>d.day){issue(k,d.index,'错误','原单不存在、非正单、客户不同或日期倒置');bad.add(d.id);continue}groups.set(d.ref,[...(groups.get(d.ref)||[]),d])}for(const [ref,g] of groups)if(sum(g.map(d=>d.n.abs())).gt(docs[k].get(ref)!.n)){for(const d of g){issue(k,d.index,'错误','累计冲减超过原单金额');bad.add(d.id)}}for(const id of bad)docs[k].delete(id)}
 for(const d of docs.revenue.values()){const c=docs.contracts.get(text(d.row.cells['合同ID']));if(!c||c.customer!==d.customer||d.day<c.day){issue('revenue',d.index,'错误','收入合同不存在、客户不同或日期倒置');docs.revenue.delete(d.id)}}
 let allocs:Alloc[]=[];const dup=duplicates('allocations');
 w.tables.allocations.forEach((r,index)=>{try{
 if(Object.values(r.cells).some(c=>typeof c==='object'&&c!==null||typeof c==='string'&&/^\s*=/.test(c)))throw Error('含公式/缓存，须全部改为静态值');
 const id=text(r.cells.ID);if(dup.get(id)!==1)throw Error('分配ID重复，全部重复行阻塞');
 const typ=text(r.cells['分配类型']);if(!['开票','回款'].includes(typ))throw Error('分配类型须开票或回款');
 const kind=typ==='开票'?'invoices':'receipts',doc=text(r.cells['单据ID']),contract=text(r.cells['合同ID']),invoice=opt(r,'发票ID'),day=date(r.cells['日期']),n=amount(r.cells['金额']);text(r.cells['依据']);
 if(day>w.config.cutoff){issue('allocations',index,'排除','截止日后分配');return}
 const d=docs[kind].get(doc),c=docs.contracts.get(contract);if(!d||!c)throw Error('来源单据或合同未有效纳入');if(d.customer!==c.customer)throw Error('跨客户分配禁止');if(day<d.day||day<c.day)throw Error('分配日期早于单据/合同');if(n.isZero()||n.isPositive()!==d.n.isPositive())throw Error('分配金额零或方向与来源不同');if(kind==='invoices'&&invoice)throw Error('开票分配不填写发票ID（用单据ID）');
 allocs.push({id,kind,doc,contract,invoice,day,n,row:r,index});
 }catch(e){issue('allocations',index,'错误',(e as Error).message)}});
 // Validate all proposed allocations as a set before using any, never let array order select a winner.
 const bad=new Set<number>();const group=new Map<string,Alloc[]>();for(const a of allocs)group.set(a.kind+':'+a.doc,[...(group.get(a.kind+':'+a.doc)||[]),a]);for(const g of group.values()){const d=docs[g[0].kind].get(g[0].doc)!;if(sum(g.map(a=>a.n.abs())).gt(d.n.abs()))for(const a of g){bad.add(a.index);issue('allocations',a.index,'错误','来源单据整组超额分配，全部阻塞')}}
 allocs=allocs.filter(a=>!bad.has(a.index));
 // Reversals must reverse an explicitly allocated original target, never silently transfer between contracts/invoices.
 const validateReversals=(kind:Alloc['kind'])=>{const reversed=new Map<string,Alloc[]>();for(const a of allocs.filter(a=>a.kind===kind&&docs[a.kind].get(a.doc)!.ref)){const d=docs[a.kind].get(a.doc)!;const key=JSON.stringify([a.kind,d.ref,a.contract,a.invoice]);reversed.set(key,[...(reversed.get(key)||[]),a])}for(const g of reversed.values()){const a=g[0],ref=docs[a.kind].get(a.doc)!.ref;const invalid=g.some(c=>sum(g.filter(b=>b.day<=c.day).map(b=>b.n.abs())).gt(sum(allocs.filter(b=>b.kind===kind&&b.doc===ref&&b.contract===a.contract&&b.invoice===a.invoice&&b.day<=c.day).map(b=>b.n))));if(invalid)for(const b of g){bad.add(b.index);issue('allocations',b.index,'错误','冲减分配超过原单同合同/发票的分配')}}allocs=allocs.filter(a=>!bad.has(a.index))};
 validateReversals('invoices');
 // Receipt to invoice needs an explicit effective invoice-to-contract relationship, including date validity.
 allocs=allocs.filter(a=>{if(a.kind!=='receipts'||!a.invoice)return true;const d=docs.invoices.get(a.invoice);if(!d||d.customer!==docs.receipts.get(a.doc)!.customer||d.day>a.day||!allocs.some(b=>b.kind==='invoices'&&b.doc===a.invoice&&b.contract===a.contract&&b.day<=a.day)){issue('allocations',a.index,'错误','指定发票无有效同合同开票分配或日期倒置');return false}return true});
 validateReversals('receipts');
 const forC=(id:string,kind:Alloc['kind'],settled?:boolean)=>sum(allocs.filter(a=>a.contract===id&&a.kind===kind&&(settled===undefined||Boolean(a.invoice)===settled)).map(a=>a.n));
 const contracts:Balance[]=[];for(const c of docs.contracts.values()){const inv=forC(c.id,'invoices'),cash=forC(c.id,'receipts'),settled=forC(c.id,'receipts',true),advance=forC(c.id,'receipts',false),unbilled=c.n.minus(inv),unreceived=c.n.minus(cash),receivable=inv.minus(settled),rev=[...docs.revenue.values()].filter(d=>text(d.row.cells['合同ID'])===c.id);if(unbilled.lt(0)||unreceived.lt(0)||receivable.lt(0))issue('contracts',c.index,'复核','超开票/超回款/负余额待复核');contracts.push({id:c.id,customer:c.customer,name:c.name,contract:c.n.toString(),invoiced:inv.toString(),received:cash.toString(),settled:settled.toString(),advance:advance.toString(),unbilled:unbilled.toString(),unreceived:unreceived.toString(),receivable:receivable.toString(),revenue:rev.length?sum(rev.map(d=>d.n)).toString():null,status:receivable.abs().lte(amount(w.config.tolerance))?'已开票余额在容差内':'待回款复核'})}
 const documents:DocumentBalance[]=[];for(const kind of ['invoices','receipts'] as const)for(const d of docs[kind].values()){const allocated=sum(allocs.filter(a=>a.kind===kind&&a.doc===d.id).map(a=>a.n)),remaining=d.n.minus(allocated),settled=kind==='invoices'?sum(allocs.filter(a=>a.kind==='receipts'&&a.invoice===d.id).map(a=>a.n)):new Decimal(0);if(!remaining.isZero())issue(kind,d.index,'复核','存在未分配金额 '+remaining.toString());const outstanding=kind==='invoices'?d.n.minus(settled):remaining;if(kind==='invoices'&&outstanding.lt(0))issue(kind,d.index,'复核','发票负余额/超收待复核');documents.push({kind,id:d.id,customer:d.customer,amount:d.n.toString(),allocated:allocated.toString(),unallocated:remaining.toString(),settled:settled.toString(),outstanding:outstanding.toString(),source:d.row})}
 // Check each invoice-contract pair separately so excess receipts cannot be hidden by another contract's invoice balance.
 for(const a of allocs.filter(a=>a.kind==='receipts'&&a.invoice)){const invoiced=sum(allocs.filter(b=>b.kind==='invoices'&&b.doc===a.invoice&&b.contract===a.contract).map(b=>b.n));const paid=sum(allocs.filter(b=>b.kind==='receipts'&&b.invoice===a.invoice&&b.contract===a.contract).map(b=>b.n));if(paid.gt(invoiced))issue('allocations',a.index,'复核','该发票/合同组合超收，余额保留')}
 const nums=['contract','invoiced','received','settled','advance','unbilled','unreceived','receivable'] as const;const customers:CustomerBalance[]=[];for(const id of new Set([...contracts.map(c=>c.customer),...documents.map(d=>d.customer)])){const cs=contracts.filter(c=>c.customer===id),ds=documents.filter(d=>d.kind==='invoices'&&d.customer===id),raw=[...docs.contracts.values()].find(c=>c.customer===id)?.row||ds[0]?.source;const b:CustomerBalance={id,customer:id,name:raw?opt(raw,'客户名称')||id:id,contract:'0',invoiced:'0',received:'0',settled:'0',advance:'0',unbilled:'0',unreceived:'0',receivable:'0',revenue:cs.some(c=>c.revenue!==null)?sum(cs.filter(c=>c.revenue!==null).map(c=>new Decimal(c.revenue!))).toString():null,status:'全量有效票按客户ID汇总',linkedReceivable:sum(cs.map(c=>new Decimal(c.receivable))).toString(),unallocatedInvoiced:sum(ds.map(d=>new Decimal(d.unallocated))).toString()};for(const n of nums)b[n]=sum(cs.map(c=>new Decimal(c[n]))).toString();b.receivable=sum(ds.map(d=>new Decimal(d.outstanding))).toString();customers.push(b)}
 const totals:Record<string,string|null>={};for(const n of nums)totals[n]=sum(contracts.map(c=>new Decimal(c[n]))).toString();totals.linkedReceivable=totals.receivable;totals.receivable=sum(documents.filter(d=>d.kind==='invoices').map(d=>new Decimal(d.outstanding))).toString();totals.revenue=contracts.some(c=>c.revenue!==null)?sum(contracts.filter(c=>c.revenue!==null).map(c=>new Decimal(c.revenue!))).toString():null;
 const flows:Record<string,string>={};for(const k of ['invoices','receipts','revenue'] as const)flows[k]=sum([...docs[k].values()].filter(d=>d.day>=w.config.start).map(d=>d.n)).toString();
 const reconciliation:Record<string,string>={};for(const kind of ['invoices','receipts'] as const){const ds=documents.filter(d=>d.kind===kind);totals[kind+'Total']=sum(ds.map(d=>new Decimal(d.amount))).toString();totals[kind+'Unallocated']=sum(ds.map(d=>new Decimal(d.unallocated))).toString();reconciliation[kind]=sum(ds.map(d=>new Decimal(d.amount).minus(d.allocated).minus(d.unallocated))).toString()}reconciliation.receivable=new Decimal(totals.invoicesTotal!).minus(totals.settled!).minus(totals.receivable!).toString();reconciliation.linkedReceivable=new Decimal(totals.invoiced!).minus(totals.settled!).minus(totals.linkedReceivable!).toString();reconciliation.unlinkedReceivable=new Decimal(totals.receivable!).minus(totals.linkedReceivable!).minus(totals.invoicesUnallocated!).toString();for(const n of nums)reconciliation['customer_'+n]=sum(customers.map(c=>new Decimal(c[n]))).minus(totals[n]!).toString();
 reconciliation.customer_linkedReceivable=sum(customers.map(c=>new Decimal(c.linkedReceivable))).minus(totals.linkedReceivable!).toString();reconciliation.customer_unallocatedInvoiced=sum(customers.map(c=>new Decimal(c.unallocatedInvoiced))).minus(totals.invoicesUnallocated!).toString();
 return {app_version:VERSION,rule_version:RULE_VERSION,contracts,customers,documents,allocations:allocs.map(a=>({id:a.id,kind:a.kind,doc:a.doc,contract:a.contract,invoice:a.invoice,amount:a.n.toString(),source:a.row})),issues,totals,flows,reconciliation,sources:kinds.flatMap(k=>w.tables[k].map((source,index)=>({kind:k,index,status:status.get(`${k}:${index}`)||'已校验（复核不改变余额）',source})))};
}
