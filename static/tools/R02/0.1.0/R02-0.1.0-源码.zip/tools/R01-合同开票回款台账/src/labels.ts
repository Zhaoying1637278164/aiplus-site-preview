export const balanceLabels:Record<string,string>={id:'业务ID',customer:'客户ID',name:'名称',contract:'合同额',invoiced:'净开票',received:'合同净回款',settled:'票净回款',advance:'预收款',unbilled:'待开票',unreceived:'合同未收款',receivable:'合同已关联票未收款',linkedReceivable:'合同已关联票未收款',unallocatedInvoiced:'未关联合同票额',revenue:'独立收入',status:'余额状态'};
export function reconciliationLabel(k:string){return k==='customer_receivable'?'客户全量有效票未收款汇总一致':k.startsWith('customer_')?'客户与合同汇总一致 · '+balanceLabels[k.slice(9)]:({invoices:'开票金额＝已分配＋未分配',receipts:'回款金额＝已分配＋未分配',receivable:'全量净票－明确票核销＝全量有效票未收款',linkedReceivable:'已关联净票－明确票核销＝合同关联票余额',unlinkedReceivable:'全量票余额＝合同关联票余额＋未关联票额'} as Record<string,string>)[k]||k}

export const customerLabels={...balanceLabels,receivable:'全量有效票未收款'};
