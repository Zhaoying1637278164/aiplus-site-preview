import type {SourceRow, Table} from '../../../packages/core/types';
import {LIMITS} from '../../../packages/core/types';
import {amount,date,text} from '../../../packages/core/value';
export const kinds=['contracts','invoices','receipts','allocations','revenue'] as const;
export type Kind=typeof kinds[number];
export const names:Record<Kind,string>={contracts:'合同台账',invoices:'开票记录',receipts:'回款记录',allocations:'关联与分配',revenue:'独立收入资料'};
export const fields:Record<Kind,string[]>={
 contracts:['ID','客户ID','客户名称','名称','日期','金额','币种','单位','口径','状态','撤销日期','依据'],
 invoices:['ID','客户ID','名称','日期','金额','币种','单位','口径','类型','原单ID','状态','撤销日期','依据'],
 receipts:['ID','客户ID','名称','日期','金额','币种','单位','口径','类型','原单ID','状态','撤销日期','依据'],
 allocations:['ID','分配类型','单据ID','合同ID','发票ID','日期','金额','依据'],
 revenue:['ID','客户ID','合同ID','日期','金额','币种','单位','口径','状态','撤销日期','依据']
};
export const required:Record<Kind,string[]>={contracts:['ID','客户ID','日期','金额','币种','单位','口径','状态'],invoices:['ID','客户ID','日期','金额','币种','单位','口径','类型','状态'],receipts:['ID','客户ID','日期','金额','币种','单位','口径','类型','状态'],allocations:['ID','分配类型','单据ID','合同ID','日期','金额','依据'],revenue:['ID','客户ID','合同ID','日期','金额','币种','单位','口径','状态','依据']};
export interface Config {start:string;cutoff:string;currency:string;unit:string;basis:'含税'|'不含税';precision:number;tolerance:string;complete:boolean}
export const defaultConfig:Config={start:'2026-09-01',cutoff:'2026-09-30',currency:'CNY',unit:'元',basis:'含税',precision:2,tolerance:'0.01',complete:false};
export interface History {at:string;action:string;kind:Kind|'config';before:unknown;after:unknown}
export interface Work {config:Config;tables:Record<Kind,SourceRow[]>;history:History[];notes:Record<string,string>}
export function emptyWork():Work{return {config:{...defaultConfig},tables:{contracts:[],invoices:[],receipts:[],allocations:[],revenue:[]},history:[],notes:{}}}
export function checkConfig(c:Config){if(Object.keys(c).sort().join(',')!==Object.keys(defaultConfig).sort().join(',')||['start','cutoff','currency','unit','basis','tolerance'].some(k=>typeof (c as any)[k]!=='string'||(c as any)[k].length>100))throw Error('配置字段或类型无效');date(c.start);date(c.cutoff);if(c.start>c.cutoff)throw Error('期间起点不能晚于截止日');text(c.currency);text(c.unit);if(!['含税','不含税'].includes(c.basis)||!Number.isInteger(c.precision)||c.precision<0||c.precision>6||amount(c.tolerance).lt(0)||typeof c.complete!=='boolean')throw Error('口径/精度/容差/完整性参数无效');}
export function checkTable(t:Table,k:Kind){if(required[k].some(f=>!t.headers.includes(f)))throw Error('缺少模板字段：'+required[k].filter(f=>!t.headers.includes(f)).join('、'));return t.rows}
export function validateRows(rows:unknown):asserts rows is SourceRow[]{if(!Array.isArray(rows)||rows.length>LIMITS.rows)throw Error('资料超过行限制');for(const r of rows){if(!r||typeof r.file!=='string'||r.file.length>500||typeof r.sheet!=='string'||r.sheet.length>100||!Number.isInteger(r.row)||r.row<1||!r.cells||typeof r.cells!=='object'||Array.isArray(r.cells)||Object.keys(r.cells).length>LIMITS.columns)throw Error('资料来源结构无效');for(const [k,v] of Object.entries(r.cells)){if(k.length>10000)throw Error('字段名超限');if(v===null)continue;if(typeof v==='string'&&v.length<=10000)continue;if(typeof v==='number'&&Number.isFinite(v))continue;if(typeof v==='object'&&v&&typeof (v as any).formula==='string'&&(v as any).formula.length<=10000&&Object.keys(v).every(x=>['formula','cached'].includes(x))&&JSON.stringify(v).length<=20000)continue;throw Error('资料单元格结构或长度无效')}}}
