import {LIMITS} from '../../../packages/core/types';
import {VERSION,RULE_VERSION} from './types';
import {initial,validateOptions,validateSession,execute,strict,clone,type Options,type Session} from './workflow';
const envelope=(contains_data:boolean)=>({schema_version:2,tool:'D03',app_version:VERSION,rule_version:RULE_VERSION,contains_data});
function bounded(raw:string){if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('恢复文件超过10MB');return raw}
function read(raw:string,data:boolean){const v=JSON.parse(bounded(raw));strict(v,['schema_version','tool','app_version','rule_version','contains_data',data?'session':'options']);if(v.schema_version!==2||v.tool!=='D03'||v.app_version!==VERSION||v.rule_version!==RULE_VERSION||v.contains_data!==data)throw Error('请使用D03 0.2.0对应文件，版本或含数据标识不一致');return v}
export function encodeWork(s:Session){validateSession(s);if(s.tables.every(Boolean))execute(s);return bounded(JSON.stringify({...envelope(true),session:s},null,2))}
export function decodeWork(raw:string):Session{const s=read(raw,true).session as Session;validateSession(s);if(s.tables.every(Boolean))execute(s);else if(s.decisions.length)throw Error('无完整资料不能恢复逐行确认');return clone(s)}
export function encodeOptions(o:Options){validateOptions(o);return bounded(JSON.stringify({...envelope(false),options:{...o,scopes:[]}},null,2))}
export function decodeOptions(raw:string):Session{const o=read(raw,false).options as Options;validateOptions(o);if(o.scopes.length)throw Error('无数据方案不能包含范围实体值');return {...initial(),options:clone(o)}}
