import type {Table,SourceRow} from '../../../packages/core/types';
export const VERSION='0.2.0',RULE_VERSION='D03-2026-10-03.2';
export const KINDS=['科目','客商','部门'] as const;
export type Kind=typeof KINDS[number];
export interface Config {kind?:string;schema_version:1;tool:'D03';code:string;name:string;scope:string;date:string;trim:boolean;ignoreCase:boolean}
export interface Mapping {kind?:Kind;id:string;by:'code'|'name';value:string;aliases:string[];target:string;scope:string;from:string;to:string;priority:number;confirmed:boolean}
export interface MappingVersion {version:string;entries:Mapping[]}
export type Status='已映射'|'待确认'|'冲突'|'未映射'|'异常';
export interface Candidate {kind?:Kind;code:string;name:string;scope:string;distance:number;source:SourceRow}
export interface Result {source:SourceRow;status:Status;target_code:string;target_name:string;rule_ids:string[];dictionary_rows:SourceRow[];suggestions:Candidate[];reason:string}
export interface Report {tool:'D03';app_version:string;rule_version:string;config:Config;mapping:MappingVersion;dictionary:Table;rows:Result[];stats:Record<Status,number>&{input:number};dictionary_errors:{source:SourceRow;reason:string}[]}
