import ExcelJS from 'exceljs';
import type {ReleaseAsset} from '../../../packages/core/release-assets';
import {example} from './work-example';
import {encodeWork} from './restore';
export async function releaseAssets():Promise<ReleaseAsset[]>{const s=example();const wb=new ExcelJS.Workbook();wb.created=new Date('2026-10-03T00:00:00Z');wb.modified=new Date('2026-10-03T00:00:00Z');for(const t of s.tables){const ws=wb.addWorksheet(t!.sheet);ws.addRow(t!.headers);for(const r of t!.rows)ws.addRow(t!.headers.map(h=>{const v=r.cells[h];return v!==null&&typeof v==='object'?{formula:v.formula,result:v.cached}:v}))}const bytes=new Uint8Array(await wb.xlsx.writeBuffer());return [{filename:'空白模板.csv',data:'\uFEFF类别,原始编码,原始名称,范围,业务日期,金额,币种,单位\r\n'},{filename:'目标字典模板.csv',data:'\uFEFF类别,目标编码,目标名称,范围\r\n'},{filename:'虚构样例.xlsx',data:bytes},{filename:'虚构完整工作.json',data:encodeWork(s)}]}
