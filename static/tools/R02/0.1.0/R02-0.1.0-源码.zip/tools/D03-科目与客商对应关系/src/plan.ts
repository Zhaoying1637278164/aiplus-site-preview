import {LIMITS} from '../../../packages/core/types';import {VERSION,RULE_VERSION,type Config,type MappingVersion} from './types';import {validateConfig,validateMapping} from './engine';
function parse(raw:string,contains_data:boolean){if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MB');const v=JSON.parse(raw);const keys=['schema_version','tool','app_version','rule_version','contains_data',contains_data?'mapping':'config'];if(!v||Object.keys(v).some(k=>!keys.includes(k))||v.schema_version!==1||v.tool!=='D03'||v.app_version!==VERSION||v.rule_version!==RULE_VERSION||v.contains_data!==contains_data)throw Error('只接受当前D03版本及明确数据标识的文件');return v}
const envelope=(contains_data:boolean)=>({schema_version:1,tool:'D03',app_version:VERSION,rule_version:RULE_VERSION,contains_data});
export function encodeConfig(config:Config){validateConfig(config);return JSON.stringify({...envelope(false),config},null,2)}
export function decodeConfig(raw:string):Config{const v=parse(raw,false);validateConfig(v.config);return structuredClone(v.config)}
export function encodeMapping(mapping:MappingVersion){validateMapping(mapping);return JSON.stringify({...envelope(true),mapping},null,2)}
export function decodeMapping(raw:string):MappingVersion{const v=parse(raw,true);validateMapping(v.mapping);return structuredClone(v.mapping)}
