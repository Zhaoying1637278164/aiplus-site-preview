# D03 第三方来源与声明

D03业务、规则、React页面及全部虚构资料自主实现。

- 方法来源：OpenRefine User Manual，https://openrefine.org/docs/manual/reconciling 、https://openrefine.org/docs/manual/cellediting ，访问2026-10-03，文档CC BY 4.0；归属OpenRefine，仅借鉴方法，没有复制代码、表达式或视觉资产。Reconciling标示2026-01-28更新，未运行上游软件。
- ExcelJS 4.4.0，https://github.com/exceljs/exceljs/tree/v4.4.0 ，MIT，Copyright (c) 2014-2019 Guyon Roche；现有锁定依赖，许可全文在references/exceljs-license与node_modules/exceljs/LICENSE。
- PapaParse 5.5.3，https://github.com/mholt/PapaParse/tree/5.5.3 ，MIT，Copyright (c) 2015 Matthew Holt；现有共享CSV读写，许可全文node_modules/papaparse/LICENSE。
- React/ReactDOM 19.1.1，https://github.com/facebook/react ，MIT，Copyright (c) Meta Platforms, Inc. and affiliates；现有锁定依赖，许可全文分别位于node_modules/react/LICENSE与node_modules/react-dom/LICENSE。

仅使用现有依赖；发布及源码包须由总控保留以上完整许可及实际打包的传递依赖声明，本文件不替代其许可全文。dedupe/OpenFPA未采用；不包含商业资产或在线服务。
