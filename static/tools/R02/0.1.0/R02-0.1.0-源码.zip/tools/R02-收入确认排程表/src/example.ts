import type {Table} from '../../../packages/core/types';
import {headers,emptyData,type Kind,type Data} from './types';
export function table(kind:Kind,values:(string|null)[][],file='虚构'+kind+'.csv'):Table{return {file,sheet:'资料',headers:headers[kind],rows:values.map((cells,i)=>({file,sheet:'资料',row:i+2,cells:Object.fromEntries(headers[kind].map((h,j)=>[h,cells[j]??null]))}))}}
export function example():Data{return {...emptyData(),
 contracts:table('contracts',[['HT-001','KH-001','虚构青禾公司','12000','12000','CNY','元'],['HT-002','KH-002','虚构远山公司','10000','10000','CNY','元']]),
 obligations:table('obligations',[['HT-001','LY-01','全年维护','12000','2026-01-01','2026-12-31','月份等额','是','时段','总额','虚构批准：均匀服务进度，财会〔2017〕22号第十二条'],['HT-002','LY-02','设备交付','10000','2026-01-01','2026-12-31','里程碑','是','时点','总额','虚构批准：分批验收控制权转移']]),
 milestones:table('milestones',[['LC-01','HT-002','LY-02','2026-06-30','4000','2026-06-28','虚构验收单YS-01'],['LC-02','HT-002','LY-02','2026-10-31','6000',null,null]]),
 actuals:table('actuals',[['SR-01','HT-001','LY-01','KH-001','2026-01-31','1000','CNY','元','虚构凭证PZ-01'],['SR-02','HT-001','LY-01','KH-001','2026-02-28','1000','CNY','元','虚构凭证PZ-02'],['SR-03','HT-002','LY-02','KH-002','2026-06-28','4000','CNY','元','虚构凭证PZ-03']]),
 changes:table('changes',[['BG-01','HT-001','LY-01','V2','2026-04-01','15000','2026-04-01','2026-12-31','0','重排','虚构批准：未履约部分新增服务，人工判断前瞻重排']])}}
