import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';
import type {SourceRow} from '../../../packages/core/types';
import {kinds,headers,labels,type Data,type Config,type Run,type Issue,type Kind,type Line} from './types';
import {VERSION,RULE_VERSION} from './version';
const D=Decimal.clone({precision:60,rounding:Decimal.ROUND_HALF_UP});
const sum=(xs:string[])=>xs.reduce((s,x)=>s.plus(x),new D(0));
const val=(r:SourceRow,h:string)=>text(r.cells[h],true);
const mon=(s:string)=>s.slice(0,7);
const day=(s:string)=>Date.parse(s+'T00:00:00Z')/86400000;
const iso=(n:number)=>new Date(n*86400000).toISOString().slice(0,10);
const endMonth=(s:string)=>{const [y,m]=s.split('-').map(Number);return new Date(Date.UTC(y,m,0)).toISOString().slice(0,10)};
const nextMonth=(s:string)=>{const [y,m]=s.split('-').map(Number);return new Date(Date.UTC(y,m,1)).toISOString().slice(0,10)};
const key=(r:SourceRow)=>JSON.stringify([val(r,'合同ID'),val(r,'履约ID')]);
interface Slice {start:string;end:string;weight:Decimal;amount:string;method:string;done:boolean;source:SourceRow[];version:string;basis:string;rate?:string;prior?:string;origin?:string}
export function validateConfig(c:Config){date(c.cutoff);if(!Number.isInteger(c.precision)||c.precision<0||c.precision>6)throw Error('金额精度须为0–6');if(amount(c.tolerance).isNegative())throw Error('容差不能为负');if(c.frozenThrough){if(!/^\d{4}-\d{2}$/.test(c.frozenThrough))throw Error('冻结期须为YYYY-MM');date(c.frozenThrough+'-01')}}
export function calculate(data:Data,c:Config):Run{
 validateConfig(c);const fmt=(x:Decimal)=>x.toFixed(c.precision);const money=(r:SourceRow,h:string)=>{const a=new D(amount(r.cells[h]).toString());if(!a.eq(a.toDecimalPlaces(c.precision)))throw Error(h+'超出所选金额精度，不得静默舍入');return a};
 const run:Run={app_version:VERSION,rule_version:RULE_VERSION,config:{...c},lines:[],summaries:[],issues:[]};
 const issue=(kind:Kind,r:SourceRow,message:string,k='',severity:Issue['severity']='阻塞')=>run.issues.push({kind,source:r,message,key:k,severity});
 const rows:Record<Kind,SourceRow[]>={contracts:[],obligations:[],milestones:[],actuals:[],changes:[]};
 for(const kind of kinds){const t=data[kind];if(!t)continue;if(headers[kind].some(h=>!t.headers.includes(h)))throw Error(labels[kind]+'缺少模板列');if(t.rows.length>20000)throw Error('资料超过20000行');rows[kind]=t.rows;}
 if(!rows.contracts.length||!rows.obligations.length)throw Error('请先提供合同和履约事项');
 const contracts=new Map<string,SourceRow>(),badContracts=new Set<string>();const contractObligations=new Map<string,SourceRow[]>();for(const r of rows.obligations)try{const id=val(r,'合同ID');contractObligations.set(id,[...(contractObligations.get(id)||[]),r])}catch{}
 for(const r of rows.contracts)try{const id=val(r,'合同ID');if(contracts.has(id)){badContracts.add(id);issue('contracts',r,'合同ID重复');issue('contracts',contracts.get(id)!,'合同ID重复');}else contracts.set(id,r);val(r,'客户ID');val(r,'客户名称');val(r,'币种');val(r,'单位');if(money(r,'合同金额').isNegative()||money(r,'收入交易价格').isNegative())throw Error('合同金额/交易价格不能为负');}catch(e){try{badContracts.add(val(r,'合同ID'))}catch{}issue('contracts',r,(e as Error).message)}
 const groups=new Map<string,SourceRow[]>();for(const r of rows.obligations)try{const k=key(r);groups.set(k,[...(groups.get(k)||[]),r]);}catch(e){issue('obligations',r,(e as Error).message)}
 // Duplicate identifiers invalidate every associated row, including the first row.
 const badAux=new Set<SourceRow>();for(const kind of ['milestones','actuals','changes'] as Kind[]){const idCol=kind==='milestones'?'里程碑ID':kind==='actuals'?'记录ID':'变更ID';const ids=new Map<string,SourceRow[]>();for(const r of rows[kind])try{const id=val(r,idCol);ids.set(id,[...(ids.get(id)||[]),r]);}catch(e){badAux.add(r);issue(kind,r,(e as Error).message)}for(const rs of ids.values())if(rs.length>1)for(const r of rs){badAux.add(r);issue(kind,r,idCol+'重复')}}
 const linked:Record<string,Map<string,SourceRow[]>>={};for(const kind of ['milestones','actuals','changes'] as Kind[]){linked[kind]=new Map();for(const r of rows[kind])try{const k=key(r);if(!groups.has(k))throw Error('合同ID/履约ID未关联');linked[kind].set(k,[...(linked[kind].get(k)||[]),r]);}catch(e){issue(kind,r,(e as Error).message);badAux.add(r)}}
 // Reconcile original allocation to the explicitly supplied income transaction price.
 for(const [id,cr] of contracts){try{const os=contractObligations.get(id)||[];if(!os.length)throw Error('合同缺少履约事项');const total=sum(os.map(r=>money(r,'分配额').toString()));if(!total.eq(money(cr,'收入交易价格')))throw Error('履约分配合计不等于收入交易价格');}catch(e){badContracts.add(id);issue('contracts',cr,(e as Error).message)}}
 const periodic=(r:SourceRow,total:Decimal,start:string,end:string,method:string,version:string,basis:string):Slice[]=>{
 date(start);date(end);if(start>end)throw Error('开始日不得晚于结束日');const slices:Slice[]=[];let cursor=start;
 while(cursor<=end){if(slices.length>=1200)throw Error('单事项超过1200个月');const last=endMonth(cursor)<end?endMonth(cursor):end;const days=day(last)-day(cursor)+1;let weight=new D(1);if(method==='按日')weight=new D(days);else if(method==='月内折算')weight=new D(days).div(day(endMonth(cursor))-day(mon(cursor)+'-01')+1);else if(method!=='月份等额')throw Error('排程方法无效');slices.push({start:cursor,end:last,weight,amount:'',method,done:true,source:[r],version,basis});if(last===end)break;cursor=nextMonth(cursor)}
 const w=slices.reduce((x,s)=>x.plus(s.weight),new D(0));let assigned=new D(0),cumulative=new D(0);slices.forEach((s,i)=>{cumulative=cumulative.plus(s.weight);const target=i===slices.length-1?total:total.mul(cumulative).div(w).toDecimalPlaces(c.precision);s.amount=fmt(target.minus(assigned));if(method==='按日'){s.rate=total.div(w).toString();s.prior=assigned.toString();s.origin=start}assigned=target});return slices;
 };
 for(const [k,os] of groups){const r=os[0];const before=run.issues.length;try{
 if(os.length!==1){for(const x of os)issue('obligations',x,'合同与履约ID组合重复',k);continue}const cid=val(r,'合同ID'),cr=contracts.get(cid);if(!cr||badContracts.has(cid))throw Error('合同缺失或合同分配勾稽阻塞');
 const base=money(r,'分配额');if(base.isNegative())throw Error('基础分配额不能为负');const method=val(r,'排程方法'),basis=val(r,'判断依据');if(val(r,'适用中国收入准则')!=='是')throw Error('须确认中国收入准则适用性');const type=val(r,'确认类型');if(!['时段','时点'].includes(type)||!['总额','净额'].includes(val(r,'总额净额')))throw Error('须提供确认类型/总额净额专业判断');if(type==='时点'&&method!=='里程碑')throw Error('时点履约须使用里程碑');
 const start=date(r.cells['开始日']),end=date(r.cells['结束日']);if(start>end)throw Error('履约开始晚于结束');
 const ars=linked.actuals.get(k)||[],mrs=linked.milestones.get(k)||[],changes=linked.changes.get(k)||[];
 for(const [kind,rs] of [['actuals',ars],['milestones',mrs],['changes',changes]] as [Kind,SourceRow[]][]){if(rs.some(x=>badAux.has(x)))throw Error('关联'+labels[kind]+'存在重复/无效记录，阻塞本事项');}
 const actuals=ars.map(a=>{try{if(val(a,'币种')!==val(cr,'币种')||val(a,'单位')!==val(cr,'单位')||val(a,'客户ID')!==val(cr,'客户ID'))throw Error('实际客户/币种/单位不一致');val(a,'凭证依据');const d=date(a.cells['记账日期']);const amt=money(a,'金额');return {r:a,date:d,amount:amt}}catch(e){issue('actuals',a,(e as Error).message,k);throw e}});
 let slices:Slice[]=[];if(method==='里程碑'){
 if(!mrs.length)throw Error('里程碑缺失');let mt=new D(0);for(const m of mrs)try{const due=date(m.cells['计划日期']),a=money(m,'金额');if(a.isNegative())throw Error('里程碑金额不能为负');if(due<start||due>end)throw Error('里程碑计划日期不在履约期');const done=m.cells['完成日']!==null&&String(m.cells['完成日']).trim()!=='';const d=done?date(m.cells['完成日']):due;if(done)val(m,'验收依据');if(done&&(d<start||d>end))throw Error('完成日不在履约期，须调整期间');mt=mt.plus(a);slices.push({start:d,end:d,weight:new D(1),amount:fmt(a),method,done,source:[r,m],version:'原始',basis:done?val(m,'验收依据'):basis})}catch(e){issue('milestones',m,(e as Error).message,k);throw e}if(!mt.eq(base))throw Error('里程碑金额合计不等于分配额');
 }else{if(mrs.length)throw Error('非里程碑事项不能夹带里程碑');slices=periodic(r,base,start,end,method,'原始',basis)}
 const original=slices.map(s=>({...s}));let allocation=base;let prev='';const versionIds=new Set<string>();
 for(const ch of [...changes].sort((a,b)=>String(a.cells['生效日']).localeCompare(String(b.cells['生效日']))))try{
 if(method==='里程碑')throw Error('里程碑变更须独立重建批准事项，首版阻塞直接重排');const eff=date(ch.cells['生效日']),em=mon(eff);if(!eff.endsWith('-01'))throw Error('变更仅支持月份首日生效；月中需人工批准拆分');if(eff<start||eff>end||em<=prev||(c.frozenThrough&&em<=c.frozenThrough))throw Error('变更期间越界、重复、倒序或已冻结');if(actuals.some(a=>mon(a.date)>=em))throw Error('生效期及以后有已确认收入，须先核对并从未确认月份变更');const v=val(ch,'版本');if(versionIds.has(v))throw Error('变更版本重复');versionIds.add(v);const cb=val(ch,'批准依据'),a=money(ch,'新分配额'),adj=money(ch,'当期调整');if(a.isNegative())throw Error('新分配额不能为负');const mode=val(ch,'处理方式');if(!['重排','终止'].includes(mode))throw Error('处理方式须为重排或终止');const past=slices.filter(s=>mon(s.end)<em);const remaining=a.minus(sum(past.map(s=>s.amount))).minus(adj);if(remaining.isNegative())throw Error('新额不足历史加调整，请用户批准当期冲回');slices=past;if(!adj.isZero())slices.push({start:eff,end:eff,weight:new D(1),amount:fmt(adj),method:'当期调整',done:true,source:[r,ch],version:v,basis:cb});
 if(mode==='终止'){if(!remaining.isZero())throw Error('终止新额须等于历史计划加当期调整');}else{const ns=date(ch.cells['未来开始日']),ne=date(ch.cells['未来结束日']);if(ns<eff)throw Error('未来开始不能早于生效日');slices.push(...periodic(ch,remaining,ns,ne,method,v,cb).map(s=>({...s,source:[r,ch]})))}allocation=a;prev=em;
 }catch(e){issue('changes',ch,(e as Error).message,k);throw e}
 const plan=sum(slices.map(s=>s.amount));if(!plan.eq(allocation))throw Error('有效计划不守恒');
 const periods=[...new Set([...slices.map(s=>mon(s.end)),...original.map(s=>mon(s.end)),...actuals.map(a=>mon(a.date))])].sort();const own:Line[]=[];
 for(const period of periods){const ss=slices.filter(s=>mon(s.end)===period);let due=new D(0);for(const s of ss){if(!s.done||s.start>c.cutoff)continue;if(s.method==='按日'&&s.end>c.cutoff)due=due.plus(new D(s.rate!).mul(day(c.cutoff)-day(s.origin!)+1).toDecimalPlaces(c.precision).minus(s.prior!));else if((s.method==='月份等额'||s.method==='月内折算')&&endMonth(s.end)>c.cutoff)continue;else if(s.end<=c.cutoff)due=due.plus(s.amount)}const act=sum(actuals.filter(a=>mon(a.date)===period&&a.date<=c.cutoff).map(a=>a.amount.toString())),p=sum(ss.map(s=>s.amount));
 own.push({key:k,contract:cid,customer:val(cr,'客户ID'),name:val(r,'履约事项'),currency:val(cr,'币种'),unit:val(cr,'单位'),period,start:ss[0]?.start||period+'-01',end:ss.at(-1)?.end||endMonth(period+'-01'),method,original:fmt(sum(original.filter(s=>mon(s.end)===period).map(s=>s.amount))),plan:fmt(p),due:fmt(due),actual:fmt(act),difference:fmt(due.minus(act)),version:[...new Set(ss.map(s=>s.version))].join(' / ')||'历史',basis:([...new Set(ss.map(s=>s.basis))].join(' / ')||basis).slice(0,2000)+((ss.map(s=>s.basis).join(' / ').length>2000)?'（完整依据见原行）':''),sources:[cr,r,...ss.flatMap(s=>s.source),...actuals.filter(a=>mon(a.date)===period).map(a=>a.r)]});}
 if(run.lines.length+own.length>20000)throw Error('输出超过20000行，请缩小输入');const actual=sum(actuals.filter(a=>a.date<=c.cutoff).map(a=>a.amount.toString())),due=sum(own.map(l=>l.due));
 run.lines.push(...own);run.summaries.push({key:k,contract:cid,customer:val(cr,'客户ID'),name:val(r,'履约事项'),currency:val(cr,'币种'),unit:val(cr,'单位'),allocation:fmt(allocation),plan:fmt(plan),due:fmt(due),actual:fmt(actual),pending:fmt(due.minus(actual)),remaining:fmt(allocation.minus(actual)),unfulfilled:fmt(sum(slices.filter(s=>s.method==='里程碑'&&(!s.done||s.end>c.cutoff)).map(s=>s.amount))),sources:[cr,r,...mrs,...ars,...changes]});
 if(due.minus(actual).abs().gt(c.tolerance))issue('actuals',r,'截至日计划与实际差异超过容差，需复核',k,'提示');if(actuals.some(a=>a.date>c.cutoff))issue('actuals',r,'含截止日后实际记录；未计截至日累计，原行仍保留',k,'提示');
 }catch(e){if(run.issues.length===before||!run.issues.slice(before).some(i=>i.severity==='阻塞'))issue('obligations',r,(e as Error).message,k)}}
 return run;
}
