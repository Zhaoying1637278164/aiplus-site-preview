import {calculate} from './engine';
import type {Data,Config} from './types';
/** Preserve established frozen schedules when replacing/editing source, as well as through changes. */
export function protectFrozen(data:Data,next:Data,config:Config){
 if(!config.frozenThrough||!data.contracts||!data.obligations||!next.contracts||!next.obligations)return;
 const old=calculate(data,config),current=calculate(next,config);
 for(const prior of old.lines.filter(l=>l.period<=config.frozenThrough)){
 const now=current.lines.find(l=>l.key===prior.key&&l.period===prior.period);
 if(!now||now.currency!==prior.currency||now.unit!==prior.unit||now.plan!==prior.plan)throw Error('已冻结计划不得被替换或修改：'+prior.contract+' / '+prior.name+' / '+prior.period+'。请保留已确认历史，通过未冻结期间的批准变更处理。');
 }
}
