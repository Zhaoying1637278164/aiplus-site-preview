import type {Table,SourceRow} from '../../../packages/core/types';
export type Kind='contracts'|'obligations'|'milestones'|'actuals'|'changes';
export const kinds:Kind[]=['contracts','obligations','milestones','actuals','changes'];
export const labels:Record<Kind,string>={contracts:'合同',obligations:'履约事项',milestones:'里程碑',actuals:'已确认收入',changes:'变更与调整'};
export const headers:Record<Kind,string[]>={
 contracts:['合同ID','客户ID','客户名称','合同金额','收入交易价格','币种','单位'],
 obligations:['合同ID','履约ID','履约事项','分配额','开始日','结束日','排程方法','适用中国收入准则','确认类型','总额净额','判断依据'],
 milestones:['里程碑ID','合同ID','履约ID','计划日期','金额','完成日','验收依据'],
 actuals:['记录ID','合同ID','履约ID','客户ID','记账日期','金额','币种','单位','凭证依据'],
 changes:['变更ID','合同ID','履约ID','版本','生效日','新分配额','未来开始日','未来结束日','当期调整','处理方式','批准依据']};
export interface Config {cutoff:string;precision:number;tolerance:string;frozenThrough:string}
export type Data=Record<Kind,Table|null>;
export interface Snapshot {id:string;label:string;data:Data;config:Config}
export interface Session {schema_version:1;tool:'R02';app_version:string;rule_version:string;includes_data:boolean;data:Data;config:Config;versions:Snapshot[]}
export interface Issue {severity:'阻塞'|'提示';kind:Kind;message:string;source:SourceRow;key:string}
export interface Line {key:string;contract:string;customer:string;name:string;currency:string;unit:string;period:string;start:string;end:string;method:string;original:string;plan:string;due:string;actual:string;difference:string;version:string;basis:string;sources:SourceRow[]}
export interface Summary {key:string;contract:string;customer:string;name:string;currency:string;unit:string;allocation:string;plan:string;due:string;actual:string;pending:string;remaining:string;unfulfilled:string;sources:SourceRow[]}
export interface Run {app_version:string;rule_version:string;config:Config;lines:Line[];summaries:Summary[];issues:Issue[]}
export const emptyData=():Data=>({contracts:null,obligations:null,milestones:null,actuals:null,changes:null});
export const defaultConfig:Config={cutoff:'2026-09-30',precision:2,tolerance:'0.01',frozenThrough:''};
