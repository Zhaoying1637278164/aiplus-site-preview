import type {Table,Cell} from '../../../packages/core/types';
import {LIMITS} from '../../../packages/core/types';
import {kinds,headers,emptyData,type Data,type Config,type Session,type Snapshot} from './types';
import {VERSION,RULE_VERSION} from './version';
import {validateConfig} from './engine';
function checkData(x:unknown):Data{
 if(!x||typeof x!=='object'||Array.isArray(x))throw Error('资料结构无效');const out=emptyData();
 for(const k of kinds){const t=(x as Data)[k];if(t===null)continue;if(!t||typeof t.file!=='string'||typeof t.sheet!=='string'||!Array.isArray(t.headers)||t.headers.length>LIMITS.columns||!t.headers.every(h=>typeof h==='string')||new Set(t.headers).size!==t.headers.length||headers[k].some(h=>!t.headers.includes(h))||!Array.isArray(t.rows)||t.rows.length>LIMITS.rows)throw Error(k+'资料结构/上限无效');
 for(const r of t.rows){if(!r||typeof r.file!=='string'||typeof r.sheet!=='string'||!Number.isInteger(r.row)||r.row<1||!r.cells||typeof r.cells!=='object'||Array.isArray(r.cells)||Object.keys(r.cells).length>LIMITS.columns)throw Error('来源行无效');for(const v of Object.values(r.cells)){if(v!==null&&typeof v!=='string'&&typeof v!=='number'){if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).sort().join(',')!=='cached,formula'||typeof v.formula!=='string'||v.formula.length>10000)throw Error('来源对象无效；不接受任意代码对象');const cached=v.cached;if(cached!==null&&typeof cached!=='string'&&typeof cached!=='number'&&typeof cached!=='boolean'&&!(cached&&typeof cached==='object'&&!Array.isArray(cached)&&Object.keys(cached).join(',')==='error'&&typeof (cached as {error:unknown}).error==='string'&&(cached as {error:string}).error.length<=10000))throw Error('公式缓存元数据无效');if(typeof cached==='number'&&!Number.isFinite(cached)||typeof cached==='string'&&cached.length>10000)throw Error('公式缓存元数据超限');}if(typeof v==='string'&&v.length>10000||typeof v==='number'&&!Number.isFinite(v))throw Error('单元格无效/超限')}}out[k]=t;
 }return out;
}
function checkConfig(c:unknown):Config{if(!c||typeof c!=='object')throw Error('参数无效');const x=c as Config;if(typeof x.cutoff!=='string'||typeof x.tolerance!=='string'||typeof x.frozenThrough!=='string')throw Error('参数类型无效');validateConfig(x);return {cutoff:x.cutoff,precision:x.precision,tolerance:x.tolerance,frozenThrough:x.frozenThrough}}
export function makeSession(data:Data,config:Config,versions:Snapshot[],include=true):Session{return {schema_version:1,tool:'R02',app_version:VERSION,rule_version:RULE_VERSION,includes_data:include,data:include?data:emptyData(),config,versions:include?versions:[]}}
export function encode(s:Session){const text=JSON.stringify(s,null,2);decode(text);return text}
export function decode(text:string):Session{
 if(new TextEncoder().encode(text).length>LIMITS.bytes)throw Error('工作文件超过10MB');const x=JSON.parse(text);if(x.schema_version!==1||x.tool!=='R02'||x.app_version!==VERSION||x.rule_version!==RULE_VERSION||typeof x.includes_data!=='boolean'||!Array.isArray(x.versions)||x.versions.length>20)throw Error('工作版本/格式不兼容');const data=checkData(x.data),config=checkConfig(x.config);const ids=new Set<string>();const versions:Snapshot[]=x.versions.map((v:Snapshot)=>{if(!v||typeof v.id!=='string'||!v.id||ids.has(v.id)||typeof v.label!=='string'||v.label.length>100)throw Error('版本记录无效');ids.add(v.id);return {id:v.id,label:v.label,data:checkData(v.data),config:checkConfig(v.config)}});if(!x.includes_data&&(kinds.some(k=>data[k]!==null)||versions.length))throw Error('无数据方案不得携带资料/版本');return {...makeSession(data,config,versions,x.includes_data)};
}
export function cleanForSave(data:Data):Data{ // Validate inert source metadata; formulas and cached values are never evaluated or used as financial inputs.
 return checkData(data);
}
