export const VERSION='0.1.0';
export const RULE_VERSION='R02-CN-2026-10-03.1';
