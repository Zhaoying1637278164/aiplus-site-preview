import {workbookBytes} from '../../../packages/core/io';
import {LIMITS} from '../../../packages/core/types';
import {kinds,labels,type Data,type Run,type Snapshot} from './types';
export async function exportWorkbook(run:Run,data:Data,versions:Snapshot[]){
 const sheets=[
 {name:'参数与版本',headers:['项目','值'],rows:[['应用版本',run.app_version],['规则版本',run.rule_version],...Object.entries(run.config),['舍入口径','累计份额四舍五入，逐期取差额，末期累计等于总额'],['口径','用户已批准专业判断；精度与容差独立；原行完整保留']]},
 {name:'事项汇总',headers:['合同ID','客户ID','履约事项','币种','单位','有效分配额','计划合计','截至日计划','已确认','待确认差额','剩余','截至日未完成里程碑'],rows:run.summaries.map(s=>[s.contract,s.customer,s.name,s.currency,s.unit,s.allocation,s.plan,s.due,s.actual,s.pending,s.remaining,s.unfulfilled])},
 {name:'月度排程',headers:['合同ID','客户ID','事项','月份','币种','单位','原计划','有效计划','截至日计划','已确认','差额','版本','依据','原行索引'],rows:run.lines.map((l,i)=>[l.contract,l.customer,l.name,l.period,l.currency,l.unit,l.original,l.plan,l.due,l.actual,l.difference,l.version,l.basis,'排程来源表：第'+(i+1)+'条排程'])},
 {name:'排程来源',headers:['排程序号','合同ID','月份','来源文件','页签','原行'],rows:run.lines.flatMap((l,i)=>l.sources.filter((s,j,rs)=>rs.findIndex(x=>x.file===s.file&&x.sheet===s.sheet&&x.row===s.row)===j).map(s=>[i+1,l.contract,l.period,s.file,s.sheet,s.row]))},
 {name:'待处理异常',headers:['级别','资料','信息','来源文件','页签','原行'],rows:run.issues.map(i=>[i.severity,labels[i.kind],i.message,i.source.file,i.source.sheet,i.source.row])},
 ...kinds.filter(k=>data[k]).map(k=>({name:labels[k]+'原始资料',headers:['来源文件','来源页签','原行',...data[k]!.headers],rows:data[k]!.rows.map(r=>[r.file,r.sheet,r.row,...data[k]!.headers.map(h=>r.cells[h])])})),
 {name:'保存版本',headers:['版本ID','说明','参数'],rows:versions.map(v=>[v.id,v.label,v.config])},
 {name:'版本原始资料',headers:['版本ID','资料','来源文件','页签','原行','字段','值'],rows:versions.flatMap(v=>kinds.flatMap(k=>(v.data[k]?.rows||[]).flatMap(r=>Object.entries(r.cells).map(([h,value])=>[v.id,labels[k],r.file,r.sheet,r.row,h,value]))))}
 ];
 if(sheets.reduce((n,s)=>n+s.rows.length*s.headers.length,0)>1000000)throw Error('完整底稿超过100万单元格，请先下载完整工作并减少保留版本后导出');
 const split=sheets.flatMap(s=>{if(s.rows.length<=LIMITS.rows)return [s];const chunks=[];for(let i=0;i<s.rows.length;i+=LIMITS.rows)chunks.push({...s,name:s.name+'-'+(i/LIMITS.rows+1),rows:s.rows.slice(i,i+LIMITS.rows)});return chunks});
 const bytes=await workbookBytes(split);if(bytes.length>LIMITS.bytes)throw Error('完整底稿超过10MB，请下载完整工作或减少保留版本后重试');return bytes;
}
