import ExcelJS from 'exceljs';
import type {ReleaseAsset} from '../../../packages/core/release-assets';
import {kinds,headers,labels} from './types';
import {example} from './example';
export async function releaseAssets():Promise<ReleaseAsset[]>{const wb=new ExcelJS.Workbook();wb.created=new Date('2026-10-03T00:00:00Z');wb.modified=wb.created;const data=example();for(const k of kinds){const ws=wb.addWorksheet(labels[k]);ws.addRow(headers[k]);for(const r of data[k]!.rows)ws.addRow(headers[k].map(h=>r.cells[h]));ws.getRow(1).font={bold:true}}return [{filename:'空白模板.csv',data:'\uFEFF'+headers.contracts.join(',')+'\r\n'},{filename:'虚构样例.xlsx',data:new Uint8Array(await wb.xlsx.writeBuffer())},...kinds.filter(k=>k!=='contracts').map(k=>({filename:labels[k]+'模板.csv',data:'\uFEFF'+headers[k].join(',')+'\r\n'}))]}
