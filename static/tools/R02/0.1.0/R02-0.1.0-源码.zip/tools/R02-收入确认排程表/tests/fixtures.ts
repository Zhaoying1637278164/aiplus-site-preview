import {mkdir,writeFile} from 'node:fs/promises';import {headers,defaultConfig,emptyData} from '../src/types';import {table} from '../src/example';import {makeSession,encode} from '../src/session';
const out='progress/evidence/R02/fixtures';await mkdir(out,{recursive:true});
const csv=(rows:(string|null)[][])=>'\uFEFF'+rows.map(r=>r.map(x=>'"'+(x??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
await writeFile(out+'/31笔虚构收入.csv',csv([headers.actuals,...Array.from({length:31},(_,i)=>['LONG-'+String(i+1).padStart(3,'0'),'HT-001','LY-01','KH-001','2026-01-31','10','CNY','元','虚构分页凭证-'+(i+1)])]));
for(const [name,amount,end,cutoff] of [['小金额两分','0.02','2026-03-31','2026-03-23'],['小金额四分','0.04','2026-06-30','2026-06-30']]){const data={...emptyData(),contracts:table('contracts',[['SMALL','K','虚构小金额客户',amount,amount,'CNY','元']]),obligations:table('obligations',[['SMALL','O','小金额按日服务',amount,'2026-01-01',end,'按日','是','时段','总额','虚构批准均匀按日履约']])};await writeFile(out+'/'+name+'.json',encode(makeSession(data,{...defaultConfig,cutoff},[])))}
// Independent manual oracle, does not import the financial engine.
await writeFile(out+'/人工预期.json',JSON.stringify({long:{records:31,actual:'310.00',pending:'10690.00'},small02:{monthly:['0.01','0.00','0.01'],due:'0.02'},small04:{monthly:['0.01','0.00','0.01','0.01','0.00','0.01'],due:'0.04'}},null,2));
