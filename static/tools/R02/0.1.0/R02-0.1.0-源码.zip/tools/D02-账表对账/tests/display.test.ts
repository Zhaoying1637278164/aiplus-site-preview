import {test} from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import {keyLabel, categoryLabel, localTime} from '../src/display';
import {execute, identity, review} from '../src/workflow';
import {exportWork} from '../src/work-export';
import {monthLeft, monthRight, monthConfig} from '../examples/month-end';
test('关联显示保留前导零及复合值，异常结构不作为关联值',()=>{
 assert.equal(keyLabel('["002"]'),'002'); assert.equal(keyLabel('["主体甲","0002"]'),'主体甲 / 0002');
 for(const s of ['oops','[2]','[]','{"key":"002"}','[""]']) assert.equal(keyLabel(s),'关联值无效');
 assert.equal(keyLabel('["<script>文字</script>"]'),'<script>文字</script>');
});
test('财务分类显示与内部分类保持分离',()=>{
 assert.deepEqual(['匹配一致','字段差异','仅左侧','仅右侧','重复/歧义','无效输入'].map(categoryLabel),['核对一致','内容差异','仅第一方有','仅第二方有','对应不唯一','资料无效']);
 assert.equal(categoryLabel('toString'),'未知分类');
});
test('时间使用本机时区格式且原标识不改写',()=>{
 const raw='2026-10-03T09:56:17.482Z'; assert.equal(localTime(raw,'Asia/Shanghai'),'2026-10-03 17:56:17');
 assert.equal(localTime(raw,'UTC'),'2026-10-03 09:56:17'); assert.equal(localTime('未知'),'时间未记录');
});
test('真实XLSX回读：业务列易读，原关联键/分类/历史时间完整保留',async()=>{
 let run=execute(structuredClone([monthLeft,monthRight]),structuredClone(monthConfig),'2026-10-03T09:56:17.482Z');
 const o=run.result.outcomes.find(o=>o.key==='["B"]')!;
 run=review(run,identity(o),{to:'追查中',reason:'虚构检查',note:'虚构说明',cause:'虚构差异',evidence:'虚构凭据',person:'虚构人员',at:'2026-10-03T10:00:00.000Z'});
 const book=new ExcelJS.Workbook(); await book.xlsx.load(await exportWork(run,'虚构事项') as unknown as Parameters<typeof book.xlsx.load>[0]);
 const sheet=book.getWorksheet('全量核对明细')!;
 const row=sheet.getRows(2,sheet.rowCount-1)!.find(r=>r.getCell(1).value==='B')!;
 assert.equal(row.getCell(2).value,'内容差异'); assert.equal(row.getCell(17).value,'["B"]'); assert.equal(row.getCell(18).value,'字段差异');
 const history=book.getWorksheet('复核历史')!.getRow(2); assert.equal(history.getCell(1).value,'B'); assert.equal(history.getCell(10).value,identity(o)); assert.equal(history.getCell(11).value,'2026-10-03T10:00:00.000Z');
 assert.equal(run.result.outcomes.find(x=>x.key==='["B"]')!.category,'字段差异');
});
