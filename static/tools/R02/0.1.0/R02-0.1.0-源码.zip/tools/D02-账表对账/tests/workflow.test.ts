import { test } from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import { execute, identity, review, completion, invalidate, search, diagnostics, select, type Session } from '../src/workflow';
import { encodeWork, decodeWork, encodeConfig, decodeConfig } from '../src/restore';
import { exportWork } from '../src/work-export';
import { monthLeft as l, monthRight as r, monthConfig as c } from '../examples/month-end';
import { defaultRule } from '../src/engine';
import { VERSION, RULE_VERSION } from '../src/version';
const run = () => execute(structuredClone([l, r]), structuredClone(c), '独立预期运行');
const session = (): Session => ({ title: '虚构9月对账', tables: structuredClone([l, r]), config: structuredClone(c), run: run(), previous: null, revision: 0 });
const event = (to: '追查中' | '已说明待复核' | '复核通过') => ({ to, reason: '虚构检查依据', note: '虚构差异说明', cause: '录入差异', evidence: '虚构凭证A', person: '虚构人员', at: '2026-10-03T01:00:00.000Z' });
test('人工预期：六类组数4/1/1/1/0/0，覆盖6/6，独立版本', () => { const x = run(); assert.deepEqual(Object.values(x.result.counts).map(x => x.groups), [4, 1, 1, 1, 0, 0]); assert.deepEqual(x.included, [6, 6]); assert.equal(x.result.app_version, VERSION); assert.equal(x.result.rule_version, RULE_VERSION); });
test('CNY主金额与辅助金额分别勾稽；容差内差额不置零；USD不混币', () => { const x = run(); assert.deepEqual(x.sums.find(s => s.currency === 'CNY' && s.field === '金额 ↔ 金额'), { currency: 'CNY', field: '金额 ↔ 金额', paired: 4, left: '250', right: '260.01', difference: '-10.01', withinTolerance: '-0.01', different: '-10', singleLeft: '0', singleRight: '0', uncomparableLeft: 0, uncomparableRight: 0 }); const a = x.sums.find(s => s.currency === 'CNY' && s.field === '辅助金额 ↔ 辅助金额')!; assert.deepEqual([a.left, a.right, a.difference], ['9', '11', '-2']); const u = x.sums.find(s => s.currency === 'USD' && s.field === '金额 ↔ 金额')!; assert.deepEqual([u.left, u.right, u.difference, u.singleLeft, u.singleRight], ['10', '10', '0', '20', '30']); });
test('范围排除完整原行与理由，两方输入=纳入+排除', () => { const config = structuredClone(c); config.scope.filters = [0, 1].map(side => ({ side: side as 0 | 1, field: '币种', kind: 'values', values: ['CNY'], from: '', to: '' })); const x = execute([l, r], config, '范围'); assert.deepEqual(x.input, [6, 6]); assert.deepEqual(x.included, [4, 4]); assert.deepEqual(x.excluded.map(e => e.source.cells.单据号), ['E', 'F', 'E', 'G']); assert.equal(x.excluded[0].source.row, 6); assert.match(x.excluded[0].reasons[0], /币种未选择/); });
test('范围无效空/公式不静默排除；日期边界纳入', () => {
    const tables = structuredClone([l, r]) as [
        typeof l,
        typeof r
    ];
    tables[0].rows[0].cells.日期 = null;
    assert.throws(() => select(tables, [{ side: 0, field: '日期', kind: 'date', values: [], from: '2026-09-30', to: '2026-09-30' }]), /范围字段/);
    assert.equal(select([l, r], [{ side: 0, field: '日期', kind: 'date', values: [], from: '2026-09-30', to: '2026-09-30' }]).selected[0].rows.length, 6);
});
test('空范围、空条件、未确认、异期间未解释及重复映射阻断', () => {
    for (const mutate of [(v: typeof c) => v.scope.confirmed = false, (v: typeof c) => v.scope.periods[1] = '2026-08', (v: typeof c) => v.rule.fields.push(v.rule.fields[0]), (v: typeof c) => v.scope.filters.push({ side: 0, field: '币种', kind: 'values', values: [], from: '', to: '' }), (v: typeof c) => v.scope.entity = '']) {
        const v = structuredClone(c);
        mutate(v);
        assert.throws(() => execute([l, r], v, 'x'));
    }
    const v = structuredClone(c);
    v.scope.periods[1] = '2026-08';
    v.scope.crossPeriod = true;
    v.scope.purpose = '虚构跨期追查';
    assert.equal(execute([l, r], v, 'x').included[0], 6);
});
test('无效B保留双方，不入金额配对', () => {
    const tables = structuredClone([l, r]) as [
        typeof l,
        typeof r
    ];
    tables[0].rows[1].cells.金额 = null;
    const x = execute(tables, c, 'x');
    const a = x.sums.find(s => s.currency === 'CNY' && s.field === '金额 ↔ 金额')!;
    assert.deepEqual([a.paired, a.left, a.right, a.difference, a.uncomparableLeft, a.uncomparableRight], [3, '50', '50.01', '-0.01', 1, 1]);
    assert.equal(x.result.counts['无效输入'].groups, 1);
});
test('复核不得跳步，完整历史不改变差额/类别，撤销需要依据', () => {
    let x = run();
    const key = identity(x.result.outcomes[1]);
    assert.throws(() => review(x, key, event('复核通过')), /跳步/);
    for (const to of ['追查中', '已说明待复核', '复核通过'] as const)
        x = review(x, key, event(to));
    assert.equal(x.reviews[key].events.length, 3);
    assert.equal(x.result.outcomes[1].category, '字段差异');
    assert.equal(x.result.outcomes[1].details[0].difference, '-10');
    assert.throws(() => review(x, key, { ...event('追查中'), reason: '' }), /必填/);
    x = review(x, key, event('追查中'));
    assert.equal(x.reviews[key].events[3].from, '复核通过');
});
test('资料/口径变化使结果和复核失效，保留过期摘要', () => { const s = session(); const n = invalidate(s); assert.equal(n.run, null); assert.equal(n.previous?.id, s.run?.id); assert.equal(n.config.scope.confirmed, false); assert.equal(n.revision, 1); });
test('全量搜索超过旧100组边界，返回源行，不受分页截断', () => { const left = structuredClone(l), right = structuredClone(r); left.rows = Array.from({ length: 150 }, (_, i) => ({ ...l.rows[0], row: i + 2, cells: { ...l.rows[0].cells, 单据号: 'X' + i } })); right.rows = left.rows.map(x => ({ ...x, file: r.file })); const x = execute([left, right], c, 'all'); assert.equal(search(x, '', '全部', '全部').length, 150); assert.equal(search(x, 'X149', '全部', '全部').length, 1); });
test('规范化碰撞诊断保留原始关联键', () => { const t = structuredClone(l); t.rows[1].cells.单据号 = ' A '; assert.deepEqual(diagnostics(t, { ...defaultRule, trim: true }, 'left'), { duplicateGroups: 1, invalid: 0, collisions: 1 }); });
test('当前无数据方案没有实际来源、事项、期间和人员；旧方案明确迁移', () => { const raw = encodeConfig(c); assert(!raw.includes('青禾')); assert(!raw.includes('2026-09')); assert(!raw.includes('虚构财务')); const restored = decodeConfig(raw); assert.equal(restored.legacy, false); assert.equal(restored.config.scope.confirmed, false); assert.equal(decodeConfig(JSON.stringify({ schema_version: 1, tool: 'D02', contains_data: false, app_version: '0.1.0', rule_version: 'D02-2026-10-03.1', rule: defaultRule })).legacy, true); });
test('含数据工作底稿重算恢复及复核事件回放', () => {
    const s = session();
    const key = identity(s.run!.result.outcomes[1]);
    for (const to of ['追查中', '已说明待复核', '复核通过'] as const)
        s.run = review(s.run!, key, event(to));
    assert.deepEqual(decodeWork(encodeWork(s)), s);
});
test('篡改结果、覆盖、复核末态、来源行、未知字段/版本拒绝', () => {
    for (const mutate of [(v: any) => v.run.result.outcomes[1].details[0].difference = '0', (v: any) => v.run.included[0] = 0, (v: any) => v.tables[0].rows[1].row = v.tables[0].rows[0].row, (v: any) => v.schema_version = 3, (v: any) => v.tables[0].rows[0].cells.code = 'eval', (v: any) => v.run.reviews['unknown'] = { status: '复核通过', events: [] }]) {
        const v = JSON.parse(encodeWork(session()));
        mutate(v);
        assert.throws(() => decodeWork(JSON.stringify(v)));
    }
    const s = session();
    const key = identity(s.run!.result.outcomes[1]);
    s.run = review(s.run!, key, event('追查中'));
    const v = JSON.parse(encodeWork(s));
    v.run.reviews[key].status = '复核通过';
    assert.throws(() => decodeWork(JSON.stringify(v)), /末态/);
});
test('工作恢复保存公式为诊断而不执行，重算同组无效', () => {
    const s = session();
    s.tables[0]!.rows[0].cells.金额 = { formula: 'WEBSERVICE("https://example.com")', cached: 100 };
    s.run = execute(s.tables as [
        typeof l,
        typeof r
    ], c, 'formula');
    assert.equal(decodeWork(encodeWork(s)).run!.result.counts['无效输入'].groups, 1);
});
test('净额零存在待处理不得完成，全部复核不改变金额', () => {
    let x = run();
    assert.equal(completion(x).pending, 3);
    for (const o of x.result.outcomes.filter(o => o.category !== '匹配一致')) {
        for (const to of ['追查中', '已说明待复核', '复核通过'] as const)
            x = review(x, identity(o), event(to));
    }
    assert.equal(completion(x).label, '本次核对已复核');
});
test('XLSX业务字段、行数勾稽、金额与复核历史真实回读', async () => { let x = run(); x = review(x, identity(x.result.outcomes[1]), event('追查中')); const bytes = await exportWork(x, '虚构9月'); const wb = new ExcelJS.Workbook(); await wb.xlsx.load(bytes as any); assert.equal(wb.getWorksheet('行数勾稽')!.getCell('B2').value, '6'); assert.equal(wb.getWorksheet('金额勾稽')!.getCell('F2').value, '-10.01'); assert.equal(wb.getWorksheet('复核历史')!.rowCount, 2); const detail = wb.getWorksheet('全量核对明细')!; assert.equal(detail.getCell('H1').value, '第一方原值'); assert.equal(wb.worksheets.length, 9); });
test('恢复体积、列数及事件上限检查', () => { assert.throws(() => decodeWork(' '.repeat(10 * 1024 * 1024 + 1)), /超过10MB/); const v = JSON.parse(encodeWork(session())); v.tables[0].headers = Array.from({ length: 201 }, (_, i) => String(i)); assert.throws(() => decodeWork(JSON.stringify(v)), /限制/); });
test('来源金额独立守恒：USD输入30/40=配对10+单侧20/30，排除追溯', () => { const x = run(); const a = x.sourceSums.filter(s => s.currency === 'USD' && s.field === '金额 ↔ 金额'); assert.deepEqual(a.map(s => [s.input, s.included, s.paired, s.single, s.uncomparable]), [['30', '30', '10', '20', '0'], ['40', '40', '10', '30', '0']]); const config = structuredClone(c); config.scope.filters = [{ side: 0, field: '币种', kind: 'values', values: ['CNY'], from: '', to: '' }]; const scoped = execute([l, r], config, 'source'); const u = scoped.sourceSums.find(s => s.side === 0 && s.currency === 'USD' && s.field === '金额 ↔ 金额')!; assert.deepEqual([u.input, u.included, u.excluded], ['30', '0', '30']); });
test('24位金额异号多行汇总仍准确；无效币种金额不可汇总', () => {
    const a = structuredClone(l), b = structuredClone(r);
    a.rows = a.rows.slice(0, 2);
    b.rows = b.rows.slice(0, 2);
    for (const x of a.rows)
        x.cells.金额 = '999999999999999999999999';
    for (const x of b.rows)
        x.cells.金额 = '-999999999999999999999999';
    const x = execute([a, b], c, 'large');
    const m = x.sums.find(m => m.field === '金额 ↔ 金额')!;
    assert.equal(m.difference, '3999999999999999999999996');
    assert.equal(m.left, '1999999999999999999999998');
    a.rows[0].cells.币种 = null;
    const y = execute([a, b], c, 'invalid-currency');
    assert(y.sourceSums.some(m => m.currency === '币种无效' && m.uncomparable === null));
});
test('同键多条含无效字段始终不可比；全部复核也不能完成', () => {
    const a = structuredClone(l), b = structuredClone(r);
    a.rows[1].cells.单据号 = 'A';
    a.rows[1].cells.金额 = null;
    let x = execute([a, b], c, 'duplicate');
    assert.equal(x.result.counts['重复/歧义'].groups, 1);
    assert(x.result.outcomes[0].issues.some(i => i.includes('金额')));
    for (const o of x.result.outcomes.filter(o => o.category !== '匹配一致'))
        for (const to of ['追查中', '已说明待复核', '复核通过'] as const)
            x = review(x, identity(o), event(to));
    assert.match(completion(x).label, /不可比/);
});
test('无数据方案清除实际范围值；工作底稿未知复核时间与字段拒绝', () => { const config = structuredClone(c); config.scope.filters = [{ side: 0, field: '单据号', kind: 'values', values: ['私密单据A'], from: '', to: '' }]; assert(!encodeConfig(config).includes('私密单据A')); const s = session(); const key = identity(s.run!.result.outcomes[1]); s.run = review(s.run!, key, event('追查中')); const v = JSON.parse(encodeWork(s)); v.run.reviews[key].events[0].at = 'not-time'; assert.throws(() => decodeWork(JSON.stringify(v)), /时间/); assert.throws(() => review(run(), key, { ...event('追查中'), note: 'x'.repeat(10001) }), /文本/); });
test('非法/缺失币种17及29不形成46或0汇总，原行数量保留且恢复/XLSX明确不可汇总', async () => { const a = structuredClone(l), b = structuredClone(r); a.rows = a.rows.slice(0, 2); b.rows = b.rows.slice(0, 2); a.rows[0].cells.金额 = '17'; a.rows[1].cells.金额 = '29'; a.rows[0].cells.币种 = null; a.rows[1].cells.币种 = '??'; const x = execute([a, b], c, 'unknown'); const u = x.sourceSums.find(s => s.side === 0 && s.currency === '币种无效' && s.field === '金额 ↔ 金额')!; assert.deepEqual([u.input, u.included, u.excluded, u.paired, u.single, u.uncomparable], [null, null, null, null, null, null]); assert.equal(u.inputRows, 2); assert.deepEqual(x.result.outcomes.map(o => o.left[0].cells.金额), ['17', '29']); const summary = x.sums.find(s => s.currency === '币种无效' && s.field === '金额 ↔ 金额')!; assert.equal(summary.left, null); const session = { title: '虚构非法币种', tables: [a, b] as [
        typeof l,
        typeof r
    ], config: c, run: x, previous: null, revision: 0 }; assert.equal(decodeWork(encodeWork(session)).run!.sourceSums[0].input, null); const wb = new ExcelJS.Workbook(); await wb.xlsx.load(await exportWork(x, '虚构') as any); assert.equal(wb.getWorksheet('来源金额守恒')!.getCell('D2').value, '不可汇总'); });
test('导入/恢复体积先检查，10MB+1读取次数0；10MB边界允许', async () => { const { readBytes, readText } = await import('../src/input'); let bytesCalls = 0, textCalls = 0; const fake = { size: 10 * 1024 * 1024 + 1, arrayBuffer: async () => { bytesCalls++; return new ArrayBuffer(0); }, text: async () => { textCalls++; return '{}'; } }; await assert.rejects(() => readBytes(fake), /未读取/); await assert.rejects(() => readText(fake), /未读取/); assert.equal(bytesCalls, 0); assert.equal(textCalls, 0); fake.size = 10 * 1024 * 1024; await readBytes(fake); await readText(fake); assert.equal(bytesCalls, 1); assert.equal(textCalls, 1); });
