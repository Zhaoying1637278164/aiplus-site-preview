import type { Table } from '../../../packages/core/types';
import { defaultRule } from '../src/engine';
import { emptyScope, type Config } from '../src/workflow';
const make = (file: string, data: [
    string,
    string,
    string,
    string
][]): Table => ({ file, sheet: '9月虚构明细', headers: ['单据号', '金额', '辅助金额', '日期', '币种'], rows: data.map(([id, m, second, c], i) => ({ file, sheet: '9月虚构明细', row: i + 2, cells: { 单据号: id, 金额: m, 辅助金额: second, 日期: '2026-09-30', 币种: c } })) });
export const monthLeft = make('虚构财务账.csv', [['A', '100', '3', 'CNY'], ['B', '200', '7', 'CNY'], ['C', '-50', '0', 'CNY'], ['D', '0', '-1', 'CNY'], ['E', '10', '0', 'USD'], ['F', '20', '0', 'USD']]);
export const monthRight = make('虚构业务表.csv', [['A', '100.01', '3', 'CNY'], ['B', '210', '9', 'CNY'], ['C', '-50', '0', 'CNY'], ['D', '0', '-1', 'CNY'], ['E', '10', '0', 'USD'], ['G', '30', '0', 'USD']]);
export const monthConfig: Config = { names: ['虚构财务账', '虚构业务表'], rule: { ...structuredClone(defaultRule), tolerance: '0.01', fields: [...defaultRule.fields, { left: '辅助金额', right: '辅助金额', type: 'amount' }] }, scope: { ...emptyScope(), entity: '虚构青禾服务公司', periods: ['2026-09', '2026-09'], unit: '元', grain: '每行一笔单据', confirmed: true } };
