# D02 账表对账

## 当前验证状态（2026-10-03，总控最新交接）

最终源码全项目69/69测试、typecheck及build D02已通过。Mac Chromium断网file://五页、复核、实际XLSX/JSON下载回读与恢复、新CSV/XLSX、多页签/表头、筛选、旧结果失效和手机复核已验证；localhost8514原生官网导航、标题/五页导航可见、同结果与实际导入恢复已验证。证据目录：progress/evidence/D02/0.2.0；browser-initial.json、browser-input.json、site-local-native.json、site-local-input.json绑定HTML SHA256 713708875a9b6a7d1377c3cc814ca92be1e80da695df56d8e5cd6de30c701219。

总控已实际审阅最终五页桌面、复核手机、官网原详情与工作区截图；最终rendered-review.json的passed=true，绑定本版HTML哈希。公开官网提交b1b3ede已实际验证：原工具库→结账13→账表对账详情及五页工作区，七项真实下载SHA与release一致且ZIP内HTML一致；30笔虚构CSV/XLSX导入的tables/result/sums/sourceSums与离线逐项相等；离线三次复核底稿在官网恢复再下载，run/tables完整相等，002、原第3行、复核通过可见；返回详情重进双方为空。证据：site-public-downloads.json及下载目录、site-public-import-work.json、site-public-restored-work.json和site-public-input/restored/reentry.jpg，均位于上述证据目录。

最终说明包重打包及公开下载回读后，由总控登记accepted；本线程不自行标完成。Windows实机未验证。本轮仅更新四份说明，未改业务代码、规则或执行打包发布。下面早期阶段记录的“未验证”是当时状态，以本节及总控最终证据为准。


结账模块：明确关联键、同粒度的双方账表核对，提供资料、口径、差异、复核与底稿五个业务页面。不是回款核销或银行余额调节。

当前：0.2.0源码、Node测试、Mac Chromium断网离线与localhost8514原生官网验证通过；公开官网上述使用与下载流程已验证，待最终说明包复核后由总控登记accepted。旧release/D02/0.1.0冻结，原产品验收已撤回，历史技术证据保留。

- [产品与页面方案](产品与页面方案.md) / [任务与接续](任务与接续.md) / [实现交接](实现交接.md)
- [人工独立预期](规格与独立预期.md) / [本轮验收证据](验收证据.md) / [财务规则](财务规则.md) / [参考来源](参考来源.md)
- 入口：src/program.tsx导出program，src/main.tsx仅为离线挂载；同一业务组件用于官网与离线。
- 计算：src/engine.ts复用原算法；src/workflow.ts范围、Decimal金额勾稽、复核及历史；src/restore.ts当前无数据方案及含数据工作底稿安全重算恢复；src/work-export.ts九页签业务底稿。

虚构样例在src/example.ts（六类回归）与examples/month-end.ts（双币种、两金额字段）。用户数据只在浏览器内存处理；关闭/卸载清除，无外部请求或默认持久化。主动保存底稿包含数据，口径方案不含资料及实际范围值。

开发：Node22+，项目根运行npm test及npm run typecheck。本线程不修改公共入口/构建/官网，打包由总控执行。新UI浏览器、下载、断网file://和本地原生官网已由总控验证；Windows未验证，最终源码包重建状态以总控证据为准。
