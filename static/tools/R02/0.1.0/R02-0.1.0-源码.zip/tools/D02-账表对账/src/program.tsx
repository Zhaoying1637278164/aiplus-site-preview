import {keyLabel,categoryLabel,localTime} from './display';
import { checkFileSize, readBytes, readText } from './input';
import Decimal from 'decimal.js';
import { amount } from '../../../packages/core/value';
import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import type { ToolProgram } from '../../../packages/ui/tool-host';
import { readFileData, asTable, workbookBytes, type LoadedFile } from '../../../packages/core/io';
import { LIMITS, type Table, type Rule, type Mapping } from '../../../packages/core/types';
import { defaultRule, CATEGORIES } from './engine';
import { leftExample, rightExample } from './example';
import { VERSION, RULE_VERSION } from './version';
import { emptyScope, execute, invalidate, select, diagnostics, identity, review, completion, search, type Session, type Scope, type Filter, type ReviewStatus } from './workflow';
import { encodeConfig, decodeConfig, encodeWork, decodeWork } from './restore';
import { exportWork, workSheets } from './work-export';
import { styles } from './styles';
const clone = <T,>(v: T) => structuredClone(v);
const initial = (): Session => ({ title: '本次账表对账', tables: [null, null], config: { names: ['财务账务明细', '业务登记台账'], rule: clone(defaultRule), scope: emptyScope() }, run: null, previous: null, revision: 0 });
const pages = ['两方资料', '范围与口径', '差异总览', '逐项复核', '结果底稿'];
const value = (v: unknown) => v === null || v === undefined ? '空值' : typeof v === 'object' ? '公式／禁止计算' : String(v);
interface Control {
    dirty: boolean;
    alive: boolean;
    urls: Set<string>;
    timers: Set<ReturnType<typeof setTimeout>>;
}
function Workspace({ control, onExit }: {
    control: Control;
    onExit?: () => void;
}) {
    const [s, setS] = useState(initial);
    const [page, setPage] = useState(0);
    const workspaceRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
        const frame = requestAnimationFrame(() => workspaceRef.current?.querySelector('.d02-heading')?.scrollIntoView({block: 'start', behavior: 'instant'}));
        return () => cancelAnimationFrame(frame);
    }, [page]);
    const [loaded, setLoaded] = useState<[
        LoadedFile | null,
        LoadedFile | null
    ]>([null, null]);
    const [sheets, setSheets] = useState(['', '']);
    const [headers, setHeaders] = useState([1, 1]);
    const [error, setError] = useState('');
    const [notice, setNotice] = useState('');
    const [busy, setBusy] = useState(false);
    const [query, setQuery] = useState('');
    const [cat, setCat] = useState('全部');
    const [status, setStatus] = useState('全部');
    const [index, setIndex] = useState(0);
    const [selected, setSelected] = useState('');
    const [cause, setCause] = useState('');
    const [note, setNote] = useState('');
    const [evidence, setEvidence] = useState('');
    const [person, setPerson] = useState('');
    const [reason, setReason] = useState('');
    const [threshold, setThreshold] = useState('0');
    const [saved, setSaved] = useState(false);
    const [pendingDraft, setPendingDraft] = useState(false);
    const [filter, setFilter] = useState<Filter>({ side: 0, field: '', kind: 'values', values: [], from: '', to: '' });
    const [sheetPreview, setSheetPreview] = useState(0);
    function update(next: Session) { control.dirty = true; setSaved(false); setS(next); }
    function changed(next: Session) { update(invalidate(next)); setSelected(''); setNotice('资料或口径已变化，旧运行已失效。请重新确认范围并生成差异。'); }
    function config(next: Session['config']) { changed({ ...s, config: next }); }
    function scope(p: Partial<Scope>) { config({ ...s.config, scope: { ...s.config.scope, ...p } }); }
    async function act(fn: () => unknown | Promise<unknown>) {
        setError('');
        setNotice('');
        setBusy(true);
        try {
            await fn();
        }
        catch (e) {
            if (control.alive)
                setError((e as Error).message);
        }
        finally {
            if (control.alive)
                setBusy(false);
        }
    }
    function download(name: string, data: BlobPart, type = 'application/json') {
        if (!control.alive)
            return;
        const url = URL.createObjectURL(new Blob([data], { type }));
        control.urls.add(url);
        const a = document.createElement('a');
        a.href = url;
        a.download = name;
        a.click();
        const timer = setTimeout(() => { URL.revokeObjectURL(url); control.urls.delete(url); control.timers.delete(timer); }, 1000);
        control.timers.add(timer);
    }
    useEffect(() => {
        const handler = (e: BeforeUnloadEvent) => {
            if (control.dirty) {
                e.preventDefault();
                e.returnValue = '';
            }
        };
        window.addEventListener('beforeunload', handler);
        return () => window.removeEventListener('beforeunload', handler);
    }, []);
    function resetDrafts() { setPendingDraft(false); setQuery(''); setCat('全部'); setStatus('全部'); setIndex(0); setSelected(''); setCause(''); setNote(''); setEvidence(''); setPerson(''); setReason(''); setThreshold('0'); setFilter({ side: 0, field: '', kind: 'values', values: [], from: '', to: '' }); setSheetPreview(0); setSaved(false); setError(''); setSheets(['', '']); setHeaders([1, 1]); }
    function important(difference: string) { try {
        const t = amount(threshold);
        if (t.isNegative())
            return ' · 阈值无效';
        return new Decimal(difference).abs().gt(t) ? ' · 超提示阈值' : '';
    }
    catch {
        return ' · 阈值无效';
    } }
    function dirtyDraft() { setPendingDraft(true); control.dirty = true; setSaved(false); }
    function clear() {
        if (control.dirty && !window.confirm('清除当前资料、结果和复核记录？尚未下载的内容将丢失。'))
            return;
        for (const t of control.timers) clearTimeout(t);
        for (const u of control.urls) URL.revokeObjectURL(u);
        control.timers.clear();
        control.urls.clear();
        resetDrafts();
        setS(initial());
        setLoaded([null, null]);
        setSheets(['', '']);
        setHeaders([1, 1]);
        setSelected('');
        setPage(0);
        control.dirty = false;
        setNotice('本次资料已清除');
    }
    async function upload(side: 0 | 1, file: File) {
        checkFileSize(file.size);
        const next = clone(s);
        next.tables[side] = null;
        changed(next);
        setLoaded(v => v.map((x, i) => i === side ? null : x) as typeof v);
        const l = await readFileData(file.name, await readBytes(file));
        if (!control.alive)
            return;
        setLoaded(v => v.map((x, i) => i === side ? l : x) as typeof v);
        setSheets(v => v.map((x, i) => i === side ? l.sheets[0].name : x));
        setHeaders(v => v.map((x, i) => i === side ? 1 : x));
        const table = asTable(l, l.sheets[0].name, 1);
        setS(v => ({ ...invalidate(v), tables: v.tables.map((x, i) => i === side ? table : x) as Session['tables'] }));
    }
    function selectSource(side: 0 | 1, sheet: string, header: number) { const next = clone(s); next.tables[side] = null; changed(next); setSheets(v => v.map((x, i) => i === side ? sheet : x)); setHeaders(v => v.map((x, i) => i === side ? header : x)); const t = asTable(loaded[side]!, sheet, header); setS(v => ({ ...v, tables: v.tables.map((x, i) => i === side ? t : x) as Session['tables'] })); }
    function sample() {
        if (control.dirty && !window.confirm('示例将替换当前资料与复核记录，继续？'))
            return;
        resetDrafts();
        const next = initial();
        next.tables = [clone(leftExample), clone(rightExample)];
        next.config.scope = { ...emptyScope(), entity: '虚构青禾服务公司', periods: ['2026-09', '2026-09'], unit: '元', grain: '每行一笔单据' };
        update(next);
        setLoaded([null, null]);
        setSelected('');
        setPage(0);
    }
    function column(side: 0 | 1, current: string, change: (v: string) => void, label: string) { return <select aria-label={label} value={current} onChange={e => change(e.target.value)}><option value="">选择字段</option>{current && !s.tables[side]?.headers.includes(current) && <option value={current}>{current}（缺列）</option>}{s.tables[side]?.headers.map(h => <option key={h}>{h}</option>)}</select>; }
    function mapping(kind: 'keys' | 'fields') { return <div className="d02-map"><div className="d02-grid"><b>{s.config.names[0]}</b><b>{s.config.names[1]}</b><b>{kind === 'keys' ? '关联项' : '核对类型'}</b></div>{s.config.rule[kind].map((m, i) => <div className="d02-grid" key={i}>{([0, 1] as const).map(side => column(side, m[side === 0 ? 'left' : 'right'], v => { const rule = clone(s.config.rule); rule[kind][i][side === 0 ? 'left' : 'right'] = v; config({ ...s.config, rule }); }, `${kind}-${i}-${side}`))}<div>{kind === 'fields' ? <select aria-label={`比较类型${i}`} value={m.type} onChange={e => { const rule = clone(s.config.rule); rule.fields[i].type = e.target.value as Mapping['type']; config({ ...s.config, rule }); }}><option value="amount">金额</option><option value="date">日期</option><option value="text">文本</option></select> : <span>按文本关联</span>} <button onClick={() => { const rule = clone(s.config.rule); rule[kind].splice(i, 1); config({ ...s.config, rule }); }}>移除</button></div></div>)}<button onClick={() => config({ ...s.config, rule: { ...s.config.rule, [kind]: [...s.config.rule[kind], { left: '', right: '', type: kind === 'keys' ? 'text' : 'amount' }] } })}>添加{kind === 'keys' ? '关联项' : '比较项'}</button></div>; }
    function restoreInput(kind: 'config' | 'work') {
        return <label className="d02-file">恢复{kind === 'config' ? '口径方案（无数据）' : '工作底稿（含数据）'}<input type="file" accept=".json" disabled={busy} onChange={e => {
                const file = e.target.files?.[0];
                e.target.value = '';
                if (file)
                    void act(async () => {
                        if (file.size > LIMITS.bytes)
                            throw Error('恢复文件超过10MB');
                        const raw = await readText(file);
                        if (!control.alive)
                            return;
                        if (kind === 'work') {
                            const next = decodeWork(raw);
                            if (control.dirty && !window.confirm('恢复底稿将替换当前资料及复核记录，继续？'))
                                return;
                            resetDrafts();
                            update(next);
                            setLoaded([null, null]);
                            setSelected('');
                            setPage(2);
                            control.dirty = false;
                            setNotice('工作底稿已通过来源重算校验并恢复；自填复核记录不构成身份认证');
                        }
                        else {
                            const { config: c, legacy } = decodeConfig(raw);
                            if (control.dirty && !window.confirm('恢复无数据方案会清除当前资料与结果，继续？'))
                                return;
                            resetDrafts();
                            changed({ ...s, config: c, tables: [null, null] });
                            setLoaded([null, null]);
                            setPage(0);
                            setNotice(legacy ? '旧0.1.0规则已迁移；请重新导入并确认口径' : '方案已恢复；请重新导入、编辑纳入条件值并确认口径');
                        }
                    });
            }}/></label>;
    }
    const run = s.run;
    const found = run ? search(run, query, cat, status) : [];
    const pageSize = 25;
    const totalPages = Math.max(1, Math.ceil(found.length / pageSize));
    const currentPage = Math.min(index, totalPages - 1);
    const rows = found.slice(currentPage * pageSize, (currentPage + 1) * pageSize);
    const item = run?.result.outcomes.find(o => identity(o) === selected);
    const currentReview = item && run ? run.reviews[identity(item)] : undefined;
    function choose(key: string) {
        if (pendingDraft && !window.confirm('当前说明尚未提交复核操作，切换事项会放弃草稿。继续？'))
            return;
        setPendingDraft(false);
        setSelected(key);
        const r = run!.reviews[key]?.events.at(-1);
        setCause(r?.cause || '');
        setNote(r?.note || '');
        setEvidence(r?.evidence || '');
        setPerson('');
        setReason('');
    }
    const filtersUI = <div className="d02-actions"><input aria-label="搜索全部核对结果" placeholder="搜索单据、来源或原值" value={query} onChange={e => { setQuery(e.target.value); setIndex(0); }}/><select aria-label="分类筛选" value={cat} onChange={e => { setCat(e.target.value); setIndex(0); setSelected(''); }}><option>全部</option>{CATEGORIES.map(c => <option key={c} value={c}>{categoryLabel(c)}</option>)}</select><select aria-label="复核状态筛选" value={status} onChange={e => { setStatus(e.target.value); setIndex(0); setSelected(''); }}>{['全部', '未复核', '追查中', '已说明待复核', '复核通过'].map(c => <option key={c}>{c}</option>)}</select><span>{found.length}组</span></div>;
    return <div className="d02" ref={workspaceRef}><style>{styles}</style><header className="d02-heading"><div><p className="d02-muted">结账 · 全程本地运行</p><h1>账表对账</h1><p>{s.title} · {run ? '当前结果 ' + localTime(run.id) : s.previous ? '结果已过期，待重新核对' : '准备本次资料'}</p></div><div className="d02-actions">{onExit && <button onClick={onExit}>返回工具详情</button>}<button onClick={clear} disabled={busy}>清除本次资料</button><details><summary>使用与口径</summary><p>仅浏览器内存处理，关闭清除。支持UTF-8 CSV/XLSX，单文件10MB、解压30MB、20000行、200列。公式不执行，不换汇、不核销或记账。</p><p>应用{VERSION} · 规则{RULE_VERSION}。金额最多6位小数，24位数字；空不等于零。人员为自填记录。</p>{run&&<p>本机时间：{localTime(run.id)}；追溯运行标识：{run.id}</p>}</details></div></header>
 <fieldset className="d02-busy" disabled={busy}><nav className="d02-tabs" aria-label="对账工作页面">{pages.map((p, i) => <button key={p} aria-current={page === i ? 'page' : undefined} onClick={() => { setPage(i); setError(''); }}>{p}</button>)}</nav>
 {error && <p role="alert" className="d02-error">{error}</p>}{notice && <p role="status">{notice}</p>}{busy && <p role="status">正在本地处理…</p>}
 {page === 0 && <section><div className="d02-actions"><h2>准备双方资料</h2><button disabled={busy} onClick={sample}>体验虚构示例</button><button onClick={() => void act(async () => { const bytes = await workbookBytes([leftExample, rightExample].map((t, i) => ({ name: i === 0 ? '财务账务明细' : '业务登记台账', headers: t.headers, rows: t.rows.map(r => t.headers.map(h => r.cells[h])) }))); download('账表对账-虚构样例.xlsx', bytes as BlobPart, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); })}>下载样例</button><button onClick={() => download('账表对账-空白模板.csv', '单据号,金额,日期,币种\n', 'text/csv;charset=utf-8')}>空白模板</button></div><label>核对事项<input aria-label="核对事项" value={s.title} onChange={e => update({ ...s, title: e.target.value })}/></label>
 <div className="d02-two">{([0, 1] as const).map(side => <article key={side}><h3>{s.config.names[side]}</h3><label>来源名称<input value={s.config.names[side]} onChange={e => { const names = clone(s.config.names); names[side] = e.target.value; config({ ...s.config, names }); }}/></label><label>导入文件<input aria-label={`导入第${side + 1}方`} type="file" accept=".csv,.xlsx" disabled={busy} onChange={e => {
                    const f = e.target.files?.[0];
                    e.target.value = '';
                    if (f)
                        void act(() => upload(side, f));
                }}/></label>{loaded[side] && <div className="d02-actions"><label>页签<select value={sheets[side]} onChange={e => { const v = e.target.value; void act(() => selectSource(side, v, headers[side])); }}>{loaded[side]!.sheets.map(t => <option key={t.name}>{t.name}</option>)}</select></label><label>表头行<input type="number" min={1} max={100} value={headers[side]} onChange={e => { const n = Number(e.target.value); void act(() => selectSource(side, sheets[side], n)); }}/></label></div>}{s.tables[side] ? <><p>{s.tables[side]!.file} / {s.tables[side]!.sheet} · {s.tables[side]!.rows.length}行 · {s.tables[side]!.headers.length}列</p><p className="d02-muted">预览前5行；完整原行在核对与底稿保留。{s.tables[side]!.rows.filter(r => Object.values(r.cells).some(c => c && typeof c === 'object')).length}行含公式或Excel错误，相关字段不参与计算。</p><div className="d02-scroll"><table><thead><tr><th>原行</th>{s.tables[side]!.headers.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{s.tables[side]!.rows.slice(0, 5).map(r => <tr key={r.row}><td>{r.row}</td>{s.tables[side]!.headers.map(h => <td key={h}>{value(r.cells[h])}</td>)}</tr>)}</tbody></table></div></> : <p>尚无可用资料。请选择文件及完整表头。</p>}</article>)}</div><div className="d02-actions">{restoreInput('config')}{restoreInput('work')}<button className="d02-primary" disabled={!s.tables.every(Boolean) || busy} onClick={() => setPage(1)}>下一步：范围与口径</button></div></section>}
 {page === 1 && <section><h2>范围与口径</h2>{!s.tables.every(Boolean) ? <p>请先准备两方资料。<button onClick={() => setPage(0)}>返回资料页</button></p> : <><article><h3>核对同一范围</h3><div className="d02-form">{([['主体', 'entity'], ['金额单位', 'unit'], ['每行粒度', 'grain']] as const).map(([label, key]) => <label key={key}>{label}<input value={s.config.scope[key]} onChange={e => scope({ [key]: e.target.value })}/></label>)}{([0, 1] as const).map(side => <label key={side}>{s.config.names[side]}期间<input value={s.config.scope.periods[side]} onChange={e => { const periods = clone(s.config.scope.periods); periods[side] = e.target.value; scope({ periods }); }}/></label>)}<label>金额含义<select value={s.config.scope.basis} onChange={e => scope({ basis: e.target.value as Scope['basis'] })}><option>发生额</option><option>余额</option></select></label><label>税口径<select value={s.config.scope.tax} onChange={e => scope({ tax: e.target.value as Scope['tax'] })}><option>不含税</option><option>含税</option></select></label></div><label><input type="checkbox" checked={s.config.scope.crossPeriod} onChange={e => scope({ crossPeriod: e.target.checked })}/>跨期明细追查</label>{s.config.scope.crossPeriod && <label>跨期目的<input value={s.config.scope.purpose} onChange={e => scope({ purpose: e.target.value })}/></label>}<p>这些内容是用户确认的两方共同口径，不改变原表值。单位、含税含义或方向不同，请先整理来源；币种列必须存在。</p>
 <h4>纳入范围（留空表示整表）</h4><div className="d02-actions"><select aria-label="筛选来源" value={filter.side} onChange={e => setFilter({ ...filter, side: Number(e.target.value) as 0 | 1, field: '', values: [] })}>{s.config.names.map((n, i) => <option key={i} value={i}>{n}</option>)}</select>{column(filter.side, filter.field, v => setFilter({ ...filter, field: v, values: [] }), '筛选字段')}<select value={filter.kind} onChange={e => setFilter({ ...filter, kind: e.target.value as Filter['kind'] })}><option value="values">字段值</option><option value="date">日期区间（含边界）</option></select>{filter.kind === 'date' ? <><input aria-label="范围开始日" type="date" value={filter.from} onChange={e => setFilter({ ...filter, from: e.target.value })}/><input aria-label="范围结束日" type="date" value={filter.to} onChange={e => setFilter({ ...filter, to: e.target.value })}/></> : <select multiple aria-label="纳入字段值" value={filter.values} onChange={e => setFilter({ ...filter, values: Array.from(e.target.selectedOptions, o => o.value) })}>{[...new Set(s.tables[filter.side]!.rows.map(r => r.cells[filter.field]).filter(v => v !== null && v !== undefined && typeof v !== 'object').map(String))].sort().map(v => <option key={v}>{v}</option>)}</select>}<button disabled={!filter.field} onClick={() => scope({ filters: [...s.config.scope.filters, clone(filter)] })}>加入范围条件</button></div>{s.config.scope.filters.map((f, i) => <p key={i}>{s.config.names[f.side]} · {f.field} · {f.kind === 'date' ? f.from + '至' + f.to : f.values.join('、')} <button onClick={() => scope({ filters: s.config.scope.filters.filter((_, j) => i !== j) })}>移除</button><button onClick={() => { setFilter(clone(f)); scope({ filters: s.config.scope.filters.filter((_, j) => i !== j) }); }}>编辑条件</button></p>)}<p className="d02-muted">同方条件同时满足才纳入；空或公式范围字段阻断，不静默排除。排除原行及理由完整写入底稿。</p>{(() => {
                    try {
                        const p = select(s.tables as [
                            Table,
                            Table
                        ], s.config.scope.filters);
                        return <p>当前范围：{s.config.names.map((n, i) => `${n}输入${s.tables[i]!.rows.length}＝纳入${p.selected[i].rows.length}＋排除${p.excluded.filter(e => e.side === i).length}`).join('；')}</p>;
                    }
                    catch (e) {
                        return <p className="d02-error">{(e as Error).message}</p>;
                    }
                })()}</article>
 <article><h3>如何找到同一笔</h3>{mapping('keys')}<div className="d02-two">{([0, 1] as const).map(side => { const d = diagnostics(s.tables[side]!, s.config.rule, side === 0 ? 'left' : 'right'); return <p key={side}>{s.config.names[side]}：同键多条{d.duplicateGroups}组，缺少关联值{d.invalid}行，文本处理碰撞{d.collisions}组</p>; })}</div><p>对应不唯一时增加真实明细维度或回源补资料，不用行号强配，也不按金额抵消。</p></article><article><h3>核对哪些内容</h3>{mapping('fields')}<div className="d02-form">{([0, 1] as const).map(side => <label key={side}>{s.config.names[side]}币种{column(side, s.config.rule.currency[side === 0 ? 'left' : 'right'], v => config({ ...s.config, rule: { ...s.config.rule, currency: { ...s.config.rule.currency, [side === 0 ? 'left' : 'right']: v } } }), `第${side + 1}方币种`)}</label>)}<label>金额容差（全部金额字段共用）<input value={s.config.rule.tolerance} onChange={e => config({ ...s.config, rule: { ...s.config.rule, tolerance: e.target.value } })}/></label></div><div className="d02-actions"><label><input type="checkbox" checked={s.config.rule.trim} onChange={e => config({ ...s.config, rule: { ...s.config.rule, trim: e.target.checked } })}/>去首尾空格（例如“ A ”→“A”）</label><label><input type="checkbox" checked={s.config.rule.ignoreCase} onChange={e => config({ ...s.config, rule: { ...s.config.rule, ignoreCase: e.target.checked } })}/>忽略大小写（a→A，可能合并关联值）</label></div></article><article><h3>本次口径摘要</h3><p>{s.config.scope.entity || '未填主体'}，双方期间{s.config.scope.periods.join(' / ')}，{s.config.scope.unit || '未填单位'}，{s.config.scope.tax}{s.config.scope.basis}；以{s.config.rule.keys.map(m => m.left + ' ↔ ' + m.right).join('、')}关联；比较{s.config.rule.fields.map(m => m.left).join('、')}，差额方向为{s.config.names.join(' 减 ')}，金额容差{s.config.rule.tolerance}。</p><label><input aria-label="确认本次范围口径" type="checkbox" checked={s.config.scope.confirmed} onChange={e => update({ ...s, config: { ...s.config, scope: { ...s.config.scope, confirmed: e.target.checked } }, run: null })}/>我已核实两方主体、期间、单位、金额含义和方向，关联粒度一致</label><div className="d02-actions"><button className="d02-primary" disabled={busy || !s.config.scope.confirmed} onClick={() => void act(() => {
                    const result = execute(s.tables as [
                        Table,
                        Table
                    ], s.config, new Date().toISOString());
                    update({ ...s, run: result });
                    setPage(2);
                    setCat('全部');
                    setIndex(0);
                    setSelected('');
                })}>生成差异</button><button onClick={() => void act(() => download('账表对账-无数据方案.json', encodeConfig(s.config)))}>保存口径方案（不含资料）</button></div></article></>}</section>}
 {(page === 2 || page === 3 || page === 4) && !run && <section><h2>{s.previous ? '旧结果已失效' : '尚未生成差异'}</h2><p>准备资料并确认范围后生成当前运行。旧复核结论不用于新资料。</p><button onClick={() => setPage(s.tables.every(Boolean) ? 1 : 0)}>返回准备</button>{s.previous && <details><summary>查看过期运行摘要</summary><p>{localTime(s.previous.id)}，覆盖{s.previous.included.join(' / ')}行，仅供历史查看。</p></details>}</section>}
 {page === 2 && run && <section><h2>差异总览</h2><p>{completion(run).label} · 未决{completion(run).pending}组。净差为零也不能替代逐项复核。</p><div className="d02-two">{([0, 1] as const).map(side => <article key={side}><b>{s.config.names[side]}</b><p>输入{run.input[side]}行 = 纳入{run.included[side]} + 排除{run.excluded.filter(e => e.side === side).length}；六类覆盖{side === 0 ? run.result.coverage.left : run.result.coverage.right}行</p></article>)}</div><div className="d02-categories">{CATEGORIES.map(c => <button key={c} onClick={() => { setCat(c); setQuery(''); setStatus('全部'); setIndex(0); setPage(3); }}><b>{categoryLabel(c)}</b><span>{run.result.counts[c].groups}组 · 两方{run.result.counts[c].left}/{run.result.counts[c].right}行</span></button>)}</div><h3>金额勾稽（分币种、分字段）</h3><div className="d02-scroll"><table><thead><tr>{['币种 / 字段', '配对数', '第一方', '第二方', '原差额', '容差内差额', '超差额', '单侧第一方/第二方', '不可比行'].map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{run.sums.map(m => <tr key={m.currency + m.field}><td>{m.currency} / {m.field}</td><td>{m.paired ?? '不可汇总'}</td><td>{m.left ?? '不可汇总'}</td><td>{m.right ?? '不可汇总'}</td><td>{m.difference ?? '不可汇总'}</td><td>{m.withinTolerance ?? '不可汇总'}</td><td>{m.different ?? '不可汇总'}</td><td>{m.singleLeft ?? '不可汇总'} / {m.singleRight ?? '不可汇总'}</td><td>{m.uncomparableLeft} / {m.uncomparableRight}</td></tr>)}</tbody></table></div><p>配对差额＝第一方−第二方＝容差内差额＋超差额。单侧不补零，重复与无效行不计入配对。</p><h3>来源金额守恒</h3><div className="d02-scroll"><table><thead><tr>{['来源 / 币种 / 字段', '输入', '纳入', '排除', '配对', '单侧', '不可比参考金额', '无效金额行'].map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{run.sourceSums.map(m => <tr key={m.side + m.currency + m.field}><td>{run.config.names[m.side]} / {m.currency} / {m.field}</td><td>{m.input ?? '不可汇总'}</td><td>{m.included ?? '不可汇总'}</td><td>{m.excluded ?? '不可汇总'}</td><td>{m.paired ?? '不可汇总'}</td><td>{m.single ?? '不可汇总'}</td><td>{m.uncomparable ?? '不可汇总'}</td><td>{m.inputRows}行（纳入{m.includedRows}/排除{m.excludedRows}）；无效金额{m.invalidInput}（纳入{m.invalidIncluded} / 排除{m.invalidExcluded}）</td></tr>)}</tbody></table></div><p>可计金额：输入＝纳入＋排除；纳入＝配对＋单侧＋不可比参考金额。不可比参考金额不参与配对差额；无效金额行单列，不补零。币种无效的金额全部标不可汇总，仅保留数量及原行。</p><details><summary>范围排除原行（{run.excluded.length}行）</summary><div className="d02-scroll"><table><thead><tr><th>来源</th><th>原行</th><th>排除理由</th></tr></thead><tbody>{run.excluded.map((e, i) => <tr key={i}><td>{run.config.names[e.side]} / {e.source.file} / {e.source.sheet}</td><td>{e.source.row}</td><td>{e.reasons.join('；')}</td></tr>)}</tbody></table></div></details><button className="d02-primary" onClick={() => setPage(3)}>逐项追查与复核</button></section>}
 {page === 3 && run && <section><h2>逐项复核</h2>{filtersUI}<label>重要性提示阈值（仅提示，不改分类）<input value={threshold} onChange={e => setThreshold(e.target.value)}/></label><div className="d02-review"><div><div className="d02-scroll"><table><thead><tr><th>单据 / 分类</th><th>差额</th><th>复核</th></tr></thead><tbody>{rows.map(o => <tr key={identity(o)} className={selected === identity(o) ? 'd02-selected' : ''}><td><button onClick={() => choose(identity(o))}>{keyLabel(o.key)}</button><br />{categoryLabel(o.category)}</td><td>{o.details.filter(d => d.difference).map(d => <div key={d.field}>{d.field}: {d.difference}{important(d.difference)}</div>)}</td><td>{run.reviews[identity(o)]?.status || '未复核'}</td></tr>)}</tbody></table></div><div className="d02-actions"><button disabled={currentPage === 0} onClick={() => setIndex(currentPage - 1)}>上一页</button><span>第{currentPage + 1}/{totalPages}页 · 每页25组</span><button disabled={currentPage + 1 >= totalPages} onClick={() => setIndex(currentPage + 1)}>下一页</button></div></div><article>{item ? <><div className="d02-actions"><h3>{keyLabel(item.key)} · {categoryLabel(item.category)}</h3><button onClick={() => setSelected('')}>返回列表</button>{['上一项', '下一项'].map((label, i) => { const n = found.findIndex(o => identity(o) === selected) + (i === 0 ? -1 : 1); return <button key={label} disabled={n < 0 || n >= found.length} onClick={() => choose(identity(found[n]))}>{label}</button>; })}</div>{item.issues.length > 0 && <p className="d02-error">{item.issues.join('；')}</p>}<div className="d02-two">{(['left', 'right'] as const).map((side, i) => <div key={side}><h4>{run.config.names[i]}</h4>{item[side].length ? item[side].map(r => <details key={r.row} open><summary>{r.file} / {r.sheet} / 原第{r.row}行</summary><dl>{Object.entries(r.cells).map(([k, v]) => <React.Fragment key={k}><dt>{k}</dt><dd>{value(v)}</dd></React.Fragment>)}</dl></details>) : <p>该方无对应行；不视为零</p>}</div>)}</div><div className="d02-scroll"><table><thead><tr><th>比较字段</th><th>原值第一/第二方</th><th>规范值第一/第二方</th><th>差额/判定</th></tr></thead><tbody>{item.details.map(d => <tr key={d.field}><td>{d.field}</td><td>{value(d.left)} / {value(d.right)}</td><td>{d.normalizedLeft} / {d.normalizedRight}</td><td>{d.difference} · {d.equal ? '容差内／相同' : '差异'}</td></tr>)}</tbody></table></div><h4>处理依据 · {currentReview?.status || '未复核'}</h4><p className="d02-muted">填写后须应用下方复核操作，草稿才进入底稿与历史。</p><div className="d02-form"><label>差异原因<select value={cause} onChange={e => { dirtyDraft(); setCause(e.target.value); }}>{['', '时间差', '录入差异', '口径待确认', '缺少资料', '重复记录待查', '其他'].map(v => <option key={v}>{v}</option>)}</select></label><label>人员（自填）<input value={person} onChange={e => { dirtyDraft(); setPerson(e.target.value); }}/></label><label>证据索引（不读附件/外链）<input value={evidence} onChange={e => { dirtyDraft(); setEvidence(e.target.value); }}/></label></div><label>追查说明<textarea value={note} onChange={e => { dirtyDraft(); setNote(e.target.value); }}/></label><label>本次操作依据<textarea value={reason} onChange={e => { dirtyDraft(); setReason(e.target.value); }}/></label><div className="d02-actions">{(currentReview?.status === '复核通过' ? ['追查中'] : currentReview?.status === '已说明待复核' ? ['追查中', '复核通过'] : currentReview?.status === '追查中' ? ['已说明待复核'] : ['追查中']).map(to => <button key={to} onClick={() => void act(() => { update({ ...s, run: review(run, identity(item), { to: to as ReviewStatus, cause, note, evidence, person, reason, at: new Date().toISOString() }) }); setPendingDraft(false); })}>{to === '追查中' ? (currentReview ? '退回／撤销通过' : '开始追查') : to}</button>)}</div><p className="d02-muted">说明/通过不改分类或原值。资料错误请回源更正后重新导入；重复整组不强配。</p><details><summary>复核历史（{currentReview?.events.length || 0}）</summary>{currentReview?.events.map((e, i) => <p key={i}>{localTime(e.at)} · {e.person} · {e.from}→{e.to}<br />{e.cause}；{e.note}；证据{e.evidence || '未填'}；依据{e.reason}</p>)}</details></> : <p>从左侧选择事项，查看双方原行和处理依据。</p>}</article></div></section>}
 {page === 4 && run && <section><h2>结果底稿</h2><p>{completion(run).label} · 未决{completion(run).pending}组 · 输入{run.input.join(' / ')}行，纳入{run.included.join(' / ')}行。复核记录为本机自填，结果不等于核销或入账。</p><div className="d02-actions"><button className="d02-primary" disabled={busy} onClick={() => void act(async () => { download('账表对账-全量底稿.xlsx', await exportWork(run, s.title) as BlobPart, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); setNotice('已发起下载：包含全部结果、排除行及未决事项。'); })}>下载全量XLSX底稿</button><button onClick={() => void act(() => {
                if (pendingDraft)
                    throw Error('有未提交的复核说明，请先应用复核操作，再保存工作底稿');
                download('账表对账-工作底稿-含数据.json', encodeWork(s));
                setSaved(true);
                setNotice('已发起含数据底稿下载，请确认文件已保存后离开。');
            })}>保存本次工作底稿（含数据）</button><button onClick={() => void act(() => download('账表对账-口径方案-无数据.json', encodeConfig(s.config)))}>保存口径方案（不含数据）</button></div><div className="d02-actions">{restoreInput('config')}{restoreInput('work')}</div><button disabled={!saved} onClick={() => {
                if (window.confirm('已确认含数据工作底稿文件实际保存成功？确认后关闭提醒解除；再次修改会重新提醒。')) {
                    control.dirty = false;
                    setNotice('已确认本次底稿已保存。');
                }
            }}>确认含数据底稿已保存</button><h3>底稿页签预览</h3><select aria-label="底稿页签" value={sheetPreview} onChange={e => setSheetPreview(Number(e.target.value))}>{workSheets(run, s.title).map((p, i) => <option key={p.name} value={i}>{p.name}（{p.rows.length}行）</option>)}</select>{(() => { const sheet = workSheets(run, s.title)[sheetPreview]; return <div className="d02-scroll"><table><thead><tr>{sheet.headers.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{sheet.rows.slice(0, 10).map((r, i) => <tr key={i}>{r.map((v, j) => <td key={j}>{value(v)}</td>)}</tr>)}</tbody></table><p>预览前10行；下载包含全部行。</p></div>; })()}<h3>选定范围导出</h3>{filtersUI}<button onClick={() => void act(async () => { const rows = found.flatMap(o => o.details.length ? o.details.map(d => [keyLabel(o.key), categoryLabel(o.category), d.field, d.normalizedLeft, d.normalizedRight, d.difference, run.reviews[identity(o)]?.status || '未复核',o.key,o.category]) : [[keyLabel(o.key), categoryLabel(o.category), '', '', '', '',run.reviews[identity(o)]?.status || '未复核',o.key,o.category]]); download('账表对账-选定范围.xlsx', await workbookBytes([{ name: '全量覆盖摘要', headers: ['项目', '内容'], rows: [['提示', '选定范围，不能作为全量底稿'], ['运行', run.id], ['查询', query], ['分类', cat==='全部'?'全部':categoryLabel(cat)], ['复核', status], ['全量纳入行', run.included.join(' / ')], ['选定组数', String(found.length)]] }, { name: '选定范围', headers: ['关联项', '分类', '字段', '第一方', '第二方', '差额', '复核状态','稳定关联键','内部分类'], rows }]) as BlobPart, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); })}>下载选定范围（{found.length}组）</button></section>}
 </fieldset><footer>资料仅保存在当前页面内存。主动下载文件请自行保管；离开前确认下载完成。</footer></div>;
}
export const program: ToolProgram = { id: 'D02', name: '账表对账', version: VERSION, mount({ container, onExit }) {
        const control: Control = { dirty: false, alive: true, urls: new Set(), timers: new Set() };
        const root = createRoot(container);
        root.render(<Workspace control={control} onExit={onExit}/>);
        return { requestExit() { return !control.dirty || window.confirm('离开将清除本次资料与复核记录。请先确认含数据工作底稿已下载。仍要离开吗？'); }, dispose() {
                if (!control.alive)
                    return;
                control.alive = false;
                root.unmount();
                for (const t of control.timers)
                    clearTimeout(t);
                for (const u of control.urls)
                    URL.revokeObjectURL(u);
                control.timers.clear();
                control.urls.clear();
                control.dirty = false;
            } };
    } };
