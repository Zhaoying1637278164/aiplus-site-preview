import { LIMITS, type Table, type Rule, type Cell } from '../../../packages/core/types';
import { amount } from '../../../packages/core/value';
import { decodePlan as decodeLegacy } from '../../../packages/core/plan';
import { VERSION, RULE_VERSION } from './version';
import { execute, review, type Config, type Run, type Session, type Scope, type ReviewEvent } from './workflow';
function object(v: unknown, keys: string[]) {
    if (!v || typeof v !== 'object' || Array.isArray(v) || Object.keys(v).some(k => !keys.includes(k)))
        throw Error('文件结构含未知字段');
    return v as Record<string, any>;
}
function str(v: unknown, max = 10000): string {
    if (typeof v !== 'string' || v.length > max)
        throw Error('文本类型或长度无效');
    return v;
}
function bool(v: unknown) {
    if (typeof v !== 'boolean')
        throw Error('布尔参数无效');
    return v;
}
function list(v: unknown, max: number) {
    if (!Array.isArray(v) || v.length > max)
        throw Error('列表超过限制或格式错误');
    return v;
}
function pair(v: unknown): [
    string,
    string
] {
    const a = list(v, 2);
    if (a.length !== 2)
        throw Error('两方参数缺失');
    return [str(a[0]), str(a[1])];
}
function parse(raw: string) {
    if (new TextEncoder().encode(raw).length > LIMITS.bytes)
        throw Error('恢复文件超过10MB');
    try {
        return JSON.parse(raw);
    }
    catch {
        throw Error('不是有效JSON');
    }
}
export function configValue(v: unknown): Config {
    const c = object(v, ['names', 'rule', 'scope']);
    const r = object(c.rule, ['schema_version', 'tool', 'keys', 'fields', 'currency', 'tolerance', 'trim', 'ignoreCase']);
    if (r.schema_version !== 1 || r.tool !== 'D02')
        throw Error('规则结构版本不支持');
    const map = (v: unknown) => list(v, 30).map(v => {
        const m = object(v, ['left', 'right', 'type']);
        if (!['text', 'amount', 'date'].includes(m.type))
            throw Error('映射类型无效');
        return { left: str(m.left), right: str(m.right), type: m.type };
    });
    const keys = map(r.keys), fields = map(r.fields);
    if (!keys.length || !fields.length || keys.length + fields.length > 30 || keys.some(m => m.type !== 'text'))
        throw Error('关联和比较映射无效');
    const currency = object(r.currency, ['left', 'right']);
    const tolerance = str(r.tolerance);
    if (amount(tolerance).isNegative())
        throw Error('容差不能负数');
    const s = object(c.scope, ['entity', 'periods', 'unit', 'basis', 'tax', 'grain', 'crossPeriod', 'purpose', 'confirmed', 'filters']);
    if (!['发生额', '余额'].includes(s.basis) || !['含税', '不含税'].includes(s.tax))
        throw Error('金额口径无效');
    const filters = list(s.filters, 20).map(v => {
        const f = object(v, ['side', 'field', 'kind', 'values', 'from', 'to']);
        if (![0, 1].includes(f.side) || !['date', 'values'].includes(f.kind))
            throw Error('范围筛选无效');
        return { side: f.side, field: str(f.field), kind: f.kind, values: list(f.values, 20000).map(v => str(v)), from: str(f.from), to: str(f.to) };
    });
    return { names: pair(c.names), rule: { schema_version: 1, tool: 'D02', keys, fields, currency: { left: str(currency.left), right: str(currency.right) }, tolerance, trim: bool(r.trim), ignoreCase: bool(r.ignoreCase) }, scope: { entity: str(s.entity), periods: pair(s.periods), unit: str(s.unit), basis: s.basis, tax: s.tax, grain: str(s.grain), crossPeriod: bool(s.crossPeriod), purpose: str(s.purpose), confirmed: bool(s.confirmed), filters } };
}
function tableValue(v: unknown): Table {
    const t = object(v, ['file', 'sheet', 'headers', 'rows']);
    const file = str(t.file), sheet = str(t.sheet), headers = list(t.headers, LIMITS.columns).map(v => str(v));
    if (!headers.length || new Set(headers).size !== headers.length || headers.some(h => !h.trim()))
        throw Error('来源表头无效');
    const seen = new Set<number>();
    const rows = list(t.rows, LIMITS.rows).map(v => {
        const r = object(v, ['file', 'sheet', 'row', 'cells']);
        if (r.file !== file || r.sheet !== sheet || !Number.isSafeInteger(r.row) || r.row < 1 || seen.has(r.row))
            throw Error('来源行标识无效');
        seen.add(r.row);
        const cells = object(r.cells, headers);
        if (Object.keys(cells).length !== headers.length)
            throw Error('来源列不完整');
        const checked: Record<string, Cell> = Object.create(null);
        for (const h of headers) {
            const x = cells[h];
            if (x === null || typeof x === 'string')
                checked[h] = x === null ? null : str(x);
            else if (typeof x === 'number') {
                if (!Number.isFinite(x))
                    throw Error('数值无效');
                checked[h] = x;
            }
            else {
                const f = object(x, ['formula', 'cached']);
                const cached = f.cached;
                if (cached !== null && typeof cached !== 'string' && typeof cached !== 'number' && typeof cached !== 'boolean')
                    throw Error('公式缓存格式无效');
                checked[h] = { formula: str(f.formula), cached };
            }
        }
        return { file, sheet, row: r.row, cells: Object.fromEntries(Object.entries(checked)) };
    });
    if (!rows.length)
        throw Error('来源表不能为空');
    return { file, sheet, headers, rows };
}
function output(v: unknown) {
    const raw = JSON.stringify(v, null, 2);
    if (new TextEncoder().encode(raw).length > LIMITS.bytes)
        throw Error('下载底稿超过10MB恢复上限；请导出XLSX并缩小事项范围');
    return raw;
}
export function encodeConfig(config: Config) { const c = structuredClone(config); c.names = ['第一方资料', '第二方资料']; c.scope.entity = ''; c.scope.periods = ['', '']; c.scope.purpose = ''; c.scope.confirmed = false; c.scope.filters = c.scope.filters.map(f => ({ ...f, values: [], from: "", to: "" })); return output({ schema_version: 2, tool: 'D02', app_version: VERSION, rule_version: RULE_VERSION, contains_data: false, config: c }); }
export function decodeConfig(raw: string): {
    config: Config;
    legacy: boolean;
} {
    const p = parse(raw);
    if (p?.schema_version === 1) {
        object(p, ['schema_version', 'tool', 'contains_data', 'app_version', 'rule_version', 'rule']);
        const legacy = decodeLegacy(raw);
        const checked = configValue({ names: ['第一方资料', '第二方资料'], rule: legacy, scope: { entity: '', periods: ['', ''], unit: '', basis: '发生额', tax: '不含税', grain: '', crossPeriod: false, purpose: '', confirmed: false, filters: [] } });
        const rule = checked.rule;
        return { legacy: true, config: { names: ['第一方资料', '第二方资料'], rule, scope: { entity: '', periods: ['', ''], unit: '', basis: '发生额', tax: '不含税', grain: '', crossPeriod: false, purpose: '', confirmed: false, filters: [] } } };
    }
    object(p, ['schema_version', 'tool', 'app_version', 'rule_version', 'contains_data', 'config']);
    if (p.schema_version !== 2 || p.tool !== 'D02' || p.app_version !== VERSION || p.rule_version !== RULE_VERSION || p.contains_data !== false)
        throw Error('仅接受当前无数据方案或明确兼容的0.1.0旧方案');
    const config = configValue(p.config);
    if (config.scope.entity || config.scope.periods.some(Boolean) || config.scope.purpose || config.scope.confirmed || config.scope.filters.some(f => f.values.length || f.from || f.to))
        throw Error('无数据方案含事项数据');
    return { config, legacy: false };
}
export function encodeWork(session: Session) {
    if (!session.run || session.tables.some(t => !t))
        throw Error('请先生成当前结果再保存工作底稿');
    return output({ schema_version: 2, tool: 'D02', app_version: VERSION, rule_version: RULE_VERSION, contains_data: true, title: session.title, tables: session.tables, run: session.run });
}
function stable(v: any): string {
    if (Array.isArray(v))
        return '[' + v.map(stable).join(',') + ']';
    if (v && typeof v === 'object')
        return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
    return JSON.stringify(v);
}
export function decodeWork(raw: string): Session {
    const p = object(parse(raw), ['schema_version', 'tool', 'app_version', 'rule_version', 'contains_data', 'title', 'tables', 'run']);
    if (p.schema_version !== 2 || p.tool !== 'D02' || p.app_version !== VERSION || p.rule_version !== RULE_VERSION || p.contains_data !== true)
        throw Error('工作底稿版本或数据标识不兼容');
    const a = list(p.tables, 2);
    if (a.length !== 2)
        throw Error('工作底稿缺少来源');
    const tables = a.map(tableValue) as [
        Table,
        Table
    ];
    const saved = object(p.run, ['id', 'config', 'result', 'excluded', 'input', 'included', 'sums', 'sourceSums', 'reviews']);
    const config = configValue(saved.config);
    let run = execute(tables, config, str(saved.id, 200));
    for (const k of ['result', 'excluded', 'input', 'included', 'sums', 'sourceSums'] as const)
        if (stable(run[k]) !== stable(saved[k]))
            throw Error('工作底稿结果与来源重算不一致：' + k);
    const reviews = object(saved.reviews, run.result.outcomes.map(o => JSON.stringify([o.key, o.left.map(r => [r.file, r.sheet, r.row]), o.right.map(r => [r.file, r.sheet, r.row])])));
    for (const [key, value] of Object.entries(reviews)) {
        const rv = object(value, ['status', 'events']);
        const events = list(rv.events, 100);
        if (!events.length)
            throw Error('复核历史缺失');
        for (const e of events) {
            const event = object(e, ['from', 'to', 'reason', 'note', 'cause', 'evidence', 'person', 'at']);
            if (event.from !== (run.reviews[key]?.status || '未复核'))
                throw Error('复核历史起点不一致');
            if (!['未复核', '追查中', '已说明待复核', '复核通过'].includes(event.to))
                throw Error('复核状态无效');
            run = review(run, key, { to: event.to, reason: str(event.reason), note: str(event.note), cause: str(event.cause), evidence: str(event.evidence), person: str(event.person), at: str(event.at) });
        }
        if (run.reviews[key].status !== rv.status)
            throw Error('复核历史与末态不一致');
    }
    return { title: str(p.title), tables, config, run, previous: null, revision: 0 };
}
