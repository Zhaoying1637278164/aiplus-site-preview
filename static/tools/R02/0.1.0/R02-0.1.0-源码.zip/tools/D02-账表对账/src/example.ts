import type {Table} from '../../../packages/core/types';
export function table(file:string,records:Record<string,string|null>[]):Table{
 return {file,sheet:'虚构示例',headers:['单据号','金额','日期','币种'],rows:records.map((cells,i)=>({file,sheet:'虚构示例',row:i+2,cells}))};
}
const row=(id:string,amt:string|null,currency='CNY')=>({'单据号':id,'金额':amt,'日期':'2026-09-30','币种':currency});
export const leftExample=table('虚构左表.xlsx',[row('001','100.10'),row('002','200'),row('003','-50'),row('004','10'),row('004','20'),row('005',null),row('006','0')]);
export const rightExample=table('虚构右表.xlsx',[row('001','100.10'),row('002','210'),row('004','30'),row('005','40'),row('007','15'),row('006','0')]);
