export const VERSION = '0.2.0';
export const RULE_VERSION = 'D02-2026-10-03.2';
