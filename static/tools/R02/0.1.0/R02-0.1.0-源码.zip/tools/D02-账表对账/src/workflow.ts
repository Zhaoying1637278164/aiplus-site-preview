import Decimal from 'decimal.js';
import { amount, date, text } from '../../../packages/core/value';
import { LIMITS, type Table, type Rule, type SourceRow } from '../../../packages/core/types';
import { calculate, validateRule, type Result } from './engine';
import { VERSION, RULE_VERSION } from './version';
export interface Filter {
    side: 0 | 1;
    field: string;
    kind: 'values' | 'date';
    values: string[];
    from: string;
    to: string;
}
export interface Scope {
    entity: string;
    periods: [
        string,
        string
    ];
    unit: string;
    basis: '发生额' | '余额';
    tax: '含税' | '不含税';
    grain: string;
    crossPeriod: boolean;
    purpose: string;
    confirmed: boolean;
    filters: Filter[];
}
export interface Config {
    names: [
        string,
        string
    ];
    rule: Rule;
    scope: Scope;
}
export interface Excluded {
    side: 0 | 1;
    source: SourceRow;
    reasons: string[];
}
export interface ReviewEvent {
    from: ReviewStatus;
    to: ReviewStatus;
    reason: string;
    note: string;
    cause: string;
    evidence: string;
    person: string;
    at: string;
}
export type ReviewStatus = '未复核' | '追查中' | '已说明待复核' | '复核通过';
export interface Review {
    status: ReviewStatus;
    events: ReviewEvent[];
}
export interface Sum {
    currency: string;
    field: string;
    paired: number;
    left: string | null;
    right: string | null;
    difference: string | null;
    withinTolerance: string | null;
    different: string | null;
    singleLeft: string | null;
    singleRight: string | null;
    uncomparableLeft: number;
    uncomparableRight: number;
}
export interface SourceSum {
    inputRows: number;
    includedRows: number;
    excludedRows: number;
    side: 0 | 1;
    currency: string;
    field: string;
    input: string | null;
    included: string | null;
    excluded: string | null;
    paired: string | null;
    single: string | null;
    uncomparable: string | null;
    invalidInput: number;
    invalidIncluded: number;
    invalidExcluded: number;
}
export interface Run {
    id: string;
    config: Config;
    result: Result;
    excluded: Excluded[];
    input: [
        number,
        number
    ];
    included: [
        number,
        number
    ];
    sums: Sum[];
    sourceSums: SourceSum[];
    reviews: Record<string, Review>;
}
export interface Session {
    title: string;
    tables: [
        Table | null,
        Table | null
    ];
    config: Config;
    run: Run | null;
    previous: Run | null;
    revision: number;
}
export const emptyScope = (): Scope => ({ entity: '', periods: ['', ''], unit: '', basis: '发生额', tax: '不含税', grain: '', crossPeriod: false, purpose: '', confirmed: false, filters: [] });
export function identity(o: Result['outcomes'][number]) { return JSON.stringify([o.key, o.left.map(r => [r.file, r.sheet, r.row]), o.right.map(r => [r.file, r.sheet, r.row])]); }
export function invalidate(s: Session): Session { return { ...s, run: null, previous: s.run || s.previous, revision: s.revision + 1, config: { ...s.config, scope: { ...s.config.scope, confirmed: false } } }; }
export function checkScope(c: Config, tables: [
    Table,
    Table
]) {
    const s = c.scope;
    if (s.filters.length > 20)
        throw Error('范围条件超过20项');
    if (!c.names.every(n => n.trim()) || !s.entity.trim() || !s.unit.trim() || !s.grain.trim() || !s.periods.every(p => p.trim()))
        throw Error('请填写两方名称、主体、双方期间、单位与每行粒度');
    if (!s.confirmed)
        throw Error('请确认本次范围与口径');
    if (s.periods[0] !== s.periods[1] && (!s.crossPeriod || !s.purpose.trim()))
        throw Error('期间不同：请明确跨期追查目的，否则不能核对');
    if (!['发生额', '余额'].includes(s.basis) || !['含税', '不含税'].includes(s.tax))
        throw Error('金额口径无效');
    validateRule(c.rule, ...tables);
    const mappings = [...c.rule.keys, ...c.rule.fields];
    if (new Set(mappings.map(m => m.left)).size !== mappings.length || new Set(mappings.map(m => m.right)).size !== mappings.length)
        throw Error('同一来源列重复对应，请检查关联项与比较项');
    for (const f of s.filters) {
        if (!tables[f.side].headers.includes(f.field))
            throw Error('筛选字段不存在');
        if (f.kind === 'values' && !f.values.length)
            throw Error('筛选值不能为空');
        if (f.kind === 'date') {
            date(f.from);
            date(f.to);
            if (f.from > f.to)
                throw Error('日期区间开始晚于结束');
        }
    }
}
export function select(tables: [
    Table,
    Table
], filters: Filter[]) {
    const excluded: Excluded[] = [];
    const selected = tables.map((t, side) => ({ ...t, rows: t.rows.filter(row => {
            const reasons: string[] = [];
            for (const f of filters.filter(f => f.side === side)) {
                const value = row.cells[f.field];
                if (value === null || value === undefined || typeof value === 'object')
                    throw Error(`${t.file} / ${t.sheet} 第${row.row}行：范围字段${f.field}无效，请补资料`);
                if (f.kind === 'date') {
                    let d: string;
                    try {
                        d = date(value);
                    }
                    catch {
                        throw Error(`第${row.row}行范围日期无效`);
                    }
                    if (d < f.from || d > f.to)
                        reasons.push(`${f.field}不在${f.from}至${f.to}`);
                }
                else if (!f.values.includes(String(value)))
                    reasons.push(`${f.field}未选择（${String(value)}）`);
            }
            if (reasons.length)
                excluded.push({ side: side as 0 | 1, source: row, reasons });
            return !reasons.length;
        }) })) as [
        Table,
        Table
    ];
    return { selected, excluded };
}
export function summaries(result: Result): Sum[] {
    const sums = new Map<string, Sum>();
    for (const o of result.outcomes)
        for (const m of result.rule.fields.filter(m => m.type === 'amount')) {
            const get = (currency: string) => {
                const key = JSON.stringify([currency, m.left, m.right]);
                let s = sums.get(key);
                if (!s) {
                    s = { currency, field: m.left + ' ↔ ' + m.right, paired: 0, left: currency === '币种无效' ? null : '0', right: currency === '币种无效' ? null : '0', difference: currency === '币种无效' ? null : '0', withinTolerance: currency === '币种无效' ? null : '0', different: currency === '币种无效' ? null : '0', singleLeft: currency === '币种无效' ? null : '0', singleRight: currency === '币种无效' ? null : '0', uncomparableLeft: 0, uncomparableRight: 0 };
                    sums.set(key, s);
                }
                return s;
            };
            const add = (s: Sum, k: 'left' | 'right' | 'difference' | 'withinTolerance' | 'different' | 'singleLeft' | 'singleRight', v: string) => { s[k] = new Decimal(s[k]!).plus(v).toFixed(); };
            if (o.category === '匹配一致' || o.category === '字段差异') {
                const d = o.details.find(d => d.field === m.left + ' ↔ ' + m.right)!;
                const s = get(String(o.left[0].cells[result.rule.currency.left]));
                s.paired++;
                add(s, 'left', d.normalizedLeft);
                add(s, 'right', d.normalizedRight);
                add(s, 'difference', d.difference);
                add(s, d.equal ? 'withinTolerance' : 'different', d.difference);
            }
            else
                for (const side of ['left', 'right'] as const)
                    for (const row of o[side]) {
                        const currency = String(row.cells[result.rule.currency[side]] ?? '未知');
                        const s = get(/^[A-Z]{3}$/.test(currency) ? currency : '币种无效');
                        if (o.category === '仅左侧' || o.category === '仅右侧') {
                            add(s, side === 'left' ? 'singleLeft' : 'singleRight', amount(row.cells[m[side]]).toFixed());
                        }
                        else
                            s[side === 'left' ? 'uncomparableLeft' : 'uncomparableRight']++;
                    }
        }
    for (const s of sums.values()) {
        if (s.currency !== '币种无效' && (!new Decimal(s.left!).minus(s.right!).eq(s.difference!) || !new Decimal(s.withinTolerance!).plus(s.different!).eq(s.difference!)))
            throw Error('金额勾稽失败');
    }
    return [...sums.values()];
}
export function sourceSummaries(tables: [
    Table,
    Table
], result: Result, excluded: Excluded[]): SourceSum[] {
    const output = new Map<string, SourceSum>();
    const classification = new Map<string, string>();
    for (const o of result.outcomes)
        for (const side of ['left', 'right'] as const)
            for (const r of o[side])
                classification.set(JSON.stringify([side === 'left' ? 0 : 1, r.row]), o.category);
    const excludedRows = new Set(excluded.map(e => JSON.stringify([e.side, e.source.row])));
    for (const side of [0, 1] as const)
        for (const row of tables[side].rows)
            for (const m of result.rule.fields.filter(m => m.type === 'amount')) {
                const role = side === 0 ? 'left' : 'right';
                const rawCurrency = String(row.cells[result.rule.currency[role]] ?? '');
                const currency = /^[A-Z]{3}$/.test(rawCurrency) ? rawCurrency : '币种无效';
                const field = m.left + ' ↔ ' + m.right;
                const key = JSON.stringify([side, currency, field]);
                let item = output.get(key);
                if (!item) {
                    item = { side, currency, field, inputRows: 0, includedRows: 0, excludedRows: 0, input: currency === '币种无效' ? null : '0', included: currency === '币种无效' ? null : '0', excluded: currency === '币种无效' ? null : '0', paired: currency === '币种无效' ? null : '0', single: currency === '币种无效' ? null : '0', uncomparable: currency === '币种无效' ? null : '0', invalidInput: 0, invalidIncluded: 0, invalidExcluded: 0 };
                    output.set(key, item);
                }
                const removed = excludedRows.has(JSON.stringify([side, row.row]));
                item.inputRows++;
                item[removed ? 'excludedRows' : 'includedRows']++;
                let v: string;
                try {
                    v = amount(row.cells[m[role]]).toFixed();
                }
                catch {
                    item.invalidInput++;
                    item[removed ? 'invalidExcluded' : 'invalidIncluded']++;
                    continue;
                }
                if (currency === '币种无效')
                    continue;
                const add = (k: 'input' | 'included' | 'excluded' | 'paired' | 'single' | 'uncomparable') => { item![k] = new Decimal(item![k]!).plus(v).toFixed(); };
                add('input');
                add(removed ? 'excluded' : 'included');
                if (!removed) {
                    const c = classification.get(JSON.stringify([side, row.row]));
                    add(c === '匹配一致' || c === '字段差异' ? 'paired' : c === '仅左侧' || c === '仅右侧' ? 'single' : 'uncomparable');
                }
            }
    for (const item of output.values()) {
        if (item.inputRows !== item.includedRows + item.excludedRows || item.invalidInput !== item.invalidIncluded + item.invalidExcluded)
            throw Error('来源数量勾稽失败');
        if (item.currency !== '币种无效' && (!new Decimal(item.included!).plus(item.excluded!).eq(item.input!) || !new Decimal(item.paired!).plus(item.single!).plus(item.uncomparable!).eq(item.included!)))
            throw Error('来源金额勾稽失败');
    }
    return [...output.values()];
}
export function execute(tables: [
    Table,
    Table
], config: Config, id: string): Run {
    checkScope(config, tables);
    const { selected, excluded } = select(tables, config.scope.filters);
    if (selected.some(t => !t.rows.length))
        throw Error('筛选后有一方无数据，不能作为一致结果');
    const result = calculate(...selected, config.rule);
    return { id, config: structuredClone(config), result, excluded, input: [tables[0].rows.length, tables[1].rows.length], included: [selected[0].rows.length, selected[1].rows.length], sums: summaries(result), sourceSums: sourceSummaries(tables, result, excluded), reviews: {} };
}
const transitions: Record<ReviewStatus, ReviewStatus[]> = { '未复核': ['追查中'], '追查中': ['已说明待复核'], '已说明待复核': ['追查中', '复核通过'], '复核通过': ['追查中'] };
export function review(run: Run, key: string, event: Omit<ReviewEvent, 'from'>): Run {
    if (!run.result.outcomes.some(o => identity(o) === key))
        throw Error('复核记录无对应事项');
    const prior = run.reviews[key] || { status: '未复核' as const, events: [] };
    if (!transitions[prior.status].includes(event.to))
        throw Error('复核状态不能跳步');
    if (!event.person.trim() || !event.reason.trim() || !event.at.trim())
        throw Error('人员与操作依据必填');
    if ((event.to === '已说明待复核' || event.to === '复核通过') && (!event.note.trim() || !event.cause.trim()))
        throw Error('差异原因与说明必填');
    if (Object.values(run.reviews).reduce((n, r) => n + r.events.length, 0) >= 10000)
        throw Error('本次复核历史超过10000条，请另存底稿');
    if ([event.reason, event.note, event.cause, event.evidence, event.person].some(v => v.length > 10000))
        throw Error('复核文本超过10000字');
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(event.at) || !Number.isFinite(Date.parse(event.at)))
        throw Error('复核时间无效');
    if (prior.events.length >= 100)
        throw Error('单项历史超过100条，请另存底稿');
    return { ...run, reviews: { ...run.reviews, [key]: { status: event.to, events: [...prior.events, { ...event, from: prior.status }] } } };
}
export function completion(run: Run) {
    const bad = run.result.outcomes.some(o => o.category === '重复/歧义' || o.category === '无效输入');
    const pending = run.result.outcomes.filter(o => o.category !== '匹配一致' && run.reviews[identity(o)]?.status !== '复核通过').length;
    return { pending, label: bad ? '复核意见可记录，资料仍不可比' : pending ? '追查中／含未决事项' : '本次核对已复核' };
}
export function diagnostics(t: Table, rule: Rule, side: 'left' | 'right') {
    const counts = new Map<string, number>();
    let invalid = 0;
    const raw = new Map<string, Set<string>>();
    for (const row of t.rows)
        try {
            const values = rule.keys.map(m => text(row.cells[m[side]], rule.trim, rule.ignoreCase));
            const key = JSON.stringify(values);
            counts.set(key, (counts.get(key) || 0) + 1);
            const set = raw.get(key) || new Set();
            set.add(JSON.stringify(rule.keys.map(m => row.cells[m[side]])));
            raw.set(key, set);
        }
        catch {
            invalid++;
        }
    return { duplicateGroups: [...counts.values()].filter(n => n > 1).length, invalid, collisions: [...raw.values()].filter(s => s.size > 1).length };
}
export function search(run: Run, query: string, category: string, status: string) { return run.result.outcomes.filter(o => (category === '全部' || o.category === category) && (status === '全部' || (run.reviews[identity(o)]?.status || '未复核') === status) && (!query || JSON.stringify([o.key, o.left, o.right]).toLocaleLowerCase().includes(query.toLocaleLowerCase()))); }
