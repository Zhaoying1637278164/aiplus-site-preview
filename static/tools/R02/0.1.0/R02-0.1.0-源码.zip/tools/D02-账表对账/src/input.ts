import { LIMITS } from '../../../packages/core/types';
export function checkFileSize(size: number) { if (!Number.isSafeInteger(size) || size < 0 || size > LIMITS.bytes)
    throw Error('文件超过10MB或体积无效，未读取'); }
export async function readBytes(file: Pick<File, 'size' | 'arrayBuffer'>): Promise<Uint8Array> { checkFileSize(file.size); return new Uint8Array(await file.arrayBuffer()); }
export async function readText(file: Pick<File, 'size' | 'text'>): Promise<string> { checkFileSize(file.size); return file.text(); }
