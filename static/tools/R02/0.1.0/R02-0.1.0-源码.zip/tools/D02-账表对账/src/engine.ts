import {amount,date,text} from '../../../packages/core/value';
import {LIMITS} from '../../../packages/core/types';
import {RULE_VERSION,VERSION} from './version';
import type {Rule,Table,Mapping,SourceRow,Cell} from '../../../packages/core/types';
export const CATEGORIES=['匹配一致','字段差异','仅左侧','仅右侧','重复/歧义','无效输入'] as const;
export type Category=typeof CATEGORIES[number];
export interface Detail{field:string;left:Cell;right:Cell;normalizedLeft:string;normalizedRight:string;difference:string;equal:boolean}
export interface Outcome{category:Category;key:string;left:SourceRow[];right:SourceRow[];details:Detail[];issues:string[]}
export interface Result{tool:'D02';app_version:string;rule_version:string;rule:Rule;outcomes:Outcome[];counts:Record<Category,{groups:number;left:number;right:number}>;coverage:{left:number;right:number}}
export const defaultRule:Rule={schema_version:1,tool:'D02',keys:[{left:'单据号',right:'单据号',type:'text'}],fields:[{left:'金额',right:'金额',type:'amount'},{left:'日期',right:'日期',type:'date'}],currency:{left:'币种',right:'币种'},tolerance:'0',trim:false,ignoreCase:false};
export function validateRule(rule:Rule,left:Table,right:Table){
 if(rule?.schema_version!==1||rule?.tool!=='D02')throw Error('不支持的方案版本或工具');
 if(!Array.isArray(rule.keys)||!Array.isArray(rule.fields)||!rule.keys.length||!rule.fields.length)throw Error('至少选择一个匹配键和比较字段');
 if(rule.keys.length+rule.fields.length>30)throw Error('映射超过30项');
 if(typeof rule.trim!=='boolean'||typeof rule.ignoreCase!=='boolean')throw Error('文本设置无效');
 for(const m of [...rule.keys,...rule.fields]){
 if(!m||!['text','date','amount'].includes(m.type)||!left.headers.includes(m.left)||!right.headers.includes(m.right))throw Error('字段映射不存在或类型无效');
 }
 if(rule.keys.some(m=>m.type!=='text'))throw Error('匹配键必须显式使用文本类型');
 if(!rule.currency||!left.headers.includes(rule.currency.left)||!right.headers.includes(rule.currency.right))throw Error('必须映射两侧币种列');
 if(amount(rule.tolerance).isNegative())throw Error('容差不能为负');
}
function normalize(v:Cell,m:Mapping,rule:Rule):string{
 return m.type==='amount'?amount(v).toFixed():m.type==='date'?date(v):text(v,rule.trim,rule.ignoreCase);
}
export function calculate(left:Table,right:Table,rule:Rule):Result{
 validateRule(rule,left,right);if(left.rows.length>LIMITS.rows||right.rows.length>LIMITS.rows)throw Error('行数超过限制');
 const outcomes:Outcome[]=[];
 const groups=new Map<string,{left:SourceRow[];right:SourceRow[];errors:string[]}>();
 for(const side of ['left','right'] as const){
 const table=side==='left'?left:right;
 for(const row of table.rows){
 let key='';const issues:string[]=[];
 try{key=JSON.stringify(rule.keys.map(m=>normalize(row.cells[m[side]],m,rule)));}catch(e){issues.push('匹配键：'+(e as Error).message);}
 for(const m of rule.fields)try{normalize(row.cells[m[side]],m,rule);}catch(e){issues.push(m[side]+'：'+(e as Error).message);}
 try{const c=text(row.cells[rule.currency[side]]);if(!/^[A-Z]{3}$/.test(c))throw Error('币种须为3位大写代码，例如CNY');}catch(e){issues.push((e as Error).message);}
 if(!key){outcomes.push({category:'无效输入',key:'',left:side==='left'?[row]:[],right:side==='right'?[row]:[],details:[],issues});continue;}
 const group=groups.get(key)||{left:[],right:[],errors:[]};group[side].push(row);group.errors.push(...issues.map(x=>side+' 第'+row.row+'行 '+x));groups.set(key,group);
 }
 }
 for(const [key,g]of groups){
 const o:Outcome={category:'匹配一致',key,left:g.left,right:g.right,details:[],issues:g.errors};
 // Group invalid fields with their valid counterpart; never silently classify counterpart as missing.
 if(g.left.length>1||g.right.length>1){o.category='重复/歧义';o.issues.push('同键多条记录，整组待确认，不强配、不抵消');}
 else if(g.errors.length)o.category='无效输入';
 else if(!g.left.length)o.category='仅右侧';else if(!g.right.length)o.category='仅左侧';
 else{
 const l=g.left[0],r=g.right[0];
 if(l.cells[rule.currency.left]!==r.cells[rule.currency.right]){o.category='无效输入';o.issues.push('币种不同，已阻断金额比较');}
 else for(const m of rule.fields){
 const lv=l.cells[m.left],rv=r.cells[m.right],nl=normalize(lv,m,rule),nr=normalize(rv,m,rule);
 const diff=m.type==='amount'?amount(lv).minus(amount(rv)).toFixed():'';
 const equal=m.type==='amount'?amount(lv).minus(amount(rv)).abs().lte(amount(rule.tolerance)):nl===nr;
 o.details.push({field:m.left+' ↔ '+m.right,left:lv,right:rv,normalizedLeft:nl,normalizedRight:nr,difference:diff,equal});if(!equal)o.category='字段差异';
 }
 }outcomes.push(o);
 }
 const counts=Object.fromEntries(CATEGORIES.map(c=>[c,{groups:0,left:0,right:0}])) as Result['counts'];
 for(const o of outcomes){counts[o.category].groups++;counts[o.category].left+=o.left.length;counts[o.category].right+=o.right.length;}
 const coverage={left:outcomes.reduce((s,o)=>s+o.left.length,0),right:outcomes.reduce((s,o)=>s+o.right.length,0)};
 if(coverage.left!==left.rows.length||coverage.right!==right.rows.length)throw Error('分类行数回勾失败');
 return {tool:'D02',app_version:VERSION,rule_version:RULE_VERSION,rule:structuredClone(rule),outcomes,counts,coverage};
}
