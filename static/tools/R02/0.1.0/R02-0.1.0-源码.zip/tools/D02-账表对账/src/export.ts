import {workbookBytes} from '../../../packages/core/io';
import {CATEGORIES,type Result} from './engine';
export async function exportResult(result:Result):Promise<Uint8Array>{
 const sheets=[{name:'说明与口径',headers:['项目','内容'],rows:[['工具','D02 双表核对助手'],['应用版本',result.app_version],['规则版本',result.rule_version],['金额方向','左减右；金额列为十进制文本避免Excel精度变化'],['币种','不同币种阻断比较；不自动换汇'],['公式','公式单元格不执行，不采用缓存'],['范围','确定性一对一核对；重复整组待确认；不做核销或审计判断']]},
 {name:'运行统计',headers:['分类','组数','左行数','右行数'],rows:CATEGORIES.map(c=>[c,result.counts[c].groups,result.counts[c].left,result.counts[c].right])},
 {name:'规则参数',headers:['规则JSON'],rows:[[JSON.stringify(result.rule)]]}];
 for(const category of CATEGORIES){const rows:unknown[][]=[];
 for(const o of result.outcomes.filter(o=>o.category===category)){
 for(const side of ['left','right'] as const)for(const r of o[side])rows.push([o.key,side,r.file,r.sheet,r.row,JSON.stringify(r.cells),JSON.stringify(o.details),o.issues.join('；')]);
 }
 sheets.push({name:category.replace('/','_'),headers:['复合键','来源侧','文件','页签','原始行号','原始值JSON','逐字段原值/规范值/差额/判定','异常'],rows:rows as any});
 }
 return workbookBytes(sheets);
}
