import {keyLabel,categoryLabel,localTime} from './display';
import { workbookBytes } from '../../../packages/core/io';
import { identity, completion, type Run } from './workflow';
import { VERSION, RULE_VERSION } from './version';
export function workSheets(run: Run, title: string) {
    const outcomeKeys = new Map(run.result.outcomes.map(o => [identity(o), o.key]));
    const rows = run.result.outcomes.flatMap(o => {
        const pairs = o.details.length ? o.details : [null];
        return pairs.flatMap(d => (['left', 'right'] as const).flatMap(side => o[side].map(r => [keyLabel(o.key), categoryLabel(o.category), run.config.names[side === 'left' ? 0 : 1], r.file, r.sheet, r.row, d?.field || '', d?.left ?? '', d?.right ?? '', d?.normalizedLeft || '', d?.normalizedRight || '', d?.difference || '', d ? (d.equal ? '容差内／相同' : '差异') : '不可配对', o.issues.join('；'), run.reviews[identity(o)]?.status || '未复核', JSON.stringify(r.cells),o.key,o.category])));
    });
    return [
        { name: '事项与口径', headers: ['项目', '内容'], rows: [['事项', title], ['结论', completion(run).label], ['运行时间（本机）', localTime(run.id)],['运行标识',run.id], ['应用版本', VERSION], ['规则版本', RULE_VERSION], ['主体', run.config.scope.entity], ['期间', run.config.scope.periods.join(' / ')], ['单位', run.config.scope.unit], ['金额口径', run.config.scope.basis + ' / ' + run.config.scope.tax], ['粒度', run.config.scope.grain], ['跨期目的', run.config.scope.purpose], ['差额方向', run.config.names.join(' 减 ')], ['规则', JSON.stringify(run.config.rule)], ['限制', '复核记录为本机自填；不代表账务准确、核销、入账或身份签名']] },
        { name: '行数勾稽', headers: ['来源', '输入', '纳入', '排除', '六类覆盖'], rows: ([0, 1] as const).map(i => [run.config.names[i], run.input[i], run.included[i], run.excluded.filter(e => e.side === i).length, i === 0 ? run.result.coverage.left : run.result.coverage.right]) },
        { name: '分类统计', headers: ['分类', '组数', '第一方行', '第二方行','内部分类'], rows: Object.entries(run.result.counts).map(([c, v]) => [categoryLabel(c), v.groups, v.left, v.right,c]) },
        { name: '金额勾稽', headers: ['币种', '金额字段', '有效配对数', '第一方配对金额', '第二方配对金额', '原始差额', '容差内差额', '超差额', '第一方单侧金额', '第二方单侧金额', '第一方不可比行', '第二方不可比行'], rows: run.sums.map(s => [s.currency, s.field, s.paired ?? '不可汇总', s.left ?? '不可汇总', s.right ?? '不可汇总', s.difference ?? '不可汇总', s.withinTolerance ?? '不可汇总', s.different ?? '不可汇总', s.singleLeft ?? '不可汇总', s.singleRight ?? '不可汇总', s.uncomparableLeft, s.uncomparableRight]) },
        { name: '来源金额守恒', headers: ['来源', '币种', '金额字段', '输入可计金额', '纳入可计金额', '排除可计金额', '配对可计金额', '单侧可计金额', '不可比参考金额', '输入无效金额行', '纳入无效金额行', '排除无效金额行', '输入行数', '纳入行数', '排除行数'], rows: run.sourceSums.map(s => [run.config.names[s.side], s.currency, s.field, s.input ?? '不可汇总', s.included ?? '不可汇总', s.excluded ?? '不可汇总', s.paired ?? '不可汇总', s.single ?? '不可汇总', s.uncomparable ?? '不可汇总', s.invalidInput, s.invalidIncluded, s.invalidExcluded, s.inputRows, s.includedRows, s.excludedRows]) },
        { name: '全量核对明细', headers: ['关联项', '分类', '来源角色', '文件', '页签', '原行号', '比较字段', '第一方原值', '第二方原值', '第一方规范值', '第二方规范值', '差额', '字段判定', '问题', '复核状态', '全部来源值','稳定关联键','内部分类'], rows },
        { name: '排除来源', headers: ['来源角色', '文件', '页签', '原行号', '排除理由', '全部来源值'], rows: run.excluded.map(e => [run.config.names[e.side], e.source.file, e.source.sheet, e.source.row, e.reasons.join('；'), JSON.stringify(e.source.cells)]) },
        { name: '复核历史', headers: ['关联事项', '原状态', '新状态', '原因', '说明', '证据索引', '操作依据', '人员', '时间（本机）','稳定复核标识','原时间'], rows: Object.entries(run.reviews).flatMap(([key, r]) => r.events.map(e => [keyLabel(outcomeKeys.get(key)||''), e.from, e.to, e.cause, e.note, e.evidence, e.reason, e.person, localTime(e.at),key,e.at])) },
        { name: '未决事项', headers: ['关联项', '分类', '问题', '复核状态','稳定关联键','内部分类'], rows: run.result.outcomes.filter(o => (o.category !== '匹配一致' && run.reviews[identity(o)]?.status !== '复核通过') || ['无效输入', '重复/歧义'].includes(o.category)).map(o => [keyLabel(o.key), categoryLabel(o.category), o.issues.join('；'), run.reviews[identity(o)]?.status || '未复核',o.key,o.category]) }
    ];
}
export function exportWork(run: Run, title: string) { return workbookBytes(workSheets(run, title)); }
