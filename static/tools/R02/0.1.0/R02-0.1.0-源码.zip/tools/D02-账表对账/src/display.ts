import type {Category} from './engine';
const labels:Record<Category,string>={'匹配一致':'核对一致','字段差异':'内容差异','仅左侧':'仅第一方有','仅右侧':'仅第二方有','重复/歧义':'对应不唯一','无效输入':'资料无效'};
export function categoryLabel(category:string):string{return Object.hasOwn(labels,category)?labels[category as Category]:'未知分类';}
// Display only; never use this joined string as a matching or review identity.
export function keyLabel(key:string):string{try{const v:unknown=JSON.parse(key);if(!Array.isArray(v)||!v.length||v.length>30||v.some(x=>typeof x!=='string'||!x.trim()))return '关联值无效';return v.join(' / ');}catch{return '关联值无效';}}
// Browser local timezone by default; explicit zone supports deterministic tests.
export function localTime(raw:string,timeZone?:string):string{
 if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(raw))return '时间未记录';
 const d=new Date(raw);if(!Number.isFinite(d.getTime()))return '时间未记录';
 const parts=new Intl.DateTimeFormat('zh-CN',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23',...(timeZone?{timeZone}:{})}).formatToParts(d);
 const p=(name:string)=>parts.find(p=>p.type===name)?.value||'';
 return `${p('year')}-${p('month')}-${p('day')} ${p('hour')}:${p('minute')}:${p('second')}`;
}
