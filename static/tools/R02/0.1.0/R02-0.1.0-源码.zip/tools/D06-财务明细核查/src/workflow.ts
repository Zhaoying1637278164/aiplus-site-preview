import type {Table,Cell,SourceRow} from '../../../packages/core/types';
import {LIMITS} from '../../../packages/core/types';
import {defaultPlan} from './example';
import {inspectTable,validatePlan} from './engine';
import {VERSION,RULE_VERSION,type Plan,type Issue,type Report} from './types';
export const clone=<T>(x:T):T=>structuredClone(x);
export interface Policy {enabled:boolean;version:string;basis:string;applicability:string;from:string;to:string}
export interface Scope {periodColumn:string;period:string;currencyColumn:string;currency:string;unitColumn:string;unit:string;declaredUnit:string;equationConfirmed:boolean}
export interface Config {plan:Plan;policies:Record<string,Policy>;scope:Scope}
export interface ReviewEvent {status:'已复核'|'已撤销';person:string;basis:string;note:string;at:string}
export interface Session {title:string;table:Table|null;config:Config;reviews:Record<string,ReviewEvent[]>;review_context:string}
export interface Run {report:Report;excluded:{source:SourceRow;reason:string}[];input:number;reviews:Session['reviews']}
export function policy():Policy{return {enabled:true,version:'1',basis:'经办人配置的明细核查约束',applicability:'本次财务明细核查；不作会计政策或审计结论',from:'',to:''}}
export function initial():Session{return {title:'本期财务明细核查',table:null,config:{plan:clone(defaultPlan),policies:Object.fromEntries(defaultPlan.checks.map(c=>[c.id,policy()])),scope:{periodColumn:'期间',period:'',currencyColumn:'币种',currency:'',unitColumn:'',unit:'',declaredUnit:'元',equationConfirmed:false}},reviews:{},review_context:''}}
export function strict(v:unknown,keys:string[]):asserts v is Record<string,any>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).some(k=>!keys.includes(k)))throw Error('文件含未允许字段或结构无效')}
function str(v:unknown,max=10000){if(typeof v!=='string'||v.length>max)throw Error('文本类型或长度无效')}
export function validateConfig(c:Config){
 strict(c,['plan','policies','scope']);validatePlan(c.plan);strict(c.plan,['schema_version','tool','trim','ignoreCase','checks']);
 for(const check of c.plan.checks){strict(check,['id','name','kind','severity','columns','value_type','allowed','min','max','terms','target','tolerance']);for(const t of check.terms||[])strict(t,['column','sign'])}
 strict(c.policies,c.plan.checks.map(x=>x.id));
 for(const r of c.plan.checks){const p=c.policies[r.id];strict(p,['enabled','version','basis','applicability','from','to']);if(typeof p.enabled!=='boolean')throw Error('启停参数无效');for(const k of ['version','basis','applicability','from','to'] as const)str(p[k]);for(const v of [p.from,p.to])if(v&&!/^\d{4}-(0[1-9]|1[0-2])$/.test(v))throw Error('有效期间需YYYY-MM');if(p.from&&p.to&&p.from>p.to)throw Error('规则有效期间倒置')}
 strict(c.scope,['periodColumn','period','currencyColumn','currency','unitColumn','unit','declaredUnit','equationConfirmed']);for(const [k,v] of Object.entries(c.scope))if(k!=='equationConfirmed')str(v,200);if(typeof c.scope.equationConfirmed!=='boolean')throw Error('勾稽确认无效');
 if(!c.plan.checks.some(r=>c.policies[r.id].enabled))throw Error('至少启用一个业务核查项目');
}
function validateTable(t:Table){
 strict(t,['file','sheet','headers','rows']);str(t.file,200);str(t.sheet,200);
 if(!Array.isArray(t.headers)||!t.headers.length||t.headers.length>LIMITS.columns||t.headers.some(h=>typeof h!=='string'||!h.trim()||h.length>200)||new Set(t.headers).size!==t.headers.length)throw Error('资料字段无效');
 if(!Array.isArray(t.rows)||!t.rows.length||t.rows.length>LIMITS.rows)throw Error('资料行数无效');const seen=new Set<number>();
 for(const r of t.rows){strict(r,['file','sheet','row','cells']);if(r.file!==t.file||r.sheet!==t.sheet||!Number.isInteger(r.row)||r.row<1||seen.has(r.row))throw Error('来源行无效或重复');seen.add(r.row);strict(r.cells,t.headers);if(Object.keys(r.cells).length!==t.headers.length)throw Error('来源字段缺失');for(const v of Object.values(r.cells)){if(v===null)continue;if(typeof v==='string'){str(v);continue}if(typeof v==='number'&&Number.isFinite(v))continue;strict(v,['formula','cached']);str(v.formula);if(v.cached!==null&&typeof v.cached!=='string'&&typeof v.cached!=='number')throw Error('公式缓存类型无效');if(typeof v.cached==='string')str(v.cached);if(typeof v.cached==='number'&&!Number.isFinite(v.cached))throw Error('公式缓存数值无效')}}
}
export function validateSession(s:Session){strict(s,['title','table','config','reviews','review_context']);str(s.title,200);str(s.review_context,LIMITS.bytes);if(Object.keys(s.reviews).length&&s.review_context!==JSON.stringify({table:s.table,config:s.config}))throw Error('复核对应的资料或规则已变化，拒绝恢复');validateConfig(s.config);if(s.table!==null)validateTable(s.table);strict(s.reviews,Object.keys(s.reviews));if(Object.keys(s.reviews).length>50000)throw Error('复核数量超限');for(const history of Object.values(s.reviews)){if(!Array.isArray(history)||!history.length||history.length>100)throw Error('复核历史数量无效');for(let i=0;i<history.length;i++){const e=history[i];strict(e,['status','person','basis','note','at']);for(const v of [e.person,e.basis,e.note,e.at])str(v);if(!e.person.trim()||!e.basis.trim()||!['已复核','已撤销'].includes(e.status)||!Number.isFinite(Date.parse(e.at)))throw Error('复核人员、依据或时间无效');if(e.status!==(i%2===0?'已复核':'已撤销'))throw Error('复核历史顺序无效')}}}
export const issueKey=(i:Issue)=>JSON.stringify([i.rule_id,i.source.file,i.source.sheet,i.source.row,i.kind]);
export function reviewed(s:Session,key:string){return s.reviews[key]?.at(-1)?.status==='已复核'}
export function changed(s:Session,patch:Partial<Pick<Session,'table'|'config'|'title'>>):Session{return {...s,...clone(patch),reviews:{},review_context:''}}
export function execute(s:Session):Run{
 validateSession(s);if(!s.table)throw Error('请先导入财务明细');const table=s.table,scope=s.config.scope;
 const filters=[[scope.periodColumn,scope.period,'期间'],[scope.currencyColumn,scope.currency,'币种'],[scope.unitColumn,scope.unit,'单位']];
 for(const [col,val,label] of filters)if(val&&(!col||!table.headers.includes(col)))throw Error(label+'范围字段缺失');
 const included:SourceRow[]=[],excluded:Run['excluded']=[];
 for(const row of table.rows){const reasons=filters.filter(([col,val])=>val&&String(row.cells[col]??'')!==val).map(([, ,label])=>label+'不在核查范围');if(reasons.length)excluded.push({source:clone(row),reason:reasons.join('；')});else included.push(row)}
 if(!included.length)throw Error('所选范围无明细，请调整范围');
 const blocked=new Map<string,string>();const enabled=s.config.plan.checks.filter(c=>s.config.policies[c.id].enabled);
 for(const c of enabled){const p=s.config.policies[c.id];let reason='';if(!p.basis.trim()||!p.version.trim()||!p.applicability.trim())reason='缺少规则版本、依据或适用条件';else if(p.from||p.to){if(!scope.period)reason='规则有生效期间，请指定本次核查期间';else if((p.from&&scope.period<p.from)||(p.to&&scope.period>p.to))reason='本期不在规则有效期间内'}if(c.kind==='equation'&&(!scope.equationConfirmed||!scope.declaredUnit.trim()))reason=reason||'尚未确认勾稽字段币种、期间和单位一致';if(reason)blocked.set(c.id,reason)}
 // Keep the existing engine for executable rules. A private placeholder provides its
 // system static-safety scan when every business rule is blocked; it is removed below.
 const checks=enabled.filter(c=>!blocked.has(c.id));
 let placeholder='INTERNAL_PENDING';while(s.config.plan.checks.some(c=>c.id===placeholder))placeholder+='_';
 const report=inspectTable({...table,rows:included},{...s.config.plan,checks:checks.length?checks:[{id:placeholder,name:'内部占位扫描',kind:'required',severity:'error',columns:['__D06_NOT_PRESENT__']}]});
 report.rules=report.rules.filter(r=>r.id!==placeholder);
 for(const c of enabled)if(blocked.has(c.id))report.rules.push({id:c.id,name:c.name,severity:c.severity,state:'blocked',examined_rows:0,violation_rows:0,unassessed_rows:0,reason:blocked.get(c.id)!});
 report.rules.sort((a,b)=>a.id==='SYSTEM_STATIC'?-1:b.id==='SYSTEM_STATIC'?1:enabled.findIndex(c=>c.id===a.id)-enabled.findIndex(c=>c.id===b.id));
 report.plan=clone(s.config.plan);report.stats.blocked_rules=report.rules.filter(r=>r.state==='blocked').length;report.conclusion=report.stats.blocked_rules?'有规则未执行':report.stats.issue_rows?'发现问题':'已启用规则未发现问题';
 const validKeys=new Set(report.issues.map(issueKey));for(const key of Object.keys(s.reviews))if(!validKeys.has(key))throw Error('复核记录不属于当前资料与规则，拒绝恢复');
 return {report,excluded,input:table.rows.length,reviews:clone(s.reviews)};
}
export function review(s:Session,key:string,event:ReviewEvent):Session{const run=execute(s);if(!run.report.issues.some(i=>issueKey(i)===key))throw Error('异常事项不存在');if(event.status===(reviewed(s,key)?'已复核':'已撤销'))throw Error('复核状态转换无效');const next=clone(s);next.review_context=JSON.stringify({table:next.table,config:next.config});next.reviews[key]=[...(next.reviews[key]||[]),clone(event)];validateSession(next);return next}
function bounded(raw:string){if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案或工作文件超过10MB');return raw}
const envelope=(contains_data:boolean)=>({schema_version:2,tool:'D06',app_version:VERSION,rule_version:RULE_VERSION,contains_data});
export function encodeWork(s:Session){validateSession(s);if(s.table)execute(s);else if(Object.keys(s.reviews).length)throw Error('无资料不能保存复核');return bounded(JSON.stringify({...envelope(true),session:s},null,2))}
export function encodeConfig(c:Config){validateConfig(c);return bounded(JSON.stringify({...envelope(false),config:{...clone(c),scope:{...clone(c.scope),equationConfirmed:false}}},null,2))}
export function restore(raw:string):Session{const v=JSON.parse(bounded(raw));strict(v,['schema_version','tool','app_version','rule_version','contains_data',v.contains_data===true?'session':'config']);if(v.schema_version!==2||v.tool!=='D06'||v.app_version!==VERSION||v.rule_version!==RULE_VERSION||typeof v.contains_data!=='boolean')throw Error('请使用D06 0.2.0对应方案或工作文件');if(v.contains_data){validateSession(v.session);if(v.session.table)execute(v.session);else if(Object.keys(v.session.reviews).length)throw Error('无资料不能恢复复核');return clone(v.session)}validateConfig(v.config);return {...initial(),config:{...clone(v.config),scope:{...clone(v.config.scope),equationConfirmed:false}}}}
