import type {Table,Cell} from '../../../packages/core/types';import type {Plan} from './types';
const headers=['单据号','金额','日期','币种','期间','期初','增加','减少','期末'];
const values:Cell[][]=[
 ['A001','100','2026-09-30','CNY','2026-09','10','5','3','12'],
 ['A002','0','2026-09-30','CNY','2026-09','0','0','0','0'],
 ['A002','-1','2026-02-30','CNY','2026-09','10','5','3','11'],
 [null,'20','2026-09-30','EUR','2026-09','10','5','3','12'],
 ['A005',null,'2026-09-30','CNY','2026-09','10',null,'3','7'],
 ['A006','abc','2026-09-30','CNY','2026-09','10','5','3','12'],
 ['A007','10','2026-09-30','CNY','2026-08','10','5','3','12'],
 ['A008',{formula:'1+1',cached:2},'2026-09-30','CNY','2026-09','10','5','3','12']
];
export const example:Table={file:'D06-虚构样例.xlsx',sheet:'虚构数据',headers,rows:values.map((vs,i)=>({file:'D06-虚构样例.xlsx',sheet:'虚构数据',row:i+2,cells:Object.fromEntries(headers.map((h,j)=>[h,vs[j]]))}))};
export const defaultPlan:Plan={schema_version:1,tool:'D06',trim:false,ignoreCase:false,checks:[
 {id:'R1',name:'单据号必填',kind:'required',severity:'error',columns:['单据号']},
 {id:'R2',name:'单据号唯一',kind:'unique',severity:'error',columns:['单据号']},
 {id:'R3',name:'金额类型',kind:'type',severity:'error',columns:['金额'],value_type:'amount'},
 {id:'R4',name:'日期类型',kind:'type',severity:'error',columns:['日期'],value_type:'date'},
 {id:'R5',name:'金额非负',kind:'range',severity:'warning',columns:['金额'],min:'0'},
 {id:'R6',name:'币种范围',kind:'allowed',severity:'warning',columns:['币种'],allowed:['CNY']},
 {id:'R7',name:'本期范围',kind:'allowed',severity:'warning',columns:['期间'],allowed:['2026-09']},
 {id:'R8',name:'余额勾稽',kind:'equation',severity:'warning',columns:['期初','增加','减少','期末'],terms:[{column:'期初',sign:1},{column:'增加',sign:1},{column:'减少',sign:-1}],target:'期末',tolerance:'0'}
]};
