import {workbookBytes} from '../../../packages/core/io';
import {execute,issueKey,reviewed,type Session} from './workflow';
import {VERSION,RULE_VERSION} from './types';
function rawSheets(s:Session){const run=execute(s),r=run.report,states=new Map(r.row_status.map(x=>[x.source.row,x]));return [
 {name:'核查摘要',headers:['项目','内容'],rows:[['工具','财务明细核查'],['应用版本',VERSION],['规则版本',RULE_VERSION],['任务',s.title],['结论',r.conclusion],['输入行',run.input],['纳入行',r.stats.input_rows],['排除行',run.excluded.length],['问题行',r.stats.issue_rows],['未命中行',r.stats.no_issue_rows],['错误行',r.stats.error_rows],['警告行',r.stats.warning_rows],['异常条数',r.stats.issue_count],['已复核条数',r.issues.filter(i=>reviewed(s,issueKey(i))).length],['边界','错误警告行可重叠；复核不改变异常；不是审计结论；金额不跨币种单位期间汇总']]},
 {name:'范围与参数',headers:['参数','内容'],rows:[['范围',JSON.stringify(s.config.scope)],['精度','输入最多6位小数/24位数字，Decimal计算，容差独立'],['文本处理',JSON.stringify({trim:s.config.plan.trim,ignoreCase:s.config.plan.ignoreCase})]]},
 {name:'规则执行',headers:['规则ID','名称','严重性','执行状态','检查行','违规行','无法判断行','原因'],rows:r.rules.map(x=>[x.id,x.name,x.severity,x.state,x.examined_rows,x.violation_rows,x.unassessed_rows,x.reason])},
 {name:'核查项目配置',headers:['规则ID','名称','规则参数','启停与版本依据适用期间'],rows:s.config.plan.checks.map(c=>[c.id,c.name,JSON.stringify(c),JSON.stringify(s.config.policies[c.id])])},
 {name:'全部异常',headers:['事项ID','规则','严重性','判定','文件','页签','原行','实际值','要求','差额','原因','复核状态','经办人','依据','原始行JSON'],rows:r.issues.map(i=>{const key=issueKey(i),e=s.reviews[key]?.at(-1);return [key,i.rule_name,i.severity,i.kind,i.source.file,i.source.sheet,i.source.row,i.actual,i.expected,i.difference,i.message,reviewed(s,key)?'已复核':'待复核',e?.person||'',e?.basis||'',JSON.stringify(i.source.cells)]})},
 {name:'复核历史',headers:['事项ID','操作','经办人','依据','说明','时间'],rows:Object.entries(s.reviews).flatMap(([k,history])=>history.map(e=>[k,e.status,e.person,e.basis,e.note,e.at]))},
 {name:'全量来源',headers:['文件','页签','原行','范围状态','有错误','有警告','无法判断','原始行JSON'],rows:s.table!.rows.map(row=>{const state=states.get(row.row);return [row.file,row.sheet,row.row,state?'纳入':'排除',state?.error??'',state?.warning??'',state?.unassessed??'',JSON.stringify(row.cells)]})},
 {name:'排除行',headers:['文件','页签','原行','原因','原始行JSON'],rows:run.excluded.map(x=>[x.source.file,x.source.sheet,x.source.row,x.reason,JSON.stringify(x.source.cells)])}
 ]}
export function workSheets(s:Session){
 const sheets=rawSheets(s),parts:(string|number|boolean)[][]=[];
 const output=sheets.map(ws=>({...ws,rows:ws.rows.map((row,i)=>row.map((v,j)=>{if(typeof v!=='string'||v.length<=8000)return v;const id=JSON.stringify([ws.name,i+2,ws.headers[j]]);for(let start=0,n=1;start<v.length;start+=8000,n++)parts.push([id,ws.name,i+2,ws.headers[j],n,v.slice(start,start+8000)]);return '完整长文本见分段索引：'+id}))}));
 if(parts.length)output.push({name:'长文本分段',headers:['文本ID','来源页签','底稿原行','字段','顺序','完整文本分段'],rows:parts});
 return output;
}
export async function exportWork(s:Session){return workbookBytes(workSheets(s))}
