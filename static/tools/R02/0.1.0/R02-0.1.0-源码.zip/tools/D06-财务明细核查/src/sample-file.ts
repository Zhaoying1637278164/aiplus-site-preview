import ExcelJS from 'exceljs';import {example} from './example';
// Create a fully fictitious test workbook. Formula text and cached result are written,
// never calculated. The reader must refuse to use that cached result.
export async function sampleBytes(){const wb=new ExcelJS.Workbook();const ws=wb.addWorksheet('虚构数据');ws.addRow(example.headers);for(const row of example.rows)ws.addRow(example.headers.map(h=>{const v=row.cells[h];return v&&typeof v==='object'?{formula:v.formula,result:v.cached}:v}));ws.getRow(1).font={bold:true};return new Uint8Array(await wb.xlsx.writeBuffer())}
