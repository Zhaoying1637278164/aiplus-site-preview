import ExcelJS from 'exceljs';
import type {ReleaseAsset} from '../../../packages/core/release-assets';
import {example} from './example';
export async function releaseAssets():Promise<ReleaseAsset[]>{const wb=new ExcelJS.Workbook();wb.created=new Date('2026-10-03T00:00:00Z');wb.modified=new Date('2026-10-03T00:00:00Z');const ws=wb.addWorksheet(example.sheet);ws.addRow(example.headers);for(const row of example.rows)ws.addRow(example.headers.map(h=>{const v=row.cells[h];return v&&typeof v==='object'?{formula:v.formula,result:v.cached}:v}));ws.getRow(1).font={bold:true};return [{filename:'空白模板.csv',data:'\uFEFF'+example.headers.join(',')+'\r\n'},{filename:'虚构样例.xlsx',data:new Uint8Array(await wb.xlsx.writeBuffer())}]}
