import {workbookBytes} from '../../../packages/core/io';import type {Report} from './types';
export async function exportReport(report:Report){
 return workbookBytes([
 {name:'检查说明',headers:['项目','内容'],rows:[['工具','D06 财务明细核查'],['应用版本',report.app_version],['规则版本',report.rule_version],['结论',report.conclusion],['边界','只诊断不修改；仅检查已启用规则，不作审计保证'],['精度','最多6位小数/24位输入数字；金额差额文本输出；容差单独配置'],['范围','单行勾稽须确认同币种、单位与期间；不汇总混币金额；不换汇'],['公式','不执行、不采用缓存'],['行数',JSON.stringify(report.stats)]]},
 {name:'规则执行',headers:['规则ID','名称','严重性','状态','已检查行','违规行','无法判断行','阻塞原因'],rows:report.rules.map(r=>[r.id,r.name,r.severity,r.state,r.examined_rows,r.violation_rows,r.unassessed_rows,r.reason])},
 {name:'方案与参数',headers:['不含数据的方案JSON'],rows:[[JSON.stringify(report.plan)]]},
 ...(['error','warning'] as const).map(severity=>({name:severity==='error'?'错误问题':'警告问题',headers:['规则ID','名称','判定','文件','页签','原行','字段','实际值','要求','差额','原因','原始行JSON'],rows:report.issues.filter(i=>i.severity===severity).map(i=>[i.rule_id,i.rule_name,i.kind,i.source.file,i.source.sheet,i.source.row,i.columns.join('、'),i.actual,i.expected,i.difference,i.message,JSON.stringify(i.source.cells)])})),
 {name:'全量行状态',headers:['文件','页签','原行','有错误','有警告','无法判断','原始行JSON'],rows:report.row_status.map(r=>[r.source.file,r.source.sheet,r.source.row,r.error,r.warning,r.unassessed,JSON.stringify(r.source.cells)])}
 ]);
}
