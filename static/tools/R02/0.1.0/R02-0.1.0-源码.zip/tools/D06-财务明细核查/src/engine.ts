import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';
import {LIMITS,type Table,type Cell,type SourceRow} from '../../../packages/core/types';
import {VERSION,RULE_VERSION,type Plan,type Check,type Report,type Issue,type Summary} from './types';
export const KINDS={required:'必填',unique:'复合唯一键',type:'字段类型',allowed:'允许取值',range:'金额范围',equation:'金额勾稽'} as const;
const blank=(v:Cell)=>v===null||v===undefined||(typeof v==='string'&&v.trim()==='');
const staticValue=(v:Cell)=>v===null||typeof v!=='object';
function fieldName(v:unknown):asserts v is string {if(typeof v!=='string'||!v.trim()||v.length>200)throw Error('字段名称为空或超限')}
export function validatePlan(plan:Plan){
 if(plan?.schema_version!==1||plan?.tool!=='D06'||typeof plan.trim!=='boolean'||typeof plan.ignoreCase!=='boolean'||!Array.isArray(plan.checks)||!plan.checks.length||plan.checks.length>100)throw Error('方案版本、参数或规则数量无效（1至100条）');
 const ids=new Set<string>();
 for(const c of plan.checks){
 if(!c||typeof c.id!=='string'||!/^[A-Za-z0-9_-]{1,40}$/.test(c.id)||c.id==='SYSTEM_STATIC'||ids.has(c.id))throw Error('规则ID须唯一，限字母数字下划线短横线，且不得使用系统ID');ids.add(c.id);
 if(typeof c.name!=='string'||!c.name.trim()||c.name.length>200||!Object.hasOwn(KINDS,c.kind)||!['error','warning'].includes(c.severity)||!Array.isArray(c.columns)||!c.columns.length||c.columns.length>30)throw Error('规则名称、类型、严重性或字段数量无效');
 c.columns.forEach(fieldName);if(new Set(c.columns).size!==c.columns.length)throw Error('规则字段重复');
 if(c.kind!=='unique'&&c.kind!=='equation'&&c.columns.length!==1)throw Error('该类规则只能选择一列');
 if(c.kind==='type'&&!['text','amount','date'].includes(c.value_type!))throw Error('字段类型无效');
 if(c.kind==='allowed'&&(!Array.isArray(c.allowed)||!c.allowed.length||c.allowed.length>500||c.allowed.some(v=>typeof v!=='string'||!v.trim()||v.length>10000)))throw Error('允许取值须为1至500个非空文本');
 if(c.kind==='range'){
 if((c.min!==undefined&&typeof c.min!=='string')||(c.max!==undefined&&typeof c.max!=='string'))throw Error('金额界限须为十进制文本');
 if((c.min===undefined||c.min==='')&&(c.max===undefined||c.max===''))throw Error('金额范围至少设置一个界限');
 const min=c.min===undefined||c.min===''?null:amount(c.min);const max=c.max===undefined||c.max===''?null:amount(c.max);if(min&&max&&min.gt(max))throw Error('下限不能大于上限');
 }
 if(c.kind==='equation'){
 if(!Array.isArray(c.terms)||!c.terms.length||c.terms.length>30)throw Error('勾稽须有1至30项');
 for(const t of c.terms){fieldName(t.column);if(t.sign!==1&&t.sign!==-1)throw Error('勾稽仅支持显式加减')}
 fieldName(c.target);if(typeof c.tolerance!=='string'||amount(c.tolerance).isNegative())throw Error('勾稽容差须为非负十进制文本');
 const columns=[...new Set([...c.terms.map(t=>t.column),c.target])];if(columns.length!==c.columns.length||columns.some(v=>!c.columns.includes(v)))throw Error('勾稽所需字段与选择不一致');
 }
 }
}
function display(row:SourceRow,columns:string[]){return JSON.stringify(Object.fromEntries(columns.map(h=>[h,row.cells[h]??null])))}
function expected(c:Check){switch(c.kind){case'required':return'非空静态值';case'unique':return'文本复合键全表唯一';case'type':return c.value_type!;case'allowed':return JSON.stringify(c.allowed);case'range':return`[${c.min||'无下限'},${c.max||'无上限'}]`;case'equation':return c.terms!.map(t=>(t.sign===1?'+':'−')+t.column).join('')+' = '+c.target+'；容差 '+c.tolerance}}
export function inspectTable(table:Table,plan:Plan):Report{
 validatePlan(plan);if(table.rows.length>LIMITS.rows||table.headers.length>LIMITS.columns)throw Error('输入行列超限');
 if(table.rows.length*plan.checks.reduce((n,c)=>n+c.columns.length,0)>500000)throw Error('检查规模超过50万行字段组合，请减少规则或分批检查');
 const issues:Issue[]=[];const rules:Summary[]=[];const marked=table.rows.map(source=>({source:structuredClone(source),error:false,warning:false,unassessed:false}));
 function add(c:Pick<Check,'id'|'name'|'severity'|'columns'>,index:number,kind:Issue['kind'],message:string,expect:string,difference=''){
 if(issues.length>=50000)throw Error('问题记录超过5万条；未生成部分报告，请分批检查');
 const row=marked[index];row[c.severity]=true;if(kind==='unassessed')row.unassessed=true;
 issues.push({rule_id:c.id,rule_name:c.name,severity:c.severity,kind,source:row.source,columns:[...c.columns],actual:display(row.source,c.columns),expected:expect,difference,message});
 }
 const system={id:'SYSTEM_STATIC',name:'静态值安全检查',severity:'error' as const,columns:table.headers};
 for(let i=0;i<table.rows.length;i++)if(table.headers.some(h=>!staticValue(table.rows[i].cells[h])))add(system,i,'unassessed','存在公式/Excel错误；不执行、不采用缓存值','全部单元格为静态值');
 rules.push({id:system.id,name:system.name,severity:'error',state:'executed',examined_rows:table.rows.length,violation_rows:0,unassessed_rows:issues.length,reason:''});
 for(const c of plan.checks){
 const missing=c.columns.filter(h=>!table.headers.includes(h));const summary:Summary={id:c.id,name:c.name,severity:c.severity,state:missing.length?'blocked':'executed',examined_rows:missing.length?0:table.rows.length,violation_rows:0,unassessed_rows:0,reason:missing.length?'缺少字段：'+missing.join('、'):''};
 rules.push(summary);if(missing.length)continue;
 const start=issues.length;
 if(c.kind==='unique'){
 const groups=new Map<string,number[]>();
 for(let i=0;i<table.rows.length;i++){
 const row=table.rows[i];try{const key=JSON.stringify(c.columns.map(h=>text(row.cells[h],plan.trim,plan.ignoreCase)));const group=groups.get(key)||[];group.push(i);groups.set(key,group)}catch(e){add(c,i,'unassessed',(e as Error).message,expected(c))}
 }
 for(const indices of groups.values())if(indices.length>1)for(const i of indices)add(c,i,'violation','同键重复'+indices.length+'行；整组标记，未删除任何记录',expected(c));
 }else for(let i=0;i<table.rows.length;i++){
 const row=table.rows[i],v=row.cells[c.columns[0]];
 if(c.kind==='required'){if(blank(v)||!staticValue(v))add(c,i,blank(v)?'violation':'unassessed',blank(v)?'必填字段为空':'公式值不可用',expected(c));continue}
 if(c.kind==='type'){
 try{if(c.value_type==='amount')amount(v);else if(c.value_type==='date')date(v);else text(v,plan.trim,plan.ignoreCase)}catch(e){add(c,i,blank(v)||!staticValue(v)?'unassessed':'violation',(e as Error).message,expected(c))}continue;
 }
 if(c.kind==='allowed'){
 try{const value=text(v,plan.trim,plan.ignoreCase);if(!c.allowed!.map(a=>text(a,plan.trim,plan.ignoreCase)).includes(value))add(c,i,'violation','不在用户允许取值内',expected(c))}catch(e){add(c,i,'unassessed',(e as Error).message,expected(c))}continue;
 }
 if(c.kind==='range'){
 try{const n=amount(v);if((c.min&&n.lt(amount(c.min)))||(c.max&&n.gt(amount(c.max))))add(c,i,'violation','金额超出用户设置范围',expected(c))}catch(e){add(c,i,'unassessed','无法判断金额范围：'+(e as Error).message,expected(c))}continue;
 }
 if(c.kind==='equation'){
 try{const calculated=c.terms!.reduce((sum,t)=>sum.plus(amount(row.cells[t.column]).times(t.sign)),new Decimal(0));const difference=calculated.minus(amount(row.cells[c.target!]));if(difference.abs().gt(amount(c.tolerance!)))add(c,i,'violation','金额勾稽不平；差额为左式减目标',expected(c),difference.toFixed())}catch(e){add(c,i,'unassessed','无法勾稽：'+(e as Error).message,expected(c))}
 }
 }
 const current=issues.slice(start);summary.violation_rows=current.filter(v=>v.kind==='violation').length;summary.unassessed_rows=current.filter(v=>v.kind==='unassessed').length;
 }
 const issueRows=marked.filter(r=>r.error||r.warning).length,blocked=rules.filter(r=>r.state==='blocked').length;
 const stats={input_rows:table.rows.length,issue_rows:issueRows,no_issue_rows:table.rows.length-issueRows,error_rows:marked.filter(r=>r.error).length,warning_rows:marked.filter(r=>r.warning).length,issue_count:issues.length,blocked_rules:blocked};
 if(stats.issue_rows+stats.no_issue_rows!==stats.input_rows)throw Error('行数勾稽失败');
 return {tool:'D06',app_version:VERSION,rule_version:RULE_VERSION,plan:structuredClone(plan),file:table.file,sheet:table.sheet,issues,rules,row_status:marked,stats,conclusion:blocked?'有规则未执行':issueRows?'发现问题':'已启用规则未发现问题'};
}
