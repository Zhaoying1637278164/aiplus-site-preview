import {LIMITS} from '../../../packages/core/types';import {validatePlan} from './engine';import {VERSION,RULE_VERSION,type Plan} from './types';
function onlyKeys(value:object,keys:string[]){if(!value||Object.keys(value).some(k=>!keys.includes(k)))throw Error('方案含未允许字段，不能包含数据或代码')}
function strictPlan(plan:Plan){
 validatePlan(plan);onlyKeys(plan,['schema_version','tool','trim','ignoreCase','checks']);
 for(const c of plan.checks){onlyKeys(c,['id','name','kind','severity','columns','value_type','allowed','min','max','terms','target','tolerance']);for(const t of c.terms||[])onlyKeys(t,['column','sign'])}
}
export function encodePlan(plan:Plan){strictPlan(plan);return JSON.stringify({schema_version:1,tool:'D06',contains_data:false,app_version:VERSION,rule_version:RULE_VERSION,plan},null,2)}
export function decodePlan(raw:string):Plan{
 if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MB');const obj=JSON.parse(raw);
 if(obj?.schema_version!==1||obj?.tool!=='D06'||obj?.contains_data!==false||![VERSION,'0.1.0','0.1.1'].includes(obj?.app_version)||obj?.rule_version!==RULE_VERSION)throw Error('仅接受当前版本D06不含数据方案');
 onlyKeys(obj,['schema_version','tool','contains_data','app_version','rule_version','plan']);strictPlan(obj.plan);return structuredClone(obj.plan);
}
