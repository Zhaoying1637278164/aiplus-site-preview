# 总控最终验收 · 2026-10-03

当前 **accepted 0.1.0**。正式证据 `progress/evidence/R01/0.1.0/site-public-final.json`。正式断网14组、独立源码127测试与重建字节一致、原生流程17/导航43/下载11、公开五表XLSX/CSV/含无数据恢复/八表完整底稿逐格一致/取消确认退出重进全空/11项版本下载均已核验；Mac已实际运行，Windows实机未验证。0.1.0字节冻结，后续修复回唯一原线程并发新版本。以下保留候选及过程历史，早期未发布/未accepted描述已被最终证据替代。

# R01 状态交接（供总控同步根STATUS）

2026-10-03：R01合同开票回款台账0.1.0源码候选tested，未正式packaged/accepted。九页完整工作流、人工预期、具体参考源码/许可、财务规则、28本款/127全工程/typecheck、15组Mac断网浏览器和实际下载恢复等自测、桌面/390/320渲染已完成；候选HTML/runtime重建字节一致。仅tools/R01及本证据目录有本线程改动，未改根STATUS/catalog/公共包/release/官网，未提交其他目录。

总控下一步：独立审查/登记、原应收模块及原详情native集成、正式打包及最后源码ZIP独立重建、官网同结果/所有下载/退出和回归。Windows及正式官网/源码ZIP未验证，不增加accepted计数。详见本款验收证据.md和实现交接.md。

## 最新总控独立复核修复（最终候选）

总控原证据progress/evidence/shared/2026-10-03-R01-unallocated-invoice-review.json：未关联合同的有效票原候选余额错误为0。先更新人工预期并新增4项测试，修复前失败记录unallocated-before-fix.txt，随后引擎改原票有效金额减明确票核销；合同已关联票余额单独保留；客户按全部有效票客户集合展示，即使无合同。总览、客户、底稿分别标明全量和合同关联范围。新增全量＝关联＋未关联、客户全量及关联汇总守恒。未分配回款/预收仍不抵票，不补合同关联。

最终28本款/127全工程/typecheck/15组真实浏览器通过。全部未关联净票800、核销0、原票余额600/300/-100；部分关联全量500=关联100+未关联400；无合同客户仍800。三例实际JSON恢复、页面及真实XLSX均核验；新截图全未关联总览/发票、部分关联客户、320无合同全量票客户已查看（表格局部滚动，更多列须横向查看）。当前HTML SHA2b4de847fea5f8a13b8d4d3717fd9857404a6d544863a7635c89ae073cb79189，runtime SHAd442c0ffc86bd3160621aa1430c4a1f38a6c8f13677eea33b10b3f7dbf864168；旧候选SHA与重建证据已被新精确绑定替代。未正式发布/未accepted，Windows/公开官网/最终源码ZIP仍未验证。

## 最新视觉纠偏与再次交接（2026-10-03）

依据总控最新要求，最终候选改为全页白底、黑灰正文、白底细灰边框卡片、黑色金额；蓝色仅当前页签/主要操作/链接和交互焦点。表头浅灰，编辑与提示白底灰边界，取消旧浅蓝后台外观。提示在对应步骤精简，九页、八项余额口径、所有字段/来源与功能保留。实际改动src/styles.ts及program.tsx的两处提示与客户表头映射显式Record类型；未改引擎、数据模型或公共/官网文件。

本轮重新执行本款28/28；typecheck退出0（回归中发现表头映射TS7053，补显式类型后通过）；最终候选Mac断网file://15组浏览器全部通过，实际CSV/XLSX/JSON下载与恢复、模板、编辑删除/撤销、三例未关联余额、宿主退出清空均重验。九页1280/390/320截图与几何重生；实际查看总览/合同/待处理/客户/底稿以及390总览/320待处理，白底、金额和来源可读。全工程127项是上轮引擎修复的历史通过记录，本轮未重复扩大回归。

最终HTML SHA `2b4de847fea5f8a13b8d4d3717fd9857404a6d544863a7635c89ae073cb79189`；runtime SHA `d442c0ffc86bd3160621aa1430c4a1f38a6c8f13677eea33b10b3f7dbf864168`。candidate-manifest、browser/result、neutral-visual-review、rendered-review及candidate-rebuild已精确绑定；同源码候选重建字节一致。旧视觉的manifest、浏览器结果及关键截图保留history/before-neutral-visual，不再作为当前候选。源码再次暂停交接；tested候选，未正式构建/发布/accepted。官网行/详情、多模板下载、正式包/源码ZIP/公开验证由总控维护；Windows实机未验证。

## 最新官网导航遮挡修复（源码再次暂停交接）

2026-10-03。总控真实四款暂存官网回归失败：恢复后点合同台账被官网header.hdr拦截。原证据progress/evidence/site-integration/D02-D03-D06-R01/R01/site-local/failure.json。本款仅改program.tsx/styles.ts及本款测试/证据：导航sticky留在页头下方；website模式预留88px、offline12px；使用独立非sticky滚动锚点定位（避免对已sticky导航scrollIntoView无法带回标题）；只对页签容器调整横向scrollLeft，当前项完整；换页、同页重算、恢复和新建以revision定位，resize重新定位，卸载移除resize监听。标题不再滚到0并把导航藏到页头后。

新增tests/navigation-candidate.ts，tests/build-candidate.ts生成明确保留76px固定页头的fixed-header-harness。命令 `node --import tsx tools/R01-合同开票回款台账/tests/navigation-candidate.ts` 实际86项通过：两个宿主（断网file固定76px头部 + 真实本地Streamlit）；1280/390/320长页底部转全部9页；无数据方案恢复/含数据工作恢复后总览与合同、重算后待处理。正常locator.click，无force click，不移除/降低官网头部；逐项断言nav.top>=max(76,实际页头bottom)+4、标题在nav下且视口内、当前标签左右完整、elementFromPoint实际命中当前按钮。真实官网桌面hdr-in76px/手机64px，测试记录原样保留，导航仍预留至少76px。

真实Streamlit验证只在测试浏览器替换R01候选runtime与注册hash，官网其余HTML/头部/loader保留，程序同document/ShadowRoot，无内层工具iframe；没有写正式官网、integration、catalog或release。总控仍须正式重建后重跑实际四款门禁，候选不替代正式官网验收。

本轮28/28计算、typecheck退出0、15组断网文件浏览器再次通过。86项geometry和截图、原失败与修正都在progress/evidence/R01/0.1.0/navigation；navigation-review/rendered-review绑定最终SHA。已实看真实桌面恢复合同、390底稿、320含数据恢复合同及固定76px手机来源页，导航/标题/来源可读。旧sticky无锚点试验标题-24的失败、误按桌面高度断言手机头部的失败分别保留failure-sticky-without-anchor.json/failure-mobile-header-assumption.json。

最终HTML SHA `2b4de847fea5f8a13b8d4d3717fd9857404a6d544863a7635c89ae073cb79189`；runtime SHA `d442c0ffc86bd3160621aa1430c4a1f38a6c8f13677eea33b10b3f7dbf864168`。candidate-manifest、browser/result、navigation/result、candidate-rebuild已绑定，同源码候选重建字节一致。旧视觉/导航前证据保留history/before-navigation。九页、八项口径和全量/关联/未关联余额不变；tested候选，未公开/冻结/accepted，Windows及正式源码ZIP未验证。源文件再次停止变更，等待总控正式重建与同版本重验。
