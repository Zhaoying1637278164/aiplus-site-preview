当前追加：session10335已实际退出0，R01真实本地四款原生Streamlit17组通过；原离线whole work及run恢复精确一致、退出取消保留/确认清空/重进空均通过。processing_requests=[]、存储与进入前基线精确一致；仅重进程序登记runtime请求允许。精确结果site-local/result.json。不计公开官网/下载/最终源码包同步验收；下方“session运行中”是通过前检查点。下一步实际11下载、四款回归及最终源码ZIP同步，正式仍3/64。

## R01稳定源码包与原生暂存（2026-10-03，当前）

R01正式HTML断网14组已有独立证据。新增源码快照打包只包含本款和稳定D02/D03/D06回归依赖，不读R02活动源码/证据；source-snapshot.json记录全文件SHA。scripts/package.py在任何写包前拒绝冻结版本，实际尝试D06 0.2.0被拒且旧7版本85文件全部SHA保持。初次R01源码ZIP33.6MB虽独立重建通过但超过24MiB传输限额，保留candidates/before-source-size及失败证据；精简生成截图（原图全部仍在项目证据，不删除），最终源码3.95MB。独立临时目录npm ci --offline/test127/typecheck/build均0，正式HTML及runtime逐字节一致，源码SHA见source-rebuild.json。当前R01 packaged，未accepted/未冻结/未官网发布。

四款官网仅stage到integration/native-site，外部官网仍701542f三款。R01真实本地Streamlit九页及文件流程测试在进行：首轮变量重名/宿主外层section严格定位失败均留档；后续工具流程通过至存储检查，原官网进入时有已有存储，测试改为精确比较进入工具前后存储而非假设0，不放宽用户数据持久化禁令。tests/r01-native-site.ts current session10335仍运行，须查同句柄，不能因观察超时重启。正式公开官网/11下载/源码包最终同步及四款回归待验。

R02尾差修复已由总控对原两组失败输入分别逐日90/181天重算：正计划各期非负、截至累计单调且不越总额、月内due不越本期计划、合计守恒且期末等于0.02/0.04；新月分配采用累计舍入差分，精确结果及engine SHA见shared/2026-10-03-R02-proration-tail-recheck.json。原失败仍保留，其他R02业务/候选浏览器与正式包官网仍未验。原线程实际active cursor7，未重复启动。正式3/64，完整目标持续，Windows未验证。

## R01正式HTML断网通过、R02尾差复核未过（2026-10-03，当前）

R01视觉修正actual turn01a101cc-4eef-7231-982b-3b0c76516e7f completed/idle，cursor16；本款已停止改源码。总控实看候选白底黑灰完整九页，执行npm run build -- R01生成正式HTML/runtime/五类CSV/虚构XLSX/说明/口径/声明。正式HTML SHA a6ff27f946d4168017d313a46ba1d1f00d615c7139b9b5e296956cd1e298cea8；runtime ae1e87aaeb938d57d06f067ed4d15dcf0214510b77d86a20e652c2dc1fd862e8。与候选包装hash不同，不能复用候选验收。tests/r01-formal-browser.ts明确读取release，本机Chromium实际断网file://14组通过、HTTP/pageerror/storage为0，实际输入/底稿/五类模板/含无数据恢复/新增删除撤销/320390/未关联三例重验。formal-browser/result、formal-build和实际查看合同/部分关联总览formal-rendered-review绑定精确正式hash。仍tested，未ZIP打包/源码ZIP重建/原生官网或发布，不能accepted。

R02总控独立算术复现0.02三个月按日末期计划0却月末前due0.03大于总0.02且到月末反降0.02；0.04六个月前五期各0.01、末期-0.01。完全虚构输入和结果在shared/2026-10-03-R02-proration-tail-review.json，已回唯一R02线程要求先独立预期测试、修正精度尾差/期间截断，使非负基础计划守恒且截止累计不越额/倒退，再文件/规则/页面重验。总控未改R02代码。

下一步总控R01正式离线/源码包及独立重建、四款原生官网/实际下载与回归；R02本款修复。源码包当前脚本会包含全部已有main工具，R02仍活动/未通过，需要先明确稳定源码依赖快照，不把未验证R02程序当R01重建前提。正式仍3/64，Windows未验证，完整64目标持续。

## R01财务复核通过、视觉修正待（2026-10-03，当前）

总控实际执行本款28项测试通过；三例独立重算全部未关联800/关联0、部分关联500=100+400、无合同新增客户90与全量890通过，精确engine SHA和原始结果见shared/2026-10-03-R01-unallocated-invoice-recheck.json。原失败复现保留。R01原线程actual turn已completed/idle cursor11，交接最终候选自测15组与127回归声明不等于正式验收。

总控实看部分关联总览截图，九页及完整金额口径成立，但浅蓝背景/蓝色指标卡/深蓝正文偏离官网原白黑蓝风格，已回同一R01线程要求保留业务深度的视觉修正并重验。证据shared/2026-10-03-R01-rendered-review.json；正式构建/包/官网/源码ZIP未执行。R02八页/手算预期与引擎在本款实现，目录不覆盖。

总控已准备scripts/site.py的R01应收同风格行/详情/独立路由和五类CSV共11项下载。六项纯结构fixture通过，原三款完整官网HTML逐字节不变，默认只stage已accepted三款；fixture不代表R01程序/包/官网通过。证据shared/2026-10-03-R01-site-structure.json，checker脚本check-r01-site-structure.py。未stage/apply或发布。正式仍3/64；5款线程、余59槽位；Windows未验证。

## R01总控独立财务复核（2026-10-03，当前未通过）

原始复现progress/evidence/shared/2026-10-03-R01-unallocated-invoice-review.json：现有虚构基线有效净发票800、所有分配清空、明确票核销0，人工全量发票未收应800；当前总览receivable及各票outstanding为0，使用合同已分配额计算掩盖未关联发票。已授权回R01唯一原线程，要求先补独立预期/全或部分未分配测试，区分全量发票余额与合同关联余额，修复中文页面及XLSX并重验，不用预收抵票、不自动关联。总控只读源码及执行复现，未改R01目录。问题解决前不正式打包/发布/验收。

R02唯一新线程已核实active，仅本款参考/政策与规格；当前5个线程/59槽位，正式3/64。本轮新增R02线程、同步财务名称与登记，并取得R01具体未通过证据，完整64目标持续。

## 应收线程调度（2026-10-03，当前）

R02｜收入确认排程表：完整业务工具已创建，唯一线程01a101c6-be97-7b82-9d38-929c64b99ce2，actual turn01a101c6-c101-7880-9104-809b1f864160，状态API核实active/inProgress、cursor2。精简任务thread-prompts/R02.md，目录已正式同步财务名tools/R02-收入确认排程表；仅本款目录与证据可写，其他目录由总控维护。R02处于参考核验/产品规格，未标实现或验收完成。

R01同一线程actual active、cursor6；候选断网11组流程通过，实际审阅发现中文底稿字段、来源分页和合同/客户名称展示需补，正在本款修正并重验。总控不与它改同目录，不因观察超时重启任务。工具同时实现最多两款，已建立5款长期线程，余59槽位未创建。正式完成仍3/64，Windows实机未验证。本轮新增R02独立线程及任务/目录登记，没有公共代码变更、正式打包或官网发布。

## 总控最终验收（2026-10-03，当前有效）

财务明细核查0.2.0已accepted，完整计数3/64。正式HTML/runtime/源码ZIP与官网701542f逐字节核对；源码独立npm ci/test/typecheck/build全部退出0并重建相同HTML/runtime。正式断网11组、人工30CSV/XLSX9组、本地官网15组和正式导航34项、公开七项实际下载、五份完整工作与离线Session/Run一致、公开无数据方案取消/确认清空、完整XLSX八张表逐单元格回读、原生退出取消/确认/重进清空均有独立证据。新旧包共7版本85文件冻结，未重新打包已发布字节。

最终绑定证据progress/evidence/D06/0.2.0/site-public-final.json；下方候选/待验记录为历史，不代替当前版本的正式证据。仅Mac实际验证，Windows实机未验证；无AI/OCR或异常交易检测平台承诺。后续修复回本款原线程，变更发新版本。

R01唯一线程实际active/inProgress，cursor5：本款24项计算/恢复自测通过，候选离线页已生成；首次浏览器沙箱启动失败已保留，仍在本款线程继续断网/实际下载/手机验证，不能计完成。总控未改或提交活动R01目录。已建4款线程，余60未创建；完整目标剩余61款。下一步接收R01具体交接、独立复核并接入官网。

## 当前线程调度（2026-10-03，取代下方历史调度记录）

一个工具一个长期线程：已建立D02/D03/D06/R01共4个，余60槽位按批次创建。R01实际active/inProgress，cursor4，九页方案、先于引擎的人工预期及具体参考已落盘，登记implementing；总控不改或提交它正在写的源码/证据。计划与权限见分线程开发计划.md，恢复入口线程调度与接续.md。最多同时两款实现，新线程使用本款精简任务，不继承总控长历史。

正式完成仍2/64。D06公开无数据方案与完整XLSX八张底稿补验已通过，原始证据site-public/supplement.json及下载回读脚本已落盘；待总控最终汇总accepted登记和冻结，保留旧失败证据，不重打已发布版本。此轮调度整理无新增线程、产品源码或官网发布。Windows实机未验证。

# 当前进度与接续

2026-10-03。正式完整验收 **2/64：D02账表对账0.2.0、D03科目与客商对应关系0.2.0**。Windows实机未验证，已明确披露；Mac Chromium已实际验证。D03 0.2.0官网cb16053实际验收通过并冻结；D06新版packaged候选、正式离线与源码重建通过，官网待验，D01 specified，其余planned。旧4个冻结包及D02新包不可覆盖。

## D06公开实际工作验收与R01独立线程（最新）

本轮为实际进展：公开官网701542f的D06实际chooser导入全虚构30CSV及XLSX（第二资料页/二行表头），实际下载完整与范围四份工作。node --import tsx tests/d06-public-readback.ts逐项比较whole Session/Run与离线精确相同：CSV16/14异常、XLSX17/15，范围27纳入3排除原行8/9/15。第五份实际下载来自离线含数据工作公开恢复，8来源/17异常/三次复核含原时间戳完全一致。公开七项版本下载此前SHA全部通过。

公开带数据退出：IAB确认接口未暴露且click超时，失败保留；改用Chrome原生确认，取消后8行/17异常保留，确定返回原财务详情，重进尚未导入资料、文件为空、维护按钮禁用。实际截图已审阅。无绕过确认、无扩大浏览器本地文件权限。新增补验无数据方案时，IAB22的label/实际input/原生按钮chooser均超时；关闭已保存测试页21亦超时导致CUA重置，未据此宣称方案或完整XLSX公开回读通过。D06仍packaged、完成2/64，检查点site-public/checkpoint.json逐项绑定实际证据；下一轮补无数据方案与完整XLSX公开回读，不能重打已公开0.2.0包。

已创建唯一R01长期线程01a101ba-f2e2-7193-b787-8a642680e595，题名“R01｜合同开票回款台账：完整业务工具”，实际状态接口确认active/inProgress，turn01a101ba-f75e-7b42-aab6-8256545c753e、cursor1。精简任务存thread-prompts/R01.md，限定本款目录及R01证据，先完整产品与独立答案再持续实现；总控同时补D06验证，目录不重叠。现在4个已建线程/60个未建槽位，R01线程启动不计产品完成。其他3款原线程不重启；无新官网发布。

## 最新线程规划检查点（本轮）

用户要求“一个工具一个线程，规划一下”。本轮核对catalog的64款和threads的64槽位；分别调用应用状态接口核实D02/D03/D06原线程全部idle。沿用这3个长期线程，余61款按批次创建，下一款R01；不复制总控长对话，每款使用六份本款接续材料，修复回原线程，总控只维护公共代码/官网/打包/最终验收。完整名称、工作流、批次和任务模板见分线程开发计划.md；简短实时入口为线程调度与接续.md。本轮没有创建线程、派发实现、修改产品源码或发布，无新增产品测试。

同时纠正接续文件的过期阶段：实际读取官网工程HEAD701542fd5d9077a622c0e0e3d0190ae2c4d9c409及D06 site-public/downloads.json，确认0.2.0已有发布与公开七项下载SHA通过证据；下方“未发布/源码门禁待”属于早期历史。D06公开输入/恢复/退出完整验收仍待，保持packaged，正式完成仍2/64。规划核对证据planning/2026-10-03-thread-plan.json。

## D06导航正式重建与独立30笔输入（最新有效）

D06原线程turn01a101a5-ea16-7430-9606-a2af909d7506已completed/idle、cursor15，修复五页统一ref定位、移动端当前项定位和原行详情跳转，仅改本款。总控已实际审查diff及交接，备份未公开0.2.0旧候选至release/D06/candidates/0.2.0-before-navigation，并保留其精确证据history；冻结旧版本不变。重新构建正式0.2.0并stage三款，99/99计算IO测试/typecheck通过，Mac正式file://11组、真实宿主15组、正式离线与未替换runtime的真实宿主导航34项通过。导航开始核查后top约96、标题约238，固定官网页头下可见；320/390当前页签、原行10单行、实际复核与全量来源详情可操作。下方导航失败为已修复的历史证据，不能沿用旧SHA。

总控新增tests/d06-v2-input-browser.ts及fixtures/D06/v2-input：全虚构30CSV/XLSX、首说明页/次资料页、二行表头，人工逐条答案CSV16异常、XLSX17异常（另有一条静态公式安全），12问题行18未命中、7错误行8警告行有交集；CNY/2026-09/元范围27纳入3排除，CSV14/XLSX15。前导零、空/零/负值、24位十进制与0.1+0.2-0.3=0、USD/元万元/期间原值、缓存999未采用、所有来源原行3–32均核验。正式断网9组、官网10组通过，完整Session/Run精确相等。修复后的来源按钮明确带原行号，首个旧测试选择器超时保留，改按查看原行17后通过。

D02/D03在新三款stage hash下五项原生/实际输入/业务回归再次均通过；实际六张三款桌面/手机图已查看，rendered-review绑定SHA。scripts/check-native-evidence.py已扩展仅审阅D02+D03或D02+D03+D06，检查独立完整输入/恢复、34项正式导航、三款真实下载/源码/冻结及视觉，当前仍待最终精确source ZIP/实际七项下载，不得apply/accepted。源码包加入虚构fixtures，排除重复生成candidate和被替代evidence/history，仅减少重复成品，源代码/测试/当前公开证据均保留；原文件仍在工程。源码下载仍受24MB界限，最终包必须实际验证。公开官网未改，完成2/64、Windows实机未验证。下一步最终源码独立重建、最终site/download hash门禁与公开浏览器验收。

## 三款官网回归与D06实际导航失败（历史，见上方正式修复）

上一目标轮为progress：分线程计划和简短接续已写入。本轮实际核验8514现存进程PID76942、integration/native-site目录和Streamlit1.50健康ok，复用服务；沙箱内curl失败不能当作服务停止。D02本地原生与实际导入、D03本地原生/新30笔CSV-XLSX/业务与跨工具隔离共五项脚本均通过，证据独立保存在progress/evidence/site-integration/D02-D03-D06，不覆盖旧accepted证据。现暂存总数79、结账14、主数据7；冻结6版本74文件全hash复核不变。

总控实际审阅D06桌面异常与320px手机截图，发现开始核查后仍停在旧页底部。tests/d06-navigation-browser.ts独立实测失败：导航top -667、标题 -525，1000px窗口，截图/geometry/result已保存，不能计视觉验收。具体修复已回D06原线程；状态API核实turn01a101a5-ea16-7430-9606-a2af909d7506 active、cursor10。D06正式重建/发布暂停至交接，主线程不同时改本款源码，产品仍packaged候选。

新增tests/d06-native-site.ts核对官网五页/17异常/三次复核、范围6纳入2排除13异常、真实文件与JSON/XLSX导出、完整离线工作实际恢复。最初不同运行人工复核时间戳不能直接整体比较，失败保留；修正为原行/配置/业务结果比较及实际恢复同一离线work后完整session/run精确比较。曾发现测试监听了不会发生的恢复确认导致后续双重dialog处理，测试已修正，旧候选完整本地工作流程最终14组通过，实际恢复同一离线工作后完整session/run精确相等；失败导航独立且尚未修复验收，修复后新版须重验。公开官网未修改，发布门禁仍拒绝三款，完成数2/64。Windows未验证。

## 本轮线程规划（当前调度入口）

用户要求一个工具一个线程，本轮已核对64款登记和64个线程槽位，D02/D03/D06三个已有线程均idle，继续复用；其余61个槽位尚未创建。已更新分线程开发计划与catalog/threads.json，明确职责、最多同时两款、交接锁定、六份本款接续材料与文件权限。下一步总控完成D06官网及三款回归，随后先R01应收业务链。总控简短接续入口为线程调度与接续.md；长测试与历史证据留原处。本轮仅调整规划，没有新增线程、运行产品测试或官网发布，正式验收仍2/64。现有未提交三款暂存与回归脚本保留，不能据此宣称D06官网已通过。

## D03最终公开验收（当前有效）

正式计完成2/64，D03 0.2.0 accepted。上一轮IAB确认框失败仍保留；本轮使用公开官网Chrome原生AX：体验12笔全虚构资料，生成独立预期3已对应/1待确认/1冲突/3未对应/4异常；带数据退出，原生取消后仍保留12笔；再次退出原生确定，返回原财务工具详情；点击原“开始核对对应关系”，原始资料/目标字典均为空。证据site-public-reentry-empty-ax.txt、site-public-reentry-empty-native.png已实际审阅。Chrome文件上传未开本地文件权限，未扩大扩展权限；仅用内置虚构示例完成退出验收，实际CSV/XLSX和恢复依旧采用此前IAB真实文件chooser及保存底稿逐项比较证据。

site-public-final.json绑定当前cb16053、精确site/HTML/runtime/source及14项原始证据SHA。此前公开七项实际下载SHA、独立30CSV/XLSX完整run/tables精确等于离线、人工确认+三处规则差异的whole session/run恢复精确相等，与本轮取消/退出/重进清空共同形成完整公开证据。下方“退出清空未验证”“未accepted”是已被本项替代的历史失败记录。

D03 0.2.0源码SHA8aeb9345fc03e8a3f60675dffd2b8f73b2d5aabe31739da1cd99a01e61f75e9c、离线ZIP5efce5d77e3c431864cc9946308753e59eeb1c1df206bcb7f2763202eebaf608保持公开字节；没有重新打包。catalog/tools/site-map/threads/总览已同步accepted/维护；release-locks现在6个版本74文件冻结且重新全部验hash，check-native-evidence.py实际门禁仍通过。Windows实机未验证。完整64目标持续，剩余62不计完成，D06原专属线程正在运行。

scripts/site.py现默认保留全部已验收条目，避免下一款暂存时漏掉D03。独立检查默认/显式选择、重复输入拒绝、未审阅D06阻塞及当前D02+D03生成HTML逐字节不变；证据shared/2026-10-03-preserve-accepted-site.json。未重新发布。

D06专属线程completed/idle，cursor9；五页源码交接，本款24/全工程99及typecheck线程自测通过，候选断网12组和实际五页/手机画面。总控已正式同步名称/目录tools/D06-财务明细核查、0.2.0，保留历史0.1.0/0.1.1冻结包；尚未正式离线/官网/source重建，不计完成。

## D06正式集成检查点

D06线程终态completed/idle、cursor9，不重启。正式名称/目录为财务明细核查、tools/D06-财务明细核查，应用0.2.0、基础规则D06-2026-10-03.1。总控独立99/99测试、typecheck通过；正式HTML/runtime/模板/虚构XLSX/说明/源码和离线ZIP已构建，catalog packaged候选，未accepted/未冻结/未官网发布。

progress/evidence/D06/0.2.0/browser/result.json绑定正式HTML/runtime：Mac断网file://实际11组通过，8行17异常、3次复核历史、XLSX/JSON下载回读、无数据清空/含数据恢复重算、草稿取消保留/确认放弃、CNY本期6纳入2排除13异常、实际XLSX公式拒绝、容差1重算16、CSV第二行表头零值换数据、390/320实际异常复核表单无横溢；HTTP/pageerror/storage为0。五张正式桌面及320复核实际查看，integration-checkpoint.json记录截图SHA；候选harness不是正式官网证据。

初次正式源码ZIP独立npm ci --offline/test/typecheck/build四项退出0，HTML/runtime逐字节相同，required包含正式浏览器测试和本款workflow/复核导出/锁文件/共享包/许可证；source-rebuild.json绑定当前ZIP。后续官网测试/发布门禁变化后，发布前须再次同步最终源码ZIP及其精确重建证据，不把此次初包当未来不同ZIP的验收。

scripts/site.py已准备D06归原结账模块同风格新行、详情及五页原生入口，保留accepted D02+D03；三款真实产物仅做独立结构生成校验79总/14结账/7主数据、财务名称/独立route/原go-render，D02+D03生成HTML保持现网逐字节。共享证据2026-10-03-three-tool-structure.json。尚未stage/apply，不构成官网同结果；发布门禁现只审阅D02+D03，会拒绝三款借旧证据。旧site-native-fixture.py使用外部已发布78行当76原稿导致断言失败，留档，不虚报通过。

下一步实际三款暂存，完整D06文件输入与参数/复核恢复/导出、长页导航、D02+D03下载及业务/跨工具清空回归；接入逐款完整门禁，最终同版本源码重建，回退标记后发布并实际公开浏览器下载/同结果才accepted。已有6冻结版本74文件全部SHA未变；Windows仍未验证。正式完成仍2/64，完整64目标有效。

## 上一轮检查点（保留历史）

正式完整验收仍为1/64。D03 0.2.0已于官网cb16053发布，回退tag codex/before-D03-native-0.2.0→db57b03；保留原76项，新财务名称归主数据，同站六页，目录78/主数据7。下方此前“未发布”“apply拒绝多工具”是历史阶段，已被本检查点替代。

新增实际证据：business/result和site-business/result覆盖规则新增/修改/删除/确认、独立三处基线差异、恢复基线清逐行确认和撤销、类别/范围/日期独立预期及排除来源、原官网固定页头下长页导航、D03→D02→D03数据隔离。本款正式源码ZIP已独立npm ci --offline /86测试/typecheck/build均退出0，HTML/runtime逐字节相等，包含新增业务测试与发布门禁；source-rebuild.json绑定最终源码SHA8aeb9345fc03e8a3f60675dffd2b8f73b2d5aabe31739da1cd99a01e61f75e9c。

scripts/check-native-evidence.py现检查双工具精确登记/包/源码/业务/本地官网/实际下载/实际视觉及旧冻结包，apply已通过门禁；不是公开accepted替代。公开site-public-downloads.json：七项实际浏览器下载SHA及离线ZIP内HTML完全一致。公开site-public-workflows.json：新30CSV/XLSX实际导入/页签2行表头/生成/含数据JSON下载，tables及完整execute与独立离线底稿完全相等（27已对应/1未对应/2异常）；离线规则变更及人工确认底稿公开恢复、三处差异和经办依据显示，实际重新下载后whole session与完整execute精确相等（5已对应/3未对应/4异常）。截图与实际底稿同目录。

公开退出清空未验证：Codex IAB的原生confirm点击使CDP超时，getJsDialog返回undefined，键盘接口也超时，桌面Codex界面控制不受支持；没有绕过确认，没有把此项记通过。真实本地Streamlit卸载重进和跨工具清空已通过；公开最终门禁仍待能操作确认框后验证。D03保持packaged、未accepted/未冻结，禁止重新打包改变已公开同版本文件。Windows实机仍未验证。正式1/64未变。

D06新专属线程01a1018e-6054-7ab3-b74b-462071704cf0，题名“D06｜财务明细核查：完整业务工具”，已启动，只改自身旧目录，按财务业务多页重做0.2.0源码候选；登记搬目录、公共包、打包、官网、最终验收由总控维护，0.1.0/0.1.1不动。D03未决官网确认检查与D06开发可以独立推进。

## 线程与分工

总控负责登记/公共代码/官网/构建/发布/验收，每款一个长期线程。D02线程01a1011d-f762-7790-8263-1600748f3f21已交接，进入维护；原实现/说明线程最新completed、cursor29。D03专属线程01a1016b-3039-7da3-9fd8-550a990d4cb7已交接六页源码，正式集成验收中；其余62款按分线程开发计划推进，不逐款问继续；先D03，再D06，之后财务模块。

## D02实际验收证据

progress/evidence/D02/0.2.0：
- 69项计算/IO测试，本款38项，typecheck通过。独立人工六类7/6预期、金额精度/空零负值/币种期间、来源行、方案与底稿重算在源码和浏览器证据中。
- browser-initial/browser-input：Mac Chromium断网file://五页、手机、实际30笔CSV/XLSX、表头/页签/范围/换文件失效、公式缓存拒绝、真实XLSX/JSON导出回读恢复、无HTTP/storage。
- site-local-native/site-local-input：真实Streamlit8514，77总/13结账、原详情与同站五页；七项实际下载hash及ZIP内HTML一致；同财务结果，实际输入、恢复、取消离开/确认卸载/重进空，处理期间工具HTTP为0。
- source-rebuild：最终源码ZIP独立/private/tmp解压，npm ci锁定依赖、69项测试、typecheck、build；HTML和runtime逐字节一致，包含共享包/锁文件/工具/测试/许可/说明。
- rendered-review：五页桌面、复核手机、官网详情和工作区实际逐张审阅通过。
- site-public-final：公开官网db57b03实际模块→详情→同站工作区；七项最终实际下载hash/离线ZIP内HTML一致；30笔实际CSV/XLSX的tables/result/sums/sourceSums与离线逐项相等；离线三次复核底稿官网恢复再下载完整run/tables相等；返回详情后重进双方为空。实际JSON/文件及截图保留。
- download-transport：官网传统静态包链接真实404已修复为第一方ASCII JSON运输/SHA校验/本地Blob，篡改拒绝不下载、原文件恢复成功；no-store消除同版本缓存重试问题。包名和页面视觉保留。

官网工程../aiplus-streamlit当前db57b03；回退tag codex/before-D02-native-0.2.0→40eea3e。新release/D02/0.2.0已加入catalog/release-locks.json冻结。以后修改必须新版本，不能重打0.2.0。此前公开部分/404/确认框失败保留历史，不是当前未决问题。

## 下一步

D02/D03已验收，维护反馈回原线程。D06源码已交接，当前由总控完成三款官网回归、独立发布门禁与公开实际验收；未通过不得accepted。之后按分线程开发计划先创建R01专属线程，持续推进64款。

本地8514是暂存，不能替代公开官网；历史阶段见history/。先读README/catalog/本文件/分线程开发计划，再读本款规格、参考来源、财务规则、任务与接续。

## 本轮公共接入与D03实际状态

scripts/build.ts改为按唯一登记动态加载本款版本/名称/目录，避免导入其他开发中工具。真实program入口自动生成原生runtime；后续款需release-assets接口交付实际模板和完全虚构样例，校验文件名/重复/10MB及必需项。package.py按真实已实现目录打源码；verify-source.py可检查后续原生款入口、样例接口和共享下载模块。接口见docs/工具交付接入.md，已发送给D03原线程。

本轮实际69/69测试、typecheck通过；D02冻结0.2.0重建字节一致、全部5版本61锁定文件hash不变；Python语法通过。证据progress/evidence/shared/2026-10-03-build-integration.json。尚未构建D03新版，不将接口或开发中目录计完成。

早期观察D03原线程active/inProgress、cursor9（最新状态见下方正式集成检查点），同一turn01a1016b-32ce-7180-a972-bff87621e9cb；已生成六页program/main、release-assets、workflow/restore/work-export，线程报告本款28项测试及类型检查通过。总控尚未独立执行本款成品验证，仍待正式交接。正式名称/目录在交接后总控同步，不能边开发边搬目录。继续先wait_threads原句柄，不因观察超时重启。

## 本轮官网多工具准备

scripts/site.py支持保留D02并显式暂存后续D03：财务名称来自唯一登记，按主数据归属新增原风格条目与详情，按当前路由返回本款详情，原主数据六条不冒称完成。默认D02单款生成HTML与当前暂存逐字节一致。结构夹具核验双款总数78/结账13/主数据7、独立路由与七项下载；夹具使用D02资产模拟目录，明确不构成D03业务证据。证据progress/evidence/shared/2026-10-03-multi-site-structure.json。

未暂存D03，未修改或发布官网。新增工具发布门禁尚待本款完整证据接入，apply显式拒绝借用D02验收发布多工具。正式名称同步与文件夹搬迁仍在D03交接后进行。

## D03正式集成检查点

D03原线程completed/idle、cursor23；目录/登记正式同步tools/D03-科目与客商对应关系、0.2.0，含科目/客商/部门，归原主数据模块同风格新行，原六条不标完成。正式HTML/runtime/候选ZIP已生成，尚未冻结/公开/accepted。86全工程/29本款测试和typecheck通过。

证据progress/evidence/D03/0.2.0：browser/result和input/result验证正式断网六页、390/320px原行10–13不折行与详情、长页切换/未提交取消、确认撤销、实际JSON/XLSX下载回读恢复、无数据清空；独立30CSV/XLSX/二行表头手算27已映射/1未映射/2异常，空零负金额、前导零、不同币种单位期间保留。site-local/result验证真实8514原主数据7/总78、原详情、七项实际下载SHA和ZIP内HTML、同站无内层iframe、导入处理恢复和卸载重进空。site-input/result完整run/tables逐项等于离线30笔。宿主localStorage预存1项，工具前后local/session存储完全相同；首次零存储断言失败留档。

候选源码ZIP独立npm ci/test/typecheck/build，HTML/runtime相等。此后root浏览器脚本扩展，正式说明与最终源码发布前同步并重新绑定精确ZIP证据。已实际查看六张正式离线桌面、320px行号及本地官网待办图，rendered-review登记。全部5版本61锁定文件SHA不变。D02在双工具站点下载/财务/实际30笔/复核恢复/退出重进回归通过，新增证据progress/evidence/site-integration/D02-D03，旧证据不覆盖。

下一步补实际规则维护/范围/版本比较、真实官网长页及跨工具数据隔离，最终资料源码同包重建；接入D03逐款发布证据门禁，回退标记后发布，实际公开官网工作区/导入恢复/全部下载通过才accepted。apply现仍拒绝多工具借用D02验收。完整目标继续，当前完成仍1/64；Windows实机未验证。
