# 当前进度

2026-10-03。目标64款，正式accepted **4/64**：D02账表对账、D03科目与客商对应关系、D06财务明细核查（均0.2.0），R01合同开票回款台账（0.1.0）。Mac Chromium有实际证据；Windows实机未验证。

| 工具 | 当前状态 | 下一步与证据 |
|---|---|---|
| D02 / D03 / D06 | accepted，原线程维护 | 已冻结8版本100文件；本轮四款原生官网受影响回归通过 |
| R01 合同开票回款台账 | accepted 0.1.0，原线程维护 | 正式断网14组、源码127测试/重建一致、本地原生流程17/导航43/下载11；公开五表XLSX/二行表头CSV/含无数据恢复/退出取消确认/重进空/完整八表底稿/全部11项实际下载通过；最终证据site-public-final.json |
| R02 收入确认排程表 | packaged 0.1.0；正式离线与源码包已构建，原线程idle | 总控10组独立手算、41本款测试、八页实际视觉审阅、新正式HTML断网35组通过（五类XLSX/31笔CSV/恢复/下载回读/精度/320与390）；源码ZIP独立npm ci/test/typecheck/build均0、HTML/runtime逐字节一致；真实原生同站八页/30组普通点击导航/恢复/五类XLSX/31筆CSV/退出重进/底稿逐格相等及11下载通过；五款门禁与公开官网仍待验 |
| R03 回款对账 | implementing；候选交接，原线程idle | 线程报告40本款测试、208全工程回归、36浏览器及21补充组通过；八页流程已交接锁定，须总控独立复核；未正式发布 |
| 其余58款 | planned | 按模块批次创建各款唯一线程，完整业务设计后再实现 |

官网发布commit `50dbf4eecc134ee719d0fa7c3bc2da503ecaea7e`，四款D02/D03/D06/R01；回退tag `codex/before-R01-native-0.1.0`。四款本地证据：`progress/evidence/site-integration/D02-D03-D06-R01/`；门禁：`integration/native-site/acceptance.json`。site SHA `5ae05f450ba29848ce5a803d29a05c78dfb6057b922f544149656e9c9bfa583f`。

R01正式HTML SHA `4739a4f179b1f1a079472b6d15ebfc0765845e5827366f29ffb16c1df23aea9a`；runtime `3c62aacde76fe3f2f3f1c5aca2d132b812d979271a5ed535c1d472ff678d8251`；源码ZIP `420004ec2663870bb83570936b17cd7084fb66c5e26209e94665f5629d241155`。已公开字节禁止同版本重打。最终公开验收：`progress/evidence/R01/0.1.0/site-public-final.json`，accepted=true；早期检查点与导航失败保留为历史，不代表当前状态。

每款一个长期工具线程，总控独立负责公共代码、官网和最终验收。已建立6个，剩余58个分批创建，最多两款同时实现；修复沿用原线程，不逐款询问继续。完整64款与交接约定见[分线程开发计划](分线程开发计划.md)，当前线程与恢复顺序见[线程调度与接续](线程调度与接续.md)，唯一索引`catalog/threads.json`。

当前线程规划已核对64个唯一ID、6个唯一线程、正式accepted4款。旧状态文件与SHA存于`progress/history/`；历史作者声明和候选截图不充当当前正式验收。

本轮仅校正分线程执行约定与调度索引：64个工具ID、6个唯一工具线程、58个待建；总控集成队列R02/R03，下一实现批次R04/R05。未创建重复线程，未更改程序或发布状态。

R02本轮原生官网证据：`progress/evidence/R02/0.1.0/native-integration-checkpoint.json`。原应收「收入确认排程表」条目复用，五款暂存仍80项；公开官网仍四款，未更新accepted。41本款测试与10独立手算重跑通过，typecheck退出0。初始测试选择器及退出分支失败保留为历史，程序源码未改。
