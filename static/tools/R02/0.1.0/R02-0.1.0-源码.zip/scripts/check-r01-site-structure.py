# coding: utf-8
"""Structural fixture only: not financial, offline, source or public acceptance."""
from pathlib import Path
import importlib.util,json,hashlib,re,tempfile
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('native_site',ROOT/'scripts/site.py');site=importlib.util.module_from_spec(spec);spec.loader.exec_module(site)
base=(ROOT/'website/base-index.html').read_text();host=(ROOT/'integration/native-host.js').read_text()
entries=json.loads((ROOT.parent/'aiplus-streamlit/site/registry.json').read_text())
files=[[f"{e['id']}-{e['version']}-离线包.zip",f"{e['id']}-{e['version']}-源码.zip",'虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md'] for e in entries]
previous=site.native_documents(base,entries,files,host)
assert previous==(ROOT.parent/'aiplus-streamlit/site/index.html').read_text()
extra=['R01-0.1.0-离线包.zip','R01-0.1.0-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md','开票记录模板.csv','回款记录模板.csv','关联与分配模板.csv','独立收入资料模板.csv']
entry={'id':'R01','name':'合同开票回款台账','version':'0.1.0','detailRoute':'tool-R01','workspaceRoute':'work-R01','runtime':'app/static/tools/R01/0.1.0/runtime.json','sha256':'0'*64,'bytes':1,'offlineSize':'fixture only'}
with tempfile.TemporaryDirectory(prefix='aiplus-r01-structure-',dir='/private/tmp') as tmp:
 site.ROOT=Path(tmp);release=site.ROOT/'release';release.mkdir()
 for e in entries:(release/e['id']).symlink_to(ROOT/'release'/e['id'],target_is_directory=True)
 fixture=release/'R01/0.1.0';fixture.mkdir(parents=True)
 for name in extra:(fixture/name).write_bytes(('STRUCTURE ONLY: '+name).encode())
 result=site.native_documents(base,entries+[entry],files+[extra],host)
 assert len(re.findall(r'\bdata-tool\s',result))==80
 assert result.count('id="r-tool-R01"')==result.count('id="r-work-R01"')==1
 row=re.search(r'<div class="trow" data-tool data-mod="ar"[^\n]*合同开票回款台账.*?</div></div>',result,re.S);assert row
 detail=re.search(r'<template id="r-tool-R01">.*?</template>',result,re.S).group()
 assert '开始维护票款台账' in detail and '不自动判断收入' in detail
 for name in extra:assert 'download="'+name+'"' in detail
 assert '虚构左表.csv' not in detail and '开始账表对账' not in detail
 for rid in ['ar-01','ar-04']:
  original=re.search(r'<template id="r-tool-'+rid+r'">.*?</template>',base,re.S).group();assert original in result
 assert 'data-count="mod:ar">'+str(int(re.search(r'data-count="mod:ar">(\d+)',base)[1])+1) in result
 assert site.stage_selection(json.loads((ROOT/'catalog/tools.json').read_text()))==['D02','D03','D06']
 checks=['existing_three_tool_site_exactly_unchanged','R01_original_ar_module_row_and_routes','original_AR_platform_and_invoice_templates_unchanged','eleven_download_links_include_all_five_csv_templates','truthful_task_entry_and_financial_scope','default_stage_only_accepted_three_tools']
 proof={'date':'2026-10-03','scope':'structural fixture only; synthetic R01 downloads and runtime; not an implemented/published or accepted artifact','checks':checks,'passed':True,'existing_site_sha256':hashlib.sha256(previous.encode()).hexdigest(),'candidate_R01_count':80,'public_validation':'not performed'}
 (ROOT/'progress/evidence/shared/2026-10-03-R01-site-structure.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
 print('PASS: six structure checks; existing three-tool site unchanged; no release/stage/publication mutation.')
