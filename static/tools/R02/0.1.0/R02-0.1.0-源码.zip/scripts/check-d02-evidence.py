"""Check exact-version local publication evidence; public acceptance is separate.

Default reports missing/stale proof without writing permission to publish.
--write creates the existing site.py local gate only if every check passes.
"""
import hashlib,json,pathlib,sys,zipfile
root=pathlib.Path.cwd();version='0.2.0'
release=root/'release/D02'/version;stage=root/'integration/native-site'
evidence=root/'progress/evidence/D02'/version
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
errors=[]
def check(ok,message):
 if not ok:errors.append(message)
def read(name):
 p=evidence/name
 if not p.is_file():errors.append(f'{name}: missing');return {}
 return json.loads(p.read_text())
html=sha(release/'index.html');runtime=sha(release/'runtime.json');site=sha(stage/'site/index.html')
for name,needed in [
 ('browser-initial.json',['offline_file_five_pages','six_categories_manual_expected_7_6',
 'review_three_transitions','actual_work_config_xlsx_downloads_readback','work_restore_review_preserved',
 'config_restore_no_results','mobile_review_no_outer_overflow','no_http_requests_or_localStorage']),
 ('browser-input.json',['actual_csv_xlsx_import','text_leading_zero_zero_negative','full_search_and_pagination',
 'value_date_filters_excluded_rows','parameter_sheet_header_source_invalidate',
 'second_sheet_second_header_source_row','formula_cache_not_calculated','no_http_storage'])]:
 data=read(name);check(data.get('version')==version and data.get('html_sha256')==html,f'{name}: stale or unbound HTML')
 check(set(needed)<=set(data.get('checks',[])),f'{name}: incomplete browser checks')
source=read('source-rebuild.json');archive=release/f'D02-{version}-源码.zip'
check(source.get('source_zip_sha256')==sha(archive),'source-rebuild.json: stale source ZIP')
check(set(['工具总览.md','tests/d02-v2-input-browser.ts','tests/d02-native-site.ts','tests/d02-native-input.ts',
           'scripts/check-d02-evidence.py','scripts/verify-source.py'])
      <=set(source.get('required_files_checked',[])),
      'source-rebuild.json: source package verification predates final import/restore test scripts')
for name,expected in [('index.html',html),('runtime.json',runtime)]:
 proof=source.get('files',{}).get(name,{})
 check(proof.get('release_sha256')==expected and proof.get('rebuilt_sha256')==expected and proof.get('identical') is True,f'source-rebuild.json: {name} differs/unbound')
commands=source.get('commands',[])
check(len(commands)==4 and all(c.get('exit_code')==0 for c in commands),'source-rebuild.json: commands incomplete')
local=read('site-local-native.json')
check(local.get('html_sha256')==html and local.get('runtime_sha256')==runtime and local.get('site_sha256')==site,'site-local-native.json: stale program/site')
needed=['business_module_77_13','original_detail_style','seven_first_party_download_hashes',
 'downloaded_offline_zip_html_matches','same_document_native_tool_no_inner_iframe_or_new_tab',
 'one_program_on_entry','business_page_heading_visible_after_navigation','same_7_6_manual_counts','work_export_readback','cancel_exit_preserves',
 'confirm_exit_disposes','reentry_empty']
check(set(needed)<=set(local.get('checks',[])),'site-local-native.json: missing navigation/download/run checks')
native_input=read('site-local-input.json')
check(native_input.get('html_sha256')==html and native_input.get('runtime_sha256')==runtime
      and native_input.get('site_sha256')==site,'site-local-input.json: stale program/site')
check(set(['native_actual_csv_xlsx_import','native_equals_offline_all_results_and_source_sums',
           'native_restore_review_history_exact','native_download_restored_work_readback',
           'no_tool_http_requests_after_import'])<=set(native_input.get('checks',[])),
      'site-local-input.json: incomplete actual import/restore checks')
for name,key in [('新导入三十笔.json','offline_input_evidence_sha256'),('工作底稿.json','offline_review_work_sha256')]:
 check(native_input.get(key)==sha(evidence/name),f'site-local-input.json: stale compared offline {name}')
names=[f'D02-{version}-离线包.zip',f'D02-{version}-源码.zip','虚构样例.xlsx','空白模板.csv',
       '使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md']
for name in names:
 expected=sha(release/name);download=evidence/'site-local-downloads'/name
 staged=stage/'static/tools/D02'/version/name
 check(local.get('downloads',{}).get(name)==expected,f'download evidence stale: {name}')
 check(download.is_file() and sha(download)==expected,f'actual download stale/missing: {name}')
 check(staged.is_file() and sha(staged)==expected,f'staged file stale/missing: {name}')
check(sha(stage/'static/tools/D02'/version/'runtime.json')==runtime,'staged runtime stale')
with zipfile.ZipFile(release/names[0]) as z:
 check(hashlib.sha256(z.read('D02/index.html')).hexdigest()==html,'offline ZIP HTML differs')
visual=read('rendered-review.json')
check(visual.get('html_sha256')==html and visual.get('site_sha256')==site,'rendered-review.json: stale or missing actual visual review')
check(visual.get('reviewed') is True and visual.get('passed') is True and not visual.get('issues')
      and visual.get('reviewer') and visual.get('screenshots')
      and set(['两方资料','范围与口径','差异总览','逐项复核','结果底稿'])<=set(visual.get('pages',[]))
      and visual.get('mobile_reviewed') is True and visual.get('site_reviewed') is True,
      'rendered-review.json: actual visual review required, screenshot presence alone is insufficient')
print(json.dumps({'tool':'D02','version':version,'ready_for_local_publication':not errors,
                  'public_acceptance':'still requires deployed browser and actual download evidence',
                  'errors':errors},ensure_ascii=False,indent=2))
if errors:sys.exit(1)
if '--write' in sys.argv:
 gate={'site_sha256':site,'local_site_navigation':True,'finance_same_results':True,
       'downloads_hashes':True,'offline':True,'source_rebuild':True,'rendered_product_ui':True,
       'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':sha(archive)}
 (stage/'acceptance.json').write_text(json.dumps(gate,indent=2)+'\n')
