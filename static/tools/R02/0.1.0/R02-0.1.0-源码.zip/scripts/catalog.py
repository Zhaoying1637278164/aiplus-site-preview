from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
cards=json.loads((root/'catalog/tools.json').read_text())
assert len(cards)==64 and len({c['id'] for c in cards})==64
lines=['# 工具总览','', '64 款全部纳入本轮。登记不等于交付；只有 accepted 计完成。名称、状态和参考来自 catalog/tools.json。', '', '| 编号 | 中文名称与文件夹 | 解决的问题 | 主要参考 / 借鉴 | 核验 | 开发交付 | 官网与下载 |','|---|---|---|---|---|---|---|']
for c in cards:
 p=root/'tools'/c['folder'];p.mkdir(exist_ok=True)
 for d in ['src','examples','tests']:
  (p/d).mkdir(exist_ok=True)
 refs='<br>'.join('['+r['name']+']('+r['url']+')：'+r['method']+('（'+r['status']+'）' if r.get('status') else '') for r in c['references'])
 delivered=c.get('delivery',{})
 links='；'.join('['+k+']('+v+')' for k,v in delivered.items()) or '尚未交付'
 lines.append('| '+c['id']+' | ['+c['name']+'](tools/'+c['folder']+'/README.md) | '+c['fields'].get('输出','')+' | '+refs+' | '+c['reference_status']+' | '+c['status']+' | '+links+' |')
 f=p/'README.md'
 if not f.exists():
  f.write_text('# '+c['id']+' '+c['name']+'\n\n'+ '## 做什么\n\n'+c['fields'].get('默认核心能力','')+'\n\n## 输入\n\n'+c['fields'].get('输入','')+'\n\n建议字段：'+c['fields'].get('模板字段建议','')+'\n\n## 输出\n\n'+c['fields'].get('输出','')+'\n\n## 使用与状态\n\n尚未实现，不能运行。完成后提供独立 HTML、模板、示例和导出，不依赖账号。登记不计完成。\n\n边界：'+c['fields'].get('不覆盖','')+'\n\n[参考来源](参考来源.md) · [财务规则](财务规则.md) · [示例](examples/) · [测试](tests/)\n')
 f=p/'参考来源.md'
 if not f.exists():
  text='# '+c['id']+' 参考来源\n\n本表是 V2 候选登记；未读取具体源文件，不能据此开始业务编码。\n'
  for r in c['references']:
   text+='\n## '+r['name']+'\n\n- 来源类型：'+('YouTube 视频' if 'youtube.com' in r['url'] else 'GitHub 项目 / Skill' if 'github.com' in r['url'] else '其他方法资料')+'\n- 原始链接：'+r['url']+'\n- 具体路径/章节/时间点：待核验。\n- 版本/提交/访问日期：待核验；登记依据 V2 2026-09-30。\n- 借鉴内容：'+r['method']+'\n- 对应功能模块：待规格化，不声称采用。\n- 使用方式：候选方法参考，暂无代码复用。\n- 状态：候选来源；未读具体文件、未运行、未采用。\n- 已验证：仅从用户提供 V2 取得关联，未独立验证。\n- 尚未验证/限制：中国口径、公式、输入输出、兼容性及许可证待核验。\n- 许可证与声明：待核验；未核验前禁止代码复用。\n'
  f.write_text(text)
 f=p/'财务规则.md'
 if not f.exists():f.write_text('# '+c['id']+' 财务规则\n\n[共同口径](../../docs/finance-rules.md)。\n\n设计要求：'+c['fields'].get('默认核心能力','')+'\n\n可配置：'+c['fields'].get('用户可改','')+'\n\n验收重点：'+c['fields'].get('独立验收重点','')+'\n\n尚未形成可执行规则；依据、生效期、参数、公式与独立答案待补，不计财务验收完成。\n')
(root/'工具总览.md').write_text('\n'.join(lines)+'\n')
