"""Validate actual exact-version evidence for the reviewed native website.
This local publication gate never declares public acceptance.
"""
import hashlib,json,pathlib,sys,zipfile
ROOT=pathlib.Path.cwd();STAGE=ROOT/'integration/native-site';errors=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,message):
 if not ok:errors.append(message)
def read(p):
 if not p.is_file():errors.append(str(p)+': missing');return {}
 return json.loads(p.read_text())
def proof(p,expected,needed):
 d=read(p)
 for key,value in expected.items():check(d.get(key)==value,str(p)+': stale '+key)
 check(set(needed)<=set(d.get('checks',[])),str(p)+': incomplete executed checks')
 return d
registry=read(STAGE/'site/registry.json');check(isinstance(registry,list),'registry structure')
if not isinstance(registry,list):sys.exit(1)
ids=[e.get('id') for e in registry]
check(ids in [['D02','D03'],['D02','D03','D06'],['D02','D03','D06','R01'],['D02','D03','D06','R01','R02']],'only reviewed tool registration')
five=ids==['D02','D03','D06','R01','R02']
four=len(ids)>=4
three=len(ids)>=3
suite=ROOT/'progress/evidence/site-integration'/('-'.join(ids))
total=76+sum(not e.get('replacesOriginal') for e in registry);closing=12+sum(i in ['D02','D06'] for i in ids)
catalog={e['id']:e for e in read(ROOT/'catalog/tools.json')}
site=sha(STAGE/'site/index.html');bind={};download_folders={}
for entry in registry:
 identifier=entry['id'];version=entry['version'];release=ROOT/'release'/identifier/version
 check(entry['name']==catalog[identifier]['name'] and version==catalog[identifier]['version'],'catalog mismatch '+identifier)
 h=sha(release/'index.html');runtime=sha(release/'runtime.json');bind[identifier]=(version,h,runtime)
 check(entry['sha256']==runtime and entry['bytes']==(release/'runtime.json').stat().st_size,'registry runtime mismatch '+identifier)
 check(sha(STAGE/'static/tools'/identifier/version/'runtime.json')==runtime,'staged runtime mismatch '+identifier)
 ev=ROOT/'progress/evidence'/identifier/version
 source=read(ev/'source-rebuild.json');check(source.get('source_zip_sha256')==sha(release/f'{identifier}-{version}-源码.zip'),'source ZIP changed '+identifier)
 check(len(source.get('commands',[]))==4 and all(c.get('exit_code')==0 for c in source.get('commands',[])),'source commands incomplete '+identifier)
 for filename,expected in [('index.html',h),('runtime.json',runtime)]:
  item=source.get('files',{}).get(filename,{})
  check(item.get('identical') is True and item.get('release_sha256')==expected and item.get('rebuilt_sha256')==expected,'source rebuilt bytes mismatch '+identifier+'/'+filename)
 with zipfile.ZipFile(release/f'{identifier}-{version}-离线包.zip') as z:check(hashlib.sha256(z.read(identifier+'/index.html')).hexdigest()==h,'offline ZIP HTML mismatch '+identifier)
 if identifier=='D02':
  proof(ev/'browser-initial.json',{'version':version,'html_sha256':h},['offline_file_five_pages','six_categories_manual_expected_7_6','review_three_transitions','actual_work_config_xlsx_downloads_readback','work_restore_review_preserved','config_restore_no_results','mobile_review_no_outer_overflow','no_http_requests_or_localStorage'])
  proof(ev/'browser-input.json',{'version':version,'html_sha256':h},['actual_csv_xlsx_import','text_leading_zero_zero_negative','full_search_and_pagination','value_date_filters_excluded_rows','parameter_sheet_header_source_invalidate','second_sheet_second_header_source_row','formula_cache_not_calculated','no_http_storage'])
  localdir=suite/'D02' if three else suite
  local=proof(localdir/'site-local-native.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},[f'business_module_{total}_{closing}','original_detail_style','seven_first_party_download_hashes','same_document_native_tool_no_inner_iframe_or_new_tab','one_program_on_entry','business_page_heading_visible_after_navigation','same_7_6_manual_counts','work_export_readback','cancel_exit_preserves','confirm_exit_disposes','reentry_empty'])
  imported=proof(localdir/'site-local-input.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},['native_actual_csv_xlsx_import','native_equals_offline_all_results_and_source_sums','native_restore_review_history_exact','native_download_restored_work_readback','no_tool_http_requests_after_import'])
  for f,key in [('新导入三十笔.json','offline_input_evidence_sha256'),('工作底稿.json','offline_review_work_sha256')]:check(imported.get(key)==sha(ev/f),'D02 compared offline work stale')
  actual=local.get('downloads',{});folder=localdir/'site-local-downloads'
 elif identifier=='D03':
  siteev=suite/'D03' if three else ev
  proof(ev/'browser/result.json',{'version':version,'html_sha256':h},['six_pages_render','manual_expected_12_3_1_1_3_4','row_conflict_confirm_revoke','actual_json_xlsx_download_readback','replacement_clears_prior_decisions','work_restore_recalculate','no_data_plan_clear','mobile_row_10_13_single_line_390_320_and_detail','long_page_scroll_all_six_pages_fixed_header','cancel_page_change_preserves_unsubmitted_input','no_http_requests','no_localStorage','no_page_errors'])
  needed=['new_30_csv_xlsx','actual_sheet_header2','manual_category_scoped_expected','leading_zero_source','null_zero_negative_original','mixed_currency_unit_period_no_aggregation','original_row_trace','actual_json_download_decode']
  proof(ev/'input/result.json',{'version':version,'html_sha256':h},needed)
  proof(siteev/'site-input/result.json',{'version':version,'html_sha256':h,'site_sha256':site},needed+['native_equals_offline_tables_and_complete_run','no_http_or_tool_storage_writes'])
  business=['rule_new_invalid_blocked','rule_edit_clears_confirmation','rule_delete_add_confirm','baseline_three_independent_differences','baseline_restore_clears_row_decision','undo_restores_mapping_and_row_decision','category_scope_date_manual_expected','complete_excluded_source_readback','long_page_source_navigation_visible','no_http_during_data_processing']
  proof(ev/'business/result.json',{'version':version,'html_sha256':h},business)
  proof(siteev/'site-business/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},business+['dirty_exit_cancel_preserves','cross_tool_dispose_reentry_empty','loads_only_current_program'])
  local=proof(siteev/'site-local/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},[f'original_module_{total}_{closing}_7','same_document_no_inner_iframe','seven_actual_downloads_hashes','offline_zip_inner_html_same','exit_dispose_reentry_empty','no_http_requests','no_tool_storage_writes','no_page_errors'])
  actual={d['filename']:d['sha256'] for d in local.get('downloads',[])};folder=siteev/'site-local'
  check(set(['tests/d03-v2-browser.ts','tests/d03-v2-input-browser.ts','tests/d03-native-site.ts','tests/d03-business-browser.ts','scripts/check-native-evidence.py'])<=set(source.get('required_files_checked',[])),'D03 source archive predates final validation scripts')
 elif identifier=='R02':
  siteev=suite/'R02'
  check(entry.get('replacesOriginal') is True and entry['detailRoute']=='tool-ar-03','R02 original financial row/detail must be reused')
  offline=read(ev/'formal-browser/result.json')
  check(offline.get('formal_html_sha')==h and offline.get('requests')==[] and offline.get('errors')==[],'R02 formal offline binding or safety')
  rows=offline.get('results',[])
  check(len(rows)==35 and all(r.get('pass') is True for r in rows),'R02 all 35 formal offline cases must pass')
  needed=['real_registered_Streamlit_same_document_eight_pages_no_inner_iframe','manual_25000_allocation_15000_due_6000_actual_19000_remaining','actual_offline_whole_work_and_every_XLSX_cell_equal','cancel_restore_preserves_and_nodata_restore_clears','five_actual_XLSX_imports_manual_due_11000','30_real_original_header_long_page_navigation_restore_geometry_no_forced_click','actual_31_CSV_rows_pagination_source17_manual_310_10690','no_processing_HTTP_storage_writes_or_page_errors','cancel_exit_preserves_imported_work','exit_to_original_detail_and_reenter_empty']
  workflow=proof(siteev/'site-local/result.json',{'tool':'R02','version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site,'forced_clicks':0},needed)
  check(workflow.get('processing_requests')==[] and workflow.get('errors')==[],'R02 processing network or script errors')
  geometry=workflow.get('geometry',[]);check(len(geometry)==30,'R02 30 actual native geometry cases missing')
  for r in geometry:
   g=r['navigation'];a=r['active'];b=r['heading'];header=r['header']
   check(g['y']>=header['y']+header['height']+4 and b['y']>=g['y']+g['height']-1 and b['y']+b['height']<(1000 if r['width']==1440 else 844) and a['x']>=g['x']-1 and a['x']+a['width']<=g['x']+g['width']+1,'R02 original header/title/current tab geometry')
  local=proof(siteev/'downloads/result.json',{'tool':'R02','version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},['original_financial_module_and_detail','eleven_actual_first_party_downloads_exact_hash','offline_zip_inner_html_same','detail_does_not_load_program'])
  actual=local.get('downloads',{});folder=siteev/'downloads/site-local-downloads'
  check(set(['tests/r02-native-site.ts','tests/r02-native-downloads.ts','tests/r02-formal-browser.ts','tests/r02-independent-review.ts','scripts/check-native-evidence.py'])<=set(source.get('required_files_checked',[])),'R02 source archive must contain final native validation scripts')
 elif identifier=='R01':
  siteev=suite/'R01'
  needed=['人工基线3待处理、收入未提供、350票余额、1150合同未收与回款守恒', '实际XLSX下载回读8页签、未提供与复核备注', '无数据方案清全部资料，含数据恢复后整工作精确等价', '取消草稿离页保留、提交后结果与备注失效、变更历史和重算', '真实分配编辑超额整组阻塞，依赖票回款与红字重新校验', '9业务页桌面/390/320实际渲染、标题定位及合同编辑无页面横溢', '来源追查保留文件页签原行及原值', '实际XLSX五页签分别导入，人工金额和勾稽保持一致', '五类实际CSV模板下载与标准字段核对', '实际新增零合同、删除与关联重校及变更历史', '实际回款撤销日期维护、450净回款及其分配失效', 'CSV第二行表头换资料、原行3、零有效/缺失/重复3错误及旧关联失效', '实际XLSX说明首表、资料页选择、公式缓存999拒绝', '全未关联票800/部分关联全量500与关联100/无合同客户800：实际JSON恢复、总览客户原票及XLSX范围勾稽']
  offline=proof(ev/'formal-browser/result.json',{'app':version,'html_sha':h,'runtime_sha':runtime},needed)
  check(offline.get('offline') is True and offline.get('file_protocol') is True and offline.get('requests')==[] and offline.get('errors')==[] and offline.get('storage')==0,'R01 formal offline safety proof incomplete')
  workflow=proof(siteev/'site-local/result.json',{'app':version,'html_sha':h,'runtime_sha':runtime,'site_sha':site},needed+['registered_real_Streamlit_same_document_nine_pages_no_inner_iframe','actual_offline_whole_work_and_run_restored_exactly_same','native_exit_cancel_preserves_confirm_disposes_reentry_empty'])
  check(workflow.get('processing_requests')==[] and workflow.get('errors')==[] and workflow.get('storage_unchanged') is True,'R01 native processing network/storage/errors')
  nav=read(siteev/'navigation/result.json')
  for k,v in {'status':'passed','html_sha256':h,'runtime_sha256':runtime,'site_sha256':site,'formal_rebuilt_site':True}.items():check(nav.get(k)==v,'R01 formal navigation stale '+k)
  check(nav.get('errors')==[],'R01 formal navigation errors')
  rows=nav.get('results',[]);check(len(rows)==43,'R01 formal long-page navigation cases incomplete')
  for r in rows:
   g=r.get('geometry',{});check(r.get('mode')=='streamlit-formal' and g.get('hitActive') is True,'R01 actual current-tab click geometry incomplete')
   if g:check(g['top']>=max(76,g['headerBottom'])+4 and g['bottom']<g['titleTop'] and g['titleBottom']<g['height'] and g['activeLeft']>=g['navLeft']-1 and g['activeRight']<=g['navRight']+1,'R01 original header/nav/title/current tab visibility')
  local=proof(siteev/'downloads/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},['original_financial_module_and_detail','eleven_actual_first_party_downloads_exact_hash','offline_zip_inner_html_same','detail_does_not_load_program'])
  actual=local.get('downloads',{});folder=siteev/'downloads/site-local-downloads'
  check(set(['source-snapshot.json','tests/r01-formal-browser.ts','tests/r01-native-site.ts','tests/r01-native-downloads.ts','tests/r01-native-navigation.ts','scripts/check-native-evidence.py'])<=set(source.get('required_files_checked',[])),'R01 source archive predates final tests')
 else:
  siteev=suite/'D06'
  offline=proof(ev/'browser/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime},['虚构八行独立17异常','逐项复核撤销三次保留异常','真实XLSX及工作方案下载回读','无数据清旧资料与含数据恢复重算','范围6纳入2排除13异常且复核失效','实际XLSX导入公式不采缓存','规则容差修改重算16','实际CSV表头更换与零值新资料'])
  check(offline.get('offline') is True and offline.get('file_protocol') is True and not offline.get('errors') and not offline.get('requests'),'D06 offline protocol/network proof incomplete')
  needed=['csv_30_manual_issues_and_sources','xlsx_30_manual_issues_and_sources','csv_currency_period_unit_scope_manual_expected','xlsx_currency_period_unit_scope_manual_expected','leading_zero_null_zero_negative_precise_decimal','formula_cached_999_never_used','second_sheet_header2_original_rows_3_32','all_sources_no_mixed_aggregation','no_http_or_storage']
  proof(ev/'input/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime},needed)
  proof(siteev/'site-input/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},needed+['native_equals_offline_complete_tables_sessions_runs'])
  workflow=proof(siteev/'site-local/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},['same_document_five_pages_no_inner_iframe','虚构八行独立17异常','逐项复核撤销三次保留异常','真实XLSX及工作方案下载回读','无数据清旧资料与含数据恢复重算','复核草稿取消离页保留与确认放弃','native_equals_offline_complete_work_and_scoped_run','dirty_exit_cancel_and_dispose_reentry_empty','no_http_or_storage_during_processing'])
  check(workflow.get('processing_requests')==[] and workflow.get('errors')==[],'D06 data-processing network/errors')
  nav=read(siteev/'navigation/result.json')
  for k,v in {'status':'passed','html_sha256':h,'runtime_sha256':runtime,'site_sha256':site,'formal_rebuilt_site':True}.items():check(nav.get(k)==v,'D06 formal navigation stale '+k)
  rows=nav.get('results',[])
  for mode in ['offline','streamlit-formal']:
   current=[r for r in rows if r.get('mode')==mode]
   check(len(current)==17,'D06 formal navigation cases incomplete '+mode)
   for r in current:
    g=r.get('geometry')
    if g:check(g['top']>=76 and g['bottom']<g['height'] and g['bottom']<g['title']<g['height'] and g['activeLeft']>=g['navLeft']-1 and g['activeRight']<=g['navRight']+1,'D06 nav/title/current tab hidden')
    if 'sourceRow' in r:check(r['sourceRow']['text']=='10' and r['sourceRow']['lineRects']==1 and r['reviewDetail']['top']>=76 and r['sourceDetailTop']>=76,'D06 mobile source/detail incomplete')
  local=proof(siteev/'downloads/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},['original_financial_module_and_detail','seven_actual_first_party_downloads_exact_hash','offline_zip_inner_html_same','detail_does_not_load_program'])
  actual=local.get('downloads',{});folder=siteev/'downloads/site-local-downloads'
  check(set(['tests/d06-v2-input-browser.ts','tests/d06-native-site.ts','tests/d06-navigation-browser.ts','tests/d06-native-downloads.ts','fixtures/D06/v2-input/独立预期.json'])<=set(source.get('required_files_checked',[])),'D06 source archive predates final tests/independent fixtures')
 names=[f'{identifier}-{version}-离线包.zip',f'{identifier}-{version}-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md']
 if identifier=='R02':names+=['履约事项模板.csv','里程碑模板.csv','已确认收入模板.csv','变更与调整模板.csv']
 if identifier=='R01':names+=['开票记录模板.csv','回款记录模板.csv','关联与分配模板.csv','独立收入资料模板.csv']
 for n in names:
  digest=sha(release/n);p=folder/n
  check(actual.get(n)==digest,'recorded download stale '+identifier+'/'+n)
  check(p.is_file() and sha(p)==digest,'actual download stale '+identifier+'/'+n)
  check(sha(STAGE/'static/tools'/identifier/version/n)==digest,'staged download stale '+identifier+'/'+n)
visual=read(suite/'rendered-review.json')
check(visual.get('site_sha256')==site and visual.get('reviewed') is True and visual.get('passed') is True,'current website visual review missing')
check(visual.get('tools')==ids and visual.get('reviewer')=='Codex actual image inspection','both tools actual image review missing')
for name,digest in visual.get('screenshots',{}).items():
 p=ROOT/name;check(p.is_file() and sha(p)==digest,'reviewed screenshot changed '+name)
check(len(visual.get('screenshots',{}))>=(10 if five else 8 if four else 6 if three else 4),'visual evidence incomplete')
for r in read(ROOT/'catalog/release-locks.json')['releases']:
 for n,digest in r['files'].items():check(sha(ROOT/'release'/r['tool']/r['version']/n)==digest,'frozen version changed')
print(json.dumps({'ready_for_local_publication':not errors,'tools':[e['id'] for e in registry],'site_sha256':site,'public_acceptance':'separate actual public browser/download gates required','errors':errors},ensure_ascii=False,indent=2))
if errors:sys.exit(1)
if '--write' in sys.argv:
 (STAGE/'acceptance.json').write_text(json.dumps({'site_sha256':site,'registry_sha256':sha(STAGE/'site/registry.json'),'tools':[e['id'] for e in registry],'programs':{i:{'version':b[0],'html_sha256':b[1],'runtime_sha256':b[2]} for i,b in bind.items()},'local_site_navigation':True,'finance_same_results':True,'downloads_hashes':True,'offline':True,'source_rebuild':True,'rendered_product_ui':True},indent=2)+'\n')
