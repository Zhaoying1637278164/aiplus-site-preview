import {build} from 'esbuild';
import {mkdir,writeFile} from 'node:fs/promises';
await mkdir('integration',{recursive:true});
const result=await build({entryPoints:['apps/site-host/main.ts'],bundle:true,write:false,format:'iife',platform:'browser',target:'es2022',minify:true});
await writeFile('integration/native-host.js',result.outputFiles[0].text);
