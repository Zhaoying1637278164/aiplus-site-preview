import type {ToolProgram,ToolInstance} from './tool-host';
export interface SiteToolRegistration {
 id:string;name:string;version:string;detailRoute:string;workspaceRoute:string;
 runtime:string;sha256:string;bytes:number;
}
interface RuntimePackage {schema_version:1;id:string;version:string;name:string;js:string;css:string}
type RuntimeWindow=Window&{__aiPlusLoadedProgram?:ToolProgram};

/** Only program bytes are fetched. User files never enter the website boundary. */
export function createSiteToolHost(registry:ReadonlyArray<SiteToolRegistration>){
 let instance:ToolInstance|null=null,activeNode:HTMLElement|null=null,abort:AbortController|null=null,generation=0;
 const entries=new Map(registry.map(r=>[r.id,r]));
 const knownRoutes=new Map(registry.map(r=>[r.workspaceRoute,r.id]));
 function dispose(){
  generation++;abort?.abort();abort=null;
  const previous=instance;instance=null;
  try{previous?.dispose()}finally{activeNode?.replaceChildren();activeNode=null}
 }
 function requestExit(){return instance?instance.requestExit():true}
 async function open(route:string,node:HTMLElement,onExit:()=>void){
  const id=knownRoutes.get(route),entry=id&&entries.get(id);
  if(!entry)throw Error('该工具尚未开放');
  dispose();const current=generation;activeNode=node;
  const controller=new AbortController();abort=controller;
  const message=document.createElement('p');message.setAttribute('role','status');message.textContent='正在准备工具…';node.append(message);
  try{
   if(!/^app\/static\/tools\/[A-Z]\d{2}\/\d+\.\d+\.\d+\/runtime\.json$/.test(entry.runtime))throw Error('程序登记路径无效');
   if(entry.bytes<=0||entry.bytes>8*1024*1024||! /^[a-f0-9]{64}$/.test(entry.sha256))throw Error('程序登记无效');
   const base=new URL(document.baseURI),url=new URL(entry.runtime,base);
   if(url.origin!==base.origin)throw Error('程序来源无效');
   const response=await fetch(url,{signal:controller.signal,credentials:'omit',referrerPolicy:'no-referrer',cache:'no-cache'});
   if(!response.ok)throw Error('工具程序暂时无法读取，请重试');
   if(!response.body)throw Error('工具程序为空');
   const reader=response.body.getReader(),parts:Uint8Array[]=[];let received=0;
   for(;;){
    const chunk=await reader.read();if(chunk.done)break;
    received+=chunk.value.byteLength;
    if(received>entry.bytes){await reader.cancel();throw Error('工具程序体积超过登记上限')}
    parts.push(chunk.value);
   }
   const bytes=new Uint8Array(received);let offset=0;
   for(const part of parts){bytes.set(part,offset);offset+=part.length}
   if(bytes.byteLength!==entry.bytes)throw Error('工具程序体积与登记不一致');
   const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(n=>n.toString(16).padStart(2,'0')).join('');
   if(digest!==entry.sha256)throw Error('工具程序版本校验失败');
   const payload=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)) as RuntimePackage;
   if(payload.schema_version!==1||payload.id!==entry.id||payload.version!==entry.version||payload.name!==entry.name||typeof payload.js!=='string'||typeof payload.css!=='string')throw Error('工具程序登记不匹配');
   if(current!==generation)return;
   // This is the hash-verified application build, never user-supplied text or code.
   const win=window as RuntimeWindow;delete win.__aiPlusLoadedProgram;
   const script=document.createElement('script');script.textContent=payload.js;
   document.head.append(script);script.remove();
   const program=Reflect.get(window,'__aiPlusLoadedProgram') as ToolProgram|undefined;delete win.__aiPlusLoadedProgram;
   if(!program||program.id!==entry.id||program.version!==entry.version||program.name!==entry.name||typeof program.mount!=='function')throw Error('工具挂载入口无效');
   node.replaceChildren();const surface=document.createElement('div');node.append(surface);
   const shadow=surface.attachShadow({mode:'open'}),style=document.createElement('style'),container=document.createElement('div');
   style.textContent=payload.css;shadow.append(style,container);
   const mounted=program.mount({container,mode:'website',onExit});
   if(!mounted||typeof mounted.dispose!=='function'||typeof mounted.requestExit!=='function'){
    if(typeof mounted?.dispose==='function')mounted.dispose();
    throw Error('工具释放接口无效');
   }
   instance=mounted;
   abort=null;
  }catch(error){
   if(current!==generation||controller.signal.aborted)return;
   instance?.dispose();instance=null;node.replaceChildren(message);
   message.setAttribute('role','alert');message.textContent=(error as Error).message;
  }
 }
 return {open,dispose,requestExit,hasRoute:(route:string)=>knownRoutes.has(route)};
}
