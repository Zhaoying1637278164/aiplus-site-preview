# E01 0.2.1候选源码
Node22+、Python3；npm ci --ignore-scripts --no-audit --no-fund，npm test，npm run typecheck，npm run build。测试包含独立Python生成604/634笔答案与全部字段核对。不含node_modules、凭据或业务数据。成品运行无需网络，浏览器补验需配置Chrome。
