export const VERSION='0.2.1';
export const RULE_VERSION='E01-2026-10-04.2';
