import {workbookBytes} from '../../../packages/core/io';import {calculate,kinds,names,type State} from './engine';import {VERSION,RULE_VERSION} from './version';
export function csv(headers:string[],rows:unknown[][]){return '\uFEFF'+[headers,...rows].map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n')}
export async function exportResult(s:State){const r=calculate(s);const list=(name:string,a:Record<string,unknown>[])=>{const h=a.length?Object.keys(a[0]):['无记录'];return {name,headers:h,rows:a.map(x=>h.map(k=>x[k]))}};return workbookBytes([
 {name:'版本参数',headers:['应用','规则','修订','参数'],rows:[[VERSION,RULE_VERSION,s.revision,JSON.stringify(s.rule)]]},
 list('逐行检查',r.outcomes as any),list('检查异常',r.issues as any),list('重复候选',r.candidates as any),list('分组金额勾稽',r.totals as any),{name:'政策未执行',headers:['问题'],rows:r.policyErrors.map(x=>[x])},list('复核记录',Object.entries(s.reviews).map(([id,x])=>({id,...x}))),
 ...kinds.flatMap(k=>{const t=s.originals[k];return t?[{name:'原始'+names[k],headers:['文件','页签','原行',...t.headers],rows:t.rows.map(r=>[r.file,r.sheet,r.row,...t.headers.map(h=>r.cells[h])])}]:[]}),
 ...kinds.flatMap(k=>{const t=s.data[k];return t?[{name:'映射'+names[k],headers:['文件','页签','原行',...t.headers],rows:t.rows.map(r=>[r.file,r.sheet,r.row,...t.headers.map(h=>r.cells[h])])}]:[]}),
 {name:'字段映射',headers:['资料','标准字段','原字段'],rows:kinds.flatMap(k=>Object.entries(s.mapping[k]).map(([a,b])=>[names[k],a,b]))},
 {name:'覆盖与边界',headers:['输入行','输出行','候选比较','截断','能力边界'],rows:[[r.coverage.input,r.coverage.output,r.candidateChecks,r.candidateTruncated,'不替代审批，不认定违规舞弊；未支持税务扣除或OCR；按主体期间币种单位分组，退款不抵限额']]}
 ])}
