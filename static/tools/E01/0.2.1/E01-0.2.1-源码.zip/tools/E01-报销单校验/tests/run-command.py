import sys,subprocess,json,pathlib,datetime,time
out=pathlib.Path('progress/evidence/E01/commands');out.mkdir(parents=True,exist_ok=True)
label=sys.argv[1];cmd=sys.argv[2:];start=time.time();p=subprocess.run(cmd,capture_output=True,text=True)
entry={'command':cmd,'cwd':str(pathlib.Path.cwd()),'date':'2026-10-04','exit_code':p.returncode,'seconds':round(time.time()-start,3),'stdout':p.stdout,'stderr':p.stderr}
(out/(label+'.json')).write_text(json.dumps(entry,ensure_ascii=False,indent=2));print(p.stdout);print(p.stderr,file=sys.stderr);print('ACTUAL_EXIT_CODE='+str(p.returncode));sys.exit(p.returncode)
