import sys
from pathlib import Path
import zipfile,json,hashlib
r=Path(sys.argv[1] if len(sys.argv)>1 else 'progress/evidence/E01/0.2.1');records=[]
for name,folder in [('E01-0.2.1-候选离线.zip','unzipped-offline'),('E01-0.2.1-候选源码.zip','unzipped-source')]:
 p=r/'zip-downloads'/name;assert p.read_bytes()==(r/name).read_bytes();out=r/folder;out.mkdir(exist_ok=False)
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  for i in z.infolist():
   assert not Path(i.filename).is_absolute() and '..' not in Path(i.filename).parts
  z.extractall(out);members=[{'name':i.filename,'crc32':f'{i.CRC:08x}','bytes':i.file_size,'compressed_bytes':i.compress_size,'sha256':hashlib.sha256(z.read(i)).hexdigest()} for i in z.infolist()]
 records.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'crc':'all passed','member_count':len(members),'members':members})
(r/'zip-verification.json').write_text(json.dumps({'status':'passed','zips':records},ensure_ascii=False,indent=2));print('downloaded ZIP CRC/members and byte identity passed',[(x['member_count'],x['bytes']) for x in records])
