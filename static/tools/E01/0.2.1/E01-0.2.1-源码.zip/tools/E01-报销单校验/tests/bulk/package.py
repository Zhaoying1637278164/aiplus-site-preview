import sys
from pathlib import Path
import zipfile,json,hashlib,shutil
r=Path.cwd();e=r/(sys.argv[1] if len(sys.argv)>1 else 'progress/evidence/E01/0.2.1');e.mkdir(parents=True,exist_ok=True);a=r/'progress/evidence/E01/candidate/0.2.1';s=e/'source';s.mkdir(parents=True,exist_ok=False)
for n in ['packages','tools/E01-报销单校验']:shutil.copytree(r/n,s/n,ignore=shutil.ignore_patterns('node_modules','.DS_Store'))
for n in ['package.json','package-lock.json','AGENTS.md','tsconfig.json']:shutil.copy2(r/n,s/n)
p=json.loads((s/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/E01-报销单校验/tests/engine.test.ts && python3 tools/E01-报销单校验/tests/bulk/oracle.py && node --import tsx tools/E01-报销单校验/tests/bulk/differential.ts','typecheck':'tsc -p tools/E01-报销单校验/tsconfig.json --noEmit','build':'node --import tsx tools/E01-报销单校验/tests/build.ts'};(s/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(s/'references').mkdir();shutil.copy2(r/'references/saxes-5.0.1-LICENSE',s/'references/saxes-5.0.1-LICENSE');shutil.copy2(a/'THIRD_PARTY_NOTICES.md',s/'THIRD_PARTY_NOTICES.md');(s/'BUILD.md').write_text('# E01 0.2.1候选源码\nNode22+、Python3；npm ci --ignore-scripts --no-audit --no-fund，npm test，npm run typecheck，npm run build。测试包含独立Python生成604/634笔答案与全部字段核对。不含node_modules、凭据或业务数据。成品运行无需网络，浏览器补验需配置Chrome。\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={str(p.relative_to(s)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in s.rglob('*') if p.is_file()};(e/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
for root,name in [(s,'E01-0.2.1-候选源码.zip'),(a,'E01-0.2.1-候选离线.zip')]:
 with zipfile.ZipFile(e/name,'w',zipfile.ZIP_DEFLATED) as z:
  for f in root.rglob('*'):
   if f.is_file():z.write(f,str(f.relative_to(root)))
 print(name,sha(e/name))
(e/'download-harness.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><a download href="E01-0.2.1-候选离线.zip">下载候选离线ZIP</a><a download href="E01-0.2.1-候选源码.zip">下载候选源码ZIP</a></html>')
