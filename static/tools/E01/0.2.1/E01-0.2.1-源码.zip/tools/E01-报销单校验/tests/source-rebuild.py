from pathlib import Path
import subprocess,json,hashlib,time,sys,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();src=root/'progress/evidence/E01/source';log=root/'progress/evidence/E01/source-rebuild.json';results=[]
for command in [['npm','ci','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]:
 start=time.time();p=subprocess.run(command,cwd=src,capture_output=True,text=True);results.append({'command':command,'cwd':str(src),'exit_code':p.returncode,'seconds':round(time.time()-start,2),'stdout':p.stdout,'stderr':p.stderr});log.write_text(json.dumps({'status':'running' if p.returncode==0 else 'failed','commands':results},ensure_ascii=False,indent=2));print(command,'actual exit',p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
a=root/'progress/evidence/E01/candidate/0.1.0';b=src/'progress/evidence/E01/candidate/0.1.0';comparisons=[]
for p in a.iterdir():
 if not p.is_file():continue
 q=b/p.name
 if p.suffix=='.xlsx':
  with zipfile.ZipFile(p) as z1,zipfile.ZipFile(q) as z2:
   assert sorted(z1.namelist())==sorted(z2.namelist());m=[]
   for n in z1.namelist():
    x,y=z1.read(n),z2.read(n)
    if n=='docProps/core.xml':
     import re
     x=re.sub(rb'(<dcterms:(?:created|modified)[^>]*>)[^<]*(</dcterms:(?:created|modified)>)',rb'\1TIME\2',x);y=re.sub(rb'(<dcterms:(?:created|modified)[^>]*>)[^<]*(</dcterms:(?:created|modified)>)',rb'\1TIME\2',y)
    assert x==y,n;m.append(n)
  comparisons.append({'file':p.name,'match':'all ZIP members identical except created/modified timestamps','members':len(m)})
 else:
  h=lambda v:hashlib.sha256(v.read_bytes()).hexdigest()
  assert h(p)==h(q),p.name;comparisons.append({'file':p.name,'sha256':h(p),'byte_identical':True})
log.write_text(json.dumps({'status':'passed','commands':results,'comparisons':comparisons,'scope':'isolated candidate source snapshot; final package by root','windows':'unverified'},ensure_ascii=False,indent=2));print('source rebuild passed',len(comparisons),'assets')
