import sys
from pathlib import Path
import subprocess,json,hashlib,time,sys
r=Path.cwd();e=r/(sys.argv[1] if len(sys.argv)>1 else 'progress/evidence/E01/0.2.1');s=e/'unzipped-source';a=r/'progress/evidence/E01/candidate/0.2.1';records=[]
for cmd in [['npm','ci','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]:
 start=time.time();p=subprocess.run(cmd,cwd=s,capture_output=True,text=True);records.append({'command':cmd,'cwd':str(s),'exit_code':p.returncode,'seconds':time.time()-start,'stdout':p.stdout,'stderr':p.stderr});(e/'source-rebuild.json').write_text(json.dumps({'status':'running' if p.returncode==0 else 'failed','commands':records},ensure_ascii=False,indent=2));print(cmd,'actual exit',p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
b=s/'progress/evidence/E01/candidate/0.2.1';assert sorted(p.name for p in a.iterdir() if p.is_file())==sorted(p.name for p in b.iterdir() if p.is_file());comparisons=[]
for p in a.iterdir():
 if p.is_file():
  q=b/p.name;assert p.read_bytes()==q.read_bytes(),p.name;comparisons.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'byte_identical':True})
(e/'source-rebuild.json').write_text(json.dumps({'status':'passed','commands':records,'comparisons':comparisons},ensure_ascii=False,indent=2));print('all',len(comparisons),'non-ZIP assets byte-identical including XLSX')
