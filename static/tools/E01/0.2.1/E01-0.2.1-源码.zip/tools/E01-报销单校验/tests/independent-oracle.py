from decimal import Decimal
from pathlib import Path
import json
p=Path('tools/E01-报销单校验/examples/独立预期.json')
amounts=list(map(Decimal,['120','120','60','50','-20','0']))
expected={'method':'Python Decimal independent arithmetic; no import of tested TypeScript','CNY':{'gross':str(sum(x for x in amounts if x>=0)),'refund':'-20','net':str(sum(amounts)),'blocked_rows':1},'USD':{'net':'10','policy':'未执行'},'per_line_excess':{'BX001':str(Decimal(120)-Decimal(100)),'BX002':'20'},'daily_group':{'claims':['BX003','BX004'],'total':str(Decimal(60)+Decimal(50)),'excess':str(Decimal(60)+Decimal(50)-Decimal(100))},'candidate_pairs':[['BX001','BX002']],'missing_attachment':['BX002'],'zero_review':['BX006'],'missing_amount':['BX007'],'coverage':8}
p.write_text(json.dumps(expected,ensure_ascii=False,indent=2));print(json.dumps(expected,ensure_ascii=False))
