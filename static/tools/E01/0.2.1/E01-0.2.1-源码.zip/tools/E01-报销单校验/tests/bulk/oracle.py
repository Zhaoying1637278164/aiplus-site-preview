# Independent spec oracle. No TypeScript imports or execution; Python Decimal and literal rules.
from pathlib import Path
from decimal import Decimal as D, getcontext
from datetime import date
import json,csv,copy,sys
getcontext().prec=40
out=Path(sys.argv[1] if len(sys.argv)>1 else 'progress/evidence/E01/0.2.1/fixtures');out.mkdir(parents=True,exist_ok=True)
EH=['报销ID','员工ID','主体','部门','日期','期间','费用类','金额','币种','单位','摘要','附件标记','发票号','单据类型','原报销ID']
PH=['政策ID','费用类','主体','部门','员工ID','生效日','失效日','币种','单位','限额','标准口径','要求附件','依据','版本']
rule={'tolerance':'0.000001','zero':'复核','refund':'核对关联','invoice':True,'exact':True,'similar':True,'days':3,'similarity':'0.6','acrossPeriods':False,'required':['报销ID','员工ID','主体','日期','期间','费用类','金额','币种','单位','单据类型']}
def plain(x):return format(x,'f').rstrip('0').rstrip('.') if '.' in format(x,'f') else format(x,'f')
def table(headers,rows,file):return {'file':file,'sheet':'CSV','headers':headers,'rows':[{'file':file,'sheet':'CSV','row':i+2,'cells':dict(zip(headers,[None if x=='' else x for x in row]))} for i,row in enumerate(rows)]}
def base(i):return [f'虚构BX{i:04}',f'虚构员工{i:04}','虚构甲公司','销售','2026-10-01','2026-10','交通','101','CNY','元',f'独立事项{i}','有',f'虚构INV{i:04}','报销','']
rows=[base(i) for i in range(1,605)]
def patch(i,**kw):
 for h,v in kw.items():rows[i-1][EH.index(h)]=v
patch(581,金额='120',员工ID='虚构重复',摘要='客户拜访出租车',发票号='虚构重复票')
patch(582,金额='120',员工ID='虚构重复',摘要='客户拜访出租车',发票号='虚构重复票',附件标记='无')
patch(583,金额='60',费用类='餐费',员工ID='虚构日限额')
patch(584,金额='50',费用类='餐费',员工ID='虚构日限额')
patch(585,金额='-20',员工ID='虚构重复',单据类型='退款',原报销ID='虚构BX0581')
patch(586,金额='-110',员工ID='虚构重复',单据类型='退款',原报销ID='虚构BX0581')
patch(587,金额='-1',单据类型='退款',原报销ID='不存在')
patch(588,金额='-1',单据类型='退款',原报销ID='虚构BX0585')
patch(589,金额='0')
patch(590,金额='')
patch(591,期间='2026-09')
patch(592,金额='10',币种='USD')
patch(593,金额='10',单位='千元')
patch(594,金额='10',费用类='住宿')
patch(595,金额='100.000001')
patch(596,金额='100.000002')
patch(597,金额='-2')
patch(598,金额='3',单据类型='退款')
patch(599,金额='5',主体='虚构乙公司')
patch(600,金额='10',日期='2026-11-01',期间='2026-11')
patch(601,金额='-5',员工ID='虚构重复',日期='2026-11-01',期间='2026-11',单据类型='退款',原报销ID='虚构BX0582')
patch(602,金额='10',费用类='重叠标准')
patch(603,金额='2',附件标记='无')
patch(604,金额='160',附件标记='无')
policies=[['P01','交通','虚构甲公司','*','*','2026-01-01','2026-12-31','CNY','元','100','每笔','是','虚构制度1','虚构v1'],['P02','餐费','虚构甲公司','*','*','2026-01-01','2026-12-31','CNY','元','100','员工每日','是','虚构制度2','虚构v1'],['P03','重叠标准','虚构甲公司','*','*','2026-01-01','2026-12-31','CNY','元','100','每笔','否','虚构制度3','虚构v1'],['P04','重叠标准','虚构甲公司','*','*','2026-01-01','2026-12-31','CNY','元','200','每笔','否','虚构制度4','虚构v2']]
def calc(data):
 rs=data['expenses']['rows'];ps=data['policies']['rows'];result={'outcomes':[],'issues':[],'candidates':[],'totals':[],'policyErrors':[],'coverage':{'input':len(rs),'output':len(rs)},'candidateChecks':0,'candidateTruncated':False};seq={};amounts={};matched={};o_map={}
 def loc(r):return f"{r['file']} / {r['sheet']} / 第{r['row']}行"
 def add(r,category,message,policy=''):
  key=f"r{r['row']}:{category}";n=seq.get(key,0);seq[key]=n+1;result['issues'].append({'id':f'{key}:{n}','row':r['row'],'claim':r['cells']['报销ID'],'category':category,'message':message,'source':loc(r),'policy':policy})
 for r in rs:
  c=r['cells'];fatal=False
  for h in rule['required']:
   if not c[h]:add(r,'数据阻塞',h+'缺失或公式');fatal=True
  try:v=D(c['金额'])
  except:add(r,'数据阻塞','缺失值或公式单元格，须提供静态值' if c['金额'] is None else '必填值为空');v=None;fatal=True
  dt=date.fromisoformat(c['日期'])
  if c['期间']!=c['日期'][:7]:add(r,'数据阻塞','期间须与费用日期月份一致');fatal=True
  if v is not None:
   if v==0:add(r,'零值复核','零金额不作为资料缺失，需说明')
   if v<0 and c['单据类型']!='退款':add(r,'数据阻塞','负金额须明确标识退款');fatal=True
   if c['单据类型']=='退款' and v>=0:add(r,'数据阻塞','退款金额须为负');fatal=True
  o={'row':r['row'],'claim':c['报销ID'],'source':loc(r),'amount':None,'period':c['期间'],'currency':c['币种'],'unit':c['单位'],'entity':c['主体'],'policy':'','limit':None,'excess':None,'status':'数据阻塞' if fatal else '待检查'};result['outcomes'].append(o);o_map[r['row']]=o
  if not fatal:
   amounts[r['row']]=v;o['amount']=plain(v)
   a=[p for p in ps if p['cells']['费用类']==c['费用类'] and p['cells']['币种']==c['币种'] and p['cells']['单位']==c['单位'] and p['cells']['生效日']<=c['日期']<=p['cells']['失效日'] and all(p['cells'][h]=='*' or p['cells'][h]==c[h] for h in ['主体','部门','员工ID'])]
   if len(a)!=1:add(r,'政策未执行','多项政策重叠，不猜测优先级' if a else '缺少适用企业标准');o['status']='政策未执行'
   else:
    p=a[0]['cells'];matched[r['row']]=p;o['policy']=p['政策ID'];o['limit']=plain(D(p['限额']));o['status']='已检查'
    if p['要求附件']=='是' and c['附件标记']!='有':add(r,'资料缺失','政策要求附件，标记须为有',o['policy'])
    if v>=0 and p['标准口径']=='每笔':
     ex=max(D(0),v-D(p['限额']));o['excess']=plain(ex)
     if ex>D(rule['tolerance']):add(r,'超标',f"金额 {plain(v)} 超每笔限额 {p['限额']}；超额 {plain(ex)}",o['policy'])
 refund={}
 for r in rs:
  c=r['cells'];v=amounts.get(r['row'])
  if v is None or v>=0:continue
  orig=[x for x in rs if x['cells']['报销ID']==c['原报销ID']]
  if len(orig)!=1 or orig[0]==r:add(r,'退款关联','原报销ID缺失或不能唯一关联');continue
  old=orig[0];ov=amounts.get(old['row']);oc=old['cells']
  if ov is None or ov<=0 or oc['单据类型']!='报销' or any(oc[h]!=c[h] for h in ['员工ID','主体','币种','单位','费用类']) or c['日期']<oc['日期']:add(r,'退款关联','原单金额、主体、员工、费用类、币种单位或日期不一致');continue
  refund.setdefault(old['row'],[]).append(r)
  if oc['期间']!=c['期间']:add(r,'跨期退款','分别保留各期间金额，不跨期抵销')
 for n,rr in refund.items():
  if sum(abs(amounts[r['row']]) for r in rr)>amounts[n]:
   for r in rr:add(r,'退款关联','累计退款绝对额超过原报销金额')
 daily={}
 for r in rs:
  c=r['cells'];p=matched.get(r['row']);v=amounts.get(r['row'])
  if p and v is not None and v>=0 and p['标准口径']=='员工每日':daily.setdefault((p['政策ID'],c['主体'],c['员工ID'],c['日期'],c['币种'],c['单位']),[]).append(r)
 for rr in daily.values():
  p=matched[rr[0]['row']];total=sum(amounts[r['row']] for r in rr);ex=max(D(0),total-D(p['限额']))
  for r in rr:
   o=o_map[r['row']];o['excess']=plain(ex)
   if ex>D(rule['tolerance']):add(r,'超标',f"员工每日组 {'/'.join(x['cells']['报销ID'] for x in rr)} 合计 {plain(total)} 超限额 {p['限额']}；组超额 {plain(ex)}（不能逐行重复加总）",o['policy'])
 totals={};buckets={}
 for r in rs:
  c=r['cells'];key=json.dumps([c[h] for h in ['主体','期间','币种','单位']],ensure_ascii=False,separators=(',',':'));t=totals.setdefault(key,{'key':key,'rows':0,'valid':0,'blocked':0,'gross':'0','refund':'0','net':'0'});t['rows']+=1;v=amounts.get(r['row'])
  if v is None:t['blocked']+=1;continue
  t['valid']+=1;h='refund' if v<0 else 'gross';t[h]=plain(D(t[h])+v);t['net']=plain(D(t['gross'])+D(t['refund']));buckets.setdefault(tuple(c[h] for h in ['主体','币种','单位','期间']),[]).append(r)
 result['totals']=list(totals.values())
 def grams(t):
  a=''.join(t.lower().split());return set(a if len(a)<2 else [a[i:i+2] for i in range(len(a)-1)])
 stopped=False
 for group in buckets.values():
  for i,a in enumerate(group):
   for b in group[i+1:]:
    result['candidateChecks']+=1
    if result['candidateChecks']>200000 or len(result['candidates'])>=10000:stopped=True;break
    ac=a['cells'];bc=b['cells'];reasons=[];score=''
    if ac['发票号'] and ac['发票号']==bc['发票号']:reasons.append('同发票号')
    same=amounts[a['row']]==amounts[b['row']] and ac['员工ID']==bc['员工ID']
    if same and ac['日期']==bc['日期'] and ac['费用类']==bc['费用类']:reasons.append('员工日期费用类金额相同')
    if same and abs((date.fromisoformat(ac['日期'])-date.fromisoformat(bc['日期'])).days)<=rule['days']:
     ga=grams(ac['摘要']);gb=grams(bc['摘要'])
     if ga and gb:
      sim=D(len(ga&gb))/D(len(ga|gb))
      if sim>=D(rule['similarity']):score=format(sim,'.6f');reasons.append('摘要相似')
    if reasons:result['candidates'].append({'id':f"pair:{a['row']}:{b['row']}",'left':a['row'],'right':b['row'],'claims':ac['报销ID']+' / '+bc['报销ID'],'reason':'；'.join(reasons)+'（仅候选）','score':score,'source':loc(a)+' ↔ '+loc(b)})
   if stopped:break
  if stopped:break
 result['candidateTruncated']=stopped
 if stopped:result['policyErrors'].append('重复候选检查达到200000次比较或10000候选上限；未检查部分须分批导入，不能宣称完整检查')
 return result
for name,rr in [('main',rows),('changed',copy.deepcopy(rows)),('truncated',[base(i) for i in range(1,635)]),('comparelimit',[base(i) for i in range(1,635)])]:
 if name=='changed':rr[0][7]='80'
 if name=='truncated':
  for r in rr:r[12]='虚构同发票'
 data={'expenses':table(EH,rr,'虚构'+name+'报销.csv'),'policies':table(PH,policies,'虚构政策.csv')};result=calc(data)
 (out/(name+'.json')).write_text(json.dumps({'data':data,'rule':rule,'result':result},ensure_ascii=False,indent=2))
 for key,headers,file in [('expenses',EH,data['expenses']['file']),('policies',PH,'虚构政策.csv')]:
  with (out/file).open('w',encoding='utf-8-sig',newline='') as f:
   w=csv.writer(f);w.writerow(headers);w.writerows([r['cells'][h] for h in headers] for r in data[key]['rows'])
 print(name,len(rr),len(result['issues']),len(result['candidates']),result['candidateChecks'],result['candidateTruncated'])
