import Decimal from 'decimal.js';import {amount as baseAmount,text} from '../../../packages/core/value';import type {Cell,SourceRow} from '../../../packages/core/types';import {HEADERS,type Work,type Analysis,type Measure,type Result,type Fact} from './types';
function amount(v:Cell){if(typeof v==='number'&&String(v).replace(/\D/g,'').replace(/^0+/,'').length>15)throw Error('数值型超过15位数字，请以十进制文本提供，避免工作簿精度损失');return baseAmount(v)}
export const valueUnit=(w:Work,m:Work['metrics'][number])=>m.kind==='ratio'?'%':m.inputUnit==='报告单位'?w.settings.unit:m.inputUnit;
export const groupKey=(id:string,dim:string)=>JSON.stringify([id,dim]);
export function validateConfig(w:Work){const s=w.settings;
 for(const v of [s.title,s.audience,s.entity,s.currency,s.unit])if(typeof v!=='string'||!v.trim()||v.length>200)throw Error('报告标题、读者、主体、币种、单位必填且不超过200字');
 if(!/^(19|20|21)\d{2}-(0[1-9]|1[0-2])$/.test(s.period))throw Error('期间须为有效 YYYY-MM（1900–2199）');
 if(!['当期','累计'].includes(s.basis)||!['完整','摘要'].includes(s.layout)||!['完整比较','仅本期'].includes(s.narrative)||typeof s.confirmed!=='boolean')throw Error('报告口径/版式无效');
 if(!Number.isInteger(s.precision)||s.precision<0||s.precision>6||amount(s.tolerance).lt(0)||amount(s.threshold).lt(0)||amount(s.threshold).gt(10000))throw Error('显示精度0–6；容差非负；关注阈值0–10000');
 if(!Array.isArray(w.metrics)||!w.metrics.length||w.metrics.length>200||new Set(w.metrics.map(m=>m.id)).size!==w.metrics.length)throw Error('指标1–200个且ID唯一');
 for(const m of w.metrics){if(!m||typeof m.id!=='string'||!m.id.trim()||m.id.length>100||typeof m.name!=='string'||!m.name.trim()||m.name.length>100||typeof m.definition!=='string'||!m.definition.trim()||m.definition.length>2000||typeof m.inputUnit!=='string'||!m.inputUnit.trim()||m.inputUnit.length>100||!['报告币种','不适用'].includes(m.inputCurrency)||!['sum','snapshot','ratio'].includes(m.kind)||!['higher','lower','neutral'].includes(m.direction))throw Error('指标ID、名称、口径必填；类型和方向必须有效')}
}
const empty=():Measure=>({value:null,numerator:null,denominator:null,sources:[],status:'缺失'});
export function analyze(w:Work):Analysis{const a:Analysis={results:[],issues:[],facts:[],ready:false};try{validateConfig(w)}catch(e){a.issues.push({code:'CONFIG',message:(e as Error).message,source:null,key:''});return a}
 if(!w.settings.confirmed)a.issues.push({code:'CONFIRM',message:'请确认输入已核对、维度互斥且无汇总与明细重复',source:null,key:''});
 if(!w.table?.rows.length)return a;
 if(w.table.rows.length>20000||w.table.headers.length>200||HEADERS.some(h=>!w.table!.headers.includes(h))){a.issues.push({code:'HEADERS',message:'须包含全部模板列，最多20000行/200列',source:null,key:''});return a}
 const s=w.settings,prior=String(Number(s.period.slice(0,4))-1)+s.period.slice(4),groups=new Map<string,{id:string;dimension:string;scenarios:Map<string,SourceRow[]>}>(),ids=new Map<string,SourceRow[]>();
 const issue=(code:string,message:string,source:SourceRow,key='')=>a.issues.push({code,message,source,key});
 for(const r of w.table.rows){let key='';try{
  if(Object.values(r.cells).some(c=>typeof c==='object'&&c!==null))throw Error('不接受公式/Excel错误，仅静态值');
  const id=text(r.cells['指标ID']),dim=text(r.cells['维度']),record=text(r.cells['记录ID']);key=groupKey(id,dim);
  const entries=ids.get(record)||[];entries.push(r);ids.set(record,entries);
  const m=w.metrics.find(m=>m.id===id);if(!m)throw Error('指标未配置：'+id);
  const scenario=text(r.cells['场景']);if(!['实际','预算','同期'].includes(scenario))throw Error('场景仅实际/预算/同期');
  if(text(r.cells['主体'])!==s.entity||text(r.cells['币种'])!==(m.inputCurrency==='报告币种'?s.currency:'不适用')||text(r.cells['单位'])!==(m.inputUnit==='报告单位'?s.unit:m.inputUnit)||text(r.cells['期间口径'])!==s.basis)throw Error('主体、币种、单位或期间口径不一致');
  if(text(r.cells['期间'])!==(scenario==='同期'?prior:s.period))throw Error('场景期间不一致：同期必须上一年同月，实际/预算须本期');
  if(m.kind==='ratio'){amount(r.cells['分子']);amount(r.cells['分母']);if(r.cells['数值']!==null&&String(r.cells['数值']??'').trim()!=='')throw Error('比例不接受数值列，必须提供分子/分母重算')}
  else {amount(r.cells['数值']);if(['分子','分母'].some(h=>r.cells[h]!==null&&String(r.cells[h]??'').trim()!==''))throw Error('金额/快照不接受分子分母')}
  let g=groups.get(key);if(!g){g={id,dimension:dim,scenarios:new Map()};groups.set(key,g)}const rows=g.scenarios.get(scenario)||[];rows.push(r);g.scenarios.set(scenario,rows);
 }catch(e){issue('ROW',(e as Error).message,r,key)}}
 for(const [id,rs] of ids)if(rs.length>1)for(const r of rs)issue('DUPLICATE','记录ID重复：'+id,r,groupKey(String(r.cells['指标ID']),String(r.cells['维度'])));
 const measure=(rs:SourceRow[]|undefined,m:Work['metrics'][number],key:string):Measure=>{if(!rs?.length)return empty();if(m.kind==='snapshot'&&rs.length!==1){for(const r of rs)issue('SNAPSHOT','快照同维度同场景只能一行，不得累计',r,key);return {...empty(),sources:rs,status:'阻塞'}}
  if(m.kind==='ratio'){const n=rs.reduce((v,r)=>v.plus(amount(r.cells['分子'])),new Decimal(0)),d=rs.reduce((v,r)=>v.plus(amount(r.cells['分母'])),new Decimal(0));if(d.lte(0)){for(const r of rs)issue('DENOMINATOR','比例分母合计须大于零',r,key);return {value:null,numerator:n.toFixed(),denominator:d.toFixed(),sources:rs,status:'阻塞'}}return {value:n.div(d).times(100).toFixed(12),numerator:n.toFixed(),denominator:d.toFixed(),sources:rs,status:'有效'}}
  return {value:rs.reduce((v,r)=>v.plus(amount(r.cells['数值'])),new Decimal(0)).toFixed(),numerator:null,denominator:null,sources:rs,status:'有效'};
 };
 for(const [key,g] of groups){const m=w.metrics.find(m=>m.id===g.id)!,actual=measure(g.scenarios.get('实际'),m,key),budget=measure(g.scenarios.get('预算'),m,key),p=measure(g.scenarios.get('同期'),m,key);
 const delta=(v:Measure)=>actual.value===null||v.value===null?null:new Decimal(actual.value).minus(v.value).toFixed();
 const rate=(v:Measure)=>actual.value===null||v.value===null||new Decimal(v.value).lte(0)||m.kind==='ratio'?null:new Decimal(actual.value).minus(v.value).div(v.value).times(100).toFixed(12);
 const bd=delta(budget),pd=delta(p),br=rate(budget),pr=rate(p),favorable=bd===null?'缺少预算':m.direction==='neutral'?'中性':new Decimal(bd).abs().lte(s.tolerance)?'容差内':((new Decimal(bd).gt(0))===(m.direction==='higher'))?'有利':'不利';
 const attention=w.focus.includes(key)||favorable==='不利'||[m.kind==='ratio'?bd:br,m.kind==='ratio'?pd:pr].some(v=>v!==null&&new Decimal(v).abs().gte(s.threshold));
 a.results.push({key,metric:m,dimension:g.dimension,actual,budget,prior:p,budgetDelta:bd,priorDelta:pd,budgetRate:br,priorRate:pr,favorable,attention});}
 // Any unsafe source prevents report facts/charts; diagnostics and all raw rows remain accessible.
 a.ready=a.issues.length===0&&a.results.some(r=>r.actual.value!==null);
 if(a.ready)for(const r of a.results){if(r.actual.value===null)continue;const unit=valueUnit(w,r.metric),fmt=(v:string)=>new Decimal(v).toFixed(s.precision),values:Record<string,string>={actual:r.actual.value};let prose=`${s.period}（${s.basis}）${s.entity}，${r.dimension}的${r.metric.name}为${fmt(r.actual.value)}${unit}。`;let sources=[...r.actual.sources];
 if(s.narrative==='完整比较')for(const [label,v,d,rate] of [['预算',r.budget,r.budgetDelta,r.budgetRate],['同期',r.prior,r.priorDelta,r.priorRate]] as const){if(v.value!==null&&d!==null){values[label]=v.value;values[label+'差额']=d;prose+=`较${label}${fmt(v.value)}${unit}差额${fmt(d)}${r.metric.kind==='ratio'?'个百分点':unit}`;if(rate!==null){values[label+'差异率']=rate;prose+=`，差异率${fmt(rate)}%`}else if(r.metric.kind!=='ratio')prose+='，基数非正，差异率不适用';prose+='。';sources.push(...v.sources)}}
 a.facts.push({id:'fact-'+(a.facts.length+1),key:r.key,text:prose,values,sources});}
 return a;
}
