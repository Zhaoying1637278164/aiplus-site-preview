import type {Table,SourceRow} from '../../../packages/core/types';
export const VERSION='0.1.1',RULE_VERSION='M05-2026-10-04.2';
export const HEADERS=['记录ID','指标ID','维度','主体','期间','期间口径','场景','币种','单位','数值','分子','分母'];
export interface Metric {id:string;name:string;kind:'sum'|'snapshot'|'ratio';direction:'higher'|'lower'|'neutral';definition:string;inputUnit:string;inputCurrency:'报告币种'|'不适用'}
export interface Settings {title:string;audience:string;entity:string;period:string;basis:'当期'|'累计';currency:string;unit:string;precision:number;tolerance:string;threshold:string;layout:'完整'|'摘要';narrative:'完整比较'|'仅本期';confirmed:boolean}
export interface Work {settings:Settings;metrics:Metric[];table:Table|null;notes:Record<string,{reason:string;action:string;owner:string}>;focus:string[]}
export interface Issue {code:string;message:string;source:SourceRow|null;key:string}
export interface Measure {value:string|null;numerator:string|null;denominator:string|null;sources:SourceRow[];status:string}
export interface Result {key:string;metric:Metric;dimension:string;actual:Measure;budget:Measure;prior:Measure;budgetDelta:string|null;priorDelta:string|null;budgetRate:string|null;priorRate:string|null;favorable:string;attention:boolean}
export interface Fact {id:string;key:string;text:string;values:Record<string,string>;sources:SourceRow[]}
export interface Analysis {results:Result[];issues:Issue[];facts:Fact[];ready:boolean}
export const defaults:Settings={title:'经营月报',audience:'经营管理层',entity:'待设置主体',period:'2026-09',basis:'当期',currency:'CNY',unit:'元',precision:2,tolerance:'0.01',threshold:'10',layout:'完整',narrative:'完整比较',confirmed:false};
export const defaultMetrics:Metric[]=[{id:'revenue',name:'营业收入',kind:'sum',direction:'higher',inputUnit:'报告单位',inputCurrency:'报告币种',definition:'经过核对的营业收入明细，同维度汇总'},{id:'margin',name:'毛利率',kind:'ratio',direction:'higher',inputUnit:'报告单位',inputCurrency:'报告币种',definition:'毛利额合计 / 营业收入合计 × 100；分子分母均为同单位金额'},{id:'headcount',name:'期末人数',kind:'snapshot',direction:'neutral',inputUnit:'人',inputCurrency:'不适用',definition:'期间末同维度单笔快照；不得按明细求和'}];
export const blankWork=():Work=>({settings:{...defaults},metrics:defaultMetrics.map(m=>({...m})),table:null,notes:{},focus:[]});
