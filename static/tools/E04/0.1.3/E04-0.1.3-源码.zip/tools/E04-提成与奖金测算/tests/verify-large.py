"""Read browser artifacts independently with stdlib XML/CSV; compare every cell."""
from pathlib import Path
import importlib.util,json,zipfile,xml.etree.ElementTree as ET,re,csv,sys,hashlib
sp=importlib.util.spec_from_file_location('oracle',Path(__file__).with_name('large-oracle.py'));o=importlib.util.module_from_spec(sp);sp.loader.exec_module(o)
base=Path('progress/evidence/E04/0.1.3');label=sys.argv[1] if len(sys.argv)>1 else 'large-browser';evidence=json.loads((base/label/'result.json').read_text());downloads=evidence['downloads'];counts={'reports':0,'cells':0,'json_fields':0,'csv_cells':0,'grid_cells':0};sha=lambda b:hashlib.sha256(b).hexdigest()
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
def xlsx(file):
 with zipfile.ZipFile(file) as z:
  assert z.testzip() is None
  strings=[]
  if 'xl/sharedStrings.xml' in z.namelist():strings=[''.join(t.itertext()) for t in ET.fromstring(z.read('xl/sharedStrings.xml'))]
  rel={e.attrib['Id']:e.attrib['Target'] for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))};sheets=[]
  for s in ET.fromstring(z.read('xl/workbook.xml')).find('s:sheets',NS):
   target=rel[s.attrib['{'+NS['r']+'}id']];target=target.lstrip('/') if target.startswith('/') else 'xl/'+target;root=ET.fromstring(z.read(target));matrix=[]
   for row in root.findall('s:sheetData/s:row',NS):
    arr=[]
    for c in row:
     ref=c.attrib['r'];n=0
     for ch in re.match('[A-Z]+',ref)[0]:n=n*26+ord(ch)-64
     while len(arr)<n:arr.append(None)
     v=c.find('s:v',NS)
     value=None if v is None else v.text
     if c.attrib.get('t')=='s':value=strings[int(value)]
     elif c.attrib.get('t')=='inlineStr':value=''.join(c.find('s:is',NS).itertext())
     arr[n-1]=value
    matrix.append(arr)
   sheets.append((s.attrib['name'],matrix))
  return sheets
# Workbook export string contract: no formulas; object cells JSON text, null cells empty.
def display(v):return '' if v is None else o.stringify(v) if isinstance(v,(dict,list)) else str(v)
def check_sheets(file,expected):
 actual=xlsx(file);assert [n for n,_ in actual]==[s['name'] for s in expected],file
 for (name,rows),spec in zip(actual,expected):
  exp=[spec['headers']]+spec['rows'];assert len(rows)==len(exp),(file,name,len(rows),len(exp))
  for i,(a,e) in enumerate(zip(rows,exp)):
   assert len(a)==len(e),(file,name,i,len(a),len(e))
   for j,(x,y) in enumerate(zip(a,e)):
    assert (x or '')==display(y),(file,name,i,j,x,y)
    counts['cells']+=1
 counts['reports']+=1
# Every paired downloaded work is original input evidence; calculate expected independently.
for d in downloads:
 if d['button']!='下载完整测算底稿':continue
 workentry=next(x for x in downloads if x['tag']==d['tag'] and x['button']=='下载含数据工作');work=json.loads(Path(workentry['file']).read_text());assert work['app_version']=='0.1.3' and work['rule_version']=='E04-2026-10-04.1';res=o.oracle(work);check_sheets(d['file'],o.sheets(work,res));counts['json_fields']+=sum(len(r['cells'])+4 for ds in work['data'].values() for r in ds['table']['rows']);
 # Validate all JSON structure/key values through a round-trip independent dump and CSV/XLSX origins below.
 original=json.loads((o.F/'604工作.json').read_text())
 if d['tag'] in ['original','restored','after-no-data','cancel-clear','cancel-exit']:
  assert work==original,(d['tag'],'all JSON source cells/maps/edits/versions/params')
 if d['tag'].startswith('tail-'):
  expected=json.loads(json.dumps(original));width=int(d['tag'].split('-')[1]);ds=expected['data']['规则'];row=next(r['row'] for r in ds['table']['rows'] if r['cells']['规则ID']=='RULE0602');ds['edits'][str(row)]={'封顶':'0' if width==1440 else '3500'};ds=expected['data']['调整'];row=next(r['row'] for r in ds['table']['rows'] if r['cells']['员工ID']=='EMP0603');ds['edits'][str(row)]={'状态':'已复核'};assert work==expected,'tail entire JSON'
 if d['tag'] in ['csv','xlsx','cancel-import','sheet-restored']:
  for k in o.SC:
   exp=original['data'][k]['table'];actual=work['data'][k]['table'];assert actual['headers']==exp['headers'];assert [r['cells'] for r in actual['rows']]==[{h:None if v=='' else v for h,v in r['cells'].items()} for r in exp['rows']];assert [r['row'] for r in actual['rows']]==[r['row'] for r in exp['rows']];assert work['data'][k]['edits']=={}
# Literal 0.1.3 built-in sample contract, not copied from export output.
sample={
 '业绩':[['P01','0001','虚构小林','2026-09','销售','CNY','元','100000','80000','虚构订单甲'],['P02','0001','虚构小林','2026-09','销售','CNY','元','50000','40000','虚构订单乙'],['P03','0002','虚构小陈','2026-09','回款','CNY','元','160000','150000','虚构收款甲'],['P04','0003','虚构小周','2026-09','销售','CNY','元','0','0','虚构零业绩'],['P05','0004','虚构小许','2026-09','缺规则','CNY','元','10000','5000','虚构待核验']],
 '规则':[['R1','销售','2026-01-01','2026-12-31','CNY','元','业绩','累进','3500','净额冲减','否','虚构销售方案V1'],['R2','回款','2026-01-01','2026-12-31','CNY','元','回款','全额','','禁止','是','虚构回款方案V1']],
 '档位':[[r,t,lo,hi,rate,bonus] for r in ['R1','R2'] for t,lo,hi,rate,bonus in [('T1','0','100000','2','0'),('T2','100000','200000','4','200'),('T3','200000','','6','500')]],
 '调整':[['A1','0001','2026-09','销售','CNY','元','调整','100','','虚构服务奖励','虚构审批A','虚构制单甲','虚构复核乙','2026-09-30','已复核'],['A2','0002','2026-09','回款','CNY','元','冲回','-200','PAY-虚构01','虚构退款冲回','虚构审批B','虚构制单甲','虚构复核乙','2026-09-30','已复核']]}
for d in downloads:
 if d['tag']!='asset':continue
 name=d['filename'].removeprefix('E04-')
 if name.endswith('.csv'):
  k=name.replace('虚构','').replace('模板','').replace('.csv','');expected=[o.SC[k]]+(sample[k] if name.startswith('虚构') else []);actual=list(csv.reader(Path(d['file']).open(encoding='utf-8-sig')));assert actual==expected,(name,actual);counts['csv_cells']+=sum(map(len,actual))
 else:check_sheets(d['file'],[{'name':k,'headers':o.SC[k],'rows':[] if '空白' in name else sample[k]} for k in o.SC])
# Full paginated UI cell contract at both widths; no first/last sampling.
work=json.loads((o.F/'604工作.json').read_text());res=o.oracle(work)
shown=lambda v:'（未计算/空）' if v is None else str(v)
def identity(group):
 matched=[a for a in res['people'] if a['group']==group]
 if matched:a=matched[0];return [a[k] for k in ['employee','name','period','plan','currency','unit']]
 try:
  key=json.loads(group);assert len(key)==5;return [key[0],None,key[1],key[2],key[3],key[4]]
 except:return [None]*6
identity_display=lambda v:'（未提供）' if v is None else '（空字符串）' if v=='' else str(v)
for g in evidence['pagination']:
 name=g['heading'];actual=sum(g['batches'],[]);details=sum(g['details'],[]);detail_expected=[]
 if name in ['个人处理状态','查找个人','同一基数的两种算法']:
  keys={'个人处理状态':['base','rounded','capReduction','adjustment','payable','status'],'查找个人':['performance','collection','base','rule','basis','method','bonus','rounded','cap','capReduction','adjustment','payable','residual','status'],'同一基数的两种算法':['base','method','progressive','whole','bonus','raw','rounded','roundDelta']}[name]
  expected=[[identity_display(a[k]) for k in ['employee','name','period','plan','currency','unit']]+[shown(a[h]) for h in keys]+['技术与来源详情'] for a in res['people']];detail_expected=[[a] for a in res['people']]
  assert g['headers'][:6]==['人员编号','姓名','月份','方案','币种','单位'] if g['width']>720 else g['headers'][0]=='测算对象'
 elif name in ['累进逐段底稿','异常与复核待办']:
  keys=['rule','tier','lower','upper','rate','base','commission','source'] if name=='累进逐段底稿' else ['kind','severity','source','message'];items=res['segments'] if name=='累进逐段底稿' else res['issues']
  expected=[[identity_display(v) for v in identity(a['group'])]+[shown(a[h]) for h in keys]+['技术与来源详情'] for a in items];detail_expected=[[a] for a in items]
  assert g['headers'][:6]==['人员编号','姓名','月份','方案','币种','单位'] if g['width']>720 else g['headers'][0]=='测算对象';assert '范围键' not in g['headers']
 elif name in ['当前范围结果','按期间币种单位独立勾稽']:
  keys=['period','currency','unit','rounded','capReduction','adjustment','payable','residual','blocked'];expected=[[shown(a[h]) for h in keys] for a in res['controls']];detail_expected=[[] for a in res['controls']]
 elif name=='资料预览与人工修正':
  k={'业绩与回款':'业绩','有效规则':'规则','比例与奖金档位':'档位','调整与冲回':'调整'}[g['page']];ds=work['data'][k];expected=[[str(r['row'])]+[str(r['cells'][h] or '') for h in o.SC[k]]+['无人工修正','技术与来源详情'] for r in ds['table']['rows']];detail_expected=[[{'original':r,'edits':{},'map':ds['map']}] for r in ds['table']['rows']]
 elif name.startswith('原始'):
  k=name.removeprefix('原始').replace('与修正轨迹','');ds=work['data'][k];expected=[[r['file'],r['sheet'],str(r['row'])]+[shown(r['cells'][h]) for h in ds['table']['headers']]+['无人工修正','技术与来源详情'] for r in ds['table']['rows']];detail_expected=[[{'original':r,'edits':{},'map':ds['map']}] for r in ds['table']['rows']]
 else:raise AssertionError(name)
 if g['width']<=720 and name in ['个人处理状态','查找个人','同一基数的两种算法','累进逐段底稿','异常与复核待办']:
  expected=[[sum(([h,v] for h,v in zip(['人员编号','姓名','月份','方案','币种','单位'],row[:6])),[])]+row[6:] for row in expected]
 assert actual==expected,(g['width'],g['page'],name,'all grid cells differ');assert details==detail_expected,(name,'all original technical detail objects');counts['grid_cells']+=sum(map(len,expected))
for d in downloads:assert sha(Path(d['file']).read_bytes())==d['sha256']
(base/label/'all-cell-validation.json').write_text(json.dumps({'passed':True,'algorithm':'Independent Python literal rows + Decimal; stdlib XLSX XML reader, all cells and JSON source objects','counts':counts,'download_sha_verified':len(downloads)},ensure_ascii=False,indent=2));print(json.dumps(counts))
