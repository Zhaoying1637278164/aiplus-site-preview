"""Independent integer oracle: cents × integer percent / 100; no app import."""
from pathlib import Path
import json,random
rng=random.Random(404);cases=[]
amounts=[0,1,25,9999999,10000000,10000001,15000000,20000000,20000001,25000000]+[rng.randrange(0,100000000) for _ in range(120)]
fmt=lambda n:f'{n//100}.{n%100:02}' if n>=0 else '-'+fmt(-n)
for cents in amounts:
 for mode in ['累进','全额']:
  for cap in [None,0,350000]:
   rate=2 if cents<=10000000 else 4 if cents<=20000000 else 6
   bonus=0 if cents<=10000000 else 20000 if cents<=20000000 else 50000
   progressive=min(cents,10000000)*2+max(0,min(cents,20000000)-10000000)*4+max(0,cents-20000000)*6
   whole=cents*rate
   raw=(progressive if mode=='累进' else whole)+bonus*100
   rounded=(raw+50)//100;limit=rounded if cap is None else min(rounded,cap)
   adj=0 if cap==0 else 10000
   cases.append({'base':fmt(cents),'mode':mode,'cap':'' if cap is None else fmt(cap),'adjustment':fmt(adj),'progressive':fmt((progressive+50)//100),'whole':fmt((whole+50)//100),'bonus':fmt(bonus),'rounded':fmt(rounded),'capReduction':fmt(rounded-limit),'payable':fmt(limit+adj),'residual':'0.00'})
root=Path('tools/E04-提成与奖金测算');(root/'examples/独立预期.json').write_text(json.dumps({'algorithm':'Python integer cents, integer percentage, half-up single rounding; seed404','cases':cases},ensure_ascii=False,indent=2))
print(f'{len(cases)} independent integer cases')
