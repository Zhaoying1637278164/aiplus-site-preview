"""Generate independent input workbook without ExcelJS/engine/export."""
import importlib.util,zipfile,xml.sax.saxutils as xml,json
from pathlib import Path
sp=importlib.util.spec_from_file_location('oracle',Path(__file__).with_name('large-oracle.py'));o=importlib.util.module_from_spec(sp);sp.loader.exec_module(o)
w=json.loads((o.F/'604工作.json').read_text())
def col(n):
 s=''
 while n:n,r=divmod(n-1,26);s=chr(65+r)+s
 return s
def workbook(file,sheets):
 with zipfile.ZipFile(file,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,len(sheets)+1))+'</Types>')
  z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
  z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{name}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,matrix) in enumerate(sheets,1))+'</sheets></workbook>')
  z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))+'</Relationships>')
  for i,(name,matrix) in enumerate(sheets,1):
   z.writestr(f'xl/worksheets/sheet{i}.xml','<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+''.join(f'<row r="{n}">'+''.join(f'<c r="{col(j)}{n}" t="inlineStr"><is><t xml:space="preserve">{xml.escape(str(v if v is not None else ""))}</t></is></c>' for j,v in enumerate(row,1))+'</row>' for n,row in enumerate(matrix,1))+'</sheetData></worksheet>')
workbook(o.F/'604四表.xlsx',[(k,[ds['table']['headers']]+[[r['cells'][h] for h in ds['table']['headers']] for r in ds['table']['rows']]) for k,ds in w['data'].items()]);print('independent XML input XLSX generated')
