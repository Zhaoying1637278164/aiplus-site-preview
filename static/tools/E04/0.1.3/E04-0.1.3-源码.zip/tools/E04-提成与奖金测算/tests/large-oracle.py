"""Literal scenario spec + independent Decimal/integer oracle. Never imports TS/engine/export."""
from pathlib import Path
from decimal import Decimal,ROUND_HALF_UP
import json,csv,sys,hashlib
B=Path('progress/evidence/E04/0.1.3');F=B/'large';F.mkdir(parents=True,exist_ok=True)
SC={'业绩':['记录ID','员工ID','员工姓名','期间','计划ID','币种','单位','业绩','回款','依据'],'规则':['规则ID','计划ID','开始日','结束日','币种','单位','基数','算法','封顶','负业绩','允许负测算','规则依据'],'档位':['规则ID','档位ID','下限','上限','比例%','固定奖金'],'调整':['调整ID','员工ID','期间','计划ID','币种','单位','类型','金额','原支付ID','理由','依据','制单人','复核人','复核日','状态']}
fmt=lambda n,p=2:format(Decimal(n).quantize(Decimal(10)**-p,rounding=ROUND_HALF_UP),f'.{p}f')
def stringify(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def make():
 rows={k:[] for k in SC};cases=[]
 for i in range(604):
  c=i%32 if i<600 else 0;employee=f'EMP{i:04}',;employee=employee[0];plan=f'PLAN{i:04}';rid=f'RULE{i:04}';period='2026-08' if i%5==0 else '2026-09';currency='USD' if i%7==0 else 'CNY';unit='万元' if i%11==0 else '元'
  base=['0','0.25','99999.99','100000','100000.01','150000','200000','200000.01','250000'][i%9] if c<=8 else '150000';method='全额' if i%2 else '累进';cap='0' if c==9 else '' if c==10 or i%3 else '3500'
  perf=[f'PERF{i:04}',employee,'虚构员工'+str(i),period,plan,currency,unit,base,str(Decimal(base)+100),'虚构订单'+str(i)]
  rule=[rid,plan,'2026-01-01','2026-12-31',currency,unit,'回款' if i%4==0 else '业绩',method,cap,'净额冲减','是','虚构内部方案'+str(i)]
  tiers=[[rid,'T1','0','100000','2','0'],[rid,'T2','100000','200000','4','200'],[rid,'T3','200000','','6','500']]
  adj=[f'ADJ{i:04}',employee,period,plan,currency,unit,'调整','100','','虚构理由'+str(i),'虚构凭据'+str(i),'虚构制单','虚构复核','2026-10-01','已复核']
  extra_perf=[];extra_rules=[];extra_adj=[]
  if c in [11,12,13]:
   neg=perf.copy();neg[0]+='-退款';neg[7]=neg[8]='-200000' if c==13 else '-50000';extra_perf=[neg]
   if c==12:rule[9]='禁止'
  if c==14:perf[7]=''
  if c==15:extra_perf=[perf.copy()]
  if c==16:perf[8]=''
  if c==17:perf[5]='EUR'
  if c==18:perf[6]='千元'
  if c==19:rule[2]='2027-01-01';rule[3]='2027-12-31'
  if c==20:rule[2]=period+'-02'
  if c==21:rule[3]=period+'-29'
  if c==22:
   other=rule.copy();other[0]+='-OVERLAP';extra_rules=[other]
  if c==23:tiers[1][2]='100001'
  if c==24:tiers[1][1]='T1'
  if c==25:adj[14]='待复核'
  if c==26:adj[12]=adj[11]
  if c==27:adj[6]='冲回';adj[8]='PAY'+str(i)
  if c==28:adj[6]='奖金';adj[7]='-100'
  if c==29:
   adj[6]='冲回';adj[7]='-100';adj[8]='PAY'+str(i);other=adj.copy();other[0]+='-DUP';extra_adj=[other]
  if c==30:rule[11]=''
  if c==31:adj[6]='冲回';adj[7]='-100';adj[8]='PAY'+str(i)
  if i>=600:perf[7]=perf[8]='150000';rule[6]='业绩';rule[7]='累进';rule[8]='';adj[6]='调整';adj[7]='100';adj[14]='待复核' if i==603 else '已复核'
  rows['业绩'] += [perf]+extra_perf;rows['规则'] += [rule]+extra_rules;rows['档位']+=tiers;rows['调整'] += [adj]+extra_adj;cases.append(c)
 data={}
 for k,rs in rows.items():
  name='604虚构'+k+'.csv';
  with (F/name).open('w',encoding='utf-8-sig',newline='') as f:csv.writer(f,quoting=csv.QUOTE_ALL,lineterminator='\r\n').writerows([SC[k]]+rs)
  data[k]={'table':{'file':name,'sheet':k,'headers':SC[k],'rows':[{'file':name,'sheet':k,'row':i+2,'cells':dict(zip(SC[k],r))} for i,r in enumerate(rs)]},'map':{h:h for h in SC[k]},'edits':{}}
 work={'schema_version':1,'tool':'E04','app_version':'0.1.3','rule_version':'E04-2026-10-04.1','contains_data':True,'params':{'period':'','precision':2,'tolerance':'0.01'},'maps':{k:{h:h for h in SC[k]} for k in SC},'data':data}
 (F/'604工作.json').write_text(json.dumps(work,ensure_ascii=False,indent=2));(F/'literal-spec.json').write_text(json.dumps({'groups':604,'cases':cases,'schemas':SC,'policy':'Literal rows generated here; amounts calculated independently; no app output read'},ensure_ascii=False,indent=2));return work
LABELS={'group':'范围键','employee':'员工ID','name':'姓名','period':'期间','plan':'计划ID','currency':'币种','unit':'单位','performance':'业绩合计','collection':'回款合计','base':'基数','rule':'规则ID','basis':'基数口径','method':'算法','progressive':'累进提成12位','whole':'全额提成12位','bonus':'档位奖金','raw':'舍入前规则额12位','rounded':'舍入后规则额','roundDelta':'舍入差额12位','cap':'封顶','capReduction':'封顶扣减','adjustment':'复核调整','payable':'测算额','residual':'勾稽残差','status':'状态','source':'来源','ruleSource':'规则来源','tierSources':'档位来源','adjustSources':'调整来源','tier':'档位ID','lower':'下限','upper':'上限','rate':'比例%','commission':'分段提成12位','kind':'资料类型','message':'复核事项','severity':'严重性','blocked':'阻塞个人数'}
def oracle(work):
 data=work['data'];p=work['params'];precision=p['precision'];people=[];segments=[];issues=[];src=lambda r:f"{r['file']} / {r['sheet']} / 行{r['row']}"
 effective=lambda k,r:{h:data[k]['edits'].get(str(r['row']),{}).get(h,r['cells'].get(data[k]['map'][h])) for h in SC[k]}
 rows={k:[(r,effective(k,r)) for r in data.get(k,{}).get('table',{}).get('rows',[])] for k in SC}
 issue=lambda k,r,m,g='',sev='阻塞':issues.append({'kind':k,'source':src(r),'message':m,'group':g,'severity':sev})
 keys={stringify([v[h] for h in ['员工ID','期间','计划ID','币种','单位']]) for r,v in rows['业绩']}
 for r,v in rows['调整']:
  g=stringify([v[h] for h in ['员工ID','期间','计划ID','币种','单位']])
  if g not in keys:issue('调整',r,'无对应业绩组，调整未应用',g)
 # independent literal preflight for generated invalid rule-basis scenarios
 for r,v in rows['规则']:
  if not v['规则依据']:issue('规则',r,'缺失值或公式单元格，须提供静态值' if v['规则依据'] is None else '必填值为空')
 groups={}
 for r,v in rows['业绩']:
  g=stringify([v[h] for h in ['员工ID','期间','计划ID','币种','单位']]);groups.setdefault(g,[]).append((r,v))
 for g,rs in groups.items():
  r,v=rs[0];adjs=[(ar,av) for ar,av in rows['调整'] if all(av[h]==v[h] for h in ['员工ID','期间','计划ID','币种','单位'])]
  a=dict(group=g,employee=v['员工ID'],name=v['员工姓名'],period=v['期间'],plan=v['计划ID'],currency=v['币种'],unit=v['单位'],performance=None,collection=None,base=None,rule='',basis='',method='',progressive=None,whole=None,bonus=None,raw=None,rounded=None,roundDelta=None,cap='',capReduction=None,adjustment=None,payable=None,residual=None,status='未计算',source='\n'.join(src(r) for r,v in rs),ruleSource='',tierSources='',adjustSources='\n'.join(src(ar) for ar,av in adjs));people.append(a)
  def block(msg):a['status']='阻塞：'+msg;issue('业绩',r,msg,g)
  perf_bad=False
  for pr,pv in rs:
   if not pv['业绩'] or not pv['回款']:issue('业绩',pr,'缺失值或公式单元格，须提供静态值' if pv['业绩'] is None or pv['回款'] is None else '必填值为空',g);perf_bad=True
   elif sum(x['记录ID']==pv['记录ID'] for _,x in rows['业绩'])>1:issue('业绩',pr,'记录ID重复，整组待复核',g);perf_bad=True
  if perf_bad:block('业绩资料异常');continue
  perf=sum((Decimal(x['业绩']) for _,x in rs),Decimal(0));cash=sum((Decimal(x['回款']) for _,x in rs),Decimal(0));a.update(performance=fmt(perf,precision),collection=fmt(cash,precision))
  match=[(rr,rv) for rr,rv in rows['规则'] if rv['计划ID']==v['计划ID'] and rv['币种']==v['币种'] and rv['单位']==v['单位'] and rv['开始日']<=v['期间']+'-31' and rv['结束日']>=v['期间']+'-01']
  if len(match)!=1:block('规则缺失或重叠，须唯一规则覆盖完整月份');continue
  rr,rv=match[0];a.update(rule=rv['规则ID'],ruleSource=src(rr))
  if not rv['规则依据']:block('规则无效：'+('缺失值或公式单元格，须提供静态值' if rv['规则依据'] is None else '必填值为空'));continue
  import calendar
  end=v['期间']+'-'+str(calendar.monthrange(*map(int,v['期间'].split('-')))[1])
  if rv['开始日']>v['期间']+'-01' or rv['结束日']<end:block('规则未覆盖完整月份，中途变更需另行分期');continue
  basis=rv['基数'];base=perf if basis=='业绩' else cash;a.update(basis=basis,method=rv['算法'],base=fmt(base,precision))
  if any(Decimal(x[basis])<0 for _,x in rs) and rv['负业绩']!='净额冲减':block('负业绩未获净额冲减规则允许');continue
  if base<0:block('净基数为负，不能猜测历史提成冲回');continue
  tiers=[(tr,tv) for tr,tv in rows['档位'] if tv['规则ID']==rv['规则ID']];a['tierSources']='\n'.join(src(tr) for tr,tv in tiers)
  if len({x['档位ID'] for _,x in tiers})!=len(tiers):block('同规则档位ID重复');continue
  last=Decimal(0);gap=False
  for tr,tv in tiers:
   if Decimal(tv['下限'])!=last:gap=True
   if tv['上限']:last=Decimal(tv['上限'])
  if gap:block('档位缺口或重叠，必须从0连续');continue
  # Independent integration: tier commissions are polynomial integrals over clipped intervals.
  bounds=[Decimal(t['下限']) for _,t in tiers];upper=[Decimal(t['上限']) if t['上限'] else base for _,t in tiers];pieces=[max(Decimal(0),min(base,hi)-lo) for lo,hi in zip(bounds,upper)];comm=[piece*Decimal(t['比例%'])/100 for piece,(_,t) in zip(pieces,tiers)];prog=sum(comm,Decimal(0));index=sum(base>b for b in bounds)-1;hit=tiers[max(0,index)][1];whole=base*Decimal(hit['比例%'])/100;bonus=Decimal(hit['固定奖金']) if base else Decimal(0);raw=(prog if rv['算法']=='累进' else whole)+bonus;rounded=Decimal(fmt(raw,precision));cap=None if rv['封顶'] in ['',None] else Decimal(rv['封顶']);capped=rounded if cap is None else min(rounded,cap)
  a.update(progressive=fmt(prog,12),whole=fmt(whole,12),bonus=fmt(bonus,precision),raw=fmt(raw,12),rounded=fmt(rounded,precision),roundDelta=fmt(rounded-raw,12),cap='无限制' if cap is None else fmt(cap,precision),capReduction=fmt(rounded-capped,precision))
  total=Decimal(0);bad=False
  for ar,av in adjs:
   message=None
   if av['状态']!='已复核':message='调整未复核'
   elif av['制单人']==av['复核人']:message='制单人与复核人须不同'
   elif av['类型']=='奖金' and Decimal(av['金额'])<0:message='奖金不得为负'
   elif av['类型']=='冲回' and Decimal(av['金额'])>0:message='冲回金额须非正'
   elif av['类型']=='冲回' and sum(x['员工ID']==av['员工ID'] and x['原支付ID']==av['原支付ID'] and x['类型']=='冲回' for _,x in rows['调整'])>1:message='同一员工原支付ID重复冲回'
   if message:issue('调整',ar,message,g);bad=True
   else:total+=Decimal(av['金额'])
  if bad:block('调整资料异常');continue
  payable=capped+total;a['adjustment']=fmt(total,precision)
  if payable<0 and rv['允许负测算']!='是':block('最终负测算额未经规则允许');continue
  a.update(payable=fmt(payable,precision),residual=fmt(0,precision),status='已测算，待企业确认')
  segments += [dict(group=g,rule=rv['规则ID'],tier=tv['档位ID'],lower=str(Decimal(tv['下限'])),upper=str(Decimal(tv['上限'])) if tv['上限'] else '∞',rate=tv['比例%'],base=fmt(part,precision),commission=fmt(c,12),source=src(tr)) for (tr,tv),part,c in zip(tiers,pieces,comm)]
 controls=[]
 for scope in dict.fromkeys((a['period'],a['currency'],a['unit']) for a in people):
  subset=[a for a in people if (a['period'],a['currency'],a['unit'])==scope];ok=[a for a in subset if a['payable'] is not None];tot={h:fmt(sum((Decimal(a[h]) for a in ok),Decimal(0)),precision) for h in ['rounded','capReduction','adjustment','payable']};controls.append(dict(period=scope[0],currency=scope[1],unit=scope[2],**tot,residual=fmt(0,precision),blocked=len(subset)-len(ok)))
 return dict(people=people,segments=segments,issues=issues,controls=controls)
PH=['employee','name','period','plan','currency','unit','performance','collection','base','rule','basis','method','progressive','whole','bonus','raw','rounded','roundDelta','cap','capReduction','adjustment','payable','residual','status','source','ruleSource','tierSources','adjustSources']
def sheets(work,res):
 def arr(name,items,hs):return {'name':name,'headers':[LABELS.get(h,h) for h in hs],'rows':[[i.get(h) for h in hs] for i in items]}
 data=work['data'];params={'app_version':'0.1.3','rule_version':'E04-2026-10-04.1',**work['params'],'maps':{k:data[k]['map'] if k in data else None for k in SC}}
 result=[arr('个人测算',res['people'],PH),arr('累进分段',res['segments'],['group','rule','tier','lower','upper','rate','base','commission','source']),arr('范围勾稽',res['controls'],['period','currency','unit','rounded','capReduction','adjustment','payable','residual','blocked']),arr('阻塞个人',[a for a in res['people'] if a['payable'] is None],PH),arr('异常清单',res['issues'],['kind','severity','source','message','group']),{'name':'参数与版本','headers':['参数','值'],'rows':list(map(list,params.items()))}]
 for k in SC:
  t=data.get(k,{}).get('table',{'headers':[],'rows':[]});result.append({'name':'原始'+k,'headers':['文件','页签','行号']+t['headers'],'rows':[[r['file'],r['sheet'],r['row']]+[r['cells'][h] for h in t['headers']] for r in t['rows']]})
 trail=[]
 for k in SC:
  ds=data.get(k)
  if ds:
   for r in ds['table']['rows']:
    for h,v in ds['edits'].get(str(r['row']),{}).items():trail.append([k,r['file'],r['sheet'],r['row'],h,r['cells'][ds['map'][h]],v])
 result.append({'name':'人工修正轨迹','headers':['资料','文件','页签','行号','业务字段','原始值','修正值'],'rows':trail});return result
if __name__=='__main__':
 if len(sys.argv)==1:work=make();(F/'expected-result.json').write_text(json.dumps(oracle(work),ensure_ascii=False,indent=2));print('604 literal groups generated')
 else:
  work=json.loads(Path(sys.argv[1]).read_text());result=oracle(work);Path(sys.argv[2]).write_text(json.dumps(result,ensure_ascii=False,indent=2));
  if len(sys.argv)>3:Path(sys.argv[3]).write_text(json.dumps(sheets(work,result),ensure_ascii=False,indent=2))
