"""Rebuild actual browser-downloaded source ZIP, independently of packaging."""
from pathlib import Path
import tempfile,subprocess,json,hashlib,zipfile
base=Path('progress/evidence/E04/0.1.3');archive=base/'downloaded-packages/E04-0.1.3-候选源码.zip';src=Path(tempfile.mkdtemp(prefix='e04-downloaded-source-'))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n in z.namelist():assert not n.startswith('/') and '..' not in Path(n).parts
 z.extractall(src)
steps=[]
for label,cmd in [('install',['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund']),('unit',['npm','test']),('typecheck',['npm','run','typecheck']),('build',['npm','run','build'])]:
 p=subprocess.run(cmd,cwd=src,capture_output=True,text=True);(base/f'downloaded-rebuild-{label}.log').write_text(p.stdout+p.stderr);steps.append({'step':label,'command':cmd,'exit_code':p.returncode})
 if p.returncode:break
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();checks=[]
if len(steps)==4 and all(s['exit_code']==0 for s in steps):
 expected={p.name for p in (base/'candidate').iterdir() if p.is_file()};actual={p.name for p in (src/'candidate').iterdir() if p.is_file()};assert expected==actual
 for n in sorted(expected):
  a=base/'candidate'/n;b=src/'candidate'/n;checks.append({'file':n,'original_sha256':sha(a),'rebuilt_sha256':sha(b),'equal':a.read_bytes()==b.read_bytes(),'comparison':'all bytes including entire XLSX'})
result={'actual_browser_downloaded_zip':True,'source_zip_sha256':sha(archive),'temp':str(src),'steps':steps,'checks':checks,'scope':'local candidate source, not official release'}
(base/'downloaded-source-rebuild.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({'steps':steps,'assets_equal':sum(c['equal'] for c in checks)}))
assert len(steps)==4 and all(s['exit_code']==0 for s in steps) and len(checks)==16 and all(c['equal'] for c in checks)
