import test from 'node:test';import assert from 'node:assert/strict';import {decode,encode,example} from '../src/documents';import {defaults} from '../src/engine';
test('0.1.3 rejects 0.1.2 application restore',()=>{const raw=JSON.parse(encode(example(),defaults,true));raw.app_version='0.1.2';assert.throws(()=>decode(JSON.stringify(raw)),/版本/)});
