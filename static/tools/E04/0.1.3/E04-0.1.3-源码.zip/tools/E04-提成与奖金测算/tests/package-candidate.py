"""Offline candidate archive only, no release or site writes."""
from pathlib import Path
import zipfile,json,hashlib,shutil
base=Path('progress/evidence/E04/0.1.3');src=base/'candidate';tool=Path('tools/E04-提成与奖金测算');archive=base/'E04-0.1.3-候选离线包.zip';out=base/'offline-extracted';out.mkdir(exist_ok=True)
files={p.name:p for p in src.iterdir() if p.is_file()};files.update({'使用说明.md':tool/'README.md','财务规则.md':tool/'财务规则.md','参考来源.md':tool/'参考来源.md'})
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.write(p,name)
checks=[]
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():
  b=z.read(name);p=out/name;p.write_bytes(b);checks.append({'file':name,'equal_to_candidate':b==files[name].read_bytes(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
assert all(c['equal_to_candidate'] for c in checks)
(base/'offline-package.json').write_text(json.dumps({'passed':True,'zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'zip_bytes':archive.stat().st_size,'actual_extracted':str(out),'members':checks},ensure_ascii=False,indent=2))
print(json.dumps({'members':len(checks),'bytes':archive.stat().st_size,'equal':True}))
