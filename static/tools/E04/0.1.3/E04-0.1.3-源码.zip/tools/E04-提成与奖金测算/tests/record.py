"""Run commands with their real exit codes and full logs; writes only E04 evidence."""
from pathlib import Path
import json,subprocess,sys,datetime
base=Path('progress/evidence/E04/0.1.3');base.mkdir(parents=True,exist_ok=True)
label=sys.argv[1];cmd=sys.argv[2:]
f=base/'commands.json';r=json.loads(f.read_text()) if f.exists() else []
count=sum(x['label']==label for x in r);log=base/(label+('-'+str(count) if count else '')+'.log')
p=subprocess.run(cmd,capture_output=True,text=True)
log.write_text(p.stdout+p.stderr)
r=json.loads(f.read_text()) if f.exists() else []
r.append({'label':label,'command':cmd,'exit_code':p.returncode,'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log)});f.write_text(json.dumps(r,ensure_ascii=False,indent=2))
print(json.dumps({'label':label,'exit_code':p.returncode,'tail':(p.stdout+p.stderr)[-1800:]},ensure_ascii=False));sys.exit(p.returncode)
