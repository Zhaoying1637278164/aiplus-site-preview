"""Extract the actual tool-only source ZIP into a fresh temporary checkout and run all steps."""
from pathlib import Path
import tempfile,shutil,subprocess,json,hashlib,zipfile
root=Path.cwd();ev=root/'progress/evidence/E04/0.1.3';tool='tools/E04-提成与奖金测算';tmp=Path(tempfile.mkdtemp(prefix='e04-rebuild-'));stage=tmp/'staged';stage.mkdir()
for f in ['package.json','package-lock.json','tsconfig.json']:shutil.copy2(root/f,stage/f)
pkg=json.loads((stage/'package.json').read_text());pkg['scripts']={'test':'node --import tsx --test tools/E04-提成与奖金测算/tests/*.test.ts','typecheck':'tsc --noEmit','build':'node --import tsx tools/E04-提成与奖金测算/tests/build-candidate.ts candidate'};(stage/'package.json').write_text(json.dumps(pkg,ensure_ascii=False,indent=2)+'\n')
shutil.copytree(root/'packages',stage/'packages');shutil.copytree(root/tool,stage/tool)
(stage/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',stage/'references/saxes-5.0.1-LICENSE');shutil.copy2(ev/'candidate/THIRD_PARTY_NOTICES.md',stage/'THIRD_PARTY_NOTICES.md')
(stage/'BUILD.md').write_text('E04 0.1.3候选源码。Node22+。解压后npm ci（离线须已有缓存）；npm test；npm run typecheck；npm run build。生成candidate/index.html与原生runtime.json。锁文件原样，package.json仅替换为本款测试/类型/构建命令；无需其它工具或官网代码。用户资料、node_modules、凭据、其它业务工程不进入源码。正式官网及accepted由总控核验。\n')
archive=ev/'E04-0.1.3-候选源码.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(stage)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None;names=z.namelist();assert not any('node_modules' in n or '.git/' in n for n in names);assert all(n.startswith(tool+'/') for n in names if n.startswith('tools/'));src=tmp/'extracted';z.extractall(src)
steps=[]
for label,cmd in [('install',['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund']),('unit',['npm','test']),('typecheck',['npm','run','typecheck']),('build',['npm','run','build'])]:
 p=subprocess.run(cmd,cwd=src,capture_output=True,text=True);(ev/f'rebuild-{label}.log').write_text(p.stdout+p.stderr);steps.append({'step':label,'command':cmd,'exit_code':p.returncode})
 if p.returncode:break
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();checks=[]
if len(steps)==4 and steps[-1]['exit_code']==0:
 for p in sorted((src/'candidate').iterdir()):
  if not p.is_file():continue
  a=ev/'candidate'/p.name;equal=a.read_bytes()==p.read_bytes();mode='bytes'
  checks.append({'file':p.name,'original_sha256':sha(a),'rebuilt_sha256':sha(p),'equal':equal,'comparison':mode})
(ev/'source-rebuild.json').write_text(json.dumps({'source_zip_sha256':sha(archive),'actual_zip_extracted':True,'temp':str(src),'steps':steps,'checks':checks,'source_members':names,'isolation':'tool-only source + shared packages + lock + license; no other tools','scope':'候选源码重建，不是正式官网或release验收'},ensure_ascii=False,indent=2))
print(json.dumps({'steps':steps,'assets_equal':sum(c['equal'] for c in checks),'source_zip_sha256':sha(archive)},ensure_ascii=False))
if len(steps)!=4 or any(s['exit_code'] for s in steps) or not checks or any(not c['equal'] for c in checks):raise SystemExit(1)
