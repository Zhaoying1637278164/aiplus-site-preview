import test from 'node:test';import assert from 'node:assert/strict';import {releaseAssets} from '../src/documents';
test('all XLSX byte identical across different clock seconds',async()=>{const a=await releaseAssets();await new Promise(r=>setTimeout(r,2100));const b=await releaseAssets();for(let i=0;i<a.length;i++)assert.deepEqual(a[i].data,b[i].data,a[i].filename)});
