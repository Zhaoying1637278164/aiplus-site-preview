from pathlib import Path
import zipfile,json,hashlib,sys
base=Path('progress/evidence/E04/0.1.3');items=[]
for name in ['E04-0.1.3-候选离线包.zip','E04-0.1.3-候选源码.zip']:
 file=base/'downloaded-packages'/name;out=base/('downloaded-offline-extracted' if '离线' in name else 'downloaded-source-extracted');out.mkdir(exist_ok=True)
 with zipfile.ZipFile(file) as z:
  assert z.testzip() is None;members=[]
  for m in z.infolist():
   assert not m.filename.startswith('/') and '..' not in Path(m.filename).parts
   data=z.read(m);target=out/m.filename;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);members.append({'name':m.filename,'crc32':f'{m.CRC:08x}','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 items.append({'zip':str(file),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'bytes':file.stat().st_size,'crc_all_passed':True,'members':members,'extracted':str(out)})
(base/'downloaded-zip-audit.json').write_text(json.dumps({'passed':True,'packages':items},ensure_ascii=False,indent=2));print(json.dumps({'packages':2,'members':[len(x['members']) for x in items]}))
