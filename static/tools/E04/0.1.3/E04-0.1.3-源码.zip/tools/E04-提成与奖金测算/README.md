# 0.1.3 官网窄容器导航返修（2026-10-05）

当前仅tested候选；正式官网复验、release/catalog/STATUS/发布和accepted由总控负责。本线程只改本款目录及E04证据。旧0.1.2、正式包和root实际视觉失败全部保留；其金融通过证据不被导航失败抹掉。

旧导航135px flex basis在官网272px可用宽度导致十行。本版窄导航使用两列minmax(0,1fr)，按照工具实际容器宽度生效，同时保留viewport降级规则。完整十页中文名称、aria-current和原13px字号保持；没有裁切或隐藏标题。窄桌面容器复验发现原桌面页眉挤占首屏，将已有窄屏页眉的流式布局/20px内边距及main/section内边距按容器应用，让业务标题不被桌面留白推离首屏；字号不改；App、财务身份卡、原始详情与所有业务流程不改。

应用0.1.3，规则E04-2026-10-04.1及schema_version=1保持。engine仅VERSION字面更新；documents、workbook、财务规则、App/view、原94项断言及独立Python算法逐字节保持，见financial-source-invariance.json；另增0.1.2恢复拒绝断言。新旧604全部金融字段必须一致。

证据位于progress/evidence/E04/0.1.3：navigation-before为实际失败；navigation-final为六个outer/usable宽度组合（320/272、320/320、272/272、1440/272、1440/320、1440/1392），原生mode=website的内边距等效宿主，全部十页导航布局与首屏位置逐页断言。等效宿主不是原官网复验。equivalent-host-full与downloaded-offline-browser覆盖272/320/1440、604资料、45全分页表格及全部下载；verify-large逐报告所有格和原始详情对象，禁止归一金额/时间。双ZIP实际下载、CRC/逐成员SHA、离线解压重复和源码四命令/全部RAW资产见相应JSON；命令exit与完整失败日志见commands.json，实际审图范围以visual-review.json为准，不以截图数声称全视觉。最终manifest记录全部源码/证据SHA与大小，交接后停写。

Windows/Safari/Firefox、真实官网/public下载与总控独立验收待办，AI/OCR未实现。以下旧版段落仅历史说明，不代表0.1.3当前通过结论。

---

# 0.1.2 财务身份展示返修（2026-10-05）

本版仅UI视图、响应式样式与应用版本更新；财务engine（除VERSION字面）、documents导出、workbook、财务规则、原有engine/io断言及独立Python算法保持逐字节不变，证据financial-source-invariance.json。旧0.1.1全部包及证据保留，旧版金融核验保留；旧版视觉被总控实际截图判失败，不再沿用其视觉通过结论。当前只为tested候选，不发布、不标accepted。

人员业务主表桌面显示人员编号、姓名、月份、方案、币种、单位；320手机为全六字段中文身份卡片，完整币种/单位无需靠截断JSON辨认。分段/异常按完整技术键匹配身份，孤立事项不猜姓名，null与空字符串分别标明未提供/空字符串，不按姓名或单独人员编号合并。原始键、完整结果/来源、原行与映射/修正保留于明确展开的技术与来源详情。人工修正主列显示字段和值，无修正明确标注。

当前604完整范围、新旧源码字节核对、所有报告单元格和详情对象、实际1440/320十页截图、双ZIP下载CRC与解压file://、源码四命令及全部raw字节证据位于progress/evidence/E04/0.1.2。具体通过与失败以commands.json、financial-source-invariance.json、large-browser及downloaded-offline-browser的result/all-cell-validation.json、view-browser.json、visual-review.json、downloaded-zip-audit.json、source-rebuild.json、downloaded-source-rebuild.json、manifest.json为准；未存在或exit非0不得记通过。正式官网/public下载、Windows/Safari/Firefox未验证；AI/OCR未实现。

0.1.2交接后停写，正式发布/catalog/STATUS/官网由总控负责。下列为0.1.1历史说明，其版本、旧视觉和金额计数不代表0.1.2最终证据。

---

# E04 提成与奖金测算

应用版本0.1.1，规则版本E04-2026-10-04.1，schema_version=1。状态为tested候选；正式发布、官网验收和accepted由总控完成。旧0.1.0候选、ZIP、失败日志保留于progress/evidence/E04/0.1.0；旧说明及样例副本保留于0.1.1/history。严格拒绝旧应用版本工作恢复。

打开候选离线包中的index.html。十页依次为工作概览、业绩与回款、有效规则、比例与奖金档位、调整与冲回、运行与勾稽、个人测算、跨档与算法比较、异常与来源、保存与底稿。可先载入完全虚构样例；小林3600、小陈6000、小周0、小许缺规则阻塞，合计9600、阻塞1。

四类资料支持CSV/XLSX、页签和表头选择、字段映射、原值保留及人工修正。每批50行，首批/末批/前后批可访问全量，个人支持搜索。替换已加载文件需确认，取消保留资料。文件10MiB、解压30MiB、每表20000行200列；不执行宏、公式、外链或用户代码。

文件仅在浏览器内存读取、计算、导出，无上传、日志、遥测或默认持久化。主动下载无数据方案（参数及字段映射，不含四表）或含数据工作（四表、规则及修正）；恢复替换并重算，关闭/退出清除内存。完整XLSX底稿11页签保留金额、分段、勾稽、异常、参数版本、原始四表及修正轨迹。

按员工×月份×计划×币种×单位独立计算。规则须覆盖完整月份，跨档边界归前档；累进积分或全额比例，最高适用档奖金只计一次。先舍入规则额并封顶，再加独立复核调整/冲回。空不等于零，封顶0与空不同；异常阻塞对应个人。企业确认规则、复核权限及原支付余额；工具不自动发薪或推断税务和法定工资政策。

0.1.1新增确定性XLSX元数据与ZIP成员日期、首末批导航、替换确认；财务算法及限制不变。源码重建比较全部字节，包括整个XLSX，不接受时间戳例外。实际证据见[验收证据](验收证据.md)和[实现交接](实现交接.md)。只实际验证Mac Chromium，Windows/Safari/Firefox未运行；AI/OCR及在线审批未实现。

本地源码：Node22+，根目录npm ci；node --import tsx --test tools/E04-提成与奖金测算/tests/*.test.ts；npx tsc --noEmit；node --import tsx tools/E04-提成与奖金测算/tests/build-candidate.ts。工具独立源码ZIP含共享包、锁文件、BUILD.md及第三方声明，解压后npm ci、npm test、npm run typecheck、npm run build。离线安装需已有npm缓存。604组补充验收先运行tests/large-oracle.py和large-files.py，随后large-unit.ts、large-browser.ts、verify-large.py；历史browser.ts/offline-zip.ts仅对应0.1.0。

[财务规则](财务规则.md) · [参考来源](参考来源.md) · [规格与独立预期](规格与独立预期.md) · [产品与页面方案](产品与页面方案.md) · [任务与接续](任务与接续.md)
