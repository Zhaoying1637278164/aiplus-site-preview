import {releaseAssets as assets} from './documents';
/** Standard website entries are aliases; four-table templates stay available. */
export async function releaseAssets(){const a=await assets();return [...a,{filename:'空白模板.csv',data:a.find(x=>x.filename==='业绩模板.csv')!.data},{filename:'虚构样例.xlsx',data:a.find(x=>x.filename==='四表虚构样例.xlsx')!.data}]}
