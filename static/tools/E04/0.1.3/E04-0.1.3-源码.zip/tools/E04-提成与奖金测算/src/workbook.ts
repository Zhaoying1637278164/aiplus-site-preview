import ExcelJS from 'exceljs';
import JSZip from 'jszip';
/** Fixed export metadata is an application format constant, not a transaction date. */
export async function workbookBytes(sheets:{name:string;headers:string[];rows:unknown[][]}[]):Promise<Uint8Array>{
 const wb=new ExcelJS.Workbook(),epoch=new Date('2000-01-01T00:00:00Z');wb.created=epoch;wb.modified=epoch;wb.creator='E04';wb.lastModifiedBy='E04';
 for(const spec of sheets){const ws=wb.addWorksheet(spec.name.slice(0,31));ws.addRow(spec.headers);for(const r of spec.rows)ws.addRow(r.map(v=>v===null||v===undefined?'':typeof v==='object'?JSON.stringify(v):String(v)));ws.getRow(1).font={bold:true};ws.views=[{state:'frozen',ySplit:1}];ws.columns.forEach(c=>c.width=24)}
 const raw=await wb.xlsx.writeBuffer(),zip=await JSZip.loadAsync(raw);for(const entry of Object.values(zip.files))entry.date=epoch;
 return zip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6},platform:'DOS'});
}
