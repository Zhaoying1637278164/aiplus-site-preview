import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';
import type {Table,SourceRow,Cell} from '../../../packages/core/types';
const D=Decimal.clone({precision:70,rounding:Decimal.ROUND_HALF_UP});
export const VERSION='0.1.3',RULE_VERSION='E04-2026-10-04.1';
export const schemas={业绩:['记录ID','员工ID','员工姓名','期间','计划ID','币种','单位','业绩','回款','依据'],规则:['规则ID','计划ID','开始日','结束日','币种','单位','基数','算法','封顶','负业绩','允许负测算','规则依据'],档位:['规则ID','档位ID','下限','上限','比例%','固定奖金'],调整:['调整ID','员工ID','期间','计划ID','币种','单位','类型','金额','原支付ID','理由','依据','制单人','复核人','复核日','状态']};
export const kinds=Object.keys(schemas) as Kind[];export type Kind=keyof typeof schemas;
export interface Dataset{table:Table;map:Record<string,string>;edits:Record<string,Record<string,string>>}
export type Data=Partial<Record<Kind,Dataset>>;
export interface Params{period:string;precision:number;tolerance:string}
export const defaults:Params={period:'',precision:2,tolerance:'0.01'};
export const dataset=(table:Table,k:Kind):Dataset=>({table,map:Object.fromEntries(schemas[k].map(h=>[h,table.headers.includes(h)?h:''])),edits:{}});
export const cell=(ds:Dataset,r:SourceRow,h:string):Cell=>Object.hasOwn(ds.edits[r.row]??{},h)?ds.edits[r.row][h]:r.cells[ds.map[h]]??null;
export const source=(r:SourceRow)=>`${r.file} / ${r.sheet} / 行${r.row}`;
export function validateParams(p:Params){if(!p||typeof p.period!=='string'||(p.period&&!/^\d{4}-(0[1-9]|1[0-2])$/.test(p.period))||!Number.isInteger(p.precision)||p.precision<0||p.precision>6||typeof p.tolerance!=='string'||amount(p.tolerance).isNegative())throw Error('期间/金额精度/勾稽容差无效')}
const period=(v:Cell)=>{const s=text(v);if(!/^(19|20|21)\d{2}-(0[1-9]|1[0-2])$/.test(s))throw Error('期间须为1900–2199的YYYY-MM');return s};
const dec=(v:Cell)=>new D(amount(v).toString());
const str=(v:Cell)=>text(v).trim();
const blank=(v:Cell)=>v===null||v===undefined||v==='';
const money=(v:Cell,p:Params)=>{const a=dec(v);if(a.decimalPlaces()>p.precision)throw Error('金额超过选定精度');return a};
const key=(a:Record<string,string>)=>JSON.stringify([a.员工ID,a.期间,a.计划ID,a.币种,a.单位]);
interface Parsed{r:SourceRow;v:Record<string,string>;get:(h:string)=>Cell}
export interface Issue{kind:Kind;source:string;message:string;group:string;severity:'阻塞'|'提示'}
export interface Segment{group:string;rule:string;tier:string;lower:string;upper:string;rate:string;base:string;commission:string;source:string}
export interface Person{group:string;employee:string;name:string;period:string;plan:string;currency:string;unit:string;performance:string|null;collection:string|null;base:string|null;rule:string;basis:string;method:string;progressive:string|null;whole:string|null;bonus:string|null;raw:string|null;rounded:string|null;roundDelta:string|null;cap:string;capReduction:string|null;adjustment:string|null;payable:string|null;residual:string|null;status:string;source:string;ruleSource:string;tierSources:string;adjustSources:string}
export interface Result{people:Person[];segments:Segment[];issues:Issue[];controls:{period:string;currency:string;unit:string;rounded:string;capReduction:string;adjustment:string;payable:string;residual:string;blocked:number}[]}
export function calculate(data:Data,p:Params):Result{
 validateParams(p);const issues:Issue[]=[],people:Person[]=[],segments:Segment[]=[];
 const parsed={} as Record<Kind,Parsed[]>;
 for(const k of kinds){const ds=data[k];if(!ds){if(k!=='调整')throw Error('缺少'+k+'资料');parsed[k]=[];continue}if(schemas[k].some(h=>!ds.map[h]||!ds.table.headers.includes(ds.map[h])))throw Error(k+'字段映射不完整');if(new Set(schemas[k].map(h=>ds.map[h])).size!==schemas[k].length)throw Error(k+'不同业务字段不得映射到同一列');parsed[k]=ds.table.rows.map(r=>({r,v:Object.fromEntries(schemas[k].map(h=>[h,typeof cell(ds,r,h)==='object'?'':String(cell(ds,r,h)??'').trim()])),get:h=>cell(ds,r,h)}));}
 const issue=(k:Kind,a:Parsed,message:string,g='',severity:Issue['severity']='阻塞')=>issues.push({kind:k,source:source(a.r),message,group:g,severity});
 const duplicates=(rows:Parsed[],h:string)=>{const n=new Map<string,number>();for(const a of rows){const id=a.v[h];if(id)n.set(id,(n.get(id)??0)+1)}return new Set([...n].filter(([,v])=>v>1).map(([k])=>k))};
 const dupPerf=duplicates(parsed.业绩,'记录ID'),dupRules=duplicates(parsed.规则,'规则ID'),dupAdj=duplicates(parsed.调整,'调整ID');
 const groups=new Map<string,Parsed[]>();
 for(const a of parsed.业绩){const g=key(a.v);if(p.period&&a.v.期间!==p.period){issue('业绩',a,'不在期间筛选，未参与',g,'提示');continue}groups.set(g,[...(groups.get(g)??[]),a]);}
 const adjGroups=new Map<string,Parsed[]>();for(const a of parsed.调整){const g=key(a.v);if(p.period&&a.v.期间!==p.period){issue('调整',a,'不在期间筛选，未参与',g,'提示');continue}adjGroups.set(g,[...(adjGroups.get(g)??[]),a]);if(!groups.has(g))issue('调整',a,'无对应业绩组，调整未应用',g);}
 // Preflight every rule/tier, including unused records. Invalid rows never vanish silently.
 const badRule=new Map<Parsed,string>(),badTier=new Map<Parsed,string>();
 for(const a of parsed.规则)try{for(const h of schemas.规则.filter(h=>h!=='封顶'))str(a.get(h));date(a.get('开始日'));date(a.get('结束日'));if(a.v.开始日>a.v.结束日)throw Error('规则日期倒置');if(dupRules.has(a.v.规则ID))throw Error('规则ID重复');if(!['业绩','回款'].includes(a.v.基数)||!['累进','全额'].includes(a.v.算法)||!['禁止','净额冲减'].includes(a.v.负业绩)||!['是','否'].includes(a.v.允许负测算))throw Error('规则枚举无效');if(!blank(a.get('封顶'))&&money(a.get('封顶'),p).isNegative())throw Error('封顶不得为负');}catch(e){badRule.set(a,(e as Error).message);issue('规则',a,(e as Error).message);}
 for(const a of parsed.档位)try{for(const h of schemas.档位.filter(h=>h!=='上限'))str(a.get(h));const lo=money(a.get('下限'),p),hi=blank(a.get('上限'))?null:money(a.get('上限'),p),rate=dec(a.get('比例%')),bonus=money(a.get('固定奖金'),p);if(lo.isNegative()||hi&&hi.lte(lo)||rate.isNegative()||rate.gt(100)||bonus.isNegative())throw Error('档位上下限/比例/奖金无效');if(!parsed.规则.some(r=>r.v.规则ID===a.v.规则ID))throw Error('档位没有关联规则');}catch(e){badTier.set(a,(e as Error).message);issue('档位',a,(e as Error).message);}
 const reversalCounts=new Map<string,number>();for(const a of parsed.调整)if(a.v.类型==='冲回'&&a.v.原支付ID){const k=JSON.stringify([a.v.员工ID,a.v.原支付ID]);reversalCounts.set(k,(reversalCounts.get(k)??0)+1)}
 for(const [g,rows] of groups){const a=rows[0],v=a.v,adjs=adjGroups.get(g)??[];const out:Person={group:g,employee:v.员工ID,name:v.员工姓名,period:v.期间,plan:v.计划ID,currency:v.币种,unit:v.单位,performance:null,collection:null,base:null,rule:'',basis:'',method:'',progressive:null,whole:null,bonus:null,raw:null,rounded:null,roundDelta:null,cap:'',capReduction:null,adjustment:null,payable:null,residual:null,status:'未计算',source:rows.map(a=>source(a.r)).join('\n'),ruleSource:'',tierSources:'',adjustSources:adjs.map(a=>source(a.r)).join('\n')};people.push(out);
 try{
 let perf=new D(0),cash=new D(0);const names=new Set<string>();for(const a of rows){try{for(const h of schemas.业绩)str(a.get(h));period(a.get('期间'));if(dupPerf.has(a.v.记录ID))throw Error('记录ID重复，整组待复核');names.add(a.v.员工姓名);perf=perf.plus(money(a.get('业绩'),p));cash=cash.plus(money(a.get('回款'),p));}catch(e){issue('业绩',a,(e as Error).message,g)}}
 if(names.size>1)issue('业绩',a,'同一员工ID对应不同姓名',g);if(issues.some(i=>i.group===g&&i.severity==='阻塞'))throw Error('业绩资料异常');out.performance=perf.toFixed(p.precision);out.collection=cash.toFixed(p.precision);
 const start=v.期间+'-01',[year,month]=v.期间.split('-').map(Number),end=v.期间+'-'+new Date(Date.UTC(year,month,0)).getUTCDate();
 const matching=parsed.规则.filter(r=>r.v.计划ID===v.计划ID&&r.v.币种===v.币种&&r.v.单位===v.单位&&(badRule.has(r)||(r.v.开始日<=end&&r.v.结束日>=start)));
 if(matching.length!==1)throw Error('规则缺失或重叠，须唯一规则覆盖完整月份');const rule=matching[0];out.rule=rule.v.规则ID;out.ruleSource=source(rule.r);if(badRule.has(rule))throw Error('规则无效：'+badRule.get(rule));if(rule.v.开始日>start||rule.v.结束日<end)throw Error('规则未覆盖完整月份，中途变更需另行分期');out.basis=rule.v.基数;out.method=rule.v.算法;
 const base=rule.v.基数==='业绩'?perf:cash;out.base=base.toFixed(p.precision);if(rows.some(a=>money(a.get(rule.v.基数),p).isNegative())&&rule.v.负业绩!=='净额冲减')throw Error('负业绩未获净额冲减规则允许');if(base.isNegative())throw Error('净基数为负，不能猜测历史提成冲回');
 const tiers=parsed.档位.filter(t=>t.v.规则ID===rule.v.规则ID);out.tierSources=tiers.map(t=>source(t.r)).join('\n');if(!tiers.length||tiers.length>30)throw Error('档位须1–30档');if(tiers.some(t=>badTier.has(t)))throw Error('档位含无效行');if(new Set(tiers.map(t=>t.v.档位ID)).size!==tiers.length)throw Error('同规则档位ID重复');tiers.sort((a,b)=>dec(a.get('下限')).cmp(dec(b.get('下限'))));let previous=new D(0);for(let i=0;i<tiers.length;i++){const t=tiers[i],lo=dec(t.get('下限'));if(!lo.eq(previous))throw Error('档位缺口或重叠，必须从0连续');if(blank(t.get('上限'))){if(i!==tiers.length-1)throw Error('无限档必须是末档');}else{if(i===tiers.length-1)throw Error('末档上限必须为空（无限）');previous=dec(t.get('上限'));}}
 let progressive=new D(0);const lines:Segment[]=[];let hit=tiers[0];for(const t of tiers){const lo=dec(t.get('下限')),hi=blank(t.get('上限'))?base:dec(t.get('上限')),part=D.max(0,D.min(base,hi).minus(lo)),commission=part.times(dec(t.get('比例%'))).div(100);progressive=progressive.plus(commission);if(base.gt(lo))hit=t;lines.push({group:g,rule:rule.v.规则ID,tier:t.v.档位ID,lower:lo.toString(),upper:blank(t.get('上限'))?'∞':hi.toString(),rate:t.v['比例%'],base:part.toFixed(p.precision),commission:commission.toFixed(12),source:source(t.r)});}
 const whole=base.times(dec(hit.get('比例%'))).div(100),bonus=base.isZero()?new D(0):dec(hit.get('固定奖金')),raw=(rule.v.算法==='累进'?progressive:whole).plus(bonus),rounded=raw.toDecimalPlaces(p.precision),cap=blank(rule.get('封顶'))?null:money(rule.get('封顶'),p),capped=cap?D.min(rounded,cap):rounded;
 out.progressive=progressive.toFixed(12);out.whole=whole.toFixed(12);out.bonus=bonus.toFixed(p.precision);out.raw=raw.toFixed(12);out.rounded=rounded.toFixed(p.precision);out.roundDelta=rounded.minus(raw).toFixed(12);out.cap=cap?cap.toFixed(p.precision):'无限制';out.capReduction=rounded.minus(capped).toFixed(p.precision);
 let adjustment=new D(0);for(const adj of adjs)try{for(const h of schemas.调整.filter(h=>h!=='原支付ID'))str(adj.get(h));period(adj.get('期间'));date(adj.get('复核日'));if(dupAdj.has(adj.v.调整ID))throw Error('调整ID重复');if(adj.v.状态!=='已复核')throw Error('调整未复核');if(adj.v.制单人===adj.v.复核人)throw Error('制单人与复核人须不同');const n=money(adj.get('金额'),p);if(!['奖金','调整','冲回'].includes(adj.v.类型))throw Error('调整类型无效');if(adj.v.类型==='奖金'&&n.isNegative())throw Error('奖金不得为负');if(adj.v.类型==='冲回'){str(adj.get('原支付ID'));if(n.isPositive())throw Error('冲回金额须非正');if((reversalCounts.get(JSON.stringify([adj.v.员工ID,adj.v.原支付ID]))??0)>1)throw Error('同一员工原支付ID重复冲回');}adjustment=adjustment.plus(n);}catch(e){issue('调整',adj,(e as Error).message,g)}
 if(issues.some(i=>i.group===g&&i.severity==='阻塞'))throw Error('调整资料异常');out.adjustment=adjustment.toFixed(p.precision);const payable=capped.plus(adjustment);if(payable.isNegative()&&rule.v.允许负测算!=='是')throw Error('最终负测算额未经规则允许');out.payable=payable.toFixed(p.precision);out.residual=rounded.minus(rounded.minus(capped)).plus(adjustment).minus(payable).toFixed(p.precision);out.status='已测算，待企业确认';segments.push(...lines);
 }catch(e){out.status='阻塞：'+(e as Error).message;issue('业绩',a,(e as Error).message,g)}
 }
 const controls:Result['controls']=[];for(const group of new Set(people.map(x=>JSON.stringify([x.period,x.currency,x.unit])))){const [period,currency,unit]=JSON.parse(group),rows=people.filter(x=>x.period===period&&x.currency===currency&&x.unit===unit),ok=rows.filter(x=>x.payable!==null);const sum=(h:'rounded'|'capReduction'|'adjustment'|'payable')=>ok.reduce((s,r)=>s.plus(r[h]!),new D(0));const residual=sum('rounded').minus(sum('capReduction')).plus(sum('adjustment')).minus(sum('payable'));controls.push({period,currency,unit,rounded:sum('rounded').toFixed(p.precision),capReduction:sum('capReduction').toFixed(p.precision),adjustment:sum('adjustment').toFixed(p.precision),payable:sum('payable').toFixed(p.precision),residual:residual.toFixed(p.precision),blocked:rows.length-ok.length});if(residual.abs().gt(dec(p.tolerance)))throw Error('内部勾稽超差');}
 return {people,segments,issues,controls};
}
