import type {Person,Result} from './engine';
/** View identity uses the exact engine group key, never employee or name alone. */
export const identityHeaders=['人员编号','姓名','月份','方案','币种','单位'];
export function identity(group:string,result:Result):unknown[]{
 const person=result.people.find(p=>p.group===group);
 if(person)return [person.employee,person.name,person.period,person.plan,person.currency,person.unit];
 try{const key:unknown=JSON.parse(group);if(Array.isArray(key)&&key.length===5&&key.every(v=>typeof v==='string'||v===null))return [key[0],null,key[1],key[2],key[3],key[4]]}catch{}
 return [null,null,null,null,null,null];
}
export const personIdentity=(p:Person)=>[p.employee,p.name,p.period,p.plan,p.currency,p.unit];
export const displayValue=(v:unknown)=>v===null||v===undefined?'（未提供）':v===''?'（空字符串）':typeof v==='object'?'结构值（展开原始详情）':String(v);
export function editSummary(edits:Record<string,string>){const entries=Object.entries(edits);return entries.length?entries.map(([field,value])=>field+'：'+displayValue(value)).join('；'):'无人工修正'}
