/** Build-time fictitious examples and blank templates; never browser user files. */
export interface ReleaseAsset {filename:string;data:string|Uint8Array}
export function validateReleaseAssets(assets:ReleaseAsset[]):void{
 const names=new Set<string>();
 for(const asset of assets){
  if(!asset||typeof asset.filename!=='string'||!asset.filename||asset.filename.includes('/')||asset.filename.includes('\\')||asset.filename.startsWith('.')||asset.filename.endsWith('.zip'))throw Error('交付文件名无效');
  if(names.has(asset.filename))throw Error('交付文件名重复');names.add(asset.filename);
  if(typeof asset.data!=='string'&&!(asset.data instanceof Uint8Array))throw Error('交付文件内容无效');
  const size=typeof asset.data==='string'?new TextEncoder().encode(asset.data).length:asset.data.byteLength;
  if(size>10*1024*1024)throw Error('模板或虚构样例超过浏览器单文件上限');
 }
 if(!names.has('空白模板.csv')||!names.has('虚构样例.xlsx'))throw Error('缺少统一登记的空白模板或虚构Excel样例');
}
