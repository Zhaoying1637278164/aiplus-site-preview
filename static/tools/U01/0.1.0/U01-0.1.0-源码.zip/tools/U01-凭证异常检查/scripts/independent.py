# 独立Python Decimal计算，不调用被测引擎，输入来自完全虚构样例CSV。
import csv,pathlib,json,decimal,collections,hashlib
root=pathlib.Path.cwd();p=root/'tools/U01-凭证异常检查/candidate/0.1.0/虚构样例.csv';rows=list(csv.DictReader(p.open(encoding='utf-8-sig')));groups=collections.defaultdict(list)
for i,r in enumerate(rows):
 if r['主体']=='虚构甲公司' and r['期间']=='2026-09' and r['币种']=='CNY' and r['单位']=='元':groups[r['凭证ID']].append((i+2,r))
result=[]
for k,rs in groups.items():
 invalid=any(r['借方']=='' or r['贷方']=='' for _,r in rs)
 d=None if invalid else sum((decimal.Decimal(r['借方']) for _,r in rs),decimal.Decimal(0));c=None if invalid else sum((decimal.Decimal(r['贷方']) for _,r in rs),decimal.Decimal(0));result.append({'voucher':k,'source_rows':[i for i,_ in rs],'debit':None if invalid else str(d),'credit':None if invalid else str(c),'difference':None if invalid else str(d-c)})
assert [None if r['difference'] is None else decimal.Decimal(r['difference']) for r in result]==[decimal.Decimal('0.02'),decimal.Decimal('0.0'),None,decimal.Decimal('0')]
(root/'progress/evidence/U01/0.1.0/independent-finance.json').write_text(json.dumps({'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'method':'Python Decimal independent sums; manual rules in 规格与独立预期.md','groups':result,'scope_rows':9,'excluded':3,'status':'passed'},ensure_ascii=False,indent=2));print('independent passed')
