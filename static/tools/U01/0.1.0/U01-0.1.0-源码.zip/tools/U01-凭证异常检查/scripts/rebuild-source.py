import pathlib,zipfile,tempfile,subprocess,os,json,hashlib,time
root=pathlib.Path.cwd();out=root/'tools/U01-凭证异常检查/candidate/0.1.0';e=root/'progress/evidence/U01/0.1.0/source-rebuild';e.mkdir(parents=True,exist_ok=True);source=out/'U01-0.1.0-源码.zip';dst=pathlib.Path(tempfile.mkdtemp(dir='/private/tmp',prefix='u01-rebuild-'))
with zipfile.ZipFile(source) as z:z.extractall(dst)
m=json.loads((dst/'SOURCE-SHA256.json').read_text());assert all(hashlib.sha256((dst/f).read_bytes()).hexdigest()==s for f,s in m.items());runs=[];env=dict(os.environ);env['npm_config_audit']='false';env['npm_config_fund']='false'
try:
 for i,cmd in enumerate([['npm','ci'],['npm','test'],['npm','run','typecheck'],['npm','run','build','--','U01']]):
  start=time.time()
  with (e/f'{i+1}.log').open('w') as log:p=subprocess.run(cmd,cwd=dst,env=env,stdout=log,stderr=subprocess.STDOUT)
  runs.append({'command':cmd,'exit_code':p.returncode,'seconds':round(time.time()-start,3)});print(json.dumps(runs[-1]),flush=True);assert p.returncode==0
 assets=[]
 for p in sorted(out.iterdir()):
  if p.is_file() and p.suffix!='.zip':
   sha=hashlib.sha256((dst/'tools/U01-凭证异常检查/candidate/0.1.0'/p.name).read_bytes()).hexdigest();assert sha==hashlib.sha256(p.read_bytes()).hexdigest(),p.name;assets.append({'file':p.name,'sha256':sha})
 result={'status':'passed','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_entries':len(m),'commands':runs,'exact_assets':assets,'directory':str(dst)}
except Exception as ex:result={'status':'failed','error':str(ex),'commands':runs,'directory':str(dst)}
(e/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));assert result['status']=='passed',result
