import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';import type {Table,Cell} from '../../../packages/core/types';import {FIELDS,RULES,LABELS,type Config,type Field,type Result,type Hit} from './types';
const month=(s:string)=>/^\d{4}-(0[1-9]|1[0-2])$/.test(s)&&Number(s.slice(0,4))>=1900;
export function validateConfig(c:Config){if(!c||!c.mapping||FIELDS.some(f=>typeof c.mapping[f]!=='string')||!c.enabled||RULES.some(r=>typeof c.enabled[r]!=='boolean'))throw Error('字段或检查开关无效');
 for(const s of [c.scope.entity,c.scope.currency,c.scope.unit,c.basis])if(typeof s!=='string'||!s.trim()||s.length>10000)throw Error('主体、币种、单位和规则依据须填写');
 const mapped=FIELDS.map(f=>c.mapping[f]).filter(Boolean);if(new Set(mapped).size!==mapped.length)throw Error('同一源列不能对应多个业务字段');
 for(const s of [c.scope.from,c.scope.to,c.effectiveFrom,c.effectiveTo])if(!month(s))throw Error('期间须为YYYY-MM');
 if(c.scope.from>c.scope.to||c.effectiveFrom>c.effectiveTo||c.scope.from<c.effectiveFrom||c.scope.to>c.effectiveTo)throw Error('检查范围须在规则生效期间内');
 for(const s of [c.threshold,c.tolerance])if(amount(s).isNegative())throw Error('阈值和容差不能负数');if(!amount(c.multiple).gt(0))throw Error('整数倍须大于零');
 if(typeof c.weekend!=='boolean')throw Error('周末参数无效');
 for(const k of ['dates','keywords','accountA','accountB'] as const)if(typeof c[k]!=='string'||c[k].length>10000)throw Error('规则文本无效');
 for(const d of c.dates.split(',').map(x=>x.trim()).filter(Boolean))date(d);
 if(c.enabled.keyword&&!c.keywords.split(',').some(x=>x.trim()))throw Error('关键词不能空');
 if(c.enabled.pair&&(!c.accountA.trim()||!c.accountB.trim()||c.accountA.trim()===c.accountB.trim()))throw Error('须提供两个不同的关联科目');
}
export function validateTable(t:Table){if(!t||typeof t.file!=='string'||typeof t.sheet!=='string'||!Array.isArray(t.headers)||!Array.isArray(t.rows)||t.headers.length>200||t.rows.length>20000||new Set(t.headers).size!==t.headers.length||t.headers.some(h=>typeof h!=='string'||!h.trim()||h.length>10000))throw Error('资料结构无效或超过行列上限');
 const sources=new Set<number>();for(const r of t.rows){if(r.file!==t.file||r.sheet!==t.sheet||!Number.isSafeInteger(r.row)||r.row<1||sources.has(r.row)||!r.cells||typeof r.cells!=='object')throw Error('来源行无效或重复');sources.add(r.row);for(const h of t.headers){const v=r.cells[h];if(v!==null&&typeof v!=='string'&&typeof v!=='number'&&!(v&&typeof v==='object'&&typeof v.formula==='string'))throw Error('单元格无效');if((typeof v==='string'&&v.length>10000)||(v&&typeof v==='object'&&JSON.stringify(v).length>10000))throw Error('单元格过长');}}
}
export function run(t:Table,c:Config):Result{validateTable(t);validateConfig(c);const out:Result={execution:[],hits:[],coverage:[],excluded:[],included:[],groups:[],quality:[]};
 const get=(i:number,f:Field):Cell=>{if(!c.mapping[f]||!t.headers.includes(c.mapping[f]))throw Error('缺少字段：'+f);return t.rows[i].cells[c.mapping[f]]};
 const val=(i:number,f:Field)=>text(get(i,f),true);const money=(i:number)=>[amount(get(i,'借方')),amount(get(i,'贷方'))] as const;
 const groupMap=new Map<string,number[]>();
 for(let i=0;i<t.rows.length;i++){try{const entity=val(i,'主体'),period=val(i,'期间'),cur=val(i,'币种'),unit=val(i,'单位');if(!month(period))throw Error('期间格式无效');if(entity!==c.scope.entity||period<c.scope.from||period>c.scope.to||cur!==c.scope.currency||unit!==c.scope.unit){out.excluded.push({index:i,reason:'不在选定主体/期间/币种/单位范围'});continue}out.included.push(i);
 try{const key=JSON.stringify([entity,period,val(i,'凭证ID'),cur,unit]);if(!groupMap.has(key))groupMap.set(key,[]);groupMap.get(key)!.push(i)}catch(e){out.quality.push({id:'q-id-'+i,rule:'数据质量',object:'原行'+t.rows[i].row,rows:[i],reason:String((e as Error).message)})}
 }catch(e){out.excluded.push({index:i,reason:'范围不可判定：'+(e as Error).message})}}
 const quality=(i:number,reason:string,suffix:string)=>out.quality.push({id:'q-'+suffix+'-'+i,rule:'数据质量',object:'原行'+t.rows[i].row,rows:[i],reason});
 for(const i of out.included){try{const [d,cr]=money(i);if(d.lt(0)||cr.lt(0))quality(i,'负金额保留原方向，需复核','negative');if(!d.isZero()&&!cr.isZero())quality(i,'同一行借贷均非零','both')}catch(e){quality(i,(e as Error).message,'amount')}
 try{if(date(get(i,'日期')).slice(0,7)!==val(i,'期间'))quality(i,'凭证日期与期间不一致','period')}catch(e){quality(i,(e as Error).message,'date')}
 try{val(i,'科目')}catch(e){quality(i,(e as Error).message,'account')}}
 for(const [key,rows]of groupMap){let debit:string|null=null,credit:string|null=null,difference:string|null=null,reason='';try{let d=new Decimal(0),cr=new Decimal(0);for(const i of rows){const m=money(i);d=d.plus(m[0]);cr=cr.plus(m[1])}debit=d.toFixed();credit=cr.toFixed();difference=d.minus(cr).toFixed()}catch(e){reason=(e as Error).message}out.groups.push({key,rows,debit,credit,difference,reason})}
 const groupsByKey=new Map(out.groups.map(g=>[g.key,g]));
 const deps:Record<string,Field[]>={balance:['凭证ID','借方','贷方'],large:['借方','贷方'],round:['借方','贷方'],special:['日期','期间'],keyword:['摘要'],sameUser:['制单人','审核人'],pair:['凭证ID','科目'],duplicate:['凭证ID','行ID']};
 for(const rule of RULES){const grouped=['balance','pair','duplicate'].includes(rule);const objects: {key:string;rows:number[]}[]=grouped?out.groups.map(g=>({key:g.key,rows:g.rows})):out.included.map(i=>({key:'原行'+t.rows[i].row,rows:[i]}));
 const cov={rule,label:LABELS[rule],executed:0,skipped:0,hits:0,disabled:!c.enabled[rule],reason:''};out.coverage.push(cov);if(cov.disabled){cov.reason='用户关闭';out.execution.push({rule:LABELS[rule],object:'全部范围',rows:[],status:'关闭',reason:'用户关闭'});continue}
 if(grouped){const identified=new Set(out.groups.flatMap(g=>g.rows));const unidentified=out.included.filter(i=>!identified.has(i));for(const i of unidentified)out.execution.push({rule:LABELS[rule],object:'原行'+t.rows[i].row,rows:[i],status:'未执行',reason:'凭证ID缺失'});cov.skipped+=unidentified.length;if(unidentified.length)cov.reason='凭证ID缺失，未分组行不执行；'}
 const missing=deps[rule].filter(f=>!c.mapping[f]||!t.headers.includes(c.mapping[f]));if(missing.length){cov.skipped+=objects.length;cov.reason+='缺少列：'+missing.join('、');for(const obj of objects)out.execution.push({rule:LABELS[rule],...obj,object:obj.key,status:'未执行',reason:cov.reason});continue}
 for(const obj of objects){try{let reason='';const i=obj.rows[0];if(rule==='balance'){const g=groupsByKey.get(obj.key)!;if(g.difference===null)throw Error(g.reason);if(amount(g.difference).abs().gt(amount(c.tolerance)))reason='借方'+g.debit+' − 贷方'+g.credit+' = '+g.difference+'，绝对差额超过容差'+c.tolerance}
 if(rule==='large'||rule==='round'){const m=money(i),a=Decimal.max(m[0].abs(),m[1].abs());if(rule==='large'&&a.gte(amount(c.threshold)))reason='单边绝对金额'+a.toFixed()+' ≥ 阈值'+c.threshold;if(rule==='round'&&!a.isZero()&&a.mod(amount(c.multiple)).isZero())reason='非零单边绝对金额'+a.toFixed()+'为'+c.multiple+'的整数倍'}
 if(rule==='special'){const d=date(get(i,'日期'));if(d.slice(0,7)!==val(i,'期间'))throw Error('日期期间不一致');const dow=new Date(d+'T00:00:00Z').getUTCDay();if(c.dates.split(',').map(x=>x.trim()).includes(d)||(c.weekend&&(dow===0||dow===6)))reason='日期'+d+'命中指定日期/周末'}
 if(rule==='keyword'){const s=val(i,'摘要'),words=c.keywords.split(',').map(x=>x.trim()).filter(Boolean),hit=words.filter(w=>s.includes(w));if(hit.length)reason='摘要包含字面关键词：'+hit.join('、')}
 if(rule==='sameUser'){const a=val(i,'制单人'),b=val(i,'审核人');if(a===b)reason='制单人与审核人相同：'+a}
 if(rule==='pair'){const codes=obj.rows.map(j=>val(j,'科目'));if(codes.includes(c.accountA.trim())&&codes.includes(c.accountB.trim()))reason='同凭证含科目'+c.accountA+'与'+c.accountB}
 if(rule==='duplicate'){const ids=obj.rows.map(j=>val(j,'行ID')),dups=[...new Set(ids.filter((v,j)=>ids.indexOf(v)!==j))];if(dups.length)reason='同凭证重复行ID：'+dups.join('、')}
 cov.executed++;out.execution.push({rule:LABELS[rule],object:obj.key,rows:obj.rows,status:reason?'命中':'未命中',reason:reason||'未命中不等于无风险'});if(reason){cov.hits++;out.hits.push({id:rule+':'+obj.key,rule:LABELS[rule],object:obj.key,rows:obj.rows,reason})}
 }catch(e){cov.skipped++;const msg=(e as Error).message;out.execution.push({rule:LABELS[rule],object:obj.key,rows:obj.rows,status:'未执行',reason:msg});if(!cov.reason.includes(msg))cov.reason+=(cov.reason?'；':'')+msg}}
 }
 return out;
}
