import type {Table} from '../../../packages/core/types';
export const VERSION='0.1.0';export const RULE_VERSION='U01-2026-10-04.1';
export const FIELDS=['主体','期间','凭证ID','行ID','日期','科目','借方','贷方','币种','单位','摘要','制单人','审核人'] as const;
export type Field=typeof FIELDS[number];
export const RULES=['balance','large','round','special','keyword','sameUser','pair','duplicate'] as const;
export type RuleId=typeof RULES[number];
export const LABELS:Record<RuleId,string>={balance:'凭证借贷差额',large:'大额分录',round:'整数倍金额',special:'特殊日期',keyword:'摘要关键词',sameUser:'制单审核同人',pair:'关联科目组合',duplicate:'重复行ID'};
export interface Config {mapping:Record<Field,string>;scope:{entity:string;from:string;to:string;currency:string;unit:string};enabled:Record<RuleId,boolean>;threshold:string;tolerance:string;multiple:string;weekend:boolean;dates:string;keywords:string;accountA:string;accountB:string;basis:string;effectiveFrom:string;effectiveTo:string}
export interface Review {status:'待复核'|'已补充解释'|'需跟进';reviewer:string;date:string;note:string}
export interface Work {table:Table|null;config:Config;reviews:Record<string,Review>}
export interface Hit {id:string;rule:string;object:string;rows:number[];reason:string}
export interface Coverage {rule:RuleId;label:string;executed:number;skipped:number;hits:number;disabled:boolean;reason:string}
export interface Exclusion {index:number;reason:string}
export interface Group {key:string;rows:number[];debit:string|null;credit:string|null;difference:string|null;reason:string}
export interface Execution {rule:string;object:string;rows:number[];status:string;reason:string}
export interface Result {execution:Execution[];hits:Hit[];coverage:Coverage[];excluded:Exclusion[];included:number[];groups:Group[];quality:Hit[]}
export function initial():Work{return {table:null,config:{mapping:Object.fromEntries(FIELDS.map(f=>[f,f])) as Record<Field,string>,scope:{entity:'虚构甲公司',from:'2026-09',to:'2026-09',currency:'CNY',unit:'元'},enabled:Object.fromEntries(RULES.map(r=>[r,true])) as Record<RuleId,boolean>,threshold:'10000',tolerance:'0.01',multiple:'1000',weekend:true,dates:'2026-09-30',keywords:'调整,冲回',accountA:'1001',accountB:'6001',basis:'用户内部凭证复核要求（演示，需确认）',effectiveFrom:'2026-01',effectiveTo:'2026-12'},reviews:{}}}
