import {workbookBytes} from '../../../packages/core/io';import type {Work,Result,Hit} from './types';import {VERSION,RULE_VERSION,FIELDS,RULES,LABELS} from './types';
function safeCsv(v:unknown){const s=String(v??'');return /^[=+\-@]/.test(s)&&! /^[+-]?\d+(?:\.\d+)?$/.test(s)?"'"+s:s}
export function csv(headers:string[],rows:unknown[][]){return '\uFEFF'+[headers,...rows].map(row=>row.map(v=>'"'+safeCsv(v).replace(/"/g,'""')+'"').join(',')).join('\r\n')}
export function source(w:Work,indices:number[]){return indices.map(i=>{const r=w.table!.rows[i];return r.file+' / '+r.sheet+' / 行'+r.row}).join('；')}
export function hitRows(w:Work,hits:Hit[]){return hits.map(h=>[h.id,h.rule,h.object,h.reason,source(w,h.rows)])}
export function sheets(w:Work,r:Result){const t=w.table!;return [
 {name:'检查说明',headers:['项目','值'],rows:[['应用版本',VERSION],['规则版本',RULE_VERSION],['范围',JSON.stringify(w.config.scope)],['边界','未命中不等于无风险；不认定舞弊、不生成审计结论'],['原始行数',t.rows.length],['范围内行数',r.included.length],['范围外或不可判定',r.excluded.length]]},
 {name:'检查条件',headers:['参数','值'],rows:Object.entries(w.config).map(([k,v])=>[k,typeof v==='object'?JSON.stringify(v):String(v)])},
 {name:'字段对应',headers:['业务字段','源列'],rows:FIELDS.map(f=>[f,w.config.mapping[f]])},
 {name:'规则覆盖',headers:['规则','启用','执行对象','未执行对象','命中对象','原因'],rows:r.coverage.map(c=>[c.label,!c.disabled,c.executed,c.skipped,c.hits,c.reason])},
 {name:'逐项执行',headers:['规则','对象','状态','原因','来源'],rows:r.execution.map(e=>[e.rule,e.object,e.status,e.reason,source(w,e.rows)])},
 {name:'异常线索',headers:['线索ID','规则','对象','原因','来源'],rows:hitRows(w,r.hits)},
 {name:'凭证勾稽',headers:['凭证键','借方','贷方','差额','不可用原因','来源'],rows:r.groups.map(g=>[g.key,g.debit,g.credit,g.difference,g.reason,source(w,g.rows)])},
 {name:'资料例外',headers:['类别','原因','来源'],rows:[...r.excluded.map(e=>['范围例外',e.reason,source(w,[e.index])]),...r.quality.map(h=>['数据质量',h.reason,source(w,h.rows)])]},
 {name:'复核记录',headers:['线索ID','状态','复核人','日期','依据'],rows:r.hits.map(h=>{const v=w.reviews[h.id];return [h.id,v?.status||'待复核',v?.reviewer||'',v?.date||'',v?.note||'']})},
 {name:'原始来源',headers:['文件','页签','原行',...t.headers],rows:t.rows.map(row=>[row.file,row.sheet,row.row,...t.headers.map(h=>row.cells[h])])}
]}
export async function report(w:Work,r:Result){return workbookBytes(sheets(w,r))}
