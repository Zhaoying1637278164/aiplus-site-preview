import {readFile,writeFile,mkdir,mkdtemp} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import JSZip from 'jszip';
import path from 'node:path';
const out='progress/evidence/D04/0.1.0/root-formal-offline';await mkdir(out,{recursive:true});
const hash=async p=>createHash('sha256').update(await readFile(p)).digest('hex');
const artifacts={};for(const n of ['index.html','runtime.json'])artifacts[n]=await hash('release/D04/0.1.0/'+n);
const offlineArchive='release/D04/0.1.0/D04-0.1.0-离线包.zip',offlineArchiveSha=await hash(offlineArchive);
const extracted=await mkdtemp('/private/tmp/aiplus-D04-offline-');
const zip=await JSZip.loadAsync(await readFile(offlineArchive));
for(const f of Object.values(zip.files)){
 if(f.dir)continue;
 if(! /^D04\/[^/]+$/.test(f.name)||f.name.includes('..'))throw Error('Unexpected offline package member');
 const bytes=await f.async('nodebuffer'),filename=path.basename(f.name);
 if(!bytes.equals(await readFile('release/D04/0.1.0/'+filename)))throw Error('Offline archive bytes differ from formal release');
 await mkdir(extracted+'/D04',{recursive:true});await writeFile(extracted+'/'+f.name,bytes);
}
const extractedIndex=extracted+'/D04/index.html';
const runs=[];let failure;
for(const suite of ['browser','extended-browser','boundaries-browser','native-browser','ui-repair-browser']){
 const script='tests/d04-formal-'+suite+'.mjs',scriptSha=await hash(script);
 try{
  const output=execFileSync(process.execPath,[script],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,AIPLUS_D04_OFFLINE_INDEX:extractedIndex}});
  runs.push({script,script_sha256:scriptSha,exit_code:0,output});console.log('PASS formal '+suite);
 }catch(e){runs.push({script,script_sha256:scriptSha,exit_code:e.status??-1,output:String(e.stdout??'')+String(e.stderr??'')});failure=e;break;}
}
for(const [n,h] of Object.entries(artifacts))if(await hash('release/D04/0.1.0/'+n)!==h)failure=Error('Formal artifact changed during browser verification');
await writeFile(out+'/run.json',JSON.stringify({tool:'D04',version:'0.1.0',offline_archive_sha256:offlineArchiveSha,extracted_index:extractedIndex,artifact_sha256:artifacts,runs,passed:!failure,website_verified:false,accepted:false},null,2)+'\n');
if(failure)throw failure;
