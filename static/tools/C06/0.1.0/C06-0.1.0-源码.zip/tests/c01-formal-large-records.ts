import {chromium} from 'playwright';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileData} from '../packages/core/io';

// Independent, completely fictional input. Do not call the C01 engine to create
// the fixture or its expected deadline/amount/source answers.
const out=path.resolve('progress/evidence/C01/0.1.0/root-formal-large-records');
await mkdir(out,{recursive:true});
const id=(n:number)=>'TASK'+String(n).padStart(3,'0');
const templates=Array.from({length:203},(_,i)=>({id:id(i+1),name:'虚构月结任务'+(i+1),owner:'虚构会计',offset:0,deps:i?[id(i)]:[],required:false,source:'虚构月结安排.csv / 月结模板 / 行'+(i+2)}));
const tasks=templates.map(t=>({...t,status:'未开始',note:'',completed:''}));
const evidence=tasks.map((t,i)=>{const bytes=Buffer.from('完全虚构证据 '+t.id);return {id:'E'+(i+1),task:t.id,name:'虚构证据'+(i+1)+'.txt',bytes:bytes.length,sha:createHash('sha256').update(bytes).digest('hex'),content:bytes.toString('base64'),source:'虚构证据登记 / 行'+(i+2)}});
const issues=tasks.map((t,i)=>({id:'I'+(i+1),task:t.id,title:'虚构待处理事项'+(i+1),owner:'虚构会计',due:'2024-03-01',amount:[null,'0.00','-1.25','2.10'][i%4],currency:'CNY',unit:'元',period:'2024-02',status:'待处理',resolution:'',source:'虚构事项.csv / 行'+(i+2)}));
const logs=Array.from({length:406},(_,i)=>({seq:i+1,at:'2024-03-01T00:00:00.000Z',period:'2024-02',action:'虚构复核',target:id(i%203+1),reason:'虚构测试记录',before:'虚构原值'+i,after:'虚构新值'+i}));
const work={templates,periods:[{id:'2024-02',entity:'完全虚构月结主体',currency:'CNY',unit:'元',asOf:'2024-03-01',tasks,evidence,issues,seal:null,priorSeals:[]}],logs};
const fixture=out+'/虚构203任务完整工作.json';
await writeFile(fixture,JSON.stringify({schema_version:1,tool:'C01',app_version:'0.1.0',rule_version:'C01-CLOSE-20261004.1',contains_data:true,work}));
const html=path.resolve('progress/evidence/C01/0.1.0/root-formal-offline/extracted/C01/index.html');
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const context=await browser.newContext({offline:true,acceptDownloads:true,viewport:{width:1440,height:1000}}),page=await context.newPage();
const errors:string[]=[],requests:string[]=[],checks:string[]=[],downloads:string[]=[];
page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});page.on('dialog',d=>d.accept());
await context.addInitScript(()=>{(window as any).__writes=[];for(const name of ['setItem','removeItem','clear'] as const){Storage.prototype[name]=function(){(window as any).__writes.push(name)}}const open=indexedDB.open.bind(indexedDB);indexedDB.open=(...a:any[])=>{(window as any).__writes.push('indexedDB');return (open as any)(...a)}});
const nav=async(name:string)=>{await page.getByRole('navigation').getByRole('button',{name,exact:true}).click()};
const status=async(text:RegExp)=>{await page.getByRole('status').filter({hasText:text}).waitFor()};
const download=async(name:string)=>{const pending=page.waitForEvent('download');await page.getByRole('button',{name,exact:true}).click();const d=await pending;const f=out+'/'+d.suggestedFilename();await d.saveAs(f);downloads.push(f);return f};
try{
 await page.goto('file://'+html);await nav('封板与恢复');await page.getByLabel('恢复JSON或归档ZIP',{exact:true}).setInputFiles(fixture);await status(/完整工作与证据字节已回读/);
 await nav('月结总览');assert.match(await page.locator('main').innerText(),/0 \/ 203/);assert.match(await page.locator('main').innerText(),/41.25 CNY \/ 元/);assert.match(await page.locator('main').innerText(),/51 项金额未填/);assert.equal(await page.locator('main tbody tr').count(),203);await page.locator('main tbody tr').last().scrollIntoViewIfNeeded();assert.match(await page.locator('main tbody tr').last().innerText(),/TASK203/);checks.push('203任务总览全尾部/闰年截止/独立41.25金额/51空值');
 await nav('依赖与日程');assert.equal(await page.locator('main tbody tr').count(),203);const tail=page.locator('main tbody tr').last();await tail.scrollIntoViewIfNeeded();assert.match(await tail.innerText(),/2024-02-29/);assert.match(await tail.innerText(),/TASK202：未开始/);await tail.getByRole('button',{name:'查看执行',exact:true}).click();assert.equal(await page.getByLabel('执行任务',{exact:true}).inputValue(),'TASK203');assert.match(await page.locator('main').innerText(),/行204/);checks.push('203日程末行/前置/原始行204/末项定位执行');
 await nav('证据管理');assert.equal(await page.locator('main tbody tr').count(),203);await page.locator('main tbody tr').last().scrollIntoViewIfNeeded();assert.match(await page.locator('main tbody tr').last().innerText(),/虚构证据203.txt/);const pending=page.waitForEvent('download');await page.locator('main tbody tr').last().getByRole('button',{name:'下载原件',exact:true}).click();const d=await pending;const original=out+'/最后证据原件.txt';await d.saveAs(original);downloads.push(original);assert.equal(await readFile(original,'utf8'),'完全虚构证据 TASK203');checks.push('203证据尾部/实际下载原字节');
 await nav('未结事项');assert.equal(await page.locator('main tbody tr').count(),203);await page.locator('main tbody tr').last().scrollIntoViewIfNeeded();assert.match(await page.locator('main tbody tr').last().innerText(),/I203/);checks.push('203事项全尾部/零负空值保留');
 await nav('变更记录');assert.equal(await page.locator('main tbody tr').count(),406);await page.locator('main tbody tr').last().scrollIntoViewIfNeeded();await page.locator('main tbody tr').last().locator('summary').click();assert.match(await page.locator('main tbody tr').last().innerText(),/虚构原值405/);assert.match(await page.locator('main tbody tr').last().innerText(),/虚构新值405/);checks.push('406变更全尾部/展开前后值');
 await nav('封板与恢复');const report=await download('下载月结底稿'),json=await download('下载恢复JSON'),zip=await download('下载归档ZIP');const sheets=(await readFileData('完整底稿.xlsx',new Uint8Array(await readFile(report)))).sheets;assert.deepEqual(sheets.map(s=>s.name),['期间','本期任务','证据索引','未结事项','变更记录','封板历史']);assert.deepEqual(sheets.map(s=>s.matrix.length-1),[1,203,203,203,406,0]);
 for(let i=0;i<203;i++){const t=sheets[1].matrix[i+1],e=sheets[2].matrix[i+1],issue=sheets[3].matrix[i+1];assert.equal(t[1],id(i+1));assert.equal(t[4],'2024-02-29');assert.equal(t[10],templates[i].source);assert.equal(e[1],id(i+1));assert.equal(e[5],evidence[i].sha);assert.equal(e[6],evidence[i].source);assert.equal(issue[1],'I'+(i+1));assert.equal(issue[6],issues[i].amount??'');assert.equal(issue[11],issues[i].source)}
 for(let i=0;i<406;i++){const row=sheets[4].matrix[i+1];assert.equal(Number(row[0]),i+1);assert.equal(row[6],'虚构原值'+i);assert.equal(row[7],'虚构新值'+i)}
 assert.deepEqual(JSON.parse(await readFile(json,'utf8')).work,work);checks.push('实际六表所有203/406行字段及来源逐格独立比对/完整JSON等同输入');
 await page.getByRole('button',{name:'清空工作并换资料',exact:true}).click();await status(/工作已清空/);await page.getByLabel('恢复JSON或归档ZIP',{exact:true}).setInputFiles(zip);await status(/完整工作与证据字节已回读/);await nav('变更记录');assert.equal(await page.locator('main tbody tr').count(),406);checks.push('实际完整ZIP下载/清空/恢复406记录');
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);assert.deepEqual(await page.evaluate(()=>(window as any).__writes),[]);
 await writeFile(out+'/result.json',JSON.stringify({passed:true,checks,downloads,errors,requests,storage_writes:[],html_sha256:createHash('sha256').update(await readFile(html)).digest('hex'),fixture_sha256:createHash('sha256').update(await readFile(fixture)).digest('hex'),expected:{tasks:203,evidence:203,issues:203,logs:406,deadline:'2024-02-29',unresolved_amount:'41.25',null_amounts:51},windows_verified:false,website_verified:false},null,2)+'\n');console.log('C01 formal large-records: '+checks.length+' groups passed');
}catch(e){await page.screenshot({path:out+'/failure.png',fullPage:true});await writeFile(out+'/failure.json',JSON.stringify({error:String(e),checks,errors,requests},null,2));throw e}finally{await browser.close()}
