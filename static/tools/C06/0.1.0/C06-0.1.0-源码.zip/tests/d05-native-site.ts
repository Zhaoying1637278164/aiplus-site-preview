import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import ExcelJS from 'exceljs';
import JSZip from 'jszip';
const host=process.env.AIPLUS_NATIVE_SITE_URL||'http://127.0.0.1:8521',origin=new URL(host).origin;
const out=path.resolve('progress/evidence/D05/0.1.0/site-local'),release=path.resolve('release/D05/0.1.0');
await mkdir(out+'/downloads',{recursive:true});const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const checks:string[]=[],errors:string[]=[],requests:string[]=[],downloads:Record<string,string>={},geometry:unknown[]=[];
const browser=await chromium.launch({headless:true,executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
try{
 const ctx=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}});
 await ctx.route('**/*',async route=>{const u=new URL(route.request().url());if(/^https?:/.test(u.protocol)&&u.origin!==origin){requests.push(u.href);await route.abort('blockedbyclient')}else await route.continue()});
 const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));let accept=false;page.on('dialog',d=>void(accept?d.accept():d.dismiss()));
 await page.goto(host,{waitUntil:'domcontentloaded'});const frame=page.frameLocator('iframe').first();
 await frame.locator('.nav a[href="#tools"]').click();await frame.locator('[data-f="mod"][data-v="meta"]').click();
 assert.equal(await frame.locator('[data-total]').innerText(),'9');
 const row=frame.locator('[data-tool]').filter({has:frame.getByRole('link',{name:'财务表格公式检查',exact:true})});assert.equal(await row.count(),1);
 assert.equal(await frame.locator('[data-tool]').filter({has:frame.getByRole('link',{name:'主数据管理台',exact:true})}).count(),1);
 await row.getByRole('link',{name:'详情',exact:true}).click();await frame.getByRole('heading',{name:'财务表格公式检查',exact:true}).waitFor();
 const detail=await frame.locator('#app').innerText();assert.match(detail,/工作簿、检查范围、问题定位、模式复核、来源追查、检查底稿、方案管理/);assert.match(detail,/不重算/);assert.match(detail,/仅接受XLSX/);
 await page.screenshot({path:out+'/detail.png',fullPage:true});checks.push('existing_meta_module_single_finance_row_and_explicit_static_xlsx_detail');
 const names=['D05-0.1.0-离线包.zip','D05-0.1.0-源码.zip','虚构样例.xlsx','空白模板.xlsx','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md','参考来源.md'];
 const labels=['下载离线包','下载源码','虚构样例（Excel）','空白模板（Excel）','使用说明','财务口径','第三方声明','参考来源.md'];
 for(let i=0;i<names.length;i++){
  const [d]=await Promise.all([page.waitForEvent('download'),frame.getByRole('link',{name:labels[i],exact:true}).click()]);await d.saveAs(out+'/downloads/'+names[i]);assert.equal(await d.failure(),null);
  const data=await readFile(out+'/downloads/'+names[i]);assert.equal(sha(data),sha(await readFile(release+'/'+names[i])));downloads[names[i]]=sha(data);
 }
 const zip=await JSZip.loadAsync(await readFile(out+'/downloads/'+names[0]));assert.equal(sha(Buffer.from(await zip.file('D05/index.html')!.async('uint8array'))),sha(await readFile(release+'/index.html')));
 checks.push('eight_actual_first_party_downloads_and_offline_program_exact_formal_sha');
 await frame.getByRole('link',{name:'开始检查财务表格',exact:true}).click();const app=frame.locator('#tool-workspace');await app.getByRole('heading',{name:'财务表格公式检查',exact:true}).waitFor();assert.equal(await frame.locator('iframe').count(),0);
 const nav=(name:string)=>app.getByRole('navigation').getByRole('button',{name,exact:true}).click();
 const take=async(name:string,filename:string)=>{const [d]=await Promise.all([page.waitForEvent('download'),app.getByRole('button',{name,exact:true}).click()]);const p=out+'/downloads/'+filename;await d.saveAs(p);assert.equal(await d.failure(),null);return p};
 await app.getByLabel('导入工作簿',{exact:true}).setInputFiles(out+'/downloads/虚构样例.xlsx');await app.getByRole('status').filter({hasText:'工作簿已读取'}).waitFor();await nav('检查范围');await app.getByRole('button',{name:'开始静态检查',exact:true}).click();assert.match(await app.locator('main').innerText(),/共9项/);
 await app.getByLabel('问题类型').selectOption('硬编码候选');await app.getByRole('button',{name:'追查 D4',exact:true}).click();await app.getByRole('heading',{name:'月度预算 / D4',exact:true}).waitFor();assert.match(await app.getByLabel('原格详情').innerText(),/123/);
 await nav('问题定位');await app.getByLabel('忽略依据').fill('虚构预算经理已确认此行手工覆盖');await app.getByRole('button',{name:'有依据忽略',exact:true}).click();
 await nav('检查底稿');const workbookPath=await take('下载完整检查底稿','site-workbook.xlsx'),reportPath=await take('下载完整报告JSON','site-report.json');
 const actual=JSON.parse(await readFile(reportPath,'utf8')),expected=JSON.parse(await readFile('progress/evidence/D05/0.1.0/root-formal-offline/browser/report.json','utf8'));assert.deepEqual(actual,expected);
 const matrix=async(p:string)=>{const w=new ExcelJS.Workbook();await w.xlsx.load(await readFile(p) as any);return w.worksheets.map(s=>{const rows:unknown[][]=[];s.eachRow({includeEmpty:true},r=>{const values:unknown[]=[];for(let i=1;i<=s.columnCount;i++){const c=r.getCell(i);assert.notEqual(c.type,ExcelJS.ValueType.Formula);values.push(c.value)}rows.push(values)});return {name:s.name,rows}})};
 assert.deepEqual(await matrix(workbookPath),await matrix('progress/evidence/D05/0.1.0/root-formal-offline/browser/workbook.xlsx'));
 checks.push('downloaded_real_xlsx_nine_manual_findings_original_cell_and_ignored_reason');checks.push('entire_json_and_seven_sheet_workpaper_exact_offline_finance_values_sources_rules');
 await nav('方案管理');const work=await take('下载含数据工作','site-work.json'),plan=await take('下载无数据方案','site-plan.json');
 const no=JSON.parse(await readFile(plan,'utf8'));assert.equal(no.contains_data,false);assert.equal(no.workbook,null);assert.deepEqual(no.rules.ignored,[]);
 await nav('工作簿');await app.getByLabel('导入工作簿',{exact:true}).setInputFiles(out+'/downloads/空白模板.xlsx');await app.getByRole('status').filter({hasText:'已读取'}).waitFor();await nav('检查范围');await app.getByRole('button',{name:'开始静态检查',exact:true}).click();assert.match(await app.locator('main').innerText(),/共1项/);
 await nav('方案管理');accept=true;await app.getByLabel('恢复方案或工作').setInputFiles(work);await app.getByRole('status').filter({hasText:'重新静态检查'}).waitFor();await nav('问题定位');assert.match(await app.locator('main').innerText(),/共9项/);
 checks.push('actual_template_replace_clears_and_explicit_data_restore_rechecks');
 for(const width of [1440,390,320]){
  await page.setViewportSize({width,height:1000});for(const name of ['工作簿','检查范围','问题定位','模式复核','来源追查','检查底稿','方案管理']){
   await app.locator('main').evaluate(el=>el.ownerDocument.defaultView!.scrollTo(0,el.ownerDocument.body.scrollHeight));await nav(name);
   const n=await app.locator('nav').boundingBox(),h=await app.locator('main h2').boundingBox(),header=await frame.locator('.hdr').boundingBox();assert.ok(n&&h&&header);assert.ok(n.y>=header.y+header.height-2);assert.ok(h.y>=n.y+n.height-2&&h.y+h.height<=1000);
   assert.equal(await frame.locator('#app').evaluate(el=>el.ownerDocument.documentElement.scrollWidth<=el.ownerDocument.defaultView!.innerWidth),true);geometry.push({width,name,nav:n,heading:h,header});
  }await page.screenshot({path:out+`/work-${width}.png`,fullPage:true});await page.screenshot({path:out+`/viewport-${width}.png`});
 }
 checks.push('21_real_existing_host_page_geometries_desktop_mobile');
 accept=false;await app.getByRole('button',{name:'返回工具详情',exact:true}).click();assert.equal(await app.getByRole('heading',{name:'财务表格公式检查',exact:true}).count(),1);
 accept=true;await app.getByRole('button',{name:'返回工具详情',exact:true}).click();await frame.getByRole('link',{name:'开始检查财务表格',exact:true}).waitFor();await frame.getByRole('link',{name:'开始检查财务表格',exact:true}).click();await app.getByRole('heading',{name:'开始一次复核',exact:true}).waitFor();checks.push('cancel_exit_preserves_confirm_dispose_reenter_empty');
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);checks.push('zero_cross_origin_requests_or_page_errors');
 await writeFile(out+'/result.json',JSON.stringify({passed:true,tool:'D05',version:'0.1.0',site_sha256:sha(await readFile('integration/native-site/site/index.html')),runtime_sha256:sha(await readFile(release+'/runtime.json')),checks,downloads,geometry,errors,requests,scope:'local original-site staging only',public_verified:false,accepted:false},null,2)+'\n');console.log(JSON.stringify({passed:true,checks:checks.length,downloads:Object.keys(downloads).length,geometry:geometry.length}));
}catch(e){await writeFile(out+'/failed.json',JSON.stringify({error:String(e),checks,downloads,geometry,errors,requests},null,2)+'\n');throw e}finally{await browser.close()}
