import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {headers,defaultRule,emptyState,parseTable,schedule} from '../tools/C03-待摊费用排程/src/engine';
const out=path.resolve('progress/evidence/C03/root-candidate-review');await mkdir(out,{recursive:true});
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const rows=Array.from({length:203},(_,i)=>['ROOT'+String(i+1).padStart(4,'0'),'完全虚构费用',i===202?'24':'12','2026-01-01','2026-12-31','CNY','元','0','2025-12','管理费用','待摊费用','完全虚构依据'+(i+1)]);
const fixture='\uFEFF'+[headers,...rows].map(a=>a.map(x=>'"'+x+'"').join(',')).join('\r\n');await writeFile(out+'/203-expenses.csv',fixture);
const table={file:'203-expenses.csv',sheet:'CSV',headers,rows:rows.map((a,i)=>({file:'203-expenses.csv',sheet:'CSV',row:i+2,cells:Object.fromEntries(headers.map((h,k)=>[h,a[k]]))}))};
const state={...emptyState(),items:parseTable(table,defaultRule)},lines=schedule(state);
// Independent expected: 203 * 12 monthly rows; 202 * 12 + 24 = 2448 total.
assert.equal(lines.length,2436);assert.equal(lines.filter(x=>x.id==='ROOT0203').length,12);
assert.ok(lines.filter(x=>x.id==='ROOT0203').every(x=>x.amount==='2.00'));
assert.equal(lines.find(x=>x.id==='ROOT0203'&&x.period==='2026-12')?.cumulative,'24.00');
const html=path.resolve('tools/C03-待摊费用排程/candidate/0.1.0/index.html');
const b=await chromium.launch({headless:true,executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const errors:string[]=[],requests:string[]=[];
try{
 const c=await b.newContext({offline:true,acceptDownloads:true,viewport:{width:1440,height:1000}});const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));p.on('request',q=>{if(/^https?:/.test(q.url()))requests.push(q.url())});
 await p.goto('file://'+html);const nav=(s:string)=>p.getByRole('navigation').getByRole('button',{name:new RegExp(s+'$')}).click();
 await nav('费用台账');await p.getByLabel('费用文件',{exact:true}).setInputFiles(out+'/203-expenses.csv');await p.getByRole('status').filter({hasText:'准备完成'}).waitFor();await p.getByRole('button',{name:'验证并导入',exact:true}).click();await p.getByRole('status').filter({hasText:'导入并校验通过'}).waitFor();
 assert.equal(await p.locator('tbody tr').count(),200);assert.equal(await p.getByRole('cell',{name:'ROOT0203',exact:true}).count(),0);assert.match(await p.locator('main').innerText(),/全部203行/);
 await p.screenshot({path:out+'/ledger-cap.png',fullPage:true});
 await nav('月度排程');assert.equal(await p.locator('tbody tr').count(),200);assert.match(await p.locator('main').innerText(),/全部2436行/);assert.equal(await p.getByRole('cell',{name:'ROOT0203',exact:true}).count(),0);await p.screenshot({path:out+'/schedule-cap.png',fullPage:true});
 await nav('来源追溯');assert.equal(await p.locator('tbody tr').count(),200);assert.equal(await p.getByRole('cell',{name:'ROOT0203',exact:true}).count(),0);
 await nav('方案与导出');const [d]=await Promise.all([p.waitForEvent('download'),p.getByRole('button',{name:'下载排程CSV',exact:true}).click()]);await d.saveAs(out+'/2436-schedule.csv');
 const csv=await readFile(out+'/2436-schedule.csv','utf8');assert.equal(csv.split('\r\n').length,2437);assert.match(csv,/"ROOT0203","2026-12","1","2.00","24.00","0.00"/);
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 await writeFile(out+'/result.json',JSON.stringify({diagnostic_passed:true,ready_for_formal_integration:false,expected:{items:203,schedule_rows:2436,last_item:'ROOT0203',last_source_row:204,last_month_amount:'2.00',last_total:'24.00',all_item_totals:'2448.00'},visible_ledger:200,visible_schedule:200,visible_source:200,findings:['All203 items and2436 schedule rows processed but every Grid shows first200 without pagination/search','Last ROOT0203 original source row204 and all its12 months are inaccessible in UI; CSV export remains complete'],html_sha256:sha(await readFile(html)),engine_sha256:sha(await readFile('tools/C03-待摊费用排程/src/engine.ts')),app_sha256:sha(await readFile('tools/C03-待摊费用排程/src/App.tsx')),test_sha256:sha(await readFile('tests/c03-root-candidate-review.ts')),fixture_sha256:sha(await readFile(out+'/203-expenses.csv')),errors,requests,scope:'Independent root expected schedule and actual offline candidate UI limitation reproduction; blocks formal integration'},null,2)+'\n');
 console.log('C03 root reproduction: all2436 months exported; first200 UI caps confirmed for203 items; formal integration blocked pending original-thread repair');
}finally{await b.close()}
