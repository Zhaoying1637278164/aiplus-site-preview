// Actual Streamlit website bootstrap. Financial processing starts only after offline.
import {type Browser,type Page} from 'playwright';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
export async function openK04Native(browser:Browser,out:string,dir:string,errors:string[],requests:string[],accept:()=>boolean){
 const context=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}});
 await context.addInitScript(()=>{(window as any).__writes=[];for(const k of ['setItem','removeItem','clear']){const old=(Storage.prototype as any)[k];(Storage.prototype as any)[k]=function(...args:any[]){(window as any).__writes.push(k);return old.apply(this,args)}}const old=IDBFactory.prototype.open;IDBFactory.prototype.open=function(...args:Parameters<IDBFactory['open']>){(window as any).__writes.push('IDB');return old.apply(this,args)}});
 const shell=await context.newPage(),programs:string[]=[];
 shell.on('pageerror',e=>errors.push(e.message));shell.on('dialog',d=>accept()?d.accept():d.dismiss());shell.on('request',r=>{if(r.url().endsWith('runtime.json'))programs.push(r.url())});
 const runtimeResponse=shell.waitForResponse(r=>r.url().endsWith('/K04/0.1.0/runtime.json'));
 await shell.goto((process.env.AIPLUS_NATIVE_SITE_URL||'http://127.0.0.1:8515').replace(/\/$/,'')+'/?tool=K04');
 const actualRuntime=await (await runtimeResponse).body(),sha=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
 const actualRuntimeSHA=sha(actualRuntime);assert.equal(actualRuntimeSHA,sha(await readFile(dir+'/runtime.json')));
 await shell.locator('iframe').first().waitFor();const doc=await shell.locator('iframe').first().getAttribute('srcdoc');assert(doc);
 const siteSHA=sha(await readFile('integration/native-site/site/index.html'));assert.equal(sha(doc.replace(/<script>window\.__AIPlusInitialRoute=[\s\S]*?<\/script>/,'')),siteSHA);await writeFile(out+'/actual-srcdoc.html',doc);
 const frame=await (await shell.locator('iframe').first().elementHandle())!.contentFrame();assert(frame);await frame.locator('.k04').waitFor();assert.equal(await frame.locator('iframe').count(),0);assert.equal(programs.length,1);assert.ok(programs[0].endsWith('/K04/0.1.0/runtime.json'));
 let loadingProgram=false;
 await context.setOffline(true);shell.on('request',r=>{if(/^https?:/.test(r.url())&&!(loadingProgram&&r.url().endsWith('/K04/0.1.0/runtime.json')))requests.push(r.url())});await frame.evaluate(()=>(window as any).__writes=[]);
 async function reenter(action:()=>Promise<unknown>){
  // A new website entry needs the public program bytes. User-file processing remains offline.
  loadingProgram=true;await context.setOffline(false);
  const response=shell.waitForResponse(r=>r.url().endsWith('/K04/0.1.0/runtime.json'));
  await action();assert.equal(sha(await (await response).body()),actualRuntimeSHA);
  await frame!.locator('.k04').waitFor();await context.setOffline(true);loadingProgram=false;
 }
 const page=new Proxy(shell,{get(target,key){if(key==='getByRole')return (role:any,options:any)=>role==='navigation'?frame.locator('.k04').getByRole(role,options):frame.getByRole(role,options);if(key==='locator')return (selector:string,options?:any)=>selector.startsWith('.k04')?frame.locator(selector,options):frame.locator('.k04').locator(selector,options);if(['getByLabel','getByText','evaluate'].includes(String(key)))return (frame as any)[key].bind(frame);const v=(target as any)[key];return typeof v==='function'?v.bind(target):v}}) as Page;
 return {context,shell,frame,page,siteSHA,actualRuntimeSHA,programs,reenter};
}
