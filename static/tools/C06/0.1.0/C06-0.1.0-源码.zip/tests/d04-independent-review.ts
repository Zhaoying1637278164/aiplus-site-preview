import test from 'node:test';
import assert from 'node:assert/strict';
import {extract,check} from '../tools/D04-PDF财务表格整理/src/engine';
import {emptyWork,defaultRule,type Work} from '../tools/D04-PDF财务表格整理/src/types';
import {encodePlan,decodePlan} from '../tools/D04-PDF财务表格整理/src/plan';
import {sheets} from '../tools/D04-PDF财务表格整理/src/export';
import {workbookBytes} from '../packages/core/io';
import ExcelJS from 'exceljs';

// Hand-owned expected input, separate from the PDF parser and sample generator.
function work():Work{
 const w=emptyWork();
 const rows=[['Item','Amount','Prior'],['Sales','1,200.10','0'],['Refund','(200.10)','-10'],['Missing','','5']];
 const continuation=[['Item','Amount','Prior'],['Other','0','5'],['Total','1,000.00','0']];
 w.document={file:'virtual-source.pdf',fingerprint:'a'.repeat(64),pages:[rows,continuation].map((data,i)=>({number:i+1,width:600,height:800,blocked:'',tokens:data.flatMap((r,y)=>r.map((text,x)=>({id:`p${i+1}r${y}c${x}`,text,x:40+x*170,y:40+y*30,width:100,height:12})))}))};
 w.areas=[1,2].map(page=>({id:`a${page}`,table:'本期财务表',page,x0:0,y0:0,x1:600,y1:800,cuts:[200,370],headerRows:1,rowTolerance:3}));
 w.rules={'本期财务表':{...defaultRule(),period:'2026-10',metadataConfirmed:true,amountColumns:[1,2],totalRow:5}};
 return w;
}
test('independent two-page source, empty amount blocks, known prior sum is zero',()=>{
 const w=work(),before=JSON.stringify(w),r=extract(w),c=check(w,r);
 assert.equal(r.rows.length,5);assert.equal(r.skipped.length,2);
 assert.deepEqual(r.rows.map(r=>[r.sequence,r.page,r.cells[0].raw]),[[1,1,'Sales'],[2,1,'Refund'],[3,1,'Missing'],[4,2,'Other'],[5,2,'Total']]);
 assert.deepEqual(r.rows[2].cells[1],{raw:'',tokens:['p1r3c1']});
 assert.equal(c.sums[0].status,'阻塞');assert.equal(c.sums[0].difference,null);
 assert.deepEqual(c.sums[1],{table:'本期财务表',column:3,sum:'0.00',total:'0.00',difference:'0.00',status:'通过'});
 assert.equal(c.ready,false);assert.equal(JSON.stringify(w),before);
});
test('explicit fictional correction preserves blank source and exact 1200.10-200.10=1000.00',()=>{
 const w=work(),rows=extract(w).rows;w.edits[rows[2].id+'c1']={value:'0',reason:'仅虚构验收资料人工明确为零'};
 w.confirmed=Object.fromEntries(rows.map(r=>[r.id,true]));const c=check(w);
 assert.deepEqual(c.sums[0],{table:'本期财务表',column:2,sum:'1000.00',total:'1000.00',difference:'0.00',status:'通过'});
 assert.equal(c.ready,true);assert.equal(extract(w).rows[2].cells[1].raw,'');
 w.rules['本期财务表'].period='unknown';assert.equal(check(w).ready,false);
});
test('actual XLSX retains all raw source cells, reasons, zero and negative strings',async()=>{
 const w=work(),r=extract(w).rows;w.edits[r[2].id+'c1']={value:'0',reason:'虚构来源核对'};
 const bytes=await workbookBytes(sheets(w)),b=new ExcelJS.Workbook();await b.xlsx.load(bytes as any);
 assert.deepEqual(b.worksheets.map(s=>s.name),['整理1','原始正文','分页表头','原文定位','异常与勾稽','参数版本']);
 assert.equal(b.getWorksheet('原始正文')!.rowCount,16);assert.equal(b.getWorksheet('分页表头')!.rowCount,7);
 assert.equal(b.getWorksheet('原文定位')!.rowCount,22);
 const raw=b.getWorksheet('原始正文')!;assert.equal(raw.getRow(9).getCell(7).text,'');assert.equal(raw.getRow(9).getCell(8).text,'0');assert.equal(raw.getRow(9).getCell(10).text,'虚构来源核对');
 assert.equal(b.getWorksheet('整理1')!.getRow(3).getCell(5).text,'(200.10)');
 for(const s of b.worksheets)s.eachRow(r=>r.eachCell(c=>assert.notEqual(c.type,ExcelJS.ValueType.Formula)));
});
test('no-data restore clears imported text and confirmations; wrong schema is refused',()=>{
 const w=work(),r=extract(w).rows;w.confirmed[r[0].id]=true;
 const plan=JSON.parse(encodePlan(w,false));assert.equal(plan.schema_version,1);assert.equal(plan.contains_data,false);
 const restored=decodePlan(JSON.stringify(plan));assert.equal(restored.document,null);assert.deepEqual(restored.confirmed,{});assert.equal(restored.rules['本期财务表'].metadataConfirmed,false);
 plan.schema_version=2;assert.throws(()=>decodePlan(JSON.stringify(plan)),/版本/);
});
