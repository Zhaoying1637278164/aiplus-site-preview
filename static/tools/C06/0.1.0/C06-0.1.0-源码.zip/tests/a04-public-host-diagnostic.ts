// Read-only public host diagnostic. No user files, no fictitious business work.
import {chromium} from 'playwright';
import {mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
const out=path.resolve(process.env.AIPLUS_HOST_DIAGNOSTIC_OUT||'progress/evidence/A04/0.1.1/site-public/host-diagnostic');
await mkdir(out,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const context=await browser.newContext(),page=await context.newPage();
const host='https://aiplus-guance.streamlit.app',requests:any[]=[],frames:string[]=[],initiators:any[]=[];
const cdp=await context.newCDPSession(page);
await cdp.send('Network.enable');
cdp.on('Network.requestWillBeSent',(event:any)=>{const u=new URL(event.request.url);if(/^https?:/.test(u.protocol)&&u.origin!==host)initiators.push({origin:u.origin,path:u.pathname,method:event.request.method,type:event.type,initiator_type:event.initiator?.type,initiator_url:event.initiator?.url,stack:event.initiator?.stack?.callFrames?.slice(0,6).map((f:any)=>({url:f.url,line:f.lineNumber,functionName:f.functionName}))??[]})});
// Prevent all external transmissions while examining host startup. Never treat
// these aborted attempts as a product privacy pass.
await context.route('**/*',async route=>{const u=new URL(route.request().url());if(/^https?:/.test(u.protocol)&&u.origin!==host)await route.abort('blockedbyclient');else await route.continue()});
page.on('request',r=>{const u=new URL(r.url());if(/^https?:/.test(u.protocol)&&u.origin!==host){let keys:string[]=[],event='';try{const body=r.postDataJSON();keys=Object.keys(body??{});event=typeof body?.event==='string'?body.event:''}catch{}requests.push({origin:u.origin,method:r.method(),payload_keys:keys,event,resource_type:r.resourceType()})}});
page.on('websocket',ws=>ws.on('framereceived',async data=>{if(Buffer.isBuffer(data.payload)){const name=out+'/'+frames.length+'.protobuf';frames.push(name);await writeFile(name,data.payload)}}));
try{await page.goto(host+'/~/+/?tool=A04');await page.frameLocator('iframe').first().locator('.a04').waitFor();await page.waitForTimeout(2500);await writeFile(out+'/result.json',JSON.stringify({source:'actual public host startup; outbound cross-origin blocked by diagnostic only',business_files_loaded:false,requests,external_request_initiators:initiators,websocket_frames:frames,product_acceptance:false},null,2)+'\n');console.log('Public host diagnostic: '+frames.length+' server frames; '+requests.length+' blocked external startup attempts')}finally{await browser.close()}
