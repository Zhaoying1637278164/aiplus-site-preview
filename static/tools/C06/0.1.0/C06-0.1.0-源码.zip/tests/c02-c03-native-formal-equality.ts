import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import ExcelJS from 'exceljs';

const sha = (b:Buffer) => createHash('sha256').update(b).digest('hex');
async function matrix(file:string) {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(await readFile(file) as any);
  return workbook.worksheets.map(sheet => {
    const rows:unknown[][]=[];
    sheet.eachRow({includeEmpty:true}, row => {
      const values:unknown[]=[];
      for(let i=1;i<=sheet.columnCount;i++) {
        assert.notEqual(row.getCell(i).type, ExcelJS.ValueType.Formula);
        values.push(row.getCell(i).value);
      }
      rows.push(values);
    });
    return {name:sheet.name, rows};
  });
}
const siteSHA=sha(await readFile('integration/native-site/site/index.html'));
for(const id of ['C02','C03']) {
  const base=`progress/evidence/${id}/0.1.0/`;
  const siteBook=base+(id==='C02'?'site-workbook/602-workbook.xlsx':'site-local/downloads/full-workbook.xlsx');
  const formalBook=base+(id==='C02'?'root-formal-offline/root-workbook/602-workbook.xlsx':'root-formal-offline/root-browser/downloads/full-workbook.xlsx');
  const siteJSON=base+`site-local/downloads/${id==='C02'?'602-evidence':'full-work'}.json`;
  const formalJSON=base+`root-formal-offline/root-browser/downloads/${id==='C02'?'602-evidence':'full-work'}.json`;
  const actual=await matrix(siteBook), expected=await matrix(formalBook);
  assert.equal(actual.length,id==='C02'?13:8);
  assert.deepEqual(actual,expected);
  assert.deepEqual(JSON.parse(await readFile(siteJSON,'utf8')),JSON.parse(await readFile(formalJSON,'utf8')));
  const proof={passed:true,tool:id,site_sha256:siteSHA,worksheets:actual.length,
    all_sheets_all_cells_identical:true,entire_evidence_json_identical:true,
    files:Object.fromEntries(await Promise.all([siteBook,formalBook,siteJSON,formalJSON].map(async f=>[f,sha(await readFile(f))]))),
    script_sha256:sha(await readFile('tests/c02-c03-native-formal-equality.ts')),
    public_verified:false,accepted:false};
  await writeFile(base+'site-local/exact-formal-equality.json',JSON.stringify(proof,null,2)+'\n');
  console.log(id,actual.length,'sheets every cell and entire JSON equal formal offline');
}
