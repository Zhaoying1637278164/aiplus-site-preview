process.env.C01_CANDIDATE='progress/evidence/C01/0.1.0/root-formal-offline/extracted/C01';
process.env.C01_BROWSER_OUT='progress/evidence/C01/0.1.0/root-formal-offline/browser';
await import('../tools/C01-月结工作台/tests/browser');
export {};
