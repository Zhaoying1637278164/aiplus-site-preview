// Final archive-only verification on the original financial website.
// Financial workflow evidence is separate and remains bound to unchanged HTML/runtime/site.
import {chromium} from 'playwright';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import assert from 'node:assert/strict';
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const suite=process.env.AIPLUS_EVIDENCE_DIR||'progress/evidence/A02/0.1.0';
const registry=JSON.parse(await readFile('integration/native-site/site/registry.json','utf8'));
const host=process.env.AIPLUS_NATIVE_SITE_URL||'http://127.0.0.1:8515';
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
try{for(const id of (process.argv[2]?[process.argv[2]]:['A02'])){
 const entry=registry.find((e:any)=>e.id===id);assert.ok(entry&&['A02'].includes(id));
 const release=path.resolve('release/'+id+'/0.1.0'),out=path.resolve(suite+'/'+id+'/downloads');await mkdir(out+'/site-local-downloads',{recursive:true});
 const context=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}}),page=await context.newPage(),programs:string[]=[],errors:string[]=[];
 page.on('request',r=>{if(r.url().endsWith('runtime.json'))programs.push(r.url())});page.on('pageerror',e=>errors.push(e.message));
 await page.goto(host);const frame=page.frameLocator('iframe').first();
 const total=76+registry.filter((e:any)=>!e.replacesOriginal).length;assert.equal(await frame.locator('.bignum').innerText(),String(total));
 await frame.locator('.nav a[href="#tools"]').click();await frame.locator('[data-f="mod"][data-v="'+'asset'+'"]').click();assert.equal(await frame.locator('[data-total]').innerText(),'5');
 const row=frame.locator('[data-tool]').filter({has:frame.getByRole('link',{name:entry.name,exact:true})});assert.equal(await row.count(),1);await row.getByRole('link',{name:'详情',exact:true}).click();
 await frame.getByRole('heading',{name:entry.name,exact:true}).waitFor();assert.equal(await frame.locator('template#r-'+entry.detailRoute).count(),1);assert.equal(await frame.getByText('工具信息',{exact:true}).count(),1);
 const links=frame.locator('[data-program-download]');const clicks=await links.count();assert.ok(clicks>=9);const downloads:Record<string,string>={};
 for(let i=0;i<clicks;i++){
  const link=links.nth(i),filename=await link.getAttribute('download');assert.ok(filename&&!filename.includes('/')&&!filename.includes('..'));
  const pending=page.waitForEvent('download');await link.click();const file=await pending;assert.equal(await file.failure(),null);const target=out+'/site-local-downloads/'+filename;await file.saveAs(target);downloads[filename]=sha(await readFile(target));assert.equal(downloads[filename],sha(await readFile(release+'/'+filename)));
 }
 execFileSync('python3',['-c','import sys,zipfile,hashlib,pathlib; p=pathlib.Path(sys.argv[1]); t=sys.argv[2]; z=zipfile.ZipFile(p/(t+"-0.1.0-离线包.zip")); r=pathlib.Path(sys.argv[3]); expected={f.name for f in r.iterdir() if f.is_file() and f.suffix!=".zip"}; assert set(z.namelist())=={t+"/"+n for n in expected}; [None if z.read(t+"/"+n)==(r/n).read_bytes() else (_ for _ in ()).throw(AssertionError(n)) for n in expected]',out+'/site-local-downloads',id,release]);
 assert.deepEqual(programs,[]);assert.deepEqual(errors,[]);await page.screenshot({path:out+'/site-detail-local.png',fullPage:true});
 await writeFile(out+'/result.json',JSON.stringify({tool:id,version:'0.1.0',html_sha256:sha(await readFile(release+'/index.html')),runtime_sha256:sha(await readFile(release+'/runtime.json')),site_sha256:sha(await readFile('integration/native-site/site/index.html')),test_sha256:sha(await readFile('tests/a01-native-downloads.ts')),downloads,clicks,errors,checks:['original_financial_module_and_detail','all_actual_first_party_version_downloads_exact_hash','offline_zip_inner_html_same','detail_does_not_load_program'],scope:'actual original financial website with 27 registered programs; final archives; public separately verified',passed:true},null,2));
 await context.close();console.log(id,clicks,'download clicks;',Object.keys(downloads).length,'unique exact files');
}}finally{await browser.close()}
