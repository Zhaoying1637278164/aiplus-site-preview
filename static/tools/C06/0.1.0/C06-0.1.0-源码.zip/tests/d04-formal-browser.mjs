// Root replay of the owner suite against exact formal release bytes. Not public website evidence.
import {chromium} from 'playwright';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dir=path.join(root,'progress/evidence/D04/0.1.0/root-formal-offline/browser');await mkdir(dir,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'}),context=await browser.newContext({offline:true,viewport:{width:1440,height:1000},acceptDownloads:true});const page=await context.newPage(),requests=[],errors=[];page.setDefaultTimeout(15000);page.on('request',r=>{if(!r.url().startsWith('file:'))requests.push(r.url());});page.on('pageerror',e=>errors.push(e.message));
const log=[];async function step(name,fn){await fn();log.push(name);console.log('PASS',name);}
const nav=async n=>page.getByRole('navigation').getByRole('button',{name:n}).click();
try{
await page.goto(pathToFileURL((process.env.AIPLUS_D04_OFFLINE_INDEX||path.join(root,'release/D04/0.1.0/index.html'))).href);
await step('file offline self contained loaded',async()=>{await page.getByRole('heading',{name:'PDF财务表格整理',exact:true}).waitFor();});
await step('real fictitious PDF import local input',async()=>{await page.getByLabel('导入本地PDF',{exact:true}).setInputFiles(path.join(root,'tools/D04-PDF财务表格整理/examples/完全虚构财务表.pdf'));await page.getByText('文本可读，等待选表').first().waitFor();assert.equal(await page.locator('tbody tr').count(),2);});
await page.screenshot({path:path.join(dir,'01-资料.png'),fullPage:true});
await nav('2. 选表与列界');
await step('explicit region on page 1 and continuation page 2',async()=>{await page.getByRole('button',{name:'添加本页区域'}).click();await page.getByLabel('PDF页',{exact:true}).selectOption('2');await page.getByRole('button',{name:'添加本页区域'}).click();assert.match(await page.locator('.summary').innerText(),/5 正文行/);});
await page.screenshot({path:path.join(dir,'02-范围.png'),fullPage:true});
await nav('3. 分页表头');await page.screenshot({path:path.join(dir,'03-表头.png'),fullPage:true});
await step('continuation header retained separately',async()=>{assert.match(await page.locator('main').innerText(),/已单列表头 2 行/);assert.match(await page.locator('main').innerText(),/当前未发现结构异常/);});
await nav('4. 校正复核');await page.screenshot({path:path.join(dir,'04-校正前.png'),fullPage:true});
await step('independent expected raw values 5 rows, blanks zero negative',async()=>{const rows=page.locator('tbody tr');assert.equal(await rows.count(),5);assert.match(await rows.nth(0).innerText(),/Sales.*1,200.10/s);assert.match(await rows.nth(1).innerText(),/\(200.10\).*?-10/s);assert.match(await rows.nth(2).innerText(),/\[空\]/);assert.match(await rows.nth(3).innerText(),/Other.*0/s);});
await nav('5. 金额勾稽');
await page.getByLabel('财务表1期间',{exact:true}).fill('2026-10');await page.getByLabel('财务表1金额列号',{exact:true}).fill('2,3');await page.getByLabel('财务表1总计行',{exact:true}).fill('5');await page.getByLabel('已对原文件确认币种、期间、单位一致').check();
await step('missing amount blocks and independent prior exact sum',async()=>{assert.match(await page.locator('main').innerText(),/行3 列2 金额缺失/);assert.match(await page.locator('tbody tr').nth(1).innerText(),/0.00.*0.00.*0.00.*通过/s);});
await page.screenshot({path:path.join(dir,'05-金额阻塞.png'),fullPage:true});
await nav('4. 校正复核');
await step('explicit correction preserves reason and original blank',async()=>{let i=0;page.on('dialog',async d=>{await d.accept(i++===0?'0':'完全虚构样例：人工确认本行是零');});await page.locator('tbody tr').nth(2).locator('.cells button').nth(1).click();assert.match(await page.locator('tbody tr').nth(2).innerText(),/原 \[空\].*0.*人工确认/s);});
for(let n=0;n<5;n++)await page.getByRole('button',{name:'确认本行',exact:true}).first().click();
await nav('5. 金额勾稽');await step('independent 1200.10 - 200.10 + 0 + 0 = 1000.00',async()=>{assert.match(await page.locator('tbody tr').nth(0).innerText(),/1,?000.00.*1,?000.00.*0.00.*通过/s);assert.equal(await page.locator('main').getByText(/金额缺失/).count(),0);});await page.screenshot({path:path.join(dir,'05-金额通过.png'),fullPage:true});
await nav('6. 导出与恢复');await page.screenshot({path:path.join(dir,'06-导出.png'),fullPage:true});
await step('actual downloads full XLSX CSV official and data plan',async()=>{for(const name of ['下载完整复核底稿 XLSX','下载原始与校正全量 CSV','下载已复核整理表','下载方案 JSON']){const pending=page.waitForEvent('download');await page.getByRole('button',{name,exact:true}).click();const d=await pending;await d.saveAs(path.join(dir,d.suggestedFilename()));}});
await step('clear and restore downloaded plan recalculates and restores review',async()=>{await page.getByRole('button',{name:'退出并清空'}).click();await page.getByText('尚未导入PDF').waitFor();await nav('6. 导出与恢复');await page.getByLabel('恢复方案',{exact:true}).setInputFiles(path.join(dir,'D04-含数据工作.json'));await page.getByText('已恢复含文本工作',{exact:false}).waitFor();assert.match(await page.locator('.summary').innerText(),/已确认 5 \/ 5/);await nav('5. 金额勾稽');assert.match(await page.locator('tbody tr').nth(0).innerText(),/1000.00.*1000.00.*0.00.*通过/s);});
await step('page and coordinate trace points back to corrected row',async()=>{await nav('4. 校正复核');await page.locator('tbody tr').nth(2).getByRole('button',{name:'定位原文'}).click();assert.equal(await page.getByLabel('PDF页',{exact:true}).inputValue(),'1');assert.ok(await page.locator('svg rect[fill="#ffdb79"]').count()>0);});await page.screenshot({path:path.join(dir,'02-原文定位.png'),fullPage:true});
await step('data replacement clears areas corrections and confirmations',async()=>{await nav('1. 资料与页码');await page.getByRole('button',{name:'载入虚构PDF'}).click();await page.getByText('文本可读，等待选表').first().waitFor();assert.match(await page.locator('.summary').innerText(),/0 区域 · 0 正文行/);});
await step('real scan PDF blocks without fabricated table',async()=>{await page.getByLabel('导入本地PDF',{exact:true}).setInputFiles(path.join(root,'tools/D04-PDF财务表格整理/examples/虚构扫描无文字.pdf'));await page.getByRole('alert').filter({hasText:'OCR未实现'}).waitFor();assert.match(await page.locator('.summary').innerText(),/0 正文行/);});await page.screenshot({path:path.join(dir,'07-扫描阻塞.png'),fullPage:true});
await step('no external network requests or page errors',async()=>{assert.deepEqual(requests,[]);assert.deepEqual(errors,[]);});
await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(dir,'08-手机资料.png'),fullPage:true});
await writeFile(path.join(dir,'result.json'),JSON.stringify({status:'passed',offline:true,url:page.url(),platform:process.platform,checks:log,requests,errors},null,2));
}catch(e){await page.screenshot({path:path.join(dir,'failure.png'),fullPage:true});await writeFile(path.join(dir,'failure.json'),JSON.stringify({checks:log,error:String(e),requests,errors},null,2));throw e;}finally{await browser.close();}
