import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {calculate} from '../tools/C02-计提与冲回/src/engine';
import {makeTable} from '../tools/C02-计提与冲回/src/example';

const out=path.resolve('progress/evidence/C02/root-candidate-review');
await mkdir(out,{recursive:true});
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const data={
 expenses:makeTable('expenses',Array.from({length:602},(_,i)=>[
  'ROOT'+String(i+1).padStart(4,'0'),'完全虚构部门','2026-01',i===601?'41.25':'1.25',
  'CNY','元','ROOT-AUTO','完全虚构依据'+(i+1),'计提']), '根独立虚构费用.csv'),
 rules:makeTable('rules',[['ROOT-AUTO','虚构v1','2026-01','2026-12','1','次期全额','6602','2241','1','1','CNY','元','完全虚构规则']]),
 reversals:null,changes:null,
};
// Independent expected values: 601 * 1.25 + 41.25 = 792.50;
// each expense produces two events/four entries and closes to zero next month.
const expected={items:602,events:1204,entries:2408,accrual:'792.50',reversal:'792.50',balance:'0.00',debit:'1585.00',credit:'1585.00'};
const r=calculate(data);assert.equal(r.canConfirm,true);
assert.equal(r.events.length,expected.events);assert.equal(r.entries.length,expected.entries);
for(const k of ['accrual','reversal','balance','debit','credit'] as const)assert.equal(r.totals[0][k],expected[k]);
assert.equal(r.events.find(e=>e.item==='ROOT0602'&&e.type==='计提')?.amount,'41.25');
const raw=JSON.stringify({schema_version:1,tool:'C02',app_version:'0.1.0',rule_version:'C02-20261004.1',contains_data:true,work:{data,tolerance:'0.00',history:[]}});
await writeFile(out+'/602-work.json',raw);
const html=path.resolve('progress/evidence/C02/candidate/0.1.0/index.html');
const browser=await chromium.launch({headless:true,executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const errors:string[]=[],requests:string[]=[];
try{
 const ctx=await browser.newContext({offline:true,acceptDownloads:true,viewport:{width:1440,height:1000}});
 const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));p.on('request',q=>{if(/^https?:/.test(q.url()))requests.push(q.url())});
 await p.goto('file://'+html);
 const nav=(s:string)=>p.getByRole('navigation').getByRole('button',{name:new RegExp(s+'$')}).click();
 await nav('底稿与恢复');await p.getByLabel('恢复方案或工作').setInputFiles(out+'/602-work.json');
 await p.getByRole('status').filter({hasText:'已恢复含数据工作'}).waitFor();
 await nav('费用依据');const editor=p.getByRole('region',{name:'费用依据编辑',exact:true});
 const inputRows=await editor.locator('tbody tr').count();const tailInput=await editor.getByRole('textbox',{name:'费用依据第602行金额',exact:true}).count();
 assert.equal(inputRows,200);assert.equal(tailInput,0);
 assert.match(await editor.innerText(),/只编辑前200行/);
 await p.screenshot({path:out+'/expense-cap.png',fullPage:true});
 await nav('计划与余额');const grid=p.getByRole('region',{name:'计划事件',exact:true});
 const visibleEvents=await grid.locator('tbody tr').count();assert.equal(visibleEvents,500);
 assert.match(await grid.innerText(),/1204行/);assert.match(await grid.innerText(),/页面显示前500行/);
 assert.equal(await grid.getByRole('cell',{name:'ROOT0602',exact:true}).count(),0);
 await p.screenshot({path:out+'/event-cap.png',fullPage:true});
 await nav('分录核对');const entries=p.getByRole('region',{name:'分录底稿',exact:true});
 assert.equal(await entries.locator('tbody tr').count(),500);assert.match(await entries.innerText(),/2408行/);
 await nav('底稿与恢复');const [download]=await Promise.all([p.waitForEvent('download'),p.getByRole('button',{name:'下载计算证据（含数据）'}).click()]);
 await download.saveAs(out+'/602-evidence.json');const exported=JSON.parse(await readFile(out+'/602-evidence.json','utf8'));
 assert.equal(exported.result.events.length,1204);assert.equal(exported.result.entries.length,2408);
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 await writeFile(out+'/result.json',JSON.stringify({diagnostic_passed:true,ready_for_formal_integration:false,expected,inputRows,tailInput,visibleEvents,visibleEntries:500,findings:['602 expense rows imported but only first 200 can be viewed/edited; no tail input','1204 events and 2408 entries exported correctly but grids silently limit navigable records to first 500','Original source is text only; no direct source-row navigation'],html_sha256:sha(await readFile(html)),engine_sha256:sha(await readFile('tools/C02-计提与冲回/src/engine.ts')),app_sha256:sha(await readFile('tools/C02-计提与冲回/src/App.tsx')),test_sha256:sha(await readFile('tests/c02-root-candidate-review.ts')),fixture_sha256:sha(await readFile(out+'/602-work.json')),errors,requests,scope:'Root independent engine totals and actual offline candidate UI limitation reproduction; findings block integration, not acceptance'},null,2)+'\n');
 console.log('C02 root reproduction: correct 602-item totals; first200/500 UI caps confirmed; formal integration blocked pending original-thread repair');
}finally{await browser.close()}
