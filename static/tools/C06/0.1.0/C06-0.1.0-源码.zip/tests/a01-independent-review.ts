// Root fixtures and literal answers calculated before calling the candidate.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import ExcelJS from 'exceljs';
import {calculate,confirmHistory,type Data,type Settings} from '../tools/A01-折旧摊销排程表/src/engine';
import {exportWorkbook} from '../tools/A01-折旧摊销排程表/src/export';
import type {Table} from '../packages/core/types';
const out=process.env.A01_ROOT_OUT||'progress/evidence/A01/root-independent';await mkdir(out,{recursive:true});
const headers=['资产ID','资产名称','主体','类型','类别','币种','单位','可供使用日','开始月','原值','期初累计折摊','期初减值','残值','剩余月','方法','剩余工作量','残值依据','政策依据'];
const asset:Record<string,string>={'资产ID':'ROOT-FA','资产名称':'虚构根验收设备','主体':'虚构根验收公司','类型':'固定资产','类别':'设备','币种':'CNY','单位':'元','可供使用日':'2025-12-15','开始月':'2026-01','原值':'2700','期初累计折摊':'0','期初减值':'0','残值':'270','剩余月':'24','方法':'直线法','剩余工作量':'','残值依据':'','政策依据':'虚构已批准会计政策，独立测试'};
const settings:Settings={entity:'虚构根验收公司',currency:'CNY',unit:'元',from:'2026-01',to:'2027-12',precision:2,tolerance:'0.01',policyConfirmed:true,basis:'会计'};
function table(h:string[],rows:Record<string,string>[],sheet:string,start=7):Table{return {file:'虚构根验收资产.xlsx',sheet,headers:h,rows:rows.map((cells,i)=>({file:'虚构根验收资产.xlsx',sheet,row:start+i,cells}))}}
function input(over:Record<string,string>={}):Data{return {assets:table(headers,[{...asset,...over}],'assets'),events:null,usage:null,ledger:null}}
function valid(d:Data,s=settings){const r=calculate(d,s);assert.deepEqual(r.issues.filter(i=>i.level==='阻塞'),[]);assert.ok(r.lines.every(l=>l.check==='0.00'));return r}
const checks:string[]=[];
const base=input(),straight=valid(base);
// (2700-270)/24=101.25; 24*101.25=2430; final270.
assert.equal(straight.lines.length,24);assert.ok(straight.lines.every(l=>l.expense==='101.25'));
assert.equal(straight.lines.at(-1)!.accumulated,'2430.00');assert.equal(straight.lines.at(-1)!.closing,'270.00');
assert.equal(straight.lines[0].source,'虚构根验收资产.xlsx / assets / 第7行');
checks.push('new manual2700/residual270/24 months:101.25 each,2430 accumulated,270 final and original row7');
function disposal(kind:string){const d=input(kind==='无形资产'?{类型:kind,类别:'软件',可供使用日:'2026-01-15',原值:'2430',残值:'0'}:{});d.events=table(['事件ID','资产ID','生效月','事件类型','金额','新剩余月','新残值','新方法','批准人','依据'],[{'事件ID':'ROOT-E','资产ID':'ROOT-FA','生效月':'2026-04','事件类型':'处置','金额':'0','新剩余月':'','新残值':'','新方法':'','批准人':'虚构复核人','依据':'虚构整项处置批准'}],'events',13);return valid(d)}
const fixed=disposal('固定资产'),intangible=disposal('无形资产');
assert.equal(fixed.lines[3].expense,'101.25');assert.equal(fixed.lines[3].disposal,'2295.00');
assert.equal(intangible.lines[3].expense,'0.00');assert.equal(intangible.lines[3].disposal,'2126.25');
assert.ok([...fixed.lines.slice(3),...intangible.lines.slice(3)].every(l=>l.closing==='0.00'));
checks.push('new fixed disposal April:2700-4*101.25=2295; intangible2430-3*101.25=2126.25; all later zero');
const tiny=valid(input({原值:'1',残值:'0',剩余月:'6'}),{...settings,to:'2026-06'});
assert.deepEqual(tiny.lines.map(l=>l.expense),['0.17','0.17','0.17','0.17','0.17','0.15']);assert.equal(tiny.lines.at(-1)!.closing,'0.00');
checks.push('manual1/6 rounding:five0.17 then0.15; finalzero; no tolerance adjustment');
const accelerated=valid(input({原值:'54000',残值:'0',剩余月:'36',方法:'年数总和法'}),{...settings,to:'2028-12'});
assert.deepEqual([0,12,24].map(i=>accelerated.lines[i].expense),['2250.00','1500.00','750.00']);assert.equal(accelerated.lines.at(-1)!.closing,'0.00');
const double=valid(input({原值:'150000',残值:'0',剩余月:'60',方法:'双倍余额递减法'}),{...settings,to:'2030-12'});
assert.deepEqual([0,12,24,36,48].map(i=>double.lines[i].expense),['5000.00','3000.00','1800.00','1350.00','1350.00']);assert.equal(double.lines.at(-1)!.closing,'0.00');
checks.push('manualSYD54000 three yearly27000/18000/9000; DDB150000 yearly60000/36000/21600/16200/16200');
const usage=input({原值:'2800',残值:'0',剩余月:'3',方法:'工作量法',剩余工作量:'7'});usage.usage=table(['资产ID','期间','工作量'],['2','0','5'].map((q,i)=>({'资产ID':'ROOT-FA','期间':'2026-0'+(i+1),'工作量':q})),'usage',19);
assert.deepEqual(valid(usage,{...settings,to:'2026-03'}).lines.map(l=>l.expense),['800.00','0.00','2000.00']);
usage.usage.rows.splice(1,1);assert.ok(calculate(usage,{...settings,to:'2026-03'}).issues.some(i=>i.level==='阻塞'));
checks.push('manual2800/7 quantities2/0/5 =>800/0/2000; missing zero-month record blocks');
const invalid:Record<string,string>[]=[{原值:''},{原值:'-1'},{币种:'USD'},{单位:'万元'}];
for(const over of invalid)assert.ok(calculate(input(over),settings).issues.some(i=>i.level==='阻塞'));
const duplicate=input();duplicate.assets!.rows.push(structuredClone(duplicate.assets!.rows[0]));assert.ok(calculate(duplicate,settings).issues.some(i=>i.level==='阻塞'));
assert.equal(calculate(base,{...settings,basis:'税法'}).lines.length,0);
const history=confirmHistory(straight,'2026-02','虚构根复核','虚构历史确认',null);
assert.ok(calculate(input({原值:'2800'}),settings,history).issues.some(i=>i.level==='阻塞'));
assert.equal(calculate(base,settings,history).lines[0].expense,'101.25');
checks.push('null/negative/currency/unit/duplicate and tax basis blocked; history change blocked; unchanged history retained');
// Separate root literal future-event cases: first2 months202.50, Marchopening2497.50.
for(const [kind,expectedExpense,expectedClosing] of [['追加','111.25','2606.25'],['减值','91.25','2186.25']] as const){
 const d=input();d.events=table(['事件ID','资产ID','生效月','事件类型','金额','新剩余月','新残值','新方法','批准人','依据'],[{'事件ID':'ROOT-FUTURE','资产ID':'ROOT-FA','生效月':'2026-03','事件类型':kind,'金额':'220','新剩余月':'','新残值':'','新方法':'','批准人':'虚构批准人','依据':'虚构未来事件批准'}],'events',23);
 const r=valid(d);assert.equal(r.lines[2].expense,expectedExpense);assert.equal(r.lines[2].closing,expectedClosing);assert.equal(r.lines.at(-1)!.closing,'270.00');assert.equal(r.lines[1].expense,'101.25');assert.match(r.lines[2].event,/第23行/);assert.deepEqual(calculate(d,settings,history).issues.filter(x=>x.level==='阻塞'),[]);
 checks.push('manual future'+kind+':Marchopening2497.50,220event,expense'+expectedExpense+',closing'+expectedClosing+',final270; confirmed JanFeb unchanged');
}
const changed=input();changed.events=table(['事件ID','资产ID','生效月','事件类型','金额','新剩余月','新残值','新方法','批准人','依据'],[{'事件ID':'ROOT-CHANGE','资产ID':'ROOT-FA','生效月':'2026-03','事件类型':'变更','金额':'0','新剩余月':'10','新残值':'497.5','新方法':'直线法','批准人':'虚构批准人','依据':'虚构剩余寿命新依据'}],'events',29);
const changedResult=valid(changed);assert.equal(changedResult.lines[2].expense,'200.00');assert.equal(changedResult.lines[2].closing,'2297.50');assert.equal(changedResult.lines[11].closing,'497.50');assert.equal(changedResult.lines[12].expense,'0.00');assert.deepEqual(calculate(changed,settings,history).issues.filter(x=>x.level==='阻塞'),[]);
checks.push('manual future estimate:(2497.50-497.50)/10=200,December497.50,nextJanuaryzero,confirmed JanFeb intact');
const bytes=await exportWorkbook(base,settings,history,straight);await writeFile(out+'/root-independent.xlsx',bytes);
const wb=new ExcelJS.Workbook();await wb.xlsx.readFile(out+'/root-independent.xlsx');assert.equal(wb.worksheets.length,11);
const ws=wb.getWorksheet('逐期排程')!,names=ws.getRow(1).values as unknown[];
const cell=(row:number,key:string)=>String(ws.getRow(row).getCell(names.indexOf(key)).value);
assert.equal(cell(2,'expense'),'101.25');assert.equal(cell(2,'closing'),'2598.75');assert.equal(cell(25,'accumulated'),'2430.00');assert.equal(cell(25,'closing'),'270.00');assert.equal(cell(2,'source'),'虚构根验收资产.xlsx / assets / 第7行');
const raw=wb.getWorksheet('资产原始资料')!;assert.equal(String(raw.getRow(2).getCell(3).value),'7');
checks.push('actual11-sheet XLSX directly reread by ExcelJS:four literal financial cells plus raw source row and full source path');
const sha=async(p:string)=>createHash('sha256').update(await readFile(p)).digest('hex');
await writeFile(out+'/result.json',JSON.stringify({tool:'A01',passed:true,checks,independent_expected_origin:'Root new fictitious cases; literal hand arithmetic; no example or owner test imports',engine_sha256:await sha('tools/A01-折旧摊销排程表/src/engine.ts'),script_sha256:await sha('tests/a01-independent-review.ts'),workbook_sha256:await sha(out+'/root-independent.xlsx'),scope:'Candidate financial and workbook independent QA only; formal packaging/offline/website/source root verification outstanding',accepted:false},null,2)+'\n');
console.log(JSON.stringify({passed:true,groups:checks.length,sheets:11}));
