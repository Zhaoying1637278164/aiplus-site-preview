import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import ExcelJS from 'exceljs';
import JSZip from 'jszip';

const host=process.env.AIPLUS_NATIVE_SITE_URL||'http://127.0.0.1:8514';
const origin=new URL(host).origin,release=path.resolve('release/D01/0.1.0');
const out=path.resolve('progress/evidence/D01/0.1.0/site-local-with-C01');
await mkdir(out+'/downloads',{recursive:true});
const sha=(data:Buffer)=>createHash('sha256').update(data).digest('hex');
const browser=await chromium.launch({headless:true,executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const errors:string[]=[],requests:string[]=[],downloads:Record<string,string>={};
try{
 const context=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}});
 await context.route('**/*',async route=>{const url=new URL(route.request().url());if(/^https?:/.test(url.protocol)&&url.origin!==origin){requests.push(url.origin);await route.abort('blockedbyclient')}else await route.continue()});
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await page.goto(host,{waitUntil:'domcontentloaded'});
 const frame=page.frameLocator('iframe').first();
 await frame.locator('.nav a[href="#tools"]').click();
 await frame.locator('[data-f="mod"][data-v="meta"]').click();
 assert.equal(await frame.locator('[data-total]').innerText(),'9');
 const row=frame.locator('[data-tool]').filter({has:frame.getByRole('link',{name:'财务台账合并拆分',exact:true})});
 assert.equal(await row.count(),1);
 await row.getByRole('link',{name:'详情',exact:true}).click();
 await frame.getByRole('heading',{name:'财务台账合并拆分',exact:true}).waitFor();
 assert.match(await frame.locator('#app').innerText(),/字段对应、清理规则、合并预览、分拆下载、来源追查、方案管理/);
 assert.equal(await frame.getByRole('link',{name:'开始整理财务台账',exact:true}).count(),1);
 assert.equal((await page.locator('iframe').count()),1);
 await page.screenshot({path:out+'/detail.png',fullPage:true});
 const names=['D01-0.1.0-离线包.zip','D01-0.1.0-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md','参考来源.md','虚构乙台账.xlsx'];
 const labels=['下载离线包','下载源码','虚构样例（Excel）','空白模板（CSV）','使用说明','财务口径','第三方声明','参考来源.md','虚构乙台账.xlsx'];
 for(let i=0;i<names.length;i++){
  const [file]=await Promise.all([page.waitForEvent('download'),frame.getByRole('link',{name:labels[i],exact:true}).click()]);
  const target=path.join(out,'downloads',names[i]);await file.saveAs(target);assert.equal(await file.failure(),null);
  const actual=await readFile(target),expected=await readFile(path.join(release,names[i]));
  assert.equal(sha(actual),sha(expected),names[i]);downloads[names[i]]=sha(actual);
 }
 const archive=await JSZip.loadAsync(await readFile(path.join(out,'downloads',names[0])));
 assert.equal(sha(Buffer.from(await archive.file('D01/index.html')!.async('uint8array'))),sha(await readFile(release+'/index.html')));
 await frame.getByRole('link',{name:'开始整理财务台账',exact:true}).click();
 await frame.getByRole('heading',{name:'财务台账合并拆分',exact:true}).waitFor();
 assert.equal(await frame.locator('iframe').count(),0);
 await frame.getByRole('button',{name:'体验虚构样例',exact:true}).click();
 await frame.getByRole('button',{name:'清理规则',exact:true}).click();
 await frame.getByRole('button',{name:'生成合并预览',exact:true}).click();
 assert.match(await frame.locator('#tool-workspace main').innerText(),/输入9 = 有效4 \+ 异常3 \+ 重复移出2 \+ 空行移出0/);
 const [work]=await Promise.all([page.waitForEvent('download'),frame.getByRole('button',{name:'下载完整处理底稿',exact:true}).click()]);
 const workPath=out+'/downloads/site-完整处理底稿.xlsx';await work.saveAs(workPath);
 const workbook=new ExcelJS.Workbook();await workbook.xlsx.load(await readFile(workPath) as any);
 assert.deepEqual(workbook.worksheets.map(s=>s.name),['处理日志','有效','异常','重复移出','空行移出']);
 assert.deepEqual(workbook.worksheets.slice(1).map(s=>s.rowCount-1),[4,3,2,0]);
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 const result={passed:true,tool:'D01',version:'0.1.0',site_sha256:sha(await readFile('integration/native-site/site/index.html')),
  runtime_sha256:sha(await readFile(release+'/runtime.json')),module:'主数据',detail:'财务台账合并拆分',
  checks:['existing_finance_module_and_detail','workspace_loaded_inside_original_site_document','nine_row_work_matches_offline_expected','five_sheet_actual_download_readback','offline_zip_index_identical','nine_actual_first_party_downloads_exact_sha256','no_cross_origin_requests_or_page_errors'],downloads,errors,requests,accepted:false};
 await writeFile(out+'/result.json',JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({passed:true,checks:result.checks.length,downloads:Object.keys(downloads).length}));
}finally{await browser.close()}
