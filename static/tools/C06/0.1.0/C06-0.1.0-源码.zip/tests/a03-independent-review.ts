// Root new fictitious fixtures and literal hand arithmetic, no owner samples.
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fresh,schemas,calculate,canExport,change,type Kind,type State} from '../tools/A03-资产处置测算/src/engine';
import {encodeWork,decodeWork} from '../tools/A03-资产处置测算/src/work';
import {exportWorkbook} from '../tools/A03-资产处置测算/src/export';
import {readFileData,asTable} from '../packages/core/io';
import type {Table} from '../packages/core/types';
const out='progress/evidence/A03/root-independent';await mkdir(out,{recursive:true});
const scope={'批次ID':'ROOT-09','主体':'虚构根测算公司','期间':'2026-09','币种':'CNY','单位':'元'};
function table(k:Kind,rows:Record<string,string|null>[],offset:number):Table{
 const file='虚构根-'+k+'.csv',sheet='CSV',headers=schemas[k];
 return {file,sheet,headers,rows:rows.map((r,i)=>({file,sheet,row:offset+i,cells:Object.fromEntries(headers.map(h=>[h,({...scope,...r} as any)[h]??null]))}))};
}
function fixture():State{
 const s=fresh();s.rule={...s.rule,batch:scope['批次ID'],entity:scope['主体'],policyConfirmed:true,accountsConfirmed:true};
 s.data={book:table('book',[{'资产ID':'0007','资产名称':'虚构设备','资产类别':'固定资产','账面日':'2026-09-01','原值':'12500.25','累计折摊':'2500.05','减值':'500.1','账面净值':'9500.1'}],7),disposals:table('disposals',[{'处置ID':'ROOT-FULL','资产ID':'0007','处置方式':'出售','处置日':'2026-09-15','截止口径':'日截止','折摊截止日':'2026-09-15','补提折摊':'250.1','补提依据':'虚构已批准折摊底稿','处置范围':'全部','对价口径':'含税','处置对价':'10600','销项税额':'600','税额依据':'虚构企业确认税额，非税率推定','税费状态':'明细','税费依据':'虚构两项费用底稿'}],23),fees:table('fees',[{'税费ID':'F1','处置ID':'ROOT-FULL','种类':'处置费用','损益金额':'100.25','可抵扣税额':'6.015','支付总额':'106.265','依据':'虚构企业确认费用与抵扣额'},{'税费ID':'F2','处置ID':'ROOT-FULL','种类':'其他税费','损益金额':'50.75','可抵扣税额':'0','支付总额':'50.75','依据':'虚构其他税费'}],41)};
 s.originals=structuredClone(s.data);s.reviews={'ROOT-FULL':{reviewer:'虚构根复核员',basis:'虚构独立测算底稿'}};return s;
}
const checks:string[]=[];const full=fixture(),r=calculate(full),v=r.items[0].values;
assert.deepEqual(r.errors,[]);assert.equal(r.blocked,0);assert.deepEqual(r.totals,{net:'9250',revenue:'10000',costs:'151',gain:'599'});
for(const [key,value] of Object.entries({totalDep:'2750.15',inputVat:'6.015',feeGross:'157.015',gross:'10600',remainingNet:'0',allocationResidual:'0'}))assert.equal(v[key],value);
assert.equal(canExport(full),true);assert.deepEqual(r.items[0].sources.map(s=>s.row),[23,7,41,42]);
checks.push('literal full disposal net9250/revenue10000/cost151/gain599 and source rows');
// Independent six-place fixed integer sum; never imports tested Decimal helpers.
const fixed=(s:string)=>{const [a,b='']=s.split('.');assert(b.length<=6);return BigInt(a)*1000000n+BigInt(b.padEnd(6,'0'))};
const sums:Record<string,bigint>={};let debit=0n,credit=0n;
for(const e of r.entries){sums[e.stage]=(sums[e.stage]||0n)+fixed(e.debit)-fixed(e.credit);debit+=fixed(e.debit);credit+=fixed(e.credit);assert.match(e.source,/虚构根-/)}
assert.equal(Object.keys(sums).length,5);assert(Object.values(sums).every(x=>x===0n));assert.equal(debit,24106365000n);assert.equal(credit,debit);
checks.push('five journal stages independently balanced, total debit/credit24106.365');
function partial(){const s=fixture(),d=s.data.disposals!.rows[0].cells;Object.assign(d,{'处置范围':'比例','分配比例':'0.25','分配依据':'虚构25%组件分配依据','对价口径':'不含税','处置对价':'1500','销项税额':'90','税费状态':'确认零','税费依据':'虚构确认无费用'});s.data.fees!.rows=[];s.originals=structuredClone(s.data);return s}
const part=calculate(partial());assert.equal(part.blocked,0);
for(const [k,n] of Object.entries({allocatedCost:'3125.0625',allocatedDep:'687.5375',allocatedImp:'125.025',net:'2312.5',remainingCost:'9375.1875',remainingDep:'2062.6125',remainingImp:'375.075',remainingNet:'6937.5',gross:'1590',gain:'-812.5',allocationResidual:'0'}))assert.equal(part.items[0].values[k],n);
checks.push('quarter disposal six-decimal components conserve net2312.5 plus6937.5; loss812.5');
const specified=partial();Object.assign(specified.data.disposals!.rows[0].cells,{'处置范围':'指定金额','处置原值':'3000','处置累计折摊':'700','处置减值':'100'});const sr=calculate(specified);assert.equal(sr.blocked,0);assert.equal(sr.items[0].values.net,'2200');assert.equal(sr.items[0].values.remainingNet,'7050');assert.equal(sr.items[0].values.gain,'-700');
checks.push('specified components net2200 remaining7050 loss700');
const tiny=partial();Object.assign(tiny.data.book!.rows[0].cells,{'原值':'1','累计折摊':'0','减值':'0','账面净值':'1'});Object.assign(tiny.data.disposals!.rows[0].cells,{'补提折摊':'0','分配比例':'0.333333'});const tr=calculate(tiny);assert.equal(tr.items[0].values.net,'0.333333');assert.equal(tr.items[0].values.remainingNet,'0.666667');tiny.rule.precision=0;assert.equal(calculate(tiny).items[0].values.net,'0.333333');
checks.push('display precision0 preserves exact split0.333333 plus0.666667');
const zero=partial();Object.assign(zero.data.book!.rows[0].cells,{'原值':'0','累计折摊':'0','减值':'0','账面净值':'0'});Object.assign(zero.data.disposals!.rows[0].cells,{'处置范围':'全部','补提折摊':'0','处置对价':'0','销项税额':'0'});assert.equal(calculate(zero).blocked,0);assert.equal(calculate(zero).totals.gain,'0');const missing=structuredClone(zero);missing.data.disposals!.rows[0].cells['销项税额']=null;assert.equal(calculate(missing).blocked,1);assert.equal(canExport(missing),false);const negative=fixture();negative.data.book!.rows[0].cells['原值']='-1';assert.equal(calculate(negative).blocked,1);
checks.push('explicit zero valid; missing VAT and negative original block instead of zero');
for(const patch of [{'币种':'USD'},{'单位':'万元'},{'期间':'2026-10'}]){const s=fixture();Object.assign(s.data.disposals!.rows[0].cells,patch);assert.equal(calculate(s).blocked,1);assert.equal(calculate(s).totals.gain,'0')}
const dup=fixture();dup.data.book!.rows.push({...structuredClone(dup.data.book!.rows[0]),row:8});assert.equal(calculate(dup).blocked,1);const unrelated=fixture();unrelated.data.fees!.rows[0].cells['处置ID']='OTHER';assert.equal(canExport(unrelated),false);assert(calculate(unrelated).errors.some(s=>s.includes('未匹配')));
checks.push('currency/unit/period isolated; duplicate card and orphan fee block batch export');
const month=fixture();Object.assign(month.data.disposals!.rows[0].cells,{'截止口径':'处置月','折摊截止日':'2026-09-30'});assert.equal(calculate(month).blocked,0);month.data.book!.rows[0].cells['资产类别']='无形资产';assert.equal(calculate(month).blocked,1);const tolerance=fixture();tolerance.data.book!.rows[0].cells['账面净值']='9500.109';assert.equal(calculate(tolerance).blocked,0);tolerance.data.book!.rows[0].cells['账面净值']='9500.111';assert.equal(calculate(tolerance).blocked,1);
checks.push('explicit fixed monthly cutoff allowed, intangible monthly blocked, independent0.009/0.011 tolerance');
const restored=decodeWork(encodeWork(full,true));assert.equal(restored.rule.accountsConfirmed,false);assert.deepEqual(restored.reviews,{});assert.deepEqual(calculate(restored).totals,r.totals);assert.equal(canExport(restored),false);const blank=decodeWork(encodeWork(full,false));assert.deepEqual(blank.data,{});assert.deepEqual(blank.originals,{});assert.deepEqual(change(full,{revision:5}).reviews,{});assert.throws(()=>decodeWork(encodeWork(full,true).replace('"schema_version": 1','"schema_version": 2')));
checks.push('contains/no-data restore respects scope, clears confirmations, change clears review, schema rejected');
const bytes=await exportWorkbook(full);await writeFile(out+'/root-disposal.xlsx',bytes);const wb=await readFileData('root-disposal.xlsx',new Uint8Array(bytes));assert.equal(wb.sheets.length,12);const result=asTable(wb,'处置测算');assert.equal(result.rows[0].cells['处置净值'],'9250');assert.equal(result.rows[0].cells['处置损益'],'599');assert.equal(result.rows[0].cells['抵扣税'],'6.015');assert.equal(asTable(wb,'来源-资产账面').rows[0].cells['原行'],'7');assert.equal(asTable(wb,'来源-资产账面').rows[0].cells['资产ID'],'0007');
checks.push('actual12-sheet workbook literal finance cells and leading-zero/source row readback');
const sha=async(p:string)=>createHash('sha256').update(await readFile(p)).digest('hex');
await writeFile(out+'/result.json',JSON.stringify({tool:'A03',passed:true,checks,independent_expected_origin:'Root new fixtures and literal hand arithmetic; journal balance via independent BigInt fixed6 sum; no owner samples or expected imports',engine_sha256:await sha('tools/A03-资产处置测算/src/engine.ts'),script_sha256:await sha('tests/a03-independent-review.ts'),workbook_sha256:await sha(out+'/root-disposal.xlsx'),accepted:false,scope:'Independent finance/workbook/restore QA; formal source/offline/native/public separately required'},null,2)+'\n');
console.log(JSON.stringify({passed:true,groups:checks.length,sheets:12}));
