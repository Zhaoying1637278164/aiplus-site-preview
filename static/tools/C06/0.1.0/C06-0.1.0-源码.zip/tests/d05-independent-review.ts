import test from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import {readWorkbook} from '../tools/D05-财务表格公式检查/src/input';
import {run} from '../tools/D05-财务表格公式检查/src/engine';
import {initialRules} from '../tools/D05-财务表格公式检查/src/types';
import {exportWork} from '../tools/D05-财务表格公式检查/src/export';
import {releaseAssets} from '../tools/D05-财务表格公式检查/src/release-assets';
import {validateReleaseAssets} from '../packages/core/release-assets';

// Fixtures and expectations are authored here, independently of candidate examples.
async function fixture(){
 const wb=new ExcelJS.Workbook();const s=wb.addWorksheet('虚构资金表');
 s.getCell('A1').value='CNY / 元 / 2026-10';
 s.getCell('A2').value=0;s.getCell('A3').value=-10;s.getCell('A4').value=25;
 s.getCell('B2').value={formula:'A2',result:0};
 s.getCell('B3').value={formula:'A3',result:-10};
 s.getCell('B4').value={formula:'A3',result:-10};
 s.getCell('D2').value={formula:'"#REF!"',result:'#REF!'};
 s.getCell('E2').value={formula:'A2'};
 s.getCell('F2').value={formula:'G2',result:0};
 s.getCell('G2').value={formula:'F2',result:0};
 s.getCell('H2').value={formula:'F2',result:0};
 return readWorkbook('完全虚构独立预期.xlsx',new Uint8Array(await wb.xlsx.writeBuffer()));
}
test('manual finance source and zero/negative/missing caches; only B4 differs in majority pattern',async()=>{
 const w=await fixture();const rules=initialRules(w);rules.literals=false;
 const r=run(w,rules);
 const find=(addr:string)=>w.cells.find(c=>c.address===addr)!;
 assert.equal(find('A1').value,'CNY / 元 / 2026-10');
 assert.equal(find('B2').cache,'0');assert.equal(find('B3').cache,'-10');
 assert.equal(find('E2').cache,null);assert.equal(find('E2').cacheState,'missing');
 assert.deepEqual(r.findings.filter(f=>f.type==='模式差异').map(f=>f.address),['B4']);
 assert.deepEqual(r.findings.filter(f=>f.type==='静态循环路径').map(f=>f.address).sort(),['F2','G2']);
 assert.equal(r.findings.some(f=>f.address==='H2'&&f.type==='静态循环路径'),false);
 assert.equal(r.findings.some(f=>f.address==='D2'&&f.type==='断裂引用'),false);
 assert.deepEqual(r.findings.filter(f=>f.type==='缺少缓存').map(f=>f.address),['E2']);
});
test('actual seven-sheet export preserves formula strings, original coordinates and zero caches',async()=>{
 const w=await fixture();const r=run(w,initialRules(w));
 const bytes=await exportWork(r);const wb=new ExcelJS.Workbook();
 await wb.xlsx.load(bytes as unknown as Parameters<typeof wb.xlsx.load>[0]);
 assert.deepEqual(wb.worksheets.map(s=>s.name),['检查摘要','完整问题','公式模式','引用清单','全部原格','范围与规则','忽略清单']);
 const raw=wb.getWorksheet('全部原格')!;
 assert.equal(raw.rowCount,w.cells.length+1);
 const row=raw.getRows(2,w.cells.length)!.find(x=>x.getCell(3).value==='B2')!;
 assert.equal(row.getCell(2).value,'虚构资金表');assert.equal(row.getCell(8).value,'=A2');
 assert.equal(row.getCell(10).value,'0');
 for(const s of wb.worksheets)s.eachRow(row=>row.eachCell(c=>assert.notEqual(c.type,ExcelJS.ValueType.Formula)));
});
test('actual D05 delivery exposes usable XLSX template with no fabricated CSV entry',async()=>{
 const assets=await releaseAssets();validateReleaseAssets(assets,'空白模板.xlsx');
 assert.deepEqual(assets.map(a=>a.filename).sort(),['空白模板.xlsx','虚构样例.xlsx'].sort());
 for(const asset of assets){assert.ok(asset.data instanceof Uint8Array);const parsed=await readWorkbook(asset.filename,asset.data as Uint8Array);assert.ok(parsed.sheets.length>0);}
});
