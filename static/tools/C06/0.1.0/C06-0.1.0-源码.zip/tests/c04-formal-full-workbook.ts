import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const base='progress/evidence/C04/0.1.0/root-formal-offline/large-browser';
const file=base+'/604底稿.xlsx',book=new ExcelJS.Workbook();
await book.xlsx.load(await readFile(file) as any);
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
assert.equal(book.worksheets.length,8);
function matrix(name:string) {
 const s=book.getWorksheet(name);assert.ok(s,name);const result:unknown[][]=[];
 s.eachRow({includeEmpty:true},(r,i)=>{if(i===1)return;const values:unknown[]=[];for(let c=1;c<=s.columnCount;c++){assert.notEqual(r.getCell(c).type,ExcelJS.ValueType.Formula);values.push(r.getCell(c).value??'');}result.push(values)});
 return result;
}
// Fully specified fictitious rows. No engine/report result used as oracle.
const expected=Array.from({length:604},(_,k)=>{
 const i=k+1,id=String(i).padStart(4,'0'),entity='虚构主体'+id,account='TAIL'+id,name='虚构余额'+i;
 const source=`604虚构余额.xlsx / 原始余额 / 第${i+2}行`;
 const keys=[entity,'2026-09','CNY','元'],prefix=[...keys,account,name,source];
 return {group:[...keys,'1','1','100','0','30','20','110','0','100','10','110','借贷差异','借贷差异','借贷差异',source],
  reconcile:[...prefix,'100','10','110','110','0','容差内'],
  direction:[...prefix,'110',i===604?'不限方向':'无超阈方向线索'],
  continuity:[...prefix,'','','未执行：无前期资料'],
  completeness:[...prefix,'','已执行代数检查'],
  raw:['604虚构余额.xlsx','原始余额',String(i+2),...keys,account,name,'100','0','30','20','110','0','借']};
});
for(const [name,key] of [['借贷汇总','group'],['余额勾稽','reconcile'],['方向线索','direction'],['期间连续性','continuity'],['资料完整性','completeness'],['原始资料','raw']] as const)
 assert.deepEqual(matrix(name),expected.map(r=>r[key]),name+' all604 rows every cell');
assert.deepEqual(matrix('科目方向配置'),[['TAIL0604','不限']]);
assert.equal(matrix('检查说明').length,5);
await writeFile(base+'/root-every-cell.json',JSON.stringify({passed:true,tool:'C04',worksheets:8,manual_rows:604,
 six_tables_every_source_and_finance_cell_checked:true,workbook_sha256:sha(await readFile(file)),
 script_sha256:sha(await readFile('tests/c04-formal-full-workbook.ts')),html_sha256:sha(await readFile('release/C04/0.1.0/index.html')),
 public_verified:false,accepted:false},null,2)+'\n');
console.log('C04 all604 rows across six tables, direction configuration and eight sheets checked independently');
