import {chromium} from 'playwright';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const out='progress/evidence/A01/0.1.0/root-formal-offline/rendered-supplement';
await mkdir(out,{recursive:true});
const build=JSON.parse(await readFile('progress/evidence/A01/0.1.0/root-formal-build.json','utf8'));
const html=build.offline_extraction+'/A01/index.html';
assert.equal(createHash('sha256').update(await readFile(html)).digest('hex'),build.files['index.html']);
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const ctx=await browser.newContext({offline:true}),p=await ctx.newPage(),errors:string[]=[],requests:string[]=[],images:any[]=[];
p.on('pageerror',e=>errors.push(e.message));p.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});
try{
 await p.goto('file://'+html);await p.getByRole('button',{name:'载入虚构资料',exact:true}).click();
 for(const width of [1440,900,390])for(const page of [4,8]){
  await p.setViewportSize({width,height:1000});await p.getByRole('navigation').getByRole('button').nth(page).click();
  await p.evaluate(async()=>{scrollTo(0,0);await new Promise<void>(r=>requestAnimationFrame(()=>requestAnimationFrame(()=>r())))});
  const rows=p.locator('table').first().locator('tbody tr');assert.equal(await rows.count(),240);
  const first=await rows.first().innerText(),last=await rows.last().innerText();assert.match(first,/FA01/);assert.match(last,/IA02/);assert.match(last,/2030-12/);
  const geometry=await p.evaluate(()=>({height:document.documentElement.scrollHeight,width:innerWidth,scrollWidth:document.documentElement.scrollWidth,footer:document.querySelector('footer')!.getBoundingClientRect().bottom+scrollY}));
  assert(geometry.scrollWidth<=width+1);assert(geometry.footer<=geometry.height+1);
  const full=`${width}-${page+1}-complete.png`;await p.screenshot({path:out+'/'+full,fullPage:true});
  const segments:any[]=[];
  for(const [label,target] of [['top',0],['middle',Math.floor(geometry.height/2)],['bottom',geometry.height]] as const){
   await p.evaluate(y=>scrollTo(0,y),target);await p.evaluate(()=>new Promise<void>(r=>requestAnimationFrame(()=>requestAnimationFrame(()=>r()))));
   const y=await p.evaluate(()=>scrollY),file=`${width}-${page+1}-${label}.png`;await p.screenshot({path:out+'/'+file});
   segments.push({file,y,sha256:createHash('sha256').update(await readFile(out+'/'+file)).digest('hex')});
  }
  await p.locator('footer').scrollIntoViewIfNeeded();assert(await p.locator('footer').isVisible());
  images.push({width,page:page+1,full,full_sha256:createHash('sha256').update(await readFile(out+'/'+full)).digest('hex'),geometry,rows:240,first,last,segments});
 }
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 await writeFile(out+'/result.json',JSON.stringify({passed:true,html_sha256:build.files['index.html'],images,errors,requests,scope:'Actual extracted formal ZIP, reset scroll before full capture; 240 actual DOM rows and last IA02/2030-12/footer verified; 18 actual viewport segments; visual review separate'},null,2));
 console.log(JSON.stringify({passed:true,fullImages:images.length,viewportSegments:18}));
}finally{await browser.close()}
