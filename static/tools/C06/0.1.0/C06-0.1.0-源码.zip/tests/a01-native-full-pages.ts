// Capture all actual srcdoc content, including content below the iframe viewport.
import {chromium} from 'playwright';import {mkdir,readFile,writeFile} from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';import {openA01Native} from './a01-native-bootstrap';
const out=path.resolve('progress/evidence/A01/0.1.1/site-full-pages');await mkdir(out,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'}),errors:string[]=[],requests:string[]=[],images:any[]=[];
try{
 const native=await openA01Native(browser,out,path.resolve('release/A01/0.1.1'),errors,requests,()=>true),{frame,shell,page}=native;
 await page.getByRole('button',{name:'载入虚构资料',exact:true}).click();
 const pages=['工作概览','资产范围与建档','政策与折摊方法','期初累计与净值','逐期排程','追加减值与处置','生效变更','已确认历史','余额勾稽','来源追查与异常','方案与完整底稿'];
 for(const width of [1440,900,390]){
  await shell.setViewportSize({width,height:1000});
  for(let i=0;i<pages.length;i++){
   await shell.setViewportSize({width,height:1000});
   await page.getByRole('navigation').getByRole('button').nth(i).click();
   if(i===10)await page.getByRole('button',{name:'下载虚构样例.xlsx',exact:true}).waitFor();
   const iframe=shell.locator('iframe').first(),before=await iframe.getAttribute('style'),attr=await iframe.getAttribute('height');
   // Freeze the current viewport-based min-height during capture, then restore.
   const toolStyle=await frame.locator('.a01').getAttribute('style');
   await frame.locator('.a01').evaluate(el=>{el.style.minHeight=innerHeight+'px'});
   const height=await frame.evaluate(()=>Math.max(document.documentElement.scrollHeight,document.body.scrollHeight));
   try{
    await iframe.evaluate((el,h)=>{const ancestors:any[]=[];for(let parent=el.parentElement;parent;parent=parent.parentElement){ancestors.push([parent,parent.getAttribute('style')]);parent.style.setProperty('overflow','visible','important')} (el as any).__captureStyles=ancestors;el.style.setProperty('height',h+'px','important');el.setAttribute('height',String(h))},height);
    await frame.waitForFunction(h=>innerHeight>=h-2,height);
    await shell.setViewportSize({width,height:height+50});
    await shell.evaluate(()=>{scrollTo(0,0);for(const el of Array.from(document.querySelectorAll('*')))if(el.scrollTop)el.scrollTop=0});
    await frame.evaluate(async()=>{scrollTo(0,0);await new Promise<void>(r=>requestAnimationFrame(()=>requestAnimationFrame(()=>r())))});
    await shell.evaluate(()=>new Promise<void>(r=>requestAnimationFrame(()=>requestAnimationFrame(()=>r()))));
    const rendered=await frame.evaluate(()=>({width:innerWidth,height:innerHeight,scrollHeight:document.documentElement.scrollHeight,overflow:document.documentElement.scrollWidth>innerWidth+2}));
    assert(!rendered.overflow);assert(rendered.height>=height-2);assert(rendered.scrollHeight<=rendered.height+2);
    const box=await iframe.boundingBox();assert(box && box.y>=-1 && box.y+box.height<=height+50+1, 'Entire iframe must fit capture viewport');
    const file=`site-full-${width}-${i+1}.png`;await shell.screenshot({path:out+'/'+file,clip:{x:box.x,y:box.y,width:box.width,height:box.height}});const bytes=await readFile(out+'/'+file);
    images.push({file,requestedWidth:width,page:pages[i],iframeExpandedHeight:height,rendered,sha256:createHash('sha256').update(bytes).digest('hex')});
   }finally{await shell.setViewportSize({width,height:1000});await frame.locator('.a01').evaluate((el,style)=>{if(style===null)el.removeAttribute('style');else el.setAttribute('style',style)},toolStyle);await iframe.evaluate((el,v)=>{for(const [parent,style] of (el as any).__captureStyles||[]){if(style===null)parent.removeAttribute('style');else parent.setAttribute('style',style)}delete (el as any).__captureStyles;if(v.style===null)el.removeAttribute('style');else el.setAttribute('style',v.style);if(v.height===null)el.removeAttribute('height');else el.setAttribute('height',v.height)},{style:before,height:attr})}
  }
 }
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);await writeFile(out+'/result.json',JSON.stringify({passed:true,siteSHA:native.siteSHA,actualRuntimeSHA:native.actualRuntimeSHA,images,errors,requests,scope:'33 actual iframe content screenshots with temporary iframe height equal document content; restored after capture; internal tables remain horizontally scrollable; manual visual review separate'},null,2));console.log(JSON.stringify({passed:true,actualFullContentImages:images.length}));
}finally{await browser.close()}
