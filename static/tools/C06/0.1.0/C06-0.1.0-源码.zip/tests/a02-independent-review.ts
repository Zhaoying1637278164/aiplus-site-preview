// Root-created fictitious cases and literal hand calculations. No owner example/expected imports.
import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {freshBatch,calculate,choose,undoChoice,review,confirmBatch,newBatch,invalidate,type Batch} from '../tools/A02-资产台账与盘点/src/engine';
import {encodeWork,decodeWork} from '../tools/A02-资产台账与盘点/src/work';
import {exportWorkbook} from '../tools/A02-资产台账与盘点/src/export';
import {asTable,readFileData} from '../packages/core/io';
import type {Table} from '../packages/core/types';
const out='progress/evidence/A02/root-independent';await mkdir(out,{recursive:true});
function table(sheet:string,rows:Record<string,string|null>[]):Table{const file='根虚构盘点.xlsx';return {file,sheet,headers:Object.keys(rows[0]),rows:rows.map((cells,i)=>({file,sheet,row:i+7,cells}))}}
function fixture():Batch{
 const b=freshBatch();b.rule.entity='虚构松柏公司';
 const book=(id:string,cost:string,dep:string,loss:string,net:string)=>({'主体':b.rule.entity,'期间':'2026-09','币种':'CNY','金额单位':'元','资产ID':id,'资产名称':'虚构同名设备','类别':'设备','位置':'甲室','责任人':'虚构甲','原值':cost,'累计折旧':dep,'减值':loss,'账面净值':net,'账面依据':'根独立虚构账面'});
 const count=(id:string,record:string,status:string,entity=b.rule.entity)=>({'批次ID':b.rule.batchId,'主体':entity,'期间':'2026-09','币种':'CNY','金额单位':'元','记录ID':record,'实物ID':id,'资产名称':'虚构同名设备','盘点日':'2026-09-29','实盘状态':status,'位置':id==='001'?'乙室':'甲室','责任人':'虚构甲','盘点人':'虚构丙','证据':'根独立虚构盘点'});
 b.data.book=table('根账面',[book('001','100.125','10.025','0.1','90'),book('1','50','50','0','0'),book('003','200.005','20','0','180.005'),book('004','10','0','0','10')]);
 b.data.count=table('根实盘',[count('001','Q1','在场'),count('003','Q3','未找到'),count('004','Q4','待核实'),count('NEW','QN','在场'),count('001','FOREIGN','在场','虚构其他公司')]);return b;
}
const groups:string[]=[];function check(name:string,fn:()=>void){fn();groups.push(name)}
check('独立金额360.13-80.025-0.1=280.005；前导零同名分开；缺盘与未知价值不补零',()=>{
 const r=calculate(fixture());assert.deepEqual([r.totals.original,r.totals.depreciation,r.totals.impairment,r.totals.net,r.totals.residual,r.totals.formulaResidual],['360.13','80.025','0.1','280.005','0','0']);
 const item=(id:string)=>r.items.find(x=>x.id===id)!;
 assert.deepEqual([item('001').status,item('001').net,item('001').actual,item('001').difference],['位置责任变化','90',1,0]);
 assert.deepEqual([item('1').status,item('1').net,item('1').actual,item('1').difference],['未盘','0',null,null]);
 assert.deepEqual([item('003').status,item('003').net,item('003').difference],['盘亏候选','180.005',-1]);
 assert.deepEqual([item('004').status,item('004').actual],['待核实',null]);assert.deepEqual([item('NEW').net,item('NEW').difference], [null,1]);
 assert.equal(r.items.length,5);assert.equal(r.coverage.excluded,1);assert.equal(item('001').book[0].source.row,7);
});
check('未盘、待核实不能确认；盘亏仅复核分类',()=>{const b=fixture(),r=calculate(b);for(const id of ['1','004'])assert.throws(()=>review(b,r.items.find(x=>x.id===id)!.key,'虚构复核','独立复核','认可分类'));const x=review(b,r.items.find(x=>x.id==='003')!.key,'虚构复核','调查依据','需后续处理');assert.equal(calculate(x).coverage.reviewed,1);assert.throws(()=>confirmBatch(x,'虚构复核','尚未全盘'))});
check('空净值与负原值保留异常，不能作为零或有效合计',()=>{for(const value of [null,'-1']){const b=fixture();b.data.book!.rows[0].cells[value===null?'账面净值':'原值']=value;const r=calculate(b);assert.equal(r.items.find(x=>x.id==='001')!.status,'异常');assert.equal(r.items.find(x=>x.id==='001')!.net,null);assert.equal(r.totals.net,'190.005')}});
check('单位与币种隔离，不自动换算；重复账面不合并',()=>{for(const [k,v] of [['币种','USD'],['金额单位','万元']] as const){const b=fixture();b.data.book!.rows[0].cells[k]=v;assert.equal(calculate(b).totals.net,'190.005')}const b=fixture();const x=structuredClone(b.data.book!.rows[0]);x.row=80;b.data.book!.rows.push(x);const r=calculate(b);assert.equal(r.items.find(x=>x.id==='001')!.status,'异常');assert.equal(r.totals.net,'190.005')});
check('重复实盘显式选择和撤销；重复记录ID不可选择绕过',()=>{const b=fixture();const q=structuredClone(b.data.count!.rows[0]);q.row=81;q.cells['记录ID']='Q2';b.data.count!.rows.push(q);const item=calculate(b).items.find(x=>x.id==='001')!;assert.equal(item.status,'异常');const chosen=choose(b,item.key,item.counts[0].sid,'虚构复核','采用初盘依据');assert.equal(calculate(chosen).coverage.notUsedCounts,1);assert.equal(calculate(undoChoice(chosen,item.key,'虚构复核','撤销')).items.find(x=>x.id==='001')!.status,'异常');b.data.count!.rows.at(-1)!.cells['记录ID']='Q1';assert.throws(()=>choose(b,item.key,item.counts[0].sid,'虚构复核','重复记录不可绕过'))});
function complete(){let b=fixture();const q=structuredClone(b.data.count!.rows[0]);q.row=82;q.cells['记录ID']='ZERO';q.cells['实物ID']='1';q.cells['位置']='甲室';b.data.count!.rows.push(q);b.data.count!.rows[2].cells['实盘状态']='在场';for(const i of calculate(b).items)b=review(b,i.key,'虚构复核','根完整分类核查','认可分类');return confirmBatch(b,'虚构复核','根虚构封存');}
check('实际批次封存保护；下一批仅参数无完成数据；历史金额保持280.005',()=>{const b=complete();assert.equal(calculate(b).coverage.reviewed,5);assert.throws(()=>invalidate(b,{data:fixture().data},'不应修改已封存'));const old={active:b.rule.batchId,batches:[b]},next=newBatch(old,'ROOT-NEXT');assert.equal(next.batches.length,2);assert.equal(next.batches[1].data.book,null);assert.deepEqual(next.batches[1].reviews,{});assert.equal(next.batches[1].confirmed,null);assert.equal(calculate(next.batches[0]).totals.net,'280.005');assert.throws(()=>newBatch(next,b.rule.batchId));});
check('含数据工作恢复全部历史与净值；无数据方案不带资料或确认',()=>{const b=complete(),s={active:b.rule.batchId,batches:[b]},raw=encodeWork(s,true);const restored=decodeWork(raw);assert.deepEqual(restored,s);assert.equal(calculate(restored.batches[0]).totals.net,'280.005');const plan=JSON.parse(encodeWork(s,false));assert.equal(plan.contains_data,false);assert.equal('state' in plan,false);const empty=decodeWork(JSON.stringify(plan));assert.equal(empty.batches[0].data.book,null);assert.deepEqual(empty.batches[0].reviews,{});assert.equal(empty.batches[0].confirmed,null);});
check('伪造封存/复核与未知schema拒绝，不静默恢复错误历史',()=>{const b=complete(),raw=encodeWork({active:b.rule.batchId,batches:[b]},true);for(const change of [(p:any)=>{p.schema_version=2},(p:any)=>{p.state.batches[0].data.book.rows[0].cells['原值']='101.125'},(p:any)=>{p.state.batches[0].confirmed.signature='伪造'}]){const p=JSON.parse(raw);change(p);assert.throws(()=>decodeWork(JSON.stringify(p)));}});
const b=fixture(),bytes=await exportWorkbook({active:b.rule.batchId,batches:[b]});await writeFile(out+'/根独立底稿.xlsx',bytes);const loaded=await readFileData('根独立底稿.xlsx',bytes);assert.equal(loaded.sheets.length,12);const cards=asTable(loaded,'资产卡片与差异');assert.equal(cards.rows.length,5);assert.equal(cards.rows.find(x=>x.cells['资产ID']==='001')!.cells['账面净值'],'90');assert.equal(cards.rows.find(x=>x.cells['资产ID']==='NEW')!.cells['账面净值'],'');assert.equal(asTable(loaded,'原始资产台账').rows[0].cells['原行'],'7');groups.push('实际12表XLSX回读；5卡片；未知净值空；原行7');
await writeFile(out+'/result.json',JSON.stringify({passed:true,groups,exportSheets:12,rootFixture:'Fully fictitious independent root rows; no owner example or expected imports',test_sha256:createHash('sha256').update(await readFile('tests/a02-independent-review.ts')).digest('hex'),workbook_sha256:createHash('sha256').update(bytes).digest('hex'),scope:'Root financial calculation and actual export readback only; formal/offline/website/source acceptance pending'},null,2));console.log(JSON.stringify({passed:true,groups:groups.length,exportSheets:12}));
