// Root fixture and expectations use literal source sequences and integer cents.
import {chromium} from 'playwright';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import {openA02Native} from './a02-native-bootstrap';
import {fresh,active,columns,type State} from '../tools/A02-资产台账与盘点/src/engine';
import {readFileData,asTable} from '../packages/core/io';
const out=path.resolve('progress/evidence/A02/0.1.0/root-native-pagination');await mkdir(out,{recursive:true});
const sha=(v:Buffer|string)=>createHash('sha256').update(v).digest('hex');
function fixture(size:number,bad=false):State{
 const s=fresh(),b=active(s),scope=['虚构星河公司','2026-09','CNY','元'];
 const id=(i:number)=>'A'+String(i+1).padStart(4,'0');
 const add=(role:'book'|'count'|'mapping',rows:unknown[][])=>{const file='虚构根独立'+role+'.csv';b.data[role]={file,sheet:'CSV',headers:columns[role],rows:rows.map((r,i)=>({file,sheet:'CSV',row:i+2,cells:Object.fromEntries(columns[role].map((c,j)=>[c,r[j] as string|null]))}))}};
 add('book',Array.from({length:size},(_,i)=>[...scope,id(i),'虚构资产'+id(i),'设备','A室','甲',bad?null:'100.01','20','0','80.01','虚构独立余额行'+(i+2)]));
 add('count',Array.from({length:size},(_,i)=>['B202609',...scope,'C'+id(i),'L'+id(i),'虚构资产'+id(i),'2026-09-29','在场','A室','甲','虚构盘点人','虚构证据'+(i+2)]));
 add('mapping',Array.from({length:size},(_,i)=>['B202609',...scope,'L'+id(i),id(i),'虚构标签册行'+(i+2)]));
 return s;
}
async function file(name:string,state:State,contains=true){const b=active(state),payload={schema_version:1,tool:'A02',app_version:'0.1.0',rule_version:'A02-2026-10-04.1',contains_data:contains,...(contains?{state}:{rule:b.rule,fields:b.fields})};const f=out+'/'+name;await writeFile(f,JSON.stringify(payload));return f}
const long=await file('虚构400件1200源行.json',fixture(400)),bad=await file('虚构400异常.json',fixture(400,true)),small=await file('虚构2件.json',fixture(2)),empty=await file('无数据.json',fixture(400),false);
const errors:string[]=[],requests:string[]=[],checks:string[]=[],downloads:any[]=[];let accept=true;
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const native=await openA02Native(browser,out,path.resolve('release/A02/0.1.0'),errors,requests,()=>accept),p=native.page;
const nav=async(i:number)=>{await p.getByRole('navigation').getByRole('button').nth(i).click()};
const region=(name:string)=>p.getByRole('region',{name,exact:true});
const pager=(name:string)=>region(name).locator('xpath=following-sibling::div[contains(@class,"a02-pagination")][1]');
const status=(name:string)=>pager(name).locator('span').innerText();
const btn=(name:string,dir:string)=>pager(name).getByRole('button',{name:dir,exact:true});
const restore=async(f:string)=>{await nav(7);await p.getByLabel('恢复JSON',{exact:true}).setInputFiles(f);await p.getByRole('status').filter({hasText:'恢复成功'}).waitFor()};
const check=async(name:string,fn:()=>Promise<void>)=>{await fn();checks.push(name);console.log('PASS '+name)};
async function allRows(name:string,index:number,expected:string[]){const seen:string[]=[];let page=0;while(true){const trs=region(name).locator('tbody tr');for(let i=0;i<await trs.count();i++)seen.push(await trs.nth(i).locator('td').nth(index).innerText());page++;if(await btn(name,'下一页').isDisabled())break;await btn(name,'下一页').click()}assert.equal(page,Math.ceil(expected.length/30));assert.deepEqual(seen,expected);assert.equal(await btn(name,'下一页').isDisabled(),true);return seen}
const ids=Array.from({length:400},(_,i)=>'A'+String(i+1).padStart(4,'0'));
try{
 await restore(long);
 await check('400资产卡片逐页无重漏/十四页边界',async()=>{await nav(1);assert.match(await status('资产卡片列表'),/400 行.*1\/14 页/);assert.equal(await btn('资产卡片列表','上一页').isDisabled(),true);assert.equal(await region('资产卡片列表').locator('tbody tr').count(),30);await allRows('资产卡片列表',0,ids);assert.equal(await region('资产卡片列表').locator('tbody tr').count(),10);assert.match(await status('资产卡片列表'),/14\/14 页/)});
 await check('1200全部原行逐页来源顺序及原行1200可达',async()=>{await nav(5);await allRows('全部原行去向',2,[...ids,...ids.map(x=>'L'+x),...ids.map(x=>'L'+x)]);assert.match(await status('全部原行去向'),/1200 行.*40\/40 页/);assert.match(await region('全部原行去向').locator('tbody tr').last().innerText(),/401/)});
 await check('末页搜索全量而非当前页且空筛选恢复',async()=>{await p.getByLabel('搜索来源').fill('A0400');assert.match(await status('全部原行去向'),/3 行.*1\/1 页/);assert.equal(await region('全部原行去向').locator('tbody tr').count(),3);await p.getByLabel('搜索来源').fill('不存在虚构ID');assert.match(await status('全部原行去向'),/0 行.*0\/0 页/);assert.equal(await btn('全部原行去向','下一页').isDisabled(),true);await p.getByLabel('搜索来源').fill('');assert.match(await status('全部原行去向'),/1200 行.*1\/40 页/)});
 await check('400差异逐页所有ID与单件净值及勾稽守恒',async()=>{await nav(4);await allRows('差异清单',0,ids);const text=await region('差异清单').locator('tbody tr').last().innerText();assert.match(text,/A0400/);assert.match(text,/80\.01/);await nav(5);const totals=await region('勾稽').innerText();assert.match(totals,/32004/);assert.match(totals,/分类残差\s*0/);assert.match(totals,/净值公式残差\s*0/)});
 await check('筛选末件时12表XLSX和CSV仍完整400/1200行，金额源行前导零保留',async()=>{await nav(4);await p.getByLabel('搜索差异').fill('A0400');assert.match(await status('差异清单'),/1 行.*1\/1 页/);await nav(7);let wait=p.waitForEvent('download');await p.getByRole('button',{name:'下载完整XLSX底稿',exact:true}).click();let d=await wait,f=out+'/'+d.suggestedFilename();await d.saveAs(f);const bytes=await readFile(f),wb=await readFileData(f,new Uint8Array(bytes));assert.equal(wb.sheets.length,12);for(const name of ['原始资产台账','原始盘点记录','原始ID对应','资产卡片与差异','ID对应结果'])assert.equal(asTable(wb,name).rows.length,400);assert.equal(asTable(wb,'原行去向与追查').rows.length,1200);const cards=asTable(wb,'资产卡片与差异');assert.deepEqual(cards.rows.map(x=>x.cells['资产ID']),ids);assert.ok(cards.rows.every(x=>x.cells['账面净值']==='80.01'));assert.equal(asTable(wb,'原始资产台账').rows.at(-1)!.cells['原行'],'401');downloads.push({name:d.suggestedFilename(),sha256:sha(bytes),sheets:12,cardRows:400,sourceRows:1200});wait=p.waitForEvent('download');await p.getByRole('button',{name:'原行去向与追查 CSV',exact:true}).click();d=await wait;f=out+'/'+d.suggestedFilename();await d.saveAs(f);const csvBytes=await readFile(f),csvWb=await readFileData(f,new Uint8Array(csvBytes));assert.equal(asTable(csvWb,csvWb.sheets[0].name).rows.length,1200);downloads.push({name:d.suggestedFilename(),sha256:sha(csvBytes),sourceRows:1200});await nav(4);await p.getByLabel('搜索差异').fill('')});
 await check('换资料后旧尾行不可见、恢复空方案不保留原始资料',async()=>{await restore(small);await nav(1);assert.match(await status('资产卡片列表'),/2 行.*1\/1 页/);assert.equal(await btn('资产卡片列表','下一页').isDisabled(),true);assert.doesNotMatch(await region('资产卡片列表').innerText(),/A0400/);await restore(empty);await nav(5);assert.match(await status('全部原行去向'),/0 行.*0\/0 页/);assert.doesNotMatch(await region('全部原行去向').innerText(),/A0001/)});
 await check('400空金额异常全量可追查，不填零也不丢原行',async()=>{await restore(bad);await nav(4);await p.getByLabel('差异分类').selectOption('异常');await allRows('差异清单',0,ids);const t=region('差异清单').locator('tbody tr').last();assert.equal(await t.locator('td').nth(3).innerText(),'—');await p.getByLabel('选择资产追查').selectOption({label:'A0400 · 虚构资产A0400 · 异常'});assert.equal(await p.getByRole('button',{name:'确认逐项复核',exact:true}).isDisabled(),true);await nav(5);await allRows('全部原行去向',2,[...ids,...ids.map(x=>'L'+x),...ids.map(x=>'L'+x)])});
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);assert.deepEqual(await p.evaluate(()=>(window as any).__writes),[]);
 await writeFile(out+'/result.json',JSON.stringify({passed:true,checks,downloads,siteSHA:native.siteSHA,runtimeSHA:native.actualRuntimeSHA,testSHA:sha(await readFile('tests/a02-native-pagination.ts')),errors,requests,expected:'400 literal consecutive asset IDs; 1200 literal ordered book/count/mapping source IDs; net=400×8001 cents=32004 yuan; no expectations copied from calculate()',scope:'actual local original Streamlit same-document A02; processing offline; pagination/source/export/restore; public separately required'},null,2));
}catch(e){await p.screenshot({path:out+'/failure.png',fullPage:true});await writeFile(out+'/failure.json',JSON.stringify({checks,error:String(e)},null,2));throw e}finally{await browser.close()}
