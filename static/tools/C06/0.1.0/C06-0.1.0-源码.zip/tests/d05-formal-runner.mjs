import {readFile,mkdir,writeFile,mkdtemp} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import JSZip from 'jszip';
const out='progress/evidence/D05/0.1.0/root-formal-offline';await mkdir(out,{recursive:true});
const folder='release/D05/0.1.0',sha=b=>createHash('sha256').update(b).digest('hex');
const bytes=await readFile(folder+'/D05-0.1.0-离线包.zip');const zip=await JSZip.loadAsync(bytes);
const temp=await mkdtemp('/private/tmp/aiplus-D05-offline-');const extracted=temp+'/D05';await mkdir(extracted);
const assets={};for(const [name,member] of Object.entries(zip.files)){
 if(member.dir)continue;if(!/^D05\/[^/]+$/.test(name))throw Error('unexpected ZIP entry '+name);
 const data=await member.async('nodebuffer'),filename=name.slice(4);
 if(sha(data)!==sha(await readFile(folder+'/'+filename)))throw Error('ZIP differs '+filename);
 await writeFile(extracted+'/'+filename,data);assets[filename]=sha(data);
}
const commands=[];let failed=false;
for(const script of ['tests/d05-formal-browser.ts','tests/d05-formal-native.ts']){
 const exit_code=await new Promise((resolve,reject)=>{
  const child=spawn(process.execPath,['--import','tsx',script],{env:{...process.env,AIPLUS_D05_OFFLINE_FOLDER:extracted},stdio:['ignore','pipe','pipe']});let log='';
  child.stdout.on('data',b=>{log+=b;process.stdout.write(b)});child.stderr.on('data',b=>{log+=b;process.stderr.write(b)});
  child.on('error',reject);child.on('close',async code=>{await writeFile(out+'/'+script.split('/').pop()+'.log',log);resolve(code)});
 });commands.push({script,script_sha256:sha(await readFile(script)),exit_code});if(exit_code!==0){failed=true;break;}
}
await writeFile(out+'/run.json',JSON.stringify({passed:!failed,tool:'D05',version:'0.1.0',offline_zip_sha256:sha(bytes),extracted_directory:extracted,assets,commands,runner_sha256:sha(await readFile('tests/d05-formal-runner.mjs'))},null,2)+'\n');
if(failed)process.exitCode=1;
