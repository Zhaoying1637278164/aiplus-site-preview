import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import ExcelJS from 'exceljs';
const out=path.resolve(process.env.C03_ROOT_QA_DIR||'progress/evidence/C03/root-repaired-browser');
const html=path.resolve(process.env.C03_ROOT_HTML||'tools/C03-待摊费用排程/candidate/0.1.0/index.html');
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');await mkdir(out+'/downloads',{recursive:true});
const headers=['事项ID','费用名称','金额','开始日','结束日','币种','单位','已摊金额','已摊截至期','费用科目','待摊科目','依据'];
const rows=Array.from({length:203},(_,i)=>['ROOT'+String(i+1).padStart(4,'0'),'完全虚构费用',i===202?'24':'12','2026-01-01','2026-12-31','CNY','元','0','2025-12','管理费用','待摊费用','完全虚构依据'+(i+1)]);
const csv=(rs:string[][])=>'\uFEFF'+[headers,...rs].map(a=>a.map(x=>'"'+x+'"').join(',')).join('\r\n');
await writeFile(out+'/203-expenses.csv',csv(rows));
const checks:string[]=[],errors:string[]=[],requests:string[]=[],downloads:Record<string,string>={};
const browser=await chromium.launch({headless:true,executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
try{
 const c=await browser.newContext({offline:true,acceptDownloads:true,viewport:{width:1440,height:1000}});
 await c.addInitScript(()=>{Storage.prototype.setItem=()=>{throw Error('forbidden persistence')};indexedDB.open=()=>{throw Error('forbidden indexedDB')};});
 const p=await c.newPage();let accept=true;p.on('pageerror',e=>errors.push(e.message));p.on('request',q=>{if(/^https?:/.test(q.url()))requests.push(q.url())});p.on('dialog',d=>void(accept?d.accept():d.dismiss()));
 await p.goto('file://'+html);
 const nav=(s:string)=>p.getByRole('navigation').getByRole('button',{name:new RegExp(s+'$')}).click();
 const panel=(i=0)=>p.locator('main .table-panel').nth(i);
 const collect=async(i=0)=>{const a=panel(i),all:string[][]=[];if(await a.getByRole('button',{name:'首页',exact:true}).isEnabled())await a.getByRole('button',{name:'首页',exact:true}).click();
  while(true){const current=await a.locator('tbody tr').evaluateAll(ts=>ts.map(t=>Array.from(t.querySelectorAll('td')).map(td=>td.textContent||'')));assert.ok(current.length<=50);all.push(...current);if(await a.getByRole('button',{name:'下一页',exact:true}).isDisabled())break;const before=await a.getByRole('note').innerText();await a.getByRole('button',{name:'下一页',exact:true}).click();await p.waitForFunction(({before,index})=>document.querySelectorAll('main .table-panel')[index]?.querySelector('[role="note"]')?.textContent!==before,{before,index:i});}
  return all;
 };
 const dl=async(label:string,name:string)=>{const [d]=await Promise.all([p.waitForEvent('download'),p.getByRole('button',{name:label,exact:true}).click()]);await d.saveAs(out+'/downloads/'+name);assert.equal(await d.failure(),null);downloads[name]=sha(await readFile(out+'/downloads/'+name));return out+'/downloads/'+name;};
 await nav('费用台账');await p.getByLabel('费用文件',{exact:true}).setInputFiles(out+'/203-expenses.csv');await p.getByRole('status').filter({hasText:'准备完成'}).waitFor();await p.getByRole('button',{name:'验证并导入',exact:true}).click();await p.getByRole('status').filter({hasText:'导入并校验通过'}).waitFor();
 const inputs=await collect();assert.equal(inputs.length,203);for(let i=0;i<203;i++)assert.deepEqual(inputs[i].slice(0,15),[...rows[i],'203-expenses.csv','CSV',String(i+2)]);
 checks.push('203_all_source_rows_exact_original_cells_and_tail204_over_five_pages');
 await nav('月度排程');const monthly=await collect();assert.equal(monthly.length,2436);
 for(let i=0;i<203;i++)for(let m=1;m<=12;m++){const unit=i===202?2:1,total=unit*12;assert.deepEqual(monthly[i*12+m-1].slice(0,10),[rows[i][0],'2026-'+String(m).padStart(2,'0'),'1',unit+'.00',(unit*m)+'.00',(total-unit*m)+'.00','0','203-expenses.csv / CSV / 行'+(i+2),'CNY','元']);}
 await writeFile(out+'/all2436-visible-rows.json',JSON.stringify(monthly));checks.push('2436_all_monthly_rows_every_finance_and_source_cell_manual_expected_49_pages');
 await panel().getByLabel('搜索事项、期间、来源',{exact:true}).fill('ROOT0203');assert.equal(await panel().locator('tbody tr').count(),12);
 await panel().locator('tbody tr').last().getByRole('button',{name:'查看原始台账行'}).click();await p.getByRole('heading',{name:'费用台账',exact:true}).waitFor();assert.equal(await panel().locator('tbody tr').count(),1);assert.equal(await panel().locator('tbody td').nth(14).innerText(),'204');
 checks.push('tail_period_result_direct_jump_to_original_item204');
 await nav('本期底稿');await p.getByLabel('本期期间',{exact:true}).fill('2026-06');await p.getByRole('button',{name:'确认本期计划',exact:true}).click();await p.getByRole('status').filter({hasText:'确认锁定'}).waitFor();
 const confirmed=await collect(1);assert.equal(confirmed.length,203);assert.deepEqual(confirmed[202].slice(0,6),['ROOT0203','2026-06','2.00','203-expenses.csv / CSV / 行204','CNY','元']);
 await nav('变更管理');await p.getByLabel('事项ID',{exact:true}).selectOption('ROOT0203');await p.getByLabel('生效期间',{exact:true}).fill('2026-07');await p.getByLabel('修订总额',{exact:true}).fill('36');await p.getByLabel('变更依据',{exact:true}).fill('根独立虚构追加依据');await p.getByRole('button',{name:'追加变更并重算'}).click();await p.getByRole('status').filter({hasText:'变更已追加'}).waitFor();
 await nav('余额核对');await p.getByLabel('实际事项ID',{exact:true}).selectOption('ROOT0203');await p.getByLabel('实际截至期',{exact:true}).fill('2026-07');await p.getByLabel('实际累计金额',{exact:true}).fill('15');await p.getByLabel('实际更新依据',{exact:true}).fill('根独立虚构账务依据');await p.getByRole('button',{name:'追加实际累计'}).click();await p.getByRole('status').filter({hasText:'实际累计已追加'}).waitFor();
 await panel().getByLabel('搜索事项、期间、来源',{exact:true}).fill('ROOT0203');assert.deepEqual((await panel().locator('tbody tr').first().locator('td').allTextContents()).slice(0,10),['ROOT0203','CNY','元','2026-07','36.00','16.00','15.00','-1.00','21.00','需复核']);
 checks.push('tail_future36_plan16_actual15_difference_negative1_balance21_history2_preserved');
 await nav('方案与导出');const work=await dl('下载含数据方案','full-work.json'),empty=await dl('下载无数据方案','no-data.json'),book=await dl('下载完整底稿XLSX','full-workbook.xlsx'),sched=await dl('下载排程CSV','full-schedule.csv');
 const full=JSON.parse(await readFile(work,'utf8'));assert.equal(full.state.items.length,203);assert.equal(full.state.items[202].total,'24.00');assert.equal(full.state.confirmed[0].lines[202].amount,'2.00');assert.equal(full.state.changes[0].total,'36');assert.equal(full.state.actualUpdates[0].amount,'15.00');
 const wb=new ExcelJS.Workbook();await wb.xlsx.load(await readFile(book) as any);assert.equal(wb.worksheets.length,8);const sheet=wb.getWorksheet('月度排程')!;assert.equal(sheet.rowCount,2437);const actualRows:string[][]=[];sheet.eachRow((r,n)=>{if(n>1)actualRows.push(r.values as string[])});assert.equal(actualRows.length,2436);
 for(let i=0;i<203;i++)for(let m=1;m<=12;m++){const amount=i===202?(m<=6?2:4):1,cum=i===202?(m<=6?2*m:12+4*(m-6)):m,total=i===202?(m<=6?24:36):12;assert.deepEqual(actualRows[i*12+m-1].slice(1,8),[rows[i][0],'2026-'+String(m).padStart(2,'0'),'1',amount+'.00',cum+'.00',(total-cum)+'.00',total+'.00']);}
 assert.equal(wb.getWorksheet('费用原始行')!.rowCount,204);assert.equal(wb.getWorksheet('确认历史')!.rowCount,204);assert.equal(wb.getWorksheet('余额核对')!.rowCount,204);assert.equal((await readFile(sched,'utf8')).split('\r\n').length,2437);
 checks.push('eight_sheet_real_xlsx2436_every_monthly_amount_cumulative_remaining_original203_and_locked203');
 await p.getByLabel('恢复方案',{exact:true}).setInputFiles(empty);await p.getByRole('status').filter({hasText:'方案已恢复'}).waitFor();await nav('月度排程');assert.equal(await panel().locator('tbody tr').count(),0);
 await nav('方案与导出');await p.getByLabel('恢复方案',{exact:true}).setInputFiles(work);await p.getByRole('status').filter({hasText:'历史和来源校验通过'}).waitFor();const restored=await dl('下载含数据方案','restored-work.json');assert.equal(await readFile(restored,'utf8'),await readFile(work,'utf8'));
 checks.push('no_data_clear_and_full203_history_change_actual_restore_byte_exact');
 for(const width of [1440,320]){await p.setViewportSize({width,height:1000});for(const n of ['工作概览','费用台账','摊销规则','月度排程','本期底稿','变更管理','余额核对','来源追溯','方案与导出','使用说明']){await p.locator('main').evaluate(el=>window.scrollTo(0,document.body.scrollHeight));await nav(n);const heading=await p.locator('main h2').boundingBox();assert.ok(heading&&heading.y>=0&&heading.y+heading.height<=1000);assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));}await p.screenshot({path:out+`/viewport-${width}.png`});}
 checks.push('20_long_page_real_navigation_headings_desktop320_no_outer_overflow');
 accept=false;await p.getByRole('button',{name:'退出并清空'}).click();await nav('费用台账');await panel().getByRole('button',{name:'末页',exact:true}).click();assert.equal(await panel().locator('tbody tr').count(),3);accept=true;await p.getByRole('button',{name:'退出并清空'}).click();assert.equal(await panel().locator('tbody tr').count(),0);
 checks.push('cancel_exit_preserves_tail_confirm_exit_clears_work');assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 await writeFile(out+'/result.json',JSON.stringify({passed:true,checks,downloads,html_sha256:sha(await readFile(html)),script_sha256:sha(await readFile('tests/c03-root-repaired-browser.ts')),source_sha256:sha(await readFile('tools/C03-待摊费用排程/src/App.tsx')),fixture_sha256:sha(await readFile(out+'/203-expenses.csv')),errors,requests,scope:'Root independent offline repaired candidate verification; formal/source/website and Windows gates separate',accepted:false},null,2)+'\n');console.log('C03 root repaired browser passed',checks.length);
}catch(e){await writeFile(out+'/failed.json',JSON.stringify({error:String(e),checks,errors,requests},null,2));throw e}finally{await browser.close()}
