// Capture all actual srcdoc content, including content below the iframe viewport.
import {chromium} from 'playwright';import {mkdir,readFile,writeFile} from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';import {openK05Native} from './k05-native-bootstrap';
const out=path.resolve('progress/evidence/K05/0.1.0/site-full-pages');await mkdir(out,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'}),errors:string[]=[],requests:string[]=[],images:any[]=[];
try{
 const native=await openK05Native(browser,out,path.resolve('release/K05/0.1.0'),errors,requests,()=>true),{frame,shell,page}=native;
 await page.getByRole('button',{name:'体验虚构样例',exact:true}).click();
 await page.getByRole('button',{name:'5 · 组别与批准',exact:true}).click();await page.getByLabel('批准当前资料',{exact:true}).check();await page.getByRole('button',{name:'计算存货跌价',exact:true}).click();
 const pages=['工作总览','存货成本','准备变动','净值依据','组别与批准','跌价测算','计提与转回','来源与例外','底稿与恢复'];
 for(const width of [1440,390,320]){
  await shell.setViewportSize({width,height:1000});
  for(let i=0;i<pages.length;i++){
   await page.getByRole('button',{name:String(i+1)+' · '+pages[i],exact:true}).click();
   if(i===8)await page.getByRole('button',{name:'下载虚构样例.xlsx',exact:true}).waitFor();
   const iframe=shell.locator('iframe').first(),before=await iframe.getAttribute('style'),attr=await iframe.getAttribute('height');
   const height=await frame.evaluate(()=>Math.max(document.documentElement.scrollHeight,document.body.scrollHeight));
   try{
    await iframe.evaluate((el,h)=>{const ancestors:any[]=[];for(let parent=el.parentElement;parent;parent=parent.parentElement){ancestors.push([parent,parent.getAttribute('style')]);parent.style.setProperty('overflow','visible','important')} (el as any).__captureStyles=ancestors;el.style.setProperty('height',h+'px','important');el.setAttribute('height',String(h))},height);
    await frame.waitForFunction(h=>innerHeight>=h-2,height);
    await frame.evaluate(()=>window.scrollTo(0,0));
    const rendered=await frame.evaluate(()=>({width:innerWidth,height:innerHeight,scrollHeight:document.documentElement.scrollHeight,overflow:document.documentElement.scrollWidth>innerWidth+2}));
    assert(!rendered.overflow);assert(rendered.height>=height-2);assert(rendered.scrollHeight<=rendered.height+2);
    const file=`site-full-${width}-${i+1}.png`;await iframe.screenshot({path:out+'/'+file});const bytes=await readFile(out+'/'+file);
    images.push({file,requestedWidth:width,page:pages[i],iframeExpandedHeight:height,rendered,sha256:createHash('sha256').update(bytes).digest('hex')});
   }finally{await iframe.evaluate((el,v)=>{for(const [parent,style] of (el as any).__captureStyles||[]){if(style===null)parent.removeAttribute('style');else parent.setAttribute('style',style)}delete (el as any).__captureStyles;if(v.style===null)el.removeAttribute('style');else el.setAttribute('style',v.style);if(v.height===null)el.removeAttribute('height');else el.setAttribute('height',v.height)},{style:before,height:attr})}
  }
 }
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);await writeFile(out+'/result.json',JSON.stringify({passed:true,siteSHA:native.siteSHA,actualRuntimeSHA:native.actualRuntimeSHA,images,errors,requests,scope:'27 actual iframe content screenshots with temporary iframe height equal document content; restored after capture; internal tables remain horizontally scrollable; manual visual review separate'},null,2));console.log(JSON.stringify({passed:true,actualFullContentImages:images.length}));
}finally{await browser.close()}
