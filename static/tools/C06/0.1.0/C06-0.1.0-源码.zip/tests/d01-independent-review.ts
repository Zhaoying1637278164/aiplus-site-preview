import test from 'node:test';
import assert from 'node:assert/strict';
import {example} from '../tools/D01-财务台账合并拆分/src/example';
import {clone,run,plan,restore} from '../tools/D01-财务台账合并拆分/src/engine';
import {readFileData,asTable} from '../packages/core/io';
import {exportWork,exportZip} from '../tools/D01-财务台账合并拆分/src/export';
import ExcelJS from 'exceljs';
import JSZip from 'jszip';

test('independent nine-row ledger answer retains exact origin, currency and period',()=>{
 const state=example(),before=clone(state),result=run(state);
 assert.deepEqual(result.stats,{有效:4,异常:3,重复移出:2,空行移出:0});
 assert.deepEqual(result.rows.filter(r=>r.status==='有效').map(r=>r.id),['S1:2','S1:3','S2:2','S2:3']);
 assert.deepEqual(result.rows.filter(r=>r.status==='异常').map(r=>r.id),['S1:4','S1:5','S2:5']);
 assert.deepEqual(result.rows.filter(r=>r.status==='重复移出').map(r=>[r.id,r.duplicateOf]),[['S1:6','S1:3'],['S2:4','S1:3']]);
 assert.deepEqual(result.groups.map(g=>[g.values,g.rows.map(r=>r.id)]),[
  [['CNY','2026-09','研发 部'],['S1:2']],
  [['CNY','2026-09','销售'],['S1:3']],
  [['USD','2026-09','销售'],['S2:2']],
  [['CNY','2026-08','研发部'],['S2:3']],
 ]);
 assert.equal(result.rows[0].values.金额,'0'); assert.equal(result.rows[1].values.金额,'-2.5');
 assert.equal(result.rows[2].values.金额,null); assert.deepEqual(state,before);
 assert.equal(result.rows.reduce((n,r)=>n+Number(r.status==='有效'),0)+result.stats.异常+result.stats.重复移出+result.stats.空行移出,9);
});

test('conflicting repeated invoice is held as a whole group; retaining duplicates preserves all six valid rows',()=>{
 const conflict=example(); conflict.slots[1].table!.rows[2].cells.数额='-3';
 const held=run(conflict); assert.deepEqual(held.stats,{有效:3,异常:6,重复移出:0,空行移出:0});
 assert.equal(held.rows.filter(r=>r.reasons.includes('相同重复键存在不同目标值，整组待确认')).length,3);
 const retained=example(); retained.removeDuplicates=false;
 assert.deepEqual(run(retained).stats,{有效:6,异常:3,重复移出:0,空行移出:0});
});

test('actual release inputs and workbook use all four categories and do not execute formula cells',async()=>{
 const assets=await import('../tools/D01-财务台账合并拆分/src/release-assets');
 const supplied=await assets.releaseAssets(),state=example();
 for(let i=0;i<2;i++){const file=supplied[i+1],data=await readFileData(file.filename,file.data as Uint8Array);state.slots[i].table=(await import('../tools/D01-财务台账合并拆分/src/input')).tableFrom(data,'台账',1)}
 const result=run(state);assert.deepEqual(result.stats,{有效:4,异常:3,重复移出:2,空行移出:0});
 assert.deepEqual(result.rows[3].source.cells.金额,{formula:'1+1',cached:2});
 const book=new ExcelJS.Workbook();await book.xlsx.load(await exportWork(result) as any);
 assert.deepEqual(book.worksheets.map(s=>s.name),['处理日志','有效','异常','重复移出','空行移出']);
 const valid=asTable(await readFileData('root-export.xlsx',await exportWork(result) as Uint8Array),'有效');
 assert.deepEqual(valid.rows.map(r=>[r.cells.币种,r.cells.期间,r.cells.金额]),[['CNY','2026-09','0'],['CNY','2026-09','-2.5'],['USD','2026-09','10'],['CNY','2026-08','0.1']]);
 const zip=await JSZip.loadAsync(await exportZip(result)); assert.equal(Object.keys(zip.files).length,6);
 const manifest=JSON.parse(await zip.file('分拆清单.json')!.async('string'));
 assert.equal(manifest.contains_data,true);assert.deepEqual(manifest.groups.map((g:any)=>g.rows),[1,1,1,1]);
});

test('no-data plan has a stable schema and restoration cannot retain the previous imported ledger',()=>{
 const current=example(),serialized=JSON.stringify(plan(current));
 assert.equal(JSON.parse(serialized).schema_version,1);assert.equal(JSON.parse(serialized).contains_data,false);
 assert.equal(serialized.includes('A001'),false);const restored=restore(serialized);
 assert.ok(restored.slots.every(s=>s.table===null));assert.throws(()=>run(restored),/未载入/);
 for(const bad of [{schema_version:2},{contains_data:true},{data:['A001']},{rule_version:'unknown'}])
  assert.throws(()=>restore(JSON.stringify({...JSON.parse(serialized),...bad})));
});
