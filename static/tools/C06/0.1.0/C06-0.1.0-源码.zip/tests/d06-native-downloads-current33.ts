import {chromium} from 'playwright';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const host=process.env.AIPLUS_NATIVE_SITE_URL||'http://127.0.0.1:8514';
const release=path.resolve('release/D06/0.2.0'),evidence=path.resolve(process.env.AIPLUS_EVIDENCE_DIR||'progress/evidence/site-integration/D02-D03-D06/D06/downloads');await mkdir(evidence,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
const registered=JSON.parse(await readFile('integration/native-site/site/registry.json','utf8')) as {id:string;replacesOriginal?:boolean}[];
const catalogueTotal=76+registered.filter(e=>!e.replacesOriginal).length,closingTotal=12+registered.filter(e=>['D02','D06','D04','C01','C03'].includes(e.id)).length;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
try{
 const context=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}}),page=await context.newPage();
 const programs:string[]=[];page.on('request',r=>{if(r.url().endsWith('runtime.json'))programs.push(r.url())});
 await page.goto(host,{waitUntil:'domcontentloaded'});const frame=page.frameLocator('iframe').first();
 assert.equal(await frame.locator('.bignum').innerText(),String(catalogueTotal));
 assert.equal(await frame.getByRole('link',{name:`07 结账 ${closingTotal}`,exact:true}).count(),1);
 await frame.locator('.nav a[href="#tools"]').click();assert.equal(await frame.locator('[data-total]').innerText(),String(catalogueTotal));
 await frame.locator('[data-f="mod"][data-v="close"]').click();assert.equal(await frame.locator('[data-total]').innerText(),String(closingTotal));
 const row=frame.locator('[data-tool]').filter({has:frame.getByRole('link',{name:'财务明细核查',exact:true})});
 await row.getByRole('link',{name:'详情',exact:true}).click();await frame.getByRole('heading',{name:'财务明细核查',exact:true}).waitFor();
 assert.equal(programs.length,0);assert.equal(await frame.getByText('工具信息',{exact:true}).count(),1);
 await page.screenshot({path:evidence+'/site-detail-local.png',fullPage:true});
 const labels=['离线工具包','同版本源码','虚构样例（Excel）','空白模板（CSV）','使用说明','财务口径','第三方声明'];
 const names=['D06-0.2.0-离线包.zip','D06-0.2.0-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md'];
 const downloads:Record<string,string>={};
 for(let i=0;i<names.length;i++){
  const pending=page.waitForEvent('download');await frame.getByRole('link',{name:labels[i],exact:true}).click();const file=await pending;
  assert.equal(await file.failure(),null);const target=path.join(evidence,'site-local-downloads',names[i]);await mkdir(path.dirname(target),{recursive:true});await file.saveAs(target);
  downloads[names[i]]=sha(await readFile(target));assert.equal(downloads[names[i]],sha(await readFile(path.join(release,names[i]))));
 }
 execFileSync('python3',['-c','import sys,zipfile,hashlib; archive=zipfile.ZipFile(sys.argv[1]); assert hashlib.sha256(archive.read("D06/index.html")).hexdigest()==sys.argv[2]',path.join(evidence,'site-local-downloads',names[0]),sha(await readFile(release+'/index.html'))]);

 assert.equal(programs.length,0);await writeFile(evidence+'/result.json',JSON.stringify({tool:'D06',version:'0.2.0',html_sha256:sha(await readFile(release+'/index.html')),runtime_sha256:sha(await readFile(release+'/runtime.json')),site_sha256:sha(await readFile('integration/native-site/site/index.html')),downloads,checks:['original_financial_module_and_detail','seven_actual_first_party_downloads_exact_hash','offline_zip_inner_html_same','detail_does_not_load_program'],browser:await browser.version(),scope:'真实本地三款官网；公开官网另验'},null,2));console.log('D06七项实际下载及原详情通过');
}finally{await browser.close()}
