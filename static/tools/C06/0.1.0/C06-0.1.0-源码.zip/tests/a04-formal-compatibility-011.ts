import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
const out=path.resolve('progress/evidence/A04/0.1.1/root-formal-compatibility');await mkdir(out,{recursive:true});
const old=path.resolve('release/A04/0.1.0/虚构完整工作.json'),html=path.resolve('progress/evidence/A04/0.1.1/root-formal-offline/extracted/A04/index.html');
assert.equal(JSON.parse(await readFile(old,'utf8')).app_version,'0.1.0');
const browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
const ctx=await browser.newContext({offline:true,acceptDownloads:true}),p=await ctx.newPage(),requests:string[]=[],errors:string[]=[];
p.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});p.on('pageerror',e=>errors.push(e.message));p.on('dialog',d=>d.accept());
try{
 await p.goto('file://'+html);await p.getByRole('navigation').getByRole('button').nth(8).click();await p.getByLabel('恢复JSON',{exact:true}).setInputFiles(old);await p.getByRole('status').filter({hasText:'已恢复'}).waitFor();
 await p.getByRole('navigation').getByRole('button').nth(5).click();const text=await p.locator('main').innerText();for(const n of ['2000.00','1000.00','CNY','USD'])assert.ok(text.includes(n));
 await p.getByRole('navigation').getByRole('button').nth(8).click();const [dl]=await Promise.all([p.waitForEvent('download'),p.getByRole('button',{name:'下载含数据完整工作',exact:true}).click()]);const dest=out+'/restored-011.json';await dl.saveAs(dest);assert.equal(JSON.parse(await readFile(dest,'utf8')).app_version,'0.1.1');
 assert.deepEqual(requests,[]);assert.deepEqual(errors,[]);await writeFile(out+'/result.json',JSON.stringify({passed:true,actual_offline:true,old_app_version:'0.1.0',new_app_version:'0.1.1',old_work_sha256:createHash('sha256').update(await readFile(old)).digest('hex'),html_sha256:createHash('sha256').update(await readFile(html)).digest('hex'),checks:['formal0.1.0 work restored on formal0.1.1','independent original PV2000/1000 and separated CNY/USD','actual saved work app_version0.1.1'],requests,errors},null,2));console.log('A04 formal compatibility3 passed');
}finally{await browser.close()}
