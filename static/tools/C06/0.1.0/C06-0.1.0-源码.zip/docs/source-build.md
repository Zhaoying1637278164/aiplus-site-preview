# 同版本源码重建

解压对应 D02、D03、D06 或 R01 的同版本源码.zip，在解压目录使用 Node.js 22+：

```sh
npm ci
npm test
npm run typecheck
npm run build -- D02
# D06 源码包也可运行：
npm run build -- D06
```

当前D02输出在 release/D02/0.2.0（下载旧版本源码则以该包内版本为准）。业务、五页React、范围、复核与恢复位于 tools/D02-账表对账/src；program.tsx提供官网挂载出口，main.tsx提供离线入口。受限读写和金额在 packages/core，官网挂载边界在 packages/ui。源码包含锁文件、计算与文件测试、浏览器验收脚本、所有实际浏览器依赖许可通知。没有 node_modules、凭据或业务数据。

浏览器验收先安装开发用 Chromium（`npx playwright install chromium`），再运行 `npm run test:browser`。运行 `npm run test:browser` 检查五页、复核、下载恢复；运行 `npm run test:browser:input` 检查实际CSV/XLSX导入、多页签及表头、分页、筛选、公式拒绝和结果失效。完整门禁以绑定该版本HTML哈希的证据为准，不把任一单独脚本等同完整验收。也可通过 `AIPLUS_CHROME` 指定本机 Chromium可执行文件。开发安装可能需要网络，生成的成品不需要网络。旧tests/browser.ts保留为0.1.0历史程序验证，不用于0.2.0。

D02构建还输出runtime.json，为官网同一业务组件的可信程序包（哈希和体积记录在build-manifest.json）；它不是用户数据文件，也不能用来恢复财务资料。源码重建需同时核对index.html与runtime.json的SHA256。网站按登记读取这一包，在原工作区挂载，不用第二层工具iframe。离线index.html自包含，不读取runtime.json或其他资源。

website/base-index.html和base-manifest.json保留官网原76项结构及参考commit；scripts/site.py生成原生整合暂存。官网相关浏览器脚本需先运行授权官网暂存服务：`npm run test:site:native`核对导航和程序下载，`npm run test:site:input`核对实际导入与离线逐项同结果及工作底稿恢复；默认localhost:8514，可用AIPLUS_NATIVE_SITE_URL覆盖。这是部署整合验证，普通离线源码重建不需要运行Streamlit或访问官网工程。

构建从 ExcelJS 4.4.0 的 lib/exceljs.bare.js 与锁定依赖源码打包，避免其dist内嵌版本无法核验的依赖；fs/crypto接口明确抛错，ExcelJS CSV入口停用，CSV只经过本项目PapaParse受限读取器。注入浏览器Buffer、微任务与事件接口；不加载网络polyfill或在线脚本。ExcelJS的密码/文件系统/CSV接口不在本产品能力中。

Mac Chromium已验证；Windows实机未验证。正式完成状态以progress/STATUS.md与官网验收证据为准。

D06业务与React位于tools/D06-财务明细核查/src；验收脚本tests/d06-browser.ts。D06源码包含D02代码作为受影响回归及构建依赖，不含node_modules或业务数据。

D03业务与React在tools/D03-科目与客商对应关系/src，npm run build -- D03，浏览器tests/d03-browser.ts。D06 0.1.1补充tests/d06-sheet-regression.ts验证多页签及第二行表头；0.1.0旧包保留，不覆盖。

总控可运行 `python3 scripts/verify-source.py release/D02/0.2.0`，在独立临时目录解压本项目源码ZIP、检查必要文件及排除项、离线安装锁定依赖、测试和重建，并比较HTML与runtime.json哈希。该检查记录源码ZIP哈希，不代替官网或离线浏览器验收。

源码包包含 fixtures 中的完全虚构独立输入及预期。生成的工具候选 HTML/runtime 和被替代的 evidence/history 快照保留在工程，但不在每款源码ZIP中重复携带；对应生成与验证脚本仍包含。当前正式公开证据保留。

R01运行 `npm run build -- R01`，源码位于tools/R01-合同开票回款台账；正式断网流程tests/r01-formal-browser.ts。新源码包的source-snapshot.json明确记录本款和稳定回归依赖的逐文件SHA，正在实现的其他工具源码/证据不作为重建依赖。完整目录登记保留，全64目标不变。`scripts/package.py`拒绝重打任何冻结版本；独立重建需核对快照、测试和HTML/runtime字节，不代替真实官网验收。

K01 成本分摊表：`npm run build -- K01` 输出 release/K01/0.1.0。源码含锁文件、公共包、本款全部代码与财务预期、tests/k01-independent-review.ts、tests/k01-formal-browser.ts 和独立16表导出检查；正式离线验证由 runtime 自动生成宿主夹具，无需候选HTML。Windows实机未验证，正式官网验收另行记录。

源码包不重复携带 progress/evidence/site-integration 的整站生成输出；这些原始证据保留在项目证据目录。整站重放脚本、工具源码、共享包、锁文件、测试和独立预期仍包含在源码包中。本款离线与源码验证另有证据。

D04 使用 `npm run build -- D04`。固定 PDF.js 4.10.38 主库及带解码限额补丁的 worker、内部 core-js 3.39.0 许可位于本款 vendor 目录；`catalog/vendor-notices.json` 将实际浏览器输入、完整许可和补丁声明逐文件绑定到 SHA256。构建不读取远程 Worker、字体或 CMap。PDF 与独立预期夹具、本款代码、根独立测试和正式浏览器脚本均随源码提供；运行 `node tests/d04-formal-runner.mjs` 需安装开发浏览器并按本机位置调整脚本内路径，Windows 实机未验证。

源码ZIP也不重复携带已解压的 source/source-rebuild 工作副本、原始平台 WebSocket protobuf、由测试脚本自行生成的超限空白文件，以及其他工具在公开站重复下载的 XLSX 输出。这些原始证据保留在工程；生成脚本、独立预期、结构化回执、测试夹具与当前工具的结果下载仍保留。该规则不改变历史冻结源码ZIP。
