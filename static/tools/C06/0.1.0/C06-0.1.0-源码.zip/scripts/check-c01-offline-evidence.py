"""Check exact revised C01 formal delivery evidence; never grants website acceptance."""
from pathlib import Path
import hashlib, json, zipfile

root = Path.cwd()
release = root / 'release/C01/0.1.0'
evidence = root / 'progress/evidence/C01/0.1.0'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
formal = read(evidence / 'root-formal-command.json')
assert formal['actual_build_exit_code'] == formal['actual_package_exit_code'] == 0
assert formal['files_sha256'] == {f.name: sha(f) for f in release.iterdir() if f.is_file()}
assert (release / 'C01-0.1.0-源码.zip').stat().st_size <= 24 * 1024 * 1024
extract = read(evidence / 'root-formal-offline/extraction.json')
assert extract['offline_zip_sha256'] == sha(release / 'C01-0.1.0-离线包.zip')
with zipfile.ZipFile(release / 'C01-0.1.0-离线包.zip') as z:
    assert z.testzip() is None
    assert set(z.namelist()) == {'C01/' + name for name in extract['files_sha256']}
    for name, digest in extract['files_sha256'].items():
        assert hashlib.sha256(z.read('C01/' + name)).hexdigest() == digest == sha(release / name)
        assert sha(evidence / 'root-formal-offline/extracted/C01' / name) == digest

independent = read(evidence / 'root-revised-independent-command.json')
assert independent['actual_exit_code'] == 0 and independent['groups'] == 7
assert independent['script_sha256'] == sha(root / 'tests/c01-independent-review.ts')
source_review = read(evidence / 'ui-copy-20261004/src-diff-review.json')
for name, digest in source_review['after_src_files'].items():
    assert sha(root / 'tools/C01-月结工作台' / name) == digest
assert independent['source_sha256'] == source_review['src_sha256']

browser = read(evidence / 'root-formal-offline/browser/result.json')
command = read(evidence / 'root-formal-browser-command.json')
assert command['actual_exit_code'] == 0
assert command['script_sha256'] == sha(root / 'tests/c01-formal-browser.ts')
assert command['owner_browser_script_sha256'] == sha(root / 'tools/C01-月结工作台/tests/browser.ts')
assert browser['html_sha256'] == command['formal_html_sha256'] == sha(release / 'index.html')
assert browser['passed'] and browser['offline'] and not browser['errors'] and not browser['requests'] and not browser['writes']
assert len(browser['checks']) == 17 and len(browser['screens']) == 27 and len(browser['downloads']) == 7
for d in browser['downloads']:
    assert sha(Path(d['path'])) == d['sha256'] and Path(d['path']).stat().st_size == d['bytes']
visual = read(evidence / 'root-visual-review.json')
assert visual['actual_review'] and visual['html_sha256'] == sha(release / 'index.html')
assert set(visual['images']) == {Path(f).name for f in browser['screens']}
for f in browser['screens']:
    assert sha(Path(f)) == visual['images'][Path(f).name]

large = read(evidence / 'root-formal-large-records/result.json')
command = read(evidence / 'root-formal-large-records/root-command.json')
assert command['actual_exit_code'] == command['actual_typecheck_exit_code'] == 0
assert command['script_sha256'] == sha(root / command['script'])
assert command['result_sha256'] == sha(evidence / 'root-formal-large-records/result.json')
assert large['passed'] and len(large['checks']) == 7 and not large['errors'] and not large['requests'] and not large['storage_writes']
assert large['html_sha256'] == sha(release / 'index.html')
assert large['expected'] == {'tasks':203, 'evidence':203, 'issues':203, 'logs':406, 'deadline':'2024-02-29', 'unresolved_amount':'41.25', 'null_amounts':51}
assert large['fixture_sha256'] == sha(evidence / 'root-formal-large-records/虚构203任务完整工作.json')
assert all(Path(f).is_file() for f in large['downloads'])

rebuild = read(evidence / 'source-rebuild.json')
command = read(evidence / 'root-source-command.json')
assert command['actual_exit_code'] == command['actual_asset_readback_exit_code'] == 0
# The executed verifier is frozen in this source ZIP. Later independent tool
# requirements in the root verifier do not invalidate its historical bytes.
with zipfile.ZipFile(release / 'C01-0.1.0-源码.zip') as archive:
    assert command['script_sha256'] == hashlib.sha256(archive.read('scripts/verify-source.py')).hexdigest()
assert command['result_sha256'] == sha(evidence / 'source-rebuild.json')
assert rebuild['source_zip_sha256'] == command['source_zip_sha256'] == sha(release / 'C01-0.1.0-源码.zip')
assert len(rebuild['commands']) == 4 and all(c['exit_code'] == 0 for c in rebuild['commands'])
for f in ['index.html', 'runtime.json']:
    assert rebuild['files'][f]['identical'] and rebuild['files'][f]['release_sha256'] == sha(release / f)
assets = read(evidence / 'source-rebuild-assets.json')
assert command['asset_readback_sha256'] == sha(evidence / 'source-rebuild-assets.json')
assert assets['source_zip_sha256'] == rebuild['source_zip_sha256']
assert set(assets['files']) == set(extract['files_sha256'])
for name, row in assets['files'].items():
    assert row['release_sha256'] == sha(release / name)
    assert row['bytes_identical'] or (name.endswith('.xlsx') and row['content_identical_except_created_modified'])
with zipfile.ZipFile(release / 'C01-0.1.0-源码.zip') as z:
    assert z.read('tests/c01-formal-large-records.ts') == (root / 'tests/c01-formal-large-records.ts').read_bytes()

result = {'tool':'C01', 'version':'0.1.0', 'passed_offline_delivery':True,
          'formal_files_sha256':formal['files_sha256'], 'browser_groups':17,
          'independent_groups':7, 'large_record_groups':7, 'source_commands':4,
          'assets_verified':len(assets['files']), 'website_verified':False,
          'windows_verified':False, 'accepted':False}
(evidence / 'root-offline-delivery-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('C01 revised formal offline/source/large-record evidence passed; website acceptance remains separate')
