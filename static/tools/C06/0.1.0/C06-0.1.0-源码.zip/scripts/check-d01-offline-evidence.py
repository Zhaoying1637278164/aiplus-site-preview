"""Check D01's exact formal browser and source rebuild receipts; never marks it accepted."""
from pathlib import Path
import hashlib, json, zipfile

root=Path.cwd(); base=root/'progress/evidence/D01/0.1.0'; release=root/'release/D01/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
browser=read(base/'root-formal-offline/browser/browser.json')
assert browser['passed'] and browser['artifact']=='release/D01/0.1.0/index.html'
assert len(browser['checks'])==17 and browser['errors']==[] and browser['requests']==[]
assert browser['windows']=='unverified'
assert len(list((base/'root-formal-offline/browser/screenshots').glob('*.png')))==28
archive=release/'D01-0.1.0-离线包.zip'; source=release/'D01-0.1.0-源码.zip'
assert archive.is_file() and source.is_file() and source.stat().st_size<=24*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={'D01/'+p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
 for name in ['index.html','runtime.json','THIRD_PARTY_NOTICES.md','参考来源.md','财务规则.md','使用说明.md','空白模板.csv','虚构样例.xlsx','虚构乙台账.xlsx']:
  assert z.read('D01/'+name)==(release/name).read_bytes(),name
rebuild=read(base/'source-rebuild.json')
assert rebuild['tool']=='D01' and rebuild['version']=='0.1.0'
assert len(rebuild['commands'])==4 and all(c['exit_code']==0 for c in rebuild['commands'])
assets=read(base/'source-rebuild-assets.json')
assert assets['source_zip_sha256']==sha(source) and assets['files']
assert all(v['content_identical_except_created_modified'] for k,v in assets['files'].items() if k.endswith('.xlsx'))
assert all(v['bytes_identical'] for k,v in assets['files'].items() if not k.endswith('.xlsx'))
result={'tool':'D01','version':'0.1.0','formal_offline_browser_groups':len(browser['checks']),
 'screenshots':28,'offline_archive_sha256':sha(archive),'source_archive_sha256':sha(source),
 'source_archive_bytes':source.stat().st_size,'source_rebuild_commands':4,
 'formal_release_files':sorted(p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'),
 'website_verified':False,'public_acceptance':False,'windows_verified':False,'accepted':False}
(base/'root-formal-offline/check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('D01 exact formal offline evidence passed; website/public/Windows remain separate gates')
