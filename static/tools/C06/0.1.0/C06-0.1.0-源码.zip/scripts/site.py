"""Generate the native website workspace from trusted program artifacts."""
from pathlib import Path
import base64, hashlib, html, json, re, shutil, subprocess, sys
from urllib.parse import quote

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT.parent/'aiplus-streamlit'
STAGE=ROOT/'integration/native-site'

# Presentation belongs to the original financial catalogue. Product names and
# versions continue to come exclusively from catalog/tools.json.
PRESENTATION={
    'D02': {'module':'close','label':'结账','template':'close-11','original':'对外报送数据核对',
            'description':'会计明细与业务台账按单据和口径核对，逐项追查差异并留存复核底稿'},
    'D03': {'module':'meta','label':'主数据','template':'meta-02','original':'科目主数据维护',
            'description':'分别核对科目、客商和部门的对应关系，处理冲突并追查原始资料'},
    'D06': {'module':'close','label':'结账','template':'close-11','original':'对外报送数据核对',
            'description':'核查本期财务明细的缺失、重复与金额勾稽，逐项追查异常并留存复核底稿'},
    'R01': {'module':'ar','label':'应收','template':'ar-04','original':'开票登记',
            'description':'合同、开票与回款分别维护，明确部分分配，追查未关联记录与余额并导出底稿'},
    'R02': {'module':'ar','label':'应收','template':'ar-03','original':'收入确认排程表',
            'replace_original':True,
            'description':'按已批准的履约口径排程，核对独立账面收入，保留变更、未完成事项和完整底稿'},
    'R03': {'module':'ar','label':'应收','template':'ar-05','original':'回款对账',
            'replace_original':True,
            'description':'核对应收与银行回款，逐项确认部分分配、撤销与退款，追查未核销余额和完整底稿'},
    'R04': {'module':'ar','label':'应收','template':'ar-06','original':'应收账龄分析表',
            'replace_original':True,
            'description':'分别分析应收账龄与逾期，核对截止余额、客户待办和原始来源，导出完整底稿'},
    'R05': {'module':'ar','label':'应收','template':'ar-08','original':'坏账计提表',
            'replace_original':True,
            'description':'按已批准的组合参数或个别评估测算坏账准备，核对账面变动与计提差异'},
    'P01': {'module':'ap','label':'应付','template':'ap-03','original':'采购合同台账',
            'description':'核对采购订单、收货退货与发票红字，追查数量金额差异、明确分配和来源底稿'},
    'P02': {'module':'ap','label':'应付','template':'ap-05','original':'付款计划表',
            'replace_original':True,
            'description':'按未付余额安排部分付款，核对原到期日、13周排程、账户资金限额和来源底稿'},
    'P03': {'module':'ap','label':'应付','template':'ap-03','original':'采购合同台账',
            'description':'明确预付与结算双端额度，确认部分核销与撤销，追查未核销余额、账龄和来源底稿'},
    'P04': {'module':'ap','label':'应付','template':'ap-06','original':'供应商对账',
            'replace_original':True,
            'description':'核对双方期初、增加、付款与期末，确认供应商对应和部分关联，追查差异与来源底稿'},
    'T01': {'module':'fund','label':'资金','template':'fund-04','original':'银行对账台',
            'replace_original':True,
            'description':'核对银行流水与企业日记账，批准部分关联和四类未达，分别编制两侧余额调节底稿'},
    'T02': {'module':'fund','label':'资金','template':'fund-03','original':'银行流水导入归集',
            'description':'按账户和日期核对期初、收支、期末与可用资金，分别复核调拨和来源差异'},
    'T03': {'module':'fund','label':'资金','template':'fund-05','original':'现金流预测表',
            'replace_original':True,
            'description':'按账户期初、实际收支和剩余计划编制13周资金排程，核对缺口、情景和滚动版本'},

    'T05': {'module':'fund','label':'资金','template':'fund-03','original':'银行流水导入归集',
            'description':'逐笔核对借款到账、还本、利息与费用，比较净到账、融资现金成本和有效年化，保留求解残差与来源底稿'},
    'K02': {'module':'cost','label':'成本','template':'cost-02','original':'成本分析看板',
            'description':'按实际产出重建可比标准，分别复核用量、价格、交叉项和账面未解释差额，追查完整成本桥接底稿'},
    'K01': {'module':'cost','label':'成本','template':'cost-03','original':'成本分摊表',
            'replace_original':True,
            'description':'归集来源成本，明确直接归属和分摊动因，复核对象成本、尾差、排除与未分配，追查完整底稿'},
    'T04': {'module':'fund','label':'资金','template':'fund-03','original':'银行流水导入归集',
            'description':'按合同建立原还本付息计划，确认实际本金、利息和费用的逐笔分配，核对余额、后续计息及付款底稿'},
    'T06': {'module':'fund','label':'资金','template':'fund-03','original':'银行流水导入归集',
            'description':'按主体与余额日核对外币资产负债，明确手工汇率、货币性和政策依据，复核敞口、汇兑变化与情景底稿'},
    'K03': {'module':'cost','label':'成本','template':'cost-05','original':'存货台账周转表',
            'replace_original':True,
            'description':'核对期初与完整收发台账，追查截止库存、来源库龄、平均库存和周转底稿'},
    'K04': {'module':'cost','label':'成本','template':'cost-05','original':'存货台账周转表',
            'description':'按同一盘点截止日核对账面与实盘，明确物料单位、重盘与分区，复核盘盈盘亏和来源底稿'},
    'A01': {'module':'asset','label':'固资','template':'asset-02','original':'折旧摊销排程表',
            'replace_original':True,
            'description':'按已确认政策编制固定资产折旧与无形资产摊销，保护已确认历史，复核净值、变更与来源底稿'},
    'K05': {'module':'cost','label':'成本','template':'cost-05','original':'存货台账周转表',
            'description':'核对存货成本、准备变动和净值依据，按批准单项或组别测算跌价，复核计提、转回及来源底稿'},
    'A02': {'module':'asset','label':'固资','template':'asset-03','original':'资产盘点表',
            'replace_original':True,
            'description':'按盘点批次核对资产台账、实盘及明确ID对应，复核差异、重盘选择和完整来源，封存本地批次历史'},
    'A03': {'module':'asset','label':'固资','template':'asset-03','original':'资产盘点表',
            'description':'核对资产账面、截止折摊和处置对价税费，测算部分处置损益，逐项复核分录及完整来源底稿'},
    'A04': {'module':'asset','label':'固资','template':'asset-03','original':'资产盘点表',
            'description':'明确承租人固定付款和折现依据，逐笔测算付款现值、租赁负债与未来变更，保留已确认历史和来源底稿'},
    'D01': {'module':'meta','label':'主数据','template':'meta-02','original':'科目主数据维护',
            'description':'多份财务台账按字段清理后合并或分拆，保留每一行来源，并单列异常、重复和空行'},
    'D04': {'module':'close','label':'结账','template':'close-11','original':'对外报送数据核对',
            'description':'整理财务PDF中的指定表格，逐行复核原文与金额，导出保留页码、坐标和校正依据的底稿'},
    'D05': {'module':'meta','label':'主数据','template':'meta-02','original':'科目主数据维护',
            'description':'复核财务工作簿的公式、引用与模式差异，逐格追查原值和缓存，导出完整检查底稿'},
    'C01': {'module':'close','label':'结账','template':'close-11','original':'对外报送数据核对',
            'description':'按期间安排月结任务和依赖，登记证据与未结事项，复核执行进度并下载封板归档'},
    'C03': {'module':'close','label':'结账','template':'close-11','original':'对外报送数据核对',
            'description':'按受益期间编制待摊费用排程，保护确认历史，复核未来变更、实际已摊与剩余余额'},
    'C02': {'module':'close','label':'结账','template':'close-04','original':'计提预提计算表',
            'replace_original':True,
            'description':'按费用依据和生效规则编制计提与冲回，逐期核对余额、借贷分录、变更和确认历史'},
}

def clean_legacy(source):
    source=re.sub(r'<template id="r-tool-D(?:02|03|06)">.*?</template>', '', source, flags=re.S)
    source=re.sub(r'^\s*var d(?:02|03|06)=document\.createElement\([^\n]+\n', '', source, flags=re.M)
    return source

def native_document(source, entry, files, host_js, fragments=False):
    source=clean_legacy(source)
    assert len(re.findall(r'\bdata-tool\s',source))==76, 'Unexpected original catalogue; inspect before editing'
    identifier=entry['id'];name=html.escape(entry['name']);version=html.escape(entry['version'])
    prefix='app/static/tools/'+identifier+'/'+entry['version']+'/'
    def download(filename,label,classes='btn btn-s btn-sm'):
        asset=ROOT/'release'/entry['id']/entry['version']/filename
        digest=hashlib.sha256(asset.read_bytes()).hexdigest()
        transport=prefix+f'download-{files.index(filename)}.json'
        return f'<a class="{classes}" href="{transport}" data-program-download data-download-sha="{digest}" data-download-bytes="{asset.stat().st_size}" download="{html.escape(filename)}">{html.escape(label)}</a>'
    presentation=PRESENTATION[identifier];module=presentation['module'];label=presentation['label']
    description=presentation['description']
    row=f'''<div class="trow" data-tool data-mod="{module}" data-type="T" data-ai="0" data-q="{name} {description} {label}">
<div class="stack gap8" style="min-width:0"><div class="row gap8" style="flex-wrap:wrap"><a href="#{entry['detailRoute']}" class="rt ink" style="font-size:16px;font-weight:600;margin-right:4px">{name}</a><span class="pill">{label}</span><span class="pill">单点工具</span></div><div style="font-size:14px;color:#3D4250;line-height:1.6">{description}</div></div>
<div class="row gap8"><a href="#{entry['detailRoute']}" class="btn btn-s btn-sm">详情</a><a href="#{entry['workspaceRoute']}" class="btn btn-p btn-sm">在线使用</a></div></div>'''
    marker='<div class="trow" data-tool data-mod="tax"'
    assert marker in source;source=source.replace(marker,row+marker,1)
    source=source.replace('76 个开源工具','77 个工具').replace('76 个工具','77 个工具')
    source=source.replace('data-count="mod:all">76','data-count="mod:all">77').replace('data-total>76','data-total>77')
    source=source.replace('<div class="bignum num">76</div>','<div class="bignum num">77</div>')
    source=re.sub(r'(>)(54)(</span><span style="font-size:15px;font-weight:500">单点工具)',r'\g<1>55\g<3>',source)
    source=re.sub(r'(<a href="#tools-close" class="idx hov">.*?class="num body" style="font-size:15px">)12(</span>)',r'\g<1>13\g<2>',source)
    source=source.replace('data-count="ai:all">76','data-count="ai:all">77').replace('data-count="ai:0">69','data-count="ai:0">70')
    template='r-tool-'+presentation['template']
    original=re.search(r'<template id="'+template+r'">.*?</template>',source,re.S)
    assert original
    detail=original.group().replace(template,'r-'+entry['detailRoute']).replace(presentation['original'],name)
    detail=re.sub(r'<p class="lead">.*?</p>',f'<p class="lead">{description}</p>',detail,flags=re.S)
    detail=detail.replace('<span class="btn is-off" aria-disabled="true">工具包即将上线</span>',f'<a href="#{entry["workspaceRoute"]}" class="btn btn-p">开始账表对账</a>'+download(files[0],'下载离线包','btn btn-s'),1)
    detail=re.sub(r'<a href="https://github\.com/".*?</a>',download(files[1],'下载源码','btn btn-s'),detail,flags=re.S)
    for info_label,value in [('版本',version),('更新日期','2026-10-04' if identifier in ['C02','C03'] else '2026-10-03'),('文件大小',entry['offlineSize'])]:
        pattern=r'('+info_label+r'</span><span style="text-align:right">)[^<]+(</span>)'
        detail=re.sub(pattern,lambda m:m.group(1)+value+m.group(2),detail)
    detail=re.sub(r'<div class="row"(?:(?!</div>).)*?下载次数.*?</div>','',detail,flags=re.S)
    detail=detail.replace('编辑口径说明和规则配置，重新运行即可生效。','在范围与口径页面设置核对字段和金额容差，再生成差异。').replace('口径说明.md','财务规则.md')
    detail=detail.replace('得到「'+name+'」文件夹，放在任意位置。','得到工具文件夹，打开其中的 index.html。')
    detail=detail.replace('导入「示例数据」文件夹中的文件，查看运行结果。','导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。')
    detail=detail.replace('完整的使用说明、口径说明与示例数据随工具包一并提供。','两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。')
    if identifier in ['C02','C03']:
        workflows={'C02':'费用依据、规则与生效期、冲回申请、计划与余额、分录核对、确认与变更、异常追溯、底稿与恢复分别操作。来源与历史全量保留，确认是本地复核快照，不自动入账。','C03':'工作概览、费用台账、摊销规则、月度排程、本期底稿、变更管理、余额核对、来源追溯、方案与导出、使用说明分别操作。计划与实际累计分别核对，已确认历史保留，未来变更须有依据。'}
        detail=detail.replace('开始账表对账','开始计提与冲回' if identifier=='C02' else '开始待摊费用排程').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。',workflows[identifier]).replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','先确认费用性质、期间、规则依据与科目；金额精度与容差分别设置，不换汇、不混加币种单位。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构资料，再按本款模板导入财务台账；确认结果后主动下载底稿和恢复方案。')
    if identifier=='D03':
        detail=detail.replace('开始账表对账','开始核对对应关系').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资料与字典、对应规则、待办处理、来源追查、版本比较、结果底稿分开操作。科目、客商、部门分别核对，冲突与人工确认保留来源。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','在对应规则页面设置类别、范围与生效期，再核对对应关系。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先在工具内体验虚构示例，再导入资料与字典。')
    if identifier=='D06':
        detail=detail.replace('开始账表对账','开始核查明细').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资料及核查范围、核查项目维护、异常待办、来源追查、核查结果与底稿分开操作。复核保留经办依据，异常与未执行项目仍保留。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','按本期期间、币种和单位设置核查范围，再维护检查项目及业务依据。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先在工具内体验虚构样例，再导入本机财务明细。')
    if identifier=='D01':
        detail=detail.replace('开始账表对账','开始整理财务台账').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资料清单、字段对应、清理规则、合并预览、分拆下载、来源追查、方案管理分别操作。支持多文件与多页签，保留原始文件、页签和行号；异常不会被跳过，重复与空行仅按明确规则移出。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','先核对每份资料的表头与目标字段，设置清理方式和复合键，再生成预览。币种、期间和单位保留原值，不作混算。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先下载虚构样例，或导入本机台账；确认字段映射后再运行。').replace('完整的使用说明、口径说明与示例数据随工具包一并提供。','合并与分拆、来源追查和方案管理分步完成。每条结果保留原文件、页签、行号和清理变化，完整底稿可按当前预览下载。')
    if identifier=='D04':
        detail=detail.replace('开始账表对账','开始整理PDF财务表格').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资料与页码、选表与列界、分页表头、校正复核、金额勾稽、导出与恢复分开操作。仅读取文本型PDF；保留原文页码、文字项坐标和校正理由。扫描页明确阻塞，OCR未实现。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','按原PDF设置区域、列界和续页表头；人工确认期间、币种、单位及金额列后复核总计。空值阻塞，零与负数保留，不自动换汇。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先载入工具内虚构PDF，或下载完全虚构财务表.pdf再导入；CSV只说明选表范围结构，Excel样例是独立预期，不作为PDF输入。文字坐标预览不等同原PDF影像。').replace('空白模板（CSV）','选表范围说明（CSV）').replace('虚构样例（Excel）','独立预期样例（Excel）')
    if identifier=='D05':
        detail=detail.replace('开始账表对账','开始检查财务表格').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','工作簿、检查范围、问题定位、模式复核、来源追查、检查底稿、方案管理分为七页。只静态读取公式和保存的缓存，不重算；模式差异、硬编码与循环均为复核线索。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','选择页签与A1范围，设置模式方向、硬编码范围和检查项目。缺缓存不补零，期间、币种、单位保留原表；不自动判断报表平衡或政策适用。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先导入下载的虚构样例.xlsx，再复核原格、公式及缓存；仅接受XLSX，CSV不能保留公式检查资料。命名、动态、结构化与3D等引用明确列为覆盖不足。').replace('2026-10-03','2026-10-04')
    if identifier=='C01':
        detail=detail.replace('开始账表对账','开始安排月结').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','月结总览、期间建档、任务模板、依赖与日程、本期执行、证据管理、未结事项、变更记录、封板与恢复分九页。本机单人记录，保留附件原字节及变更；不提供企业审批或多人同步。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','确认主体、期间、币种、单位和观察日；截止按月末加相对自然日，不自动调整节假日。缺前置、证据或未结事项明确阻塞；封板不改变ERP期间。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先导入虚构任务模板或体验样例，再建立期间。跨期仅复制任务模板，不带完成状态、证据和事项；需主动下载JSON或ZIP才能恢复工作。').replace('2026-10-03','2026-10-04')
    if identifier=='R01':
        detail=detail.replace('开始账表对账','开始维护票款台账').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','合同、开票、回款和关联分配分别维护；查看待处理、客户余额、原始来源与独立收入，保存工作并导出完整底稿。预收款单列，未分配记录保留，不自动判断收入。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','在工作总览设置截止日、本期起点、币种、单位和含税口径，再维护票款及显式分配。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构资料，再分别导入合同、开票、回款、关联分配与独立收入资料。')
    if identifier=='R02':
        detail=detail.replace('开始账表对账','开始收入排程').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','合同与履约事项、排程口径、里程碑、已确认收入、月度排程、变更与调整、异常与底稿分开维护。已确认收入取独立账面资料；履约判断与变更由用户批准，不从开票或回款推导。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','设置收入截止日、已批准排程方法、金额精度和差异容差，再生成排程；冻结历史和变更依据保留。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验虚构合同，再分别导入合同、履约事项、里程碑、独立已确认收入及变更资料。')
    if identifier=='R03':
        detail=detail.replace('开始账表对账','开始回款对账').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','应收单据、银行回款、候选规则、候选与确认、核销与撤销、截止余额与待办、来源与底稿分开维护。只有人工确认且有效的分配影响余额；退款、红字与撤销保留来源和依据。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','明确工作起止日、金额精度和候选规则；容差只产生候选，不调平余额。币种、单位和含税口径分别核对，不自动判断收入。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再分别导入应收单据、银行回款和核销记录。')
    if identifier in ['R04','R05']:
        business = ('截止日未结快照与期初推导分别选择；发生账龄、到期逾期、客户待办、例外来源与版本底稿分别操作。负余额和未知项目单列，不自动计提坏账。' if identifier=='R04' else '应收与账面资料、组合与个别评估、批准参数、计提、准备变动、例外复核与版本底稿分别操作。整个存续期损失参数由用户外部评估批准，不按账龄默认计提。')
        detail=detail.replace('开始账表对账','开始账龄与逾期分析' if identifier=='R04' else '开始坏账计提测算').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。',business).replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','在业务口径页明确截止日、资料范围与已批准参数，再重算；原始资料和版本依据保留。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再按本款模板分别导入本机资料。')
    if identifier in ['P01','P02','P03','P04']:
        starts={'P01':'开始采购三单核对','P02':'开始安排付款计划','P03':'开始预付款核销','P04':'开始供应商对账'}
        business={'P01':'采购订单、收货退货、发票红字、关联分配、核对口径、差异复核与完整底稿分别操作。数量单位换算和价格版本需明确批准，不自动记账或付款。','P02':'应付资料、付款安排、到期排程、账户资金限额、差异复核、版本比较与来源底稿分别操作。原到期日保留，实际已付不再次扣减未付余额，不发起银行付款。','P03':'预付台账、结算资料、人工分配、确认撤销、余额账龄、异常复核与来源底稿分别操作。核销受双端批准额度约束，快照历史不重复扣减，不自动处理退款红字。','P04':'双方资料、往来口径、供应商对应、单据关联、收付衔接、差异复核、版本比较、来源底稿与本地对账单分开操作。方向和对应须批准，部分关联受双端额度约束；流水四项与期末快照分别核对。'}
        detail=detail.replace('开始账表对账',starts[identifier]).replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。',business[identifier]).replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','明确本款业务范围、批准资料和计算口径；金额精度与勾稽容差分别设置，币种单位不转换。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再按本款模板分别导入本机资料。')
    if identifier in ['T01','T02','T03']:
        business={'T03':'预测范围、账户期初、收付款计划、实际收支、预测口径、13周排程、资金缺口与措施、情景比较、版本与滚动、例外复核、来源与底稿分别操作；实际与剩余计划衔接，币种单位分列，缺失期初或未确认覆盖阻塞对应结论。','T01':'银行流水与企业日记账分别导入；批准字段方向、确认部分关联、明确四类未达，核对两侧独立余额和余额调节表。人工依据、撤销、原始来源与完整历史底稿分别保留。','T02':'账户、余额依据、收付款资料、分类与调拨、日结与连续、资金日报、可用资金、异常复核、版本与底稿分别操作。主体、日期、币种与单位分列；受限资金缺失时可用余额显示未知，不自动推断。'}
        detail=detail.replace('开始账表对账',{'T01':'开始银行对账','T02':'开始资金日报','T03':'开始13周资金预测'}[identifier]).replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。',business[identifier]).replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','明确本款业务期间、账户、币种单位、资料范围和批准参数；金额精度与勾稽容差分开，缺失不补零。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再按本款模板分别导入本机资料。')
    if identifier=='A02':
        detail=detail.replace('开始账表对账','开始资产盘点').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','盘点批次、资产台账、盘点记录、ID对应、差异复核、勾稽来源、批次历史、方案底稿分成八页。缺盘保留未盘状态；明确未找到才列盘亏候选；无账面在场的金额未知。封存只表示个人底稿确认，不生成会计处理。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','明确主体、账面期间、盘点截止日、币种单位和字段；重复盘点须有人员依据选择，复核完成后才能封存批次。金额精度与容差分开，不换汇。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先载入完全虚构样例，再分别导入资产台账、盘点记录及ID对应；保留全部原始来源与复核历史。')
    if identifier=='A03':
        detail=detail.replace('开始账表对账','开始资产处置测算').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','处置批次、资产账面、截止折摊、对价税费、部分处置、损益复核、分录与来源、方案与底稿分成八页。按企业确认的折摊、税额和科目测算，不自动猜测政策；复核后的完整底稿保留全部来源与剩余账面。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','明确主体、期间、币种单位及适用准则，提供截止折摊与税费依据，确认企业科目并逐项复核处置损益。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先载入完全虚构样例，再分别导入资产账面、处置事项和税费明细。').replace('2026-10-03','2026-10-04')
    if identifier=='A04':
        detail=detail.replace('开始账表对账','开始租赁测算').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','工作概览、资料导入、合同与范围、付款现金流、折现口径、付款现值、负债排程、固定付款变更、异常与底稿分成九页。只测算承租人已确定固定净付款；已确认历史保留，复杂租赁条件阻塞，不自动判断利率或生成会计分录。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','确认中国新租赁准则适用、税费已分拆、固定付款及折现依据；明确利率口径、日数基础、复利频率和金额精度，容差单独设置。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再分别导入合同和付款；按日期复核逐笔现值、负债和已确认历史。').replace('2026-10-03','2026-10-04')
    if identifier=='A01':
        detail=detail.replace('开始账表对账','开始折摊排程').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资产建档、政策、期初、逐期排程、追加减值处置、未来变更、历史、余额与来源分开操作，提供完整十一页签底稿。本款支持固定资产和无形资产；长期待摊费用由对应费用排程工具承接，不从资产排程推导。税法排程尚未实现。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','确认执行企业会计准则、方法和生效月；金额精度与余额核对容差分别设置。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先载入完全虚构资料，再分别导入资产、事件、逐月工作量与账面净值资料。').replace('2026-10-03','2026-10-04')
    package_block=r'<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:8px">工具包内容</div>.*?</div>\s*(?=<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:4px">相关工具)'
    labels=['离线工具包','同版本源码','虚构样例（Excel）','空白模板（CSV）','使用说明','财务口径','第三方声明']
    labels.extend(filename.removesuffix('.csv')+'（CSV）' if filename.endswith('.csv') else filename for filename in files[len(labels):])
    links=''.join('<div style="padding:6px 0">'+download(f,label,'tl')+'</div>' for f,label in zip(files,labels))
    replacement='<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:8px">下载与说明</div>'+links+'</div>\n'
    detail,matched=re.subn(package_block,lambda _:replacement,detail,flags=re.S);assert matched==1
    if identifier=='D04':
        detail=detail.replace('空白模板（CSV）','选表范围说明（CSV）').replace('虚构样例（Excel）','独立预期样例（Excel）')
    if identifier=='D05':
        detail=detail.replace('空白模板（CSV）','空白模板（Excel）')
    if identifier=='T05':
        detail=detail.replace('开始账表对账','开始融资成本比较').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','比较范围、方案台账、条款与费用、现金流资料、成本比较、求解与来源、方案与底稿分别操作。按借款人现金流比较净到账、现金成本和有效年化，保留原始来源、候选根及NPV残差；非正常现金流不输出单一利率结论。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','设置比较期间、币种单位、折现率、年基准与搜索范围；逐笔核对到账、还本、利息、费用和退款。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构融资方案，再导入本机现金流CSV或XLSX。')
    if identifier=='K01':
        detail=detail.replace('开始账表对账','开始成本分摊').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','成本归集、直接归属、成本对象、分摊动因、分配规则、运行复核、来源明细、方案与底稿分别操作。来源成本拆成直接、分摊、排除及未分配；缺依据不强分，逐池核对尾差及来源。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','确定主体、期间、币种单位，明确直接归属与分摊动因、红冲、零分母和尾差规则，运行后复核未分配及排除项。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构四表样例，再分别导入成本、对象、动因和规则资料。')
    if identifier=='K02':
        detail=detail.replace('开始账表对账','开始成本差异分析').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','工作总览、标准成本、实际产出、实际耗用、对象对应、可比口径、差异桥接、来源与例外、底稿与恢复分别操作。按实际产出重建允许量，逐笔耗用重建成本；价量交叉和精度残差明确列示，独立账面差额不强行归因。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','确认四表的主体、期间、币种单位及对象对应，批准可比依据、生效期、分解顺序和容差，分别复核价格、用量和未解释差额。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构成本四表样例，再导入标准成本、实际产出、实际耗用和对象对应资料。')
    if identifier=='T06':
        detail=detail.replace('开始账表对账','开始外币敞口与汇兑测算').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','工作范围、外币余额、手工汇率、货币性复核、币种敞口、期末汇兑、汇率情景、差异来源和完整底稿分别操作。普通损益需批准中国准则适用与可兑换性，特殊及未知政策单列阻塞；管理抵销不改变会计汇兑。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','明确主体、余额日、本位币、金额精度和政策依据；逐笔确认分类和报价方向。币种数量分列，保留舍入尾差与冲回来源。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再分别导入外币余额、期末汇率和情景资料；不提供在线汇率。')
    if identifier=='K03':
        detail=detail.replace('开始账表对账','开始存货库龄与周转').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资料导入、分析规则、收发台账、截止库存、库龄分布、周转分析、呆滞明细、异常复核、底稿与恢复分别操作。按主体、仓库、物料、币种与单位独立核对，保留原入库日期、FIFO估算标识、未知来源和完整十张底稿。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','确认完整期间台账及账面成本，设置基准期间、平均库存、库龄区间与量额容差；退货与红字需实际依据和本期间原单，不自动换汇或判断减值。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再分别导入期初库存层、期间收发台账及可选截止核对表；本期无收发须明确确认。')
    if identifier=='K04':
        detail=detail.replace('开始账表对账','开始存货盘点核对').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','盘点范围、账面存货、实盘清单、物料与单位、重复盘点、盘盈盘亏、财务复核、盘点底稿、使用说明与模板分别操作。重盘须批准唯一记录，分区须明确全部来源；缺侧不补零，未可靠计价单列，保留完整十二张底稿。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','确认主体、仓库、截止日、币种及范围依据；单位换算和估计单价须显式有依据，数量容差与金额精度分别设置。不自动调整库存或生成凭证。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构盘点资料，再分别导入账面存货和实盘清单；按需导入编码对应、单位换算和估计单价。')
    if identifier=='K05':
        detail=detail.replace('开始账表对账','开始存货跌价测算').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','工作总览、存货成本、准备变动、净值依据、组别与批准、跌价测算、计提与转回、来源与例外、底稿与恢复分别操作。净额输入加回准备还原成本；处置与转回分列，缺少因素消失依据保留待依据差额，十五张底稿保留全部来源。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','确认中国企业会计准则适用、主体期间、币种单位及净值政策依据；合同与一般售价分别填写数量、完工成本、销售费用和税费，批准单项或组别后复核计提及转回上限。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构三表样例，再分别导入存货成本、准备变动和净值依据；换资料后重新批准计算。')
    workspace=f'''<template id="r-{entry['workspaceRoute']}"><section class="sec" style="padding:28px 0 72px"><div class="wrap stack gap20"><nav aria-label="面包屑" class="row gap8 small"><a href="#tools">工具库</a><span>/</span><a href="#tools-{module}">{label}</a><span>/</span><a href="#{entry['detailRoute']}">{name}</a></nav><div id="tool-workspace"></div></div></section></template>'''
    registry={k:entry[k] for k in ['id','name','version','detailRoute','workspaceRoute','runtime','sha256','bytes']}
    if fragments:return row,detail+workspace,registry
    registration=json.dumps([registry],ensure_ascii=False).replace('<','\\u003c')
    injection=detail+workspace+'<script>window.__AIPlusRegistry='+registration+';</script><script>'+host_js.replace('</script','<\\/script')+'</script>\n'
    marker='<script>\nwindow.__initTools';assert marker in source;source=source.replace(marker,injection+marker,1)
    old="function go(h){PREV=CUR||'home';CUR=h;render()}"
    new="function go(h){if(h===CUR)return;if(window.__AIPlusHost&&!window.__AIPlusHost.requestExit())return;PREV=CUR||'home';CUR=h;render()}"
    assert old in source;source=source.replace(old,new,1)
    marker="  app.innerHTML='';app.appendChild(t.content.cloneNode(true));"
    assert marker in source;source=source.replace(marker,"  if(window.__AIPlusHost)window.__AIPlusHost.dispose();\n"+marker,1)
    marker='  wireForms();'
    replacement=marker+"\n  if(window.__AIPlusHost&&window.__AIPlusHost.hasRoute(rid)){window.__AIPlusHost.open(rid,document.getElementById('tool-workspace'),function(){go('"+entry['detailRoute']+"')})}"
    assert marker in source;source=source.replace(marker,replacement,1)
    source=source.replace("tool:'tools',course:","tool:'tools',work:'tools',course:",1)
    marker='  hdr.hidden=admin;ftr.hidden=admin;'
    assert marker in source;source=source.replace(marker,marker+"\n  if(bar)bar.hidden=window.__AIPlusHost.hasRoute(rid);",1)
    source=source.replace("var CUR='',PREV='home';","var CUR=window.__AIPlusInitialRoute||'',PREV='home';",1)
    source=source.replace('data-count="mod:close">12','data-count="mod:close">13')
    source=source.replace('window.scrollTo(0,0)',"window.scrollTo({top:0,behavior:'instant'})")
    # Reserve the sticky website header when native tools scroll/focus controls.
    # Scope to work routes; keep the original catalogue/detail scroll behavior.
    css="html.ai-plus-workspace{scroll-behavior:auto;scroll-padding-top:88px}@media(max-width:720px){html.ai-plus-workspace{scroll-padding-top:76px}}"
    source=source.replace('</style>',css+'</style>',1)
    anchor='  hdr.hidden=admin;ftr.hidden=admin;'
    source=source.replace(anchor,anchor+"\n  document.documentElement.classList.toggle('ai-plus-workspace',window.__AIPlusHost.hasRoute(rid));",1)

    assert len(re.findall(r'\bdata-tool\s',source))==77
    assert 'link03' not in source and 'link06' not in source and 'link.textContent=\'D02' not in source
    return source

def native_documents(source, entries, file_sets, host_js):
    assert entries and entries[0]['id']=='D02', 'Keep the accepted D02 delivery'
    assert len({e['id'] for e in entries})==len(entries), 'Duplicate program registration'
    result=native_document(source,entries[0],file_sets[0],host_js)
    if len(entries)==1:return result
    registry=[{k:entries[0][k] for k in ['id','name','version','detailRoute','workspaceRoute','runtime','sha256','bytes']}]
    for entry,files in zip(entries[1:],file_sets[1:]):
        row,templates,registration=native_document(source,entry,files,host_js,fragments=True)
        module=PRESENTATION[entry['id']]['module']
        # Add the financial product within its original module; preserve the
        # existing broader platform entries and their implementation status.
        markers={'meta':'<div data-empty hidden','close':'<div class="trow" data-tool data-mod="tax"','ar':'<div class="trow" data-tool data-mod="ap"','ap':'<div class="trow" data-tool data-mod="exp"','fund':'<div class="trow" data-tool data-mod="cost"','cost':'<div class="trow" data-tool data-mod="asset"','asset':'<div class="trow" data-tool data-mod="tax"'}
        assert module in markers, 'Module placement needs review'
        marker=markers[module]
        assert marker in result
        if PRESENTATION[entry['id']].get('replace_original'):
            route='#tool-'+PRESENTATION[entry['id']]['template']
            anchor=result.index('href="'+route+'"')
            start=result.rfind('<div class="trow" data-tool',0,anchor)
            assert start>=0
            depth=0;end=None
            for match in re.finditer(r'<div\b[^>]*>|</div>',result[start:]):
                depth+=-1 if match.group()=='</div>' else 1
                if depth==0:end=start+match.end();break
            assert end is not None
            result=result[:start]+row+result[end:]
            original='r-tool-'+PRESENTATION[entry['id']]['template']
            result,removed=re.subn(r'<template id="'+original+r'">.*?</template>','',result,count=1,flags=re.S)
            assert removed==1
        else:
            result=result.replace(marker,row+marker,1)
        result=result.replace('<script>window.__AIPlusRegistry=',templates+'<script>window.__AIPlusRegistry=',1)
        registry.append(registration)
        if not PRESENTATION[entry['id']].get('replace_original'):
            result=re.sub(r'(data-count="mod:'+module+r'">)(\d+)',lambda m:m[1]+str(int(m[2])+1),result)
            result=re.sub(r'(<a href="#tools-'+module+r'" class="idx hov">.*?class="num body" style="font-size:15px">)(\d+)(</span>)',lambda m:m[1]+str(int(m[2])+1)+m[3],result)
    registration=json.dumps(registry,ensure_ascii=False).replace('<','\\u003c')
    result=re.sub(r'window\.__AIPlusRegistry=\[.*?\];',lambda _: 'window.__AIPlusRegistry='+registration+';',result,count=1)
    extra=sum(not PRESENTATION[e['id']].get('replace_original') for e in entries)-1;total=77+extra
    result=result.replace('77 个工具',str(total)+' 个工具').replace('data-total>77','data-total>'+str(total)).replace('data-count="mod:all">77','data-count="mod:all">'+str(total)).replace('data-count="ai:all">77','data-count="ai:all">'+str(total)).replace('data-count="ai:0">70','data-count="ai:0">'+str(70+extra)).replace('<div class="bignum num">77</div>','<div class="bignum num">'+str(total)+'</div>')
    result=re.sub(r'(>)(55)(</span><span style="font-size:15px;font-weight:500">单点工具)',lambda m:m[1]+str(55+extra)+m[3],result)
    result=result.replace("function(){go('tool-D02')}","function(){var entry=window.__AIPlusRegistry.find(function(e){return e.workspaceRoute===rid});if(entry)go(entry.detailRoute)}",1)
    assert len(re.findall(r'\bdata-tool\s',result))==total
    return result

def stage_selection(tools, include=()):
    assert len(set(include))==len(include), 'Duplicate tool selection'
    accepted=[t['id'] for t in tools if t['status']=='accepted']
    identifiers=list(dict.fromkeys(['D02',*accepted,*include]))
    assert all(i in PRESENTATION for i in identifiers), 'No reviewed website placement for this tool'
    return sorted(identifiers,key=list(PRESENTATION).index)

def stage(include=()):
    tools=json.loads((ROOT/'catalog/tools.json').read_text())
    # Publishing the next tool must preserve every accepted website entry.
    identifiers=stage_selection(tools,include)
    entries=[];file_sets=[];folders=[]
    for identifier in identifiers:
        tool=next(t for t in tools if t['id']==identifier)
        if identifier=='D02':assert tool['name']=='账表对账'
        if identifier=='D03':assert tool['name']=='科目与客商对应关系', 'Formal product registration must precede staging'
        if identifier=='D06':assert tool['name']=='财务明细核查', 'Formal financial name must precede staging'
        if identifier=='R01':assert tool['name']=='合同开票回款台账', 'Formal financial name must precede staging'
        if identifier=='R02':assert tool['name']=='收入确认排程表', 'Use original financial name'
        if identifier=='R03':assert tool['name']=='回款对账', 'Use original financial name'
        version=tool['version'];folder=ROOT/'release'/identifier/str(version)
        runtime=folder/'runtime.json'
        if not runtime.is_file():raise SystemExit(identifier+' 原生版本runtime.json尚未生成；不使用旧独立页面替代，不修改官网。')
        payload=json.loads(runtime.read_text())
        assert payload['id']==identifier and payload['version']==version and payload['name']==tool['name'] and payload['schema_version']==1
        template_filename='空白模板.xlsx' if identifier=='D05' else '空白模板.csv'
        files=[f'{identifier}-{version}-离线包.zip',f'{identifier}-{version}-源码.zip','虚构样例.xlsx',template_filename,'使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md']
        if identifier=='R01':files+=['开票记录模板.csv','回款记录模板.csv','关联与分配模板.csv','独立收入资料模板.csv']
        if identifier=='R02':files+=['履约事项模板.csv','里程碑模板.csv','已确认收入模板.csv','变更与调整模板.csv']
        if identifier=='R03':files+=['银行回款模板.csv','核销记录模板.csv']
        if identifier in ['C01','C02','C03','D01','D04','D05','R04','R05','P01','P02','P03','P04','T01','T02','T03','T05','K01','K02','T04','T06','K03','K04','K05','A01','A02','A03','A04']:
            files += [p.name for p in sorted(folder.iterdir()) if p.is_file() and p.suffix!='.zip' and p.name not in files and p.name not in ['index.html','runtime.json','build-manifest.json']]
        for filename in files:assert (folder/filename).is_file(),filename
        entries.append({'id':identifier,'name':tool['name'],'version':version,'detailRoute':'tool-'+identifier,'workspaceRoute':'work-'+identifier,'runtime':f'app/static/tools/{identifier}/{version}/runtime.json','sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'bytes':runtime.stat().st_size,'offlineSize':f'{(folder/files[0]).stat().st_size/1024/1024:.1f} MB'})
        if PRESENTATION[identifier].get('replace_original'):
            entries[-1]['detailRoute']='tool-'+PRESENTATION[identifier]['template']
            entries[-1]['replacesOriginal']=True
        file_sets.append(files);folders.append(folder)
    subprocess.run(['node','--import','tsx','scripts/build-site-host.ts'],cwd=ROOT,check=True)
    base=(ROOT/'website/base-index.html').read_bytes()
    baseline=json.loads((ROOT/'website/base-manifest.json').read_text())
    assert hashlib.sha256(base).hexdigest()==baseline['sha256'],'Original website base changed without review'
    expected=[baseline['known_external_index_sha256']]
    deployed=ROOT/'website/deployed-site.json'
    if deployed.is_file():expected.append(json.loads(deployed.read_text())['site_sha256'])
    assert hashlib.sha256((SITE/'site/index.html').read_bytes()).hexdigest() in expected,'Website has unrelated changes; merge them before regeneration'
    source=native_documents(base.decode(),entries,file_sets,(ROOT/'integration/native-host.js').read_text())
    (STAGE/'site').mkdir(parents=True,exist_ok=True);(STAGE/'site/index.html').write_text(source)
    (STAGE/'site/registry.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n')
    app=native_streamlit_app((SITE/'app.py').read_text())
    (STAGE/'app.py').write_text(app);(STAGE/'requirements.txt').write_text('streamlit==1.50.0\n')
    (STAGE/'.streamlit').mkdir(exist_ok=True)
    config=(SITE/'.streamlit/config.toml').read_text()
    if '[server]' not in config:config+='\n[server]\nenableStaticServing = true\n'
    elif not re.search(r'\[server\]\s*enableStaticServing\s*=\s*true',config):raise SystemExit('现有server配置需要核验，不能自动覆盖')
    (STAGE/'.streamlit/config.toml').write_text(config)
    for entry,folder,files in zip(entries,folders,file_sets):
        target=STAGE/'static/tools'/entry['id']/entry['version'];target.mkdir(parents=True,exist_ok=True)
        for file in folder.iterdir():
            if file.is_file():shutil.copy2(file,target/file.name)
        for number,filename in enumerate(files):
            payload={'schema_version':1,'filename':filename,'base64':base64.b64encode((folder/filename).read_bytes()).decode('ascii')}
            (target/f'download-{number}.json').write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':'))+'\n')
    print('原生官网已暂存；尚未发布：',STAGE)

def native_streamlit_app(app,index='site/index.html',registry='site/registry.json'):
    anchor='ROOT = Path(__file__).parent';assert anchor in app
    generated=app[:app.index(anchor)]+'''ROOT = Path(__file__).parent
import json
REGISTRY = json.loads((ROOT / "REGISTRY_PATH").read_text(encoding="utf-8"))
TOOLS = {r["id"]: r for r in REGISTRY}
selected = st.query_params.get("tool", "")
entry = TOOLS.get(selected)
document = (ROOT / "INDEX_PATH").read_text(encoding="utf-8")
if entry:
    initial = json.dumps(entry["workspaceRoute"]).replace("<", "\\\\u003c")
    document = document.replace("<script>window.__AIPlusRegistry", "<script>window.__AIPlusInitialRoute=" + initial + ";</script><script>window.__AIPlusRegistry", 1)
elif selected:
    st.info("该工具尚未开放，请从工具库选择已交付的工具。")
components.html(document, height=900, scrolling=True)
'''
    return generated.replace('REGISTRY_PATH',registry).replace('INDEX_PATH',index)

def apply():
    registry=json.loads((STAGE/'site/registry.json').read_text())
    checker='check-d02-evidence.py' if [e['id'] for e in registry]==['D02'] else 'check-native-evidence.py'
    if len(registry)==26 and registry[-1]['id']=='A03':checker='check-current26-native-evidence.py'
    if len(registry)==27 and registry[-1]['id']=='A04':checker='check-current27-native-evidence.py'
    subprocess.run([sys.executable,str(ROOT/'scripts'/checker)],cwd=ROOT,check=True)
    gate=STAGE/'acceptance.json'
    if not gate.is_file():raise SystemExit('缺少原生官网暂存验收证据，不发布。')
    evidence=json.loads(gate.read_text())
    required=['local_site_navigation','finance_same_results','downloads_hashes','offline','source_rebuild','rendered_product_ui']
    assert all(evidence.get(k) is True for k in required),'Incomplete delivery evidence'
    assert evidence['site_sha256']==hashlib.sha256((STAGE/'site/index.html').read_bytes()).hexdigest(),'Stale website evidence'
    for relative in ['app.py','requirements.txt','site/index.html','site/registry.json','.streamlit/config.toml']:
        target=SITE/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(STAGE/relative,target)
    shutil.copytree(STAGE/'static/tools',SITE/'static/tools',dirs_exist_ok=True)
    (ROOT/'website/deployed-site.json').write_text(json.dumps({'site_sha256':evidence['site_sha256'],'registry_sha256':hashlib.sha256((STAGE/'site/registry.json').read_bytes()).hexdigest()},indent=2)+'\n')
    print('已同步原生官网；须实际公开浏览器验证后才能accepted。')

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'stage'
    if mode=='stage':stage(sys.argv[2:])
    elif mode=='apply':apply()
    else:raise SystemExit('仅支持stage/apply')
