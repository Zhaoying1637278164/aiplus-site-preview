"""Bind A03 actual independent, formal offline, rendering, full-volume and source evidence."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();ev=root/'progress/evidence/A03/0.1.0';release=root/'release/A03/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
tool=next(t for t in read(root/'catalog/tools.json') if t['id']=='A03');assert tool['version']=='0.1.0'
html=sha(release/'index.html');runtime=sha(release/'runtime.json')
indroot=root/'progress/evidence/A03/root-independent';ind=read(indroot/'result.json');cmd=read(indroot/'root-command.json')
assert ind['passed'] and len(ind['checks'])==10 and cmd['actual_exit_code']==0
assert ind['script_sha256']==cmd['script_sha256']==sha(root/'tests/a03-independent-review.ts')
assert cmd['result_sha256']==sha(indroot/'result.json') and ind['engine_sha256']==sha(root/'tools'/tool['folder']/'src/engine.ts')
assert ind['workbook_sha256']==sha(indroot/'root-disposal.xlsx')
unit=read(indroot/'root-unit-command.json');assert unit['actual_exit_code']==0 and unit['tests']==unit['pass']==56
assert read(indroot/'root-typecheck-command.json')['actual_exit_code']==0
src=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json')
assert src['source_zip_sha256']==assets['source_zip_sha256']==sha(release/'A03-0.1.0-源码.zip')
assert len(src['commands'])==4 and all(r['exit_code']==0 for r in src['commands'])
nonzip={f.name for f in release.iterdir() if f.is_file() and f.suffix!='.zip'}
assert set(assets['files'])==nonzip and len(nonzip)==14
for name,row in assets['files'].items():assert row['bytes_identical'] and row['release_sha256']==row['rebuilt_sha256']==sha(release/name)
with zipfile.ZipFile(release/'A03-0.1.0-源码.zip') as z:
 for file in (root/'tools'/tool['folder']/'src').iterdir():
  if file.is_file():
   suffix=str(file.relative_to(root));names=[n for n in z.namelist() if n==suffix];assert len(names)==1
   assert z.read(names[0])==file.read_bytes()
with zipfile.ZipFile(release/'A03-0.1.0-离线包.zip') as z:
 assert set(z.namelist())=={'A03/'+n for n in nonzip}
 for name in nonzip:
  assert z.read('A03/'+name)==(release/name).read_bytes()==(ev/'root-formal-offline/extracted/A03'/name).read_bytes()
off=read(ev/'root-formal-offline/result.json');cmd=read(ev/'root-formal-offline/root-command.json')
assert off['status']=='passed' and off['offline'] and len(off['checks'])==14 and len(off['downloads'])==14
assert cmd['actual_exit_code']==0 and cmd['actual_extracted_zip_execution']
assert cmd['formal_html_sha256']==html and cmd['archive_sha256']==sha(release/'A03-0.1.0-离线包.zip')
assert cmd['script_sha256']==sha(root/'tests/a03-formal-browser.ts') and cmd['result_sha256']==sha(ev/'root-formal-offline/result.json')
assert off['requests']==off['errors']==[] and all(v==0 for v in off['privacy'].values())
for file in off['downloads']:assert (ev/'root-formal-offline'/file).is_file()
def executed(folder,script):
 p=ev/folder;r=read(p/'result.json');c=read(p/'root-command.json')
 assert r['passed'] and c['actual_exit_code']==0 and c['result_sha256']==sha(p/'result.json')
 assert c.get('script_sha256',c.get('test_sha256'))==sha(root/'tests'/script)
 assert r.get('testSHA')==sha(root/'tests'/script) and r['htmlSHA']==html and r['errors']==r['requests']==[]
 return r
render=executed('root-rendered-pages','a03-rendered-pages.ts');review=read(ev/'root-rendered-pages/root-visual-review.json')
assert review['reviewed'] and review['count']==len(render['images'])==27 and review['result_sha256']==sha(ev/'root-rendered-pages/result.json') and review['htmlSHA']==html
assert review['images']=={r['file']:r['sha256'] for r in render['images']}
for row in render['images']:
 assert sha(ev/'root-rendered-pages'/row['file'])==row['sha256'] and not row['rendered']['overflow']
 assert row['before']['headers']==row['before']['navs']==row['before']['main']==1 and row['before']['fixed']==0
 assert row['rendered']['scrollHeight']<=row['rendered']['height']+1
pager=executed('root-formal-pagination','a03-formal-pagination.ts');assert len(pager['checks'])==5
assert pager['workbookSHA']==sha(ev/'root-formal-pagination/A03-诊断草稿.xlsx')
reviewed=executed('root-formal-reviewed-export','a03-formal-reviewed-export.ts');assert len(reviewed['checks'])==3
assert reviewed['fixtureSHA']==sha(ev/'root-formal-pagination/large.json')
assert reviewed['planSHA']==sha(ev/'root-formal-reviewed-export/reviewed400.json')
assert reviewed['exports'][0]['sha256']==sha(ev/'root-formal-reviewed-export/reviewed400.xlsx')
assert reviewed['exports'][0]['reviewRows']==400 and reviewed['exports'][0]['sheets']==12
assert read(ev/'root-formal-reviewed-export/root-typecheck.json')['actual_exit_code']==0
out={'tool':'A03','version':'0.1.0','offline_exact_gates_passed':True,'html_sha256':html,'runtime_sha256':runtime,'unit_tests':56,'independent_finance_groups':10,'source_rebuild_commands':4,'source_identical_assets':14,'formal_offline_groups':14,'actual_reviewed_images':27,'full_volume_groups':5,'actual_individual_reviews':400,'reviewed_export_groups':3,'independent_balanced_journal_stages':1200,'native_verified':False,'public_verified':False,'accepted':False,'windows_real_machine':'unverified','scope':'Root actual independent and formal source/offline evidence; source ZIP includes program baseline, late root QA outside ZIP; website/whole-stage/public gates still required'}
(ev/'offline-delivery-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
