"""Bind only actual terminal0 current25 subprocesses; retain prior root receipts."""
from pathlib import Path
import hashlib,json,shutil
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());site=sha(root/'integration/native-site/site/index.html');ids=[x['id'] for x in read(root/'integration/native-site/site/registry.json')];suite=root/'progress/evidence/site-integration'/'-'.join(ids)
terminal=read(suite/'root-current25-terminal-command.json');assert terminal['actual_exit_code']==0 and terminal['actual_session']==16282 and terminal['site_sha256']==site
rows={}
for name in ['additional-existing-commands.json','final-additions-current25-commands.json','t06-final-stage-additional-commands.json','final-tool-current25-commands.json','k04-current25-commands.json','k05-current25-commands.json','t04-current20-commands.json']:
 p=suite/name;d=read(p);assert d['passed'] and d['site_sha256']==site
 for row in d['results']:
  if row.get('exit_code',row.get('actual_exit_code'))==0:rows[(row['script'],tuple(row.get('args',[])))]=(row,p)
updated=[]
def bind(tool,version,folder,script,args=()):
 row,record=rows[(script,args)];p=root/'progress/evidence'/tool/version/folder/'root-command.json';result=p.parent/'result.json';d=read(result);assert d.get('site_sha256',d.get('siteSHA'))==site
 source=root/'tests'/script;assert row.get('test_sha256',row.get('script_sha256'))==sha(source)
 archive=p.parent/'history/before-current25-binding';archive.mkdir(parents=True,exist_ok=True)
 if p.exists() and not (archive/p.name).exists():shutil.copy2(p,archive/p.name)
 c=read(p) if p.exists() else {};c.update(row);c.update(actual_exit_code=0,actual_session=16282,actual_session_id=16282,actual_parent_session=16282,actual_root_exit_code=0,actual_terminal_chunk='2d19ee',script_sha256=sha(source),test_sha256=sha(source),result_sha256=sha(result),site_sha256=site,parent_subprocess_record=str(record.relative_to(root)),parent_subprocess_record_sha256=sha(record),parent_root_command=str((suite/'root-current25-terminal-command.json').relative_to(root)),scope='Actual current25 subprocess terminal0 bound by parent command group receipt; public acceptance separate')
 p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');updated.append(str(p.relative_to(root)))
for t in ['P04','T01','T02']:
 bind(t,'0.1.0','site-local',t.lower()+'-native-site.ts')
 p=root/'progress/evidence'/t/'0.1.0/site-local/result.json';d=read(p);q=p.parent/'history/before-current25-binding/raw-result.json'
 if not q.exists():q.write_bytes(p.read_bytes())
 d.update(test_sha256=sha(root/'tests'/(t.lower()+'-native-site.ts')),actual_root_exit_code=0,actual_execution_parent_session=16282,actual_execution_parent_terminal_chunk='2d19ee');p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 c=p.parent/'root-command.json';v=read(c);v['result_sha256']=sha(p);c.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
for t in ['T05','K01','K02']:
 bind(t,'0.1.0','site-local',t.lower()+'-native-site.ts');bind(t,'0.1.0',t+'/downloads',t.lower()+'-native-downloads.ts')
for folder,script in [('site-local','t04-native-execution.ts'),('site-financial','t04-native-financial-browser.ts'),('T04/downloads','t04-native-downloads.ts')]:bind('T04','0.2.0',folder,script)
for t in ['T06','K05']:
 folder='site-local' if t=='T06' else 'root-native-business-browser';script='t06-native-site.ts' if t=='T06' else 'k05-native-business-browser.ts';bind(t,'0.1.0',folder,script);bind(t,'0.1.0',t+'/downloads',t.lower()+'-native-downloads.ts')
(suite/'root-current25-binding.json').write_text(json.dumps({'site_sha256':site,'actual_parent_session':16282,'actual_parent_terminal':'2d19ee','updated':updated,'scope':'Actual command receipts only; visual review and gates pending'},indent=2)+'\n');print('Bound',len(updated),'actual current25 receipts')
