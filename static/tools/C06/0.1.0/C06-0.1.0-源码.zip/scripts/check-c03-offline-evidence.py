"""C03 exact formal offline/source gate; public and Windows acceptance separate."""
from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();ev=root/'progress/evidence/C03/0.1.0';release=root/'release/C03/0.1.0';b=ev/'root-formal-offline'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
command=read(b/'root-command.json');large=read(b/'root-browser/result.json');normal=read(b/'standard-browser/result.json')
assert command['actual_exit_code']==0 and command['actual_session']==39377 and command['actual_terminal_chunk']=='c78278'
assert command['script_sha256']==large['script_sha256']==sha(root/'tests/c03-root-repaired-browser.ts')
assert command['standard_script_sha256']==sha(root/'tools/C03-待摊费用排程/tests/browser.ts')
assert large['passed'] and len(large['checks'])==8 and normal['passed'] and len(normal['checks'])==23
assert large['errors']==large['requests']==normal['errors']==normal['requests']==normal['writes']==[]
assert command['html_sha256']==large['html_sha256']==normal['html_sha256']==sha(release/'index.html')
assert command['bulk_result_sha256']==sha(b/'root-browser/result.json') and command['standard_result_sha256']==sha(b/'standard-browser/result.json')
for f,h in large['downloads'].items():assert sha(b/'root-browser/downloads'/f)==h
zip_record=read(b/'zip-members.json');assert zip_record['passed'] and zip_record['zip_sha256']==sha(release/'C03-0.1.0-离线包.zip')
with zipfile.ZipFile(release/'C03-0.1.0-离线包.zip') as z:
 assert set(z.namelist())==set(zip_record['members']) and len(z.namelist())==12
 for n,h in zip_record['members'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h==sha(release/Path(n).name)==sha(b/'extracted'/n)
ind=read(root/'progress/evidence/C03/root-independent/result.json');assert ind['passed'] and ind['actual_exit_code']==0 and ind['tests']==6
for n,h in ind['files'].items():assert sha(root/n)==h
source=release/'C03-0.1.0-源码.zip';assert source.stat().st_size<=24*1024*1024
rebuild=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json');c=read(ev/'root-source-command.json')
assert c['actual_exit_code']==c['actual_asset_readback_exit_code']==0 and c['actual_session']==74368
assert rebuild['source_zip_sha256']==assets['source_zip_sha256']==c['source_zip_sha256']==sha(source)
assert c['result_sha256']==sha(ev/'source-rebuild.json') and c['assets_result_sha256']==sha(ev/'source-rebuild-assets.json')
assert len(rebuild['commands'])==4 and all(x['exit_code']==0 for x in rebuild['commands']) and len(assets['files'])==12
for n,x in assets['files'].items():assert x['release_sha256']==sha(release/n) and (x['bytes_identical'] or n.endswith('.xlsx') and x['content_identical_except_created_modified'])
with zipfile.ZipFile(source) as z:
 assert sum(x.file_size for x in z.infolist())<=250*1024*1024
 for n in ['tools/C03-待摊费用排程/src/engine.ts','tools/C03-待摊费用排程/src/App.tsx','tools/C03-待摊费用排程/tests/engine.test.ts','tools/C03-待摊费用排程/tests/browser.ts','tests/c03-root-independent.test.ts','tests/c03-root-repaired-browser.ts','package-lock.json','packages/core/io.ts','scripts/verify-source.py','scripts/verify-rebuilt-assets.py']:assert z.read(n)==(root/n).read_bytes(),n
 assert c['source_archive_verifier_sha256']==hashlib.sha256(z.read('scripts/verify-source.py')).hexdigest()
assert 'release/C03/0.1.0/index.html' in (release/'使用说明.md').read_text()
result={'passed':True,'formal_offline_groups':8,'standard_browser_groups':23,'independent_financial_tests':6,'source_commands':4,'formal_assets':12,'html_sha256':sha(release/'index.html'),'runtime_sha256':sha(release/'runtime.json'),'source_zip_sha256':sha(source),'offline_zip_sha256':zip_record['zip_sha256'],'accepted':False,'website':'unverified','Windows':'unverified','scope':'Exact offline ZIP actual replay and isolated source reconstruction; no public acceptance'}
(b/'check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
