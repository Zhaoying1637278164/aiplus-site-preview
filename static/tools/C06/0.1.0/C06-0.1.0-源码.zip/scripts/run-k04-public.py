"""Replay unchanged K04 local business/download/full-page assertions publicly."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path.cwd();mode=sys.argv[1];assert mode in ['work','downloads','full']
script={'work':'k04-native-business-browser.ts','downloads':'k04-native-downloads.ts','full':'k04-native-full-pages.ts'}[mode]
base=root/'progress/evidence/K04/0.1.0/site-public'/mode;base.mkdir(parents=True,exist_ok=True)
source=root/'tests'/script;original=source.read_text()
def resolve_import(m):
 return 'from '+json.dumps(str((root/'tests'/m[2]).resolve()),ensure_ascii=False) if m[2].startswith('.') else m[0]
executed=re.sub(r"from (['\"])([^'\"]+)\1",resolve_import,original)
if mode in ['work','full']:
 old='progress/evidence/K04/0.1.0/'+('root-native-business-browser' if mode=='work' else 'site-full-pages')
 assert executed.count(old)==1
 executed=executed.replace(old,str(base))
 if mode=='work':
  old_scope='实际本地Streamlit完成业务验证；后3组另验接口夹具。公开官网与Windows实机未验证'
  assert executed.count(old_scope)==1
  executed=executed.replace(old_scope,'实际公开Streamlit业务验证；后3组另验本地接口夹具。Windows实机未验证')
  trace="downloads.push({label,file:d.suggestedFilename(),bytes:b.length,sha256:"
  assert executed.count(trace)==1
  executed=executed.replace(trace,"const artifact_file='download-'+downloads.length+'-'+d.suggestedFilename();await writeFile(out+'/'+artifact_file,b);downloads.push({label,file:d.suggestedFilename(),artifact_file,bytes:b.length,sha256:")
else:
 target="await page.goto(host);const frame=page.frameLocator('iframe').first();"
 capture="await page.locator('iframe').first().waitFor({timeout:120000});const actualDoc=await page.locator('iframe').first().getAttribute('srcdoc');assert(actualDoc);assert.equal(sha(Buffer.from(actualDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')));await writeFile(out+'/actual-srcdoc.html',actualDoc);"
 assert executed.count(target)==1
 executed=executed.replace(target,target+capture)
 needle="const pending=page.waitForEvent('download');";assert executed.count(needle)==1
 executed=executed.replace(needle,"await page.waitForTimeout(1100);"+needle)
url='https://aiplus-guance.streamlit.app/~/+/'
executed="assert.equal(new URL(process.env.AIPLUS_NATIVE_SITE_URL||'').href,"+json.dumps(url)+");\n"+executed
file=base/'executed-public-validator.ts';file.write_text(executed)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,AIPLUS_NATIVE_SITE_URL=url,AIPLUS_EVIDENCE_DIR=str(base))
record={'mode':mode,'public_url':url,'expected_site_sha256':sha(root/'integration/native-site/site/index.html'),'source_validator_sha256':sha(source),'executed_validator_sha256':sha(file),'native_bootstrap_sha256':sha(root/'tests/k04-native-bootstrap.ts'),'adaptation':'Original finance/restore/storage/file assertions retained. Output paths, absolute relative imports, public limitation metadata, deployed srcdoc capture and download pacing; each work download additionally retained under a unique artifact filename for exact hash readback.'}
with (base/'command.log').open('w') as log:
 result=subprocess.run(['node','--import','tsx',str(file)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record['actual_subprocess_exit_code']=result.returncode
(base/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(mode,'actual subprocess exit',result.returncode,flush=True)
raise SystemExit(result.returncode)
