"""Fresh K03 full pages and K04 readable guide; original assertions retained."""
from pathlib import Path
import json,hashlib,subprocess,shutil
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stage=root/'integration/native-site/site/index.html';digest=sha(stage)
ids=[e['id'] for e in json.loads((stage.parent/'registry.json').read_text())]
assert len(ids)==25 and ids[-5:]==['K03','K04','A01','K05','A02']
suite=root/'progress/evidence/site-integration'/'-'.join(ids)
result={'site_sha256':digest,'passed':False,'results':[]}
for script,tool,folder in [('k03-native-full-pages.ts','K03','site-full-pages'),('k04-native-guide-readable.ts','K04','site-guide-readable')]:
    ev=root/'progress/evidence'/tool/'0.1.0';p=ev/folder;q=ev/'history/before-current25'/folder
    if p.exists() and not q.exists():shutil.copytree(p,q)
    source=root/'tests'/script;log=suite/(script+'.log')
    assert sha(stage)==digest
    print('Executing',script,flush=True)
    with log.open('w') as f:
        run=subprocess.run(['node','--import','tsx',str(source)],cwd=root,stdout=f,stderr=subprocess.STDOUT)
    row={'script':script,'script_path':str(source.relative_to(root)),'test_sha256':sha(source),'exit_code':run.returncode,'log':str(log.relative_to(root))}
    if run.returncode==0:row['result_sha256']=sha(p/'result.json')
    result['results'].append(row);(suite/'visual-regression-commands.json').write_text(json.dumps(result,indent=2)+'\n')
    if run.returncode:raise SystemExit('Failed '+script)
result['passed']=True;(suite/'visual-regression-commands.json').write_text(json.dumps(result,indent=2)+'\n')
print('Both fresh visual regressions passed',flush=True)
