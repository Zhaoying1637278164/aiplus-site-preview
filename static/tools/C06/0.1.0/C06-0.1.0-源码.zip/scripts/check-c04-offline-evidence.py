import runpy,sys
sys.argv=['scripts/check-c04-c05-offline-evidence.py','C04']
runpy.run_path('scripts/check-c04-c05-offline-evidence.py',run_name='__main__')
