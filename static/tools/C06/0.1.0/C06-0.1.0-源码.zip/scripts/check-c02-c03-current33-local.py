"""Fresh exact local native results, downloads and whole offline equality; no public acceptance."""
from pathlib import Path
import hashlib, json, subprocess, sys, zipfile

root = Path.cwd()
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
stage = root / 'integration/native-site'
registry = read(stage / 'site/registry.json')
ids = [r['id'] for r in registry]
assert len(ids) == 33 and ids[-2:] == ['C03', 'C02']
site = sha(stage / 'site/index.html')
suite = root / 'progress/evidence/site-integration' / '-'.join(ids)
parent = read(suite / 'root-current33-commands.json')
terminal = read(suite / 'root-current33-terminal-command.json')
assert parent['passed'] and len(parent['results']) == 29
assert parent['site_sha256'] == terminal['site_sha256'] == site
assert terminal['actual_exit_code'] == 0 and terminal['actual_session'] and terminal['actual_terminal_chunk']
nested = next(r for r in parent['results'] if r['script'] == 'scripts/run-c02-c03-current33-local.py')
assert nested['actual_exit_code'] == 0 and nested['script_sha256'] == sha(root / nested['script'])
run = read(root / 'progress/evidence/site-integration/C02-C03-current33-local/run.json')
assert run['passed'] and run['site_sha256'] == site and len(run['commands']) == 4
assert {c['script'] for c in run['commands']} == {'tests/c03-native-site.ts','tests/c02-native-site.ts','tests/c02-native-workbook.ts','tests/c02-c03-native-downloads.ts'}
for c in run['commands']:
    assert c['exit_code'] == 0 and c['script_sha256'] == sha(root / c['script']) and (root / c['log']).is_file()
downloads_base = root / 'progress/evidence/site-integration/C02-C03-current33-downloads'
downloads = read(downloads_base / 'result.json')
assert downloads['passed'] and downloads['site_sha256'] == site
assert downloads['errors'] == downloads['requests'] == [] and downloads['accepted'] is False
assert downloads['C03_entire_json_and_eight_sheets_same_formal'] is True
equality_script = root / 'tests/c02-c03-native-formal-equality.ts'
equal = subprocess.run(['node','--import','tsx',str(equality_script)], cwd=root, text=True, capture_output=True)
assert equal.returncode == 0, equal.stdout + equal.stderr
for tool in sys.argv[1:] or ['C02', 'C03']:
    release = root / 'release' / tool / '0.1.0'
    ev = root / 'progress/evidence' / tool / '0.1.0'
    result = read(ev / 'site-local/result.json')
    assert result['passed'] and result['site_sha256'] == site
    assert result['html_sha256'] == sha(release / 'index.html')
    assert result['script_sha256'] == sha(root / 'tests' / (tool.lower() + '-native-site.ts'))
    assert result['errors'] == result['requests'] == [] and result['accepted'] is False
    assert len(result['checks']) == len(set(result['checks'])) == (6 if tool == 'C02' else 8)
    if tool == 'C02':
        workbook = read(ev / 'site-workbook/result.json')
        assert workbook['passed'] and workbook['site_sha256'] == site and len(workbook['checks']) == 3
        assert workbook['script_sha256'] == sha(root / 'tests/c02-native-workbook.ts')
        assert workbook['workbook_sha256'] == sha(ev / 'site-workbook/602-workbook.xlsx')
        assert workbook['errors'] == workbook['requests'] == []
    row = next(r for r in downloads['results'] if r['id'] == tool)
    expected = {f.name for f in release.iterdir() if f.is_file() and f.name not in ['index.html','runtime.json','build-manifest.json']}
    assert set(row['downloads']) == expected and row['files'] == len(expected) == (17 if tool == 'C02' else 11)
    for name, digest in row['downloads'].items():
        assert digest == sha(release / name) == sha(downloads_base / tool / name)
    for f in release.iterdir():
        if f.is_file():
            assert sha(stage / 'static/tools' / tool / '0.1.0' / f.name) == sha(f)
    with zipfile.ZipFile(downloads_base / tool / f'{tool}-0.1.0-离线包.zip') as z:
        assert z.read(tool + '/index.html') == (release / 'index.html').read_bytes()
    comparison = read(ev / 'site-local/exact-formal-equality.json')
    assert comparison['passed'] and comparison['site_sha256'] == site
    assert comparison['all_sheets_all_cells_identical'] and comparison['entire_evidence_json_identical']
    assert comparison['worksheets'] == (13 if tool == 'C02' else 8)
    assert comparison['script_sha256'] == sha(equality_script)
    for f, digest in comparison['files'].items():
        assert sha(root / f) == digest
    gate = root / 'scripts' / ('check-c02-current33-offline.py' if tool=='C02' else 'check-c03-offline-evidence.py')
    subprocess.run([sys.executable, str(gate)], check=True)
    (ev / 'site-local/exact-local-audit.json').write_text(json.dumps(dict(passed=True, tool=tool,
        site_sha256=site, actual_parent_session=terminal['actual_session'],
        actual_parent_terminal=terminal['actual_terminal_chunk'],
        result_sha256=sha(ev / 'site-local/result.json'), downloads_sha256=sha(downloads_base / 'result.json'),
        equality_actual_exit_code=equal.returncode, equality_script_sha256=sha(equality_script),
        equality_result_sha256=sha(ev / 'site-local/exact-formal-equality.json'),
        formal_gate_sha256=sha(gate), public_verified=False, accepted=False), indent=2) + '\n')
    print(tool, 'actual native, all downloads and every offline JSON/workbook cell equal; public separate')
