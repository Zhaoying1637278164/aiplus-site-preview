"""Build-only: keep every XLSX member byte and fix ZIP metadata for reproducibility."""
from pathlib import Path
import io,sys,zipfile,hashlib
p=Path(sys.argv[1]);before=p.read_bytes()
with zipfile.ZipFile(io.BytesIO(before)) as original:
    names=original.namelist();assert len(names)==len(set(names))
    members={n:original.read(n) for n in names}
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as arc:
    for n in sorted(names):
        info=zipfile.ZipInfo(n,(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.create_system=0;info.external_attr=0
        arc.writestr(info,members[n],compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(io.BytesIO(buf.getvalue())) as final:
    assert set(final.namelist())==set(names)
    for n in names:assert final.read(n)==members[n]
p.write_bytes(buf.getvalue())
