"""K05 exact local evidence; does not grant whole-site/public acceptance."""
from pathlib import Path
import hashlib, json, zipfile
root=Path.cwd(); ev=root/'progress/evidence/K05/0.1.0'; release=root/'release/K05/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
html=sha(release/'index.html'); runtime=sha(release/'runtime.json'); site=sha(root/'integration/native-site/site/index.html')
ind=read(ev/'root-independent-review.json')
assert ind['passed'] and len(ind['checks'])==8 and ind['exported_financial_cells']==14
assert ind['engine_sha256']==sha(root/'tools/K05-存货跌价测算/src/engine.ts')
assert ind['script_sha256']==sha(root/'tests/k05-independent-review.ts')
src=read(ev/'source-rebuild.json'); assets=read(ev/'source-rebuild-assets.json')
assert src['source_zip_sha256']==sha(release/'K05-0.1.0-源码.zip')==assets['source_zip_sha256']
assert len(src['commands'])==4 and all(c['exit_code']==0 for c in src['commands'])
assert len(assets['files'])==17
for name,row in assets['files'].items():
    assert row['bytes_identical'] and row['release_sha256']==row['rebuilt_sha256']==sha(release/name)
with zipfile.ZipFile(release/'K05-0.1.0-源码.zip') as z:
    for name in ['package-lock.json','docs/source-build.md','packages/core/io.ts','packages/ui/tool-host.ts','tools/K05-存货跌价测算/src/engine.ts','tools/K05-存货跌价测算/src/program.tsx','tests/k05-independent-review.ts']:
        assert name in z.namelist(),name
formal=read(ev/'root-formal-browser/result.json')
assert formal['status']=='passed' and len(formal['checks'])==24 and len(formal['downloads'])==24
assert formal['candidate_sha']==html and formal['runtime_sha']==runtime and formal['errors']==[]
offline=read(ev/'root-formal-zip-browser/result.json')
assert offline['passed'] and offline['indexSHA']==html and offline['errors']==offline['requests']==[]
assert offline['result'][0]['final']=='430' and offline['result'][0]['net']=='1870' and offline['result'][0]['movementCheck']=='0'
native=read(ev/'root-native-business-browser/result.json'); command=read(ev/'root-native-business-browser/root-command.json')
assert native['status']=='passed' and len(native['checks'])==19 and len(native['downloads'])==24
assert native['errors']==native['requests']==[] and native['officialWebsite']
assert native['candidate_sha']==html and native['runtime_sha']==native['actualRuntimeSHA']==runtime and native['siteSHA']==site
assert command['actual_exit_code']==0
if command['actual_session']!=22817:
    record_path=root/command['parent_subprocess_record']
    parent=read(record_path); execution=read(root/command['parent_root_command'])
    assert command['parent_subprocess_record_sha256']==sha(record_path)
    assert parent['passed'] and parent['site_sha256']==site
    assert execution['actual_exit_code']==0 and execution['actual_session']==command['actual_session']
    assert execution['site_sha256']==site
    assert execution['command_groups'][str(record_path.relative_to(root))]==sha(record_path)
    rows=[r for r in parent['results'] if r['script']=='k05-native-business-browser.ts']
    assert len(rows)==1 and rows[0]['exit_code']==0
    assert rows[0]['test_sha256']==command['script_sha256'] and (root/rows[0]['log']).is_file()
assert command['script_sha256']==native['test_sha256']==sha(root/'tests/k05-native-business-browser.ts')
assert command['result_sha256']==sha(ev/'root-native-business-browser/result.json')
assert len({r['artifact_file'] for r in native['downloads']})==24
for r in native['downloads']:
    p=Path(r['artifact_file']); assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
downloads=ev/'K05/downloads'; d=read(downloads/'result.json'); cmd=read(downloads/'root-command.json')
assert d['passed'] and d['clicks']==18 and d['errors']==[]
assert d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime
assert d['test_sha256']==sha(root/'tests/k05-native-downloads.ts') and cmd['actual_exit_code']==0
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==16 and set(d['downloads'])==expected
for name,digest in d['downloads'].items():
    assert sha(downloads/'site-local-downloads'/name)==sha(release/name)==digest
for zp in [release/'K05-0.1.0-离线包.zip',downloads/'site-local-downloads/K05-0.1.0-离线包.zip']:
    with zipfile.ZipFile(zp) as z:
        members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
        assert len(members)==17 and set(z.namelist())=={'K05/'+n for n in members}
        for n in members: assert z.read('K05/'+n)==(release/n).read_bytes()
full=read(ev/'site-full-pages/result.json'); review=read(ev/'site-full-pages/root-rendered-review.json')
assert full['passed'] and len(full['images'])==27 and full['siteSHA']==review['site_sha256']==site
assert full['actualRuntimeSHA']==review['runtime_sha256']==runtime
assert review['result_sha256']==sha(ev/'site-full-pages/result.json') and review['count']==27
for r in full['images']:
    assert r['sha256']==sha(ev/'site-full-pages'/r['file'])==review['reviewed_images'][r['file']]
    assert not r['rendered']['overflow'] and r['rendered']['scrollHeight']<=r['rendered']['height']+2
review=read(ev/'root-formal-offline-visual-review.json')
assert review['actual_review'] and review['count']==27 and review['formal_result_sha256']==sha(ev/'root-formal-browser/result.json')
assert review['html_sha256']==html and review['runtime_sha256']==runtime
for name,digest in review['reviewed_images'].items(): assert sha(ev/'root-formal-browser'/name)==digest
for p in release.iterdir():
    if p.is_file(): assert sha(root/'integration/native-site/static/tools/K05/0.1.0'/p.name)==sha(p)
result={'tool':'K05','version':'0.1.0','local_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'independent_groups':8,'native_groups':19,'native_unique_work_downloads':24,'actual_site_full_images_reviewed':27,'formal_offline_images_reviewed':27,'version_download_clicks':18,'unique_version_files':16,'whole_site_verified':False,'public_verified':False,'accepted':False,'windows_real_machine':'unverified','scope':'Late root native QA scripts are outside frozen source ZIP; rebuilt formal program and17 assets identical. Review covers visible page layout; hidden table columns verified through exports rather than individual visual inspection.'}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
