"""Exact current A03 local same-site evidence; never counts public acceptance."""
from pathlib import Path
import json,hashlib
root=Path.cwd();base=root/'progress/evidence/A03/0.1.0';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();site=sha(root/'integration/native-site/site/index.html');runtime=sha(root/'release/A03/0.1.0/runtime.json')
folders=['root-native-business','root-native-pagination','root-native-reviewed-export','root-native-navigation','site-full-pages','A03/downloads'];results={}
for folder in folders:
 p=base/folder;r=json.loads((p/'result.json').read_text());c=json.loads((p/'root-command.json').read_text());assert c['actual_exit_code']==0 and c['terminal_chunk'] and c['session'];assert c['result_sha256']==sha(p/'result.json');assert c['test_sha256']==sha(root/c['test']);assert c['site_sha256']==site
 assert r.get('siteSHA',r.get('site_sha256'))==site;assert r.get('runtimeSHA',r.get('actualRuntimeSHA',r.get('runtime_sha256')))==runtime
 assert r.get('passed') is True or r.get('status')=='passed';assert r['errors']==[]
 if folder!='A03/downloads':assert r['requests']==[]
 results[folder]=r
b=results['root-native-business'];assert len(b['checks'])==14 and len(b['downloads'])==14;assert b['privacy']['writes']==[]
p=results['root-native-pagination'];assert len(p['checks'])==5
r=results['root-native-reviewed-export'];assert len(r['checks'])==3 and r['exports'][0]['reviewRows']==400 and r['exports'][0]['sheets']==12
assert sha(base/'root-native-reviewed-export'/r['exports'][0]['file'])==r['exports'][0]['sha256'];assert sha(base/'root-native-reviewed-export/reviewed400.json')==r['planSHA']
n=results['root-native-navigation'];assert len(n['geometry'])==24 and len(n['checks'])==6
v=results['site-full-pages'];review=json.loads((base/'site-full-pages/root-visual-review.json').read_text());assert len(v['images'])==24 and review['actual_review'] is True
for image in v['images']:assert sha(base/'site-full-pages'/image['file'])==image['sha256']==review['images'][image['file']]
d=results['A03/downloads'];assert d['clicks']==15 and len(d['downloads'])==13
for f,h in d['downloads'].items():assert sha(root/'release/A03/0.1.0'/f)==h==sha(base/'A03/downloads/site-local-downloads'/f)
registry=json.loads((root/'integration/native-site/site/registry.json').read_text());assert len(registry)==31 and registry[25]['id']=='A03' and registry[26]['id']=='A04' and [r['id'] for r in registry[27:]]==['D01','D04','D05','C01']
typecheck=json.loads((base/'root-native-stage/typecheck-command.json').read_text());assert typecheck['actual_exit_code']==0
for script,h in typecheck['scripts'].items():assert sha(root/script)==h
out={'passed':True,'site_sha256':site,'runtime_sha256':runtime,'tools':31,'actual_local_groups':6,'result_hashes':{f:sha(base/f/'result.json') for f in folders},'public_verified':False,'whole31_regression_passed':False,'accepted':False,'scope':'Exact A03 local original website workflows, full pagination/reviews/export, navigation/downloads and contact-sheet layout review; whole31/public and Windows separately required'}
(base/'native-local-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS A03 six actual local groups; whole31/public still required')
