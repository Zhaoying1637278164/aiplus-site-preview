"""Explicit count-only adaptation for frozen validators on reviewed 16-tool stage.
Original validator source stays immutable; executed bytes are separately recorded.
"""
import pathlib,hashlib,json,tempfile,subprocess,os
root=pathlib.Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def adapted_download(script,args,log):
 source=root/'tests'/script;text=source.read_text();needle="id==='P04'?'9':'7'";assert text.count(needle)==1
 original=text;count=10 if any(e['id']=='T06' for e in json.loads((root/'integration/native-site/site/registry.json').read_text())) else 9 if any(e['id']=='T04' for e in json.loads((root/'integration/native-site/site/registry.json').read_text())) else 8;text=text.replace(needle,"id==='P04'?'9':'"+str(count)+"'")
 text=text.replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
 archive=root/'progress/evidence/shared/current-stage-adapters';archive.mkdir(parents=True,exist_ok=True)
 executed=archive/(script.removesuffix('.ts')+'-fund'+str(count)+'.mts');executed.write_text(text)
 with log.open('w') as handle:r=subprocess.run(['node','--import',str(root/'node_modules/tsx/dist/loader.mjs'),str(executed),*args],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
 return {'script':script,'exit_code':r.returncode,'test_sha256':sha(source),'executed_test_sha256':sha(executed),'executed_test':str(executed.relative_to(root)),'fund_count':count,'adaptation':'fund catalogue count 7 -> '+str(count)+'; absolute Playwright import only; all financial assertions retained'}
def verify_adapter_row(row):
 source=root/'tests'/row['script'];needle="id==='P04'?'9':'7'";text=source.read_text();assert text.count(needle)==1
 count=row.get('fund_count',8);assert count in [8,9,10]
 expected=text.replace(needle,"id==='P04'?'9':'"+str(count)+"'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
 executed=root/row['executed_test'];assert executed.read_text()==expected
 assert row['exit_code']==0 and row['test_sha256']==sha(source) and row['executed_test_sha256']==sha(executed)

def adapted_cost_download(script,log):
 source=root/'tests'/script;original=source.read_text();needle="frame.locator('[data-total]').innerText(),'6'";assert original.count(needle)==1
 count=9 if any(e['id']=='K05' for e in json.loads((root/'integration/native-site/site/registry.json').read_text())) else 8 if any(e['id']=='K04' for e in json.loads((root/'integration/native-site/site/registry.json').read_text())) else 7
 expected=original.replace(needle,"frame.locator('[data-total]').innerText(),'"+str(count)+"'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
 archive=root/'progress/evidence/shared/current-stage-adapters';archive.mkdir(parents=True,exist_ok=True);executed=archive/(script.removesuffix('.ts')+'-cost'+str(count)+'.mts');executed.write_text(expected)
 with log.open('w') as handle:r=subprocess.run(['node','--import',str(root/'node_modules/tsx/dist/loader.mjs'),str(executed)],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
 return {'script':script,'exit_code':r.returncode,'test_sha256':sha(source),'executed_test_sha256':sha(executed),'executed_test':str(executed.relative_to(root)),'cost_count':count,'adaptation':'cost catalogue count 6 -> '+str(count)+'; absolute Playwright import only; all financial assertions retained'}

def verify_cost_adapter_row(row):
 source=root/'tests'/row['script'];needle="frame.locator('[data-total]').innerText(),'6'";original=source.read_text();assert original.count(needle)==1
 count=row.get('cost_count',7);assert count in [7,8,9]
 expected=original.replace(needle,"frame.locator('[data-total]').innerText(),'"+str(count)+"'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
 executed=root/row['executed_test'];assert executed.read_text()==expected and row['exit_code']==0 and row['test_sha256']==sha(source) and row['executed_test_sha256']==sha(executed)

def adapted_t05_download(log):
 source=root/'tests/t05-native-downloads.ts';original=source.read_text();needle="id==='P04'?'9':'8'";assert original.count(needle)==1
 assert any(e['id']=='T04' for e in json.loads((root/'integration/native-site/site/registry.json').read_text()))
 count=10 if any(e['id']=='T06' for e in json.loads((root/'integration/native-site/site/registry.json').read_text())) else 9
 expected=original.replace(needle,"id==='P04'?'9':'"+str(count)+"'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
 archive=root/'progress/evidence/shared/current-stage-adapters';archive.mkdir(parents=True,exist_ok=True);executed=archive/('t05-native-downloads-fund'+str(count)+'.mts');executed.write_text(expected)
 with log.open('w') as handle:r=subprocess.run(['node','--import',str(root/'node_modules/tsx/dist/loader.mjs'),str(executed)],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
 return {'script':'t05-native-downloads.ts','exit_code':r.returncode,'test_sha256':sha(source),'executed_test_sha256':sha(executed),'executed_test':str(executed.relative_to(root)),'fund_count':count,'adaptation':'fund catalogue count 8 -> '+str(count)+'; absolute Playwright import only; all financial assertions retained'}

def verify_t05_adapter_row(row):
 source=root/'tests/t05-native-downloads.ts';original=source.read_text();needle="id==='P04'?'9':'8'";assert original.count(needle)==1
 count=row.get('fund_count',9);assert count in [9,10]
 expected=original.replace(needle,"id==='P04'?'9':'"+str(count)+"'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
 executed=root/row['executed_test'];assert executed.read_text()==expected and row['exit_code']==0 and row['test_sha256']==sha(source) and row['executed_test_sha256']==sha(executed)
