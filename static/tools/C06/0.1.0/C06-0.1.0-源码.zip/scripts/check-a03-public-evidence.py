"""Independent final A03 acceptance gate; factual evidence only, no status mutation."""
from pathlib import Path
import json,hashlib,zipfile,subprocess,sys
from decimal import Decimal
import openpyxl
root=Path.cwd();ev=root/'progress/evidence/A03/0.1.0';pub=ev/'site-public';release=root/'release/A03/0.1.0';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
for script in ['scripts/check-a03-offline-evidence.py','scripts/check-a03-native-local.py','scripts/check-current26-native-evidence.py']:
 r=subprocess.run([sys.executable,script],cwd=root,capture_output=True,text=True)
 assert r.returncode==0,(script,r.stdout,r.stderr)
terminal=read(pub/'root-public-terminal-command.json');commands=read(pub/'root-public-commands.json');assert terminal['actual_exit_code']==0 and terminal['actual_session']==9797 and terminal['actual_terminal_chunk']=='0f9903';assert terminal['commands_sha256']==sha(pub/'root-public-commands.json');assert terminal['script_sha256']==sha(root/'scripts/run-a03-public.py');assert commands['passed'] and len(commands['results'])==5 and commands['site_sha256']==site
folders={'business':'root-native-business','pagination':'root-native-pagination','reviewed-export':'root-native-reviewed-export','full-pages':'site-full-pages','downloads':'A03/downloads'}
for row in commands['results']:
 assert row['actual_exit_code']==0 and row['script_sha256']==sha(root/row['script']) and row['site_sha256']==site and (root/row['log']).is_file()
 name=Path(row['script']).stem.removeprefix('a03-public-');folder=pub/folders[name];result=read(folder/'result.json');assert row['result_sha256']==sha(folder/'result.json');assert result.get('passed',result.get('status')=='passed') and result['errors']==[]
 assert result.get('siteSHA',result.get('site_sha256'))==site;assert result.get('runtimeSHA',result.get('actualRuntimeSHA',result.get('runtime_sha256')))==runtime
 if 'requests' in result:assert result['requests']==[]
 if 'testSHA' in result:assert result['testSHA']==row['script_sha256']
 if 'test_sha256' in result:assert result['test_sha256']==row['script_sha256']
 if 'programs' in result:assert result['programs'] and all(url=='https://aiplus-guance.streamlit.app/~/+/app/static/tools/A03/0.1.0/runtime.json' for url in result['programs'])
 assert read(folder/'root-command.json')['result_sha256']==sha(folder/'result.json')
business=read(pub/'root-native-business/result.json');assert business['url']=='https://aiplus-guance.streamlit.app/~/+/?tool=A03' and business['offline'] and len(business['checks'])==14 and len(business['downloads'])==14 and business['privacy']['writes']==[]
for name in business['downloads']:assert (pub/'root-native-business'/name).is_file()
assert len(read(pub/'root-native-pagination/result.json')['checks'])==5
reviewed=read(pub/'root-native-reviewed-export/result.json');assert len(reviewed['checks'])==3 and reviewed['exports'][0]['sheets']==12 and reviewed['exports'][0]['reviewRows']==400 and reviewed['exports'][0]['journalRows']==2800
for x in reviewed['exports']:assert sha(pub/'root-native-reviewed-export'/x['file'])==x['sha256']
# Re-read the actual public workbook with independent Decimal aggregation, rather than trusting the JS result.
book=openpyxl.load_workbook(pub/'root-native-reviewed-export/reviewed400.xlsx',read_only=True,data_only=False);assert len(book.sheetnames)==12
rows=list(book['处置测算'].values);heads=rows[0];calc=[dict(zip(heads,r)) for r in rows[1:]];assert len(calc)==400 and len({r['处置ID'] for r in calc})==400
assert all(Decimal(r['处置净值'])==Decimal('80.01') and Decimal(r['处置损益'])==Decimal('19.99') and Decimal(r['分配勾稽差'])==0 and '虚构根分页' in r['来源'] for r in calc);assert sum(Decimal(r['处置损益']) for r in calc)==Decimal('7996')
rows=list(book['借贷分录'].values);heads=rows[0];stages={};debit=credit=Decimal(0)
for cells in rows[1:]:
 r=dict(zip(heads,cells));d,c=Decimal(r['借方']),Decimal(r['贷方']);key=(r['处置ID'],r['阶段']);stages[key]=stages.get(key,Decimal(0))+d-c;debit+=d;credit+=c;assert '虚构根分页' in r['来源']
assert len(rows)-1==2800 and len(stages)==1200 and all(x==0 for x in stages.values()) and debit==credit==Decimal('88000');book.close()
nav=pub/'root-native-navigation';n=read(nav/'result.json');receipt=read(nav/'root-command.json');assert receipt['actual_exit_code']==0 and receipt['actual_session']==51193 and receipt['actual_terminal_chunk']=='2d81ef' and receipt['test_sha256']==sha(root/'tests/a03-public-navigation.ts') and receipt['result_sha256']==sha(nav/'result.json');assert n['passed'] and n['siteSHA']==site and n['runtimeSHA']==runtime and len(n['geometry'])==24 and len(n['checks'])==6 and n['errors']==n['requests']==[];assert all(not x['overflow'] and x['header']['bottom']<=x['tool']['y'] and x['tool']['bottom']<=x['footer']['top'] for x in n['geometry'])
full=read(pub/'site-full-pages/result.json');local_review=read(ev/'site-full-pages/root-visual-review.json');assert local_review['actual_review'] and len(full['images'])==24
for x in full['images']:assert x['sha256']==sha(pub/'site-full-pages'/x['file'])==local_review['images'][x['file']] and not x['rendered']['overflow']
d=read(pub/'A03/downloads/result.json');assert d['passed'] and d['clicks']==15 and len(d['downloads'])==13 and d['html_sha256']==html and d['runtime_sha256']==runtime
folder=pub/'A03/downloads/site-local-downloads'
for name,digest in d['downloads'].items():assert sha(folder/name)==sha(release/name)==digest
source=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json');assert source['source_zip_sha256']==sha(folder/'A03-0.1.0-源码.zip') and len(source['commands'])==4 and all(x['exit_code']==0 for x in source['commands']);assert len(assets['files'])==14
for name,row in assets['files'].items():assert row['bytes_identical'] and row['release_sha256']==row['rebuilt_sha256']==sha(release/name)
with zipfile.ZipFile(folder/'A03-0.1.0-离线包.zip') as z:
 expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert len(expected)==14 and set(z.namelist())=={'A03/'+n for n in expected}
 for name in expected:assert z.read('A03/'+name)==(release/name).read_bytes()==(pub/'downloaded-zip-offline/extracted/A03'/name).read_bytes()
offline=read(pub/'downloaded-zip-offline/result.json');c=read(pub/'downloaded-zip-offline/root-command.json');assert c['actual_exit_code']==0 and c['actual_session']==28155 and c['actual_terminal_chunk']=='f5a575' and c['test_sha256']==sha(root/'tests/a03-public-zip-offline.ts') and c['result_sha256']==sha(pub/'downloaded-zip-offline/result.json');assert offline['status']=='passed' and offline['offline'] and len(offline['checks'])==14 and len(offline['downloads'])==14 and offline['requests']==offline['errors']==[]
publication=read(ev/'root-site-push-command.json');assert publication['actual_exit_code']==0 and publication['actual_commit']=='ee43c412c12d672ed463234b21994f9a912c706d' and publication['origin_main_actual_readback']==publication['actual_commit'] and publication['site_sha256']==site
final={'tool':'A03','version':'0.1.0','all_required_gates_passed':True,'public_verified':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':source['source_zip_sha256'],'website_commit':publication['actual_commit'],'rollback_tag':publication['rollback_tag'],'actual_public_workflow_groups':14,'actual_public_large_checks':5,'actual_public_reviewed_checks':3,'independently_reread_reviewed_rows':400,'independently_balanced_stages':1200,'independent_total_debit_credit':'88000','actual_public_download_clicks':15,'unique_public_files':13,'public_whole_images_identical_to_actual_review':24,'actual_public_zip_offline_groups':14,'windows_real_machine':'unverified','scope':'Mac browser actual verification. Late root public QA is outside frozen source ZIP; program/shared rebuild and14 assets identical. Visual scope is layout, not every hidden column/cell.'}
(ev/'site-public-final.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n');print(json.dumps(final,ensure_ascii=False,indent=2))
