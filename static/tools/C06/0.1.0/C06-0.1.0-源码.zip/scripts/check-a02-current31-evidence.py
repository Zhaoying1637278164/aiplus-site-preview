"""Exact A02 delivery evidence; whole-stage and public verification are separate."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();ev=root/'progress/evidence/A02/0.1.0';release=root/'release/A02/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
tool=next(t for t in read(root/'catalog/tools.json') if t['id']=='A02');assert tool['version']=='0.1.0'
indroot=root/'progress/evidence/A02/root-independent';ind=read(indroot/'result.json');cmd=read(indroot/'root-command.json')
assert ind['passed'] and len(ind['groups'])==9 and ind['exportSheets']==12
assert ind['test_sha256']==cmd['script_sha256']==sha(root/'tests/a02-independent-review.ts')
assert cmd['actual_exit_code']==0 and cmd['result_sha256']==sha(indroot/'result.json')
assert ind['workbook_sha256']==sha(indroot/'根独立底稿.xlsx')
unit=read(indroot/'root-unit-typecheck.json');assert unit['unit_actual_exit_code']==unit['isolated_typecheck_exit_code']==0 and unit['unit_tests']==78
src=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json')
assert src['source_zip_sha256']==assets['source_zip_sha256']==sha(release/'A02-0.1.0-源码.zip')
assert len(src['commands'])==4 and all(x['exit_code']==0 for x in src['commands'])
assert len(assets['files'])==18
for name,row in assets['files'].items():assert row['bytes_identical'] and row['release_sha256']==row['rebuilt_sha256']==sha(release/name)
with zipfile.ZipFile(release/'A02-0.1.0-离线包.zip') as z:
 members={f.name for f in release.iterdir() if f.is_file() and f.suffix!='.zip'}
 assert set(z.namelist())=={'A02/'+n for n in members}
 for name in members:assert z.read('A02/'+name)==(release/name).read_bytes()
with zipfile.ZipFile(release/'A02-0.1.0-源码.zip') as z:
 # Financial assertions bind the live reviewed engine to the actual rebuilt source ZIP.
 for name in ['engine.ts','work.ts','export.ts','App.tsx']:
  suffix='tools/'+tool['folder']+'/src/'+name
  paths=[n for n in z.namelist() if n.endswith(suffix)];assert len(paths)==1
  assert z.read(paths[0])==(root/suffix).read_bytes()
off=read(ev/'root-formal-offline/browser/result.json');cmd=read(ev/'root-formal-offline/root-command.json')
assert off['passed'] and len(off['groups'])==15 and len(off['downloads'])==26
assert off['htmlSHA']==html and off['errors']==off['requests']==[]
assert cmd['exit_code']==0 and cmd['test_sha256']==sha(root/'tests/a02-formal-browser.ts')
for row in off['downloads']:assert row['sha256']==sha(ev/'root-formal-offline/browser'/row['file'])
def executed(folder,script):
 p=ev/folder;r=read(p/'result.json');c=read(p/'root-command.json')
 assert r['passed'] and c['actual_exit_code']==0
 assert c['result_sha256']==sha(p/'result.json') and c['script_sha256']==sha(root/'tests'/script)
 assert r['errors']==r['requests']==[] and r['siteSHA']==site
 assert r.get('actualRuntimeSHA',r.get('runtimeSHA'))==runtime
 return r
native=executed('root-native-business-browser','a02-native-business-browser.ts');assert len(native['groups'])==15 and native['htmlSHA']==html
assert native['programs'] and all(u.endswith('/A02/0.1.0/runtime.json') for u in native['programs'])
for row in native['downloads']:assert row['sha256']==sha(ev/'root-native-business-browser'/row['file'])
pager=executed('root-native-pagination','a02-native-pagination.ts');assert len(pager['checks'])==7
for row in pager['downloads']:assert row['sha256']==sha(ev/'root-native-pagination'/row['name'])
assert pager['downloads'][0]['sheets']==12 and pager['downloads'][0]['cardRows']==400 and pager['downloads'][0]['sourceRows']==1200
navigation=executed('root-native-navigation','a02-native-navigation-current31.ts');assert len(navigation['geometry'])==24 and len(navigation['checks'])==6
full=executed('site-full-pages','a02-native-full-pages.ts');review=read(ev/'site-full-pages/root-visual-review.json')
assert len(full['images'])==24 and review['reviewed'] and review['result_sha256']==sha(ev/'site-full-pages/result.json') and review['siteSHA']==site
assert review['images']==full['images']
for row in full['images']:
 assert row['sha256']==sha(ev/'site-full-pages'/row['file']) and not row['rendered']['overflow']
 assert row['rendered']['scrollHeight']<=row['rendered']['height']+2
download=read(ev/'A02/downloads/result.json');cmd=read(ev/'A02/downloads/root-command.json')
assert download['passed'] and download['clicks']==19 and len(download['downloads'])==17
assert cmd['actual_exit_code']==0 and cmd['result_sha256']==sha(ev/'A02/downloads/result.json')
assert cmd['executed_script_sha256']==sha(root/'tests/a02-native-downloads-current31.ts')
assert download['site_sha256']==site and download['runtime_sha256']==runtime
expected={f.name for f in release.iterdir() if f.is_file() and f.name not in ['index.html','runtime.json','build-manifest.json']}
assert set(download['downloads'])==expected
for name,h in download['downloads'].items():assert h==sha(release/name)==sha(ev/'A02/downloads/site-local-downloads'/name)
for f in release.iterdir():
 if f.is_file():assert sha(f)==sha(root/'integration/native-site/static/tools/A02/0.1.0'/f.name)
placement=next(x for x in read(root/'integration/native-site/site/registry.json') if x['id']=='A02')
assert placement['detailRoute']=='tool-asset-03' and placement['replacesOriginal']
out={'tool':'A02','version':'0.1.0','local_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'independent_groups':9,'unit_tests':78,'source_rebuild_commands':4,'source_rebuilt_identical_assets':18,'offline_groups':15,'native_groups':15,'pagination_groups':7,'navigation_geometries':24,'actual_full_images_reviewed':24,'website_download_clicks':19,'website_unique_version_files':17,'whole_site_verified':False,'public_verified':False,'accepted':False,'windows_real_machine':'unverified','visual_scope':'Full page layout; hidden columns proved through complete source pagination and exports; no every-field visual claim'}
(ev/'local-delivery-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))

# Exact count-only current31 adapters; financial assertions remain unchanged.
original=(root/'tests/a02-native-downloads.ts').read_text(); adapted=(root/'tests/a02-native-downloads-current31.ts').read_text()
expected=original.replace("innerText(),'3'","innerText(),'5'").replace('tests/a02-native-downloads.ts','tests/a02-native-downloads-current31.ts').replace('24 registered programs','27 registered programs').replace('three entries','five entries')
assert adapted==expected
original=(root/'tests/a02-native-navigation.ts').read_text(); adapted=(root/'tests/a02-native-navigation-current31.ts').read_text()
expected=original.replace("innerText(),'3'","innerText(),'5'").replace('tests/a02-native-navigation.ts','tests/a02-native-navigation-current31.ts').replace('24 registered programs','27 registered programs').replace('three entries','five entries')
assert adapted==expected
