"""Rerun frozen T03 workflows on current stage; download count adapter explicit."""
import pathlib,json,hashlib,subprocess,runpy,shutil
root=pathlib.Path.cwd();ev=root/'progress/evidence/T03/0.1.0';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ids=[e['id'] for e in json.loads((root/'integration/native-site/site/registry.json').read_text())];assert (len(ids)==16 and ids[-1]=='T05') or (len(ids)==17 and ids[-2:]==['T05','K01']) or (len(ids)==18 and ids[-2:]==['K02','K01']) or (len(ids)==19 and ids[-3:]==['K02','K01','T04']) or (len(ids)==20 and ids[-4:]==['K02','K01','T04','T06']) or (len(ids)==21 and ids[-5:]==['K02','K01','T04','T06','K03']) or (len(ids)==22 and ids[-6:]==['K02','K01','T04','T06','K03','K04']) or (len(ids)==23 and ids[-7:]==['K02','K01','T04','T06','K03','K04','K05']) or (len(ids)==24 and ids[-8:]==['K02','K01','T04','T06','K03','K04','A01','K05']) or ids==['D02','D03','D06','R01','R02','R03','R04','R05','P01','P02','P03','P04','T01','T02','T03','T05','K02','K01','T04','T06','K03','K04','A01','K05','A02']
site=sha(root/'integration/native-site/site/index.html');suite=root/'progress/evidence/site-integration'/'-'.join(ids);suite.mkdir(parents=True,exist_ok=True)
record=ev/'root-native-commands.json';history=ev/'history/before-T05-stage';history.mkdir(parents=True,exist_ok=True)
if not (history/record.name).exists():shutil.copy2(record,history/record.name)
result=json.loads(record.read_text());result['site_sha256']=site;result['current_stage_passed']=False
adapter=runpy.run_path('scripts/current-stage-download-adapter.py')['adapted_download']
for key,script,relative in [('native_work','t03-native-site.ts','site-local/result.json'),('native_supplement','t03-native-supplement.ts','site-local-supplement/result.json'),('native_downloads','t03-native-downloads.ts','all-version-downloads/T03/downloads/result.json')]:
 assert sha(root/'integration/native-site/site/index.html')==site
 log=suite/(script+'.log')
 if key=='native_downloads':row=adapter(script,['T03'],log)
 else:
  with log.open('w') as handle:r=subprocess.run(['node','--import','tsx',str(root/'tests'/script)],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
  row={'script':script,'exit_code':r.returncode,'test_sha256':sha(root/'tests'/script)}
 row.update(script_sha256=sha(root/'tests'/script),validator_sha256=sha(root/'tests'/script),log=str(log.relative_to(root)))
 if row['exit_code']==0:row['result_sha256']=sha(ev/relative)
 result[key]=row;record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(key,row['exit_code'],flush=True)
 if row['exit_code']:raise SystemExit(1)
result['current_stage_passed']=True;record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
