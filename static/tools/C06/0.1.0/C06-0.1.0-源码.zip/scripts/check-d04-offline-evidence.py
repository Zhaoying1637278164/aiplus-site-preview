"""Bind D04 exact formal assets, browser, vendor licenses and isolated rebuild evidence."""
from pathlib import Path
import hashlib,json,zipfile
from urllib.parse import unquote,urlparse
root=Path.cwd();release=root/'release/D04/0.1.0';base=root/'progress/evidence/D04/0.1.0'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=read(base/'root-formal-offline/run.json')
assert run['passed'] and len(run['runs'])==5 and all(r['exit_code']==0 for r in run['runs'])
assert all(sha(root/r['script'])==r['script_sha256'] for r in run['runs'])
assert all(sha(release/n)==h for n,h in run['artifact_sha256'].items())
groups=0
for suite in ['browser','extended-browser','boundaries-browser','native-browser','ui-repair-browser']:
 report=read(base/'root-formal-offline'/suite/('after/result.json' if suite=='ui-repair-browser' else 'result.json'))
 assert report['status']=='passed' and report['requests']==[] and report['errors']==[]
 groups+=len(report['checks'])
 if suite=='browser':assert report['offline'] and urlparse(report['url']).scheme=='file' and Path(unquote(urlparse(report['url']).path))==Path(run['extracted_index'])
assert groups==47
assert read(base/'root-independent/result.json')['tests']==16
source=release/'D04-0.1.0-源码.zip';archive=release/'D04-0.1.0-离线包.zip'
assert sha(archive)==run['offline_archive_sha256'] and sha(Path(run['extracted_index']))==sha(release/'index.html')
assert source.stat().st_size<=24*1024*1024
with zipfile.ZipFile(source) as z:assert sum(i.file_size for i in z.infolist())<=250*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={'D04/'+f.name for f in release.iterdir() if f.is_file() and f.suffix!='.zip'}
 for f in release.iterdir():
  if f.is_file() and f.suffix!='.zip':assert z.read('D04/'+f.name)==f.read_bytes()
notices=(release/'THIRD_PARTY_NOTICES.md').read_text()
manifest=read(release/'build-manifest.json')
assert len(manifest['vendor_dependencies'])==2
for dependency in manifest['vendor_dependencies']:
 assert dependency['name'] in notices
 for item in dependency['runtime_files']+dependency['license_files']:
  assert sha(root/item['path'])==item['sha256']
 for item in dependency['license_files']:assert (root/item['path']).read_text() in notices
rebuild=read(base/'source-rebuild.json');assets=read(base/'source-rebuild-assets.json')
assert rebuild['source_zip_sha256']==assets['source_zip_sha256']==sha(source)
assert len(rebuild['commands'])==4 and all(c['exit_code']==0 for c in rebuild['commands'])
assert all(v['identical'] for v in rebuild['files'].values())
assert all(v.get('bytes_identical') or (k.endswith('.xlsx') and v.get('content_identical_except_created_modified')) for k,v in assets['files'].items())
result={'tool':'D04','version':'0.1.0','groups':groups,'screenshots':len(list((base/'root-formal-offline').rglob('*.png'))),
 'offline_zip_sha256':sha(archive),'source_zip_sha256':sha(source),'source_zip_bytes':source.stat().st_size,
 'artifact_sha256':run['artifact_sha256'],'source_rebuild_commands':4,'formal_assets':len(assets['files']),
 'website_verified':False,'windows_verified':False,'accepted':False}
(base/'root-formal-offline/check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('D04 formal offline, source and vendor evidence passed; website/Windows remain unverified')
