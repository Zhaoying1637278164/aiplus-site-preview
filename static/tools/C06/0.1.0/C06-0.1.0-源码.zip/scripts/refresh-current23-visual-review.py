"""Carry actual prior image review only after fresh capture bytes match exactly."""
from pathlib import Path
import hashlib,json
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
stage=root/'integration/native-site/site/index.html';site=sha(stage)
ids=[e['id'] for e in read(stage.parent/'registry.json')]
assert len(ids)==23 and ids[-1]=='K05'
suite=root/'progress/evidence/site-integration'/'-'.join(ids)
old_suite=suite.parent/'-'.join(ids[:-1]);old=read(old_suite/'rendered-review.json')
assert old['reviewed'] and old['passed'] and old['reviewer']=='Codex actual image inspection'
assert read(suite/'k04-current23-commands.json')['passed']
screens={};changes=[];updates=[]
actual=read(suite/'current23-actual-changed-review.json') if (suite/'current23-actual-changed-review.json').exists() else {}
if actual:assert actual['actual_review'] and actual['reviewer']=='Codex actual image inspection' and actual['site_sha256']==site
for name,digest in old['screenshots'].items():
    fresh=root/name.replace(str(old_suite.relative_to(root)),str(suite.relative_to(root)))
    if not fresh.is_file() or sha(fresh)!=digest:
        name=str(fresh.relative_to(root))
        if fresh.is_file() and actual.get('images',{}).get(name)==sha(fresh):screens[name]=sha(fresh)
        else:changes.append(name)
    else:screens[str(fresh.relative_to(root))]=digest
for tool in ['K01','K02']:
    ev=root/'progress/evidence'/tool/'0.1.0'
    path=ev/('root-visual-review.json' if tool=='K01' else 'site-local/root-visual-review.json')
    review=read(path);assert review['actual_review']
    result=read(ev/'site-local/result.json');assert result['site_sha256']==site
    rows={str(ev/'site-local'/n):d for n,d in review['files'].items()} if tool=='K01' else {str(root/n):d for n,d in {**review['screenshots'],**review['contacts_actually_viewed']}.items()}
    for name,digest in rows.items():
        if not Path(name).is_file() or sha(Path(name))!=digest:changes.append(name)
    review.update(site_sha256=site,current23_basis={'fresh_capture_result_sha256':sha(ev/'site-local/result.json'),'exact_prior_actually_reviewed_bytes':True,'scope':'Only preserved bytes receive carried review; finance workflow rerun separately'})
    updates.append((path,review))
ev=root/'progress/evidence/K04/0.1.0';review=read(ev/'site-full-pages/root-visual-review.json')
full=read(ev/'site-full-pages/result.json');guide=read(ev/'site-guide-readable/result.json')
assert full['siteSHA']==guide['siteSHA']==site and full['passed'] and guide['passed']
for folder,data,key in [('site-full-pages',full,'images'),('site-guide-readable',guide,'guide_readable_clips_viewed')]:
    for row in data['images']:
        p=ev/folder/row['file'];assert sha(p)==row['sha256']
        if review[key].get(row['file'])!=row['sha256']:changes.append(str(p.relative_to(root)))
review.update(site_sha256=site,result_sha256=sha(ev/'site-full-pages/result.json'),guide_readable_clips_result_sha256=sha(ev/'site-guide-readable/result.json'),current23_basis='Fresh actual current23 captures compared with prior actually viewed bytes; exact images only carried')
updates.append((ev/'site-full-pages/root-visual-review.json',review))
ev=root/'progress/evidence/K05/0.1.0/site-full-pages';review=read(ev/'root-rendered-review.json')
assert review['site_sha256']==site and review['count']==27
for name,digest in review['reviewed_images'].items():
    assert sha(ev/name)==digest;screens[str((ev/name).relative_to(root))]=digest
(suite/'pending-current23-visual-review.json').write_text(json.dumps({'site_sha256':site,'exact_prior_images':len(screens)-27-len(actual.get('images',{})),'changed_images_actually_viewed':len(actual.get('images',{})),'new_actual_reviewed_K05_images':27,'changed_or_missing_images_requiring_actual_review':changes},ensure_ascii=False,indent=2)+'\n')
if changes:raise SystemExit('Actual image review required: '+json.dumps(changes,ensure_ascii=False))
for path,data in updates:
    archive=path.parent/'history/before-current23-review';archive.mkdir(parents=True,exist_ok=True)
    if not (archive/path.name).exists():(archive/path.name).write_bytes(path.read_bytes())
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(suite/'rendered-review.json').write_text(json.dumps({'site_sha256':site,'tools':ids,'reviewed':True,'passed':True,'reviewer':'Codex actual image inspection','screenshots':screens,'scope':'Fresh current23 old-tool captures either exact prior actually viewed bytes or six changed images explicitly actually reviewed; K05 actual27 full images directly viewed. Finance calculations independently checked. No review inferred from screenshots count alone.','windows_real_machine':'unverified'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'reviewed_screenshots':len(screens),'changed_images':0,'site_sha256':site}))
