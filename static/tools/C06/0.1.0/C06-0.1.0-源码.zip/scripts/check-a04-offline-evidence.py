"""A04 0.1.1 exact formal offline gate; website acceptance remains separate."""
import hashlib,json,zipfile
from pathlib import Path
from decimal import Decimal
from openpyxl import load_workbook
root=Path.cwd();ev=Path('progress/evidence/A04/0.1.1');rel=Path('release/A04/0.1.1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
html=sha(rel/'index.html')
proofs={}
for sub,groups in [('root-formal-offline/browser',10),('root-formal-pagination',12)]:
 p=ev/sub;r=read(p/'result.json');cmd=read(p/'root-command.json')
 assert cmd['actual_exit_code']==0 and cmd['actual_terminal_chunk']
 assert cmd['test_sha256']==sha(cmd['test']) and cmd['raw_result_sha256']==sha(p/'result.json')
 assert r['status']=='passed' and r['offline'] and len(r['checks'])==groups
 assert r.get('candidate_sha256',r.get('html_sha256'))==html
 assert not r.get('errors') and not r.get('requests')
 for d in r['downloads']:
  f=Path(d['file']);f=f if f.is_absolute() else p/f
  assert sha(f)==d['sha256']
 proofs[sub]=sha(p/'result.json')
x=read(ev/'root-formal-offline/extraction.json');assert x['offline_zip_sha256']==sha(rel/'A04-0.1.1-离线包.zip')
for n,h in x['files_sha256'].items():assert sha(rel/n)==h and sha(Path(x['extracted_directory'])/n)==h
src=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json')
assert len(src['commands'])==4 and all(c['exit_code']==0 for c in src['commands'])
assert src['source_zip_sha256']==sha(rel/'A04-0.1.1-源码.zip')==assets['source_zip_sha256']
assert len(assets['files'])==14
for n,c in assets['files'].items():
 assert c['release_sha256']==sha(rel/n)
 assert c['bytes_identical'] or (n.endswith('.xlsx') and c['content_identical_except_created_modified'])
# Read actual browser-downloaded workbook independently; no engine import.
r=read(ev/'root-formal-pagination/result.json');assert r['contracts']==203 and r['payments']==406
book=next(Path(d['file']) for d in r['downloads'] if d['file'].endswith('.xlsx'))
w=load_workbook(book,read_only=True,data_only=False);assert len(w.sheetnames)==18
rows=lambda n:[dict(zip(next(iter(w[n].values)),v)) for v in list(w[n].values)[1:]]
results=rows('合同结果');assert len(results)==203 and len({r['租约ID'] for r in results})==203
D=lambda x:Decimal(str(x))
for r in results:
 assert r['币种']=='CNY' and r['单位']=='元'
 assert D(r['初始未付负债'])==D(r['全部付款现值'])==2100 and D(r['总利息'])==331 and D(r['开始日已付'])==0
assert sum(D(r['初始未付负债']) for r in results)==426300
pv=rows('逐笔现值');schedule=rows('负债排程');assert len(pv)==len(schedule)==406
for i,r in enumerate(pv):
 assert D(r['金额'])==([1100,1331][i%2]) and D(r['精确现值'])==([1000,1100][i%2])
 assert r['来源文件']=='完全虚构样例.xlsx' and r['来源页签']=='付款' and int(r['来源行'])==i+2
for i,r in enumerate(schedule):
 assert D(r['期初负债'])+D(r['利息'])-D(r['付款'])==D(r['期末负债'])
 assert D(r['利息'])==([210,121][i%2]) and D(r['期末负债'])==([1210,0][i%2])
changes=rows('变更比较');hist=rows('已确认历史排程');assert len(changes)==len(hist)==203
for r in changes:assert D(r['原截止负债'])==1100 and D(r['原未来现值'])==1100 and D(r['新未来现值'])==1210 and D(r['测算差额'])==110 and not r['阻塞']
for r in hist:assert D(r['期初负债'])==2000 and D(r['利息'])==200 and D(r['付款'])==1100 and D(r['期末负债'])==1100
original=rows('原始付款');working=rows('工作付款');assert len(original)==len(working)==406
for i,(a,b) in enumerate(zip(original,working)):
 assert D(a['金额'])==([1100,1210][i%2]) and D(b['金额'])==([1100,1331][i%2]);assert a['付款ID']==b['付款ID']
compat=read(ev/'root-formal-compatibility/result.json');cc=read(ev/'root-formal-compatibility/root-command.json')
assert compat['passed'] and compat['actual_offline'] and compat['html_sha256']==html and len(compat['checks'])==3
assert compat['old_work_sha256']==sha('release/A04/0.1.0/虚构完整工作.json') and not compat['requests'] and not compat['errors']
assert cc['actual_exit_code']==0 and cc['result_sha256']==sha(ev/'root-formal-compatibility/result.json') and cc['test_sha256']==sha(cc['test'])
ind=read(ev/'root-independent/root-command.json');assert ind['actual_independent_exit_code']==ind['unit_actual_exit_code']==ind['typecheck_actual_exit_code']==0 and ind['unit_tests']==41 and ind['independent_groups']==7
assert ind['independent_test_sha256']==sha('tests/a04-independent-review-011.ts') and ind['independent_result_sha256']==sha(ev/'root-independent/result.json')
visual=read(ev/'root-formal-offline/browser/root-visual-review.json');assert visual['passed_layout_review'] and len(visual['reviewed_whole_page_images'])==27 and len(visual['actual_reviewed_contact_sheets'])==6
for n,h in {**visual['reviewed_whole_page_images'],**visual['actual_reviewed_contact_sheets']}.items():assert sha(ev/'root-formal-offline/browser'/n)==h
old=read('progress/evidence/A04/0.1.0/root-formal-package-command.json')['all_formal_files']
for n,h in old.items():assert sha(Path('release/A04/0.1.0')/n)==h
out={'tool':'A04','version':'0.1.1','all_offline_gates_passed':True,'accepted':False,'website_verified':False,'html_sha256':html,'runtime_sha256':sha(rel/'runtime.json'),'offline_zip_sha256':sha(rel/'A04-0.1.1-离线包.zip'),'source_zip_sha256':sha(rel/'A04-0.1.1-源码.zip'),'unit_tests':41,'independent_groups':7,'formal_browser_groups':10,'formal_browser_downloads':26,'formal_pagination_groups':12,'compatibility_groups':3,'independently_read_contracts':203,'independently_read_payment_events':406,'independent_initial_liability_total':'426300','independent_change_delta_total':'22330','source_assets':14,'old_formal_files_unchanged':16,'reviewed_whole_layout_images':27,'proofs':proofs,'windows_real_machine':'unverified','scope':'Actual Mac formal ZIP file:// offline and exact source rebuild. Financial algebra rechecked from actual downloaded18sheet workbook with Decimal independently. Late root browser QA outside source ZIP. Website/full27/public download verification still required.'}
(ev/'offline-delivery-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('A04 0.1.1 formal offline gate passed; website pending')
