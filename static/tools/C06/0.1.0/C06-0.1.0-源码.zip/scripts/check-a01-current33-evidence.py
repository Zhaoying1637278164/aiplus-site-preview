"""Exact A01 local delivery evidence. Public acceptance remains separate."""
from pathlib import Path
import hashlib, json, zipfile

root = Path.cwd()
version = '0.1.1'
ev = root / 'progress/evidence/A01' / version
release = root / 'release/A01' / version
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
tool = next(t for t in read(root / 'catalog/tools.json') if t['id'] == 'A01')
assert tool['version'] == version
folder = root / 'tools' / tool['folder']
html, runtime = sha(release / 'index.html'), sha(release / 'runtime.json')
site = sha(root / 'integration/native-site/site/index.html')
ind = read(ev / 'root-independent/result.json')
assert ind['passed'] and len(ind['checks']) == 10
assert ind['engine_sha256'] == sha(folder / 'src/engine.ts')
assert ind['script_sha256'] == sha(root / 'tests/a01-independent-review.ts')
assert ind['workbook_sha256'] == sha(ev / 'root-independent/root-independent.xlsx')
src = read(ev / 'source-rebuild.json')
assets = read(ev / 'source-rebuild-assets.json')
assert src['source_zip_sha256'] == assets['source_zip_sha256'] == sha(release / f'A01-{version}-源码.zip')
assert len(src['commands']) == 4 and all(c['exit_code'] == 0 for c in src['commands'])
assert len(assets['files']) == 15
for name, row in assets['files'].items():
    assert row['bytes_identical'] and row['release_sha256'] == row['rebuilt_sha256'] == sha(release / name)
for name in ['index.html', 'runtime.json']:
    row = src['files'][name]
    assert row['identical'] and row['release_sha256'] == row['rebuilt_sha256'] == sha(release / name)
with zipfile.ZipFile(release / f'A01-{version}-离线包.zip') as z:
    members = {f.name for f in release.iterdir() if f.is_file() and f.suffix != '.zip'}
    assert set(z.namelist()) == {'A01/' + n for n in members}
    for name in members:
        assert z.read('A01/' + name) == (release / name).read_bytes()

def executed(folder_name, script):
    target = ev / folder_name
    result, command = read(target / 'result.json'), read(target / 'root-command.json')
    assert result['passed'] and command['exit_code'] == 0
    assert command['result_sha256'] == sha(target / 'result.json')
    assert command['test_sha256'] == sha(root / 'tests' / script)
    assert result.get('errors', []) == result.get('requests', []) == []
    return result

offline = executed('root-formal-offline/browser', 'a01-v011-formal-browser.ts')
assert len(offline['groups']) == 16 and offline['htmlSha256'] == html
pager = executed('root-formal-offline/pagination', 'a01-v011-formal-pagination-browser.ts')
assert len(pager['checks']) == 9 and pager['htmlSHA'] == html
assert pager['downloads'][0]['rows'] == 480 and pager['downloads'][0]['sheets'] == 11
native = executed('root-native-business-browser', 'a01-native-business-browser.ts')
assert len(native['groups']) == 16 and native['htmlSha256'] == html
assert native['actualRuntimeSHA'] == runtime and native['siteSHA'] == site
assert native['programs'] and len(set(native['programs'])) == 1
assert all(url.endswith('/A01/0.1.1/runtime.json') for url in native['programs'])
assert len({r['artifact_file'] for r in native['downloads']}) == len(native['downloads'])
for row in native['downloads']:
    f = Path(row['artifact_file'])
    assert f.stat().st_size == row['bytes'] and sha(f) == row['sha256']
pager = executed('root-native-pagination', 'a01-native-pagination.ts')
assert len(pager['checks']) == 9 and pager['htmlSHA'] == html
assert pager['runtimeSHA'] == runtime and pager['siteSHA'] == site
download = executed('A01/downloads', 'a01-native-downloads-current33.ts')
assert download['version'] == version and download['clicks'] == 16
assert download['site_sha256'] == site and download['runtime_sha256'] == runtime
expected = {f.name for f in release.iterdir() if f.is_file() and f.name not in ['index.html', 'runtime.json', 'build-manifest.json']}
assert set(download['downloads']) == expected
for name, digest in download['downloads'].items():
    assert digest == sha(release / name) == sha(ev / 'A01/downloads/site-local-downloads' / name)
full = executed('site-full-pages', 'a01-native-full-pages.ts')
review = read(ev / 'site-full-pages/root-rendered-review.json')
assert len(full['images']) == review['count'] == 33 and review['actual_review']
assert full['siteSHA'] == review['site_sha256'] == site
assert full['actualRuntimeSHA'] == review['runtime_sha256'] == runtime
assert review['result_sha256'] == sha(ev / 'site-full-pages/result.json')
for row in full['images']:
    assert row['sha256'] == review['reviewed_images'][row['file']] == sha(ev / 'site-full-pages' / row['file'])
    assert not row['rendered']['overflow']
    assert row['rendered']['scrollHeight'] <= row['rendered']['height'] + 2
for f in release.iterdir():
    if f.is_file():
        assert sha(f) == sha(root / 'integration/native-site/static/tools/A01' / version / f.name)
result = dict(tool='A01', version=version, local_exact_gates_passed=True,
              site_sha256=site, html_sha256=html, runtime_sha256=runtime,
              independent_groups=10, offline_groups=16, native_groups=16,
              pagination_groups=9, actual_native_full_images_reviewed=33,
              whole_site_verified=False, public_verified=False, accepted=False,
              windows_real_machine='unverified',
              visual_scope='Visible full-page layout; hidden table columns checked through complete exports and source tracing, not every field visually.')
(ev / 'local-delivery-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

# Exact count-only current33 adapters; financial assertions remain unchanged.
original=(root/'tests/a01-native-downloads.ts').read_text(); adapted=(root/'tests/a01-native-downloads-current33.ts').read_text()
expected=original.replace("innerText(),'3'","innerText(),'5'").replace('tests/a01-native-downloads.ts','tests/a01-native-downloads-current33.ts').replace('24 registered programs','27 registered programs').replace('three entries','five entries')
assert adapted==expected
