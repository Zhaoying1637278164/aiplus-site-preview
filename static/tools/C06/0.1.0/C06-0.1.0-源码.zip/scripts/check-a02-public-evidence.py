"""Exact A02 public delivery gate, requires actual HTTPS and public-downloaded offline replay."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();ev=root/'progress/evidence/A02/0.1.0';pub=ev/'site-public';release=root/'release/A02/0.1.0';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
local=read(ev/'local-delivery-audit.json');assert local['local_exact_gates_passed'] and local['site_sha256']==site
whole=read(root/'integration/native-site/acceptance.json');assert whole['site_sha256']==site and len(whole['tools'])==25 and 'A02' in whole['tools'];assert all(whole[k] for k in ['local_site_navigation','finance_same_results','downloads_hashes','offline','source_rebuild','rendered_product_ui'])
publication=read(ev/'root-publication-preflight.json');assert publication['push_actual_exit_code']==0 and publication['site_sha256']==site and publication['pushed_commit']=='0f80e89ccad1372357781e49e069e6e257831804'
def executed(folder,script):
 p=pub/folder;d=read(p/'result.json');c=read(p/'root-command.json');assert d['passed'] and c['actual_exit_code']==0
 assert c['script_sha256']==sha(root/'tests'/script) and c['result_sha256']==sha(p/'result.json') and d['errors']==[]
 if folder!='A02/downloads':assert d['requests']==[]
 if folder not in ['offline/browser','full-pages']:assert c['public_url']=='https://aiplus-guance.streamlit.app/~/+/?tool=A02'
 return d
business=executed('business','a02-public-business-browser.ts');assert len(business['groups'])==15 and business['siteSHA']==site and business['actualRuntimeSHA']==runtime and business['htmlSHA']==html
assert business['programs'] and all(x.startswith('https://aiplus-guance.streamlit.app/') and x.endswith('/A02/0.1.0/runtime.json') for x in business['programs'])
for x in business['downloads']:assert sha(pub/'business'/x['file'])==x['sha256']
pager=executed('pagination','a02-public-pagination.ts');assert len(pager['checks'])==7 and pager['siteSHA']==site and pager['runtimeSHA']==runtime
assert pager['downloads'][0]['sheets']==12 and pager['downloads'][0]['cardRows']==400 and pager['downloads'][0]['sourceRows']==1200
for x in pager['downloads']:assert sha(pub/'pagination'/x['name'])==x['sha256']
nav=executed('navigation','a02-public-navigation.ts');assert len(nav['geometry'])==24 and len(nav['checks'])==6 and nav['siteSHA']==site and nav['runtimeSHA']==runtime
full=executed('full-pages','a02-public-full-pages.ts');assert len(full['images'])==24 and full['siteSHA']==site and full['actualRuntimeSHA']==runtime
review=read(ev/'site-full-pages/root-visual-review.json');assert review['reviewed'] and review['siteSHA']==site and review['result_sha256']==sha(ev/'site-full-pages/result.json');prior={x['file']:x['sha256'] for x in review['images']}
for x in full['images']:assert x['sha256']==sha(pub/'full-pages'/x['file'])==prior[x['file']] and not x['rendered']['overflow'] and x['rendered']['scrollHeight']<=x['rendered']['height']+2
(pub/'full-pages/root-visual-review.json').write_text(json.dumps({'reviewed':True,'site_sha256':site,'result_sha256':sha(pub/'full-pages/result.json'),'images':prior,'count':24,'basis':'Actual public fresh captures all byte-identical with24 previously actually reviewed local whole-tool pages','prior_actual_review_sha256':sha(ev/'site-full-pages/root-visual-review.json'),'scope':'Full layout; hidden table cells covered by full pagination and exports, not everycell visual inspection'},indent=2)+'\n')
downloads=executed('A02/downloads','a02-public-downloads.ts');assert downloads['clicks']==19 and len(downloads['downloads'])==17 and downloads['site_sha256']==site and downloads['html_sha256']==html and downloads['runtime_sha256']==runtime
folder=pub/'A02/downloads/site-local-downloads';expected={f.name for f in release.iterdir() if f.is_file() and f.name not in ['index.html','runtime.json','build-manifest.json']};assert set(downloads['downloads'])==expected
for n,h in downloads['downloads'].items():assert h==sha(folder/n)==sha(release/n)
with zipfile.ZipFile(folder/'A02-0.1.0-离线包.zip') as z:
 members={f.name for f in release.iterdir() if f.is_file() and f.suffix!='.zip'};assert len(members)==18 and set(z.namelist())=={'A02/'+n for n in members}
 for n in members:assert z.read('A02/'+n)==(release/n).read_bytes()==(pub/'offline/extracted/A02'/n).read_bytes()
offline=executed('offline/browser','a02-public-offline-browser.ts');assert len(offline['groups'])==15 and len(offline['downloads'])==26 and offline['htmlSHA']==html
for x in offline['downloads']:assert sha(pub/'offline/browser'/x['file'])==x['sha256']
source=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json');sourcehash=sha(folder/'A02-0.1.0-源码.zip');assert sourcehash==sha(release/'A02-0.1.0-源码.zip')==source['source_zip_sha256']==assets['source_zip_sha256']
assert len(source['commands'])==4 and all(x['exit_code']==0 for x in source['commands']) and len(assets['files'])==18
for n,x in assets['files'].items():assert x['bytes_identical'] and x['release_sha256']==x['rebuilt_sha256']==sha(release/n)
result={'tool':'A02','version':'0.1.0','public_exact_gates_passed':True,'public_url':'https://aiplus-guance.streamlit.app/~/+/?tool=A02','site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'publication_commit':publication['pushed_commit'],'rollback_tag':publication['rollback_tag'],'business_groups':15,'full_volume_groups':7,'navigation_geometries':24,'reviewed_whole_pages':24,'download_clicks':19,'unique_version_files':17,'public_downloaded_offline_groups':15,'public_source_zip_sha256':sourcehash,'source_independent_rebuild_commands':4,'source_identical_assets':18,'whole_local_tools':25,'windows_real_machine':'unverified','scope':'Actual canonicalHTTPS same-document public workflow; full original module/detail and exact formal assets; browser data processingoffline; downloadedZIP actualfileoffline; public sourceZIP exact same bytes as independently four-command rebuilt source. Late root QA outside frozen sourceZIP.','accepted_registration':'Root to update only after thisactualgate passes'}
(ev/'site-public-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
