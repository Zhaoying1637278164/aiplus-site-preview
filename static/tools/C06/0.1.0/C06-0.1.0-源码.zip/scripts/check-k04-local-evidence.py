"""Exact local K04 delivery gate; whole-site and public gates remain separate."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();ev=root/'progress/evidence/K04/0.1.0';release=root/'release/K04/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
html=sha(release/'index.html');runtime=sha(release/'runtime.json');site=sha(root/'integration/native-site/site/index.html')
ind=read(ev/'root-independent-review.json')
assert ind['passed'] and len(ind['checks'])==6
assert ind['engine_sha256']==sha(root/'tools/K04-存货盘点差异/src/engine.ts')
assert ind['script_sha256']==sha(root/'tests/k04-independent-review.ts')
src=read(ev/'source-rebuild.json');assert src['source_zip_sha256']==sha(release/'K04-0.1.0-源码.zip')
assert len(src['commands'])==4 and all(c['exit_code']==0 for c in src['commands'])
for name,digest in [('index.html',html),('runtime.json',runtime)]:
 item=src['files'][name];assert item['identical'] and item['release_sha256']==item['rebuilt_sha256']==digest
assets=read(ev/'source-rebuild-assets.json');assert len(assets['files'])==20 and assets['source_zip_sha256']==src['source_zip_sha256']
for name,row in assets['files'].items():assert row['bytes_identical'] and row['release_sha256']==row['rebuilt_sha256']==sha(release/name)
with zipfile.ZipFile(release/'K04-0.1.0-源码.zip') as z:
 for name in ['package-lock.json','docs/source-build.md','packages/core/io.ts','packages/ui/tool-host.ts','tools/K04-存货盘点差异/src/engine.ts','tools/K04-存货盘点差异/src/program.tsx','tests/k04-independent-review.ts']:
  assert name in z.namelist(),name
for folder in ['root-formal-browser','root-formal-zip-browser','root-native-business-browser']:
 d=read(ev/folder/'result.json');assert d['status']=='passed' and len(d['checks'])==20 and len(d['downloads'])==43
 assert d['index_sha']==html and d['runtime_sha']==runtime and d['errors']==d['requests']==[]
 if folder=='root-native-business-browser':
  assert d['officialWebsite'] and d['siteSHA']==site and d['actualRuntimeSHA']==runtime
  assert d['test_sha256']==sha(root/'tests/k04-native-business-browser.ts')
downloads=ev/'K04/downloads';d=read(downloads/'result.json')
assert d['passed'] and d['clicks']==21 and d['errors']==[] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime
assert d['test_sha256']==sha(root/'tests/k04-native-downloads.ts')
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==19 and set(d['downloads'])==expected
for name,digest in d['downloads'].items():assert sha(downloads/'site-local-downloads'/name)==sha(release/name)==digest
for zip_path in [release/'K04-0.1.0-离线包.zip',downloads/'site-local-downloads/K04-0.1.0-离线包.zip']:
 with zipfile.ZipFile(zip_path) as z:
  expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
  assert len(expected)==20 and set(z.namelist())=={'K04/'+name for name in expected}
  for name in expected:assert z.read('K04/'+name)==(release/name).read_bytes()
full=read(ev/'site-full-pages/result.json');review=read(ev/'site-full-pages/root-visual-review.json');clips=read(ev/'site-guide-readable/result.json')
assert full['passed'] and len(full['images'])==27 and full['siteSHA']==site and full['actualRuntimeSHA']==runtime
assert review['actual_review'] and review['all_27_full_content_images_viewed'] and review['site_sha256']==site
assert review['result_sha256']==sha(ev/'site-full-pages/result.json')
for row in full['images']:
 assert row['sha256']==sha(ev/'site-full-pages'/row['file'])==review['images'][row['file']]
 assert not row['rendered']['overflow'] and row['rendered']['scrollHeight']<=row['rendered']['height']+2
assert clips['passed'] and len(clips['images'])==28 and clips['siteSHA']==site and clips['actualRuntimeSHA']==runtime
assert review['guide_readable_clips_result_sha256']==sha(ev/'site-guide-readable/result.json')
for row in clips['images']:assert row['sha256']==sha(ev/'site-guide-readable'/row['file'])==review['guide_readable_clips_viewed'][row['file']]
for p in release.iterdir():
 if p.is_file():assert sha(root/'integration/native-site/static/tools/K04/0.1.0'/p.name)==sha(p)
result={'tool':'K04','version':'0.1.0','local_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'independent_groups':6,'native_groups':20,'native_downloads':43,'full_images_reviewed':27,'readable_guide_clips_reviewed':28,'version_download_clicks':21,'unique_files':19,'public_verified':False,'accepted':False,'windows_real_machine':'unverified'}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
