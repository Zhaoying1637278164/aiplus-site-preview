"""Actual public A04 checks, including its downloaded ZIP; acceptance is separate."""
from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path.cwd()
out = root / 'progress/evidence/A04/0.1.1/site-public'
out.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
site = sha(root / 'integration/native-site/site/index.html')
tasks = [('business','root-native-business'), ('pagination','root-native-pagination'),
         ('navigation','root-native-navigation'), ('full-pages','site-full-pages'),
         ('downloads','A04/downloads'), ('zip-offline','downloaded-zip-offline/browser')]
record = {'site_sha256':site, 'passed':False, 'results':[], 'final_public_acceptance':False}
for name, folder in tasks:
    if name == 'zip-offline':
        archive = out / 'A04/downloads/site-local-downloads/A04-0.1.1-离线包.zip'
        release = root / 'release/A04/0.1.1'
        assert sha(archive) == sha(release / archive.name)
        with zipfile.ZipFile(archive) as z:
            expected = {f.name for f in release.iterdir() if f.is_file() and f.suffix != '.zip'}
            assert z.testzip() is None and set(z.namelist()) == {'A04/' + f for f in expected}
            for f in expected:
                assert z.read('A04/' + f) == (release / f).read_bytes()
            z.extractall(out / 'downloaded-zip-offline/extracted')
    script = root / ('tests/a04-public-' + name + '.ts')
    log = out / (name + '.root-public.log')
    print('Actual public', name, flush=True)
    with log.open('w') as f:
        process = subprocess.run(['node','--import','tsx',str(script)], cwd=root, stdout=f, stderr=subprocess.STDOUT)
    row = {'script':str(script.relative_to(root)), 'script_sha256':sha(script),
           'actual_exit_code':process.returncode, 'log':str(log.relative_to(root)), 'site_sha256':site}
    if process.returncode == 0:
        result = out / folder / 'result.json'
        row['result_sha256'] = sha(result)
        (result.parent / 'root-command.json').write_text(json.dumps(row, indent=2) + '\n')
    record['results'].append(row)
    (out / 'root-public-commands.json').write_text(json.dumps(record, indent=2) + '\n')
    print('Exit', process.returncode, name, flush=True)
    if process.returncode:
        raise SystemExit('Actual public failed ' + name + '; evidence retained')
record['passed'] = True
(out / 'root-public-commands.json').write_text(json.dumps(record, indent=2) + '\n')
print('Six actual public checks passed; final independent acceptance remains.', flush=True)
