"""C02 final formal/source evidence only; real website and Windows separate."""
from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();ev=root/'progress/evidence/C02/0.1.0';b=ev/'root-formal-offline';release=root/'release/C02/0.1.0'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=read(b/'run.json');terminal=read(b/'root-final-browser-command.json');assert run['passed'] and run['finished'] and len(run['commands'])==4
assert terminal['actual_exit_code']==0 and terminal['run_sha256']==sha(b/'run.json')
assert run['html_sha256']==sha(release/'index.html') and run['offline_zip_sha256']==sha(release/'C02-0.1.0-离线包.zip')
for c in run['commands']:assert c['exit_code']==0 and c['script_sha256']==sha(root/c['script']) and (root/c['log']).is_file()
for folder,groups in [('root-browser',6),('standard-browser',13),('large-browser',11),('native',4)]:
 d=read(b/folder/'result.json');assert d.get('passed',d.get('status')=='passed') and len(d['checks'])==groups and d['errors']==d['requests']==[]
zr=read(b/'zip-members.json');assert zr['passed'] and zr['zip_sha256']==run['offline_zip_sha256']
with zipfile.ZipFile(release/'C02-0.1.0-离线包.zip') as z:
 assert set(z.namelist())==set(zr['members']) and len(z.namelist())==18
 for n,h in zr['members'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h==sha(release/Path(n).name)==sha(b/'extracted'/n)
unit=read(b/'root-unit-command.json');assert unit['actual_exit_code']==unit['typecheck_exit_code']==unit['build_exit_code']==0 and unit['tests']==54
for n,h in unit['files'].items():assert sha(root/n)==h
ind=read(root/'progress/evidence/C02/root-independent/result.json');assert ind['passed'] and ind['tests']==6
for n,h in ind['files'].items():assert sha(root/n)==h
work=read(b/'root-workbook/result.json');wc=read(b/'root-workbook/root-command.json');assert work['passed'] and len(work['checks'])==3 and work['errors']==work['requests']==[]
assert wc['actual_exit_code']==0 and wc['result_sha256']==sha(b/'root-workbook/result.json')
assert work['script_sha256']==sha(root/'tests/c02-root-formal-workbook.ts') and work['html_sha256']==sha(release/'index.html') and work['workbook_sha256']==sha(b/'root-workbook/602-workbook.xlsx')
source=release/'C02-0.1.0-源码.zip';assert source.stat().st_size<=24*1024*1024
src=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json');sc=read(ev/'root-source-command.json');assert sc['actual_exit_code']==sc['actual_asset_readback_exit_code']==0
assert src['source_zip_sha256']==assets['source_zip_sha256']==sc['source_zip_sha256']==sha(source)
assert sc['result_sha256']==sha(ev/'source-rebuild.json') and sc['assets_result_sha256']==sha(ev/'source-rebuild-assets.json')
assert len(src['commands'])==4 and all(c['exit_code']==0 for c in src['commands']) and len(assets['files'])==18
for n,v in assets['files'].items():assert v['release_sha256']==sha(release/n) and (v['bytes_identical'] or n.endswith('.xlsx') and v['content_identical_except_created_modified'])
with zipfile.ZipFile(source) as z:
 assert sum(x.file_size for x in z.infolist())<=250*1024*1024
 assert hashlib.sha256(z.read('scripts/verify-source.py')).hexdigest()==sc['script_sha256']
 for n in ['tools/C02-计提与冲回/src/engine.ts','tools/C02-计提与冲回/src/App.tsx','tools/C02-计提与冲回/src/paging.tsx','tools/C02-计提与冲回/tests/engine.test.ts','tools/C02-计提与冲回/tests/browser.ts','tests/c02-root-independent.test.ts','tests/c02-root-repaired-browser.ts','tests/c02-formal-native.ts','tests/c02-formal-large-browser.ts','package-lock.json','packages/core/io.ts','scripts/build.ts','scripts/package.py']:assert z.read(n)==(root/n).read_bytes(),n
assert 'release/C02/0.1.0/index.html' in (release/'使用说明.md').read_text()
result={'passed':True,'tests':54,'formal_browser_groups':[6,13,11,4],'independent_export_groups':3,'formal_assets':18,'source_commands':4,'source_zip_bytes':source.stat().st_size,'html_sha256':sha(release/'index.html'),'runtime_sha256':sha(release/'runtime.json'),'source_zip_sha256':sha(source),'offline_zip_sha256':sha(release/'C02-0.1.0-离线包.zip'),'website':'unverified','Windows':'unverified','accepted':False,'scope':'Actual final offline ZIP and isolated source rebuild. Late workbook QA and this gate outside source ZIP; core finance/browser tests included.'}
(b/'check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
