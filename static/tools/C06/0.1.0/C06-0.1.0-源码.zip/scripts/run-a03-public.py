"""Actual public A03 sequential checks; no final acceptance claim."""
from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=root/'progress/evidence/A03/0.1.0/site-public';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tasks=[('business','root-native-business'),('pagination','root-native-pagination'),('reviewed-export','root-native-reviewed-export'),('full-pages','site-full-pages'),('downloads','A03/downloads')]
site=sha(root/'integration/native-site/site/index.html');record={'site_sha256':site,'passed':False,'results':[],'final_public_acceptance':False}
for name,folder in tasks:
 script=root/('tests/a03-public-'+name+'.ts');log=out/(name+'.root-public.log');print('Actual public',name,flush=True)
 with log.open('w') as f:r=subprocess.run(['node','--import','tsx',str(script)],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 row={'script':str(script.relative_to(root)),'script_sha256':sha(script),'actual_exit_code':r.returncode,'log':str(log.relative_to(root)),'site_sha256':site}
 if r.returncode==0:
  result=out/folder/'result.json';row['result_sha256']=sha(result);(result.parent/'root-command.json').write_text(json.dumps(row,indent=2)+'\n')
 record['results'].append(row);(out/'root-public-commands.json').write_text(json.dumps(record,indent=2)+'\n');print('Exit',r.returncode,name,flush=True)
 if r.returncode:raise SystemExit('Public failed '+name+'; evidence preserved')
record['passed']=True;(out/'root-public-commands.json').write_text(json.dumps(record,indent=2)+'\n');print('Five public checks passed; public ZIP offline and final acceptance gate remain.',flush=True)
