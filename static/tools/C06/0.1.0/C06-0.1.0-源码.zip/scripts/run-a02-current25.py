"""Execute fresh whole-site regressions for exact A02 stage; no acceptance claim."""
from pathlib import Path
import hashlib,json,subprocess,sys,os,shutil
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stage=root/'integration/native-site/site/index.html';digest=sha(stage)
ids=[x['id'] for x in json.loads((stage.parent/'registry.json').read_text())]
assert ids==['D02','D03','D06','R01','R02','R03','R04','R05','P01','P02','P03','P04','T01','T02','T03','T05','K02','K01','T04','T06','K03','K04','A01','K05','A02']
suite=root/'progress/evidence/site-integration'/'-'.join(ids);suite.mkdir(parents=True,exist_ok=True)
# Preserve current actual outputs before fresh stage overwrites them.
for tool,version,folders in [
 ('A01','0.1.1',['root-native-business-browser','root-native-pagination','A01/downloads','site-full-pages']),
 ('K03','0.1.0',['site-full-pages']),('K04','0.1.0',['site-guide-readable']),
]:
 ev=root/'progress/evidence'/tool/version
 for folder in folders:
  source=ev/folder;target=ev/'history/before-current25'/folder
  if source.exists() and not target.exists():shutil.copytree(source,target)
tasks=[('scripts/run-native-regression.py',None),('scripts/run-a02-remaining-current25.py',None),('scripts/run-a02-visual-regressions.py',None),
 ('tests/a01-native-business-browser.ts','root-native-business-browser'),('tests/a01-native-pagination.ts','root-native-pagination'),
 ('tests/a01-native-downloads.ts','A01/downloads'),('tests/a01-native-full-pages.ts','site-full-pages')]
record=suite/'root-current25-commands.json';result={'site_sha256':digest,'tools':ids,'results':[],'passed':False,'public_verified':False}
if '--resume' in sys.argv and record.exists():
 old=json.loads(record.read_text());assert old['site_sha256']==digest and old['tools']==ids
 for i,row in enumerate(old['results']):
  if row['actual_exit_code']:break
  assert row['script']==tasks[i][0] and row['script_sha256']==sha(root/row['script'])
  result['results'].append(row)
env=dict(os.environ);env['AIPLUS_PARENT_RUN']='A02-current25-'+digest
for script,folder in tasks[len(result['results']):]:
 assert sha(stage)==digest
 source=root/script;log=suite/(source.name+'.root-current25.log');print('Executing',script,flush=True)
 command=[sys.executable,str(source)] if source.suffix=='.py' else ['node','--import','tsx',str(source)]
 if '--resume' in sys.argv and source.name=='run-a02-remaining-current25.py':command.append('--resume')
 with log.open('w') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'script':script,'script_sha256':sha(source),'actual_exit_code':r.returncode,'site_sha256':digest,'log':str(log.relative_to(root))}
 if folder and r.returncode==0:
  out=root/'progress/evidence/A01/0.1.1'/folder
  row['result_sha256']=sha(out/'result.json')
  (out/'root-command.json').write_text(json.dumps({'exit_code':0,'test_sha256':sha(source),'result_sha256':row['result_sha256'],'site_sha256':digest,'executed_by':'scripts/run-a02-current25.py','actual_execution_run_id':env['AIPLUS_PARENT_RUN'],'log':row['log']},indent=2)+'\n')
 result['results'].append(row);record.write_text(json.dumps(result,indent=2)+'\n');print('Exit',r.returncode,script,flush=True)
 if r.returncode:raise SystemExit('Failed '+script+'; '+str(log))
result['passed']=True;record.write_text(json.dumps(result,indent=2)+'\n')
print('Fresh 25-stage regressions passed; visual review and local/public gates remain separate.',flush=True)
