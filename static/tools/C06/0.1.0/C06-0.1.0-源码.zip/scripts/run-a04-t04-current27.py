"""Actual frozen T04 regression against current20 stage; catalogue-only adapter."""
from pathlib import Path
import json,hashlib,subprocess,shutil
root=Path.cwd();ev=root/'progress/evidence/T04/0.2.0';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();stage=root/'integration/native-site/site/index.html';digest=sha(stage)
ids=[x['id'] for x in json.loads((stage.parent/'registry.json').read_text())];assert ids == ['D02', 'D03', 'D06', 'R01', 'R02', 'R03', 'R04', 'R05', 'P01', 'P02', 'P03', 'P04', 'T01', 'T02', 'T03', 'T05', 'K02', 'K01', 'T04', 'T06', 'K03', 'K04', 'A01', 'K05', 'A02', 'A03', 'A04']
history=ev/('history/before-current'+str(len(ids)))
for folder in ['site-local','site-financial','T04/downloads']:
 p=ev/folder;q=history/folder
 if p.exists() and not q.exists():shutil.copytree(p,q)
suite=root/'progress/evidence/site-integration'/'-'.join(ids);record=suite/'t04-current20-commands.json';result={'site_sha256':digest,'passed':False,'results':[]}
for script,folder in [('t04-native-execution.ts','site-local'),('t04-native-financial-browser.ts','site-financial'),('t04-native-downloads.ts','T04/downloads')]:
 source=root/'tests'/script;execution=source;adaptation=None
 if script.endswith('downloads.ts'):
  text=source.read_text();needle="frame.locator('[data-total]').innerText(),'9'";assert text.count(needle)==1
  text=text.replace(needle,"frame.locator('[data-total]').innerText(),'10'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
  execution=suite/'t04-native-downloads-fund10.mts';execution.write_text(text);adaptation='Only original funds catalogue count 9 -> 10 and absolute Playwright import; financial/archive assertions unchanged'
 log=suite/(script+'.log');assert sha(stage)==digest
 with log.open('w') as handle:r=subprocess.run(['node','--import',str(root/'node_modules/tsx/dist/loader.mjs'),str(execution)],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
 row={'script':script,'actual_exit_code':r.returncode,'script_sha256':sha(source),'executed_script':str(execution.relative_to(root)),'executed_script_sha256':sha(execution),'site_sha256':digest,'log':str(log.relative_to(root)),'adaptation':adaptation,'result_sha256':sha(ev/folder/'result.json') if r.returncode==0 else None}
 result['results'].append(row);record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(script,r.returncode,flush=True)
 if r.returncode:raise SystemExit(1)
result['passed']=True;record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
