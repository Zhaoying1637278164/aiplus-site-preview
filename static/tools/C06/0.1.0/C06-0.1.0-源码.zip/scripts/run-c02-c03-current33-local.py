from pathlib import Path
import json,hashlib,subprocess,concurrent.futures
r=Path.cwd();out=r/'progress/evidence/site-integration/C02-C03-current33-local';out.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();site=sha(r/'integration/native-site/site/index.html');rows=[]
def run(script):
 log=out/(Path(script).stem+'.log');print('Running',script,flush=True)
 with log.open('w') as f:code=subprocess.run(['node','--import','tsx',script],stdout=f,stderr=subprocess.STDOUT).returncode
 print('Exit',code,script,flush=True);return {'script':script,'script_sha256':sha(r/script),'exit_code':code,'log':str(log.relative_to(r))}
rows.append(run('tests/c03-native-site.ts'))
if rows[0]['exit_code']==0:
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows+=list(pool.map(run,['tests/c02-native-site.ts','tests/c02-native-workbook.ts','tests/c02-c03-native-downloads.ts']))
assert sha(r/'integration/native-site/site/index.html')==site
(out/'run.json').write_text(json.dumps({'passed':len(rows)==4 and all(x['exit_code']==0 for x in rows),'site_sha256':site,'commands':rows,'public_verified':False,'full33_regression':False,'accepted':False},indent=2)+'\n')
if any(x['exit_code'] for x in rows):
 for x in rows:
  if x['exit_code']:print((r/x['log']).read_text())
 raise SystemExit(1)
print('Four current33 local C02/C03 scripts passed',flush=True)
