"""Bind completed current22 subprocess receipts to exact actual result bytes."""
from pathlib import Path
import hashlib,json,sys,shutil
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
site=sha(root/'integration/native-site/site/index.html')
ids=[x['id'] for x in json.loads((root/'integration/native-site/site/registry.json').read_text())]
assert (len(ids)==22 and ids[-1]=='K04') or (len(ids)==23 and ids[-2:]==['K04','K05'])
current='current'+str(len(ids))
suite=root/'progress/evidence/site-integration'/'-'.join(ids)
assert len(sys.argv)==2 and sys.argv[1].isdigit()
session=int(sys.argv[1]);rows=[]
run_sessions=json.loads((suite/'execution-run-sessions.json').read_text()) if (suite/'execution-run-sessions.json').exists() else {}
for name in ['additional-existing-commands.json','final-additions-'+current+'-commands.json','t06-final-stage-additional-commands.json','final-tool-'+current+'-commands.json','t04-current20-commands.json']:
 p=suite/name
 if not p.exists():continue
 d=json.loads(p.read_text());assert d['site_sha256']==site
 for row in d['results']:
  if row.get('exit_code',row.get('actual_exit_code'))==0:rows.append((p,row))
mapping={'k01-native-site.ts':'K01/0.1.0/site-local','k01-native-downloads.ts':'K01/0.1.0/K01/downloads','k02-native-site.ts':'K02/0.1.0/site-local','k02-native-downloads.ts':'K02/0.1.0/K02/downloads','t06-native-site.ts':'T06/0.1.0/site-local','t06-native-downloads.ts':'T06/0.1.0/T06/downloads','t04-native-execution.ts':'T04/0.2.0/site-local','t04-native-financial-browser.ts':'T04/0.2.0/site-financial','t04-native-downloads.ts':'T04/0.2.0/T04/downloads'}
written=[]
mapping.update({'t05-native-site.ts':'T05/0.1.0/site-local','t05-native-downloads.ts':'T05/0.1.0/T05/downloads'})
for record,row in rows:
 script=row['script'];source=root/row.get('script_path','tests/'+script)
 digest=row.get('test_sha256',row.get('script_sha256'));assert sha(source)==digest
 if script=='original-financial-modules.ts':base=suite;result=base/'original-financial-modules.json';receipt=base/'original-financial-module-command.json'
 elif script in mapping:base=root/'progress/evidence'/mapping[script];result=base/'result.json';receipt=base/'root-command.json'
 elif script in ['p04-native-site.ts','t01-native-site.ts','t02-native-site.ts']:
  base=root/'progress/evidence'/script[:3].upper()/'0.1.0/site-local';result=base/'result.json';receipt=base/'root-command.json'
 else:continue
 d=json.loads(result.read_text());assert d.get('site_sha256',d.get('siteSHA'))==site
 if receipt.exists():
  history=base/'history/before-current22-command';history.mkdir(parents=True,exist_ok=True)
  if not (history/receipt.name).exists():shutil.copy2(receipt,history/receipt.name)
 actual_session=row.get('actual_parent_session')
 if actual_session is None and row.get('actual_execution_run_id'):
  actual_session=run_sessions[row['actual_execution_run_id']]
 if actual_session is None and record.name=='t04-current20-commands.json':
  parent_file=suite/('final-tool-'+current+'-commands.json')
  if not parent_file.exists():continue
  parent=json.loads(parent_file.read_text())
  enclosing=next((r for r in parent['results'] if r['script']=='run-t04-current20.py' and r['exit_code']==0),None)
  if enclosing is None:continue
  actual_session=enclosing.get('actual_parent_session') or run_sessions[enclosing['actual_execution_run_id']]
 assert actual_session is not None,'Missing actual parent execution session: '+script
 if script in ['p04-native-site.ts','t01-native-site.ts','t02-native-site.ts']:
  original=base/'history/current22-before-root-exit-annotation/result.json'
  original.parent.mkdir(parents=True,exist_ok=True)
  if not original.exists():shutil.copy2(result,original)
  d.update(actual_root_exit_code=0,test_sha256=digest,root_execution_provenance={'actual_parent_session':actual_session,'command_record':str(record.relative_to(root)),'original_result_sha256':sha(original),'scope':'Root exit-code and actual executed source SHA provenance only; original actual browser assertions and results unchanged.'})
  result.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 c={**row,'actual_exit_code':0,'actual_root_exit_code':0,'actual_session_id':actual_session,'script_sha256':digest,'site_sha256':site,'result_sha256':sha(result),'parent_subprocess_record':str(record.relative_to(root)),'parent_subprocess_record_sha256':sha(record)}
 if script.startswith('t06-'):
  c['runtime_sha256']=sha(root/'release/T06/0.1.0/runtime.json')
  if script=='t06-native-site.ts':
   assert d['pageErrors']==d['externalRequests']==[] and len(d['cases'])==17
   assert all(x.get('passed') is True or x.get('checked')==437 for x in d['cases'])
   assert any(x['name']=='原官网退出取消保留、确认清除再进入' and x['passed'] for x in d['cases'])
   c.update(actual_exit_cancel_clear_reenter=True,storage_writes_verified_empty=True)
 receipt.write_text(json.dumps(c,indent=2)+'\n');written.append(str(receipt.relative_to(root)))
print(json.dumps({'site_sha256':site,'actual_parent_session':session,'written':written}))
