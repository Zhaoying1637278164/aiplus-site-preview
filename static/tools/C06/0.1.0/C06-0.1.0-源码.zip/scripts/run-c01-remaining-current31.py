"""Fresh remaining regressions against exact A03 staged site, resumable by SHA."""
from pathlib import Path
import hashlib,json,subprocess,runpy,sys,shutil,os
root=Path.cwd(); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stage=root/'integration/native-site/site/index.html'; digest=sha(stage)
ids=[x['id'] for x in json.loads((stage.parent/'registry.json').read_text())]
assert ids==['D02', 'D03', 'D06', 'R01', 'R02', 'R03', 'R04', 'R05', 'P01', 'P02', 'P03', 'P04', 'T01', 'T02', 'T03', 'T05', 'K02', 'K01', 'T04', 'T06', 'K03', 'K04', 'A01', 'K05', 'A02', 'A03', 'A04', 'D01', 'D04', 'D05', 'C01']
suite=root/'progress/evidence/site-integration'/'-'.join(ids)
adapter=runpy.run_path('scripts/current-stage-download-adapter.py')
groups={
 'additional-existing-commands.json':[(s,[],None) for s in ['r04-r05-native-site.ts','r04-r05-native-downloads.ts','p01-native-site.ts','p02-native-site.ts','p03-native-site.ts','payables-native-navigation.ts']],
 'final-additions-current31-commands.json':[(s,args,'fund' if args else None) for s,args in [('p04-native-site.ts',[]),('new-tools-native-downloads.ts',['P04']),('t01-native-site.ts',[]),('new-tools-native-downloads.ts',['T01']),('t02-native-site.ts',[]),('new-tools-native-downloads.ts',['T02'])]],
 't06-final-stage-additional-commands.json':[(s,[],a) for s,a in [('run-c01-t03-current31.py',None),('t05-native-site.ts',None),('t05-native-downloads.ts','t05'),('k01-native-site.ts',None),('k01-native-downloads.ts','cost'),('k02-native-site.ts',None),('k02-native-downloads.ts','cost7'),('original-financial-modules.ts',None)]],
 'final-tool-current31-commands.json':[(s,[],'cost7' if s=='k03-native-downloads.ts' else None) for s in ['run-c01-t04-current31.py','t06-native-site.ts','t06-native-downloads.ts','k03-native-site.ts','k03-native-financial-browser.ts','k03-native-downloads.ts']],
 'k04-current31-commands.json':[(s,[],'cost8' if s=='k04-native-downloads.ts' else None) for s in ['k04-native-business-browser.ts','k04-native-downloads.ts','k04-native-full-pages.ts']],
 'k05-current31-commands.json':[(name,[],None) for name in ['k05-native-business-browser.ts','k05-native-downloads.ts','k05-native-full-pages.ts']]
}
k04=root/'progress/evidence/K04/0.1.0'
for folder in ['root-native-business-browser','site-full-pages','K04/downloads']:
 p=k04/folder;q=k04/'history/before-current31'/folder
 if p.exists() and not q.exists():shutil.copytree(p,q)
k05=root/'progress/evidence/K05/0.1.0'
for folder in ['root-native-business-browser','site-full-pages','K05/downloads']:
 p=k05/folder;q=k05/'history/before-current31'/folder
 if p.exists() and not q.exists():shutil.copytree(p,q)
for name,tasks in groups.items():
 record=suite/name; result={'site_sha256':digest,'tools':ids,'results':[],'passed':False}
 if '--resume' in sys.argv and record.exists():
  old=json.loads(record.read_text());assert old['site_sha256']==digest
  for i,row in enumerate(old['results']):
   if row['exit_code']:break
   source=root/row['script_path'];assert row['script']==tasks[i][0] and sha(source)==row['test_sha256']
   result['results'].append(row)
 for script,args,adapt in tasks[len(result['results']):]:
  assert sha(stage)==digest
  source=root/('scripts' if script.endswith('.py') else 'tests')/script
  log=suite/(script+('-'+'-'.join(args) if args else '')+'.log');print('Executing',script,args,flush=True)
  if adapt=='fund':row=adapter['adapted_download'](script,args,log)
  elif adapt=='cost':row=adapter['adapted_cost_download'](script,log)
  elif adapt=='t05':row=adapter['adapted_t05_download'](log)
  elif adapt in ('cost7','cost8'):
   original=source.read_text();old_count='7' if adapt=='cost7' else '8';needle="frame.locator('[data-total]').innerText(),'"+old_count+"'";assert original.count(needle)==1
   text=original.replace(needle,"frame.locator('[data-total]').innerText(),'9'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
   executed=suite/(script.removesuffix('.ts')+'-cost9.mts');executed.write_text(text)
   with log.open('w') as handle:r=subprocess.run(['node','--import',str(root/'node_modules/tsx/dist/loader.mjs'),str(executed)],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
   row={'script':script,'exit_code':r.returncode,'test_sha256':sha(source),'executed_test':str(executed.relative_to(root)),'executed_test_sha256':sha(executed),'adaptation':'Only original cost catalogue count 7/8 -> 9 and absolute Playwright import; all file and financial assertions retained'}
  else:
   command=[sys.executable,str(source)] if script.endswith('.py') else ['node','--import','tsx',str(source),*args]
   env=dict(os.environ)
   if script.startswith('r04-r05-'):env['AIPLUS_EVIDENCE_DIR']=str(suite)
   with log.open('w') as handle:r=subprocess.run(command,cwd=root,env=env,stdout=handle,stderr=subprocess.STDOUT)
   row={'script':script,'exit_code':r.returncode,'test_sha256':sha(source)}
  if script=='original-financial-modules.ts' and row['exit_code']==0:
   module=json.loads((suite/'original-financial-modules.json').read_text())
   assert module['site_sha256']==digest and module['test_sha256']==sha(source)
   (suite/'original-financial-module-command.json').write_text(json.dumps({'actual_root_exit_code':0,'site_sha256':digest,'test_sha256':sha(source),'actual_execution_run_id':os.environ.get('AIPLUS_PARENT_RUN'),'log':str(log.relative_to(root))},indent=2)+'\n')
  row.update(script_path=str(source.relative_to(root)),args=args,log=str(log.relative_to(root)),actual_execution_run_id=os.environ.get('AIPLUS_PARENT_RUN'))
  result['results'].append(row);record.write_text(json.dumps(result,indent=2)+'\n')
  if row['exit_code']:raise SystemExit('Failed '+script+'; actual log '+str(log))
 result['passed']=True;record.write_text(json.dumps(result,indent=2)+'\n')
print('All remaining current31 regression command groups passed',flush=True)
