"""Verify four exact local deliveries; does not grant public acceptance."""
from pathlib import Path
import hashlib, json, subprocess, sys, zipfile

root = Path.cwd()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
stage = root / 'integration/native-site'
registry = read(stage / 'site/registry.json')
assert len(registry) == 31
assert [r['id'] for r in registry[27:]] == ['D01', 'D04', 'D05', 'C01']
site = sha(stage / 'site/index.html')
binding = root / 'progress/evidence/C01/0.1.0/site-local/command-bindings.json'
commands = read(binding)
placements = read(binding.parent / 'stage-bindings.json')
assert placements['passed'] and placements['prior30_identical']
assert placements['site_sha256'] == site and placements['current_entries'] == 31
specs = {
    'D01': ('site-local-with-C01', 'd01-native-site-with-c01.ts', 7, 9, None),
    'D04': ('site-local-with-C01', 'd04-native-site-with-c01.ts', 7, 10, None),
    'D05': ('site-local-with-C01', 'd05-native-site-with-c01.ts', 8, 8, 21),
    'C01': ('site-local', 'c01-native-site.ts', 10, 10, None),
}
for tool in sys.argv[1:] or specs:
    folder, script, groups, files, geometries = specs[tool]
    release = root / 'release' / tool / '0.1.0'
    ev = root / 'progress/evidence' / tool / '0.1.0' / folder
    result = read(ev / 'result.json')
    assert result['passed'] and result['tool'] == tool and result['version'] == '0.1.0'
    assert result['site_sha256'] == site
    assert result['runtime_sha256'] == sha(release / 'runtime.json')
    assert result['errors'] == result['requests'] == []
    assert len(result['checks']) == groups and len(set(result['checks'])) == groups
    assert len(result['downloads']) == files
    if geometries is not None:
        assert len(result['geometry']) == geometries
    assert commands['files']['tests/' + script] == sha(root / 'tests' / script)
    assert commands['terminals'][tool]
    assert result['accepted'] is False
    entry = next(r for r in registry if r['id'] == tool)
    assert entry['sha256'] == result['runtime_sha256']
    for f in release.iterdir():
        if f.is_file():
            assert sha(stage / 'static/tools' / tool / '0.1.0' / f.name) == sha(f)
    for name, digest in result['downloads'].items():
        assert digest == sha(release / name) == sha(ev / 'downloads' / name)
    with zipfile.ZipFile(ev / 'downloads' / f'{tool}-0.1.0-离线包.zip') as z:
        assert z.read(tool + '/index.html') == (release / 'index.html').read_bytes()
    gate = root / 'scripts' / f'check-{tool.lower()}-offline-evidence.py'
    subprocess.run([sys.executable, str(gate)], check=True)
    out = dict(tool=tool, passed=True, site_sha256=site,
               result_sha256=sha(ev / 'result.json'), script_sha256=sha(root / 'tests' / script),
               prior_execution_terminal=commands['terminals'][tool],
               historical_command_bindings_sha256=sha(binding),
               formal_gate_sha256=sha(gate), native_groups=groups, downloads=files,
               whole31_verified=False, public_verified=False, accepted=False,
               scope='Exact recorded local native results and fresh formal/source gate; visual and whole-site gates separate')
    (ev / 'exact-local-audit.json').write_text(json.dumps(out, indent=2) + '\n')
    print(tool, 'exact local evidence passed; whole31/public still separate')
