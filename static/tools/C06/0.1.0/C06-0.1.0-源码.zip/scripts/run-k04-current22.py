"""Fresh remaining regressions against exact K04 staged site, resumable by SHA."""
from pathlib import Path
import hashlib,json,subprocess,runpy,sys,shutil,os
root=Path.cwd(); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stage=root/'integration/native-site/site/index.html'; digest=sha(stage)
ids=[x['id'] for x in json.loads((stage.parent/'registry.json').read_text())]
assert ids==['D02','D03','D06','R01','R02','R03','R04','R05','P01','P02','P03','P04','T01','T02','T03','T05','K02','K01','T04','T06','K03','K04']
suite=root/'progress/evidence/site-integration'/'-'.join(ids)
adapter=runpy.run_path('scripts/current-stage-download-adapter.py')
groups={
 'additional-existing-commands.json':[(s,[],None) for s in ['r04-r05-native-site.ts','r04-r05-native-downloads.ts','p01-native-site.ts','p02-native-site.ts','p03-native-site.ts','payables-native-navigation.ts']],
 'final-additions-current22-commands.json':[(s,args,'fund' if args else None) for s,args in [('p04-native-site.ts',[]),('new-tools-native-downloads.ts',['P04']),('t01-native-site.ts',[]),('new-tools-native-downloads.ts',['T01']),('t02-native-site.ts',[]),('new-tools-native-downloads.ts',['T02'])]],
 't06-final-stage-additional-commands.json':[(s,[],a) for s,a in [('run-t03-current-stage.py',None),('t05-native-site.ts',None),('t05-native-downloads.ts','t05'),('k01-native-site.ts',None),('k01-native-downloads.ts','cost'),('k02-native-site.ts',None),('k02-native-downloads.ts','cost7'),('original-financial-modules.ts',None)]],
 'final-tool-current22-commands.json':[(s,[],'cost7' if s=='k03-native-downloads.ts' else None) for s in ['run-t04-current20.py','t06-native-site.ts','t06-native-downloads.ts','k03-native-site.ts','k03-native-financial-browser.ts','k03-native-downloads.ts']]
}
for name,tasks in groups.items():
 record=suite/name; result={'site_sha256':digest,'tools':ids,'results':[],'passed':False}
 if '--resume' in sys.argv and record.exists():
  old=json.loads(record.read_text());assert old['site_sha256']==digest
  for i,row in enumerate(old['results']):
   if row['exit_code']:break
   source=root/row['script_path'];assert row['script']==tasks[i][0] and sha(source)==row['test_sha256']
   result['results'].append(row)
 for script,args,adapt in tasks[len(result['results']):]:
  assert sha(stage)==digest
  source=root/('scripts' if script.endswith('.py') else 'tests')/script
  log=suite/(script+'.log');print('Executing',script,args,flush=True)
  if adapt=='fund':row=adapter['adapted_download'](script,args,log)
  elif adapt=='cost':row=adapter['adapted_cost_download'](script,log)
  elif adapt=='t05':row=adapter['adapted_t05_download'](log)
  elif adapt=='cost7':
   original=source.read_text();needle="frame.locator('[data-total]').innerText(),'7'";assert original.count(needle)==1
   text=original.replace(needle,"frame.locator('[data-total]').innerText(),'8'").replace("from 'playwright'",'from '+json.dumps((root/'node_modules/playwright/index.mjs').as_uri()))
   executed=suite/(script.removesuffix('.ts')+'-cost8.mts');executed.write_text(text)
   with log.open('w') as handle:r=subprocess.run(['node','--import',str(root/'node_modules/tsx/dist/loader.mjs'),str(executed)],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
   row={'script':script,'exit_code':r.returncode,'test_sha256':sha(source),'executed_test':str(executed.relative_to(root)),'executed_test_sha256':sha(executed),'adaptation':'Only original cost catalogue count 7 -> 8 and absolute Playwright import; all file and financial assertions retained'}
  else:
   command=[sys.executable,str(source)] if script.endswith('.py') else ['node','--import','tsx',str(source),*args]
   env=dict(os.environ)
   if script.startswith('r04-r05-'):env['AIPLUS_EVIDENCE_DIR']=str(suite)
   with log.open('w') as handle:r=subprocess.run(command,cwd=root,env=env,stdout=handle,stderr=subprocess.STDOUT)
   row={'script':script,'exit_code':r.returncode,'test_sha256':sha(source)}
  row.update(script_path=str(source.relative_to(root)),args=args,log=str(log.relative_to(root)),actual_execution_run_id=os.environ.get('AIPLUS_PARENT_RUN'))
  result['results'].append(row);record.write_text(json.dumps(result,indent=2)+'\n')
  if row['exit_code']:raise SystemExit('Failed '+script+'; actual log '+str(log))
 result['passed']=True;record.write_text(json.dumps(result,indent=2)+'\n')
print('All remaining current22 regression command groups passed',flush=True)
