"""Reconstruct exact count/path-only adapters; reject any other assertion changes."""
from pathlib import Path
import json, hashlib
root=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ids=[r['id'] for r in json.loads((root/'integration/native-site/site/registry.json').read_text())]
assert len(ids)==33 and ids[-2:]==['C03','C02']
suite=root/'progress/evidence/site-integration'/'-'.join(ids)
manifest=json.loads((suite/'current33-adapter-review.json').read_text())
for row in manifest['changes']:
    original=root/row['original']; adapted=root/row['adapted']
    assert sha(original)==row['original_sha256'] and sha(adapted)==row['adapted_sha256']
    expected=original.read_text()
    if original.suffix=='.py':
        expected=expected.replace(repr(ids[:-2]),repr(ids)).replace('current31','current33').replace('Fresh 27-stage','Fresh 33-stage')
        if original.name=='run-c01-current31.py':
            needle=" ('tests/a04-native-full-pages.ts','site-full-pages'),('tests/a04-native-downloads.ts','A04/downloads'),('tests/a04-native-navigation.ts','root-native-navigation')]"
            assert expected.count(needle)==1
            expected=expected.replace(needle,needle[:-1]+",\n ('tests/d01-native-site-current33.ts','site-local-current33'),('tests/d04-native-site-current33.ts','site-local-current33'),('tests/d05-native-site-current33.ts','site-local-current33'),('tests/c01-native-site-current33.ts','site-local-current33'),('scripts/run-c02-c03-current33-local.py',None)]")
    elif 'current31' in original.name:
        expected=expected.replace('current31','current33').replace("['D02','D06','D04','C01']","['D02','D06','D04','C01','C03']")
    else:
        expected=expected.replace(original.name,adapted.name).replace('site-local-with-C01','site-local-current33')
        if original.name=='c01-native-site.ts':expected=expected.replace("0.1.0/site-local'","0.1.0/site-local-current33'")
        if original.name.startswith(('d04','c01')):
            needle="frame.locator('[data-total]').innerText(),'16'"
            assert expected.count(needle)==1
            expected=expected.replace(needle,"frame.locator('[data-total]').innerText(),'17'").replace('existing_close_module_16_items','existing_close_module_17_items')
    assert expected==adapted.read_text(), 'Unexpected changed finance assertions: '+row['adapted']
print('18 adapters exactly reconstructable; original financial assertions unchanged')
