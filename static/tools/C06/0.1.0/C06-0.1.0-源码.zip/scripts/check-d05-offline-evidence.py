"""Bind D05 formal ZIP, actual browser replay and isolated source rebuild."""
import hashlib,json,pathlib,zipfile
root=pathlib.Path.cwd();release=root/'release/D05/0.1.0';evidence=root/'progress/evidence/D05/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
run=load(evidence/'root-formal-offline/run.json')
assert run['passed'] and len(run['commands'])==2
assert run['offline_zip_sha256']==sha(release/'D05-0.1.0-离线包.zip')
assert run['runner_sha256']==sha(root/'tests/d05-formal-runner.mjs')
for cmd in run['commands']:
 assert cmd['exit_code']==0 and cmd['script_sha256']==sha(root/cmd['script'])
for name,digest in run['assets'].items():assert digest==sha(release/name)
with zipfile.ZipFile(release/'D05-0.1.0-离线包.zip') as z:
 assert set(z.namelist())=={'D05/'+n for n in run['assets']}
 for n in run['assets']:assert hashlib.sha256(z.read('D05/'+n)).hexdigest()==run['assets'][n]
assert '空白模板.xlsx' in run['assets'] and '空白模板.csv' not in run['assets']
browser=load(evidence/'root-formal-offline/browser/result.json');native=load(evidence/'root-formal-offline/native/result.json')
assert browser['html_sha256']==sha(release/'index.html') and native['runtime_sha256']==sha(release/'runtime.json')
expected=['seven_business_pages','actual_xlsx_import_nine_manual_findings','finding_original_cell_trace','ignore_with_reason_and_revoke','actual_plan_work_template_sample_downloads','seven_sheet_unfiltered_workpaper_download_readback_no_executable_formulas','replace_clears_old_rules_results_and_ignored','restore_data_recheck_same_findings_and_ignore','no_data_restore_clear_and_apply_matching_workbook','400_findings_formulas_800_source_cells_last_page_reachable','large_all_rows_exported','21_page_geometries_long_scroll_mobile_no_outer_overflow','cancel_clear_preserves_confirm_clear_removes','offline_file_no_network_errors_or_storage']
assert browser['checks']==expected
assert native['checks']==['native_mount_same_9_findings','cancel_exit_preserves','confirm_exit_dispose','reenter_empty','21_simulated_fixed_host_geometry','no_network_or_errors']
for result in [browser,native]:
 assert not result['requests'] and not result['errors'] and len(result['geometry'])==21
 for g in result['geometry']:assert g['outer'] and g['heading']
source=release/'D05-0.1.0-源码.zip';assert source.stat().st_size<=24*1024*1024
with zipfile.ZipFile(source) as z:assert sum(x.file_size for x in z.infolist())<=250*1024*1024
rebuild=load(evidence/'source-rebuild.json');assert rebuild['source_zip_sha256']==sha(source)
assert len(rebuild['commands'])==4 and all(c['exit_code']==0 for c in rebuild['commands'])
assets=load(evidence/'source-rebuild-assets.json')
assert assets['source_zip_sha256']==sha(source) and set(assets['files'])==set(run['assets'])
for name,check in assets['files'].items():
 assert check['release_sha256']==sha(release/name)
 assert check['bytes_identical'] or (name.endswith('.xlsx') and check['content_identical_except_created_modified'])
with zipfile.ZipFile(source) as z:
 for name in ['tests/d05-independent-review.ts','tests/d05-formal-browser.ts','tests/d05-formal-native.ts','tests/d05-formal-runner.mjs','scripts/check-d05-offline-evidence.py','scripts/verify-source.py','packages/core/release-assets.ts']:
  assert hashlib.sha256(z.read(name)).hexdigest()==sha(root/name)
receipt={'passed':True,'scope':'formal offline and isolated source only; website/Windows unverified','checks':20,'geometry':42,'source_zip_sha256':sha(source),'offline_zip_sha256':sha(release/'D05-0.1.0-离线包.zip'),'verifier_sha256':sha(pathlib.Path(__file__)),'source_rebuild_assets_sha256':sha(evidence/'source-rebuild-assets.json')}
(evidence/'root-formal-offline/check.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
