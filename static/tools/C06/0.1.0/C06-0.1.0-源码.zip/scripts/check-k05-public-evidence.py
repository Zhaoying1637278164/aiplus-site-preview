"""K05 actual public same-version workflow, archives and complete page gate."""
from pathlib import Path
import hashlib,json,re,zipfile
root=Path.cwd();ev=root/'progress/evidence/K05/0.1.0';release=root/'release/K05/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json');url='https://aiplus-guance.streamlit.app/~/+/'
for mode,script in [('work','k05-native-business-browser.ts'),('downloads','k05-native-downloads.ts'),('full','k05-native-full-pages.ts')]:
 b=ev/'site-public'/mode;c=read(b/'execution.json');receipt=read(b/'root-command.json')
 assert c['actual_subprocess_exit_code']==receipt['actual_exit_code']==0 and receipt['actual_session_id']
 assert c['public_url']==receipt['endpoint']==url and c['expected_site_sha256']==receipt['site_sha256']==site
 assert c['source_validator_sha256']==sha(root/'tests'/script) and c['executed_validator_sha256']==sha(b/'executed-public-validator.ts')
 assert c['native_bootstrap_sha256']==sha(root/'tests/k05-native-bootstrap.ts')
 folder=b/'K05/downloads' if mode=='downloads' else b;d=read(folder/'result.json')
 assert receipt['result_sha256']==sha(folder/'result.json')
 doc=(folder/'actual-srcdoc.html').read_text()
 assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
 if mode=='work':
  assert d['status']=='passed' and d['officialWebsite'] and d['siteSHA']==site and d['actualRuntimeSHA']==runtime
  assert d['candidate_sha']==html and d['runtime_sha']==runtime and d['errors']==d['requests']==[]
  assert len(d['checks'])==19 and len(d['downloads'])==24 and len(d['screens'])==27
  assert d['programs'] and all(p.startswith('https://aiplus-guance.streamlit.app/') and p.endswith('/K05/0.1.0/runtime.json') for p in d['programs'])
  assert len({row['artifact_file'] for row in d['downloads']})==24
  for row in d['downloads']:
   p=Path(row['artifact_file']);assert p.is_relative_to(b)
   assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 elif mode=='downloads':
  assert d['passed'] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime
  assert d['errors']==[] and d['clicks']==18
  expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
  assert len(expected)==16 and set(d['downloads'])==expected
  for name,h in d['downloads'].items():assert sha(folder/'site-local-downloads'/name)==sha(release/name)==h
  with zipfile.ZipFile(folder/'site-local-downloads/K05-0.1.0-离线包.zip') as z:
   expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
   assert set(z.namelist())=={'K05/'+n for n in expected}
   for n in expected:assert z.read('K05/'+n)==(release/n).read_bytes()
 else:
  assert d['passed'] and d['siteSHA']==site and d['actualRuntimeSHA']==runtime and len(d['images'])==27
  assert d['errors']==d['requests']==[]
visual=read(ev/'site-public/full/root-visual-review.json')
assert visual['actual_review'] and visual['site_sha256']==site and len(visual['files'])==27
for name,h in visual['files'].items():assert sha(Path(name))==h
local=read(ev/'local-delivery-audit.json');assert local['local_exact_gates_passed'] and local['site_sha256']==site
result={'tool':'K05','version':'0.1.0','public_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'public_workflow_groups':19,'additional_local_interface_groups':0,'actual_work_downloads':24,'full_images_reviewed':27,'version_download_clicks':18,'unique_version_files':16,'Windows_real_machine':'unverified'}
(ev/'site-public-final.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
