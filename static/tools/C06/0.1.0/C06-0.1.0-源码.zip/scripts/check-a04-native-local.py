"""Exact A04 offline and original-website local gate. No public acceptance."""
from pathlib import Path
import json,hashlib,subprocess,sys
from openpyxl import load_workbook
root=Path.cwd();base=Path('progress/evidence/A04/0.1.1');rel=Path('release/A04/0.1.1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
subprocess.run([sys.executable,'scripts/check-a04-offline-evidence.py'],check=True)
site=sha('integration/native-site/site/index.html');runtime=sha(rel/'runtime.json');html=sha(rel/'index.html')
folders=['root-native-business','root-native-pagination','root-native-navigation','site-full-pages','A04/downloads'];results={}
for folder in folders:
 p=base/folder;r=read(p/'result.json');c=read(p/'root-command.json')
 assert c['actual_exit_code']==0 and c['actual_terminal_chunk'] and c['actual_session']
 assert c['result_sha256']==sha(p/'result.json') and c['test_sha256']==sha(c.get('test',c.get('script')))
 assert c['site_sha256']==site and r.get('siteSHA',r.get('site_sha256'))==site
 assert r.get('actualRuntimeSHA',r.get('runtimeSHA',r.get('runtime_sha256')))==runtime
 assert r.get('passed') or r.get('status')=='passed';assert r['errors']==[]
 if folder!='A04/downloads':assert r['requests']==[]
 results[folder]=r
b=results['root-native-business'];assert len(b['checks'])==10 and len(b['downloads'])==26 and b['candidate_sha256']==html
assert len(b.get('reloadRequests',[]))>=1
from urllib.parse import urlparse
for u in b['reloadRequests']:
 p=urlparse(u);assert p.hostname=='127.0.0.1' and p.port==8515 and (p.path=='/' and p.query=='tool=A04' or p.path.startswith('/static/') or p.path in ['/_stcore/health','/_stcore/host-config','/favicon.png'])
p=results['root-native-pagination'];assert len(p['checks'])==12 and p['contracts']==203 and p['payments']==406 and p['html_sha256']==html
nav=results['root-native-navigation'];assert len(nav['geometry'])==27 and len(nav['checks'])==6
for g in nav['geometry']:assert not g['overflow'] and g['tool']['y']>=g['header']['bottom']-2 and g['tool']['bottom']<=g['footer']['top']+2
# Read all18 actual offline/site downloaded worksheets, every cell, independently.
for folder in ['business','pagination']:
 offline=base/('root-formal-offline/browser' if folder=='business' else 'root-formal-pagination')
 native=base/('root-native-business' if folder=='business' else 'root-native-pagination')
 filename='03-租赁测算完整底稿.xlsx' if folder=='business' else '1-租赁测算完整底稿.xlsx'
 a=offline/filename;bfile=native/filename;assert a.is_file() and bfile.is_file()
 a=load_workbook(a,read_only=True,data_only=False);bfile=load_workbook(bfile,read_only=True,data_only=False)
 assert a.sheetnames==bfile.sheetnames and len(a.sheetnames)==18
 for n in a.sheetnames:assert list(a[n].values)==list(bfile[n].values),(folder,n)
v=results['site-full-pages'];review=read(base/'site-full-pages/root-visual-review.json');assert len(v['images'])==27 and review['passed_layout_review']
for x in v['images']:assert sha(base/'site-full-pages'/x['file'])==x['sha256']==review['actual_reviewed_images'][x['file']]
d=results['A04/downloads'];assert d['clicks']==15 and len(d['downloads'])==13 and d['html_sha256']==html
for n,h in d['downloads'].items():assert sha(rel/n)==h==sha(base/'A04/downloads/site-local-downloads'/n)
reg=read('integration/native-site/site/registry.json');old=read('integration/history/A03-accepted26-before-next/site/registry.json')
assert len(reg)==27 and reg[:-1]==old and reg[-1]['id']=='A04' and reg[-1]['version']=='0.1.1' and not reg[-1].get('replacesOriginal')
for f in rel.iterdir():
 if f.is_file():assert sha(f)==sha(Path('integration/native-site/static/tools/A04/0.1.1')/f.name)
out={'passed':True,'tool':'A04','version':'0.1.1','site_sha256':site,'runtime_sha256':runtime,'html_sha256':html,'tools':27,'actual_local_groups':5,'result_hashes':{f:sha(base/f/'result.json') for f in folders},'all18_worksheet_cells_offline_equal_site':True,'large_pagination_cells_offline_equal_site':True,'public_verified':False,'whole27_regression_passed':False,'accepted':False,'scope':'Actual exact original website same-document nine pages, unchanged26 entries and original platform, entire18sheet workbook equality for business and203contract/406payment batch, navigation/reload/downloads. Whole27/public/Windows separate.'}
(base/'native-local-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('A04 exact five local website groups and full worksheet equality passed; whole27/public pending')
