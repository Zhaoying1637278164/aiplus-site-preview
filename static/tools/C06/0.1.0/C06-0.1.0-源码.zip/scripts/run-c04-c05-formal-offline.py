"""Actual formal extracted ZIP browsers; two independent tool runs, no site acceptance."""
from pathlib import Path
import concurrent.futures,hashlib,json,subprocess
root=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tasks={'C04':['tests/c04-formal-browser.ts','tests/c04-formal-large-browser.ts','tests/c04-formal-full-workbook.ts','tests/c04-formal-native.ts'],
       'C05':['tests/c05-formal-browser.ts','tests/c05-formal-browser-extra.ts','tests/c05-formal-bulk-browser.ts','tests/c05-formal-native.ts']}
def run(tool):
    out=root/'progress/evidence'/tool/'0.1.0/root-formal-offline'
    release=root/'release'/tool/'0.1.0'
    result={'tool':tool,'html_sha256':sha(release/'index.html'),'runtime_sha256':sha(release/'runtime.json'),
            'offline_zip_sha256':sha(release/f'{tool}-0.1.0-离线包.zip'),'passed':False,'finished':False,'commands':[],
            'public_verified':False,'accepted':False}
    for script in tasks[tool]:
        assert sha(release/'index.html')==result['html_sha256'] and sha(release/'runtime.json')==result['runtime_sha256']
        source=root/script;log=out/(source.stem+'.log');print('Executing',script,flush=True)
        with log.open('w') as handle:
            actual=subprocess.run(['node','--import','tsx',str(source)],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
        row={'script':script,'script_sha256':sha(source),'actual_exit_code':actual.returncode,'log':str(log.relative_to(root)),'log_sha256':sha(log)}
        result['commands'].append(row);(out/'run.json').write_text(json.dumps(result,indent=2)+'\n');print('Exit',actual.returncode,script,flush=True)
        if actual.returncode:return False
    result.update(passed=True,finished=True);(out/'run.json').write_text(json.dumps(result,indent=2)+'\n');return True
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(run,['C04','C05']))
if not all(results):raise SystemExit('Actual formal browser failed; preserve failures and inspect logs')
print('C04 and C05 formal browser command groups passed; visual/source/native original website gates separate',flush=True)
