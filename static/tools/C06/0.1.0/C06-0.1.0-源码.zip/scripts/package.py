import sys,pathlib,zipfile,json,hashlib
root=pathlib.Path.cwd();out=pathlib.Path(sys.argv[1]);version=out.name;tool=out.parent.name
catalog=json.loads((root/'catalog/tools.json').read_text())
entry=next(t for t in catalog if t['id']==tool)
locks=json.loads((root/'catalog/release-locks.json').read_text())
if any(r['tool']==tool and r['version']==version for r in locks['releases']):
 raise SystemExit('冻结版本禁止重新打包；变更须发布新版本。')
if entry['version']!=version or entry['status'] not in ['tested','packaged']:
 raise SystemExit('仅可打包当前已测试且未冻结的版本。')
threads={t['tool_id']:t for t in json.loads((root/'catalog/threads.json').read_text())['tools']}
def source_locked(t):
 return t['status']=='accepted' or threads.get(t['id'],{}).get('thread_status')=='handed_off_formal_integration'
if not source_locked(entry):
 raise SystemExit('工具源码仍活动或待修正；正式交接锁定后才可打包。')
stable=[t for t in catalog if t['status'] in ['tested','packaged','accepted']
        and source_locked(t) and (root/'tools'/t['folder']/'src/main.tsx').is_file()]
stable_ids={t['id'] for t in stable}
excluded=[t['id'] for t in catalog if t['id'] not in stable_ids
          and ((root/'tools'/t['folder']/'src/main.tsx').is_file() or threads.get(t['id'],{}).get('thread_status','').startswith('active_'))]
stage_registry=root/'integration/native-site/site/registry.json'
current_suite='-'.join(e['id'] for e in json.loads(stage_registry.read_text())) if stage_registry.exists() else None
def source_file(f):
 # Keep source/tests/current public evidence; omit duplicate generated candidates and
 # superseded evidence snapshots. These stay in the repository, not in every ZIP.
 parts=f.relative_to(root).parts
 if parts[:2]==('progress','history'):return False
 # Whole-site replay outputs are generated integration evidence, not source or
 # rebuild fixtures. Keep their replay scripts and authoritative repository data;
 # duplicating these growing batches in every source ZIP breaks bounded downloads.
 if parts[:3]==('progress','evidence','site-integration'):return False
 # Extracted rebuild checkouts and raw platform WebSocket captures are generated
 # diagnostics. Keep source-rebuild receipts and replay code, not copied sources.
 if parts[:2]==('progress','evidence') and any(p in ['source-rebuild','source','rebuilt-source'] for p in parts[2:]):return False
 if parts[:2]==('progress','evidence') and f.suffix=='.protobuf':return False
 # Boundary suites generate these all-space oversized files themselves. Retain
 # generators and rejection receipts, not hundreds of MiB of repeated padding.
 if parts[:2]==('progress','evidence') and f.stem=='oversize':return False
 # Sibling public-site export workbooks duplicate formal/local export evidence.
 # They stay in the repository; retain this tool's actual outputs and all source
 # fixtures, tests, independent answers and structured public receipts.
 if parts[:2]==('progress','evidence') and len(parts)>2 and parts[2]!=tool and 'site-public' in parts and f.suffix=='.xlsx':return False
 # Other tools' generated workbook outputs are reproduced by their included
 # browser tests. Keep source fixtures under tools/fixtures and structured
 # result/hash receipts; do not duplicate every sibling's export in this ZIP.
 if parts[:2]==('progress','evidence') and len(parts)>2 and parts[2]!=tool and f.suffix=='.xlsx':return False
 # Large sibling generated work/exports duplicate replay outputs. Original fixtures
 # and independent oracles stay under tools; result/hash receipts remain included.
 if parts[:2]==('progress','evidence') and len(parts)>2 and parts[2]!=tool and f.suffix=='.json' and f.stat().st_size>1024*1024 and f.name not in ['result.json','handoff.json','check.json','oracle.json']:return False
 # Superseded stage-suite replay outputs remain in the repository; current suite stays.
 if parts[:3]==('progress','evidence','site-integration') and len(parts)>3 and parts[3].startswith('D02') and parts[3]!=current_suite:return False
 if len(parts)>2 and parts[:2]==('progress','evidence') and parts[2] in excluded:return False
 if parts[0]=='fixtures' and len(parts)>1 and parts[1] in excluded:return False
 # Root validation scripts importing active tool code must not make that tool a
 # hidden source-build dependency. Shared infrastructure without imports stays.
 if parts[0] in ['tests','scripts'] and f.is_file() and f.suffix in ['.ts','.tsx','.py']:
  text=f.read_text()
  if any('tools/'+t['folder']+'/' in text for t in catalog if t['id'] in excluded):return False
 # Screenshots remain in the evidence repository; source downloads retain code,
 # independent expected answers, structured results and actual input/output files.
 if 'evidence' in parts and f.suffix.lower() in ['.png','.jpg','.jpeg','.webp']:return False
 # Legacy D03 rendered UI checks live beside tests, not input fixtures.
 # Keep their replay code/results; generated screenshots remain in the repository.
 # Candidate programs are generated duplicates; retain their source/build/tests.
 if parts[0]=='tools' and 'candidate' in parts:return False
 if parts[0]=='tools' and 'ui-preflight' in parts and f.suffix.lower() in ['.png','.jpg','.jpeg','.webp']:return False
 # Rendered HTML is generated evidence, not a source dependency; retain hashes and replay scripts.
 if 'evidence' in parts and f.suffix.lower()=='.html':return False
 if 'evidence' in parts and 'history' in parts:return False
 if 'evidence' in parts and 'candidate' in parts:return False
 # Repeated extracted/site-fixture program bundles are rebuilt from included
 # tools/shared source. Retain their hash receipts and replay code, not bundles.
 if 'evidence' in parts and f.name in ['runtime.json','build-manifest.json']:return False
 # Formal test program mirrors are generated release bytes; source and fixtures
 # are already included under tools, so do not duplicate runtime bundles.
 if 'evidence' in parts and 'root-formal' in parts and 'program' in parts:return False
 return (f.is_file() and f.suffix not in ['.zip','.pyc','.pyo']
         and not any(p in ['node_modules','__pycache__','.git'] for p in f.parts)
         and f.name not in ['.DS_Store','finance-reconciliation.md','upstream-tree.json'])
with zipfile.ZipFile(out/f'{tool}-{version}-离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(out.iterdir()):
  if f.is_file() and f.suffix!='.zip':z.write(f,tool+'/'+f.name)
with zipfile.ZipFile(out/f'{tool}-{version}-源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 snapshot={}
 for name in ['package.json','package-lock.json','tsconfig.json','README.md','工具总览.md','AGENTS.md','CLAUDE.md']:
  content=(root/name).read_bytes();snapshot[name]=hashlib.sha256(content).hexdigest();z.writestr(name,content)
 implemented=['tools/'+t['folder'] for t in stable]
 for folder in ['apps','packages','scripts','tests','fixtures','docs','catalog','references','progress','website']+implemented:
  for f in sorted((root/folder).rglob('*')):
   if source_file(f):
    relative=str(f.relative_to(root));content=f.read_bytes()
    snapshot[relative]=hashlib.sha256(content).hexdigest();z.writestr(relative,content)
 content=(out/'THIRD_PARTY_NOTICES.md').read_bytes()
 snapshot['THIRD_PARTY_NOTICES.md']=hashlib.sha256(content).hexdigest()
 z.writestr('THIRD_PARTY_NOTICES.md',content)
 z.writestr('source-snapshot.json',json.dumps({'schema_version':1,'tool':tool,'version':version,
  'included_tools':sorted(stable_ids),'excluded_active_tools':excluded,
  'excluded_generated_media':'Evidence screenshots are retained in the project repository, not duplicated in source ZIPs.',
  'reason':'Include stable regression dependencies; active tool source/evidence is not a delivery dependency.',
  'file_sha256':snapshot},ensure_ascii=False,indent=2)+'\n')
