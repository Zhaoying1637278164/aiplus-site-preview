"""Report current26 images needing real inspection; never assert unseen review."""
from pathlib import Path
import json,hashlib
root=Path.cwd();read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ids=[r['id'] for r in read(root/'integration/native-site/site/registry.json')];suite=root/'progress/evidence/site-integration'/'-'.join(ids);parent=read(suite/'root-current26-commands.json');assert parent['passed'];old_suite=suite.parent/'-'.join(ids[:-1]);old=read(old_suite/'rendered-review.json');assert old['reviewed'] and old['passed'];unchanged={};changed=[];missing=[]
for file,h in old['screenshots'].items():
 fresh=root/file.replace(str(old_suite.relative_to(root)),str(suite.relative_to(root)));name=str(fresh.relative_to(root))
 if not fresh.is_file():missing.append(name);continue
 digest=sha(fresh)
 if digest==h:unchanged[name]=digest
 else:changed.append({'file':name,'old_sha256':h,'new_sha256':digest})
a03=root/'progress/evidence/A03/0.1.0/site-full-pages';r=read(a03/'root-visual-review.json');assert r['actual_review']
for f,h in r['images'].items():assert sha(a03/f)==h;unchanged[str((a03/f).relative_to(root))]=h
out={'site_sha256':sha(root/'integration/native-site/site/index.html'),'old_actual_review':str((old_suite/'rendered-review.json').relative_to(root)),'old_review_sha256':sha(old_suite/'rendered-review.json'),'unchanged_or_a03_actual_review':unchanged,'changed_needing_actual_view':changed,'missing':missing,'accepted':False,'scope':'Strict old image byte identity plus actual A03 contact-sheet layout review; changed images require inspection before binding'};(suite/'root-current26-visual-change-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('Exact old/A03 actual reviews',len(unchanged),'changed',len(changed),'missing',len(missing))
if changed or missing:raise SystemExit(1)
