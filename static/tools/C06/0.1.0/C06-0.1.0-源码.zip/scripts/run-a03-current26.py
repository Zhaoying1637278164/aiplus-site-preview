"""Execute fresh whole-site regressions for exact A03 stage; no acceptance claim."""
from pathlib import Path
import hashlib,json,subprocess,sys,os,shutil
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stage=root/'integration/native-site/site/index.html';digest=sha(stage)
ids=[x['id'] for x in json.loads((stage.parent/'registry.json').read_text())]
assert ids==['D02', 'D03', 'D06', 'R01', 'R02', 'R03', 'R04', 'R05', 'P01', 'P02', 'P03', 'P04', 'T01', 'T02', 'T03', 'T05', 'K02', 'K01', 'T04', 'T06', 'K03', 'K04', 'A01', 'K05', 'A02', 'A03']
suite=root/'progress/evidence/site-integration'/'-'.join(ids);suite.mkdir(parents=True,exist_ok=True)
# Preserve current actual outputs before fresh stage overwrites them.
for tool,version,folders in [
 ('A01','0.1.1',['root-native-business-browser','root-native-pagination','A01/downloads','site-full-pages']),
 ('K03','0.1.0',['site-full-pages']),('K04','0.1.0',['site-guide-readable']),
]:
 ev=root/'progress/evidence'/tool/version
 for folder in folders:
  source=ev/folder;target=ev/'history/before-current26'/folder
  if source.exists() and not target.exists():shutil.copytree(source,target)
tasks=[('scripts/run-a03-base-current26.py',None),('scripts/run-a03-remaining-current26.py',None),('scripts/run-a03-visual-current26.py',None),
 ('tests/a01-native-business-browser.ts','root-native-business-browser'),('tests/a01-native-pagination.ts','root-native-pagination'),
 ('tests/a01-native-downloads-current26.ts','A01/downloads'),('tests/a01-native-full-pages.ts','site-full-pages'),
 ('tests/a02-native-business-browser.ts','root-native-business-browser'),('tests/a02-native-pagination.ts','root-native-pagination'),
 ('tests/a02-native-downloads-current26.ts','A02/downloads'),('tests/a02-native-full-pages.ts','site-full-pages'),
 ('tests/a02-native-navigation-current26.ts','root-native-navigation'),('tests/t06-native-visual.ts','site-visual')]
record=suite/'root-current26-commands.json';result={'site_sha256':digest,'tools':ids,'results':[],'passed':False,'public_verified':False}
if '--resume' in sys.argv and record.exists():
 old=json.loads(record.read_text());assert old['site_sha256']==digest and old['tools']==ids
 for i,row in enumerate(old['results']):
  if row['actual_exit_code']:break
  assert row['script']==tasks[i][0] and row['script_sha256']==sha(root/row['script'])
  result['results'].append(row)
env=dict(os.environ);env['AIPLUS_PARENT_RUN']='A03-current26-'+digest
for script,folder in tasks[len(result['results']):]:
 assert sha(stage)==digest
 source=root/script;log=suite/(source.name+'.root-current26.log');print('Executing',script,flush=True)
 command=[sys.executable,str(source)] if source.suffix=='.py' else ['node','--import','tsx',str(source)]
 if '--resume' in sys.argv and source.name=='run-a02-remaining-current26.py':command.append('--resume')
 with log.open('w') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'script':script,'script_sha256':sha(source),'actual_exit_code':r.returncode,'site_sha256':digest,'log':str(log.relative_to(root))}
 if folder and r.returncode==0:
  tool,version=('A02','0.1.0') if source.name.startswith('a02-') else ('T06','0.1.0') if source.name.startswith('t06-') else ('A01','0.1.1')
  out=root/'progress/evidence'/tool/version/folder
  row['result_sha256']=sha(out/'result.json')
  (out/'root-command.json').write_text(json.dumps({'exit_code':0,'test_sha256':sha(source),'result_sha256':row['result_sha256'],'site_sha256':digest,'executed_by':'scripts/run-a03-current26.py','actual_execution_run_id':env['AIPLUS_PARENT_RUN'],'log':row['log']},indent=2)+'\n')
 result['results'].append(row);record.write_text(json.dumps(result,indent=2)+'\n');print('Exit',r.returncode,script,flush=True)
 if r.returncode:raise SystemExit('Failed '+script+'; '+str(log))
result['passed']=True;record.write_text(json.dumps(result,indent=2)+'\n')
print('Fresh 26-stage regressions passed; visual review and local/public gates remain separate.',flush=True)
