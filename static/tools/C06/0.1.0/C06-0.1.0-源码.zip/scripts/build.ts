import {build} from 'esbuild';
import {mkdir,readFile,writeFile,copyFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync} from 'node:fs';
import {workbookBytes} from '../packages/core/io';
import type {Table} from '../packages/core/types';
import {validateReleaseAssets,type ReleaseAsset} from '../packages/core/release-assets';
const id=process.argv[2]||'D02';
const registry=JSON.parse(await readFile('catalog/tools.json','utf8')) as {id:string;name:string;folder:string;status:string;version:string}[];
const entry=registry.find(t=>t.id===id);
if(!entry||!existsSync(path.join('tools',entry.folder,'src/main.tsx')))throw Error('尚未实现该工具，不能生成占位成品');
const folder='tools/'+entry.folder,name=entry.name;
const versionModule=['version','types','engine'].find(module=>existsSync(folder+'/src/'+module+'.ts'));
if(!versionModule)throw Error('缺少工具版本声明；不能猜测应用版本');
const {VERSION}=await import('../'+folder+'/src/'+versionModule+'.ts') as {VERSION:string};
if(!/^\d+\.\d+\.\d+$/.test(VERSION))throw Error('应用版本无效');
const hasNative=existsSync(folder+'/src/program.tsx');
const out=path.resolve('release',id,VERSION);await mkdir(out,{recursive:true});
const options={outfile:'bundle.js',bundle:true,write:false,platform:'browser' as const,format:'iife' as const,target:['es2022'],minify:true,define:{'process.env.NODE_ENV':'"production"'},metafile:true,alias:{exceljs:'exceljs/lib/exceljs.bare.js'},inject:['packages/core/browser-globals.ts'],plugins:[{name:'browser-io-boundary',setup(b:import('esbuild').PluginBuild){b.onResolve({filter:/^(fs|crypto)$/},()=>({path:path.resolve('packages/core/browser-disabled.cjs')}));b.onResolve({filter:/^\.\.\/csv\/csv$/},()=>({path:path.resolve('packages/core/browser-csv-disabled.cjs')}))}}]};
const bundled=await build({...options,entryPoints:[folder+'/src/main.tsx']});
const js=bundled.outputFiles!.find(f=>f.path.endsWith('.js'))!.text;
const css=(hasNative?'body{margin:0;background:#fff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;}':'')+(bundled.outputFiles!.find(f=>f.path.endsWith('.css'))?.text||'');
const html=`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; font-src 'none'; base-uri 'none'; form-action 'none'"><title>${id} ${name} · ${VERSION}</title><style>${css}</style></head><body><div id="root"></div><script>${js.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
let nativeManifest:{sha256:string;bytes:number}|undefined,nativePayload:string|undefined;
if(hasNative){
 const native=await build({...options,entryPoints:[folder+'/src/program.tsx'],globalName:'__AIPlusProgram'});
 const nativeJS=native.outputFiles!.find(f=>f.path.endsWith('.js'))!.text;
 nativePayload=JSON.stringify({schema_version:1,id,version:VERSION,name,css:native.outputFiles!.find(f=>f.path.endsWith('.css'))?.text||'',js:`(()=>{${nativeJS};window.__aiPlusLoadedProgram=__AIPlusProgram.program;})();`});
 const bytes=Buffer.byteLength(nativePayload);if(bytes>8*1024*1024)throw Error('原生工具程序超过8MB上限');
 nativeManifest={sha256:createHash('sha256').update(nativePayload).digest('hex'),bytes};
 Object.assign(bundled.metafile!.inputs,native.metafile!.inputs);
}
const locks=JSON.parse(await readFile('catalog/release-locks.json','utf8')) as {releases:{tool:string;version:string;files:Record<string,string>}[]};
const locked=locks.releases.find(r=>r.tool===id&&r.version===VERSION);
if(locked){
 for(const [file,expected] of Object.entries(locked.files)){
  const bytes=await readFile(path.join(out,file));
  if(createHash('sha256').update(bytes).digest('hex')!==expected)throw Error(`冻结版本文件已变化：${id}/${VERSION}/${file}；不得覆盖历史交付包`);
 }
}
if((locked||registry.some(t=>t.id===id&&t.status==='accepted'&&t.version===VERSION))&&existsSync(path.join(out,'index.html'))){
 const existing=await readFile(path.join(out,'index.html'),'utf8');
 if(createHash('sha256').update(existing).digest('hex')!==createHash('sha256').update(html).digest('hex'))throw Error('该版本已验收；程序变化必须发布新版本，不能覆盖既有交付包');
 if(nativePayload&&existsSync(path.join(out,'runtime.json'))&&createHash('sha256').update(await readFile(path.join(out,'runtime.json'))).digest('hex')!==nativeManifest!.sha256)throw Error('原生程序已变化；必须发布新版本，不能覆盖既有交付包');
 console.log(`已重建并核对 ${id} ${VERSION}；已发布版本包保持不变（不受产品复审状态影响）`);process.exit(0);
}
await writeFile(path.join(out,'index.html'),html);
if(nativePayload)await writeFile(path.join(out,'runtime.json'),nativePayload);
const assetModule=folder+'/src/release-assets.ts';
if(hasNative&&id!=='D02'){
 if(!existsSync(assetModule))throw Error('原生工具缺少本款模板与虚构样例交付接口');
 const {releaseAssets}=await import('../'+assetModule) as {releaseAssets:()=>Promise<ReleaseAsset[]>};
 const assets=await releaseAssets();
 // The website has one standard template entry. T01 retains both financial
 // side names; their empty schemas must agree before exposing the shared alias.
 if(id==='T01'&&!assets.some(a=>a.filename==='空白模板.csv')){
  const bank=assets.find(a=>a.filename==='银行流水空白模板.csv');
  const book=assets.find(a=>a.filename==='企业日记账空白模板.csv');
  if(!bank||!book||Buffer.from(bank.data).compare(Buffer.from(book.data))!==0)throw Error('银行与企业空白字段不一致，不能生成统一模板入口');
  assets.push({filename:'空白模板.csv',data:bank.data});
 }
 validateReleaseAssets(assets,id==='D05'?'空白模板.xlsx':'空白模板.csv');
 for(const [file,destination] of [['README.md','使用说明.md'],['财务规则.md','财务规则.md'],['参考来源.md','参考来源.md']])await copyFile(folder+'/'+file,path.join(out,destination));
 if(id==='T01'||id==='T02'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  const usage=`应用 ${VERSION}。解压离线包后，用 Chrome 或 Edge 双击 index.html；无需安装，断网可用。先体验完全虚构样例，再导入本机资料。用户数据只在浏览器内存，关闭或退出清空。源码包包含锁文件、共享包、本款代码、测试、说明与声明。Windows 实机未验证；官网验收状态见项目 progress/STATUS.md。`;
  await writeFile(path.join(out,'使用说明.md'),id==='T01'?explanation.replace(/^候选 0\.1\.0[^\n]+/m,usage+' 银行流水空白模板与企业日记账空白模板字段相同；统一空白模板入口保留相同字段，两侧仍分别导入。'):explanation.replace(/^候选0\.1\.0[^\n]+/m,usage));
 }
 if(id==='P02'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  await writeFile(path.join(out,'使用说明.md'),explanation.replace(/候选0\.1\.0，本工具线程自测状态tested[^\n]+/,`应用 ${VERSION}。下载离线包并解压后，用 Chrome 或 Edge 双击本文件夹内的 index.html；无需安装，断网也可使用。先载入完全虚构样例，再导入自己的资料。源码包包含锁文件、共享包、本款源码、测试、构建说明和第三方声明。Windows 实机未验证；官网最终验收状态见项目 progress/STATUS.md。`));
 }
 if(id==='P03'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  await writeFile(path.join(out,'使用说明.md'),explanation.replace(/^候选0\.1\.0[^\n]+/m,`应用 ${VERSION}。解压离线包后，用 Chrome 或 Edge 双击本文件夹内的 index.html；无需安装，断网可用。先查看完全虚构样例，再导入自己的资料。用户数据只在浏览器内存处理，关闭即清除，不要求账户或 API Key，不上传或默认保存。Windows 实机未验证。源码包包含锁文件、共享包、工具源码、测试、构建说明和第三方声明；官网验收状态见项目 progress/STATUS.md。`));
 }
 if(id==='D05'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  await writeFile(path.join(out,'使用说明.md'),explanation
   .replace(/^候选0\.1\.0[^\n]+/m,`应用 ${VERSION}。下载离线包并解压后，用 Chrome 或 Edge 双击本文件夹内 index.html；无需安装，断网可用。源码包包含锁文件、共享包、本款源码、测试、参考许可和构建说明；官网实际验收状态见项目 progress/STATUS.md。Windows 实机未验证。`)
   .replace('打开候选index.html','打开本文件夹内 index.html')
   .replace('本机macOS Chrome headless已候选测试；Windows实机、官网、总控独立验收未验证。','平台和官网验证证据见项目 progress/STATUS.md；Windows 实机未验证。')
   .replace('源码候选包含','同版本源码包含').replace('按[实现交接](实现交接.md)复建。','解压源码后依次运行 `npm ci`、`npm test`、`npm run typecheck`、`npm run build -- D05` 重建；见 docs/source-build.md。')
   .replace('[规格与独立预期](规格与独立预期.md)','规格与独立预期见源码包本款目录').replace('[验收证据](验收证据.md)','实际验收证据见项目 progress/STATUS.md'));
 }
 if(id==='D04'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  await writeFile(path.join(out,'使用说明.md'),explanation
   .replace(/^候选0\.1\.0[^\n]+/m,`应用 ${VERSION}。本包包含本机程序、完整说明、财务规则、模板、完全虚构PDF与Excel预期样例。官网和平台实际验收状态见项目 progress/STATUS.md；Windows 实机未验证。`)
   .replace('双击 candidate/0.1.0/index.html','下载离线包并解压后，双击本文件夹内 index.html')
   .replace('根 `npm run build -- D04` 及正式ZIP源重建由总控执行。','同版本源码解压后使用 `npm ci`、`npm test`、`npm run typecheck`、`npm run build -- D04` 重建；详细说明见源码包 docs/source-build.md。'));
 }
 if(id==='C02'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  await writeFile(path.join(out,'使用说明.md'),explanation
   .replace(/^候选0\.1\.0[^\n]+/m,`应用 ${VERSION}，完整八页财务流程。下载离线包并解压后，用 Chrome 或 Edge 双击本文件夹内 index.html；断网可用，无需账号或安装。官网及平台实际验收状态见项目 progress/STATUS.md；Windows 实机未验证。`)
   .replace('详细口径见财务规则.md，来源版本/许可见参考来源.md，实际状态见验收证据.md和实现交接.md。','详细口径见本文件夹内财务规则.md，来源版本/许可见参考来源.md；验收证据和实现交接见源码包本款目录。')
   +`\n同版本源码包解压后，使用 Node.js 22 或以上，依次运行 npm ci、npm test、npm run typecheck、npm run build -- C02。输出 release/C02/${VERSION}/index.html 与 runtime.json；构建说明见 docs/source-build.md。源码重建只生成本机成品，不自动修改官网。\n`);
 }
 if(id==='C03'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  await writeFile(path.join(out,'使用说明.md'),explanation
   .replace(/^候选0\.1\.0[^\n]+/m,`应用 ${VERSION}。下载离线包并解压后，用 Chrome 或 Edge 双击本文件夹内 index.html；断网可用，无需账号或安装。官网与平台实际验收状态见项目 progress/STATUS.md；Windows 实机未验证。`)
   .replace('输出tools/C03-待摊费用排程/candidate/0.1.0/index.html及runtime.json。',`输出release/C03/${VERSION}/index.html及runtime.json。`)
   .replace('此候选构建脚本不修改正式release/catalog/官网。','源码重建只生成本机成品，不自动修改官网。'));
 }
 if(id==='C04'||id==='C05'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  await writeFile(path.join(out,'使用说明.md'),explanation
   .replace(/^候选0\.1\.0[^\n]+/m,`应用 ${VERSION}，完整十一页财务流程。下载离线包并解压后，用 Chrome 或 Edge 双击本文件夹内 index.html；断网可用，无需账号或安装。官网及平台实际验收状态见项目 progress/STATUS.md；Windows 实机未验证。`)
   .replace('打开candidate/0.1.0/index.html','打开本文件夹内 index.html')
   .replace('候选证据详见验收证据.md','实际证据见源码包本款验收证据.md')
   +`\n同版本源码包包含锁文件、共享包、本款源码、测试、参考许可及构建说明。解压后使用 Node.js 22 或以上，依次运行 npm ci、npm test、npm run typecheck、npm run build -- ${id}，输出 release/${id}/${VERSION}/index.html 和 runtime.json；见 docs/source-build.md。源码重建只生成本机成品，不自动修改官网。\n`);
 }
 if(id==='C06'){
  const explanation=await readFile(path.join(out,'使用说明.md'),'utf8');
  await writeFile(path.join(out,'使用说明.md'),explanation
   .replace(/^候选0\.1\.0[^\n]+/m,`应用 ${VERSION}，完整八页财务流程。下载离线包并解压后，用 Chrome 或 Edge 双击本文件夹内 index.html；断网可用，无需账号或安装。官网及平台实际验收状态见项目 progress/STATUS.md；Windows 实机未验证。`)
   .replace('解压候选离线包','解压离线包')
   .replace('源码包根依次执行npm ci、npm test、npm run typecheck、npm run build。','源码包根依次执行 npm ci、npm test、npm run typecheck、npm run build -- C06。')
   .replace('候选产物tools/C06-总账明细账对账/candidate/0.1.0',`正式重建输出 release/C06/${VERSION}/index.html 与 runtime.json`)
   .replace('正式源码包/官网发布由总控接入，不计本线程完成。','源码包包含锁文件、共享包、工具代码、测试、声明及 docs/source-build.md；官网实际验收见项目 progress/STATUS.md。')
   .replace('真实官网/Windows/正式包未验证；停写供总控验收。','正式包与官网实际验收证据见项目 progress/STATUS.md；Windows 实机未验证。'));
 }
 for(const asset of assets)await writeFile(path.join(out,asset.filename),asset.data);
 if(id==='C06')execFileSync('python3',['scripts/stabilize-xlsx-container.py',path.join(out,'虚构样例.xlsx')]);
}else if(id==='D02'){
const {leftExample,rightExample}=await import('../'+folder+'/src/example.ts') as {leftExample:Table;rightExample:Table};
await copyFile(folder+'/README.md',path.join(out,'使用说明.md'));
await copyFile(folder+'/财务规则.md',path.join(out,'财务规则.md'));
await copyFile(folder+'/参考来源.md',path.join(out,'参考来源.md'));
for(const [label,t] of [['左',leftExample],['右',rightExample]] as const){
 const csv='\uFEFF'+[t.headers,...t.rows.map(r=>t.headers.map(h=>r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
 await writeFile(path.join(out,`虚构${label}表.csv`),csv);
}
await writeFile(path.join(out,'空白模板.csv'),'\uFEFF单据号,金额,日期,币种\r\n');
await writeFile(path.join(out,'虚构样例.xlsx'),await workbookBytes([leftExample,rightExample].map((t,i)=>({name:i?'右表':'左表',headers:t.headers,rows:t.rows.map(r=>t.headers.map(h=>r.cells[h]))}))));
}else if(id==='D06'){
 const {example:qualityExample}=await import('../'+folder+'/src/example.ts') as {example:Table};
 const {sampleBytes}=await import('../'+folder+'/src/sample-file.ts');
 await copyFile(folder+'/README.md',path.join(out,'使用说明.md'));
 for(const f of ['财务规则.md','参考来源.md'])await copyFile(folder+'/'+f,path.join(out,f));
 await writeFile(path.join(out,'空白模板.csv'),'\uFEFF'+qualityExample.headers.join(',')+'\r\n');
 const csv='\uFEFF'+[qualityExample.headers,...qualityExample.rows.map(r=>qualityExample.headers.map(h=>typeof r.cells[h]==='object'&&r.cells[h]!==null?'FORMULA_NOT_SUPPORTED':r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
 await writeFile(path.join(out,'虚构样例.csv'),csv);
 await writeFile(path.join(out,'虚构样例.xlsx'),await sampleBytes());
}
if(id==='D03'&&!hasNative){
 const {input:mappingInput,dictionary:mappingDictionary,mapping:mappingExample}=await import('../'+folder+'/src/example.ts') as {input:Table;dictionary:Table;mapping:unknown};
 const {sampleBytes:mappingSampleBytes}=await import('../'+folder+'/src/sample-file.ts');
 const {encodeMapping}=await import('../'+folder+'/src/plan.ts');
 for(const [f,destination] of [['README.md','使用说明.md'],['财务规则.md','财务规则.md'],['参考来源.md','参考来源.md']])await copyFile(folder+'/'+f,path.join(out,destination));
 for(const [t,label] of [[mappingInput,'原表'],[mappingDictionary,'字典']] as const){
  const csv='\uFEFF'+[t.headers,...t.rows.map(r=>t.headers.map(h=>typeof r.cells[h]==='object'&&r.cells[h]!==null?'FORMULA_NOT_SUPPORTED':r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
  await writeFile(path.join(out,`虚构${label}.csv`),csv);
  await writeFile(path.join(out,label==='原表'?'空白模板.csv':'字典模板.csv'),'\uFEFF'+t.headers.join(',')+'\r\n');
 }
 await writeFile(path.join(out,'虚构样例.xlsx'),await mappingSampleBytes());
 await writeFile(path.join(out,'虚构映射版本.json'),encodeMapping(mappingExample));
}
// Preserve notices from every runtime package actually included in the browser bundle.
const roots=new Set<string>();
for(const input of Object.keys(bundled.metafile!.inputs)){
 if(!input.startsWith('node_modules/'))continue;
 const parts=input.split('/');roots.add(parts.slice(0,parts[1].startsWith('@')?3:2).join('/'));
}
let notices='# 第三方声明\n\n本产品自主实现；以下从锁定源码构建的实际浏览器依赖。未使用ExcelJS预打包dist，故版本与打包输入逐项对应。\n';
for(const root of [...roots].sort()){
 const p=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));const files=(await readdir(root)).filter(n=>/^(licen[cs]e|copying|notice)(\.|$|-)/i.test(n));
 if(!files.length&&p.name!=='saxes')throw Error(`缺少依赖许可文本 ${root}`);
 notices+=`\n## ${p.name} ${p.version} (${p.license||'见文本'})\n`;
 if(p.name==='saxes')notices+=await readFile('references/saxes-5.0.1-LICENSE','utf8');
 for(const file of files)notices+=`\n### ${file}\n\n${await readFile(path.join(root,file),'utf8')}\n`;
}
notices+='\n## pako zlib port notice\n\n'+await readFile('node_modules/pako/lib/zlib/README','utf8');
// Vendored runtime code is absent from node_modules; bind its notices to the
// exact bundled inputs and source/license bytes instead of a candidate bundle.
type VendorFile={path:string;sha256:string};
type VendorNotice={name:string;version:string;runtime_files:VendorFile[];license_files:VendorFile[];notice:string};
const vendorRegistry=JSON.parse(await readFile('catalog/vendor-notices.json','utf8')) as {schema_version:number;tools:Record<string,VendorNotice[]>};
if(vendorRegistry.schema_version!==1)throw Error('第三方vendor登记版本无效');
const vendors=vendorRegistry.tools[id]||[];
const vendorInputs=Object.keys(bundled.metafile!.inputs).filter(input=>input.includes('/vendor/'));
const declared=new Set(vendors.flatMap(v=>v.runtime_files.map(f=>f.path)));
if(vendorInputs.some(input=>!declared.has(input)))throw Error('实际vendor运行代码缺少第三方声明登记');
for(const vendor of vendors){
 if(!vendor.runtime_files.length||!vendor.license_files.length)throw Error('vendor声明缺少运行源码或许可');
 notices+=`\n## ${vendor.name} ${vendor.version}\n\n${vendor.notice}\n`;
 for(const file of [...vendor.runtime_files,...vendor.license_files]){
  if(!file.path.startsWith(folder+'/vendor/')||file.path.includes('..')||! /^[a-f0-9]{64}$/.test(file.sha256))throw Error('vendor声明路径或哈希无效');
  const bytes=await readFile(file.path);
  if(createHash('sha256').update(bytes).digest('hex')!==file.sha256)throw Error('vendor源码或许可已变化，须重新核验登记：'+file.path);
 }
 for(const file of vendor.runtime_files)if(!vendorInputs.includes(file.path))throw Error('声明vendor代码未在实际浏览器程序中使用');
 for(const file of vendor.license_files)notices+=`\n### ${path.basename(file.path)}\n\n${await readFile(file.path,'utf8')}\n`;
}
await writeFile(path.join(out,'THIRD_PARTY_NOTICES.md'),notices);
await writeFile(path.join(out,'build-manifest.json'),JSON.stringify({tool:id,version:VERSION,native:nativeManifest,inputs:Object.keys(bundled.metafile!.inputs),runtime_packages:[...roots].sort(),...(vendors.length?{vendor_dependencies:vendors}:{})},null,2));
execFileSync('python3',['scripts/package.py',out]);
console.log(`已构建 ${out}`);
