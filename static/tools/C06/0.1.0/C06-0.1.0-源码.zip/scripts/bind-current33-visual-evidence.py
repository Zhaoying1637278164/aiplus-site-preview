"""Current33 review binding: exact old reviewed bytes or explicit new actual inspection."""
from pathlib import Path
import json,hashlib,shutil
root=Path.cwd();read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ids=[r['id'] for r in read(root/'integration/native-site/site/registry.json')];suite=root/'progress/evidence/site-integration'/'-'.join(ids);site=sha(root/'integration/native-site/site/index.html');parent=read(suite/'root-current33-commands.json');terminal=read(suite/'root-current33-terminal-command.json');assert parent['passed'] and terminal['actual_exit_code']==0 and terminal['site_sha256']==site
extra=suite/'root-current33-actual-changed-review.json';actual={}
if extra.exists():
 d=read(extra);assert d['actual_review'] and d['site_sha256']==site
 for f,h in d['images'].items():assert sha(root/f)==h;actual[f]=h
pending=[];updates=[]
def checked(file,previous):
 digest=sha(file);name=str(file.relative_to(root))
 if digest!=previous and actual.get(name)!=digest:pending.append({'file':name,'old_sha256':previous,'new_sha256':digest})
 return digest
old_suite=suite.parent/'-'.join(ids[:31]);old=read(old_suite/'rendered-review.json');assert old['reviewed'] and old['passed'];screens={}
for f,h in old['screenshots'].items():
 name=f.replace(str(old_suite.relative_to(root)),str(suite.relative_to(root)))
 if any('/'+t+'/0.1.0/site-local-with-C01/' in name for t in ['D01','D04','D05']):name=name.replace('/site-local-with-C01/','/site-local-current33/')
 if '/C01/0.1.0/site-local/' in name:name=name.replace('/C01/0.1.0/site-local/','/C01/0.1.0/site-local-current33/')
 fresh=root/name;screens[str(fresh.relative_to(root))]=checked(fresh,h)
for t,v,name,key in [('K03','0.1.0','root-visual-review.json','images'),('K04','0.1.0','root-visual-review.json','images'),('K05','0.1.0','root-rendered-review.json','reviewed_images'),('A01','0.1.1','root-rendered-review.json','reviewed_images')]:
 b=root/'progress/evidence'/t/v/'site-full-pages';p=b/name;r=read(p);d=read(b/'result.json');assert d['passed'] and d['siteSHA']==site
 for x in d['images']:assert sha(b/x['file'])==x['sha256'];r[key][x['file']]=checked(b/x['file'],r[key].get(x['file']))
 if t=='K04':
  g=b.parent/'site-guide-readable';gd=read(g/'result.json');assert gd['siteSHA']==site
  for x in gd['images']:r['guide_readable_clips_viewed'][x['file']]=checked(g/x['file'],r['guide_readable_clips_viewed'].get(x['file']))
  r['guide_readable_clips_result_sha256']=sha(g/'result.json')
 r.update(site_sha256=site,result_sha256=sha(b/'result.json'),actual_capture_exit_code=0,current33_basis='Actual current33 captures; exact prior reviewed bytes or explicit actual changed-image inspection');updates.append((p,r))
for t in ['K01','K02','T04']:
 b=root/'progress/evidence'/t/('0.2.0' if t=='T04' else '0.1.0');p=b/('root-visual-review.json' if t=='K01' else 'site-local/root-visual-review.json');r=read(p);assert read(b/'site-local/result.json')['site_sha256']==site
 if t=='K01':
  for f,h in r['files'].items():r['files'][f]=checked(b/'site-local'/f,h)
 elif t=='K02':
  for k in ['screenshots','contacts_actually_viewed']:
   for f,h in r[k].items():r[k][f]=checked(root/f,h)
 else:
  for x in r['images']:x['sha256']=checked(root/x['path'],x['sha256'])
 r.update(site_sha256=site,current33_basis='Exact old actual review bytes or explicit inspected new images; actual current33 captures');updates.append((p,r))
b=root/'progress/evidence/T06/0.1.0/site-visual';r=read(b/'root-visual-review.json');d=read(b/'result.json');assert d['site_sha256']==site
for x in d['captures']:r['screenshots'][Path(x['file']).name]=checked(root/x['file'],r['screenshots'].get(Path(x['file']).name))
r.update(actual_exit_code=0,actual_session=terminal['actual_session'],actual_terminal_chunk=terminal['actual_terminal_chunk'],site_sha256=site,result_sha256=sha(b/'result.json'),validator_sha256=sha(root/'tests/t06-native-visual.ts'),current33_basis='Actual parent terminal0 current33 captures; exact previously reviewed bytes or explicit changed-image inspection');updates.append((b/'root-visual-review.json',r))
b=root/'progress/evidence/A02/0.1.0/site-full-pages';r=read(b/'root-visual-review.json');d=read(b/'result.json');assert d['passed'] and d['siteSHA']==site;prior={x['file']:x['sha256'] for x in r['images']}
for x in d['images']:checked(b/x['file'],prior.get(x['file']))
r.update(siteSHA=site,result_sha256=sha(b/'result.json'),images=d['images'],current33_basis='Exact prior actual review or explicit inspected changes');updates.append((b/'root-visual-review.json',r))
b=root/'progress/evidence/A03/0.1.0/site-full-pages';r=read(b/'root-visual-review.json');d=read(b/'result.json');assert r['actual_review'] and d['passed'] and d['siteSHA']==site
for x in d['images']:
 digest=checked(b/x['file'],r['images'].get(x['file']));r['images'][x['file']]=digest;screens[str((b/x['file']).relative_to(root))]=digest
r.update(siteSHA=site,result_sha256=sha(b/'result.json'));updates.append((b/'root-visual-review.json',r))
b=root/'progress/evidence/A04/0.1.1/site-full-pages';r=read(b/'root-visual-review.json');d=read(b/'result.json');assert r['passed_layout_review'] and d['passed'] and d['siteSHA']==site
for x in d['images']:
 digest=checked(b/x['file'],r['actual_reviewed_images'].get(x['file']));r['actual_reviewed_images'][x['file']]=digest;screens[str((b/x['file']).relative_to(root))]=digest
r.update(siteSHA=site,result_sha256=sha(b/'result.json'));updates.append((b/'root-visual-review.json',r))
assert len(screens)==268
new=read(suite/'root-current33-new-tools-visual-review.json');assert new['actual_review'] and new['reviewer']=='Codex actual image inspection' and new['site_sha256']==site
assert len(new['images'])==4
for f,h in new['images'].items():assert sha(root/f)==h;screens[f]=h
assert len(screens)==272
(suite/'root-current33-pending-visual.json').write_text(json.dumps({'site_sha256':site,'pending':pending,'scope':'Unseen changes block visual binding'},indent=2)+'\n')
if pending:raise SystemExit('Actual inspection needed for '+str(len(pending))+' changed images')
for p,r in updates:
 q=p.parent/'history/before-current33-visual-binding';q.mkdir(parents=True,exist_ok=True)
 if not (q/p.name).exists():shutil.copy2(p,q/p.name)
 p.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
(suite/'rendered-review.json').write_text(json.dumps({'site_sha256':site,'tools':ids,'reviewed':True,'passed':True,'reviewer':'Codex actual image inspection','screenshots':screens,'scope':'272 actual current33 image files, including four specifically scoped new-tool viewport captures. Strict prior actually inspected bytes or separately documented actual new inspection; A03 contact-sheet layout review. Hidden columns and per-cell readability not claimed.'},indent=2)+'\n');print('Bound272 actual current33 reviewed images')
