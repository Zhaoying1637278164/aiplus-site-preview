"""Run the reviewed six-tool regressions against the current staged registry.

Fresh executions and fresh outputs only; never copy older site-bound results.
The R04/R05 additional validator and visual/public gates remain separate.
"""
import hashlib, json, os, pathlib, subprocess, sys, shutil

root = pathlib.Path.cwd()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
site = root / 'integration/native-site/site/index.html'
site_sha = sha(site)
ids = [entry['id'] for entry in json.loads((root / 'integration/native-site/site/registry.json').read_text())]
assert ids==['D02', 'D03', 'D06', 'R01', 'R02', 'R03', 'R04', 'R05', 'P01', 'P02', 'P03', 'P04', 'T01', 'T02', 'T03', 'T05', 'K02', 'K01', 'T04', 'T06', 'K03', 'K04', 'A01', 'K05', 'A02', 'A03', 'A04', 'D01', 'D04', 'D05', 'C01', 'C03', 'C02']
base = root / 'progress/evidence/site-integration/D02-D03-D06-R01-R02-R03'
reference = json.loads((base / 'regression-commands.json').read_text())
suite = root / 'progress/evidence/site-integration' / '-'.join(ids)
suite.mkdir(parents=True, exist_ok=True)
result = {'site_sha256': site_sha, 'tools': ids, 'results': [], 'passed': False}
record = suite / 'regression-commands.json'
if '--resume' in sys.argv:
    previous = json.loads(record.read_text())
    assert previous['site_sha256'] == site_sha and previous['tools'] == ids
    history = suite / 'history-before-resume'
    history.mkdir(exist_ok=True)
    shutil.copy2(record, history / record.name)
    for item in previous['results']:
        if item['exit_code'] != 0:
            shutil.copy2(root / item['log'], history / pathlib.Path(item['log']).name)
            break
        assert item['script'] == {'d02-native-site.ts':'d02-native-site-current33.ts','d03-native-site.ts':'d03-native-site-current33.ts','d06-native-downloads.ts':'d06-native-downloads-current33.ts'}.get(reference['results'][len(result['results'])]['script'],reference['results'][len(result['results'])]['script'])
        assert item['test_sha256'] == sha(root / 'tests' / item['script'])
        assert (root / item['output']).is_dir() and (root / item['log']).is_file()
        result['results'].append(item)
    print('Retained actual current-stage passes:', len(result['results']), flush=True)
for task in reference['results'][len(result['results']):]:
    assert sha(site) == site_sha, 'staged site changed during regression'
    script = {'d02-native-site.ts':'d02-native-site-current33.ts','d03-native-site.ts':'d03-native-site-current33.ts','d06-native-downloads.ts':'d06-native-downloads-current33.ts'}.get(task['script'],task['script'])
    output = suite / pathlib.Path(task['output']).relative_to(base.relative_to(root))
    env = dict(os.environ, AIPLUS_NATIVE_SITE_URL='http://127.0.0.1:8521',
               AIPLUS_EVIDENCE_DIR=str(output),
               AIPLUS_CHROME='/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing')
    logfile = suite / (script + '.log')
    print('Executing', script, flush=True)
    with logfile.open('w') as log:
        command = subprocess.run(['node','--import','tsx',str(root / 'tests' / script)],
                                 cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    result['results'].append({'script': script, 'exit_code': command.returncode,
                              'output': str(output.relative_to(root)),
                              'log': str(logfile.relative_to(root)),
                              'test_sha256': sha(root / 'tests' / script)})
    record.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    if command.returncode:
        raise SystemExit(f'{script} failed; inspect {logfile}')
result['passed'] = True
record.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('All 16 existing-tool website regressions passed', flush=True)
