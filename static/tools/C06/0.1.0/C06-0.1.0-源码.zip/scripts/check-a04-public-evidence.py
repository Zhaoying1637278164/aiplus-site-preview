"""Actual public A04 final gate. Does not mutate catalogue or freeze a release."""
from pathlib import Path
from urllib.parse import urlparse
import hashlib, json, subprocess, sys, zipfile
from openpyxl import load_workbook

root=Path.cwd();ev=root/'progress/evidence/A04/0.1.1';pub=ev/'site-public';release=root/'release/A04/0.1.1'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run([sys.executable,'scripts/check-current27-native-evidence.py'],check=True)
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
parent=read(pub/'root-public-commands.json');terminal=read(pub/'root-public-terminal-command.json')
assert parent['passed'] and len(parent['results'])==6 and parent['site_sha256']==site
assert terminal['actual_exit_code']==0 and terminal['actual_session'] and terminal['actual_terminal_chunk']
assert terminal['site_sha256']==site and terminal['result_sha256']==sha(pub/'root-public-commands.json')
folders=['root-native-business','root-native-pagination','root-native-navigation','site-full-pages','A04/downloads','downloaded-zip-offline/browser']
results={}
for row,folder in zip(parent['results'],folders):
    assert row['actual_exit_code']==0 and row['script_sha256']==sha(root/row['script'])
    assert row['result_sha256']==sha(pub/folder/'result.json')
    data=read(pub/folder/'result.json');assert data.get('passed') or data.get('status')=='passed'
    assert data['errors']==[]
    if folder!='A04/downloads':assert data['requests']==[]
    if folder!='downloaded-zip-offline/browser':
        assert data.get('siteSHA',data.get('site_sha256'))==site
        assert data.get('actualRuntimeSHA',data.get('runtimeSHA',data.get('runtime_sha256')))==runtime
    results[folder]=data
business=results['root-native-business'];pagination=results['root-native-pagination'];nav=results['root-native-navigation']
assert len(business['checks'])==10 and len(business['downloads'])==26 and business['candidate_sha256']==html
assert business['reloadRequests']
for url in business['reloadRequests']:
    parsed=urlparse(url)
    assert parsed.hostname=='aiplus-guance.streamlit.app'
    assert (parsed.path in ['/','/~/+/'] and parsed.query=='tool=A04') or parsed.path.startswith('/static/') or parsed.path in ['/_stcore/health','/_stcore/host-config','/favicon.png']
assert len(pagination['checks'])==12 and pagination['contracts']==203 and pagination['payments']==406
assert len(nav['checks'])==6 and len(nav['geometry'])==27
for g in nav['geometry']:
    assert not g['overflow'] and g['tool']['y']>=g['header']['bottom']-2 and g['tool']['bottom']<=g['footer']['top']+2
for folder in ['root-native-business','downloaded-zip-offline/browser']:
    for d in results[folder]['downloads']:assert sha(pub/folder/d['file'])==d['sha256']
for d in pagination['downloads']:assert sha(Path(d['file']))==d['sha256']
# Every actual exported worksheet cell must equal independently checked formal
# offline output. Select calculated workbooks explicitly, never a sample template.
for folder,name,offline in [('root-native-business','03-租赁测算完整底稿.xlsx','root-formal-offline/browser'),('root-native-pagination','1-租赁测算完整底稿.xlsx','root-formal-pagination'),('downloaded-zip-offline/browser','03-租赁测算完整底稿.xlsx','root-formal-offline/browser')]:
    a=load_workbook(pub/folder/name,read_only=True,data_only=False);b=load_workbook(ev/offline/name,read_only=True,data_only=False)
    try:
        assert a.sheetnames==b.sheetnames and len(a.sheetnames)==18
        for sheet in a.sheetnames:assert list(a[sheet].values)==list(b[sheet].values),(folder,sheet)
    finally:a.close();b.close()
full=results['site-full-pages'];review=read(ev/'site-full-pages/root-visual-review.json')
assert len(full['images'])==27 and review['passed_layout_review']
changed=pub/'root-actual-changed-visual-review.json';actual={}
if changed.exists():
    d=read(changed);assert d['actual_review'] and d['site_sha256']==site;actual=d['images']
for x in full['images']:
    f=pub/'site-full-pages'/x['file'];assert sha(f)==x['sha256']
    assert x['sha256']==review['actual_reviewed_images'][x['file']] or actual.get(str(f.relative_to(root)))==x['sha256']
downloads=results['A04/downloads'];assert downloads['clicks']==15 and len(downloads['downloads'])==13
assert downloads['html_sha256']==html and downloads['runtime_sha256']==runtime
directory=pub/'A04/downloads/site-local-downloads'
for name,digest in downloads['downloads'].items():assert sha(directory/name)==sha(release/name)==digest
with zipfile.ZipFile(directory/'A04-0.1.1-离线包.zip') as z:
    expected={f.name for f in release.iterdir() if f.is_file() and f.suffix!='.zip'}
    assert len(expected)==14 and set(z.namelist())=={'A04/'+n for n in expected}
    for name in expected:assert z.read('A04/'+name)==(release/name).read_bytes()==(pub/'downloaded-zip-offline/extracted/A04'/name).read_bytes()
offline=results['downloaded-zip-offline/browser'];assert offline['offline'] and len(offline['checks'])==10 and len(offline['downloads'])==26 and offline['candidate_sha256']==html
source=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json')
assert source['source_zip_sha256']==sha(directory/'A04-0.1.1-源码.zip') and len(source['commands'])==4 and all(x['exit_code']==0 for x in source['commands'])
assert len(assets['files'])==14
for name,row in assets['files'].items():
    assert row['release_sha256']==sha(release/name)
    assert row['bytes_identical'] or (name.endswith('.xlsx') and row['content_identical_except_created_modified'])
publication=read(ev/'root-site-push-command.json')
assert publication['actual_exit_code']==0 and publication['actual_commit']=='6f49f270ff197389a6fe78e9b1d01084a445e708'
assert publication['origin_main_actual_readback']==publication['actual_commit'] and publication['site_sha256']==site
final={'tool':'A04','version':'0.1.1','all_required_gates_passed':True,'public_verified':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':source['source_zip_sha256'],'website_commit':publication['actual_commit'],'rollback_tag':publication['rollback_tag'],'actual_public_groups':6,'public_business_groups':10,'public_pagination_groups':12,'public_navigation_groups':6,'public_download_clicks':15,'unique_public_files':13,'public_whole_layout_images':27,'public_zip_offline_groups':10,'public_financial_workbooks_all18_sheets_equal_formal':True,'whole_current27_tasks':24,'whole_current27_reviewed_images':262,'windows_real_machine':'unverified','scope':'Actual Mac browser and downloaded ZIP. All18 sheet cells of business/203-contract batch/ZIP equal independently checked formal output. Late root public QA is outside frozen source ZIP; program/shared source rebuild and all14 assets separately verified. Visual layout review does not claim hidden columns are individually readable.'}
(ev/'site-public-final.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n');print(json.dumps(final,ensure_ascii=False,indent=2))
