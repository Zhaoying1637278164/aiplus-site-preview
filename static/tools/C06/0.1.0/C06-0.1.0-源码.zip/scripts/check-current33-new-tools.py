"""Exact four existing new-tool deliveries bound to fresh whole33 commands."""
from pathlib import Path
import hashlib, json, subprocess, sys, zipfile

root = Path.cwd()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
stage = root / 'integration/native-site'
registry = read(stage / 'site/registry.json')
ids = [r['id'] for r in registry]
assert len(ids) == 33 and ids[27:] == ['D01', 'D04', 'D05', 'C01', 'C03', 'C02']
site = sha(stage / 'site/index.html')
suite = root / 'progress/evidence/site-integration' / '-'.join(ids)
parent = read(suite / 'root-current33-commands.json')
terminal = read(suite / 'root-current33-terminal-command.json')
assert parent['passed'] and len(parent['results']) == 29
assert parent['site_sha256'] == terminal['site_sha256'] == site
assert terminal['actual_exit_code'] == 0 and terminal['actual_session'] and terminal['actual_terminal_chunk']
rows = {r['script']: r for r in parent['results']}
preserved = read(root / 'integration/history/current31-before-C03-C02/preserved-static-sha256.json')
prior = read(root / 'integration/history/current31-before-C03-C02/site/registry.json')
assert registry[:31] == prior
assert len(preserved) == 965
for name, digest in preserved.items():
    assert sha(stage / name) == digest
specs = {'D01': (7, 9, None), 'D04': (7, 10, None), 'D05': (8, 8, 21), 'C01': (10, 10, None)}
for tool in sys.argv[1:] or specs:
    groups, files, geometries = specs[tool]
    script = 'tests/' + tool.lower() + '-native-site-current33.ts'
    row = rows[script]
    assert row['actual_exit_code'] == 0 and row['script_sha256'] == sha(root / script)
    release = root / 'release' / tool / '0.1.0'
    ev = root / 'progress/evidence' / tool / '0.1.0/site-local-current33'
    result = read(ev / 'result.json')
    command = read(ev / 'root-command.json')
    assert row['result_sha256'] == command['result_sha256'] == sha(ev / 'result.json')
    assert command['test_sha256'] == sha(root / script) and command['site_sha256'] == site
    assert result['passed'] and result['tool'] == tool and result['version'] == '0.1.0'
    assert result['site_sha256'] == site and result['runtime_sha256'] == sha(release / 'runtime.json')
    assert result['errors'] == result['requests'] == [] and result['accepted'] is False
    assert len(result['checks']) == len(set(result['checks'])) == groups
    assert len(result['downloads']) == files
    if geometries is not None:
        assert len(result['geometry']) == geometries
    for f in release.iterdir():
        if f.is_file():
            assert sha(stage / 'static/tools' / tool / '0.1.0' / f.name) == sha(f)
    for name, digest in result['downloads'].items():
        assert digest == sha(release / name) == sha(ev / 'downloads' / name)
    with zipfile.ZipFile(ev / 'downloads' / f'{tool}-0.1.0-离线包.zip') as z:
        assert z.read(tool + '/index.html') == (release / 'index.html').read_bytes()
    gate = root / 'scripts' / f'check-{tool.lower()}-offline-evidence.py'
    subprocess.run([sys.executable, str(gate)], check=True)
    (ev / 'exact-local-audit.json').write_text(json.dumps(dict(tool=tool, passed=True, site_sha256=site,
        result_sha256=sha(ev / 'result.json'), script_sha256=sha(root / script),
        actual_parent_session=terminal['actual_session'], actual_parent_terminal=terminal['actual_terminal_chunk'],
        parent_receipt_sha256=sha(suite / 'root-current33-terminal-command.json'),
        formal_gate_sha256=sha(gate), native_groups=groups, downloads=files,
        whole33_verified=False, public_verified=False, accepted=False), indent=2) + '\n')
    print(tool, 'exact actual whole33 subprocess and formal gate passed; public separate')
