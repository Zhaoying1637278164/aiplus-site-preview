"""Exact formal bytes, actual browsers/manual answers and source rebuild; no public acceptance."""
from pathlib import Path
import hashlib,json,sys,zipfile
root=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
names={'C04':'C04-科目余额核查','C05':'C05-凭证编制与核对'}
for tool in sys.argv[1:] or names:
    assert tool in names
    release=root/'release'/tool/'0.1.0';ev=root/'progress/evidence'/tool/'0.1.0';base=ev/'root-formal-offline'
    run=read(base/'run.json');terminal=read(base/'root-final-browser-command.json')
    assert run['passed'] and run['finished'] and len(run['commands'])==4
    assert terminal['actual_exit_code']==0 and terminal['actual_session'] and terminal['actual_terminal_chunk']
    assert terminal['run_sha256']==sha(base/'run.json')
    assert run['html_sha256']==sha(release/'index.html') and run['runtime_sha256']==sha(release/'runtime.json')
    assert run['offline_zip_sha256']==sha(release/f'{tool}-0.1.0-离线包.zip')
    for c in run['commands']:
        assert c['actual_exit_code']==0 and c['script_sha256']==sha(root/c['script']) and c['log_sha256']==sha(root/c['log'])
    folders=[('standard-browser',10),('large-browser',14),('native',7)] if tool=='C04' else [('standard-browser',13),('extra-browser',4),('large-browser',10),('native',7)]
    for folder,groups in folders:
        result=read(base/folder/'result.json')
        assert result['status']=='passed' and len(result['checks'])==len(set(result['checks']))==groups
        assert result['errors']==result['requests']==[]
    zproof=read(base/'zip-members.json')
    assert zproof['passed'] and zproof['zip_sha256']==run['offline_zip_sha256']
    with zipfile.ZipFile(release/f'{tool}-0.1.0-离线包.zip') as arc:
        assert set(arc.namelist())==set(zproof['members']) and len(arc.namelist())==(12 if tool=='C04' else 15)
        for name,digest in zproof['members'].items():
            assert hashlib.sha256(arc.read(name)).hexdigest()==digest==sha(release/Path(name).name)==sha(base/'extracted'/name)
    independent=read(root/'progress/evidence'/tool/'root-independent/result.json')
    assert independent['passed'] and independent['actual_exit_code']==0 and independent['tests']==10
    assert independent['script_sha256']==sha(root/'tests'/(tool.lower()+'-root-independent.test.ts'))
    existing=root/'progress/evidence'/tool/'root-handoff-audit/root-existing-unit-command.json'
    ec=read(existing);assert ec['actual_exit_code']==0 and ec['test_sha256']==sha(root/'tools'/names[tool]/'tests/engine.test.ts')
    assert ec['log_sha256']==sha(existing.parent/'root-existing-unit.log')
    if tool=='C04':
        every=read(base/'large-browser/root-every-cell.json')
        assert every['passed'] and every['manual_rows']==604 and every['worksheets']==8 and every['six_tables_every_source_and_finance_cell_checked']
        assert every['workbook_sha256']==sha(base/'large-browser/604底稿.xlsx') and every['html_sha256']==sha(release/'index.html')
        assert every['script_sha256']==sha(root/'tests/c04-formal-full-workbook.ts')
    else:
        bulk=read(base/'large-browser/result.json');manual=read(base/'large-browser/independent.json')
        assert manual['business']==609 and manual['groups']==609 and manual['entries']==1218 and manual['anomalies']==1209
        assert (manual['debit'],manual['credit'],manual['difference'])==('185745','185441.5','303.5')
        assert bulk['independent']==manual and bulk['html_sha256']==sha(release/'index.html') and bulk['runtime_sha256']==sha(release/'runtime.json')
        for row in bulk['downloads']:
            assert sha(Path(row['file']))==row['sha256']
    source=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json');source_terminal=read(ev/'root-source-command.json')
    assert source_terminal['actual_exit_code']==source_terminal['assets_actual_exit_code']==0 and source_terminal['actual_session'] and source_terminal['actual_terminal_chunk']
    assert source_terminal['source_rebuild_sha256']==sha(ev/'source-rebuild.json') and source_terminal['source_assets_sha256']==sha(ev/'source-rebuild-assets.json')
    archive=release/f'{tool}-0.1.0-源码.zip'
    assert source['source_zip_sha256']==assets['source_zip_sha256']==sha(archive)
    assert len(source['commands'])==4 and all(c['exit_code']==0 for c in source['commands'])
    for name in ['index.html','runtime.json']:
        f=source['files'][name];assert f['identical'] and f['release_sha256']==f['rebuilt_sha256']==sha(release/name)
    expected={f.name for f in release.iterdir() if f.is_file() and f.suffix!='.zip'}
    assert set(assets['files'])==expected and len(expected)==(12 if tool=='C04' else 15)
    for name,f in assets['files'].items():
        assert f['bytes_identical'] and f['release_sha256']==f['rebuilt_sha256']==sha(release/name)
    # Source replay code and independent answers must actually be in the tested ZIP.
    with zipfile.ZipFile(archive) as arc:
        snapshot=json.loads(arc.read('source-snapshot.json'))
        for name in ['package-lock.json','scripts/build.ts','scripts/check-c04-c05-offline-evidence.py','scripts/run-c04-c05-formal-offline.py',
                     'tests/'+tool.lower()+'-root-independent.test.ts','tools/'+names[tool]+'/src/engine.ts','tools/'+names[tool]+'/src/program.tsx',
                     'tools/'+names[tool]+'/README.md','tools/'+names[tool]+'/财务规则.md','tools/'+names[tool]+'/参考来源.md']+[c['script'] for c in run['commands']]:
            digest=hashlib.sha256(arc.read(name)).hexdigest()
            assert digest==snapshot['file_sha256'][name]
            # Generic build/lock files may evolve for later tools. The exact
            # archived versions already rebuilt this version independently.
            if name not in ['scripts/build.ts','package-lock.json']:
                assert digest==sha(root/name)
        assert not any('/node_modules/' in n or n.startswith('node_modules/') or '/.git/' in n for n in arc.namelist())
    (base/'check.json').write_text(json.dumps(dict(passed=True,tool=tool,version='0.1.0',html_sha256=sha(release/'index.html'),
        runtime_sha256=sha(release/'runtime.json'),source_zip_sha256=sha(archive),offline_zip_sha256=run['offline_zip_sha256'],
        browser_command_groups=4,source_commands=4,assets=len(expected),manual_tests=10,
        public_verified=False,website_verified=False,windows_verified=False,accepted=False),indent=2)+'\n')
    print(tool,'exact formal/source local gate passed; original website/public/Windows separately required')
