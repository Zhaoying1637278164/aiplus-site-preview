from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();out=root/'progress/evidence/C02/0.1.0/root-formal-offline';html=out/'extracted/C02/index.html';assert html.is_file()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=dict(os.environ,C02_ROOT_HTML=str(html),C02_ROOT_QA_DIR=str(out/'root-browser'),C02_CANDIDATE=str(html.parent),C02_BROWSER_OUT=str(out/'standard-browser'),C02_CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
commands=[]
for script in ['tests/c02-root-repaired-browser.ts','tools/C02-计提与冲回/tests/browser.ts','tests/c02-formal-large-browser.ts','tests/c02-formal-native.ts']:
 log=out/(Path(script).stem+'.log');print('Running',script,flush=True)
 with log.open('w') as f:code=subprocess.run(['node','--import','tsx',script],env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 commands.append({'script':script,'script_sha256':sha(root/script),'exit_code':code,'log':str(log.relative_to(root))})
 (out/'run.json').write_text(json.dumps({'passed':all(c['exit_code']==0 for c in commands),'finished':len(commands)==4,'commands':commands,'html_sha256':sha(html),'offline_zip_sha256':sha(root/'release/C02/0.1.0/C02-0.1.0-离线包.zip'),'accepted':False},indent=2)+'\n')
 if code:print(log.read_text(),flush=True);raise SystemExit(code)
 print('Passed',script,flush=True)
