"""Reuse only byte-identical prior actual review; explicitly bound changed views."""
from pathlib import Path
import hashlib,json,shutil
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());site=sha(root/'integration/native-site/site/index.html');ids=[r['id'] for r in read(root/'integration/native-site/site/registry.json')];suite=root/'progress/evidence/site-integration'/'-'.join(ids)
assert read(suite/'root-current25-commands.json')['passed']
def save(p,d):
 q=p.parent/'history/before-current25-visual-binding';q.mkdir(parents=True,exist_ok=True)
 if p.exists() and not (q/p.name).exists():shutil.copy2(p,q/p.name)
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
actual={}
for t,v,n in [('K03','0.1.0','site-full-1440-2.png'),('K05','0.1.0','site-full-320-4.png'),('A01','0.1.1','site-full-1440-3.png'),('A01','0.1.1','site-full-1440-8.png')]:
 p=root/'progress/evidence'/t/v/'site-full-pages'/n;actual[str(p.relative_to(root))]=sha(p)
t06_changed=root/'progress/evidence/T06/0.1.0/site-visual/768-汇率情景.png';actual[str(t06_changed.relative_to(root))]=sha(t06_changed)
t06_detail=root/'progress/evidence/T06/0.1.0/T06/downloads/site-detail-local.png';actual[str(t06_detail.relative_to(root))]=sha(t06_detail)
proof={'actual_review':True,'reviewer':'Codex actual image inspection','site_sha256':site,'images':actual,'findings':'Four changed whole-page images actually viewed this turn. Native site navigation and complete tool sections render; no overlap or outer overflow. K05 narrow table horizontal scrolling retained. Hidden columns not claimed visually checked.'};(suite/'root-current25-four-changed-images-review.json').write_text(json.dumps(proof,indent=2)+'\n')
for t,v,name,key in [('K03','0.1.0','root-visual-review.json','images'),('K04','0.1.0','root-visual-review.json','images'),('K05','0.1.0','root-rendered-review.json','reviewed_images'),('A01','0.1.1','root-rendered-review.json','reviewed_images')]:
 b=root/'progress/evidence'/t/v/'site-full-pages';p=b/name;r=read(p);d=read(b/'result.json');assert d['siteSHA']==site and d['passed']
 for x in d['images']:
  image=b/x['file'];assert sha(image)==x['sha256'];assert r[key].get(x['file'])==x['sha256'] or actual.get(str(image.relative_to(root)))==x['sha256'];r[key][x['file']]=x['sha256']
 r.update(site_sha256=site,result_sha256=sha(b/'result.json'),actual_capture_exit_code=0,current25_basis='Fresh actual current25 capture; exact prior actually reviewed bytes or explicitly viewed changed images; parent16282/2d19ee')
 if t=='K04':
  g=b.parent/'site-guide-readable';d=read(g/'result.json');assert d['siteSHA']==site
  for x in d['images']:assert sha(g/x['file'])==x['sha256']==r['guide_readable_clips_viewed'][x['file']]
  r['guide_readable_clips_result_sha256']=sha(g/'result.json')
 save(p,r)
for t in ['K01','K02','T04']:
 b=root/'progress/evidence'/t/('0.2.0' if t=='T04' else '0.1.0');p=b/('root-visual-review.json' if t=='K01' else 'site-local/root-visual-review.json');r=read(p);d=read(b/'site-local/result.json');assert d['site_sha256']==site
 if t=='K01':pairs={str(b/'site-local'/n):h for n,h in r['files'].items()}
 elif t=='K02':pairs={str(root/n):h for n,h in {**r['screenshots'],**r['contacts_actually_viewed']}.items()}
 else:pairs={str(root/x['path']):x['sha256'] for x in r['images']}
 for n,h in pairs.items():assert sha(Path(n))==h
 r.update(site_sha256=site,current25_basis='Fresh actual current25 capture compared with prior reviewed image bytes, all identical; parent16282/2d19ee');save(p,r)
b=root/'progress/evidence/T06/0.1.0/site-visual';r=read(b/'root-visual-review.json');d=read(b/'result.json');assert d['site_sha256']==site
for x in d['captures']:
 assert sha(root/x['file'])==x['sha256'];assert x['sha256']==r['screenshots'][Path(x['file']).name] or actual.get(x['file'])==x['sha256'];r['screenshots'][Path(x['file']).name]=x['sha256']
r.update(actual_exit_code=0,terminal_chunk='61a318',actual_terminal_chunk='61a318',command_session=41394,actual_session=41394,site_sha256=site,result_sha256=sha(b/'result.json'),validator_sha256=sha(root/'tests/t06-native-visual.ts'),current25_basis='Actual41394 terminal61a318 fresh27 captures26 exact prior actually reviewed bytes and768 scenario explicitly actually viewed');save(b/'root-visual-review.json',r)
old_suite=suite.parent/'-'.join(ids[:-1]);old=read(old_suite/'rendered-review.json');assert old['reviewed'] and old['passed'];screens={};d02=read(suite/'root-D02-current25-visual-review.json');assert d02['actual_review'] and d02['site_sha256']==site;actual[d02['image']]=d02['image_sha256']
for n,h in old['screenshots'].items():
 fresh=root/n.replace(str(old_suite.relative_to(root)),str(suite.relative_to(root)));name=str(fresh.relative_to(root));digest=sha(fresh);assert digest==h or actual.get(name)==digest,'Needs actual view '+name;screens[name]=digest
b=root/'progress/evidence/A02/0.1.0/site-full-pages';r=read(b/'root-visual-review.json');d=read(b/'result.json');assert r['reviewed'] and r['siteSHA']==site and r['images']==d['images']
for x in d['images']:assert sha(b/x['file'])==x['sha256'];screens[str((b/x['file']).relative_to(root))]=x['sha256']
assert len(screens)==211
(suite/'rendered-review.json').write_text(json.dumps({'site_sha256':site,'tools':ids,'reviewed':True,'passed':True,'reviewer':'Codex actual image inspection','screenshots':screens,'scope':'Actual fresh current25 screenshots. Prior actual reviews reused only for identical bytes; changed D02 plus4 full pages actually viewed with proof. New24 A02 whole pages actually reviewed previously. Layout, not hidden-column per-cell review. Windows unverified.'},indent=2)+'\n');print('Bound211 actual reviewed current25 image hashes')
