"""C06 exact formal local evidence; public/website/Windows require separate gates."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
release=root/'release/C06/0.1.0';ev=root/'progress/evidence/C06/0.1.0';b=ev/'root-formal-offline'
run=read(b/'run.json');terminal=read(b/'root-final-browser-command.json')
assert run['passed'] and run['finished'] and len(run['commands'])==3
assert terminal['actual_exit_code']==0 and terminal['actual_session'] and terminal['actual_terminal_chunk'] and terminal['run_sha256']==sha(b/'run.json')
assert run['html_sha256']==sha(release/'index.html') and run['runtime_sha256']==sha(release/'runtime.json')
assert run['offline_zip_sha256']==sha(release/'C06-0.1.0-离线包.zip')
for c in run['commands']:assert c['actual_exit_code']==0 and c['script_sha256']==sha(root/c['script']) and c['log_sha256']==sha(root/c['log'])
for folder,count in [('standard-browser',15),('large-browser',16),('native',4)]:
 d=read(b/folder/'result.json');assert d['status']=='passed' and len(d['checks'])==len(set(d['checks']))==count and d['errors']==d['requests']==[]
bulk=read(b/'large-browser/result.json');assert (bulk['groups'],bulk['flows'],bulk['download_cells'])==(604,1208,66971)
for row in read(b/'adapters.json'):
 assert row['source_sha256']==sha(root/row['source']) and row['target_sha256']==sha(root/row['target'])
 name=Path(row['source']).stem;dest={'browser':'standard-browser','bulk-browser':'large-browser','native':'native'}[name]
 expected=(root/row['source']).read_text().replace('../../../packages/','../packages/').replace("'../src/","'../tools/C06-总账明细账对账/src/").replace('tools/C06-总账明细账对账/candidate/0.1.0','progress/evidence/C06/0.1.0/root-formal-offline/extracted/C06').replace(f'progress/evidence/C06/{name}',f'progress/evidence/C06/0.1.0/root-formal-offline/{dest}')
 assert expected==(root/row['target']).read_text()
zproof=read(b/'zip-members.json');assert zproof['passed'] and zproof['zip_sha256']==run['offline_zip_sha256']
with zipfile.ZipFile(release/'C06-0.1.0-离线包.zip') as arc:
 assert set(arc.namelist())==set(zproof['members']) and len(arc.namelist())==15
 for n,h in zproof['members'].items():assert hashlib.sha256(arc.read(n)).hexdigest()==h==sha(release/Path(n).name)==sha(b/'extracted'/n)
ind=read(root/'progress/evidence/C06/root-independent/result.json');assert ind['passed'] and ind['actual_exit_code']==0 and ind['tests']==10 and ind['script_sha256']==sha(root/'tests/c06-root-independent.test.ts')
existing=root/'progress/evidence/C06/root-handoff-audit';d=read(existing/'root-existing-commands.json');assert d['passed'] and len(d['commands'])==2 and all(c['actual_exit_code']==0 for c in d['commands'])
for f,h in d['files'].items():assert sha(root/f)==h
source=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json');sc=read(ev/'root-source-command.json');archive=release/'C06-0.1.0-源码.zip'
assert archive.stat().st_size<=24*1024*1024 and sc['actual_exit_code']==sc['assets_actual_exit_code']==0 and sc['actual_session'] and sc['actual_terminal_chunk']
assert sc['source_rebuild_sha256']==sha(ev/'source-rebuild.json') and sc['source_assets_sha256']==sha(ev/'source-rebuild-assets.json')
assert source['source_zip_sha256']==assets['source_zip_sha256']==sha(archive) and len(source['commands'])==4 and all(c['exit_code']==0 for c in source['commands'])
expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert len(expected)==15 and set(assets['files'])==expected
for n,f in assets['files'].items():assert f['bytes_identical'] and f['release_sha256']==f['rebuilt_sha256']==sha(release/n)
with zipfile.ZipFile(archive) as arc:
 snapshot=json.loads(arc.read('source-snapshot.json'))
 required=['package-lock.json','scripts/build.ts','scripts/stabilize-xlsx-container.py','scripts/check-c06-offline-evidence.py','scripts/run-c06-formal-offline.py','tests/c06-root-independent.test.ts','tools/C06-总账明细账对账/src/engine.ts','tools/C06-总账明细账对账/src/program.tsx','tools/C06-总账明细账对账/tests/bulk-oracle.py','tools/C06-总账明细账对账/examples/bulk/oracle.json']+[c['script'] for c in run['commands']]
 for n in required:
  digest=hashlib.sha256(arc.read(n)).hexdigest();assert digest==snapshot['file_sha256'][n]
  if n not in ['scripts/build.ts','package-lock.json']:assert digest==sha(root/n)
 assert not any('/node_modules/' in n or n.startswith('node_modules/') or '/.git/' in n for n in arc.namelist())
(b/'check.json').write_text(json.dumps(dict(passed=True,tool='C06',version='0.1.0',html_sha256=run['html_sha256'],runtime_sha256=run['runtime_sha256'],offline_zip_sha256=run['offline_zip_sha256'],source_zip_sha256=sha(archive),source_commands=4,formal_assets=15,browser_groups=[15,16,4],manual_tests=10,bulk_groups=604,flows=1208,download_cells=66971,website_verified=False,public_verified=False,windows_verified=False,accepted=False),indent=2)+'\n')
print('C06 exact formal local/source gate passed; original website/public/Windows separate')
