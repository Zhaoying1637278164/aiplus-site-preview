from pathlib import Path
import json,zipfile,hashlib
root=Path.cwd();tool=Path('tools/U03-询证函编制');version='0.1.0';out=tool/'candidate'/version;ev=Path('progress/evidence/U03')/version
# Snapshot complete tool sources and only shared reconstruction files, no other tool/business data.
files=[p for p in tool.rglob('*') if p.is_file() and 'candidate' not in p.parts]
files += list(Path('packages/core').glob('*'))+[Path('packages/ui/tool-host.ts'),Path('package-lock.json'),Path('tsconfig.json'),Path('references/saxes-5.0.1-LICENSE')]
files=[p for p in files if p.is_file()]
pkg=json.loads(Path('package.json').read_text());pkg['scripts']={'test':'node --import tsx --test tools/U03-询证函编制/tests/*.test.ts','typecheck':'tsc --noEmit -p tools/U03-询证函编制/tsconfig.json','build':'node --import tsx tools/U03-询证函编制/scripts/build-candidate.ts'}
def add(z,name,data):
    i=zipfile.ZipInfo(str(name),(2026,10,4,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,data)
source=out/'U03-0.1.0-候选源码.zip'
with zipfile.ZipFile(source,'w') as z:
    for p in sorted(set(files)):add(z,p.as_posix(),p.read_bytes())
    add(z,'package.json',json.dumps(pkg,ensure_ascii=False,indent=2).encode())
    add(z,'构建说明.md','Node22+；npm ci；npm test；npm run typecheck；npm run build。候选输出 tools/U03-询证函编制/candidate/0.1.0。依赖安装需要网络，成品断网运行。浏览器证据不包含node_modules，Windows实机未验证。\n'.encode())
assets=[p for p in out.iterdir() if p.is_file() and p.suffix!='.zip']
offline=out/'U03-0.1.0-候选离线包.zip'
with zipfile.ZipFile(offline,'w') as z:
    for p in sorted(assets):add(z,p.name,p.read_bytes())
manifest={'version':version,'tool':'U03','stage':'candidate_not_accepted','source_files':{p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))},'artifacts':{p.as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(assets+[source,offline])}}
ev.mkdir(parents=True,exist_ok=True);(ev/'candidate-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps({'source_files':len(files),'assets':len(assets),'source':manifest['artifacts'][source.as_posix()],'offline':manifest['artifacts'][offline.as_posix()]},ensure_ascii=False))
