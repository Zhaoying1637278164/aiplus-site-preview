import tempfile,zipfile,subprocess,json,hashlib,os
from pathlib import Path
root=Path.cwd();tool=Path('tools/U03-询证函编制');out=tool/'candidate/0.1.0';ev=root/'progress/evidence/U03/0.1.0';records=[]
with tempfile.TemporaryDirectory(prefix='u03-rebuild-') as name:
    target=Path(name)
    with zipfile.ZipFile(out/'U03-0.1.0-候选源码.zip') as z:z.extractall(target)
    # Offline npm ci uses existing public cache if available, never copies node_modules.
    for command in [['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]:
        r=subprocess.run(command,cwd=target,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        records.append({'command':command,'exit':r.returncode,'output':r.stdout})
        (ev/'source-rebuild.json').write_text(json.dumps({'commands':records},ensure_ascii=False,indent=2))
        if r.returncode:raise SystemExit(r.returncode)
    actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (target/out).iterdir() if p.suffix!='.zip' and p.name!='SHA256.json'}
    expected=json.loads((out/'SHA256.json').read_text());
    if actual!=expected:
        failure=ev/'rebuild-mismatch';failure.mkdir(exist_ok=True)
        for p in (target/out).iterdir():
            if p.name in ['index.html','runtime.json']: (failure/p.name).write_bytes(p.read_bytes())
        (failure/'hashes.json').write_text(json.dumps({'actual':actual,'expected':expected},ensure_ascii=False,indent=2))
        raise SystemExit('Rebuild asset hashes differ; failure evidence retained')
    (ev/'source-rebuild.json').write_text(json.dumps({'commands':records,'assets_match':actual,'all_equal':True,'temporary_directory_deleted':True},ensure_ascii=False,indent=2))
print(json.dumps({'commands':len(records),'assets_equal':len(actual)}))
