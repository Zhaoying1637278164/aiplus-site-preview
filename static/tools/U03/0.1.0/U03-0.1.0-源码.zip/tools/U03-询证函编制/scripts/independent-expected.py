"""Independent Python Decimal answer; never imports the tool engine."""
from decimal import Decimal, getcontext
import json
from pathlib import Path
getcontext().prec=50
rows=[('001','1000.10'),('001','-20.05'),('002','0'),('003','0.123456')]
def plain(d):
    s=format(d,'f')
    return s.rstrip('0').rstrip('.') if '.' in s else s
out={'origin':'manually specified four rows; Python decimal, not application output','rows':4,'objects':3,'debit':plain(sum((Decimal(a) for _,a in rows if Decimal(a)>0),Decimal(0))),'credit':plain(-sum((Decimal(a) for _,a in rows if Decimal(a)<0),Decimal(0))),'raw':plain(sum((Decimal(a) for _,a in rows),Decimal(0))),'per_object':{}}
for obj in ['001','002','003']:
    values=[Decimal(a) for k,a in rows if k==obj]
    out['per_object'][obj]={'debit':plain(sum((a for a in values if a>0),Decimal(0))),'credit':plain(-sum((a for a in values if a<0),Decimal(0))),'raw':plain(sum(values,Decimal(0)))}
Path('tools/U03-询证函编制/examples/independent-expected.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps(out,ensure_ascii=False))
