import type {Table} from '../../../packages/core/types';
export const VERSION='0.1.0',RULE_VERSION='U03-2026-10-04.1';
export const BALANCE_HEADERS=['明细ID','对象ID','科目','截止日','币种','单位','余额'];
export const OBJECT_HEADERS=['对象ID','对象抬头','地址','联系人'];
export const TEMPLATE='{{对象抬头}}：\n\n本单位{{发函单位}}正在核对截至{{截止日}}的往来余额，请核对以下资料。金额币种：{{币种}}；单位：{{单位}}。\n\n{{余额明细}}\n\n借方合计：{{借方合计}}；贷方合计：{{贷方合计}}。\n如有不符，请列明差异与依据。请将核对结果按项目要求回复至：{{回复地址}}。\n\n本函仅供往来资料核对，具体函证控制程序另行执行。\n编制资料来源：{{来源}}\n函件编号：{{函件编号}}';
export interface Settings {entity:string;reply:string;date:string;currency:string;unit:string;positive:'借方'|'贷方';template:string;templateName:string;templateVersion:string;prefix:string;format:'html'|'txt'}
export const defaults=():Settings=>({entity:'',reply:'',date:'2026-09-30',currency:'CNY',unit:'元',positive:'借方',template:TEMPLATE,templateName:'一般往来资料核对',templateVersion:'1',prefix:'询证函',format:'html'});
export interface Work {balance:Table|null;objects:Table|null;settings:Settings;reviewed:string[]}
export const empty=():Work=>({balance:null,objects:null,settings:defaults(),reviewed:[]});
export interface Issue {severity:'阻塞'|'提示';message:string;file:string;sheet:string;row:number;object:string}
export interface Line {id:string;object:string;account:string;raw:string;amount:string;direction:'借方'|'贷方'|'零余额';file:string;sheet:string;row:number}
export interface Letter {id:string;name:string;address:string;contact:string;objectSource:string;number:string;lines:Line[];debit:string;credit:string;raw:string}
export interface Result {issues:Issue[];letters:Letter[];lines:Line[];debit:string;credit:string;raw:string;residual:string;blocked:boolean;inputRows:number}
