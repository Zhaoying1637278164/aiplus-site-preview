export {VERSION,RULE_VERSION} from './model';
