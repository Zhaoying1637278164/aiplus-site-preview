import {LIMITS} from '../../../packages/core/types';
import {VERSION,RULE_VERSION,BALANCE_HEADERS,OBJECT_HEADERS,empty,type Work,type Settings} from './model';
import {validateTable,validateSettings,calculate} from './engine';
export function encode(w:Work,data:boolean){const p={schema_version:1,tool:'U03',app_version:VERSION,rule_version:RULE_VERSION,contains_data:data,settings:w.settings,balance:data?w.balance:null,objects:data?w.objects:null,reviewed:data?w.reviewed:[]};const raw=JSON.stringify(p,null,2);if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MB，须减少资料');return raw}
export function decode(raw:string):Work{
 if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MB');const p=JSON.parse(raw);
 if(p?.schema_version!==1||p?.tool!=='U03'||p?.app_version!==VERSION||p?.rule_version!==RULE_VERSION||typeof p.contains_data!=='boolean')throw Error('方案工具或版本不兼容');
 const keys=Object.keys(empty().settings);if(!p.settings||keys.some(k=>typeof p.settings[k]!=='string')||Object.keys(p.settings).some(k=>!keys.includes(k)))throw Error('方案参数结构无效');
 const s=p.settings as Settings;
 // Empty configuration-only plans are allowed, but invalid nonempty values are rejected by calculation.
 if(s.entity&&s.reply)validateSettings(s);else {validateSettings({...s,entity:s.entity||'待填',reply:s.reply||'待填'})}
 if(!Array.isArray(p.reviewed)||p.reviewed.length>20000||p.reviewed.some((x:unknown)=>typeof x!=='string'||x.length>10000)||new Set(p.reviewed).size!==p.reviewed.length)throw Error('方案复核清单无效');
 if(!p.contains_data&&(p.balance!==null||p.objects!==null||p.reviewed.length))throw Error('无数据方案不得夹带数据');
 if(p.balance!==null)validateTable(p.balance,BALANCE_HEADERS);if(p.objects!==null)validateTable(p.objects,OBJECT_HEADERS);
 const w:Work={settings:Object.fromEntries(keys.map(k=>[k,p.settings[k]])) as unknown as Settings,balance:p.balance,objects:p.objects,reviewed:p.reviewed};const r=calculate(w);
 if(w.reviewed.some(id=>!r.letters.some(l=>l.id===id))||r.blocked&&w.reviewed.length)throw Error('方案确认对象与重算结果不一致');return w;
}
