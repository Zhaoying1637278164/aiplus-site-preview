import Decimal from 'decimal.js';
import {date,amount,text} from '../../../packages/core/value';
import {BALANCE_HEADERS,OBJECT_HEADERS,VERSION,RULE_VERSION,type Work,type Settings,type Result,type Issue,type Line,type Letter} from './model';
import type {Table,SourceRow} from '../../../packages/core/types';
const D=Decimal.clone({precision:50,rounding:Decimal.ROUND_HALF_UP});
export const TOKENS=['对象抬头','对象ID','地址','联系人','发函单位','回复地址','截止日','币种','单位','余额明细','借方合计','贷方合计','来源','函件编号'];
const REQUIRED=['对象抬头','发函单位','回复地址','截止日','币种','单位','余额明细'];
export function validateSettings(s:Settings){
 for(const k of ['entity','reply','templateName','templateVersion','prefix'] as const)if(typeof s[k]!=='string'||!s[k].trim()||s[k].length>500)throw Error('抬头、回复地址、模板名称版本及命名前缀须填写且不超过500字');
 date(s.date);if(!/^[A-Z]{3}$/.test(s.currency)||!['元','千元','万元'].includes(s.unit)||!['借方','贷方'].includes(s.positive)||!['html','txt'].includes(s.format))throw Error('币种、单位、方向或格式无效');
 if(typeof s.template!=='string'||s.template.length>10000||!s.template.trim())throw Error('模板须为1–10000字纯文本');
 const tokens=[...s.template.matchAll(/\{\{([^{}]+)\}\}/g)].map(m=>m[1]);
 if(tokens.some(t=>!TOKENS.includes(t))||/\{\{|\}\}/.test(s.template.replace(/\{\{([^{}]+)\}\}/g,'')))throw Error('模板存在未知或不完整占位符');
 for(const t of REQUIRED)if(!tokens.includes(t))throw Error('模板缺少必需占位符：'+t);
}
export function validateTable(t:Table,headers:string[]){
 if(!t||typeof t.file!=='string'||typeof t.sheet!=='string'||!t.file||!t.sheet||t.file.length>500||t.sheet.length>500||!Array.isArray(t.headers)||!Array.isArray(t.rows)||t.rows.length>20000||t.headers.length>200||new Set(t.headers).size!==t.headers.length)throw Error('来源表结构或限额无效');
 if(headers.some(h=>!t.headers.includes(h)))throw Error('缺少字段：'+headers.filter(h=>!t.headers.includes(h)).join('、'));
 for(const r of t.rows){if(r.file!==t.file||r.sheet!==t.sheet||!Number.isInteger(r.row)||r.row<1||!r.cells||typeof r.cells!=='object'||Object.keys(r.cells).length>200)throw Error('原始来源结构无效');for(const v of Object.values(r.cells))if(v!==null&&!(typeof v==='string'&&v.length<=10000)&&!(typeof v==='number'&&Number.isFinite(v))&&!(typeof v==='object'&&v&&typeof v.formula==='string'&&v.formula.length<=10000))throw Error('单元格类型或长度无效');}
 if(new Set(t.rows.map(r=>r.row)).size!==t.rows.length)throw Error('原始行号重复');
}
function required(r:SourceRow,k:string){return text(r.cells[k]??null)}
export function calculate(w:Work):Result{
 const issues:Issue[]=[],lines:Line[]=[],letters:Letter[]=[];
 const issue=(message:string,r?:SourceRow,object='',severity:Issue['severity']='阻塞')=>issues.push({message,severity,file:r?.file??'参数',sheet:r?.sheet??'',row:r?.row??0,object});
 try{validateSettings(w.settings)}catch(e){issue((e as Error).message)}
 for(const [t,h,label] of [[w.balance,BALANCE_HEADERS,'往来余额'],[w.objects,OBJECT_HEADERS,'函证对象']] as const){try{if(!t)throw Error('请导入'+label);validateTable(t,h)}catch(e){issue((e as Error).message);}}
 if(!w.balance||!w.objects||issues.some(i=>i.message.includes('结构')||i.message.startsWith('缺少字段')))return {issues,lines,letters,debit:'0',credit:'0',raw:'0',residual:'0',blocked:true,inputRows:w.balance?.rows.length??0};
 const objects=new Map<string,{name:string;address:string;contact:string;source:string}>(),objectCounts=new Map<string,number>(),detailCounts=new Map<string,number>();
 for(const r of w.objects.rows){try{const id=required(r,'对象ID');objectCounts.set(id,(objectCounts.get(id)??0)+1)}catch{}}
 for(const r of w.balance.rows){try{const id=required(r,'明细ID');detailCounts.set(id,(detailCounts.get(id)??0)+1)}catch{}}
 for(const r of w.objects.rows){let id='';try{id=required(r,'对象ID');if(objectCounts.get(id)!==1)throw Error('对象ID重复，须提供唯一档案');const name=required(r,'对象抬头'),address=required(r,'地址');const c=r.cells['联系人'];const contact=c===null||c===undefined||c===''?'':text(c);objects.set(id,{name,address,contact,source:`${r.file} / ${r.sheet} / 第${r.row}行`});}catch(e){issue((e as Error).message,r,id)}}
 for(const r of w.balance.rows){let object='';try{object=required(r,'对象ID');const id=required(r,'明细ID');if(detailCounts.get(id)!==1)throw Error('明细ID重复，不能重复编制');const account=required(r,'科目');if(date(r.cells['截止日']??null)!==w.settings.date)throw Error('截止日与本次参数不一致');if(required(r,'币种')!==w.settings.currency)throw Error('币种与本次参数不一致');if(required(r,'单位')!==w.settings.unit)throw Error('单位与本次参数不一致');if(!objects.has(object))throw Error('缺少唯一有效对象档案');const a=new D(amount(r.cells['余额']??null).toString()),direction=a.isZero()?'零余额':a.isPositive()?w.settings.positive:w.settings.positive==='借方'?'贷方':'借方';lines.push({id,object,account,raw:a.toFixed(),amount:a.abs().toFixed(),direction,file:r.file,sheet:r.sheet,row:r.row});}catch(e){issue((e as Error).message,r,object)}}
 const groups=new Map<string,Line[]>();for(const l of lines){const group=groups.get(l.object)??[];group.push(l);groups.set(l.object,group)}
 const sum=(ls:Line[],direction?:string)=>ls.filter(l=>!direction||l.direction===direction).reduce((a,l)=>a.plus(direction?l.amount:l.raw),new D(0)).toFixed();
 let n=0;for(const [id,ls] of groups){const o=objects.get(id)!;letters.push({id,...o,objectSource:o.source,number:'U03-'+w.settings.date.replaceAll('-','')+'-'+String(++n).padStart(5,'0'),lines:ls,debit:sum(ls,'借方'),credit:sum(ls,'贷方'),raw:sum(ls)})}
 for(const [id] of objects)if(!groups.has(id))issue('对象没有可编制余额行',undefined,id,'提示');
 const debit=sum(lines,'借方'),credit=sum(lines,'贷方'),raw=sum(lines),expected=new D(debit).minus(credit).times(w.settings.positive==='借方'?1:-1),residual=new D(raw).minus(expected).toFixed();
 if(!issues.some(i=>i.severity==='阻塞')){let bytes=0;for(const l of letters){try{bytes+=new TextEncoder().encode(letterText(l,w.settings)).length;if(bytes>25*1024*1024)throw Error('全部函件正文超过25MB，须拆分资料')}catch(e){issue((e as Error).message,undefined,l.id);break}}}
 if(residual!=='0')issue('借贷方向与原始余额勾稽不平');if(!lines.length)issue('没有有效往来余额');
 return {issues,letters,lines,debit,credit,raw,residual,blocked:issues.some(i=>i.severity==='阻塞'),inputRows:w.balance.rows.length};
}
export function letterText(l:Letter,s:Settings){
 validateSettings(s);const values:Record<string,string>={'对象抬头':l.name,'对象ID':l.id,'地址':l.address,'联系人':l.contact,'发函单位':s.entity,'回复地址':s.reply,'截止日':s.date,'币种':s.currency,'单位':s.unit,'借方合计':l.debit,'贷方合计':l.credit,'函件编号':l.number,'余额明细':l.lines.map(x=>`${x.account} / ${x.direction} / ${x.amount} ${s.unit}（明细${x.id}；原余额${x.raw}；${x.file}/${x.sheet}/第${x.row}行）`).join('\n'),'来源':l.lines.map(x=>`${x.file}/${x.sheet}/第${x.row}行`).join('；')};
 let projected=new TextEncoder().encode(s.template).length;for(const m of s.template.matchAll(/\{\{([^{}]+)\}\}/g))projected+=new TextEncoder().encode(values[m[1]]).length;if(projected>900000)throw Error('单份函件正文超过900KB，须拆分资料或精简模板');
 return s.template.replace(/\{\{([^{}]+)\}\}/g,(_,k:string)=>values[k])+`\n\n收件地址：${l.address}\n对象资料来源：${l.objectSource}\n应用${VERSION} / 规则${RULE_VERSION} / 模板${s.templateName} ${s.templateVersion}\n金额方向：正数为${s.positive}，负数反向；余额以原始精度列示。`;
}
export function canGenerate(w:Work,r:Result){return !r.blocked&&r.letters.length>0&&r.letters.every(l=>w.reviewed.includes(l.id))}
