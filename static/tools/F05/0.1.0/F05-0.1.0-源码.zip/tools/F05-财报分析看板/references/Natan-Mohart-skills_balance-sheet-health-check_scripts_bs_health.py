#!/usr/bin/env python3
"""
Balance sheet health check: computes standard liquidity and solvency
ratios, compares each to a healthy benchmark range, and gives an overall
verdict weighted toward the ratios that matter most for the business's
actual risk profile.

Usage:
    python3 bs_health.py --config bs.json

bs.json shape:
{
  "current_assets": 5200000,
  "current_liabilities": 3100000,
  "inventory": 1400000,
  "cash": 1800000,
  "total_debt": 4000000,
  "total_equity": 6500000,
  "ebitda": 2200000,
  "interest_expense": 380000
}
"""
import argparse
import json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = json.load(f)

    ca = cfg["current_assets"]
    cl = cfg["current_liabilities"]
    inv = cfg["inventory"]
    cash = cfg["cash"]
    debt = cfg["total_debt"]
    equity = cfg["total_equity"]
    ebitda = cfg["ebitda"]
    interest = cfg["interest_expense"]

    current_ratio = ca / cl if cl else None
    quick_ratio = (ca - inv) / cl if cl else None
    cash_ratio = cash / cl if cl else None
    debt_to_equity = debt / equity if equity else None
    debt_to_ebitda = debt / ebitda if ebitda else None
    interest_coverage = ebitda / interest if interest else None

    print("=== Balance Sheet Health Check ===\n")

    ratios = [
        ("Current Ratio", current_ratio, 1.5, 3.0, "x"),
        ("Quick Ratio", quick_ratio, 1.0, 2.0, "x"),
        ("Cash Ratio", cash_ratio, 0.3, 1.0, "x"),
        ("Debt-to-Equity", debt_to_equity, 0.0, 1.5, "x"),
        ("Debt-to-EBITDA", debt_to_ebitda, 0.0, 3.0, "x"),
        ("Interest Coverage", interest_coverage, 3.0, 999, "x"),
    ]

    flags = []
    print(f"{'Ratio':<20}{'Value':>10}{'Healthy Range':>20}{'Status':>10}")
    print("-" * 62)
    for name, val, low, high, unit in ratios:
        if val is None:
            continue
        if name in ("Debt-to-Equity", "Debt-to-EBITDA"):
            # lower is better for these
            status = "OK" if val <= high else "WATCH"
        else:
            status = "OK" if low <= val else "WATCH"
        if status == "WATCH":
            flags.append(name)
        range_str = f"{low:.1f}-{high:.1f}{unit}" if high < 999 else f">{low:.1f}{unit}"
        print(f"{name:<20}{val:>9.2f}{unit}{range_str:>20}{status:>10}")

    print(f"\n=== Verdict ===")
    if not flags:
        print("All ratios fall within healthy benchmark ranges.")
    else:
        print(f"{len(flags)} ratio(s) outside the healthy range: {', '.join(flags)}")
        if "Interest Coverage" in flags:
            print(">>> Interest coverage is the most urgent of these: it measures whether")
            print("    operating earnings can actually service the debt currently owed.")
        elif "Debt-to-EBITDA" in flags or "Debt-to-Equity" in flags:
            print(">>> Leverage ratios outside range suggest debt capacity is stretched")
            print("    relative to earnings or equity cushion, worth checking against any")
            print("    covenant thresholds separately.")
        elif "Cash Ratio" in flags:
            print(">>> Cash ratio alone being low is common and not automatically alarming")
            print("    if current and quick ratios are healthy, it just means liquidity")
            print("    relies on more than cash on hand.")


if __name__ == "__main__":
    main()
