---
name: balance-sheet-health-check
description: Computes current, quick, cash, leverage, and interest-coverage ratios via a bundled calculator against stated healthy benchmark ranges, and prioritizes interest coverage and leverage flags over a low cash ratio alone, which is common and not automatically alarming. Use whenever the user wants a balance-sheet health read, needs liquidity and solvency ratios for a lender or board update, or has ratios computed with no benchmark comparison or sense of which flagged ratio actually matters most.
---

# Balance Sheet Health Check

## When to use
Use whenever the balance sheet needs a health read — before a lender conversation, a board update, or simply as a standing check — especially replacing a ratio dump with no benchmark comparison and no sense of which ratio, if flagged, actually deserves the most attention.

## What it does
Computes the standard liquidity ratios (current, quick, cash) and solvency ratios (debt-to-equity, debt-to-EBITDA, interest coverage) via a bundled calculator, compares each against a stated healthy benchmark range, and prioritizes the flags: interest coverage and leverage ratios get treated as the most urgent, since they measure whether the business can actually service its debt, while a low cash ratio alone is flagged as common and not automatically alarming if the current and quick ratios are healthy.

## Method
1. **Gather the balance sheet inputs**: current assets, current liabilities, inventory, cash, total debt, total equity, plus EBITDA and interest expense from the income statement for the solvency ratios.
2. **Run the bundled calculator** (`scripts/bs_health.py`) to compute all six ratios and compare each against a stated healthy range.
3. **Read liquidity ratios together, not individually.** Current ratio, quick ratio, and cash ratio measure decreasingly liquid slices of the same question; a low cash ratio with healthy current and quick ratios usually just means liquidity relies on receivables and inventory rather than cash on hand, which is normal for many businesses, not a crisis on its own.
4. **Treat interest coverage as the most urgent solvency flag** if it appears — it directly measures whether operating earnings can service the debt currently owed, a more immediate concern than a leverage ratio being somewhat elevated.
5. **Cross-check leverage ratio flags against any actual covenant thresholds** the business has agreed to, separately from the generic benchmark range used here — a covenant-specific threshold is the real constraint, this benchmark is a general health check.
6. **Track the ratios over time, not as a single snapshot** — a ratio drifting toward the edge of its healthy range over several periods is a trend worth addressing before it actually breaches, which a single-period check won't show.
7. **Use the verdict to prioritize follow-up, not to declare a final judgment** — a flagged ratio is the start of an investigation into the specific driver behind it, not the end of the analysis.

## Inputs
- Current assets, current liabilities, inventory, cash
- Total debt, total equity
- EBITDA and interest expense
- Config saved as JSON matching the format documented at the top of `scripts/bs_health.py`

## Output format
Ratio table with computed value, healthy benchmark range, and OK/WATCH status per ratio; an overall verdict that prioritizes interest coverage and leverage flags over a standalone low cash ratio.

## Example
A company shows a current ratio of 1.68x and a cash ratio of 0.58x, both within healthy range, alongside interest coverage of 5.79x, comfortably above the 3.0x floor. All six ratios read healthy in this case, but if interest coverage alone had come in below 3.0x while liquidity ratios stayed fine, the verdict would correctly flag that as the most urgent finding, since it speaks directly to debt-servicing capacity rather than general liquidity comfort.

## Common pitfalls
- Treating a low cash ratio as equally alarming as a low interest coverage ratio, when the two indicate very different levels of urgency.
- Computing ratios without a stated benchmark range, leaving no way to tell whether a number is actually a problem.
- Checking ratios once instead of tracking them over time, missing a slow drift toward a real breach.
