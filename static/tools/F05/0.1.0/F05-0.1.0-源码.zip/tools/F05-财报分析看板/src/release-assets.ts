import {readFile} from 'node:fs/promises';
import {workbookBytes} from '../../../packages/core/io';import {HEADERS,sample} from './engine';import {csv,dataCSV,dataMatrix} from './export';import type {ReleaseAsset} from '../../../packages/core/release-assets';
export async function releaseAssets():Promise<ReleaseAsset[]>{return [{filename:'空白模板.csv',data:new TextEncoder().encode(csv([...HEADERS],[]))},{filename:'虚构样例.csv',data:new TextEncoder().encode(dataCSV(sample()))},{filename:'虚构样例.xlsx',data:new Uint8Array(await readFile('tools/F05-财报分析看板/examples/虚构样例.xlsx'))}];}
