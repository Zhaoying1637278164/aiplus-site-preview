import Papa from 'papaparse';import {workbookBytes} from '../../../packages/core/io';
import {HEADERS,VERSION,RULE_VERSION,analyze,changes,mapped,formula,groups,type Work} from './engine';
export const csv=(headers:string[],rows:unknown[][])=>'\uFEFF'+Papa.unparse({fields:headers,data:rows.map(r=>r.map(v=>typeof v==='string'&&/^[=+@\t\r-]/.test(v)&&!/^[-+]?\d+(?:\.\d{1,6})?$/.test(v)?"'"+v:v))});
export const dataMatrix=(w:Work)=>w.rows.map(r=>[r.entity,r.scope,r.start,r.end,r.currency,r.unit,r.basis,r.confirmed,r.report,r.label,r.role,typeof r.value==='object'&&r.value!==null?'[公式不执行]':r.value,r.note]);
export const dataCSV=(w:Work)=>csv([...HEADERS],dataMatrix(w));
export function sheets(w:Work){const a=analyze(w),delta=a.groups.flatMap(g=>a.groups.filter(p=>p.context[3]<g.context[3]).flatMap(p=>changes(g,p,w))),all=[...a.results,...a.checks,...delta];return [
 {name:'指标结果',headers:['结果ID','组合JSON','名称','状态','值','单位','分子','分母','公式','问题','同行假设','与假设差','应用版本','规则版本'],rows:a.results.map(r=>[r.id,r.group,r.name,r.status,r.value,r.unit,r.numerator,r.denominator,r.formula,r.messages.join('；'),r.peer,r.peerDelta,VERSION,RULE_VERSION])},
 {name:'报表勾稽',headers:['结果ID','组合JSON','名称','状态','左值','右值','残差','单位','容差','公式','问题'],rows:a.checks.map(r=>[r.id,r.group,r.name,r.status,r.numerator,r.denominator,r.value,r.unit,w.tolerance,r.formula,r.messages.join('；')])},
 {name:'项目变化',headers:['结果ID','组合JSON','项目','状态','本期','基期','差额','增长率百分数','增长率限制','公式','问题'],rows:delta.map(r=>[r.id,r.group,r.name,r.status,r.current,r.prior,r.value,r.growth,r.growthMessage,r.formula,r.messages.join('；')])},
 {name:'参与来源',headers:['结果ID','来源ID','文件','页签','行','金额单元格','报表','原项目','时点','原金额','依据'],rows:all.flatMap(r=>[...new Map(r.sources.map(s=>[s.id,s])).values()].map(s=>[r.id,s.id,s.source.file,s.source.sheet,s.source.row,s.source.cell,s.report,s.label,s.role,s.value,s.note]))},
 {name:'原始资料',headers:['来源ID',...HEADERS,'标准ID','文件','页签','行','金额单元格','原始字段JSON'],rows:w.rows.map((r,i)=>[r.id,...dataMatrix({ ...w,rows:[r]})[0],mapped(r,w),r.source.file,r.source.sheet,r.source.row,r.source.cell,JSON.stringify(r.raw)])},
 {name:'异常及未对应',headers:['来源ID','类型','问题','文件','页签','单元格'],rows:[...a.issues.map(x=>[x.row.id,'异常',x.messages.join('；'),x.row.source.file,x.row.source.sheet,x.row.source.cell]),...a.unmapped.map(r=>[r.id,'未对应','没有标准项目',r.source.file,r.source.sheet,r.source.cell]),...a.excluded.map(r=>[r.id,'用户不参加','明确排除',r.source.file,r.source.sheet,r.source.cell])]},
 {name:'项目映射',headers:['报表原项目JSON','标准ID','中文展示名'],rows:Object.entries(w.mapping).map(([k,v])=>[k,v,w.names[v]||'默认名称'])},
 {name:'指标与参数',headers:['ID','名称','类别','公式','启用','依据','条件','生效日','终止日'],rows:w.rules.map(r=>[r.id,r.name,r.category,formula(r,w),r.enabled,r.basis,r.condition,r.from,r.to])},
 {name:'同行假设',headers:['指标ID','值','来源依据','期间','范围JSON'],rows:Object.entries(w.peers).map(([id,p])=>[id,p.value,p.basis,p.period,p.context])},
 {name:'人工复核',headers:['结果ID','状态','复核人','说明'],rows:Object.entries(w.reviews).map(([id,r])=>[id,r.status,r.person,r.note])},
 {name:'工作边界',headers:['参数','值'],rows:[['应用版本',VERSION],['规则版本',RULE_VERSION],['平均余额',w.average],['显示位',w.digits],['绝对容差',w.tolerance],['输入行数',w.rows.length],['异常行',a.issues.length],['未对应行',a.unmapped.length],['明确排除行',a.excluded.length],['金额','Decimal40位；输入6小数24数字；输出十进制文本'],['资料','用户确认报表/附注，仅内存；空不补零，无自动换汇/年化'],['评价','仅数学分析，不提供投资评级，不作审计意见'],['比较','所有較晚组合对較早组合均列入变化表；不可比明确阻塞']]}];}
export const resultCSV=(w:Work)=>{const s=sheets(w)[0];return csv(s.headers,s.rows);};export const exportWorkbook=(w:Work)=>workbookBytes(sheets(w));
