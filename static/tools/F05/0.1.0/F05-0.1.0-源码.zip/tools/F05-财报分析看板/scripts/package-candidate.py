"""F05 candidate-only archives and real isolated four-command rebuild."""
from pathlib import Path
import json,hashlib,zipfile,shutil,tempfile,subprocess
root=Path.cwd();base=root/'progress/evidence/F05/0.1.0';tool=Path('tools/F05-财报分析看板');candidate=base/'candidate';snapshot=base/'source-snapshot'
shutil.rmtree(snapshot,ignore_errors=True);snapshot.mkdir()
for folder in [Path('packages'),tool]:shutil.copytree(root/folder,snapshot/folder)
(snapshot/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',snapshot/'references/saxes-5.0.1-LICENSE')
for name in ['package-lock.json','tsconfig.json']:shutil.copy2(root/name,snapshot/name)
p=json.loads((root/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/F05-财报分析看板/tests/engine.test.ts','typecheck':'tsc --noEmit -p tools/F05-财报分析看板/tsconfig.json','build':'node --import tsx tools/F05-财报分析看板/scripts/build-candidate.ts'};(snapshot/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(snapshot/'tsconfig.json').write_text(json.dumps({**json.loads((snapshot/'tsconfig.json').read_text()),'include':['packages','tools']},indent=2))
(snapshot/'README.md').write_text('''# F05 候选源码重建

仅本款代码、共享包、公开参考和完全虚构样例，无其他工具、node_modules、凭据或业务数据。Node.js22+：

```sh
npm ci
npm test
npm run typecheck
npm run build
```

网络安装或已有npm缓存后构建，生成progress/evidence/F05/0.1.0/candidate。成品双击index.html断网可用。当前源码候选不是官网accepted声明；正式release与官网由总控独立验收。实际重建使用npm ci --offline --ignore-scripts --no-audit --no-fund，其余三命令如上。

浏览器验收：node --import tsx tools/F05-财报分析看板/tests/browser.ts与browser-supplement.ts；F05_CHROMIUM指定本机Chromium。动态XLSX底稿真实下载另行验证；静态版本样例XLSX固定bytes，确保重建不被ZIP时间戳改变。源码包覆盖工具目录、共享core/ui、锁文件、构建与测试、公开参考许可。本款完整说明见tools/F05-财报分析看板/README.md。
''')
shutil.copy2(candidate/'THIRD_PARTY_NOTICES.md',snapshot/'THIRD_PARTY_NOTICES.md')
for name in ['实现交接.md','任务与接续.md','验收证据.md']:(snapshot/tool/name).unlink(missing_ok=True)
files={str(f.relative_to(snapshot)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(snapshot.rglob('*')) if f.is_file()};manifest={'schema_version':1,'tool':'F05','version':'0.1.0','git_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':files,'source_sha256':hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()};(base/'source-files.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
def pack(dest,folder):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(folder.rglob('*')):
   if not f.is_file():continue
   rel=str(f.relative_to(folder));assert not any(part in ['node_modules','.git','.env'] for part in Path(rel).parts)
   info=zipfile.ZipInfo(rel,(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,f.read_bytes())
pack(base/'F05-0.1.0-候选源码.zip',snapshot);pack(base/'F05-0.1.0-候选离线包.zip',candidate)
record={}
for name in ['F05-0.1.0-候选源码.zip','F05-0.1.0-候选离线包.zip']:
 f=base/name;record[name]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(base/'archives.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
temp=Path(tempfile.mkdtemp(prefix='F05-source-rebuild-',dir='/private/tmp'))
with zipfile.ZipFile(base/'F05-0.1.0-候选源码.zip') as z:z.extractall(temp)
results=[]
for i,args in enumerate([['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]):
 run=subprocess.run(args,cwd=temp,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);log=base/f'source-rebuild-{i+1}.log';log.write_text(run.stdout);results.append({'command':args,'exit_code':run.returncode,'log':str(log.relative_to(root))})
 if run.returncode:break
rebuilt=temp/'progress/evidence/F05/0.1.0/candidate';expected={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in candidate.iterdir() if f.is_file()};comparison={name:hashlib.sha256((rebuilt/name).read_bytes()).hexdigest()==sha for name,sha in expected.items()} if rebuilt.exists() else {}
r={'schema_version':1,'tool':'F05','version':'0.1.0','archives':record,'source_sha256':manifest['source_sha256'],'extracted_dir':str(temp),'commands':results,'files_equal':comparison,'status':'passed' if len(results)==4 and all(x['exit_code']==0 for x in results) and len(comparison)==len(expected) and all(comparison.values()) else 'failed'};(base/'source-rebuild.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False));assert r['status']=='passed'
offline=base/'offline-extracted';shutil.rmtree(offline,ignore_errors=True);offline.mkdir()
with zipfile.ZipFile(base/'F05-0.1.0-候选离线包.zip') as z:z.extractall(offline)
match={name:hashlib.sha256((offline/name).read_bytes()).hexdigest()==sha for name,sha in expected.items()};(base/'offline-extract.json').write_text(json.dumps({'status':'passed' if all(match.values()) else 'failed','files_equal':match,'archive':record['F05-0.1.0-候选离线包.zip']},ensure_ascii=False,indent=2));assert all(match.values())
