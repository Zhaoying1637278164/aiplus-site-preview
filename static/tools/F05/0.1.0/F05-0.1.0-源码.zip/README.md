# F05 候选源码重建

仅本款代码、共享包、公开参考和完全虚构样例，无其他工具、node_modules、凭据或业务数据。Node.js22+：

```sh
npm ci
npm test
npm run typecheck
npm run build
```

网络安装或已有npm缓存后构建，生成progress/evidence/F05/0.1.0/candidate。成品双击index.html断网可用。当前源码候选不是官网accepted声明；正式release与官网由总控独立验收。实际重建使用npm ci --offline --ignore-scripts --no-audit --no-fund，其余三命令如上。

浏览器验收：node --import tsx tools/F05-财报分析看板/tests/browser.ts与browser-supplement.ts；F05_CHROMIUM指定本机Chromium。动态XLSX底稿真实下载另行验证；静态版本样例XLSX固定bytes，确保重建不被ZIP时间戳改变。源码包覆盖工具目录、共享core/ui、锁文件、构建与测试、公开参考许可。本款完整说明见tools/F05-财报分析看板/README.md。
