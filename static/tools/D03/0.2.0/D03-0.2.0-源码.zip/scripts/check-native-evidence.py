"""Validate actual exact-version evidence for the D02+D03 native website.
This local publication gate never declares public acceptance.
"""
import hashlib,json,pathlib,sys,zipfile
ROOT=pathlib.Path.cwd();STAGE=ROOT/'integration/native-site';errors=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,message):
 if not ok:errors.append(message)
def read(p):
 if not p.is_file():errors.append(str(p)+': missing');return {}
 return json.loads(p.read_text())
def proof(p,expected,needed):
 d=read(p)
 for key,value in expected.items():check(d.get(key)==value,str(p)+': stale '+key)
 check(set(needed)<=set(d.get('checks',[])),str(p)+': incomplete executed checks')
 return d
registry=read(STAGE/'site/registry.json');check(isinstance(registry,list),'registry structure')
if not isinstance(registry,list):sys.exit(1)
check([e.get('id') for e in registry]==['D02','D03'],'only reviewed D02+D03 registration')
catalog={e['id']:e for e in read(ROOT/'catalog/tools.json')}
site=sha(STAGE/'site/index.html');bind={};download_folders={}
for entry in registry:
 identifier=entry['id'];version=entry['version'];release=ROOT/'release'/identifier/version
 check(entry['name']==catalog[identifier]['name'] and version==catalog[identifier]['version'],'catalog mismatch '+identifier)
 h=sha(release/'index.html');runtime=sha(release/'runtime.json');bind[identifier]=(version,h,runtime)
 check(entry['sha256']==runtime and entry['bytes']==(release/'runtime.json').stat().st_size,'registry runtime mismatch '+identifier)
 check(sha(STAGE/'static/tools'/identifier/version/'runtime.json')==runtime,'staged runtime mismatch '+identifier)
 ev=ROOT/'progress/evidence'/identifier/version
 source=read(ev/'source-rebuild.json');check(source.get('source_zip_sha256')==sha(release/f'{identifier}-{version}-源码.zip'),'source ZIP changed '+identifier)
 check(len(source.get('commands',[]))==4 and all(c.get('exit_code')==0 for c in source.get('commands',[])),'source commands incomplete '+identifier)
 for filename,expected in [('index.html',h),('runtime.json',runtime)]:
  item=source.get('files',{}).get(filename,{})
  check(item.get('identical') is True and item.get('release_sha256')==expected and item.get('rebuilt_sha256')==expected,'source rebuilt bytes mismatch '+identifier+'/'+filename)
 with zipfile.ZipFile(release/f'{identifier}-{version}-离线包.zip') as z:check(hashlib.sha256(z.read(identifier+'/index.html')).hexdigest()==h,'offline ZIP HTML mismatch '+identifier)
 if identifier=='D02':
  proof(ev/'browser-initial.json',{'version':version,'html_sha256':h},['offline_file_five_pages','six_categories_manual_expected_7_6','review_three_transitions','actual_work_config_xlsx_downloads_readback','work_restore_review_preserved','config_restore_no_results','mobile_review_no_outer_overflow','no_http_requests_or_localStorage'])
  proof(ev/'browser-input.json',{'version':version,'html_sha256':h},['actual_csv_xlsx_import','text_leading_zero_zero_negative','full_search_and_pagination','value_date_filters_excluded_rows','parameter_sheet_header_source_invalidate','second_sheet_second_header_source_row','formula_cache_not_calculated','no_http_storage'])
  localdir=ROOT/'progress/evidence/site-integration/D02-D03'
  local=proof(localdir/'site-local-native.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},['business_module_78_13','original_detail_style','seven_first_party_download_hashes','same_document_native_tool_no_inner_iframe_or_new_tab','one_program_on_entry','business_page_heading_visible_after_navigation','same_7_6_manual_counts','work_export_readback','cancel_exit_preserves','confirm_exit_disposes','reentry_empty'])
  imported=proof(localdir/'site-local-input.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},['native_actual_csv_xlsx_import','native_equals_offline_all_results_and_source_sums','native_restore_review_history_exact','native_download_restored_work_readback','no_tool_http_requests_after_import'])
  for f,key in [('新导入三十笔.json','offline_input_evidence_sha256'),('工作底稿.json','offline_review_work_sha256')]:check(imported.get(key)==sha(ev/f),'D02 compared offline work stale')
  actual=local.get('downloads',{});folder=localdir/'site-local-downloads'
 else:
  proof(ev/'browser/result.json',{'version':version,'html_sha256':h},['six_pages_render','manual_expected_12_3_1_1_3_4','row_conflict_confirm_revoke','actual_json_xlsx_download_readback','replacement_clears_prior_decisions','work_restore_recalculate','no_data_plan_clear','mobile_row_10_13_single_line_390_320_and_detail','long_page_scroll_all_six_pages_fixed_header','cancel_page_change_preserves_unsubmitted_input','no_http_requests','no_localStorage','no_page_errors'])
  needed=['new_30_csv_xlsx','actual_sheet_header2','manual_category_scoped_expected','leading_zero_source','null_zero_negative_original','mixed_currency_unit_period_no_aggregation','original_row_trace','actual_json_download_decode']
  proof(ev/'input/result.json',{'version':version,'html_sha256':h},needed)
  proof(ev/'site-input/result.json',{'version':version,'html_sha256':h,'site_sha256':site},needed+['native_equals_offline_tables_and_complete_run','no_http_or_tool_storage_writes'])
  business=['rule_new_invalid_blocked','rule_edit_clears_confirmation','rule_delete_add_confirm','baseline_three_independent_differences','baseline_restore_clears_row_decision','undo_restores_mapping_and_row_decision','category_scope_date_manual_expected','complete_excluded_source_readback','long_page_source_navigation_visible','no_http_during_data_processing']
  proof(ev/'business/result.json',{'version':version,'html_sha256':h},business)
  proof(ev/'site-business/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},business+['dirty_exit_cancel_preserves','cross_tool_dispose_reentry_empty','loads_only_current_program'])
  local=proof(ev/'site-local/result.json',{'version':version,'html_sha256':h,'runtime_sha256':runtime,'site_sha256':site},['original_module_78_13_7','same_document_no_inner_iframe','seven_actual_downloads_hashes','offline_zip_inner_html_same','exit_dispose_reentry_empty','no_http_requests','no_tool_storage_writes','no_page_errors'])
  actual={d['filename']:d['sha256'] for d in local.get('downloads',[])};folder=ev/'site-local'
  check(set(['tests/d03-v2-browser.ts','tests/d03-v2-input-browser.ts','tests/d03-native-site.ts','tests/d03-business-browser.ts','scripts/check-native-evidence.py'])<=set(source.get('required_files_checked',[])),'D03 source archive predates final validation scripts')
 names=[f'{identifier}-{version}-离线包.zip',f'{identifier}-{version}-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md']
 for n in names:
  digest=sha(release/n);p=folder/n
  check(actual.get(n)==digest,'recorded download stale '+identifier+'/'+n)
  check(p.is_file() and sha(p)==digest,'actual download stale '+identifier+'/'+n)
  check(sha(STAGE/'static/tools'/identifier/version/n)==digest,'staged download stale '+identifier+'/'+n)
visual=read(ROOT/'progress/evidence/site-integration/D02-D03/rendered-review.json')
check(visual.get('site_sha256')==site and visual.get('reviewed') is True and visual.get('passed') is True,'current website visual review missing')
check(visual.get('tools')==['D02','D03'] and visual.get('reviewer')=='Codex actual image inspection','both tools actual image review missing')
for name,digest in visual.get('screenshots',{}).items():
 p=ROOT/name;check(p.is_file() and sha(p)==digest,'reviewed screenshot changed '+name)
check(len(visual.get('screenshots',{}))>=4,'visual evidence incomplete')
for r in read(ROOT/'catalog/release-locks.json')['releases']:
 for n,digest in r['files'].items():check(sha(ROOT/'release'/r['tool']/r['version']/n)==digest,'frozen version changed')
print(json.dumps({'ready_for_local_publication':not errors,'tools':[e['id'] for e in registry],'site_sha256':site,'public_acceptance':'separate actual public browser/download gates required','errors':errors},ensure_ascii=False,indent=2))
if errors:sys.exit(1)
if '--write' in sys.argv:
 (STAGE/'acceptance.json').write_text(json.dumps({'site_sha256':site,'registry_sha256':sha(STAGE/'site/registry.json'),'tools':[e['id'] for e in registry],'programs':{i:{'version':b[0],'html_sha256':b[1],'runtime_sha256':b[2]} for i,b in bind.items()},'local_site_navigation':True,'finance_same_results':True,'downloads_hashes':True,'offline':True,'source_rebuild':True,'rendered_product_ui':True},indent=2)+'\n')
