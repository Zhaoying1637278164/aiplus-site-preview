"""Generate the native website workspace from trusted program artifacts."""
from pathlib import Path
import base64, hashlib, html, json, re, shutil, subprocess, sys
from urllib.parse import quote

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT.parent/'aiplus-streamlit'
STAGE=ROOT/'integration/native-site'

# Presentation belongs to the original financial catalogue. Product names and
# versions continue to come exclusively from catalog/tools.json.
PRESENTATION={
    'D02': {'module':'close','label':'结账','template':'close-11','original':'对外报送数据核对',
            'description':'会计明细与业务台账按单据和口径核对，逐项追查差异并留存复核底稿'},
    'D03': {'module':'meta','label':'主数据','template':'meta-02','original':'科目主数据维护',
            'description':'分别核对科目、客商和部门的对应关系，处理冲突并追查原始资料'},
}

def clean_legacy(source):
    source=re.sub(r'<template id="r-tool-D(?:02|03|06)">.*?</template>', '', source, flags=re.S)
    source=re.sub(r'^\s*var d(?:02|03|06)=document\.createElement\([^\n]+\n', '', source, flags=re.M)
    return source

def native_document(source, entry, files, host_js, fragments=False):
    source=clean_legacy(source)
    assert len(re.findall(r'\bdata-tool\s',source))==76, 'Unexpected original catalogue; inspect before editing'
    identifier=entry['id'];name=html.escape(entry['name']);version=html.escape(entry['version'])
    prefix='app/static/tools/'+identifier+'/'+entry['version']+'/'
    def download(filename,label,classes='btn btn-s btn-sm'):
        asset=ROOT/'release'/entry['id']/entry['version']/filename
        digest=hashlib.sha256(asset.read_bytes()).hexdigest()
        transport=prefix+f'download-{files.index(filename)}.json'
        return f'<a class="{classes}" href="{transport}" data-program-download data-download-sha="{digest}" data-download-bytes="{asset.stat().st_size}" download="{html.escape(filename)}">{html.escape(label)}</a>'
    presentation=PRESENTATION[identifier];module=presentation['module'];label=presentation['label']
    description=presentation['description']
    row=f'''<div class="trow" data-tool data-mod="{module}" data-type="T" data-ai="0" data-q="{name} {description} {label}">
<div class="stack gap8" style="min-width:0"><div class="row gap8" style="flex-wrap:wrap"><a href="#{entry['detailRoute']}" class="rt ink" style="font-size:16px;font-weight:600;margin-right:4px">{name}</a><span class="pill">{label}</span><span class="pill">单点工具</span></div><div style="font-size:14px;color:#3D4250;line-height:1.6">{description}</div></div>
<div class="row gap8"><a href="#{entry['detailRoute']}" class="btn btn-s btn-sm">详情</a><a href="#{entry['workspaceRoute']}" class="btn btn-p btn-sm">在线使用</a></div></div>'''
    marker='<div class="trow" data-tool data-mod="tax"'
    assert marker in source;source=source.replace(marker,row+marker,1)
    source=source.replace('76 个开源工具','77 个工具').replace('76 个工具','77 个工具')
    source=source.replace('data-count="mod:all">76','data-count="mod:all">77').replace('data-total>76','data-total>77')
    source=source.replace('<div class="bignum num">76</div>','<div class="bignum num">77</div>')
    source=re.sub(r'(>)(54)(</span><span style="font-size:15px;font-weight:500">单点工具)',r'\g<1>55\g<3>',source)
    source=re.sub(r'(<a href="#tools-close" class="idx hov">.*?class="num body" style="font-size:15px">)12(</span>)',r'\g<1>13\g<2>',source)
    source=source.replace('data-count="ai:all">76','data-count="ai:all">77').replace('data-count="ai:0">69','data-count="ai:0">70')
    template='r-tool-'+presentation['template']
    original=re.search(r'<template id="'+template+r'">.*?</template>',source,re.S)
    assert original
    detail=original.group().replace(template,'r-'+entry['detailRoute']).replace(presentation['original'],name)
    detail=re.sub(r'<p class="lead">.*?</p>',f'<p class="lead">{description}</p>',detail,flags=re.S)
    detail=detail.replace('<span class="btn is-off" aria-disabled="true">工具包即将上线</span>',f'<a href="#{entry["workspaceRoute"]}" class="btn btn-p">开始账表对账</a>'+download(files[0],'下载离线包','btn btn-s'),1)
    detail=re.sub(r'<a href="https://github\.com/".*?</a>',download(files[1],'下载源码','btn btn-s'),detail,flags=re.S)
    for info_label,value in [('版本',version),('更新日期','2026-10-03'),('文件大小',entry['offlineSize'])]:
        pattern=r'('+info_label+r'</span><span style="text-align:right">)[^<]+(</span>)'
        detail=re.sub(pattern,lambda m:m.group(1)+value+m.group(2),detail)
    detail=re.sub(r'<div class="row"(?:(?!</div>).)*?下载次数.*?</div>','',detail,flags=re.S)
    detail=detail.replace('编辑口径说明和规则配置，重新运行即可生效。','在范围与口径页面设置核对字段和金额容差，再生成差异。').replace('口径说明.md','财务规则.md')
    detail=detail.replace('得到「'+name+'」文件夹，放在任意位置。','得到工具文件夹，打开其中的 index.html。')
    detail=detail.replace('导入「示例数据」文件夹中的文件，查看运行结果。','导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。')
    detail=detail.replace('完整的使用说明、口径说明与示例数据随工具包一并提供。','两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。')
    if identifier=='D03':
        detail=detail.replace('开始账表对账','开始核对对应关系').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资料与字典、对应规则、待办处理、来源追查、版本比较、结果底稿分开操作。科目、客商、部门分别核对，冲突与人工确认保留来源。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','在对应规则页面设置类别、范围与生效期，再核对对应关系。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先在工具内体验虚构示例，再导入资料与字典。')
    package_block=r'<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:8px">工具包内容</div>.*?</div>\s*(?=<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:4px">相关工具)'
    labels=['离线工具包','同版本源码','虚构样例（Excel）','空白模板（CSV）','使用说明','财务口径','第三方声明']
    links=''.join('<div style="padding:6px 0">'+download(f,label,'tl')+'</div>' for f,label in zip(files,labels))
    replacement='<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:8px">下载与说明</div>'+links+'</div>\n'
    detail,matched=re.subn(package_block,lambda _:replacement,detail,flags=re.S);assert matched==1
    workspace=f'''<template id="r-{entry['workspaceRoute']}"><section class="sec" style="padding:28px 0 72px"><div class="wrap stack gap20"><nav aria-label="面包屑" class="row gap8 small"><a href="#tools">工具库</a><span>/</span><a href="#tools-{module}">{label}</a><span>/</span><a href="#{entry['detailRoute']}">{name}</a></nav><div id="tool-workspace"></div></div></section></template>'''
    registry={k:entry[k] for k in ['id','name','version','detailRoute','workspaceRoute','runtime','sha256','bytes']}
    if fragments:return row,detail+workspace,registry
    registration=json.dumps([registry],ensure_ascii=False).replace('<','\\u003c')
    injection=detail+workspace+'<script>window.__AIPlusRegistry='+registration+';</script><script>'+host_js.replace('</script','<\\/script')+'</script>\n'
    marker='<script>\nwindow.__initTools';assert marker in source;source=source.replace(marker,injection+marker,1)
    old="function go(h){PREV=CUR||'home';CUR=h;render()}"
    new="function go(h){if(h===CUR)return;if(window.__AIPlusHost&&!window.__AIPlusHost.requestExit())return;PREV=CUR||'home';CUR=h;render()}"
    assert old in source;source=source.replace(old,new,1)
    marker="  app.innerHTML='';app.appendChild(t.content.cloneNode(true));"
    assert marker in source;source=source.replace(marker,"  if(window.__AIPlusHost)window.__AIPlusHost.dispose();\n"+marker,1)
    marker='  wireForms();'
    replacement=marker+"\n  if(window.__AIPlusHost&&window.__AIPlusHost.hasRoute(rid)){window.__AIPlusHost.open(rid,document.getElementById('tool-workspace'),function(){go('"+entry['detailRoute']+"')})}"
    assert marker in source;source=source.replace(marker,replacement,1)
    source=source.replace("tool:'tools',course:","tool:'tools',work:'tools',course:",1)
    marker='  hdr.hidden=admin;ftr.hidden=admin;'
    assert marker in source;source=source.replace(marker,marker+"\n  if(bar)bar.hidden=window.__AIPlusHost.hasRoute(rid);",1)
    source=source.replace("var CUR='',PREV='home';","var CUR=window.__AIPlusInitialRoute||'',PREV='home';",1)
    source=source.replace('data-count="mod:close">12','data-count="mod:close">13')
    source=source.replace('window.scrollTo(0,0)',"window.scrollTo({top:0,behavior:'instant'})")
    assert len(re.findall(r'\bdata-tool\s',source))==77
    assert 'link03' not in source and 'link06' not in source and 'link.textContent=\'D02' not in source
    return source

def native_documents(source, entries, file_sets, host_js):
    assert entries and entries[0]['id']=='D02', 'Keep the accepted D02 delivery'
    assert len({e['id'] for e in entries})==len(entries), 'Duplicate program registration'
    result=native_document(source,entries[0],file_sets[0],host_js)
    if len(entries)==1:return result
    registry=[{k:entries[0][k] for k in ['id','name','version','detailRoute','workspaceRoute','runtime','sha256','bytes']}]
    for entry,files in zip(entries[1:],file_sets[1:]):
        row,templates,registration=native_document(source,entry,files,host_js,fragments=True)
        module=PRESENTATION[entry['id']]['module']
        # D03 follows the six existing master-data products; none is relabelled
        # as complete by this narrower correspondence tool.
        marker='<div data-empty hidden'
        assert module=='meta' and marker in result
        result=result.replace(marker,row+marker,1)
        result=result.replace('<script>window.__AIPlusRegistry=',templates+'<script>window.__AIPlusRegistry=',1)
        registry.append(registration)
        result=re.sub(r'(data-count="mod:'+module+r'">)(\d+)',lambda m:m[1]+str(int(m[2])+1),result)
        result=re.sub(r'(<a href="#tools-'+module+r'" class="idx hov">.*?class="num body" style="font-size:15px">)(\d+)(</span>)',lambda m:m[1]+str(int(m[2])+1)+m[3],result)
    registration=json.dumps(registry,ensure_ascii=False).replace('<','\\u003c')
    result=re.sub(r'window\.__AIPlusRegistry=\[.*?\];',lambda _: 'window.__AIPlusRegistry='+registration+';',result,count=1)
    extra=len(entries)-1;total=77+extra
    result=result.replace('77 个工具',str(total)+' 个工具').replace('data-total>77','data-total>'+str(total)).replace('data-count="mod:all">77','data-count="mod:all">'+str(total)).replace('data-count="ai:all">77','data-count="ai:all">'+str(total)).replace('data-count="ai:0">70','data-count="ai:0">'+str(70+extra)).replace('<div class="bignum num">77</div>','<div class="bignum num">'+str(total)+'</div>')
    result=re.sub(r'(>)(55)(</span><span style="font-size:15px;font-weight:500">单点工具)',lambda m:m[1]+str(55+extra)+m[3],result)
    result=result.replace("function(){go('tool-D02')}","function(){var entry=window.__AIPlusRegistry.find(function(e){return e.workspaceRoute===rid});if(entry)go(entry.detailRoute)}",1)
    assert len(re.findall(r'\bdata-tool\s',result))==76+len(entries)
    return result

def stage(include=()):
    identifiers=['D02',*include]
    assert len(set(identifiers))==len(identifiers), 'Duplicate tool selection'
    assert all(i in PRESENTATION for i in identifiers), 'No reviewed website placement for this tool'
    tools=json.loads((ROOT/'catalog/tools.json').read_text())
    entries=[];file_sets=[];folders=[]
    for identifier in identifiers:
        tool=next(t for t in tools if t['id']==identifier)
        if identifier=='D02':assert tool['name']=='账表对账'
        if identifier=='D03':assert tool['name']=='科目与客商对应关系', 'Formal product registration must precede staging'
        version=tool['version'];folder=ROOT/'release'/identifier/str(version)
        runtime=folder/'runtime.json'
        if not runtime.is_file():raise SystemExit(identifier+' 原生版本runtime.json尚未生成；不使用旧独立页面替代，不修改官网。')
        payload=json.loads(runtime.read_text())
        assert payload['id']==identifier and payload['version']==version and payload['name']==tool['name'] and payload['schema_version']==1
        files=[f'{identifier}-{version}-离线包.zip',f'{identifier}-{version}-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md']
        for filename in files:assert (folder/filename).is_file(),filename
        entries.append({'id':identifier,'name':tool['name'],'version':version,'detailRoute':'tool-'+identifier,'workspaceRoute':'work-'+identifier,'runtime':f'app/static/tools/{identifier}/{version}/runtime.json','sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'bytes':runtime.stat().st_size,'offlineSize':f'{(folder/files[0]).stat().st_size/1024/1024:.1f} MB'})
        file_sets.append(files);folders.append(folder)
    subprocess.run(['node','--import','tsx','scripts/build-site-host.ts'],cwd=ROOT,check=True)
    base=(ROOT/'website/base-index.html').read_bytes()
    baseline=json.loads((ROOT/'website/base-manifest.json').read_text())
    assert hashlib.sha256(base).hexdigest()==baseline['sha256'],'Original website base changed without review'
    expected=[baseline['known_external_index_sha256']]
    deployed=ROOT/'website/deployed-site.json'
    if deployed.is_file():expected.append(json.loads(deployed.read_text())['site_sha256'])
    assert hashlib.sha256((SITE/'site/index.html').read_bytes()).hexdigest() in expected,'Website has unrelated changes; merge them before regeneration'
    source=native_documents(base.decode(),entries,file_sets,(ROOT/'integration/native-host.js').read_text())
    (STAGE/'site').mkdir(parents=True,exist_ok=True);(STAGE/'site/index.html').write_text(source)
    (STAGE/'site/registry.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n')
    app=native_streamlit_app((SITE/'app.py').read_text())
    (STAGE/'app.py').write_text(app);(STAGE/'requirements.txt').write_text('streamlit==1.50.0\n')
    (STAGE/'.streamlit').mkdir(exist_ok=True)
    config=(SITE/'.streamlit/config.toml').read_text()
    if '[server]' not in config:config+='\n[server]\nenableStaticServing = true\n'
    elif not re.search(r'\[server\]\s*enableStaticServing\s*=\s*true',config):raise SystemExit('现有server配置需要核验，不能自动覆盖')
    (STAGE/'.streamlit/config.toml').write_text(config)
    for entry,folder,files in zip(entries,folders,file_sets):
        target=STAGE/'static/tools'/entry['id']/entry['version'];target.mkdir(parents=True,exist_ok=True)
        for file in folder.iterdir():
            if file.is_file():shutil.copy2(file,target/file.name)
        for number,filename in enumerate(files):
            payload={'schema_version':1,'filename':filename,'base64':base64.b64encode((folder/filename).read_bytes()).decode('ascii')}
            (target/f'download-{number}.json').write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':'))+'\n')
    print('原生官网已暂存；尚未发布：',STAGE)

def native_streamlit_app(app,index='site/index.html',registry='site/registry.json'):
    anchor='ROOT = Path(__file__).parent';assert anchor in app
    generated=app[:app.index(anchor)]+'''ROOT = Path(__file__).parent
import json
REGISTRY = json.loads((ROOT / "REGISTRY_PATH").read_text(encoding="utf-8"))
TOOLS = {r["id"]: r for r in REGISTRY}
selected = st.query_params.get("tool", "")
entry = TOOLS.get(selected)
document = (ROOT / "INDEX_PATH").read_text(encoding="utf-8")
if entry:
    initial = json.dumps(entry["workspaceRoute"]).replace("<", "\\\\u003c")
    document = document.replace("<script>window.__AIPlusRegistry", "<script>window.__AIPlusInitialRoute=" + initial + ";</script><script>window.__AIPlusRegistry", 1)
elif selected:
    st.info("该工具尚未开放，请从工具库选择已交付的工具。")
components.html(document, height=900, scrolling=True)
'''
    return generated.replace('REGISTRY_PATH',registry).replace('INDEX_PATH',index)

def apply():
    registry=json.loads((STAGE/'site/registry.json').read_text())
    checker='check-d02-evidence.py' if [e['id'] for e in registry]==['D02'] else 'check-native-evidence.py'
    subprocess.run([sys.executable,str(ROOT/'scripts'/checker)],cwd=ROOT,check=True)
    gate=STAGE/'acceptance.json'
    if not gate.is_file():raise SystemExit('缺少原生官网暂存验收证据，不发布。')
    evidence=json.loads(gate.read_text())
    required=['local_site_navigation','finance_same_results','downloads_hashes','offline','source_rebuild','rendered_product_ui']
    assert all(evidence.get(k) is True for k in required),'Incomplete delivery evidence'
    assert evidence['site_sha256']==hashlib.sha256((STAGE/'site/index.html').read_bytes()).hexdigest(),'Stale website evidence'
    for relative in ['app.py','requirements.txt','site/index.html','site/registry.json','.streamlit/config.toml']:
        target=SITE/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(STAGE/relative,target)
    shutil.copytree(STAGE/'static/tools',SITE/'static/tools',dirs_exist_ok=True)
    (ROOT/'website/deployed-site.json').write_text(json.dumps({'site_sha256':evidence['site_sha256'],'registry_sha256':hashlib.sha256((STAGE/'site/registry.json').read_bytes()).hexdigest()},indent=2)+'\n')
    print('已同步原生官网；须实际公开浏览器验证后才能accepted。')

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'stage'
    if mode=='stage':stage(sys.argv[2:])
    elif mode=='apply':apply()
    else:raise SystemExit('仅支持stage/apply')
