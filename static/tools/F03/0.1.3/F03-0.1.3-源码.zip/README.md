# F03 候选源码重建

仅本款代码、共享包、公开参考和完全虚构资料，无其他工具、node_modules、凭据或业务数据。Node.js22+：

```sh
npm ci
npm test
npm run typecheck
npm run build
```

网络安装或预先缓存依赖后构建，生成 progress/evidence/F03/0.1.3/candidate。成品双击index.html断网可用。当前源码候选不是官网accepted声明；正式release与官网由总控独立验收。

实际重建使用 npm ci --offline --ignore-scripts --no-audit --no-fund；其余三命令如上。浏览器验收可运行 node --import tsx tools/F03-财务报表勾稽/tests/large-browser.ts，F03_CHROMIUM指定本机Chromium可执行文件。

候选CSV、XLSX资产均固定字节；XLSX作者与创建修改时间、ZIP成员时间固定，源码重建逐文件RAW SHA比较，不归一化比对结果。用户实际下载XLSX九表底稿另行逐格验证。
