"""Independent literal UI mapping from the Python financial oracle, never TS output."""
from pathlib import Path
import json
base=Path('tools/F03-财务报表勾稽/tests/fixtures');source=json.loads((base/'large-oracle.json').read_text())['sheets']
checks={r[0]:r for r in source[0]['rows']};original={r[0]:r for r in source[2]['rows']}
def identity(c):return f'{c[0]} · {c[1]}\n{c[2]} 至 {c[3]}\n{c[4]} · {c[5]}'
def report(x):return {'BS':'资产负债表','PL':'利润表','CF':'现金流量表','BR':'桥接资料'}.get(x,x)
def empty(x,fallback='—'):return fallback if x is None else x
headers=[['主体与期间','财务关系','状态','左值','右值','精确差额'],['主体与期间','财务关系','参与项目 / 时点','符号','项值','问题','原金额'],['主体与期间','原项目 / 时点','原金额','标准项目'],['原项目','原金额','问题','金额来源'],['原项目','原金额','报表','金额来源'],['原项目','标准项目','报表'],['财务关系','关系类型','启用','容差','有效期间'],['主体与期间','财务关系','复核状态','复核人','说明'],['参数','值']]
out=[]
for i,s in enumerate(source):
 rows=[]
 for r in s['rows']:
  if i==0:v=[identity(r[1:7]),r[8]+' · '+r[9],r[10],empty(r[11]),empty(r[12]),empty(r[13])]
  elif i==1:v=[identity(checks[r[0]][1:7]),checks[r[0]][8],report(r[2])+' · '+r[3]+' · '+r[4],'+' if r[5]==1 else '−',empty(r[6]),r[7],r[14]]
  elif i==2:v=[identity(r[1:7]),report(r[7])+' · '+r[8]+' · '+r[9],empty(r[10],'（缺失）'),r[12] or '未对应']
  elif i==3:v=[original[r[0]][8],empty(r[6],'（缺失）'),r[1],f'{r[2]} / {r[3]}!{r[5]}（第{r[4]}行）']
  elif i==4:v=[r[2],empty(r[6],'（缺失）'),report(r[1]),f'{r[3]} / {r[4]}（第{r[5]}行）']
  elif i==5:
   key=json.loads(r[0]);v=[key[1],r[1] or '未对应',report(key[0])]
  elif i==6:v=[r[1],'提示关系' if r[2]=='hint' else '确定等式','启用' if r[3] else '停用',r[4],r[9]+' 至 '+r[10]]
  elif i==7:v=[identity(checks[r[0]][1:7]),checks[r[0]][8],r[1],r[2],r[3]]
  else:v=r
  rows.append({'values':v,'details':[{'name':h,'value':x} for h,x in zip(s['headers'],r)]})
 out.append({'name':s['name'],'headers':headers[i],'rows':rows})
(base/'large-presentation-oracle.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('Independent UI projection: 9 tables,',sum(len(s['rows']) for s in out),'rows; complete original cells retained as named details.')
