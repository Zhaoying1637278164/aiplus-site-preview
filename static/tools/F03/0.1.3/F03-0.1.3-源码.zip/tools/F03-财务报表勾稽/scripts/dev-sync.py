from pathlib import Path
import shutil,json
root=Path.cwd();base=root/'progress/evidence/F03/0.1.3';dest=Path((base/'dev-root.txt').read_text());tool=Path('tools/F03-财务报表勾稽')
for folder in [Path('packages'),tool]:
 shutil.rmtree(dest/folder,ignore_errors=True);shutil.copytree(root/folder,dest/folder)
shutil.copy2(root/'tsconfig.json',dest/'tsconfig.json');(dest/'references').mkdir(exist_ok=True);shutil.copy2(root/'references/saxes-5.0.1-LICENSE',dest/'references/saxes-5.0.1-LICENSE')
p=json.loads((root/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/F03-财务报表勾稽/tests/*.test.ts','typecheck':'tsc --noEmit -p tools/F03-财务报表勾稽/tsconfig.json','build':'node --import tsx tools/F03-财务报表勾稽/scripts/build-candidate.ts'};(dest/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
print(dest)
