"""Independent Python Decimal oracle. Never calls F03 TS engine or reads its results."""
from pathlib import Path
from decimal import Decimal, getcontext
import json,csv,io,calendar
getcontext().prec=40
root=Path.cwd();base=root/'tools/F03-财务报表勾稽/tests/fixtures';base.mkdir(exist_ok=True)
# Rule configuration is input, read from frozen 0.1.0 user-downloaded plan, never computed results.
rules=json.loads((base/'reference-rules.json').read_text())
rules=[r for r in rules if not r.get('custom')];rules[0]['tolerance']='0.03';rules[1]['enabled']=False
custom=dict(rules[2],id='USER-平衡',name='虚构完整范围平衡',custom=True,basis='虚构用户确认资产等于负债加权益',condition='仅同范围汇总金额',**{'from':'2026-01-01','to':'2026-12-31'})
expired=dict(custom,id='USER-过期',name='仅2025适用',**{'from':'2025-01-01','to':'2025-12-31'})
rules += [custom,expired]
H=['主体','报表范围','期间开始日','期间结束日','币种','金额单位','报表','项目','时点','金额','依据']
values=[('BS','资产总计','期末','1000'),('BS','流动资产合计','期末','600'),('BS','非流动资产合计','期末','400'),('BS','负债合计','期末','400'),('BS','流动负债合计','期末','250'),('BS','非流动负债合计','期末','150'),('BS','所有者权益合计','期末','600'),('BS','负债和所有者权益总计','期末','1000'),('BS','货币资金','期末','140'),('BS','货币资金','期初','100'),('BS','未分配利润','期初','200'),('BS','未分配利润','期末','250'),('PL','营业利润','本期','100'),('PL','营业外收入','本期','20'),('PL','营业外支出','本期','10'),('PL','利润总额','本期','110'),('PL','所得税费用','本期','30'),('PL','净利润','本期','80'),('PL','其他综合收益税后净额','本期','5'),('PL','综合收益总额','本期','85'),('CF','经营活动现金净额','本期','70'),('CF','投资活动现金净额','本期','-40'),('CF','筹资活动现金净额','本期','10'),('CF','汇率影响','本期','0'),('CF','现金净增加额','本期','40'),('CF','现金及等价物','期初','100'),('CF','现金及等价物','期末','140'),('CF','补充资料净利润','本期','80'),('BR','不属于现金的货币资金','期初','10'),('BR','不属于现金的货币资金','期末','20'),('BR','货币资金之外的现金等价物','期初','10'),('BR','货币资金之外的现金等价物','期末','20'),('BR','利润分配','本期','20'),('BR','盈余公积提取','本期','10'),('BR','其他留存调整','本期','0')]
def j(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def dec(v):
 s=format(v,'f');return s.rstrip('0').rstrip('.') if '.' in s else s
rows=[];mapping={}
for g in range(17):
 if g<12:start=f'2026-{g+1:02}-01';end=f'2026-{g+1:02}-{calendar.monthrange(2026,g+1)[1]}'
 else:start='2026-01-01';end='2026-12-31'
 entity=['虚构星禾','虚构远岚','虚构海芒'][g%3];scope='个别' if g%2==0 else '合并';currency='USD' if g in [13,15] else 'CNY';unit=['元','千元','万元'][g%3]
 for i,(report,m,role,value) in enumerate(values):
  value=dec(Decimal(value)*(g+1))
  if g==0 and m=='资产总计':value='1000.03'
  if g==1 and m=='所得税费用':value=None
  if g==2 and m=='汇率影响':value=None
  if g==3 and m in ['净利润','利润总额','所得税费用']:value=dec(-Decimal(value))
  if g==4 and report=='BR' and i==28:basis=''
  else:basis=f'虚构附注G{g+1}；现金/留存全部构成已确认（含零）' if report=='BR' else ''
  label=f'{m}·虚构来源{g+1:02}-{i+1:02}';mapping[j([report,label])]=m
  if g==5 and m=='非流动资产合计':mapping[j([report,label])]='资产总计' # duplicate target retained
  cells=[entity,scope,start,end,currency,unit,report,label,role,value,basis];raw={k:(None if v=='' else v) for k,v in zip(H,cells)};n=len(rows)+2
  rows.append(dict(id=f'replacement:{len(rows)}',entity=entity,scope=scope,start=start,end=end,currency=currency,unit=unit,report=report,label=label,role=role,value=value,basis=basis,source=dict(file='604行虚构资料.csv',sheet='CSV',row=n,cell=f'J{n}'),raw=raw))
for i in range(9):
 r=dict(rows[-1]);r['id']=f'replacement:{len(rows)}';r['label']=f'未对应尾部项目{i+1}';r['value']='0' if i%2==0 else '-0.123456';r['report']='BS';r['role']='期末';r['basis']='虚构未对应资料';r['raw']=dict(zip(H,[r[k] for k in ['entity','scope','start','end','currency','unit','report','label','role','value','basis']]));n=len(rows)+2;r['source']=dict(file='604行虚构资料.csv',sheet='CSV',row=n,cell=f'J{n}');rows.append(r)
assert len(rows)==604
work=dict(rows=rows,mapping=mapping,rules=rules,reviews={},digits=6,bridgeConfirmed=True,profitRangeConfirmed=True)
plan=dict(schema_version=1,tool='F03',app_version='0.1.3',rule_version='F03-2026-10-04.1',contains_data=True,**work)
(base/'large-work.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
f=io.StringIO();writer=csv.writer(f,lineterminator='\r\n');writer.writerow(H);writer.writerows([list(r['raw'].values()) for r in rows]);(base/'604行虚构资料.csv').write_text('\ufeff'+f.getvalue())
# Direct independent equations. Operators use rule INPUT terms, Decimal sums, never TS output.
groups={}
for r in rows:
 ctx=[r[k] for k in ['entity','scope','start','end','currency','unit']];groups.setdefault(j(ctx),[]).append(r)
def metric(r):return mapping.get(j([r['report'],r['label']]),'')
def errors(r):return (['缺失值或公式单元格，须提供静态值'] if r['value'] is None else [])+(['桥接资料须有依据和完整性确认'] if r['report']=='BR' and not r['basis'] else [])
def formula(ts):return ''.join((' − ' if t['sign']==-1 else ' + ' if i else '')+f"{t['report']}.{t['metric']}[{t['role']}]" for i,t in enumerate(ts))
results=[]
for key,group in groups.items():
 ctx=json.loads(key)
 for rule in rules:
  rid=j([key,rule['id']]);status='阻塞';left=right=delta=None;messages=[];terms=[]
  if not rule['enabled']:status='停用'
  elif ctx[2]<rule['from'] or ctx[3]>rule['to']:status='不适用';messages=['资料期间不在规则生效范围']
  else:
   sums=[]
   for side in ['left','right']:
    total=Decimal(0)
    for t in rule[side]:
     found=[r for r in group if r['report']==t['report'] and r['role']==t['role'] and metric(r)==t['metric']];v=None;msg=''
     if len(found)!=1:msg='重复项目，整组阻塞' if found else '缺少项目（含口径不一致或未对应）'
     elif errors(found[0]):msg='；'.join(errors(found[0]))
     else:v=dec(Decimal(found[0]['value']));total+=Decimal(v)*t['sign']
     terms.append(dict(term=t,rows=found,amount=v,message=msg))
     if msg:messages.append(f"{t['report']}.{t['metric']}[{t['role']}]：{msg}")
    sums.append(total)
   if not messages:
    left,right=map(dec,sums);delta=dec(sums[0]-sums[1]);status='提示' if rule['kind']=='hint' else '通过' if abs(sums[0]-sums[1])<=Decimal(rule['tolerance']) else '差异'
    if rule['kind']=='hint':messages=['只作复核线索；差额为零也不代表该关系是必然等式。']
  results.append(dict(id=rid,group=key,context=ctx,rule=rule,status=status,left=left,right=right,delta=delta,terms=terms,messages=messages))
# Independent nine-table layout, compare every scalar and source field.
ss=[]
def add(name,headers,data):ss.append(dict(name=name,headers=headers,rows=data))
add('检查结果',['检查ID','主体','范围','开始日','结束日','币种','单位','规则ID','规则名','关系','状态','左值','右值','差额','容差','左侧公式','右侧公式','说明','应用版本','规则版本'],[[r['id'],*r['context'],r['rule']['id'],r['rule']['name'],'提示关系' if r['rule']['kind']=='hint' else '确定等式',r['status'],r['left'],r['right'],r['delta'],r['rule']['tolerance'],formula(r['rule']['left']),formula(r['rule']['right']),'；'.join(r['messages']),'0.1.3','F03-2026-10-04.1'] for r in results])
terms=[]
for r in results:
 for x in r['terms']:
  t=x['term'];start=[r['id'],r['rule']['id'],t['report'],t['metric'],t['role'],t['sign'],x['amount'],x['message']]
  for row in x['rows'] or [None]:terms.append(start+([row['id'],row['source']['file'],row['source']['sheet'],row['source']['row'],row['source']['cell'],row['label'],row['value'],row['basis']] if row else ['']*8))
add('参与项来源',['检查ID','规则ID','报表','标准项目','时点','符号','项值','问题','来源ID','文件','页签','行号','金额单元格','原项目','原金额','依据'],terms)
add('原始资料',['来源ID',*H,'标准项目','文件','页签','行号','金额单元格','原始字段JSON'],[[r['id'],*[r[k] for k in ['entity','scope','start','end','currency','unit','report','label','role','value','basis']],metric(r),r['source']['file'],r['source']['sheet'],r['source']['row'],r['source']['cell'],j(r['raw'])] for r in rows])
add('数据异常',['来源ID','问题','文件','页签','行号','单元格','原金额'],[[r['id'],'；'.join(errors(r)),r['source']['file'],r['source']['sheet'],r['source']['row'],r['source']['cell'],r['value']] for r in rows if errors(r)])
add('未对应项目',['来源ID','报表','原项目','文件','页签','行号','金额'],[[r['id'],r['report'],r['label'],r['source']['file'],r['source']['sheet'],r['source']['row'],r['value']] for r in rows if not metric(r)])
add('项目对应',['报表与原项目JSON','标准项目'],list(map(list,mapping.items())))
add('规则与条件',['ID','名称','关系','启用','容差','左式','右式','依据','条件','生效日','终止日'],[[r['id'],r['name'],r['kind'],r['enabled'],r['tolerance'],formula(r['left']),formula(r['right']),r['basis'],r['condition'],r['from'],r['to']] for r in rules])
add('人工复核',['检查ID','状态','复核人','说明'],[])
add('参数与边界',['参数','值'],[['tool','F03'],['app_version','0.1.3'],['rule_version','F03-2026-10-04.1'],['显示小数位',6],['桥接完整性确认',True],['同利润范围确认',True],['金额','最多6位小数24位数字，Decimal40位，导出原精度文本'],['口径','主体/范围/期间/币种/单位分别核对，不自动换汇'],['结论','仅当前规则的数学核对；不代表审计通过或报表无错'],['输入行数',604],['不参加规则行',0]])
(base/'large-oracle.json').write_text(json.dumps(dict(results=results,sheets=ss,counts={x:sum(r['status']==x for r in results) for x in ['通过','差异','阻塞','提示','停用','不适用']},method='Independent Python Decimal40; authored inputs and frozen input rule configuration; no TS execution/results'),ensure_ascii=False,indent=2))
print('604 rows /',len(groups),'contexts /',len(results),'results /',[len(s['rows']) for s in ss])
