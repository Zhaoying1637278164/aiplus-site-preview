"""Verify actual browser-saved archives, CRC, all members and fresh source rebuild."""
from pathlib import Path
import json,hashlib,zipfile,tempfile,subprocess
root=Path.cwd();base=root/'progress/evidence/F03/0.1.3';download=base/'delivery-downloads'
sha=lambda b:hashlib.sha256(b).hexdigest()
records=json.loads((download/'result.json').read_text());assert records['status']=='passed'
source=json.loads((base/'source-files.json').read_text())['source_files']
candidate=base/'candidate';expected={f.name:sha(f.read_bytes()) for f in candidate.iterdir() if f.is_file()}
extracted={};audit=[]
for name,files in [('F03-0.1.3-候选离线包.zip',expected),('F03-0.1.3-候选源码.zip',source)]:
 f=download/name;assert f.read_bytes()==(base/name).read_bytes();dest=Path(tempfile.mkdtemp(prefix='F03-downloaded-',dir='/private/tmp'))
 with zipfile.ZipFile(f) as z:
  assert z.testzip() is None;assert set(z.namelist())==set(files)
  members=[]
  for info in z.infolist():
   assert not Path(info.filename).is_absolute() and '..' not in Path(info.filename).parts
   digest=sha(z.read(info.filename));assert digest==files[info.filename];members.append({'name':info.filename,'crc32':format(info.CRC,'08x'),'bytes':info.file_size,'sha256':digest})
  z.extractall(dest)
 extracted[name]=str(dest);audit.append({'name':name,'sha256':sha(f.read_bytes()),'crc_passed':True,'members':members,'extracted_dir':str(dest)})
(base/'downloaded-zip-audit.json').write_text(json.dumps({'status':'passed','archives':audit},ensure_ascii=False,indent=2))
temp=Path(extracted['F03-0.1.3-候选源码.zip']);results=[]
for i,args in enumerate([['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]):
 run=subprocess.run(args,cwd=temp,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);log=base/f'source-rebuild-{i+1}.log';log.write_text(run.stdout);results.append({'command':args,'exit_code':run.returncode,'log':str(log.relative_to(root))})
 if run.returncode:break
rebuilt=temp/'progress/evidence/F03/0.1.3/candidate';actual={f.name:sha(f.read_bytes()) for f in rebuilt.iterdir() if f.is_file()} if rebuilt.exists() else {};comparison={n:actual.get(n)==v for n,v in expected.items()}
r={'status':'passed' if len(results)==4 and all(x['exit_code']==0 for x in results) and actual==expected else 'failed','commands':results,'files_equal':comparison,'exact_file_set':set(actual)==set(expected),'extracted_source':str(temp),'extracted_offline':extracted['F03-0.1.3-候选离线包.zip'],'comparison':'all raw bytes including XLSX XML/ZIP metadata and build-manifest; no normalization'}
(base/'source-rebuild.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False));assert r['status']=='passed'
