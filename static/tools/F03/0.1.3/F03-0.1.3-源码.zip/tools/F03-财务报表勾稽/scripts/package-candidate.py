"""F03 candidate source/offline archives; four real commands from extracted ZIP."""
from pathlib import Path
import json,hashlib,zipfile,shutil,tempfile,subprocess
root=Path.cwd();base=root/'progress/evidence/F03/0.1.3';tool=Path('tools/F03-财务报表勾稽');candidate=base/'candidate';snapshot=base/'source-snapshot'
shutil.rmtree(snapshot,ignore_errors=True);snapshot.mkdir()
for folder in [Path('packages'),tool]:shutil.copytree(root/folder,snapshot/folder)
(snapshot/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',snapshot/'references/saxes-5.0.1-LICENSE')
for name in ['package-lock.json','tsconfig.json']:shutil.copy2(root/name,snapshot/name)
p=json.loads((root/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/F03-财务报表勾稽/tests/*.test.ts','typecheck':'tsc --noEmit -p tools/F03-财务报表勾稽/tsconfig.json','build':'node --import tsx tools/F03-财务报表勾稽/scripts/build-candidate.ts'};(snapshot/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(snapshot/'tsconfig.json').write_text(json.dumps({**json.loads((snapshot/'tsconfig.json').read_text()),'include':['packages','tools']},indent=2))
(snapshot/'README.md').write_text('''# F03 候选源码重建\n\n仅本款代码、共享包、公开参考和完全虚构资料，无其他工具、node_modules、凭据或业务数据。Node.js22+：\n\n```sh\nnpm ci\nnpm test\nnpm run typecheck\nnpm run build\n```\n\n网络安装或预先缓存依赖后构建，生成 progress/evidence/F03/0.1.3/candidate。成品双击index.html断网可用。当前源码候选不是官网accepted声明；正式release与官网由总控独立验收。\n\n实际重建使用 npm ci --offline --ignore-scripts --no-audit --no-fund；其余三命令如上。浏览器验收可运行 node --import tsx tools/F03-财务报表勾稽/tests/large-browser.ts，F03_CHROMIUM指定本机Chromium可执行文件。\n\n候选CSV、XLSX资产均固定字节；XLSX作者与创建修改时间、ZIP成员时间固定，源码重建逐文件RAW SHA比较，不归一化比对结果。用户实际下载XLSX九表底稿另行逐格验证。\n''')
shutil.copy2(candidate/'THIRD_PARTY_NOTICES.md',snapshot/'THIRD_PARTY_NOTICES.md')
for name in ['实现交接.md','任务与接续.md','验收证据.md']:(snapshot/tool/name).unlink(missing_ok=True)
files={str(f.relative_to(snapshot)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(snapshot.rglob('*')) if f.is_file()}
manifest={'schema_version':1,'tool':'F03','version':'0.1.3','git_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':files,'source_sha256':hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
(base/'source-files.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
def pack(dest,folder):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(folder.rglob('*')):
   if not f.is_file():continue
   rel=str(f.relative_to(folder));assert not any(part in ['node_modules','.git','.env'] for part in Path(rel).parts)
   info=zipfile.ZipInfo(rel,(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,f.read_bytes())
pack(base/'F03-0.1.3-候选源码.zip',snapshot);pack(base/'F03-0.1.3-候选离线包.zip',candidate)
record={}
for name in ['F03-0.1.3-候选源码.zip','F03-0.1.3-候选离线包.zip']:
 f=base/name;record[name]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(base/'archives.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
print(json.dumps(record,ensure_ascii=False))
