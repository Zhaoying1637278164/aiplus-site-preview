import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';
import {sheets} from '../src/export';import {decodeWork} from '../src/engine';import {readableSheets} from '../src/presentation';
const work=decodeWork(await readFile(new URL('./fixtures/large-work.json',import.meta.url),'utf8'));
const expected=JSON.parse(await readFile(new URL('./fixtures/large-presentation-oracle.json',import.meta.url),'utf8'));
test('九表中文财务优先列及完整原字段2329行与独立Python投影一致',()=>{assert.deepEqual(readableSheets(sheets(work)).map(({cardFields,...s})=>s),expected);});
