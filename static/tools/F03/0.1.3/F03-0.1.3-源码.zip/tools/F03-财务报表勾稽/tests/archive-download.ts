import {chromium} from 'playwright';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const base=path.resolve(process.env.F03_EVIDENCE_ROOT||'progress/evidence/F03/0.1.3');
const dest=base+'/delivery-downloads';await mkdir(dest,{recursive:true});
const names=['F03-0.1.3-候选离线包.zip','F03-0.1.3-候选源码.zip'];
const bytes=await Promise.all(names.map(n=>readFile(base+'/'+n)));
const fixture=dest+'/download-fixture.html';
await writeFile(fixture,'<!doctype html><meta charset="utf-8"><h1>F03本机候选包下载验证</h1><p>仅本机断网验收夹具，不是公开官网。</p>'+names.map((n,i)=>`<p><a download="${n}" href="data:application/zip;base64,${bytes[i].toString('base64')}">${n}</a></p>`).join(''));
const browser=await chromium.launch({headless:true,executablePath:process.env.F03_CHROMIUM||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const context=await browser.newContext({offline:true,acceptDownloads:true});const page=await context.newPage();
const requests:string[]=[],errors:string[]=[];await context.route('**/*',r=>{if(/^https?:/.test(r.request().url())){requests.push(r.request().url());return r.abort();}return r.continue();});page.on('pageerror',e=>errors.push(e.message));
const record=[];try{await page.goto('file://'+fixture);for(const [i,n]of names.entries()){const event=page.waitForEvent('download');await page.getByRole('link',{name:n,exact:true}).click();const d=await event;assert.equal(d.suggestedFilename(),n);await d.saveAs(dest+'/'+n);assert.equal(await d.failure(),null);const saved=await readFile(dest+'/'+n);assert.deepEqual(saved,bytes[i]);record.push({name:n,path:dest+'/'+n,bytes:saved.length,sha256:createHash('sha256').update(saved).digest('hex'),raw_equal:true});}assert.deepEqual(requests,[]);assert.deepEqual(errors,[]);await writeFile(dest+'/result.json',JSON.stringify({status:'passed',kind:'local-download-fixture-not-public-site',record,requests,errors},null,2));}finally{await browser.close();}
