import Papa from 'papaparse';
import ExcelJS from 'exceljs';
import JSZip from 'jszip';
import {HEADERS,evaluate,metric,formula,VERSION,RULE_VERSION,type Work} from './engine';
export const csv=(headers:string[],rows:unknown[][])=>'\uFEFF'+Papa.unparse({fields:headers,data:rows.map(row=>row.map(v=>typeof v==='string'&&/^[=+@\t\r-]/.test(v)&&!/^[-+]?\d+(?:\.\d{1,6})?$/.test(v)?"'"+v:v))});
export function dataCSV(w:Work){return csv([...HEADERS],w.rows.map(r=>[r.entity,r.scope,r.start,r.end,r.currency,r.unit,r.report,r.label,r.role,typeof r.value==='object'&&r.value!==null?'公式单元格':r.value,r.basis]));}
export function sheets(w:Work){const {results,issues,unmapped}=evaluate(w);return [
 {name:'检查结果',headers:['检查ID','主体','范围','开始日','结束日','币种','单位','规则ID','规则名','关系','状态','左值','右值','差额','容差','左侧公式','右侧公式','说明','应用版本','规则版本'],rows:results.map(r=>[r.id,...r.context,r.rule.id,r.rule.name,r.rule.kind==='hint'?'提示关系':'确定等式',r.status,r.left,r.right,r.delta,r.rule.tolerance,formula(r.rule.left),formula(r.rule.right),r.messages.join('；'),VERSION,RULE_VERSION])},
 {name:'参与项来源',headers:['检查ID','规则ID','报表','标准项目','时点','符号','项值','问题','来源ID','文件','页签','行号','金额单元格','原项目','原金额','依据'],rows:results.flatMap(r=>r.terms.flatMap(t=>t.rows.length?t.rows.map(x=>[r.id,r.rule.id,t.term.report,t.term.metric,t.term.role,t.term.sign,t.amount,t.message,x.id,x.source.file,x.source.sheet,x.source.row,x.source.cell,x.label,x.value,x.basis]):[[r.id,r.rule.id,t.term.report,t.term.metric,t.term.role,t.term.sign,null,t.message,'','','','','','','','']]))},
 {name:'原始资料',headers:['来源ID',...HEADERS,'标准项目','文件','页签','行号','金额单元格','原始字段JSON'],rows:w.rows.map(r=>[r.id,r.entity,r.scope,r.start,r.end,r.currency,r.unit,r.report,r.label,r.role,r.value,r.basis,metric(r,w.mapping),r.source.file,r.source.sheet,r.source.row,r.source.cell,JSON.stringify(r.raw)])},
 {name:'数据异常',headers:['来源ID','问题','文件','页签','行号','单元格','原金额'],rows:issues.map(x=>[x.row.id,x.messages.join('；'),x.row.source.file,x.row.source.sheet,x.row.source.row,x.row.source.cell,x.row.value])},
 {name:'未对应项目',headers:['来源ID','报表','原项目','文件','页签','行号','金额'],rows:unmapped.map(r=>[r.id,r.report,r.label,r.source.file,r.source.sheet,r.source.row,r.value])},
 {name:'项目对应',headers:['报表与原项目JSON','标准项目'],rows:Object.entries(w.mapping)},
 {name:'规则与条件',headers:['ID','名称','关系','启用','容差','左式','右式','依据','条件','生效日','终止日'],rows:w.rules.map(r=>[r.id,r.name,r.kind,r.enabled,r.tolerance,formula(r.left),formula(r.right),r.basis,r.condition,r.from,r.to])},
 {name:'人工复核',headers:['检查ID','状态','复核人','说明'],rows:Object.entries(w.reviews).map(([id,r])=>[id,r.status,r.reviewer,r.note])},
 {name:'参数与边界',headers:['参数','值'],rows:[['tool','F03'],['app_version',VERSION],['rule_version',RULE_VERSION],['显示小数位',w.digits],['桥接完整性确认',w.bridgeConfirmed],['同利润范围确认',w.profitRangeConfirmed],['金额','最多6位小数24位数字，Decimal40位，导出原精度文本'],['口径','主体/范围/期间/币种/单位分别核对，不自动换汇'],['结论','仅当前规则的数学核对；不代表审计通过或报表无错'],['输入行数',w.rows.length],['不参加规则行',w.rows.filter(r=>metric(r,w.mapping)==='不参加规则').length]]}
 ];}
export const resultCSV=(w:Work)=>{const s=sheets(w)[0];return csv(s.headers,s.rows);};
export async function deterministicWorkbook(specs:{name:string;headers:string[];rows:unknown[][]}[]):Promise<Uint8Array>{
 const wb=new ExcelJS.Workbook(),stamp=new Date('2026-10-04T00:00:00Z');wb.creator='AI+ F03';wb.lastModifiedBy='AI+ F03';wb.created=stamp;wb.modified=stamp;
 for(const s of specs){const ws=wb.addWorksheet(s.name);ws.addRow(s.headers);for(const row of s.rows)ws.addRow(row.map(v=>v==null?'':typeof v==='object'?JSON.stringify(v):String(v)));ws.getRow(1).font={bold:true};ws.views=[{state:'frozen',ySplit:1}];ws.columns.forEach(c=>c.width=24);}
 // Deterministic generation, not relaxed comparison: ZIP member timestamps are set before delivery.
 const zip=await JSZip.loadAsync(await wb.xlsx.writeBuffer());zip.forEach((_,entry)=>{entry.date=stamp;});return zip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6},platform:'DOS'});
}
export const exportWorkbook=(w:Work)=>deterministicWorkbook(sheets(w));
