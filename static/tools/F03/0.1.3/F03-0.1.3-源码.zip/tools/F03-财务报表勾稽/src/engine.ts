import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';
import {asTable, type LoadedFile} from '../../../packages/core/io';
import type {Cell} from '../../../packages/core/types';
export const VERSION='0.1.3', RULE_VERSION='F03-2026-10-04.1';
const D=Decimal.clone({precision:40,rounding:Decimal.ROUND_HALF_UP});
export const HEADERS=['主体','报表范围','期间开始日','期间结束日','币种','金额单位','报表','项目','时点','金额','依据'] as const;
export type Field=typeof HEADERS[number];
export type Report='BS'|'PL'|'CF'|'BR';
export type Role='期初'|'期末'|'本期';
export interface Row {id:string;entity:string;scope:string;start:string;end:string;currency:string;unit:string;report:string;label:string;role:string;value:Cell;basis:string;source:{file:string;sheet:string;row:number;cell:string}; raw:Record<string,Cell>}
export interface Term {report:Report;metric:string;role:Role;sign:1|-1}
export interface Rule {id:string;name:string;kind:'equation'|'hint';enabled:boolean;tolerance:string;left:Term[];right:Term[];basis:string;condition:string;from:string;to:string;lockedHint?:boolean;custom?:boolean}
export interface Review {status:'待复核'|'已说明'|'待补资料';reviewer:string;note:string}
export interface Work {rows:Row[];mapping:Record<string,string>;rules:Rule[];reviews:Record<string,Review>;digits:2|4|6;bridgeConfirmed:boolean;profitRangeConfirmed:boolean}
export interface Issue {row:Row;messages:string[]}
export interface EvaluatedTerm {term:Term;rows:Row[];amount:string|null;message:string}
export interface Result {id:string;group:string;context:string[];rule:Rule;status:'通过'|'差异'|'阻塞'|'提示'|'停用'|'不适用';left:string|null;right:string|null;delta:string|null;terms:EvaluatedTerm[];messages:string[]}
export const METRICS:Record<Report,string[]>={BS:['资产总计','流动资产合计','非流动资产合计','负债合计','流动负债合计','非流动负债合计','所有者权益合计','负债和所有者权益总计','货币资金','未分配利润'],PL:['营业利润','营业外收入','营业外支出','利润总额','所得税费用','净利润','其他综合收益税后净额','综合收益总额'],CF:['经营活动现金净额','投资活动现金净额','筹资活动现金净额','汇率影响','现金净增加额','现金及等价物','补充资料净利润'],BR:['不属于现金的货币资金','货币资金之外的现金等价物','利润分配','盈余公积提取','其他留存调整']};
export const mapKey=(r:Pick<Row,'report'|'label'>)=>JSON.stringify([r.report,r.label]);
export const context=(r:Row)=>[r.entity,r.scope,r.start,r.end,r.currency,r.unit];
export const groupKey=(r:Row)=>JSON.stringify(context(r));
export function metric(r:Row,mapping:Record<string,string>):string{return mapping[mapKey(r)]??(METRICS[r.report as Report]?.includes(r.label)?r.label:'');}
const t=(report:Report,metric:string,role:Role='本期',sign:1|-1=1):Term=>({report,metric,role,sign});
export function defaultRules():Rule[]{
 const rows:[string,string,Term[],Term[],string][]=[
 ['BS1','资产分类加总',[t('BS','资产总计','期末')],[t('BS','流动资产合计','期末'),t('BS','非流动资产合计','期末')],'分类合计资料完整'],
 ['BS2','负债分类加总',[t('BS','负债合计','期末')],[t('BS','流动负债合计','期末'),t('BS','非流动负债合计','期末')],'分类合计资料完整'],
 ['BS3','资产负债平衡',[t('BS','资产总计','期末')],[t('BS','负债合计','期末'),t('BS','所有者权益合计','期末')],'同一主体及报表范围'],
 ['BS4','负债权益总计',[t('BS','负债和所有者权益总计','期末')],[t('BS','负债合计','期末'),t('BS','所有者权益合计','期末')],'同一主体及报表范围'],
 ['PL1','利润总额桥接',[t('PL','利润总额')],[t('PL','营业利润'),t('PL','营业外收入'),t('PL','营业外支出','本期',-1)],'已列报汇总项目含全部营业外事项'],
 ['PL2','净利润桥接',[t('PL','净利润')],[t('PL','利润总额'),t('PL','所得税费用','本期',-1)],'净利润采用全体所有者利润，不混用归母利润'],
 ['PL3','综合收益桥接',[t('PL','综合收益总额')],[t('PL','净利润'),t('PL','其他综合收益税后净额')],'其他综合收益为税后净额、利润范围一致'],
 ['CF1','现金净增加额加总',[t('CF','现金净增加额')],[t('CF','经营活动现金净额'),t('CF','投资活动现金净额'),t('CF','筹资活动现金净额'),t('CF','汇率影响')],'三类净额带符号；汇率影响显式列出，零也需资料'],
 ['CF2','期初期末现金衔接',[t('CF','现金及等价物','期末')],[t('CF','现金及等价物','期初'),t('CF','现金净增加额')],'现金及等价物口径和流量区间一致'],
 ['X1','跨表净利润一致',[t('PL','净利润')],[t('CF','补充资料净利润')],'补充资料采用同一期间和利润范围'],
 ['X2','期末现金构成核对',[t('CF','现金及等价物','期末')],[t('BS','货币资金','期末'),t('BR','不属于现金的货币资金','期末',-1),t('BR','货币资金之外的现金等价物','期末')],'附注确认全部现金构成，桥接资料带依据'],
 ['X3','期初现金构成核对',[t('CF','现金及等价物','期初')],[t('BS','货币资金','期初'),t('BR','不属于现金的货币资金','期初',-1),t('BR','货币资金之外的现金等价物','期初')],'期初构成对应开始日前一天、桥接资料带依据'],
 ['X4','未分配利润变动桥接',[t('BS','未分配利润','期末')],[t('BS','未分配利润','期初'),t('PL','净利润'),t('BR','利润分配','本期',-1),t('BR','盈余公积提取','本期',-1),t('BR','其他留存调整')],'用户确认全部留存变动：分红/提取/前期差错/范围变化等，均有依据'],
 ['H1','净利润与经营现金流差异',[t('PL','净利润')],[t('CF','经营活动现金净额')],'仅提示权责发生制与现金流差异，非必然等式']
 ];return rows.map(([id,name,left,right,condition])=>({id,name,left,right,condition,kind:id==='H1'?'hint':'equation',lockedHint:id==='H1',enabled:true,tolerance:'0.01',from:'1900-01-01',to:'9999-12-31',basis:id.startsWith('BS')||id.startsWith('PL')?'财政部第30号，稳定列报合计数学关系':id==='X4'?'用户确认完整留存变动桥接；第30号权益变动要求':'财政部第31号现金构成与调节；输入汇总项数学核对'}));
}
export const emptyWork=():Work=>({rows:[],mapping:{},rules:defaultRules(),reviews:{},digits:2,bridgeConfirmed:false,profitRangeConfirmed:false});
export function formula(terms:Term[]):string{return terms.map((x,i)=>(x.sign===-1?' − ':i?' + ':'')+`${x.report}.${x.metric}[${x.role}]`).join('');}
function validTerm(x:unknown):x is Term {const a=x as Term;return !!a&&['BS','PL','CF','BR'].includes(a.report)&&METRICS[a.report]?.includes(a.metric)&&['期初','期末','本期'].includes(a.role)&&[1,-1].includes(a.sign)&&((a.report==='BS'&&a.role!=='本期')||(a.report==='PL'&&a.role==='本期')||a.report==='CF'||a.report==='BR');}
export function validateRule(r:Rule){
 if(!r||typeof r.id!=='string'||!r.id||r.id.length>100||typeof r.name!=='string'||!r.name.trim()||r.name.length>200||!['equation','hint'].includes(r.kind)||typeof r.enabled!=='boolean'||typeof r.tolerance!=='string')throw Error('规则结构无效');
 if(amount(r.tolerance).isNegative())throw Error('容差不能为负数');
 date(r.from);date(r.to);if(r.from>r.to)throw Error('规则生效区间倒置');
 if(typeof r.basis!=='string'||!r.basis.trim()||typeof r.condition!=='string'||!r.condition.trim()||r.basis.length>2000||r.condition.length>2000)throw Error('规则须有依据与适用条件');
 for(const side of [r.left,r.right])if(!Array.isArray(side)||!side.length||side.length>12||!side.every(validTerm))throw Error('规则仅支持最多12项标准项目的加减关系');
 const ms=[...r.left,...r.right];if(r.kind==='equation'&&ms.some(t=>t.report==='PL'&&t.metric==='净利润')&&ms.some(t=>t.report==='CF'&&t.metric==='经营活动现金净额')&&ms.length===2)throw Error('净利润与经营现金流只能作为提示关系');
 const original=defaultRules().find(x=>x.id===r.id);
 if(original&&(JSON.stringify(r.left)!==JSON.stringify(original.left)||JSON.stringify(r.right)!==JSON.stringify(original.right)||r.basis!==original.basis||r.condition!==original.condition||r.from!==original.from||r.to!==original.to))throw Error('内置关系结构/依据不可被方案静默修改；新增自定义规则');
 if(original?.lockedHint&&r.kind!=='hint')throw Error('提示关系不能升级为硬等式');
}
export function rowErrors(r:Row):string[]{
 const errors:string[]=[];for(const [name,v] of Object.entries({主体:r.entity,报表范围:r.scope,币种:r.currency,金额单位:r.unit,项目:r.label}))if(typeof v!=='string'||!v.trim())errors.push(`${name}缺失`);
 if(!['个别','合并'].includes(r.scope))errors.push('报表范围须为个别或合并');
 if(!['元','千元','万元'].includes(r.unit))errors.push('金额单位须为元/千元/万元');
 if(!/^[A-Z]{3}$/.test(r.currency))errors.push('币种须为明确的三位大写代码');
 if(!['BS','PL','CF','BR'].includes(r.report))errors.push('报表须为BS/PL/CF/BR');
 if(!['期初','期末','本期'].includes(r.role)||(r.report==='BS'&&r.role==='本期')||(r.report==='PL'&&r.role!=='本期'))errors.push('报表时点角色无效');
 try{date(r.start);date(r.end);if(r.start>r.end)errors.push('期间倒置');}catch{errors.push('期间须为真实YYYY-MM-DD日期');}
 try{amount(r.value);}catch(e){errors.push((e as Error).message);}
 if(r.report==='BR'&&!r.basis.trim())errors.push('桥接资料须有依据和完整性确认');return errors;
}
export function evaluate(w:Work):{results:Result[];issues:Issue[];unmapped:Row[]}{
 if(w.rows.length>20000)throw Error('超过20000行');if(!w.rules.length||w.rules.length>100||new Set(w.rules.map(r=>r.id)).size!==w.rules.length)throw Error('规则数量或ID无效');w.rules.forEach(validateRule);
 const issues:Issue[]=[],unmapped:Row[]=[],groups=new Map<string,Row[]>();
 for(const r of w.rows){const errors=rowErrors(r);if(errors.length)issues.push({row:r,messages:errors});if(!metric(r,w.mapping))unmapped.push(r);const k=groupKey(r);groups.set(k,[...(groups.get(k)||[]),r]);}
 if(groups.size>100)throw Error('最多100个资料口径组合，请分批检查');
 const results:Result[]=[];
 for(const [group,rows] of groups){for(const rule of w.rules){
 const ctx=context(rows[0]);const out:Result={id:JSON.stringify([group,rule.id]),group,context:ctx,rule,status:'阻塞',left:null,right:null,delta:null,terms:[],messages:[]};
 if(!rule.enabled){out.status='停用';results.push(out);continue;}
 if(!rowErrors(rows[0]).some(e=>e.includes('期间'))&&(ctx[2]<rule.from||ctx[3]>rule.to)){out.status='不适用';out.messages.push('资料期间不在规则生效范围');results.push(out);continue;}
 // Invalid metadata contaminates its scope rather than becoming a zero-valued input.
 if(['PL2','PL3','X1','X4'].includes(rule.id)&&!w.profitRangeConfirmed)out.messages.push('尚未确认利润项目为同一全体所有者利润范围');
 if(['X2','X3','X4'].includes(rule.id)&&!w.bridgeConfirmed)out.messages.push('尚未确认桥接构成完整及依据');
 const metadataErrors=rows.flatMap(r=>rowErrors(r).filter(e=>/主体|范围|币种|单位|期间/.test(e)));if(metadataErrors.length)out.messages.push(...new Set(metadataErrors));
 const evalSide=(terms:Term[])=>{let sum=new D(0);for(const term of terms){const found=rows.filter(r=>r.report===term.report&&r.role===term.role&&metric(r,w.mapping)===term.metric);let value:string|null=null,msg='';
 if(found.length!==1)msg=found.length?'重复项目，整组阻塞':'缺少项目（含口径不一致或未对应）';else{const errs=rowErrors(found[0]);if(errs.length)msg=errs.join('；');else{value=amount(found[0].value).toFixed();sum=sum.plus(new D(value).times(term.sign));}}
 out.terms.push({term,rows:found,amount:value,message:msg});if(msg)out.messages.push(`${term.report}.${term.metric}[${term.role}]：${msg}`);
 }return sum;};const l=evalSide(rule.left),r=evalSide(rule.right);
 if(!out.messages.length){out.left=l.toFixed();out.right=r.toFixed();out.delta=l.minus(r).toFixed();out.status=rule.kind==='hint'?'提示':l.minus(r).abs().lte(new D(rule.tolerance))?'通过':'差异';if(rule.kind==='hint')out.messages.push('只作复核线索；差额为零也不代表该关系是必然等式。');}
 results.push(out);
 }}return {results,issues,unmapped};
}
export function colName(index:number){let s='';for(let x=index+1;x;x=Math.floor((x-1)/26))s=String.fromCharCode(65+(x-1)%26)+s;return s;}
export function importRows(loaded:LoadedFile,sheet:string,headerRow:number,fields:Record<Field,string>,batch:string):Row[]{
 const tab=asTable(loaded,sheet,headerRow);for(const h of HEADERS.filter(h=>h!=='依据'))if(!tab.headers.includes(fields[h]))throw Error(`未对应字段：${h}`);
 if(new Set(HEADERS.filter(h=>h!=='依据').map(h=>fields[h])).size!==10)throw Error('一个原列不能同时对应多个必填字段');
 const get=(cells:Record<string,Cell>,h:Field)=>{const c=cells[fields[h]];return c==null||typeof c==='string'&&!c.trim()?'':text(c).trim();};
 return tab.rows.map((r,i)=>({id:batch+':'+i,entity:get(r.cells,'主体'),scope:get(r.cells,'报表范围'),start:get(r.cells,'期间开始日'),end:get(r.cells,'期间结束日'),currency:get(r.cells,'币种'),unit:get(r.cells,'金额单位'),report:get(r.cells,'报表'),label:get(r.cells,'项目'),role:get(r.cells,'时点'),value:r.cells[fields['金额']]??null,basis:fields['依据']?get(r.cells,'依据'):'',source:{file:r.file,sheet:r.sheet,row:r.row,cell:colName(tab.headers.indexOf(fields['金额']))+r.row},raw:r.cells}));
}
function validateRows(rows:unknown):asserts rows is Row[]{
 if(!Array.isArray(rows)||rows.length>20000)throw Error('工作行数无效');const ids=new Set<string>();
 for(const r of rows){if(!r||typeof r!=='object')throw Error('工作原始行无效');for(const k of ['id','entity','scope','start','end','currency','unit','report','label','role','basis'])if(typeof r[k]!=='string'||r[k].length>10000)throw Error('工作原始行字段无效');
 if(ids.has(r.id))throw Error('工作来源ID重复');ids.add(r.id);
 const s=r.source;if(!s||typeof s.file!=='string'||s.file.length>1000||typeof s.sheet!=='string'||s.sheet.length>1000||!Number.isInteger(s.row)||s.row<1||s.row>20100||!new RegExp('^[A-Z]{1,3}'+s.row+'$').test(s.cell))throw Error('工作来源单元格无效');
 if(!r.raw||typeof r.raw!=='object'||Array.isArray(r.raw)||Object.keys(r.raw).length>200)throw Error('工作原始列无效');
 const validCell=(v:unknown)=>v===null||typeof v==='number'&&Number.isFinite(v)||typeof v==='string'&&v.length<=10000||!!v&&typeof v==='object'&&typeof (v as any).formula==='string'&&(v as any).formula.length<=10000&&JSON.stringify(v).length<=11000;
 if(!validCell(r.value)||!Object.values(r.raw).every(validCell))throw Error('工作原始值无效');
 }
}
export function encodeWork(w:Work,contains_data:boolean){evaluate(w);const raw=JSON.stringify({schema_version:1,tool:'F03',app_version:VERSION,rule_version:RULE_VERSION,contains_data,rules:w.rules,mapping:w.mapping,digits:w.digits,bridgeConfirmed:w.bridgeConfirmed,profitRangeConfirmed:w.profitRangeConfirmed,...(contains_data?{rows:w.rows,reviews:w.reviews}:{})},null,2);if(new TextEncoder().encode(raw).length>10*1024*1024)throw Error('工作导出超过10MB，请分批保存或下载底稿');return raw;}
export function decodeWork(raw:string):Work{
 if(new TextEncoder().encode(raw).length>10*1024*1024)throw Error('方案超过10MB');const p=JSON.parse(raw);
 if(p?.schema_version!==1||p.tool!=='F03'||p.app_version!==VERSION||p.rule_version!==RULE_VERSION||typeof p.contains_data!=='boolean'||![2,4,6].includes(p.digits)||typeof p.bridgeConfirmed!=='boolean'||typeof p.profitRangeConfirmed!=='boolean')throw Error('方案版本或包含数据标识不兼容');
 if(!Array.isArray(p.rules)||!p.rules.length||p.rules.length>100||new Set(p.rules.map((r:Rule)=>r.id)).size!==p.rules.length)throw Error('方案规则结构无效');p.rules.forEach(validateRule);
 if(!p.mapping||typeof p.mapping!=='object'||Array.isArray(p.mapping)||Object.keys(p.mapping).length>20000)throw Error('方案映射无效');
 for(const [key,v] of Object.entries(p.mapping)){let pair;try{pair=JSON.parse(key);}catch{throw Error('映射键无效');}if(!Array.isArray(pair)||pair.length!==2||!pair.every(x=>typeof x==='string'&&x.length<10000)||!METRICS[pair[0] as Report]||typeof v!=='string'||v!==''&&v!=='不参加规则'&&!METRICS[pair[0] as Report].includes(v))throw Error('方案项目映射无效');}
 if(!p.contains_data&&(p.rows!==undefined||p.reviews!==undefined))throw Error('无数据方案不可夹带数据');validateRows(p.contains_data?p.rows:[]);
 const w:Work={rows:p.contains_data?p.rows:[],rules:p.rules,mapping:p.mapping,digits:p.digits,bridgeConfirmed:p.bridgeConfirmed,profitRangeConfirmed:p.profitRangeConfirmed,reviews:{}};const valid=new Set(evaluate(w).results.map(r=>r.id));
 if(p.contains_data){if(!p.reviews||typeof p.reviews!=='object'||Array.isArray(p.reviews)||Object.keys(p.reviews).length>10000)throw Error('复核记录结构无效');for(const [id,x] of Object.entries(p.reviews)){const rev=x as Review;if(!valid.has(id)||!rev||!['待复核','已说明','待补资料'].includes(rev.status)||typeof rev.reviewer!=='string'||typeof rev.note!=='string'||rev.note.length>2000||rev.reviewer.length>100)throw Error('复核记录无效');w.reviews[id]=rev;}}
 return w;
}
export function sample():Work{
 const w=emptyWork();w.bridgeConfirmed=true;w.profitRangeConfirmed=true;const values:[Report,string,Role,string][]=[['BS','资产总计','期末','1000'],['BS','流动资产合计','期末','600'],['BS','非流动资产合计','期末','400'],['BS','负债合计','期末','400'],['BS','流动负债合计','期末','250'],['BS','非流动负债合计','期末','150'],['BS','所有者权益合计','期末','600'],['BS','负债和所有者权益总计','期末','1000'],['BS','货币资金','期末','140'],['BS','货币资金','期初','100'],['BS','未分配利润','期初','200'],['BS','未分配利润','期末','250'],['PL','营业利润','本期','100'],['PL','营业外收入','本期','20'],['PL','营业外支出','本期','10'],['PL','利润总额','本期','110'],['PL','所得税费用','本期','30'],['PL','净利润','本期','80'],['PL','其他综合收益税后净额','本期','5'],['PL','综合收益总额','本期','85'],['CF','经营活动现金净额','本期','70'],['CF','投资活动现金净额','本期','-40'],['CF','筹资活动现金净额','本期','10'],['CF','汇率影响','本期','0'],['CF','现金净增加额','本期','40'],['CF','现金及等价物','期初','100'],['CF','现金及等价物','期末','140'],['CF','补充资料净利润','本期','80'],['BR','不属于现金的货币资金','期初','10'],['BR','不属于现金的货币资金','期末','20'],['BR','货币资金之外的现金等价物','期初','10'],['BR','货币资金之外的现金等价物','期末','20'],['BR','利润分配','本期','20'],['BR','盈余公积提取','本期','10'],['BR','其他留存调整','本期','0']];
 w.rows=values.map(([report,label,role,value],i)=>{const raw:Record<string,Cell>={主体:'虚构星禾公司',报表范围:'个别',期间开始日:'2026-01-01',期间结束日:'2026-09-30',币种:'CNY',金额单位:'万元',报表:report,项目:label,时点:role,金额:value,依据:report==='BR'?'虚构附注；完整构成已确认（含零调整）':''};return {id:'sample:'+i,entity:'虚构星禾公司',scope:'个别',start:'2026-01-01',end:'2026-09-30',currency:'CNY',unit:'万元',report,label,role,value,basis:String(raw['依据']),raw,source:{file:'完全虚构样例.csv',sheet:'CSV',row:i+2,cell:'J'+(i+2)}};});return w;
}
