import React from 'react';
/** Exact count text; container-relative typography never rounds or abbreviates. */
export function FinancialCount({value}:{value:number|string}){const text=String(value);return <strong className={'f03-count'+(text.length>10?' f03-count-long':'')} style={{'--count-chars':text.length} as React.CSSProperties}>{text}</strong>;}
