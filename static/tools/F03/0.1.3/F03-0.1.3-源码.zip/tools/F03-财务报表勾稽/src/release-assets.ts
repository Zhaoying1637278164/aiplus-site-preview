import {csv,dataCSV} from './export';import {HEADERS,sample} from './engine';
import {largeCSV,largeXLSX} from './large-assets';
import type {ReleaseAsset} from '../../../packages/core/release-assets';
export async function releaseAssets():Promise<ReleaseAsset[]>{return [{filename:'604行虚构资料.csv',data:new TextEncoder().encode(largeCSV())},{filename:'604行虚构资料.xlsx',data:await largeXLSX()},{filename:'空白模板.csv',data:new TextEncoder().encode(csv([...HEADERS],[]))},{filename:'虚构样例.csv',data:new TextEncoder().encode(dataCSV(sample()))}];}
