import React from 'react';
export interface DetailField{name:string;value:unknown}
export const reportName=(report:string)=>({BS:'资产负债表',PL:'利润表',CF:'现金流量表',BR:'桥接资料'}[report]||report);
export const contextText=(v:unknown[])=>`${v[0]} · ${v[1]}\n${v[2]} 至 ${v[3]}\n${v[4]} · ${v[5]}`;
export const plain=(v:unknown)=>v==null?'':typeof v==='object'?JSON.stringify(v):String(v);
export function Details({fields,label='完整详情与来源'}:{fields:DetailField[];label?:string}){
 const technical=(name:string)=>name.includes('ID')||name==='ID'||name.includes('JSON');
 const cells=(data:DetailField[])=>data.map(({name,value})=><div key={name} className="f03-detail-cell" data-detail-label={name}><dt>{name}</dt><dd>{plain(value)}</dd></div>);
 const structures=fields.filter(f=>f.name.includes('JSON')).map(f=>{try{const v=JSON.parse(String(f.value));return {name:f.name,fields:Array.isArray(v)?v.map((x,i)=>({name:`第${i+1}项`,value:x})):Object.entries(v).map(([name,value])=>({name,value}))};}catch{return null;}}).filter(x=>x!==null);
 return <details className="f03-full-details"><summary>{label}</summary><dl className="f03-detail-fields">{cells(fields.filter(f=>!technical(f.name)))}</dl>{structures.map(s=><div className="f03-original-fields" key={s!.name}><h4>原始字段与值</h4><dl>{s!.fields.map(f=><div className="f03-raw-field" key={f.name} data-raw-field={f.name}><dt>{f.name}</dt><dd>{plain(f.value)}</dd></div>)}</dl></div>)}{fields.some(f=>technical(f.name))&&<details className="f03-technical"><summary>技术标识与完整原始结构</summary><dl>{cells(fields.filter(f=>technical(f.name)))}</dl></details>}</details>;
}
export interface PreviewSheet{name:string;headers:string[];rows:{values:unknown[];details:DetailField[]}[];cardFields:number[]}
/** View projection only. All input cells remain in the full detail and unchanged export. */
export function readableSheets(input:{name:string;headers:string[];rows:unknown[][]}[]):PreviewSheet[]{
 const checks=new Map(input[0]?.rows.map(r=>[r[0],r])||[]);
 const layouts=[
 ['主体与期间','财务关系','状态','左值','右值','精确差额'],
 ['主体与期间','财务关系','参与项目 / 时点','符号','项值','问题','原金额'],
 ['主体与期间','原项目 / 时点','原金额','标准项目'],
 ['原项目','原金额','问题','金额来源'],
 ['原项目','原金额','报表','金额来源'],
 ['原项目','标准项目','报表'],
 ['财务关系','关系类型','启用','容差','有效期间'],
 ['主体与期间','财务关系','复核状态','复核人','说明'],
 ['参数','值']
 ];
 const value=(i:number,r:unknown[])=>{const c=checks.get(r[0]);switch(i){
 case 0:return [contextText(r.slice(1,7)),`${r[8]} · ${r[9]}`,r[10],r[11]??'—',r[12]??'—',r[13]??'—'];
 case 1:return [c?contextText(c.slice(1,7)):'缺少检查身份',c?.[8]||r[1],`${reportName(String(r[2]))} · ${r[3]} · ${r[4]}`,Number(r[5])===1?'+':'−',r[6]??'—',r[7],r[14]];
 case 2:return [contextText(r.slice(1,7)),`${reportName(String(r[7]))} · ${r[8]} · ${r[9]}`,r[10]??'（缺失）',r[12]||'未对应'];
 case 3:{const source=input[2]?.rows.find(s=>s[0]===r[0]);return [source?.[8]||'来源待补',r[6]??'（缺失）',r[1],`${r[2]} / ${r[3]}!${r[5]}（第${r[4]}行）`];}
 case 4:return [r[2],r[6]??'（缺失）',reportName(String(r[1])),`${r[3]} / ${r[4]}（第${r[5]}行）`];
 case 5:{let key=['',''];try{key=JSON.parse(String(r[0]));}catch{}return [key[1],r[1]||'未对应',reportName(key[0])];}
 case 6:return [r[1],r[2]==='hint'?'提示关系':'确定等式',r[3]?'启用':'停用',r[4],`${r[9]} 至 ${r[10]}`];
 case 7:return [c?contextText(c.slice(1,7)):'缺少检查身份',c?.[8]||'检查待补',r[1],r[2],r[3]];
 default:return r;
 }};
 const primary=[[0,1,2,5,6],[0,2,4,7],[0,1,2,4],[0,1,2,4],[0,1,4],[0,1,3],[0,1,2,5],[0,1,2,5],[0,1,2]];
 return input.map((s,i)=>({name:s.name,headers:layouts[i],cardFields:primary[i],rows:s.rows.map(r=>({values:value(i,r),details:s.headers.map((name,j)=>({name,value:r[j]}))}))}));
}
