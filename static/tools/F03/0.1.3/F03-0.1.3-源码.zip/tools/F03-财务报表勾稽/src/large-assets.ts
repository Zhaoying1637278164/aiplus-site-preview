import fixture from '../tests/fixtures/large-work.json';import {decodeWork} from './engine';import {dataCSV,deterministicWorkbook} from './export';import {HEADERS} from './engine';
export const largeSample=()=>decodeWork(JSON.stringify(fixture));
export const largeCSV=()=>dataCSV(largeSample());
export async function largeXLSX(){const w=largeSample();return deterministicWorkbook([{name:'虚构说明',headers:['说明'],rows:[['完全虚构资料，须选择三表资料页签和第二行表头']]},{name:'三表资料',headers:['虚构说明'],rows:[[...HEADERS.map(h=>h==='金额'?'本期列报':h)],...w.rows.map(r=>HEADERS.map(h=>r.raw[h]))]}]);}
