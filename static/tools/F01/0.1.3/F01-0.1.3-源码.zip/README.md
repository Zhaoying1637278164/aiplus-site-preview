# F01 源码重建

仅包含本款与共享工程，无其他业务工具、数据或凭据。Node.js 22+：

```sh
npm ci
npm test
npm run typecheck
npm run build
```

构建在 progress/evidence/F01/candidate 生成index.html、runtime.json及虚构资产。正式release与官网由集成负责人另行验收，本包不是accepted声明。

浏览器验收可运行本款tests/browser.ts；通过F01_CHROMIUM环境变量提供本机Chromium路径。依赖安装需要可用网络或npm缓存，构建后的HTML无需网络。

默认静态样例由ExcelJS生成后固定字节，避免ZIP时间戳漂移；源码含同一虚构XLSX与静态base64模块。共享IO对用户导出仍每次生成新的工作簿，不对用户工作伪造日期。
