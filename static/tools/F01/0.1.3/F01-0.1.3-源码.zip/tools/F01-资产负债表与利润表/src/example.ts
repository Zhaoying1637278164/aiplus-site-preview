import type {Table} from '../../../packages/core/types';
import {schemas,initialOptions,type Role,type Workspace} from './types';
export function table(role:Role,rows:unknown[][],file='虚构资料.xlsx',sheet:string=role):Table{return {file,sheet,headers:[...schemas[role]],rows:rows.map((values,i)=>({file,sheet,row:i+2,cells:Object.fromEntries(schemas[role].map((h,k)=>[h,values[k]===undefined||values[k]===''?null:values[k]]))}))} as Table;}
export function template():Table{
 const rows:unknown[][]=[];const add=(id:string,st:string,name:string,group:string,type='明细',terms='')=>rows.push([id,st,name,group,type,terms,'是']);
 const groups:[string,string,string[]][]=[['CA','流动资产',['货币资金','交易性金融资产','衍生金融资产','应收票据','应收账款','应收款项融资','预付款项','其他应收款','存货','合同资产','持有待售资产','一年内到期的非流动资产','其他流动资产']],['NA','非流动资产',['债权投资','其他债权投资','长期应收款','长期股权投资','其他权益工具投资','其他非流动金融资产','投资性房地产','固定资产','在建工程','生产性生物资产','油气资产','使用权资产','无形资产','开发支出','商誉','长期待摊费用','递延所得税资产','其他非流动资产']],['CL','流动负债',['短期借款','交易性金融负债','衍生金融负债','应付票据','应付账款','预收款项','合同负债','应付职工薪酬','应交税费','其他应付款','持有待售负债','一年内到期的非流动负债','其他流动负债']],['NL','非流动负债',['长期借款','应付债券','租赁负债','长期应付款','预计负债','递延收益','递延所得税负债','其他非流动负债']],['EQ','权益',['实收资本（或股本）','其他权益工具','资本公积','库存股','其他综合收益','专项储备','盈余公积','未分配利润']]];
 for(const [prefix,group,names]of groups){names.forEach((n,i)=>add(`${prefix}${i+1}`,'BS',n,prefix==='EQ'&&i===3?'权益减项':group));add(`${prefix}_SUM`,'BS',`${group}合计`,prefix==='CA'||prefix==='NA'?'资产合计':prefix==='CL'||prefix==='NL'?'负债合计':'权益合计','合计',names.map((_,i)=>`${prefix}${i+1}*${prefix==='EQ'&&i===3?'-1':'1'}`).join(';'));}
 add('ASSETS','BS','资产总计','资产合计','合计','CA_SUM*1;NA_SUM*1');add('LIABS','BS','负债合计','负债合计','合计','CL_SUM*1;NL_SUM*1');add('LE','BS','负债和所有者权益总计','负债权益合计','合计','LIABS*1;EQ_SUM*1');
 // 库存股是明细正数减项：引擎勾稽使用模板总计优先，避免方向重复。
 const names=['营业收入','营业成本','税金及附加','销售费用','管理费用','研发费用','财务费用','其他收益','投资收益','净敞口套期收益','公允价值变动收益','信用减值损失','资产减值损失','资产处置收益'];names.forEach((n,i)=>add(`P${i+1}`,'PL',n,'损益'));
 add('OPERATING','PL','营业利润','损益','合计',names.map((_,i)=>`P${i+1}*${i>=1&&i<=6?'-1':'1'}`).join(';'));
 add('P15','PL','营业外收入','损益');add('P16','PL','营业外支出','损益');add('PRETAX','PL','利润总额','损益','合计','OPERATING*1;P15*1;P16*-1');add('P17','PL','所得税费用','损益');add('NET','PL','净利润','损益','合计','PRETAX*1;P17*-1');
 add('MEMO_INT_COST','PL','其中：利息费用','损益','其中');add('MEMO_INT_INCOME','PL','其中：利息收入','损益','其中');
 // 默认未确认零，虚构样例才明确没有其他业务。用户需逐项确认或映射。
 const t=table('items',rows,'内置报表底稿','报表项目');t.rows.forEach(r=>{if(r.cells['类型']!=='合计')r.cells['确认零']='否'});return t;
}
export function example():Workspace{
 const items=template();items.rows.forEach(r=>r.cells['确认零']='是');
 const specs:[string,string,string,string,string,string,string,string][]=[['1001','银行','BS','CA1','借-贷','1','1000','800'],['1122','应收','BS','CA5','借-贷','1','300','200'],['1231','坏账','BS','CA5','贷-借','-1','20','10'],['1601','设备','BS','NA8','借-贷','1','500','400'],['1602','折旧','BS','NA8','贷-借','-1','100','80'],['2202','应付','BS','CL5','贷-借','1','200','150'],['4001','资本','BS','EQ1','贷-借','1','1000','1000'],['4104','留存','BS','EQ8','贷-借','1','480','160'],['6001','销售','PL','P1','贷-借','1','1000','800'],['6401','成本','PL','P2','借-贷','1','600','500'],['6602','管理','PL','P5','借-贷','1','100','80'],['6117','收益','PL','P8','贷-借','1','30','20'],['6701','减值','PL','P12','贷-借','1','20','10'],['6801','税','PL','P17','借-贷','1','50','40']];
 const balances:unknown[][]=[],maps:unknown[][]=[];for(const [code,name,st,item,direction,factor,now,prior]of specs){maps.push([`M${code}`,st,code,'汇总',item,direction,factor,'虚构公司人工确认的报表分类']);for(const [period,v]of [['2025-12',now],['2024-12',prior]]){const credit=direction==='贷-借'&&code!=='6701';balances.push(['虚构星河公司',period,'CNY','元',code,name,'汇总',st==='BS'?'期末余额':'损益发生额',credit?'0':v,credit?v:'0']);}}
 return {tables:{balances:table('balances',balances),items,mappings:table('mappings',maps),adjustments:table('adjustments',[])},options:{...initialOptions,entity:'虚构星河公司',confirmed:true}};
}
