import {program} from './program';
const instance=program.mount({container:document.getElementById('root')!,mode:'offline'});
window.addEventListener('pagehide',()=>instance.dispose(),{once:true});
