import React from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import type {ToolProgram} from '../../../packages/ui/tool-host';
import {VERSION} from './types';
import {App,type Controller} from './app';
export const program:ToolProgram={id:'F01',version:VERSION,name:'资产负债表与利润表',mount(context){const root=createRoot(context.container);const controller:Controller={dirty:false,alive:true,generation:0};const requestExit=()=>!controller.dirty||confirm('工作仅在内存，未下载的资料将丢失。确认退出？');const before=(e:BeforeUnloadEvent)=>{if(controller.dirty){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',before);const exit=()=>{if(requestExit()){controller.clear?.();context.onExit?.();}};flushSync(()=>root.render(<App controller={controller} onExit={context.onExit?exit:undefined}/>));return {requestExit,dispose(){controller.alive=false;controller.generation++;controller.clear=undefined;window.removeEventListener('beforeunload',before);root.unmount();context.container.replaceChildren();}}}};
