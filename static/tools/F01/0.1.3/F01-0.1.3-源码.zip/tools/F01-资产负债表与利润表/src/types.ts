import type {Table,SourceRow} from '../../../packages/core/types';
export const VERSION='0.1.3',RULE_VERSION='F01-CN-20261004.1';
export const schemas={
 balances:['主体','期间','币种','单位','科目编码','科目名称','明细键','资料性质','借方','贷方'],
 items:['项目ID','报表','项目名称','分组','类型','合计组成','确认零'],
 mappings:['映射ID','报表','科目编码','明细键','项目ID','方向','系数','依据'],
 adjustments:['调整ID','调整组','报表','期间','项目ID','金额','依据'],
} as const;
export type Role=keyof typeof schemas;
export interface Options{entity:string;currency:string;unit:'元'|'万元';bsPeriod:string;bsCompare:string;plStart:string;plEnd:string;priorStart:string;priorEnd:string;display:number;tolerance:string;company:'非上市'|'境内上市'|'境外或两地上市';early:boolean;confirmed:boolean;templateVersion:string;}
export interface Workspace{tables:Record<Role,Table|null>;options:Options}
export const initialOptions:Options={entity:'',currency:'CNY',unit:'元',bsPeriod:'2025-12',bsCompare:'2024-12',plStart:'2025-12',plEnd:'2025-12',priorStart:'2024-12',priorEnd:'2024-12',display:2,tolerance:'0.01',company:'非上市',early:false,confirmed:false,templateVersion:'财会2019-6附件2底稿'};
export const emptyWorkspace=():Workspace=>({tables:{balances:null,items:null,mappings:null,adjustments:null},options:{...initialOptions}});
export interface Issue{severity:'阻塞'|'提示';code:string;message:string;role:Role|'参数';source?:SourceRow;}
export interface Item{id:string;statement:'BS'|'PL';name:string;group:string;type:'明细'|'合计'|'其中';terms:{id:string;sign:number}[];zero:boolean;source:SourceRow}
export interface Trace{statement:'BS'|'PL';column:'本期'|'比较';period:string;item:string;account:string;detail:string;direction:string;factor:string;rawDebit:string;rawCredit:string;value:string;kind:'账面'|'调整';rule:string;basis:string;source:SourceRow;}
export interface Line{item:Item;current:string|null;prior:string|null;currentBook:string|null;currentAdjustment:string|null;priorBook:string|null;priorAdjustment:string|null;}
export interface Result{issues:Issue[];lines:Line[];traces:Trace[];unmapped:{source:SourceRow;statement:string;period:string;debit:string|null;credit:string|null;net:string|null;absolute:string|null;reason:string}[];checks:{name:string;period:string;difference:string|null;status:string}[];complete:boolean;}
