import {sampleBytes} from './sample-bytes';
import {example,template} from './example';
import {schemas,type Role} from './types';
import {encodePlan} from './plan';
export async function releaseAssets(){const w=example();const csv=(headers:readonly string[],rows:unknown[][]=[])=>'\uFEFF'+[headers,...rows].map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n')+'\r\n';return [
 {filename:'空白模板.csv',data:csv(schemas.balances)},
 ...(['items','mappings','adjustments']as Role[]).map(role=>({filename:({items:'报表项目模板.csv',mappings:'科目映射模板.csv',adjustments:'调整底稿模板.csv'}as Record<string,string>)[role],data:csv(schemas[role])})),
 {filename:'报表项目参考.csv',data:csv(schemas.items,template().rows.map(r=>schemas.items.map(h=>r.cells[h])))},
 {filename:'虚构样例.xlsx',data:sampleBytes()},
 ...Object.entries(w.tables).map(([role,t])=>({filename:`虚构_${role}.csv`,data:csv(schemas[role as Role],t!.rows.map(r=>schemas[role as Role].map(h=>r.cells[h])))})),
 {filename:'虚构含数据方案.json',data:encodePlan(w,true)},{filename:'虚构无数据方案.json',data:encodePlan(w,false)}];}
