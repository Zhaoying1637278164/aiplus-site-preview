import React from 'react';
/** Presentation only. The original coverage key and exported workbook are untouched. */
export const scopeHeader='主体/期间/币种/单位/性质';
export const scopeLabels=['主体','期间','币种','单位','资料性质'] as const;
export function scopeFields(raw:unknown){
 let values:unknown[]=[];try{const parsed=typeof raw==='string'?JSON.parse(raw):null;if(Array.isArray(parsed))values=parsed}catch{/* Keep the raw key available for review. */}
 return scopeLabels.map((label,index)=>{const value=values[index];let text:string;
  if(value===undefined||value===null)text='未提供';
  else if(value==='')text='空值（空字符串）';
  else if(typeof value==='string'&&!value.trim())text=`空白（${value.length}字符）`;
  else if(typeof value==='string'||typeof value==='number'||typeof value==='boolean')text=String(value);
  else text='非静态值（请复核）';
  return {label,text};
 });
}
export function ScopeIdentity({value}:{value:unknown}){
 const raw=typeof value==='string'?value:JSON.stringify(value)??'';
 return <div className="scope-identity" data-scope-key={raw}><dl className="scope-fields">{scopeFields(value).map(field=><div key={field.label} data-scope-field={field.label}><dt>{field.label}</dt><dd>{field.text}</dd></div>)}</dl><details className="scope-technical"><summary>技术原组键（核验用）</summary><pre className="scope-raw">{raw}</pre></details></div>;
}
