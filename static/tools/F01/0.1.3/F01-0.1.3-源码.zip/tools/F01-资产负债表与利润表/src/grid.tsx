import {ScopeIdentity,scopeHeader} from './scope-identity';
import React,{useEffect,useState} from 'react';
const stringify=(v:unknown)=>v===null||v===undefined?'未提供':typeof v==='object'?JSON.stringify(v):String(v);
function profile(h:string){
 if(h===scopeHeader)return {width:380,kind:'scope'};
 if(/金额|差额|借方|贷方|净额|精确|调整$|账面|列报|原借|原贷/.test(h))return {width:144,kind:'amount'};
 if(/文件|来源/.test(h))return {width:320,kind:'key'};
 if(/明细|页签|^科目$/.test(h))return {width:180,kind:'key'};
 if(/期间/.test(h))return {width:120,kind:'key'};
 if(/序号|^行$|原行|源行|系数|输入行|有效行|隔离行|计数/.test(h))return {width:112,kind:'key'};
 if(/编码|ID|方向|币种|单位|^报表$|^列$|资料性质|类型|分组|等级|状态/.test(h))return {width:160,kind:'key'};
 if(/来源|文件|页签|原始值|依据|说明|原因|合计组成|主体\/|规则/.test(h))return {width:320,kind:'text'};
 return {width:220,kind:'text'};
}
const preferred=['期间','科目编码','科目','科目名称','明细','明细键','项目ID','项目','项目名称','借方','贷方','原借','原贷','金额','精确金额','净额','本期列报','比较列报','方向','系数','报表','分组','类型','确认零','等级','代码','说明','原因','检查','状态','主体'];
function Value({header,value}:{header:string;value:unknown}){if(header===scopeHeader)return <ScopeIdentity value={value}/>;const text=stringify(value),kind=profile(header).kind;return <span className={'cell-value '+kind+(text.startsWith('-')?' negative':'')}>{text}</span>}
export function Grid({headers,rows,onEdit}:{headers:string[];rows:unknown[][];onEdit?:(index:number)=>void}){
 const [page,setPage]=useState(0),[query,setQuery]=useState(''),[size,setSize]=useState(20);
 useEffect(()=>{const media=matchMedia('(max-width:600px)');const resize=()=>{setSize(media.matches?5:20);setPage(0)};resize();media.addEventListener('change',resize);return ()=>media.removeEventListener('change',resize)},[]);
 const filtered=rows.map((cells,index)=>({cells,index})).filter(r=>!query||r.cells.some(v=>stringify(v).includes(query)));
 const max=Math.max(0,Math.ceil(filtered.length/size)-1),p=Math.min(page,max),shown=filtered.slice(p*size,p*size+size);
 let priorities=preferred.filter(h=>headers.includes(h));if(!priorities.length)priorities=headers.filter(h=>!/文件|页签|来源|行/.test(h));priorities=priorities.slice(0,6);
 const columns=headers.map(profile),width=columns.reduce((sum,c)=>sum+c.width,0)+(onEdit?128:0);
 return <div className="data-grid"><div className="grid-tools"><label>查询本表<input aria-label="查询本表" value={query} placeholder="查找科目、期间、金额或来源" onChange={e=>{setQuery(e.target.value);setPage(0)}}/></label><p>共{rows.length}行{query&&` · 匹配${filtered.length}行`} · 导出包含完整资料</p></div>
 <div className="grid desktop-grid" tabIndex={0} aria-label="完整字段表，左右滚动查看全部列"><table style={{width,minWidth:width,tableLayout:'fixed'}}><colgroup>{columns.map((c,i)=><col key={i} style={{width:c.width}}/>)}{onEdit&&<col style={{width:128}}/>}</colgroup><thead><tr>{headers.map((h,i)=><th key={i} data-column={h}>{h===scopeHeader?'财务口径':h}</th>)}{onEdit&&<th>操作</th>}</tr></thead><tbody>{shown.map(r=><tr key={r.index}>{r.cells.map((v,i)=><td key={i} data-column={headers[i]} className={columns[i].kind}>{columns[i].kind==='text'&&stringify(v).length>60?<details className="cell-detail"><summary title={stringify(v)}>{stringify(v)}</summary><div><Value header={headers[i]} value={v}/></div></details>:<Value header={headers[i]} value={v}/>}</td>)}{onEdit&&<td><button onClick={()=>onEdit(r.index)}>编辑此行</button></td>}</tr>)}</tbody></table></div>
 <div className="mobile-records">{shown.map(r=><article className="mobile-record" key={r.index}><div className="record-title">第{r.index+1}行<span>{String(r.cells[headers.indexOf('报表')]??r.cells[headers.indexOf('资料性质')]??'')}</span></div><dl className="priority-fields">{priorities.map(h=><div className={h===scopeHeader?'scope-field':undefined} key={h}><dt>{h===scopeHeader?'财务口径':h}</dt><dd><Value header={h} value={r.cells[headers.indexOf(h)]}/></dd></div>)}</dl><details className="record-detail"><summary>全部{headers.length}个字段与来源</summary><dl>{headers.map((h,i)=><div key={i}><dt>{h===scopeHeader?'财务口径':h}</dt><dd><Value header={h} value={r.cells[i]}/></dd></div>)}</dl></details>{onEdit&&<button onClick={()=>onEdit(r.index)}>编辑此行</button>}</article>)}</div>
 <div className="pagination"><span>第{p+1}/{max+1}页 · 共{filtered.length}行 · {shown.length?`${p*size+1}–${p*size+shown.length}行`:'0行'}</span><label>每页行数<select aria-label="每页行数" value={size} onChange={e=>{setSize(Number(e.target.value));setPage(0)}}>{[5,10,20,50].map(n=><option key={n} value={n}>{n}</option>)}</select></label><div className="page-buttons"><button disabled={p===0} onClick={()=>setPage(0)}>首页</button><button disabled={p===0} onClick={()=>setPage(p-1)}>上一页</button><button disabled={p===max} onClick={()=>setPage(p+1)}>下一页</button><button disabled={p===max} onClick={()=>setPage(max)}>末页</button></div><label>跳转页码<input aria-label="跳转页码" type="number" min={1} max={max+1} value={p+1} onChange={e=>{const n=Number(e.target.value);if(Number.isInteger(n)&&n>=1&&n<=max+1)setPage(n-1)}}/></label></div>{!filtered.length&&<p className="empty">暂无记录</p>}</div>;
}
