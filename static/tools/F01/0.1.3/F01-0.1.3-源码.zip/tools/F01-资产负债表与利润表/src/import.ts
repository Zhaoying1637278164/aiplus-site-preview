import {asTable,type LoadedFile} from '../../../packages/core/io';
import type {Role} from './types';
/** Empty adjustments are valid. Keep core header/bounds validation unchanged. */
export function inputTable(loaded:LoadedFile,sheet:string,header:number,role:Role){
 try{return asTable(loaded,sheet,header)}catch(e){
  if(role!=='adjustments'||(e as Error).message!=='页签没有数据行')throw e;
  const selected=loaded.sheets.find(s=>s.name===sheet)!;
  // asTable has already validated the real header. A temporary sentinel validates
  // the exact same core interface; it never enters workspace or calculation.
  const checked=asTable({...loaded,sheets:[{name:sheet,matrix:[...selected.matrix,selected.matrix[header-1].map(()=> '仅校验表头')]}]},sheet,header);
  return {...checked,rows:[]};
 }
}
