import {coverage,coverageHeaders} from './coverage';
import Decimal from 'decimal.js';
import {workbookBytes} from '../../../packages/core/io';
import type {Workspace,Result,Role} from './types';
import {VERSION,RULE_VERSION,schemas} from './types';
export function sheets(w:Workspace,r:Result){const headers=['项目ID','项目','分组','类型','本期账面','本期调整','本期精确金额','比较账面','比较调整','比较精确金额','本期显示','比较显示','输入单位','状态'];const output=(st:string)=>r.lines.filter(l=>l.item.statement===st).map(l=>[l.item.id,l.item.name,l.item.group,l.item.type,l.currentBook,l.currentAdjustment,l.current,l.priorBook,l.priorAdjustment,l.prior,l.current===null?'未提供':new Decimal(l.current).toFixed(w.options.display),l.prior===null?'未提供':new Decimal(l.prior).toFixed(w.options.display),w.options.unit,r.complete?'编制检查通过':'待复核/不完整']);return [
 {name:'资料覆盖',headers:coverageHeaders,rows:coverage(w,r)},
 {name:'编制参数',headers:['参数','值'],rows:[['应用版本',VERSION],['规则版本',RULE_VERSION],...Object.entries(w.options),['完整性',r.complete?'通过':'阻塞']]},
 {name:'资产负债表',headers,rows:output('BS')},{name:'利润表',headers,rows:output('PL')},
 {name:'来源追溯',headers:['报表','列','期间','项目','科目','明细','方向','系数','原借','原贷','精确金额','类型','规则ID','依据','文件','页签','原行'],rows:r.traces.map(t=>[t.statement,t.column,t.period,t.item,t.account,t.detail,t.direction,t.factor,t.rawDebit,t.rawCredit,t.value,t.kind,t.rule,t.basis,t.source.file,t.source.sheet,t.source.row])},
 {name:'未映射与隔离',headers:['报表','期间','借方','贷方','借贷净额','借贷绝对金额','原因','文件','页签','行','原始值'],rows:r.unmapped.map(t=>[t.statement,t.period,t.debit,t.credit,t.net,t.absolute,t.reason,t.source.file,t.source.sheet,t.source.row,t.source.cells])},
 {name:'异常',headers:['等级','代码','原因','资料','文件','页签','行','原始值'],rows:r.issues.map(i=>[i.severity,i.code,i.message,i.role,i.source?.file,i.source?.sheet,i.source?.row,i.source?.cells])},
 {name:'勾稽',headers:['检查','期间','精确差额','状态'],rows:r.checks.map(c=>[c.name,c.period,c.difference,c.status])},
 ...Object.entries(w.tables).filter(([,t])=>t).map(([role,t])=>({name:`原始_${role}`,headers:['源文件','源页签','源行',...schemas[role as Role]],rows:t!.rows.map(row=>[row.file,row.sheet,row.row,...schemas[role as Role].map(h=>row.cells[h])])}))];}
export const exportWorkbook=(w:Workspace,r:Result)=>workbookBytes(sheets(w,r));
