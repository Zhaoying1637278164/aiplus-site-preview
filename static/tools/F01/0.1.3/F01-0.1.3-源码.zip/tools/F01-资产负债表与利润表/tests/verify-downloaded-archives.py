from pathlib import Path
import json,zipfile,hashlib
b=Path.cwd()/'progress/evidence/F01/0.1.3';out=b/'archive-browser';record={}
for name,meta in json.loads((b/'archives.json').read_text()).items():
 file=out/name;assert file.stat().st_size==meta['bytes'];assert hashlib.sha256(file.read_bytes()).hexdigest()==meta['sha256']
 with zipfile.ZipFile(file) as z:
  assert z.testzip() is None
  members={i.filename:dict(bytes=i.file_size,crc=i.CRC,sha256=hashlib.sha256(z.read(i)).hexdigest()) for i in z.infolist()}
 expected=json.loads((b/('source-files.json' if '源码' in name else 'candidate/build-manifest.json')).read_text())['source_files' if '源码' in name else 'files']
 assert all(members[k]['sha256']==v for k,v in expected.items())
 record[name]=dict(status='passed',members=members)
(out/'all-members.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));print({k:len(v['members']) for k,v in record.items()})
