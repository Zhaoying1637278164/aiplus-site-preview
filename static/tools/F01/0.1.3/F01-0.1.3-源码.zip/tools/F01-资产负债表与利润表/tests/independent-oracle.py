"""Independent Python Decimal oracle. Inputs are fictitious; never imports the TS engine.
Template CSV is an input specification, not program-calculated expected output.
"""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import json,csv,io
T=Path(__file__).resolve().parents[1]; OUT=T/'tests/fixtures'; OUT.mkdir(exist_ok=True)
D=Decimal
schemas={'balances':['主体','期间','币种','单位','科目编码','科目名称','明细键','资料性质','借方','贷方'],'items':['项目ID','报表','项目名称','分组','类型','合计组成','确认零'],'mappings':['映射ID','报表','科目编码','明细键','项目ID','方向','系数','依据'],'adjustments':['调整ID','调整组','报表','期间','项目ID','金额','依据']}
# Explicit independent business fixture specification: code,item,direction,factor,current,prior.
bs=[('1001','CA1','借-贷',1,990,790),('1122','CA5','借-贷',1,300,200),('1231','CA5','贷-借',-1,20,10),('1601','NA8','借-贷',1,500,400),('1602','NA8','贷-借',-1,100,80),('2202','CL5','贷-借',1,200,150),('4001','EQ1','贷-借',1,1000,1000),('4104','EQ8','贷-借',1,480,160),('4201','EQ4','借-贷',1,10,10)]
pl=[('6001','P1','贷-借',1,1000,800),('6401','P2','借-贷',1,600,500),('6602','P5','借-贷',1,100,80),('6117','P8','贷-借',1,30,20),('6701','P12','贷-借',1,-20,-10),('6801','P17','借-贷',1,50,40)]
raw=[]; maps=[]
for statement,specs,count in [('BS',bs,30),('PL',pl,10)]:
 for group in range(1,count+1):
  for code,item,direction,factor,now,prior in specs:
   detail=f'虚构批次{group:02d}'; rule=f'{statement}-{code}-{group}';maps.append([rule,statement,code,detail,item,direction,str(factor),'完全虚构独立分类依据'])
   for year,value in [(2025,now),(2024,prior)]:
    for month in ([12] if statement=='BS' else [10,11,12]):
     v=D(value)*D(group)/100; net=v if direction=='借-贷' else -v
     debit=max(net,D(0));credit=max(-net,D(0))
     raw.append(['虚构矩阵公司',f'{year}-{month:02d}','CNY','元',code,'虚构科目'+code,detail,'期末余额' if statement=='BS' else '损益发生额',format(debit,'f'),format(credit,'f')])
assert len(raw)==900
# Copy only the input template. No expected amounts read from TS/results.
reference=T/'tests/fixtures/reference-items.csv'
itemrows=list(csv.reader(io.StringIO(reference.read_text(encoding='utf-8-sig'))))[1:]
for row in itemrows:row[-1]='是'
def table(role,rows):
 file='完整虚构资料.xlsx';sheet=role
 return dict(file=file,sheet=sheet,headers=schemas[role],rows=[dict(file=file,sheet=sheet,row=i+3,cells=dict(zip(schemas[role],row))) for i,row in enumerate(rows)])
options=dict(entity='虚构矩阵公司',currency='CNY',unit='元',bsPeriod='2025-12',bsCompare='2024-12',plStart='2025-10',plEnd='2025-12',priorStart='2024-10',priorEnd='2024-12',display=2,tolerance='0.01',company='非上市',early=False,confirmed=True,templateVersion='财会2019-6附件2底稿')
w=dict(tables={k:table(k,rows) for k,rows in [('balances',raw),('items',itemrows),('mappings',maps),('adjustments',[])]},options=options)
def num(n):return format(n,'f').rstrip('0').rstrip('.') if '.' in format(n,'f') else format(n,'f')
values={}; traces=[]; groups={}
lookup={(m[1],m[2],m[3]):m for m in maps}
for source in w['tables']['balances']['rows']:
 c=source['cells']; st='BS' if c['资料性质']=='期末余额' else 'PL';m=lookup[(st,c['科目编码'],c['明细键'])];col='本期' if c['期间'].startswith('2025') else '比较';debit=D(c['借方']);credit=D(c['贷方']);value=(debit-credit)*(1 if m[5]=='借-贷' else -1)*int(m[6]);key=(m[4],col);values[key]=values.get(key,D(0))+value
 traces.append([st,col,c['期间'],m[4],c['科目编码'],c['明细键'],m[5],m[6],num(debit),num(credit),num(value),'账面',m[0],m[7],source['file'],source['sheet'],source['row']])
 gkey=json.dumps([c[h] for h in ['主体','期间','币种','单位','资料性质']],ensure_ascii=False,separators=(',',':'));g=groups.setdefault(gkey,[0,D(0),D(0)]);g[0]+=1;g[1]+=debit;g[2]+=credit
spec={row[0]:row for row in itemrows}
def value(id,col):
 row=spec[id]
 if row[4]!='合计':return values.get((id,col),D(0))
 return sum((value(term.split('*')[0],col)*int(term.split('*')[1]) for term in row[5].split(';')),D(0))
reportheaders=['项目ID','项目','分组','类型','本期账面','本期调整','本期精确金额','比较账面','比较调整','比较精确金额','本期显示','比较显示','输入单位','状态']
reports={st:[] for st in ['BS','PL']};lines={}
for row in itemrows:
 a=value(row[0],'本期');b=value(row[0],'比较');lines[row[0]]=[num(a),num(b)];reports[row[1]].append([row[0],row[2],row[3],row[4],num(a),'0',num(a),num(b),'0',num(b),format(a.quantize(D('.01'),rounding=ROUND_HALF_UP),'.2f'),format(b.quantize(D('.01'),rounding=ROUND_HALF_UP),'.2f'),'元','编制检查通过'])
assert lines['ASSETS']==['7765.5','6045'];assert lines['LE']==lines['ASSETS'];assert lines['NET']==['429','313.5']
sheets=[dict(name='资料覆盖',headers=['主体/期间/币种/单位/性质','输入行','有效行','隔离行','未处理/无效金额计数','可读借方','可读贷方','有效借方','有效贷方','隔离借方','隔离贷方','借方未解释','贷方未解释'],rows=[[k,g[0],g[0],0,0,num(g[1]),num(g[2]),num(g[1]),num(g[2]),'0','0','0','0'] for k,g in groups.items()]),dict(name='编制参数',headers=['参数','值'],rows=[['应用版本','0.1.3'],['规则版本','F01-CN-20261004.1']]+list(map(list,options.items()))+[['完整性','通过']])]
for st,name in [('BS','资产负债表'),('PL','利润表')]:sheets.append(dict(name=name,headers=reportheaders,rows=reports[st]))
sheets += [dict(name='来源追溯',headers=['报表','列','期间','项目','科目','明细','方向','系数','原借','原贷','精确金额','类型','规则ID','依据','文件','页签','原行'],rows=traces),dict(name='未映射与隔离',headers=['报表','期间','借方','贷方','借贷净额','借贷绝对金额','原因','文件','页签','行','原始值'],rows=[]),dict(name='异常',headers=['等级','代码','原因','资料','文件','页签','行','原始值'],rows=[]),dict(name='勾稽',headers=['检查','期间','精确差额','状态'],rows=[['资产=负债+权益','2025-12','0','通过'],['资产=负债+权益','2024-12','0','通过'],['未映射及隔离行数','两表','0','通过']])]
for role,t in w['tables'].items():sheets.append(dict(name='原始_'+role,headers=['源文件','源页签','源行']+schemas[role],rows=[[r['file'],r['sheet'],r['row']]+[r['cells'][h] for h in schemas[role]] for r in t['rows']]))
(OUT/'matrix-input.json').write_text(json.dumps(w,ensure_ascii=False,indent=2));(OUT/'matrix-expected.json').write_text(json.dumps(dict(algorithm='Independent Python Decimal, explicit 900-row specification; no TS engine imports',raw_records=900,lines=lines,sheets=sheets),ensure_ascii=False,indent=2));print(json.dumps(dict(raw_records=len(raw),mappings=len(maps),lines=lines['ASSETS'],profit=lines['NET'])))
