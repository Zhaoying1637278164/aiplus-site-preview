"""F01 candidate-only source/offline packaging. Never touches formal release or catalogue."""
from pathlib import Path
import json,hashlib,zipfile,shutil,tempfile,subprocess,os
root=Path.cwd();reference_base=root/'progress/evidence/F01';base=reference_base/'0.1.3';tool=Path('tools/F01-资产负债表与利润表');candidate=base/'candidate';snapshot=base/'source-snapshot';shutil.rmtree(snapshot,ignore_errors=True);snapshot.mkdir()
for folder in [Path('packages'),tool]:shutil.copytree(root/folder,snapshot/folder)
(snapshot/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',snapshot/'references/saxes-5.0.1-LICENSE')
shutil.copytree(reference_base/'references',snapshot/'progress/evidence/F01/references')
for name in ['package-lock.json','tsconfig.json']:shutil.copy2(root/name,snapshot/name)
p=json.loads((root/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/F01-资产负债表与利润表/tests/engine.test.ts','typecheck':'tsc --noEmit','build':'node --import tsx tools/F01-资产负债表与利润表/tests/build-candidate.ts'};(snapshot/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(snapshot/'tsconfig.json').write_text(json.dumps({**json.loads((snapshot/'tsconfig.json').read_text()),'include':['packages','tools']},indent=2))
(snapshot/'README.md').write_text('''# F01 源码重建\n\n仅包含本款与共享工程，无其他业务工具、数据或凭据。Node.js 22+：\n\n```sh\nnpm ci\nnpm test\nnpm run typecheck\nnpm run build\n```\n\n构建在 progress/evidence/F01/candidate 生成index.html、runtime.json及虚构资产。正式release与官网由集成负责人另行验收，本包不是accepted声明。\n\n浏览器验收可运行本款tests/browser.ts；通过F01_CHROMIUM环境变量提供本机Chromium路径。依赖安装需要可用网络或npm缓存，构建后的HTML无需网络。\n\n默认静态样例由ExcelJS生成后固定字节，避免ZIP时间戳漂移；源码含同一虚构XLSX与静态base64模块。共享IO对用户导出仍每次生成新的工作簿，不对用户工作伪造日期。\n''')
shutil.copy2(candidate/'THIRD_PARTY_NOTICES.md',snapshot/'THIRD_PARTY_NOTICES.md')
# No circular final handoff SHA inside the source archive. Those records remain evidence-side.
for f in ['实现交接.md','任务与接续.md','验收证据.md']:(snapshot/tool/f).unlink(missing_ok=True)
files={str(f.relative_to(snapshot)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(snapshot.rglob('*')) if f.is_file()}
manifest={'schema_version':1,'tool':'F01','version':'0.1.3','git_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':files,'source_sha256':hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
(base/'source-files.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
def pack(dest,folder):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(folder.rglob('*')):
   if not f.is_file():continue
   rel=str(f.relative_to(folder));assert not any(part in ['node_modules','.git','.env'] for part in Path(rel).parts)
   info=zipfile.ZipInfo(rel,(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,f.read_bytes())
pack(base/'F01-0.1.3-候选源码.zip',snapshot);pack(base/'F01-0.1.3-候选离线包.zip',candidate)
record={};
for name in ['F01-0.1.3-候选源码.zip','F01-0.1.3-候选离线包.zip']:
 f=base/name;record[name]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(base/'archives.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));print(json.dumps(record,ensure_ascii=False))
# Real source ZIP extraction; commands run in an isolated fresh directory.
temp=Path(tempfile.mkdtemp(prefix='F01-source-rebuild-',dir='/private/tmp'))
with zipfile.ZipFile(base/'F01-0.1.3-候选源码.zip') as z:z.extractall(temp)
results=[]
for i,args in enumerate([['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]):
 run=subprocess.run(args,cwd=temp,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);log=base/f'source-rebuild-{i+1}.log';log.write_text(run.stdout);results.append({'command':args,'exit_code':run.returncode,'log':str(log.relative_to(root))})
 if run.returncode:break
rebuilt=temp/'progress/evidence/F01/candidate';expected=json.loads((candidate/'build-manifest.json').read_text())['files'];expected['build-manifest.json']=hashlib.sha256((candidate/'build-manifest.json').read_bytes()).hexdigest();comparison={name:hashlib.sha256((rebuilt/name).read_bytes()).hexdigest()==sha for name,sha in expected.items()} if rebuilt.exists() else {}
r={'schema_version':1,'extracted_dir':str(temp),'commands':results,'files_equal':comparison,'status':'passed' if len(results)==4 and all(x['exit_code']==0 for x in results) and len(comparison)==len(expected) and all(comparison.values()) else 'failed'};(base/'source-rebuild.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False));raise SystemExit(0 if r['status']=='passed' else 1)
