from pathlib import Path
import csv,json
from decimal import Decimal, getcontext
getcontext().prec=60
root=Path.cwd();source=root/'progress/evidence/E05/candidate/0.2.1/虚构费用.csv'
rows=list(csv.DictReader(source.open(encoding='utf-8-sig')));chosen=[r for r in rows if r['币种']=='CNY' and r['单位']=='元'];dm={'S':'销售部','A':'管理部'};am={'TR':'差旅费','RE':'租金','OF':'办公费'}
def group(key):
 out={}
 for r in chosen:
  k=r[key] or '未提供';k=dm.get(k,k) if key=='部门' else am.get(k,k) if key=='科目' else k
  out[k]=out.get(k,Decimal(0))+Decimal(r['金额'])
 return {k:str(v) for k,v in out.items()}
total=sum((Decimal(r['金额']) for r in chosen),Decimal(0));monthly=group('期间');a=Decimal(monthly['2026-02']);b=Decimal(monthly['2026-01'])
expected={'total':str(total),'monthly':monthly,'department':group('部门'),'account':group('科目'),'classification':group('固定变动'),'supplier':group('供应商'),'project':group('项目'),'selected_ids':[r['记录ID'] for r in chosen],'delta':str(a-b),'growth_6':str(((a-b)/b*100).quantize(Decimal('.000001'))),'USD':str(sum((Decimal(r['金额']) for r in rows if r['币种']=='USD'),Decimal(0))),'method':'Python Decimal from fictitious CSV; no engine imports'}
assert total==Decimal('1180.123456');assert monthly=={'2026-01':'280','2026-02':'400.123456','2026-03':'500'};assert expected['department']=={'销售部':'530','管理部':'650.123456'}
(root/'tools/E05-费用分析看板/examples/独立预期.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2));(root/'progress/evidence/E05/independent-oracle.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2));print('independent Decimal expected generated',len(chosen),'rows',total)
