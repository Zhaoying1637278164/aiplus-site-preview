"""Independent full JSON and all exported cells checker; never calls app modules."""
from pathlib import Path
import json,sys,csv,zipfile,xml.etree.ElementTree as ET,hashlib
import importlib.util
spec=importlib.util.spec_from_file_location('bulk_oracle',Path(__file__).with_name('bulk-oracle.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);oracle=module.oracle;expected_sheets=module.expected_sheets;J=module.J
root=Path.cwd();directory=Path(sys.argv[1]);case=sys.argv[2];expected=json.loads((root/'progress/evidence/E05/0.2.1/bulk/expected.json').read_text())[case];work=expected['work'];result=expected['result'];count=0
# Ratios use independent Decimal 40 precision; array ordering of group ties is presentation-only.
def canonical(r):
 r=json.loads(J(r))
 for d in r['groups']:r['groups'][d].sort(key=lambda g:g['name'])
 r['changes'].sort(key=lambda g:g['name']);return r
def equal(a,b,path='$'):
 global count
 count+=1
 if isinstance(b,dict):
  assert isinstance(a,dict) and a.keys()==b.keys(),(path,'keys',set(a)^set(b))
  for k in b:equal(a[k],b[k],path+'.'+k)
 elif isinstance(b,list):
  assert isinstance(a,list) and len(a)==len(b),(path,'length',len(a),len(b))
  for i,(x,y) in enumerate(zip(a,b)):equal(x,y,path+'['+str(i)+']')
 else:assert type(a)==type(b) and a==b,(path,a,b)
proof=json.loads((directory/'proof.json').read_text());equal(proof,{'schema_version':1,'tool':'E05','app_version':'0.2.1','rule_version':'E05-2026-10-04.2','contains_data':True,'parameters':work['config'],'result':proof['result'],'reviews':work['reviews']});equal(canonical(proof['result']),canonical(result),'$.complete_result')
for name,data in [('work.json',True),('plan.json',False)]:
 p=json.loads((directory/name).read_text());want={'schema_version':1,'tool':'E05','app_version':'0.2.1','rule_version':'E05-2026-10-04.2','contains_data':data,'config':work['config']}
 if data:want.update({k:work[k] for k in ['expenses','departments','accounts','reviews']})
 equal(p,want,name)
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
sheets=expected_sheets(work,result)
def value(v):return '' if v is None else 'true' if v is True else 'false' if v is False else str(v)
zipdetails=[];actual=[]
with zipfile.ZipFile(directory/'result.xlsx') as z:
 assert z.testzip() is None
 shared=ET.fromstring(z.read('xl/sharedStrings.xml'));strings=[''.join(x.itertext()) for x in shared]
 wb=ET.fromstring(z.read('xl/workbook.xml'));names=[e.attrib['name'] for e in wb.find('m:sheets',ns)];assert names==[s['name'] for s in sheets]
 for n,s in enumerate(sheets,1):
  xml=ET.fromstring(z.read('xl/worksheets/sheet'+str(n)+'.xml'));rows=[]
  for row in xml.findall('m:sheetData/m:row',ns):
   cells={}
   for c in row:
    assert c.find('m:f',ns) is None,('formula exported',s['name'])
    ref=c.attrib['r'];col=0
    for ch in ''.join(x for x in ref if x.isalpha()):col=col*26+ord(ch)-64
    v=c.find('m:v',ns);cells[col-1]=strings[int(v.text)] if c.attrib.get('t')=='s' and v is not None else v.text if v is not None else ''
   rows.append([cells.get(i,'') for i in range(len(s['headers']))])
  want=[s['headers']]+[[value(v) for v in row] for row in s['rows']]
  if s['name'].endswith('结构') or s['name']=='结构变化':rows=[rows[0]]+sorted(rows[1:],key=lambda x:x[0]);want=[want[0]]+sorted(want[1:],key=lambda x:x[0])
  equal(rows,want,'xlsx.'+s['name']);actual.append({'name':s['name'],'rows':len(rows)-1,'columns':len(s['headers']),'checked_cells':len(rows)*len(s['headers'])})
 core=z.read('docProps/core.xml').decode();assert '2000-01-01T00:00:00Z' in core or '2000-01-01T00:00:00.000Z' in core
 for item in z.infolist():zipdetails.append({'name':item.filename,'crc':item.CRC,'bytes':item.file_size,'date_time':item.date_time,'sha256':hashlib.sha256(z.read(item.filename)).hexdigest()});assert item.date_time==(2000,1,1,0,0,0),item.filename
with (directory/'detail.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.reader(f))
s=next(s for s in sheets if s['name']=='所选明细');equal(rows,[s['headers']]+[[value(v) for v in row] for row in s['rows']],'csv.all_cells')
report={'status':'passed','case':case,'full_object_fields_cells_checked':count,'xlsx_sheets':actual,'xlsx_all_members':zipdetails,'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in directory.iterdir() if p.is_file() and p.name!='verification.json'},'ordering_policy':'group/changes order canonical by dimension name only; all data, keys, provenance and ratios exact; no tolerance or ignored dates'};(directory/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('full independent verification',case,count,'fields/cells',sum(x['checked_cells'] for x in actual),'xlsx cells')
