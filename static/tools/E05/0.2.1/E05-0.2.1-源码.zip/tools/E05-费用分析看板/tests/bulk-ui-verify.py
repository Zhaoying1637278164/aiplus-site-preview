from pathlib import Path
from decimal import Decimal,ROUND_HALF_UP
import json,sys,importlib.util
spec=importlib.util.spec_from_file_location('bulk_oracle',Path(__file__).with_name('bulk-oracle.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
root=Path.cwd();cases=json.loads((root/'progress/evidence/E05/0.2.1/bulk/expected.json').read_text());w=cases['base']['work'];r=cases['base']['result'];audits=json.loads(Path(sys.argv[1]).read_text());want={}
v=lambda x:'—' if x is None else str(x)
display=lambda x:'无资料 / 不可比' if x is None else format(Decimal(x).quantize(Decimal('.000001'),rounding=ROUND_HALF_UP),'f')
pct=lambda x:'不可比' if x is None else format(Decimal(x).quantize(Decimal('.01'),rounding=ROUND_HALF_UP),'f')+'%'
def add(title,name,rows,sort=False):want[(title,name)]=(rows,sort)
for k,n in [('expenses','费用原始预览'),('departments','部门映射预览'),('accounts','科目映射预览')]:
 t=w[k];add('费用资料',n,[[str(x['row'])]+[v(x['cells'][h]) for h in t['headers']] for x in t['rows']])
for k,n in [('departments','有效期部门规则'),('accounts','有效期科目规则')]:
 t=w[k];add('映射与口径',n,[[str(x['row'])]+[v(x['cells'][h]) for h in t['headers']] for x in t['rows']])
add('期间总览','范围勾稽',[[m.NAMES[d],'可用',r['residuals'][d]] for d in m.DIMS])
coverage=[]
for x in r['valid']:
 t=(x['currency'],x['unit'])
 if t in [tuple(a[:2]) for a in coverage]:continue
 coverage.append([*t,str(sum(1 for rr in r['valid'] if (rr['currency'],rr['unit'])==t)),'按期间和维度筛选' if t==('CNY','元') else '独立未选，不换汇'])
add('期间总览','币种单位覆盖',coverage)
for title,d in [('部门与科目','department'),('固定与变动','classification'),('供应商与维度','supplier')]:
 add(title,m.NAMES[d]+'结构',[[g['name'],display(g['amount']),'不可解释' if g['share'] is None else pct(g['share']),str(g['count']),str(len(g['keys']))+'行，可下钻'] for g in r['groups'][d]],True)
changes=[[g['name'],display(g['current']),display(g['previous']),display(g['delta']),pct(g['growth'])] for g in r['changes']]
add('部门与科目','结构期间变化',changes,True);add('期间趋势','结构期间变化',changes,True)
add('期间趋势','逐月趋势',[[t['period'],display(t['amount']),str(t['count']),'无资料' if t['amount'] is None else '有记录'] for t in r['trend']])
t=w['accounts'];add('固定与变动','科目分类依据',[[str(x['row'])]+[v(x['cells'][h]) for h in t['headers']] for x in t['rows']])
add('供应商与维度','维度覆盖',[[m.NAMES[d],'可用（缺失单列）',str(sum(1 for x in r['selected'] if x[d]=='未提供')),v(next((g['amount'] for g in r['groups'][d] if g['name']=='未提供'),None))] for d in ['supplier','project']])
add('异常复核','异常待办',[[i['severity'],i['message'],f"{i['source']['file']} / {i['source']['sheet']} / {i['source']['row']}",'待复核','复核原行'] for i in r['issues']])
add('明细与来源','费用明细',[[x['id'],x['period'],x['department'],x['account'],display(x['amount']),x['classification'],x['supplier'],f"{x['source']['file']} / {x['source']['sheet']} / {x['source']['row']}",'查看原行'] for x in r['selected']])
add('底稿与恢复','导出范围',[['精确净额（元）',r['total']],['所选费用行',str(len(r['selected']))],['无效排除行',str(r['excluded'])],['可用维度勾稽差额（元）','；'.join(m.NAMES[d]+'：'+r['residuals'][d] for d in m.DIMS)]])
assert len(audits)==len(want),(len(audits),len(want));cells=0
for audit in audits:
 rows,sort=want[(audit['title'],audit['name'])];actual=audit['all_cells']
 if sort:actual=sorted(actual,key=lambda x:x[0]);rows=sorted(rows,key=lambda x:x[0])
 assert actual==rows,(audit['title'],audit['name'],next(((i,a,b) for i,(a,b) in enumerate(zip(actual,rows)) if a!=b),('count',len(actual),len(rows))))
 cells+=sum(len(x) for x in rows)
Path(sys.argv[1]).with_name('ui-independent-verification.json').write_text(json.dumps({'status':'passed','grids':len(audits),'all_pages':sum(x['pages'] for x in audits),'all_cells':cells,'method':'Independent Python fictitious source + Decimal expectation versus actual DOM every column and page, no engine/exporter imports'},indent=2));print('full UI expected cells',cells,'grids',len(audits))
