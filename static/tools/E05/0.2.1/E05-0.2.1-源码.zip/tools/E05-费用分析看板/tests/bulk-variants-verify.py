from pathlib import Path
from decimal import Decimal,ROUND_HALF_UP
import json,sys,importlib.util
spec=importlib.util.spec_from_file_location('bulk_oracle',Path(__file__).with_name('bulk-oracle.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
w=json.loads((Path.cwd()/'progress/evidence/E05/0.2.1/bulk/expected.json').read_text())['base']['work'];audits=json.loads(Path(sys.argv[1]).read_text());cells=0
fmt=lambda x:'无资料 / 不可比' if x is None else format(Decimal(x).quantize(Decimal('.000001')),'f')
pct=lambda x:'不可比' if x is None else format(Decimal(x).quantize(Decimal('.01'),rounding=ROUND_HALF_UP),'f')+'%'
for a in audits:
 w['config']['structure']=a['dimension'];r=m.oracle(w)
 if a['name']=='结构期间变化':want=[[x['name'],fmt(x['current']),fmt(x['previous']),fmt(x['delta']),pct(x['growth'])] for x in r['changes']]
 else:want=[[x['name'],fmt(x['amount']),pct(x['share']),str(x['count']),str(len(x['keys']))+'行，可下钻'] for x in r['groups'][a['dimension']]]
 assert sorted(a['rows'],key=lambda x:x[0])==sorted(want,key=lambda x:x[0]),a['name'];cells+=sum(len(x) for x in want)
Path(sys.argv[1]).with_name('verification.json').write_text(json.dumps({'status':'passed','tables':len(audits),'all_pages':sum(a['pages'] for a in audits),'all_cells':cells},indent=2));print('variant full independent DOM cells',cells)
