from pathlib import Path
import subprocess,json,sys,time
out=Path(sys.argv[1]);out.parent.mkdir(parents=True,exist_ok=True);cmd=sys.argv[2:];start=time.time();p=subprocess.run(cmd,capture_output=True,text=True);out.write_text(json.dumps({'command':cmd,'cwd':str(Path.cwd()),'exit_code':p.returncode,'seconds':round(time.time()-start,3),'stdout':p.stdout,'stderr':p.stderr},ensure_ascii=False,indent=2));print(p.stdout);print(p.stderr,file=sys.stderr);sys.exit(p.returncode)
