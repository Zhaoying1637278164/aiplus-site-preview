"""Independent Python Decimal oracle. Reads only fictitious CSV and explicit config.
No TypeScript engine/exporter imports, no expected copied from produced output.
"""
from pathlib import Path
from decimal import Decimal, getcontext, ROUND_HALF_UP
from collections import Counter,defaultdict
import csv,json,sys,re
getcontext().prec=40;getcontext().rounding=ROUND_HALF_UP
ROOT=Path.cwd();OUT=ROOT/'progress/evidence/E05/0.2.1/bulk';OUT.mkdir(parents=True,exist_ok=True)
J=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'))
FIELDS=dict(zip(['id','period','entity','department','account','currency','unit','amount','basis','gross','net','supplier','project','classification'],['记录ID','期间','主体','部门','科目','币种','单位','金额','金额口径','含税金额','不含税金额','供应商','项目','固定变动']))
DIMS=['department','account','classification','supplier','project','entity'];NAMES=dict(zip(DIMS,['部门','科目','固定变动','供应商','项目','主体']))
F={'元':Decimal(1),'千元':Decimal(1000),'万元':Decimal(10000)}
def fixed(x):
 s=format(x,'f');return (s.rstrip('0').rstrip('.') if '.' in s else s) if x else '0'
def write_csv(name,heads,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(heads);w.writerows(rows)
def read_table(name):
 with (OUT/name).open(encoding='utf-8-sig',newline='') as f:
  reader=csv.reader(f);heads=next(reader);rows=[]
  for line,v in enumerate(reader,2):rows.append({'file':name,'sheet':'CSV','row':line,'cells':dict(zip(heads,[x if x!='' else None for x in v]))})
 return {'file':name,'sheet':'CSV','headers':heads,'rows':rows}
def generate():
 rows=[]
 for i in range(620):
  amount=fixed(Decimal(i+1)/100+Decimal('0.000001')*(i%7));period='2026-'+str(i%12+1).zfill(2)
  row=[f'FAKE-{i:04}',period,f'虚构主体{i%3}',f'D{i%65:02}',f'A{i%65:02}','CNY','元',amount,'账面费用',fixed(Decimal(amount)*Decimal('1.06')),amount,f'虚构供应商{i%65:02}' if i%7 else '',f'虚构项目{i%65:02}' if i%11 else '',['固定','变动','混合','未分类'][i%4]]
  if i%19==0:row[7]='0';row[9]='0';row[10]='0'
  elif i%17==0:row[7]='-'+amount;row[9]=fixed(-Decimal(amount)*Decimal('1.06'));row[10]='-'+amount
  if i in [600,601]:row[0]='FAKE-DUP'
  if i==602:row[7]=''
  if i==603:row[1]='2026-13'
  if i==604:row[5]='USD'
  if i==605:row[6]='千元'
  if i==606:row[6]='万元'
  if i==607:row[1]='2025-12'
  if i==608:row[4]='MISSING'
  if i==609:row[3]='MISSING'
  if i==610:row[8]='未知'
  if i==611:row[7]='0.1234567'
  if i==612:row[5]='cny'
  if i==613:row[6]='件'
  if i==614:row[2]=''
  if i==615:row[3]=''
  if i==616:row[4]=''
  if i==617:row[7]='=1+1'
  if i==618:row[1]='2200-01'
  if i==619:row[7]='619.123456';row[9]='656.270863';row[10]='619.123456'
  rows.append(row)
 write_csv('bulk-expenses.csv',list(FIELDS.values()),rows)
 write_csv('bulk-departments.csv',['原部门','目标部门','开始期间','结束期间'],[[f'D{i:02}',f'虚构部门{i:02}','2025-01','2027-12'] for i in range(65)])
 write_csv('bulk-accounts.csv',['原科目','目标科目','固定变动','开始期间','结束期间','依据'],[[f'A{i:02}',f'虚构科目{i:02}',['固定','变动','混合','未分类'][i%4],'2025-01','2027-12',f'虚构分类依据{i:02}'] for i in range(65)])
 corrected=[r[:] for r in rows];corrected[619][7]='719.123456';write_csv('bulk-corrected.csv',list(FIELDS.values()),corrected)
 write_csv('bulk-no-supplier.csv',[h for h in FIELDS.values() if h!='供应商'],[[x for i,x in enumerate(r) if i!=11] for r in rows])
 write_csv('bulk-overlap.csv',['原部门','目标部门','开始期间','结束期间'],[[f'D{i:02}',f'虚构部门{i:02}','2025-01','2027-12'] for i in range(65)]+[['D00','虚构冲突','2025-01','2027-12']])
def config():return {'fields':dict(FIELDS),'basis':'账面费用','measure':'amount','confirmed':True,'from':'2026-01','to':'2026-12','current':'2026-02','previous':'2026-01','currency':'CNY','unit':'元','displayUnit':'元','precision':6,'threshold':'1','growthThreshold':'30','filters':dict.fromkeys(DIMS,''),'structure':'department'}
def key(r):return J([r['file'],r['sheet'],r['row']])
def required(v):
 if v is None or isinstance(v,dict):raise ValueError('缺失值或公式单元格，须提供静态值')
 s=str(v).strip()
 if not s:raise ValueError('必填值为空')
 return s
def per(v):
 s=required(v)
 if not re.fullmatch(r'(19|20|21)\d{2}-(0[1-9]|1[0-2])',s):raise ValueError('期间须为1900—2199的YYYY-MM')
 return s
def numeric(v):
 s=required(v)
 if not re.fullmatch(r'[+-]?\d+(?:\.\d{1,6})?',s):raise ValueError('金额须为十进制数字（最多6位小数，不含千分位/括号）')
 return Decimal(s)
def mapped(t,raw,p,kind):
 if t is None:return raw,None,[]
 matches=[r for r in t['rows'] if r['cells']['原'+kind]==raw and r['cells']['开始期间']<=p<=r['cells']['结束期间']]
 if len(matches)!=1:raise ValueError(kind+'映射有效项'+str(len(matches))+'个，须唯一')
 r=matches[0];return r['cells']['目标'+kind],r['cells'].get('固定变动'),[r]
def total(rs):return fixed(sum((Decimal(r['amount']) for r in rs),Decimal(0)))
def compare(a,b):
 x=total(a) if a else None;y=total(b) if b else None;delta=Decimal(x)-Decimal(y) if x is not None and y is not None else None
 return {'current':x,'previous':y,'delta':fixed(delta) if delta is not None else None,'growth':fixed(delta/Decimal(y)*100) if delta is not None and Decimal(y)>0 else None}
def oracle(w):
 c=w['config'];t=w['expenses'];issues=[];valid=[];counts=Counter(r['cells'].get(c['fields']['id']) for r in t['rows'])
 for row in t['rows']:
  k=key(row);cells=row['cells'];v=lambda f:cells.get(c['fields'][f]);issue=lambda msg,sev='复核':issues.append({'key':k,'severity':sev,'message':msg,'source':row})
  try:
   if not c['confirmed']:raise ValueError('金额口径尚未确认')
   rid=required(v('id'))
   if counts[rid]!=1:raise ValueError('记录ID重复，整组排除')
   p=per(v('period'));cc=required(v('currency'));u=required(v('unit'))
   if not re.fullmatch('[A-Z]{3}',cc) or u not in F:raise ValueError('币种须三位大写，单位须元/千元/万元')
   if c['measure']=='amount' and required(v('basis'))!=c['basis']:raise ValueError('行金额口径与所选口径不同')
   amt=numeric(v(c['measure']))*F[u]
   dep,_,ds=mapped(w['departments'],required(v('department')),p,'部门');acc,cls,acs=mapped(w['accounts'],required(v('account')),p,'科目')
   cls=cls or v('classification') or '未分类'
   r={'key':k,'id':rid,'period':p,'entity':required(v('entity')),'department':dep,'account':acc,'currency':cc,'unit':u,'amount':fixed(amt),'classification':cls,'supplier':v('supplier') or '未提供','project':v('project') or '未提供','source':row,'mappingSources':ds+acs};valid.append(r)
   if amt<0:issue('负费用：确认退款、冲销或调整依据')
   if abs(amt)>=Decimal(c['threshold']):issue('单笔达到关注阈值（原币种元）')
   if cls=='未分类':issue('固定变动未分类，保留总额')
  except ValueError as e:issue(str(e),'阻塞')
 available={d:d not in ['supplier','project'] or c['fields'][d] in t['headers'] and any(r[d]!='未提供' for r in valid) for d in DIMS}
 scoped=[r for r in valid if r['currency']==c['currency'] and r['unit']==c['unit'] and all(not c['filters'][d] or r[d]==c['filters'][d] for d in DIMS)];selected=[r for r in scoped if c['from']<=r['period']<=c['to']];s=total(selected);groups={}
 for d in DIMS:
  buckets=defaultdict(list)
  if available[d]:
   for r in selected:buckets[r[d]].append(r)
  groups[d]=[{'name':n,'amount':total(rs),'share':fixed(Decimal(total(rs))/Decimal(s)*100) if Decimal(s)>0 else None,'count':len(rs),'keys':[r['key'] for r in rs]} for n,rs in buckets.items()]
  groups[d].sort(key=lambda g:(-Decimal(g['amount']),g['name']))
 a=[r for r in scoped if r['period']==c['current']];b=[r for r in scoped if r['period']==c['previous']];d=c['structure'];names=sorted(set(r[d] for r in a+b));changes=[dict(name=n,**compare([r for r in a if r[d]==n],[r for r in b if r[d]==n])) for n in names] if available[d] else []
 trend=[];y,m=map(int,c['from'].split('-'))
 while (p:=f'{y}-{m:02}')<=c['to']:
  rs=[r for r in scoped if r['period']==p];trend.append({'period':p,'amount':total(rs) if rs else None,'count':len(rs)});y,m=(y+1,1) if m==12 else (y,m+1)
 return {'valid':valid,'selected':selected,'issues':issues,'total':s,'groups':groups,'available':available,'comparison':compare(a,b),'changes':changes,'trend':trend,'excluded':len(t['rows'])-len(valid),'unselected':len(valid)-len(selected),'residuals':{d:'0' if available[d] else None for d in DIMS}}
def expected_sheets(w,r):
 c=w['config'];disp=lambda v:format((Decimal(v)/F[c['displayUnit']]).quantize(Decimal(1).scaleb(-c['precision'])),'f') if v is not None else '无资料 / 不可比'
 sheets=[]
 def add(n,h,rs):sheets.append({'name':n,'headers':h,'rows':rs})
 add('口径与参数',['参数','值'],[['应用版本','0.2.1'],['规则版本','E05-2026-10-04.2']]+[[k,J(v) if isinstance(v,dict) else v] for k,v in c.items()]+[['输入行',len(w['expenses']['rows'])],['无效排除',r['excluded']],['有效未选',r['unselected']],['所选行',len(r['selected'])],['精确净额元',r['total']]])
 add('勾稽',['维度','差额元','可用'],[[NAMES[d],r['residuals'][d],r['available'][d]] for d in DIMS]);co=r['comparison']
 add('期间对比',['本期','比较期','本期元','比较期元','差额元','增幅百分比'],[[c['current'],c['previous']]+[co[k] for k in ['current','previous','delta','growth']]])
 add('期间趋势',['期间','精确元','笔数'],[[t['period'],t['amount'],t['count']] for t in r['trend']])
 for d in DIMS:add(NAMES[d]+'结构',['名称','精确元','显示'+c['displayUnit'],'净额占比百分比','笔数','来源键'],[[g['name'],g['amount'],disp(g['amount']),g['share'],g['count'],'\n'.join(g['keys'])] for g in r['groups'][d]])
 add('结构变化',['名称','本期元','比较期元','差额元','增幅百分比'],[[g[k] for k in ['name','current','previous','delta','growth']] for g in r['changes']])
 heads=['记录ID','期间','主体','部门','科目','币种','原单位','精确金额元','固定变动','供应商','项目','来源文件','来源页签','来源行','来源键','映射来源']
 detail=[[x[k] for k in ['id','period','entity','department','account','currency','unit','amount','classification','supplier','project']]+[x['source']['file'],x['source']['sheet'],x['source']['row'],x['key'],J(x['mappingSources'])] for x in r['selected']]
 add('所选明细',heads,detail)
 add('异常复核',['级别','问题','来源键','文件','页签','原行','状态','依据'],[[i['severity'],i['message'],i['key'],i['source']['file'],i['source']['sheet'],i['source']['row'],w['reviews'].get(i['key'],{}).get('status','待复核'),w['reviews'].get(i['key'],{}).get('note','')] for i in r['issues']])
 for k,n in zip(['expenses','departments','accounts'],['费用原表','部门原表','科目原表']):
  t=w[k];add(n,['来源文件','来源页签','来源行']+(t['headers'] if t else []),[[rr['file'],rr['sheet'],rr['row']]+[rr['cells'][h] for h in t['headers']] for rr in t['rows']] if t else [])
 return sheets
if __name__=='__main__':
 generate();cases={}
 for name,file in [('base','bulk-expenses.csv'),('corrected','bulk-corrected.csv'),('no-supplier','bulk-no-supplier.csv'),('overlap','bulk-expenses.csv')]:
  w={'expenses':read_table(file),'departments':read_table('bulk-overlap.csv' if name=='overlap' else 'bulk-departments.csv'),'accounts':read_table('bulk-accounts.csv'),'config':config(),'reviews':{}}
  if name=='no-supplier':w['config']['fields']['supplier']=''
  r=oracle(w);cases[name]={'work':w,'result':r,'sheets':expected_sheets(w,r)}
 for name,param in [('USD',{'currency':'USD'}),('thousands',{'unit':'千元'}),('missing-period',{'previous':'2024-01','to':'2027-01'}),('department-filter',{'filters':{**config()['filters'],'department':'虚构部门34'}})]:
  w=json.loads(J(cases['base']['work']));w['config'].update(param);r=oracle(w);cases[name]={'work':w,'result':r,'sheets':expected_sheets(w,r)}
 (OUT/'expected.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2));print('Independent bulk cases',len(cases),'source rows',620,'valid',len(cases['base']['result']['valid']),'selected',len(cases['base']['result']['selected']),'issues',len(cases['base']['result']['issues']))
