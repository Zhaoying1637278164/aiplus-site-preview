from pathlib import Path
import subprocess,json,hashlib,time,sys,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();src=root/'progress/evidence/E05/0.2.1/source';log=root/'progress/evidence/E05/0.2.1/source-rebuild.json';results=[]
for command in [['npm','ci','--ignore-scripts','--no-audit','--no-fund'],['npm','test'],['npm','run','typecheck'],['npm','run','build']]:
 start=time.time();p=subprocess.run(command,cwd=src,capture_output=True,text=True);results.append({'command':command,'cwd':str(src),'exit_code':p.returncode,'seconds':round(time.time()-start,2),'stdout':p.stdout,'stderr':p.stderr});log.write_text(json.dumps({'status':'running' if p.returncode==0 else 'failed','commands':results},ensure_ascii=False,indent=2));print(command,'actual exit',p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
a=root/'progress/evidence/E05/candidate/0.2.1';b=src/'progress/evidence/E05/candidate/0.2.1';comparisons=[]
for p in a.iterdir():
 if not p.is_file():continue
 q=b/p.name
 h=lambda v:hashlib.sha256(v.read_bytes()).hexdigest()
 assert h(p)==h(q),p.name
 members=[]
 if p.suffix=='.xlsx':
  with zipfile.ZipFile(p) as z1,zipfile.ZipFile(q) as z2:
   assert z1.namelist()==z2.namelist()
   for x,y in zip(z1.infolist(),z2.infolist()):
    assert x.date_time==y.date_time and x.CRC==y.CRC and z1.read(x.filename)==z2.read(y.filename)
    members.append({'name':x.filename,'date_time':x.date_time,'crc':x.CRC,'sha256':hashlib.sha256(z1.read(x.filename)).hexdigest()})
 comparisons.append({'file':p.name,'bytes':p.stat().st_size,'sha256':h(p),'byte_identical':True,'members':members})
log.write_text(json.dumps({'status':'passed','commands':results,'comparisons':comparisons,'scope':'isolated candidate source snapshot; final package by root','windows':'unverified'},ensure_ascii=False,indent=2));print('source rebuild passed',len(comparisons),'assets')
