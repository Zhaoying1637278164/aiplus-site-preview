from pathlib import Path
import zipfile,hashlib,json,shutil
root=Path.cwd();base=root/'progress/evidence/E05/candidate/0.2.1';out=root/'progress/evidence/E05';zip_path=out/'E05-0.2.1-候选离线包.zip'
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.iterdir() if p.is_file()}
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for name in sorted(files):z.write(base/name,name)
extract=out/'0.2.1/offline-extracted';extract.mkdir(exist_ok=True)
with zipfile.ZipFile(zip_path) as z:
 assert sorted(z.namelist())==sorted(files)
 for name,sha in files.items():
  assert hashlib.sha256(z.read(name)).hexdigest()==sha
 z.extractall(extract)
for name,sha in files.items():assert hashlib.sha256((extract/name).read_bytes()).hexdigest()==sha
(out/'0.2.1/offline-package.json').write_text(json.dumps({'tool':'E05','version':'0.2.1','status':'candidate','archive':str(zip_path.relative_to(root)),'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'bytes':zip_path.stat().st_size,'members':files,'extract_member_bytes_match':True},ensure_ascii=False,indent=2));print('candidate offline zip',len(files),'members',zip_path.stat().st_size)
