import type {Table} from '../../../packages/core/types';import {initialConfig,type Work,FIELDS} from './types';
export function table(file:string,headers:string[],values:(string|null)[][]):Table{return {file,sheet:'CSV',headers,rows:values.map((v,i)=>({file,sheet:'CSV',row:i+2,cells:Object.fromEntries(headers.map((h,k)=>[h,v[k]??null]))}))}}
export const expenses=table('虚构费用.csv',Object.values(FIELDS),[
 ['E01','2026-01','虚构公司','S','TR','CNY','元','100','账面费用',null,null,'虚构旅行','P1','变动'],
 ['E02','2026-01','虚构公司','S','TR','CNY','元','-20','账面费用',null,null,'虚构旅行','P1','变动'],
 ['E03','2026-01','虚构公司','A','RE','CNY','元','200','账面费用',null,null,'虚构物业',null,'固定'],
 ['E04','2026-01','虚构公司','A','OF','CNY','元','0','账面费用',null,null,null,null,'变动'],
 ['E05','2026-02','虚构公司','S','TR','CNY','元','150','账面费用',null,null,'虚构旅行','P1','变动'],
 ['E06','2026-02','虚构公司','A','RE','CNY','元','200','账面费用',null,null,'虚构物业',null,'固定'],
 ['E07','2026-02','虚构公司','A','OF','CNY','元','50.123456','账面费用',null,null,null,'P2','变动'],
 ['E08','2026-03','虚构公司','S','TR','CNY','元','300','账面费用',null,null,'虚构旅行','P1','变动'],
 ['E09','2026-03','虚构公司','A','RE','CNY','元','200','账面费用',null,null,'虚构物业',null,'固定'],
 ['E10','2026-02','虚构公司','A','OF','USD','元','10','账面费用',null,null,null,null,'变动']]);
export const departments=table('虚构部门映射.csv',['原部门','目标部门','开始期间','结束期间'],[['S','销售部','2026-01','2026-12'],['A','管理部','2026-01','2026-12']]);
export const accounts=table('虚构科目映射.csv',['原科目','目标科目','固定变动','开始期间','结束期间','依据'],[['TR','差旅费','变动','2026-01','2026-12','虚构管理分类按业务活动变动'],['RE','租金','固定','2026-01','2026-12','虚构固定租赁合同'],['OF','办公费','变动','2026-01','2026-12','虚构管理分类按用量']]);
export function example():Work{return {expenses:structuredClone(expenses),departments:structuredClone(departments),accounts:structuredClone(accounts),config:{...initialConfig(),confirmed:true},reviews:{}}}
