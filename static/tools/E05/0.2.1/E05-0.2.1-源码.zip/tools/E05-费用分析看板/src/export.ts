import Papa from 'papaparse';import {workbookBytes} from './workbook';import type {Work,Result} from './types';import {DIMS,DIM_NAMES} from './types';import {VERSION,RULE_VERSION} from './version';import {display} from './engine';
const safe=(v:unknown)=>typeof v==='string'&&/^[\s]*[=+\-@]/.test(v)&&!/^[-+]?\d+(\.\d+)?$/.test(v)?"'"+v:v;
export function csv(t:{headers:string[];rows:unknown[][]}){return '\uFEFF'+Papa.unparse({fields:t.headers,data:t.rows.map(r=>r.map(safe))})}
export function evidence(w:Work,r:Result){return {schema_version:1,tool:'E05',app_version:VERSION,rule_version:RULE_VERSION,contains_data:true,parameters:w.config,result:r,reviews:w.reviews}}
export function sheets(w:Work,r:Result){const c=w.config;return [
 {name:'口径与参数',headers:['参数','值'],rows:[['应用版本',VERSION],['规则版本',RULE_VERSION],...Object.entries(c).map(([k,v])=>[k,typeof v==='object'?JSON.stringify(v):v]),['输入行',w.expenses?.rows.length||0],['无效排除',r.excluded],['有效未选',r.unselected],['所选行',r.selected.length],['精确净额元',r.total]]},
 {name:'勾稽',headers:['维度','差额元','可用'],rows:DIMS.map(d=>[DIM_NAMES[d],r.residuals[d],r.available[d]])},
 {name:'期间对比',headers:['本期','比较期','本期元','比较期元','差额元','增幅百分比'],rows:[[c.current,c.previous,r.comparison.current,r.comparison.previous,r.comparison.delta,r.comparison.growth]]},
 {name:'期间趋势',headers:['期间','精确元','笔数'],rows:r.trend.map(t=>[t.period,t.amount,t.count])},
 ...DIMS.map(d=>({name:DIM_NAMES[d]+'结构',headers:['名称','精确元','显示'+c.displayUnit,'净额占比百分比','笔数','来源键'],rows:r.groups[d].map(g=>[g.name,g.amount,display(g.amount,c),g.share,g.count,g.keys.join('\n')])})),
 {name:'结构变化',headers:['名称','本期元','比较期元','差额元','增幅百分比'],rows:r.changes.map(g=>[g.name,g.current,g.previous,g.delta,g.growth])},
 {name:'所选明细',...detailTable(r)},
 {name:'异常复核',headers:['级别','问题','来源键','文件','页签','原行','状态','依据'],rows:r.issues.map(i=>[i.severity,i.message,i.key,i.source.file,i.source.sheet,i.source.row,w.reviews[i.key]?.status||'待复核',w.reviews[i.key]?.note||''])},
 ...(['expenses','departments','accounts'] as const).map((k,i)=>{const t=w[k];return {name:['费用原表','部门原表','科目原表'][i],headers:['来源文件','来源页签','来源行',...(t?.headers||[])],rows:t?.rows.map(r=>[r.file,r.sheet,r.row,...t.headers.map(h=>typeof r.cells[h]==='object'&&r.cells[h]!==null?JSON.stringify(r.cells[h]):r.cells[h])])||[]}})
 ]}
export function detailTable(r:Result){return {headers:['记录ID','期间','主体','部门','科目','币种','原单位','精确金额元','固定变动','供应商','项目','来源文件','来源页签','来源行','来源键','映射来源'],rows:r.selected.map(x=>[x.id,x.period,x.entity,x.department,x.account,x.currency,x.unit,x.amount,x.classification,x.supplier,x.project,x.source.file,x.source.sheet,x.source.row,x.key,JSON.stringify(x.mappingSources)])}}
export async function exportWorkbook(w:Work,r:Result){return workbookBytes(sheets(w,r))}
