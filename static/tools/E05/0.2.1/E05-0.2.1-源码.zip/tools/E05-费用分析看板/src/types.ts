import type {Table,SourceRow} from '../../../packages/core/types';
export type Field='id'|'period'|'entity'|'department'|'account'|'currency'|'unit'|'amount'|'basis'|'gross'|'net'|'supplier'|'project'|'classification';
export type Dimension='department'|'account'|'supplier'|'project'|'entity'|'classification';
export const FIELDS:Record<Field,string>={id:'记录ID',period:'期间',entity:'主体',department:'部门',account:'科目',currency:'币种',unit:'单位',amount:'金额',basis:'金额口径',gross:'含税金额',net:'不含税金额',supplier:'供应商',project:'项目',classification:'固定变动'};
export interface Config {fields:Record<Field,string>;basis:'账面费用'|'含税'|'不含税';measure:'amount'|'gross'|'net';confirmed:boolean;from:string;to:string;current:string;previous:string;currency:string;unit:string;displayUnit:'元'|'千元'|'万元';precision:number;threshold:string;growthThreshold:string;filters:Record<Dimension,string>;structure:Dimension;}
export interface Work {expenses:Table|null;departments:Table|null;accounts:Table|null;config:Config;reviews:Record<string,{status:'待复核'|'已确认'|'需更正';note:string}>;}
export interface Issue {key:string;severity:'阻塞'|'复核';message:string;source:SourceRow;}
export interface Detail {key:string;id:string;period:string;entity:string;department:string;account:string;currency:string;unit:string;amount:string;classification:string;supplier:string;project:string;source:SourceRow;mappingSources:SourceRow[];}
export interface Group {name:string;amount:string;share:string|null;count:number;keys:string[];}
export interface Comparison {current:string|null;previous:string|null;delta:string|null;growth:string|null;}
export interface Result {valid:Detail[];selected:Detail[];issues:Issue[];total:string;groups:Record<Dimension,Group[]>;available:Record<Dimension,boolean>;comparison:Comparison;changes:({name:string}&Comparison)[];trend:{period:string;amount:string|null;count:number}[];excluded:number;unselected:number;residuals:Record<Dimension,string|null>;}
export const DIMS:Dimension[]=['department','account','classification','supplier','project','entity'];
export const DIM_NAMES:Record<Dimension,string>={department:'部门',account:'科目',classification:'固定变动',supplier:'供应商',project:'项目',entity:'主体'};
export const initialConfig=():Config=>({fields:{...FIELDS},basis:'账面费用',measure:'amount',confirmed:false,from:'2026-01',to:'2026-03',current:'2026-02',previous:'2026-01',currency:'CNY',unit:'元',displayUnit:'元',precision:2,threshold:'10000',growthThreshold:'30',filters:{department:'',account:'',classification:'',supplier:'',project:'',entity:''},structure:'department'});
export const emptyWork=():Work=>({expenses:null,departments:null,accounts:null,config:initialConfig(),reviews:{}});
