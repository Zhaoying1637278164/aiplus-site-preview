import ExcelJS from 'exceljs';import JSZip from 'jszip';
/** E05-only deterministic workbook: fixed document and every ZIP member date. */
export async function workbookBytes(sheets:{name:string;headers:string[];rows:unknown[][]}[]):Promise<Uint8Array>{
 const wb=new ExcelJS.Workbook(),date=new Date('2000-01-01T00:00:00.000Z');wb.created=date;wb.modified=date;wb.creator='E05';wb.lastModifiedBy='E05';
 for(const spec of sheets){const ws=wb.addWorksheet(spec.name.slice(0,31));ws.addRow(spec.headers);for(const row of spec.rows)ws.addRow(row.map(v=>v===null||v===undefined?'':typeof v==='object'?JSON.stringify(v):String(v)));ws.getRow(1).font={bold:true};ws.views=[{state:'frozen',ySplit:1}];ws.columns.forEach(c=>{c.width=24})}
 const original=await JSZip.loadAsync(await wb.xlsx.writeBuffer()),fixed=new JSZip();
 for(const name of Object.keys(original.files).sort()){const entry=original.files[name];fixed.file(name,entry.dir?new Uint8Array():await entry.async('uint8array'),{date,dir:entry.dir,createFolders:false,compression:'DEFLATE'})}
 return fixed.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6},platform:'DOS'});
}
