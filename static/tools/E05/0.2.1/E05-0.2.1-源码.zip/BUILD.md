# E05候选源码重建
Node22+，npm ci，npm test，npm run typecheck，npm run build。产物progress/evidence/E05/candidate/0.2.1。锁文件、共享包、本款源码、模板、虚构样例、测试、第三方声明齐备；不含node_modules、凭据或业务数据。浏览器测试需本机Chrome；macOS路径见tests/browser.ts。正式源码及官网集成归总控。
