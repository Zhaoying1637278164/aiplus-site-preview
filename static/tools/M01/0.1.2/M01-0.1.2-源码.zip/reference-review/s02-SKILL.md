---
name: margin-decomposition
description: Decomposes a blended gross margin change into mix effect (revenue shifting toward a different-margin segment) and rate effect (a segment's own margin actually moving) via a bundled calculator, and ranks segment profitability, so a margin change gets the right root cause instead of a generic cost investigation. Use whenever the user needs to explain why blended margin moved, wants to rank segments or products by profitability, or has a margin change attributed to "costs" without checking whether it's really a mix shift.
---

# Margin Decomposition

## When to use
Use whenever company-wide gross margin has moved and the cause isn't yet clear, especially before launching a cost investigation that might be solving the wrong problem — a margin decline is very often a mix shift (more revenue coming from a lower-margin segment) rather than any segment's margin actually deteriorating.

## What it does
Decomposes the change in blended gross margin into two distinct effects via a bundled calculator: mix effect (what blended margin would be if every segment kept its prior margin, but at the current revenue mix) and rate effect (the remaining change, from segments' own margins actually moving) — the two reconcile exactly to the total blended margin change, and ranks segments by current profitability.

## Method
1. **Gather revenue and margin percentage by segment** for both the prior and current period — the same granularity discipline as variance-bridge-analyzer; a single blended number can't be decomposed.
2. **Run the bundled calculator** (`scripts/margin_decomp.py`) to get the blended margin for both periods, the mix effect, and the rate effect, which sum exactly to the total blended margin change.
3. **Read mix effect and rate effect as fundamentally different problems.** A mix effect means revenue moved toward a different-margin segment while each segment's own economics stayed intact, worth understanding as a go-to-market or product-mix story. A rate effect means a segment's own margin genuinely moved, worth investigating as a cost or pricing story within that segment.
4. **Check the revenue share change per segment** alongside the margin numbers — a segment gaining share while carrying a different margin than the blend is exactly what drives a mix effect, and seeing both together makes the story concrete rather than abstract.
5. **Don't launch a cost-cutting investigation on the strength of a blended margin decline alone** — if the decomposition shows it's primarily mix, cutting costs in a segment whose own margin never moved won't fix anything and may damage a segment that's actually healthy.
6. **Rank segments by current margin** to see which are structurally most profitable — this feeds directly into resource allocation and pricing conversations, separate from the mix/rate question.
7. **Track the decomposition over multiple periods**, not just once — a consistent mix effect toward a lower-margin segment over several quarters is a strategic trend worth addressing deliberately, not a one-off blip.

## Inputs
- Revenue and gross margin percentage by segment, for both prior and current period
- Config saved as JSON matching the format documented at the top of `scripts/margin_decomp.py`

## Output format
Segment table with prior/current revenue, margin percentage, and revenue share change, ranked by current margin; blended margin for both periods; mix effect and rate effect in percentage points, reconciling to the total change; a plain-language read on which effect dominates.

## Example
Blended gross margin rises from 61.8% to 62.7%, a result that could be read as "things are improving across the board." The decomposition shows it's actually +1.2pp of mix effect (Enterprise, a higher-margin segment, gained 7.3 points of revenue share) offset by -0.3pp of rate effect (Enterprise's own margin actually declined from 72% to 68%, and SMB's improved from 55% to 58%). The real story is nuanced: overall margin looks healthy, but the highest-margin segment's own economics are quietly eroding, a finding the blended number alone would have hidden.

## Common pitfalls
- Launching a cost investigation based on a blended margin decline that's actually a mix effect, missing the real driver entirely.
- Reporting only the blended margin number without the mix/rate decomposition, hiding whether individual segments are actually healthy.
- Checking the decomposition once instead of tracking it over multiple periods, missing a slow-building structural trend.
