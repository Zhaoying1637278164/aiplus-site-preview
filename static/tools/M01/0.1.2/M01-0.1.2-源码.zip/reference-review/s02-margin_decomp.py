#!/usr/bin/env python3
"""
Margin decomposition: breaks down a company-wide gross margin change into
mix shift (selling more of a different-margin product) versus rate change
(a specific product's own margin moving), and ranks segments by profitability.

Usage:
    python3 margin_decomp.py --config margin.json

margin.json shape:
{
  "segments": [
    {
      "name": "Enterprise",
      "prior_revenue": 4000000, "prior_margin_pct": 72,
      "current_revenue": 5200000, "current_margin_pct": 68
    },
    {
      "name": "SMB",
      "prior_revenue": 6000000, "prior_margin_pct": 55,
      "current_revenue": 5800000, "current_margin_pct": 58
    }
  ]
}
"""
import argparse
import json


def money(x):
    return f"${x:,.0f}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = json.load(f)

    segments = cfg["segments"]

    prior_total_rev = sum(s["prior_revenue"] for s in segments)
    current_total_rev = sum(s["current_revenue"] for s in segments)
    prior_total_gp = sum(s["prior_revenue"] * s["prior_margin_pct"] / 100 for s in segments)
    current_total_gp = sum(s["current_revenue"] * s["current_margin_pct"] / 100 for s in segments)

    prior_blended_margin = prior_total_gp / prior_total_rev * 100 if prior_total_rev else 0
    current_blended_margin = current_total_gp / current_total_rev * 100 if current_total_rev else 0

    print("=== Segment Profitability Ranking ===\n")
    print(f"{'Segment':<14}{'Prior Rev':>12}{'Prior Mgn%':>11}{'Curr Rev':>12}{'Curr Mgn%':>11}{'Rev Share Chg':>15}")
    print("-" * 75)

    ranked = sorted(segments, key=lambda s: s["current_margin_pct"], reverse=True)
    for s in ranked:
        prior_share = s["prior_revenue"] / prior_total_rev * 100 if prior_total_rev else 0
        curr_share = s["current_revenue"] / current_total_rev * 100 if current_total_rev else 0
        share_chg = curr_share - prior_share
        print(f"{s['name']:<14}{money(s['prior_revenue']):>12}{s['prior_margin_pct']:>10.1f}%"
              f"{money(s['current_revenue']):>12}{s['current_margin_pct']:>10.1f}%{share_chg:>+14.1f}pp")

    print(f"\nBlended margin: {prior_blended_margin:.1f}% -> {current_blended_margin:.1f}% "
          f"({current_blended_margin - prior_blended_margin:+.1f}pp)")

    # Decompose blended margin change into mix effect and rate effect
    # Mix effect: what blended margin would be if each segment kept its PRIOR margin
    # but at CURRENT revenue mix
    hypothetical_gp_prior_margins = sum(s["current_revenue"] * s["prior_margin_pct"] / 100 for s in segments)
    hypothetical_blended_margin = hypothetical_gp_prior_margins / current_total_rev * 100 if current_total_rev else 0

    mix_effect = hypothetical_blended_margin - prior_blended_margin
    rate_effect = current_blended_margin - hypothetical_blended_margin

    print(f"\n=== Decomposition ===")
    print(f"Mix effect (revenue shifting toward different-margin segments): {mix_effect:+.1f}pp")
    print(f"Rate effect (segments' own margins changing): {rate_effect:+.1f}pp")
    print(f"Total change: {mix_effect + rate_effect:+.1f}pp (should equal blended margin change above)")

    if abs(mix_effect) > abs(rate_effect) * 1.5:
        print("\n>>> READ: this is primarily a MIX story. Revenue is shifting toward a")
        print("    different-margin segment. Individual segment margins are roughly stable.")
    elif abs(rate_effect) > abs(mix_effect) * 1.5:
        print("\n>>> READ: this is primarily a RATE story. Segment mix is roughly stable,")
        print("    but individual segments' own margins are moving. Investigate cost or pricing.")
    else:
        print("\n>>> READ: both mix and rate contributed meaningfully.")


if __name__ == "__main__":
    main()
