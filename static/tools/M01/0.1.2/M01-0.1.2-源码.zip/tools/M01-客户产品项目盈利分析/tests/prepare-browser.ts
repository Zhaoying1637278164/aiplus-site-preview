import {readFile,writeFile} from 'node:fs/promises';import ExcelJS from 'exceljs';import JSZip from 'jszip';import {createHash} from 'node:crypto';import {encode} from '../src/plan';
const p=process.env.M01_ORACLE_OUTPUT||'tools/M01-客户产品项目盈利分析/tests/independent';
const oracle=JSON.parse(await readFile(p+'/oracle-manifest.json','utf8'));
for(const [file,sha] of Object.entries(oracle.files)){if(createHash('sha256').update(await readFile(p+'/'+file)).digest('hex')!==sha)throw Error('Oracle SHA不符 '+file)}
const workNames=['base604','manual','duplicates','import-csv','import-xlsx'];
for(const name of workNames){const f=JSON.parse(await readFile(p+'/'+name+'.json','utf8'));await writeFile(p+'/'+name+'-work.json',encode(f.work,true))}
const f=JSON.parse(await readFile(p+'/base604.json','utf8')),wb=new ExcelJS.Workbook();wb.created=new Date('2026-10-04T00:00:00Z');wb.modified=wb.created;
for(const [key,name] of [['data','业务'],['pools','费用池']]){const t=f.work[key],ws=wb.addWorksheet(name);ws.addRow(t.headers);for(const row of t.rows)ws.addRow(t.headers.map((h:string)=>row.cells[h]))}
const old=await JSZip.loadAsync(await wb.xlsx.writeBuffer()),fixed=new JSZip();for(const name of Object.keys(old.files).sort()){const entry=old.files[name];fixed.file(name,await entry.async('uint8array'),{date:new Date(2026,9,4,0,0,0),dir:entry.dir})}await writeFile(p+'/M01-604组合.xlsx',await fixed.generateAsync({type:'nodebuffer',compression:'DEFLATE'}));
const files:Record<string,string>={};for(const file of [...Object.keys(oracle.files),...workNames.map(n=>n+'-work.json'),'M01-604组合.xlsx'].sort())files[file]=createHash('sha256').update(await readFile(p+'/'+file)).digest('hex');
await writeFile(p+'/fixture-manifest.json',JSON.stringify({schema_version:1,sequence:['independent-oracle','work-and-xlsx','sha-readback'],files},null,2));
for(const [file,sha] of Object.entries(files))if(createHash('sha256').update(await readFile(p+'/'+file)).digest('hex')!==sha)throw Error('Fixture SHA不符 '+file);
console.log(JSON.stringify({files:Object.keys(files).length,verified:true}));
