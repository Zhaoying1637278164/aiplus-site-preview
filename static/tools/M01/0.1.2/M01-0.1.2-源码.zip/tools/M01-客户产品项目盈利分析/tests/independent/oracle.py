"""Independent Python Decimal oracle. Imports no TypeScript, application results or export.
Constructs raw fictitious inputs and hand-written financial/13-sheet contracts.
"""
from decimal import Decimal as D,localcontext,ROUND_HALF_UP
import json,pathlib,csv,io,copy,collections,hashlib
ROOT=pathlib.Path(__import__('os').environ.get('M01_ORACLE_OUTPUT',str(pathlib.Path(__file__).resolve().parent)))
VERSION='0.1.2';RULE='M01-2026-10-04.2'
F={'id':'记录ID','period':'期间','currency':'币种','unit':'单位','customer':'客户','product':'产品','project':'项目','revenue':'收入','cost':'直接成本','costEvidence':'成本依据','expense':'直接费用','expenseEvidence':'费用依据','weight':'分摊权重'}
P={'id':'费用池ID','period':'期间','currency':'币种','unit':'单位','amount':'共用费用','basis':'分摊基础','scope':'范围维度','target':'范围值','evidence':'费用依据'}
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def val(x):return None if x is None else format(D(x),'f').rstrip('0').rstrip('.') if '.' in format(D(x),'f') else format(D(x),'f')
def fixed(x,n):
 q=D(x).quantize(D(10)**-n,rounding=ROUND_HALF_UP);return format(abs(q) if q==0 else q,'.'+str(n)+'f')
def table(file,sheet,headers,values):return dict(file=file,sheet=sheet,headers=headers,rows=[dict(file=file,sheet=sheet,row=i+2,cells=dict(zip(headers,v))) for i,v in enumerate(values)])
def mainwork():
 rows=[]
 for i in range(604):
  per='2026-09' if i<560 else '2026-10';curr='USD' if 584<=i<594 else 'CNY';unit='万元' if i>=594 else '元'
  rev=D(1000+i%37)/100;cost=D(i%23)/100;expense=D(i%7)/100
  if i%67==0:rev=D(0)
  if i%71==0:rev=-D('1.23');cost=-D('.50');expense=-D('.02')
  rows.append([f'B{i:04d}',per,curr,unit,'同名客户' if i<4 else f'客户{i:04d}',f'产品{i%70:02d}',f'项目{i%90:02d}',val(rev),None if i in [27,583] else val(cost),'虚构成本凭据' if i!=27 else None,None if i==91 else val(expense),'虚构费用凭据',str(0 if i%67==0 else i%5+1)])
 ps=[]
 for i in range(64):
  period='2026-09' if i<60 else '2026-10';basis=['正收入','权重','平均'][i%3];scope='全部' if i<6 or i>=60 else ['客户','产品','项目'][i%3]
  target='*' if scope=='全部' else (f'客户{100+i+(1 if (100+i)%71==0 or (100+i)%67==0 else 0):04d}' if scope=='客户' else f'产品{i%70:02d}' if scope=='产品' else f'项目{i%90:02d}')
  ps.append([f'P{i:03d}',period,'CNY','元',val(D(i+1)/100*(-1 if i%11==0 else 1)),basis,scope,target,'完全虚构管理费用依据'])
 c=dict(poolRules={},start='2026-09',end='2026-10',currency='CNY',unit='元',precision=2,tolerance='0.01',dimension='customer',layer='分摊后贡献',confirmed=True,mapping=F.copy(),poolMapping=P.copy(),policyBasis='完全虚构604行管理分析口径')
 w=dict(config=c,data=table('M01-604业务.csv','CSV',list(F.values()),rows),pools=table('M01-64费用池.csv','CSV',list(P.values()),ps),reviews=[])
 for i in range(56):w['reviews'].append(dict(key=js([f'B{i:04d}','2026-09']),owner='虚构复核人',note=f'虚构记录{i}复核说明',evidence=f'虚构附件{i}',status='已复核'))
 return w
MISSING='缺失值或公式单元格，须提供静态值'
def oracle(w):
 c=w['config'];r=dict(config=copy.deepcopy(c),details=[],audit=[],allocations=[],pools=[],blocking=False,coverage=dict(business=len(w['data']['rows']),pools=len(w['pools']['rows'])))
 ids=collections.Counter(str(row['cells'][F['id']]) for row in w['data']['rows']);pids=collections.Counter(str(row['cells'][P['id']]) for row in w['pools']['rows'])
 def audit(side,status,source,issues):r['audit'].append(dict(side=side,status=status,source=copy.deepcopy(source),issues=issues.copy()))
 for row in w['data']['rows']:
  x=row['cells'];per=x['期间'];issues=[]
  if not(c['start']<=per<=c['end'] and x['币种']==c['currency'] and x['单位']==c['unit']):audit('业务','范围外',row,['期间/币种/单位不在选定范围，未合并或换算']);continue
  if ids[x['记录ID']]!=1:audit('业务','异常',row,['重复记录ID，整组阻塞']);continue
  if x['收入'] is None:audit('业务','异常',row,[MISSING]);continue
  rev=D(x['收入']);co=x['直接成本'];ex=x['直接费用']
  if co is None or not x['成本依据']:co=None;issues.append('直接成本缺失/无依据：'+MISSING)
  if ex is None or not x['费用依据']:ex=None;issues.append('直接费用缺失/无依据：'+MISSING)
  weight=x['分摊权重']
  if weight is None or D(weight)<0:issues.append('分摊权重无效：'+(MISSING if weight is None else '权重不得为负'));weight=''
  gross=None if co is None else val(rev-D(co));direct=None if gross is None or ex is None else val(D(gross)-D(ex))
  d=dict(key=js([x['记录ID'],per]),id=x['记录ID'],period=per,customer=x['客户'],product=x['产品'],project=x['项目'],revenue=val(rev),cost=None if co is None else val(co),expense=None if ex is None else val(ex),gross=gross,direct=direct,allocated='0',after=None,weight=weight,issues=issues.copy(),source=copy.deepcopy(row));r['details'].append(d);audit('业务','纳入',row,issues)
 for row in w['pools']['rows']:
  x=row['cells'];per=x['期间'];pid=x['费用池ID'];v=D(x['共用费用']);issues=[]
  if not(c['start']<=per<=c['end'] and x['币种']==c['currency'] and x['单位']==c['unit']):audit('费用池','范围外',row,['期间/币种/单位不在选定范围']);continue
  rule=c['poolRules'].get(pid,{})
  basis=rule.get('basis',x['分摊基础']);scope=rule.get('scope',x['范围维度']);target=rule.get('target',x['范围值']);dim={'客户':'customer','产品':'product','项目':'project'}.get(scope)
  recipients=[d for d in r['details'] if d['period']==per and (scope=='全部' or d[dim]==target)]
  if pids[pid]!=1:issues=['重复费用池ID，整组阻塞']
  elif not x['费用依据']:issues=['必填值为空' if x['费用依据']=='' else MISSING]
  elif not recipients:issues=['没有匹配分摊对象']
  elif any(a['status']=='异常' for a in r['audit'] if a['side']=='业务'):issues=['业务异常须先修正，不能分摊至残缺总体']
  elif basis=='权重' and any(d['weight']=='' for d in recipients):issues=['对象分摊权重无效']
  bases=[D(1) if basis=='平均' else max(D(d['revenue']),D(0)) if basis=='正收入' else D(d['weight'] or 0) for d in recipients]
  total=sum(bases,D(0))
  if not issues and total<=0:issues=['分摊基础合计为零，未分摊']
  if issues:
   r['pools'].append(dict(id=pid,period=per,amount=val(v),allocated='0',residual=val(v),status='阻塞',issues=issues,source=copy.deepcopy(row)));audit('费用池','异常',row,issues);continue
  parts=[(v*b/total).quantize(D(10)**-c['precision'],rounding=ROUND_HALF_UP) for b in bases];residual=v-sum(parts,D(0));tail=sorted(range(len(recipients)),key=lambda i:(-bases[i],recipients[i]['id']))[0];parts[tail]+=residual
  for i,d in enumerate(recipients):
   d['allocated']=val(D(d['allocated'])+parts[i]);r['allocations'].append(dict(pool=pid,key=d['key'],basis=basis,base=val(bases[i]),share=fixed(bases[i]/total,12),raw=fixed(v*bases[i]/total,12),amount=fixed(parts[i],c['precision']),tail=val(residual) if i==tail else '0',source=copy.deepcopy(row),targetSource=copy.deepcopy(d['source'])))
  r['pools'].append(dict(id=pid,period=per,amount=val(v),allocated=val(v),residual='0',status='已分摊',issues=[],source=copy.deepcopy(row)));audit('费用池','纳入',row,[])
 r['blocking']=any(a['status']=='异常' for a in r['audit'])
 for d in r['details']:d['after']=None if r['blocking'] or d['direct'] is None else val(D(d['direct'])-D(d['allocated']))
 return r

def sheets(w,r):
 c=w['config'];defn=[]
 def add(name,h,rows):defn.append(dict(name=name,matrix=[h]+rows))
 params={'schema_version':1,'app_version':VERSION,'rule_version':RULE,**c};params['mapping']=None;params['poolMapping']=None
 add('参数与版本',['参数','值'],[[k,v] for k,v in params.items()]);add('字段映射',['资料','业务字段','原列'],[['业务',k,v] for k,v in F.items()]+[['费用池',k,v] for k,v in P.items()])
 add('盈利明细',['键','ID','期间','客户','产品','项目','收入','直接成本','直接费用','毛利','直接贡献','共用费用','分摊后贡献','问题','文件','页签','原行'],[[d[k] for k in ['key','id','period','customer','product','project','revenue','cost','expense','gross','direct','allocated','after']]+['；'.join(d['issues']),d['source']['file'],d['source']['sheet'],d['source']['row']] for d in r['details']])
 layer={'毛利':'gross','直接贡献':'direct','分摊后贡献':'after'}[c['layer']]
 for dim,name in [('customer','客户汇总'),('product','产品汇总'),('project','项目汇总')]:
  groups=collections.OrderedDict()
  for d in r['details']:groups.setdefault((d['period'],d[dim]),[]).append(d)
  rows=[]
  for (p,label),ds in groups.items():
   rev=sum((D(d['revenue']) for d in ds),D(0));complete=all(d[layer] is not None for d in ds);profit=sum((D(d[layer]) for d in ds),D(0)) if complete else None
   rows.append([p,label,len(ds),val(rev),val(profit),None if profit is None or rev<=0 else fixed(profit/rev*100,6),'不完整' if not complete else '局部有效，源资料有异常' if r['blocking'] else '完整',[d['key'] for d in ds]])
  add(name,['期间','维度','行数','收入',c['layer'],'利润率%','状态','来源键'],rows)
 add('费用池勾稽',['费用池','期间','金额','已分摊','残余','状态','问题','文件','页签','原行'],[[p[k] for k in ['id','period','amount','allocated','residual','status','issues']]+[p['source']['file'],p['source']['sheet'],p['source']['row']] for p in r['pools']])
 add('分摊过程',['费用池','业务键','基础','基数','份额','未舍入','实摊','尾差','池文件','池页签','池原行','对象文件','对象页签','对象原行'],[[a[k] for k in ['pool','key','basis','base','share','raw','amount','tail']]+[a[s][k] for s in ['source','targetSource'] for k in ['file','sheet','row']] for a in r['allocations']])
 add('来源行分类',['资料','文件','页签','原行','分类','问题','全部原值'],[[a['side'],a['source']['file'],a['source']['sheet'],a['source']['row'],a['status'],a['issues'],a['source']['cells']] for a in r['audit']])
 for key,name in [('data','原始业务'),('pools','原始费用池')]:
  t=w[key];add(name,['文件','页签','原行']+t['headers'],[[a['file'],a['sheet'],a['row']]+[a['cells'].get(h) for h in t['headers']] for a in t['rows']])
 add('人工复核',['业务键','负责人','说明','证据引用','状态'],[[v[k] for k in ['key','owner','note','evidence','status']] for v in w['reviews']])
 add('行数守恒',['资料','输入','纳入','范围外','异常','勾稽'],[[side,r['coverage'][key]]+[sum(a['side']==side and a['status']==status for a in r['audit']) for status in ['纳入','范围外','异常']]+['通过'] for side,key in [('业务','business'),('费用池','pools')]])
 def string(v):return '' if v is None else js(v) if isinstance(v,(dict,list)) else 'true' if v is True else 'false' if v is False else str(v)
 return [dict(name=s['name'],matrix=[[string(v) for v in row] for row in s['matrix']]) for s in defn]

def generate():
 base=mainwork();cases={'base604':base}
 for name in ['manual','gross','direct','duplicates','missing-revenue','zero-basis','negative-weight','pool-missing','scope-empty','foreign-pool','zero-pool','negative-pool']:
  w=copy.deepcopy(base);w['reviews']=[]
  if name=='manual':w['config']['poolRules']={'P063':dict(basis='平均',scope='全部',target='*',note='虚构人工规则依据')}
  elif name in ['gross','direct']:w['config']['layer']='毛利' if name=='gross' else '直接贡献'
  elif name=='duplicates':w['data']['rows'][3]['cells']['记录ID']='B0002';w['pools']['rows'][63]['cells']['费用池ID']='P062'
  elif name=='missing-revenue':w['data']['rows'][583]['cells']['收入']=None
  elif name=='zero-basis':
   for row in w['data']['rows']:row['cells']['收入']='0';row['cells']['分摊权重']='0'
  elif name=='negative-weight':w['data']['rows'][583]['cells']['分摊权重']='-1'
  elif name=='pool-missing':w['pools']['rows'][63]['cells']['费用依据']=None
  elif name=='scope-empty':w['pools']['rows'][63]['cells'].update({'范围维度':'客户','范围值':'不存在'})
  elif name=='foreign-pool':w['pools']['rows'][63]['cells']['币种']='USD'
  elif name=='zero-pool':w['pools']['rows'][63]['cells']['共用费用']='0'
  elif name=='negative-pool':w['pools']['rows'][63]['cells']['共用费用']='-0.67'
  cases[name]=w
 for ext in ['csv','xlsx']:
  w=copy.deepcopy(base);w['reviews']=[]
  for key,label in [('data','业务'),('pools','费用池')]:
   t=w[key];t['file']=f'M01-604组合.xlsx' if ext=='xlsx' else t['file'];t['sheet']=label if ext=='xlsx' else 'CSV'
   for row in t['rows']:row['file']=t['file'];row['sheet']=t['sheet']
  cases['import-'+ext]=w
 for name,w in cases.items():
  with localcontext() as ctx:ctx.prec=90;r=oracle(w);ss=sheets(w,r)
  (ROOT/(name+'.json')).write_text(json.dumps(dict(work=w,result=r,sheets=ss),ensure_ascii=False,separators=(',',':')))
  if name=='base604':
   for key in ['data','pools']:
    t=w[key];out=io.StringIO();writer=csv.writer(out);writer.writerow(t['headers']);writer.writerows([[row['cells'][h] for h in t['headers']] for row in t['rows']]);(ROOT/t['file']).write_text('\ufeff'+out.getvalue())
 (ROOT/'oracle-manifest.json').write_text(json.dumps({'algorithm':'Python Decimal precision90, ROUND_HALF_UP, raw fixture constructed here; no app/result import','cases':list(cases),'business_records':604,'pools':64,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/(n+'.json') for n in cases]+[ROOT/base[k]['file'] for k in ['data','pools']]}},indent=2))
 print(json.dumps({'cases':len(cases),'records':604,'pools':64}))
if __name__=='__main__':generate()
