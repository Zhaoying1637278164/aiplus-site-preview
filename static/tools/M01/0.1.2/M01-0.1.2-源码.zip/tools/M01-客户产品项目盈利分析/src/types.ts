import type {Table,SourceRow} from '../../../packages/core/types';
export const VERSION='0.1.2',RULE_VERSION='M01-2026-10-04.2';
export const fields={id:'记录ID',period:'期间',currency:'币种',unit:'单位',customer:'客户',product:'产品',project:'项目',revenue:'收入',cost:'直接成本',costEvidence:'成本依据',expense:'直接费用',expenseEvidence:'费用依据',weight:'分摊权重'} as const;
export const poolFields={id:'费用池ID',period:'期间',currency:'币种',unit:'单位',amount:'共用费用',basis:'分摊基础',scope:'范围维度',target:'范围值',evidence:'费用依据'} as const;
export type Mapping=Record<keyof typeof fields,string>;export type PoolMapping=Record<keyof typeof poolFields,string>;
export type Dimension='customer'|'product'|'project';export type Layer='毛利'|'直接贡献'|'分摊后贡献';
export interface PoolRule{basis:string;scope:string;target:string;note:string}
export interface Config{poolRules:Record<string,PoolRule>;start:string;end:string;currency:string;unit:string;precision:number;tolerance:string;dimension:Dimension;layer:Layer;confirmed:boolean;mapping:Mapping;poolMapping:PoolMapping;policyBasis:string}
export const defaultConfig:Config={poolRules:{},start:'2026-01',end:'2026-12',currency:'CNY',unit:'元',precision:2,tolerance:'0.01',dimension:'customer',layer:'分摊后贡献',confirmed:false,mapping:{...fields},poolMapping:{...poolFields},policyBasis:'用户确认的管理分析口径；不作会计政策判断'};
export interface Review{key:string;owner:string;note:string;evidence:string;status:'待复核'|'已复核'}
export interface Work{config:Config;data:Table|null;pools:Table|null;reviews:Review[]}
export interface Detail{key:string;id:string;period:string;customer:string;product:string;project:string;revenue:string;cost:string|null;expense:string|null;gross:string|null;direct:string|null;allocated:string;after:string|null;weight:string;issues:string[];source:SourceRow}
export interface Audit{side:'业务'|'费用池';status:'纳入'|'范围外'|'异常';source:SourceRow;issues:string[]}
export interface Allocation{pool:string;key:string;basis:string;base:string;share:string;raw:string;amount:string;tail:string;source:SourceRow;targetSource:SourceRow}
export interface PoolResult{id:string;period:string;amount:string|null;allocated:string;residual:string|null;status:'已分摊'|'阻塞';issues:string[];source:SourceRow}
export interface Result{config:Config;details:Detail[];audit:Audit[];allocations:Allocation[];pools:PoolResult[];blocking:boolean;coverage:{business:number;pools:number};}
