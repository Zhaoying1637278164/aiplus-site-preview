import {fields,poolFields,defaultConfig,type Work} from './types';import type {Table} from '../../../packages/core/types';
export function table(file:string,sheet:string,headers:string[],rows:unknown[][]):Table{return {file,sheet,headers,rows:rows.map((values,i)=>({file,sheet,row:i+2,cells:Object.fromEntries(headers.map((h,j)=>[h,values[j] as string|null]))}))}}
export const data=table('完全虚构业务.xlsx','业务',Object.values(fields),[
['001','2026-09','CNY','元','示例甲客户','示例云产品','示例项目A','1000','600','虚构成本台账A','50','虚构费用A','2'],
['002','2026-09','CNY','元','示例乙客户','示例服务产品','示例项目B','500','200','虚构成本台账B','25','虚构费用B','1'],
['003','2026-09','CNY','元','示例甲客户','示例服务产品','示例项目C','0','20','虚构成本台账C','0','明确无直接费用','0'],
['004','2026-09','CNY','元','示例丙客户','示例云产品','示例项目D','200',null,null,'10','虚构费用D','1'],
]);
export const pools=table('完全虚构费用.xlsx','费用池',Object.values(poolFields),[['P01','2026-09','CNY','元','150','正收入','全部','*','虚构管理费用台账']]);
export const example:Work={config:{...structuredClone(defaultConfig),confirmed:true,start:'2026-09',end:'2026-09'},data,pools,reviews:[]};
export const emptyPools=()=>table('用户确认无共用费用','费用池',Object.values(poolFields),[]);
