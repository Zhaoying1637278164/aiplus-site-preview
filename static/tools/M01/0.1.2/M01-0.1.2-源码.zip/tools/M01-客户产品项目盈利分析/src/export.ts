import JSZip from 'jszip';
import {workbookBytes} from '../../../packages/core/io';import {VERSION,RULE_VERSION,type Work,type Result,type Dimension} from './types';import {summarize} from './engine';
export function sheets(r:Result,w:Work){const rows=(t:Work['data'])=>t?.rows.map(x=>[x.file,x.sheet,x.row,...t.headers.map(h=>x.cells[h])])||[];return [
{name:'参数与版本',headers:['参数','值'],rows:Object.entries({schema_version:1,app_version:VERSION,rule_version:RULE_VERSION,...r.config,mapping:undefined,poolMapping:undefined}).map(([k,v])=>[k,v])},
{name:'字段映射',headers:['资料','业务字段','原列'],rows:[...Object.entries(r.config.mapping).map(([k,v])=>['业务',k,v]),...Object.entries(r.config.poolMapping).map(([k,v])=>['费用池',k,v])]},
{name:'盈利明细',headers:['键','ID','期间','客户','产品','项目','收入','直接成本','直接费用','毛利','直接贡献','共用费用','分摊后贡献','问题','文件','页签','原行'],rows:r.details.map(d=>[d.key,d.id,d.period,d.customer,d.product,d.project,d.revenue,d.cost,d.expense,d.gross,d.direct,d.allocated,d.after,d.issues.join('；'),d.source.file,d.source.sheet,d.source.row])},
...(['customer','product','project'] as Dimension[]).map((dim,i)=>({name:['客户汇总','产品汇总','项目汇总'][i],headers:['期间','维度','行数','收入',r.config.layer,'利润率%','状态','来源键'],rows:summarize(r,dim,r.config.layer).map(s=>[s.period,s.label,s.count,s.revenue,s.profit,s.percent,s.status,s.sources])})),
{name:'费用池勾稽',headers:['费用池','期间','金额','已分摊','残余','状态','问题','文件','页签','原行'],rows:r.pools.map(p=>[p.id,p.period,p.amount,p.allocated,p.residual,p.status,p.issues,p.source.file,p.source.sheet,p.source.row])},
{name:'分摊过程',headers:['费用池','业务键','基础','基数','份额','未舍入','实摊','尾差','池文件','池页签','池原行','对象文件','对象页签','对象原行'],rows:r.allocations.map(a=>[a.pool,a.key,a.basis,a.base,a.share,a.raw,a.amount,a.tail,a.source.file,a.source.sheet,a.source.row,a.targetSource.file,a.targetSource.sheet,a.targetSource.row])},
{name:'来源行分类',headers:['资料','文件','页签','原行','分类','问题','全部原值'],rows:r.audit.map(a=>[a.side,a.source.file,a.source.sheet,a.source.row,a.status,a.issues,a.source.cells])},
{name:'原始业务',headers:['文件','页签','原行',...(w.data?.headers||[])],rows:rows(w.data)},
{name:'原始费用池',headers:['文件','页签','原行',...(w.pools?.headers||[])],rows:rows(w.pools)},
{name:'人工复核',headers:['业务键','负责人','说明','证据引用','状态'],rows:w.reviews.map(v=>[v.key,v.owner,v.note,v.evidence,v.status])},
{name:'行数守恒',headers:['资料','输入','纳入','范围外','异常','勾稽'],rows:(['业务','费用池'] as const).map(side=>{const n=r.audit.filter(a=>a.side===side);return [side,side==='业务'?r.coverage.business:r.coverage.pools,n.filter(a=>a.status==='纳入').length,n.filter(a=>a.status==='范围外').length,n.filter(a=>a.status==='异常').length,n.length===(side==='业务'?r.coverage.business:r.coverage.pools)?'通过':'失败']})}
]}
export async function exportWorkbook(r:Result,w:Work){return workbookBytes(sheets(r,w))}

export async function exportCSV(r:Result,w:Work){const zip=new JSZip();for(const s of sheets(r,w)){const content='\uFEFF'+[s.headers,...s.rows].map(row=>row.map(v=>'"'+(v===null||v===undefined?'':typeof v==='object'?JSON.stringify(v):String(v)).replace(/"/g,'""')+'"').join(',')).join('\r\n')+'\r\n';zip.file(s.name+'.csv',content,{date:new Date('2026-10-04T00:00:00Z')})}return zip.generateAsync({type:'uint8array',compression:'DEFLATE',platform:'DOS'})}

export function exportJSON(r:Result,w:Work){return JSON.stringify({schema_version:1,tool:'M01',kind:'report',contains_data:true,app_version:VERSION,rule_version:RULE_VERSION,sheets:sheets(r,w).map(s=>({name:s.name,matrix:[s.headers,...s.rows].map(row=>row.map(v=>v===null||v===undefined?'':typeof v==='object'?JSON.stringify(v):String(v)))}))},null,2)}
