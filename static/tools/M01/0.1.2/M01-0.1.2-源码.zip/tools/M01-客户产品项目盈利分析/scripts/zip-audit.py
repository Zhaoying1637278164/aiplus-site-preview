import pathlib,zipfile,hashlib,json
root=pathlib.Path.cwd();e=root/'progress/evidence/M01/0.1.2';items=[]
for base in [root/'tools/M01-客户产品项目盈利分析/candidate/0.1.0',root/'tools/M01-客户产品项目盈利分析/candidate/0.1.1',root/'tools/M01-客户产品项目盈利分析/candidate/0.1.2',e/'package-download']:
 for p in sorted([*base.rglob('*.zip'),*base.rglob('*.xlsx')]):
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   assert len(z.namelist())==len(set(z.namelist()))
   members=[dict(name=i.filename,bytes=i.file_size,compressed=i.compress_size,crc32=f'{i.CRC:08x}',sha256=hashlib.sha256(z.read(i)).hexdigest(),date_time=i.date_time) for i in z.infolist()]
  items.append(dict(file=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),crc_status='passed',members=members))
for p in (e/'package-download').glob('*离线包.zip'):
 with zipfile.ZipFile(p) as z:z.extractall(e/'downloaded-unpacked')
for p in (e/'package-download').glob('*源码.zip'):
 with zipfile.ZipFile(p) as z:z.extractall('/private/tmp/m01-012-downloaded-source')
(e/'zip-members.json').write_text(json.dumps(items,ensure_ascii=False,indent=2));print(json.dumps({'zips':len(items),'CRC':'passed','members':sum(len(i['members']) for i in items)}))
