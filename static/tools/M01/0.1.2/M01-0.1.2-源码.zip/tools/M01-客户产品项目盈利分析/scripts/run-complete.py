"""Sequential command receipt; no overwritten outputs. Run only this tool's local acceptance."""
import pathlib,subprocess,json,os,hashlib
root=pathlib.Path.cwd();e=root/'progress/evidence/M01/0.1.2';receipts=[]
def run(label,cmd,extra=None):
 env=os.environ.copy();env.update(extra or {});p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True);file=e/(label+'.log');assert not file.exists(),file;file.write_text(p.stdout+p.stderr);entry=dict(label=label,command=cmd,env=extra or {},exit_code=p.returncode,log=str(file.relative_to(root)));receipts.append(entry);(e/'complete-command-receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2));print(json.dumps(entry,ensure_ascii=False),flush=True);assert p.returncode==0,(label,p.stdout[-2000:],p.stderr[-2000:])
run('final-01-build',['node','--import','tsx','tools/M01-客户产品项目盈利分析/scripts/build-candidate.ts'])
run('final-02-package',['python3','tools/M01-客户产品项目盈利分析/scripts/package-candidate.py'])
run('final-03-download',['node','--import','tsx','tools/M01-客户产品项目盈利分析/tests/download-packages.ts'])
run('final-04-zip-preflight',['python3','tools/M01-客户产品项目盈利分析/scripts/zip-audit.py'])
run('final-05-direct',['node','--import','tsx','tools/M01-客户产品项目盈利分析/tests/full-browser.ts'])
run('final-06-downloaded',['node','--import','tsx','tools/M01-客户产品项目盈利分析/tests/full-browser.ts'],{'M01_MODE':'downloaded','M01_URL':(e/'downloaded-unpacked/index.html').as_uri()})
run('final-07-source-four-commands',['python3','tools/M01-客户产品项目盈利分析/scripts/rebuild-audit.py'])
