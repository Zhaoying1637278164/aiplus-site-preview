import pathlib,subprocess,json,hashlib,zipfile
root=pathlib.Path.cwd();e=root/'progress/evidence/M01/0.1.2';src=pathlib.Path('/private/tmp/m01-012-downloaded-source');commands=[]
for number,cmd in enumerate([['npm','ci'],['npm','test'],['npm','run','typecheck'],['npm','run','build','--','M01']],1):
 x=subprocess.run(cmd,cwd=src,capture_output=True,text=True);name=f'source-{number}-'+('-'.join(cmd[1:3]))+'.log';(e/name).write_text(x.stdout+x.stderr);commands.append(dict(command=' '.join(cmd),exit_code=x.returncode,log=name));print(commands[-1],flush=True)
 if x.returncode:break
folder=pathlib.Path('tools/M01-客户产品项目盈利分析/candidate/0.1.2');assets=[]
if len(commands)==4 and all(x['exit_code']==0 for x in commands):
 for p in sorted((root/folder).iterdir()):
  if p.is_file() and not p.name.endswith('.zip'):
   q=src/folder/p.name;assets.append(dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rebuilt_sha256=hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None,same=q.exists() and p.read_bytes()==q.read_bytes()))
metadata=[]
for name in ['虚构样例.xlsx','M01-604组合.xlsx']:
 p=root/folder/name;q=src/folder/name
 if not q.exists():continue
 with zipfile.ZipFile(p) as a,zipfile.ZipFile(q) as b:
  for i in a.infolist():
   j=b.getinfo(i.filename);metadata.append(dict(workbook=name,member=i.filename,time=list(i.date_time),rebuilt_time=list(j.date_time),content_same=a.read(i)==b.read(j),time_same=i.date_time==j.date_time))
zipfile_path=e/'package-download/M01-0.1.2-源码.zip';r=dict(status='passed' if len(commands)==4 and all(x['exit_code']==0 for x in commands) and assets and all(x['same'] for x in assets) and all(x['time_same'] and x['content_same'] for x in metadata) else 'failed',source_zip_sha256=hashlib.sha256(zipfile_path.read_bytes()).hexdigest(),commands=commands,assets=assets,xlsx_members=metadata);(e/'source-rebuild.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(r['status'],flush=True)

if r['status']!='passed':raise SystemExit(1)
