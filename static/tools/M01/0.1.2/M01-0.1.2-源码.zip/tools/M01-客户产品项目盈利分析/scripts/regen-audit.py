"""Empty-directory regeneration, declared SHA readback, old independent finance preservation."""
import pathlib,tempfile,subprocess,os,json,hashlib,zipfile
root=pathlib.Path.cwd();owner=root/'tools/M01-客户产品项目盈利分析';e=root/'progress/evidence/M01/0.1.2';runs=[]
with tempfile.TemporaryDirectory(prefix='m01-012-regen-',dir='/private/tmp') as temp:
 for number in [1,2]:
  out=pathlib.Path(temp)/str(number);out.mkdir();env=os.environ.copy();env['M01_ORACLE_OUTPUT']=str(out)
  if number==2:(out/'stale-work.json').write_text('deliberate residual');(out/'fixture-manifest.json').write_text('deliberate old manifest')
  commands=[]
  for cmd in [['python3',str(owner/'tests/independent/oracle.py')],['node','--import','tsx',str(owner/'tests/prepare-browser.ts')]]:
   x=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True);commands.append(dict(command=cmd,exit_code=x.returncode,stdout=x.stdout,stderr=x.stderr));assert x.returncode==0,commands
  manifests={}
  for name,count in [('oracle-manifest.json',17),('fixture-manifest.json',23)]:
   m=json.loads((out/name).read_text());assert len(m['files'])==count;assert not any('manifest' in f or 'stale' in f for f in m['files'])
   for f,sha in m['files'].items():assert hashlib.sha256((out/f).read_bytes()).hexdigest()==sha,f
   manifests[name]=m
  finance=[]
  with zipfile.ZipFile(e/'original-0.1.1-source-input.zip') as old:
   for case in manifests['oracle-manifest.json']['cases']:
    names=[n for n in old.namelist() if n.endswith('/independent/'+case+'.json')];assert len(names)==1,names
    before=json.loads(old.read(names[0]));after=json.loads((out/(case+'.json')).read_text())
    # Only export parameter app identity changes; compare complete financial results unchanged.
    assert before['result']==after['result'],case
    def normalize(v):
     if isinstance(v,list):return [normalize(x) for x in v]
     if isinstance(v,dict):return {k:normalize(x) for k,x in v.items()}
     return 'APP_VERSION' if v in ['0.1.1','0.1.2'] else v
    assert normalize(before)==normalize(after),case
    finance.append(dict(case=case,full_result_same=True,work_and_13_tables_same_except_app_identity=True))
  runs.append(dict(run=number,residual_injected=number==2,commands=commands,manifests=manifests,finance=finance))
 assert runs[0]['manifests']==runs[1]['manifests'],'Fresh and residual regeneration differs'
 for name,m in runs[0]['manifests'].items():
  assert m==json.loads((owner/'tests/independent'/name).read_text()),'Checked-in fixtures differ '+name
(e/'regeneration.json').write_text(json.dumps(dict(status='passed',runs=runs),ensure_ascii=False,indent=2));print('passed: two regenerations, 17 Oracle + 23 fixture SHA each, 15 unchanged financial cases')
