import {readFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
export async function verifyFixtures(p='tools/M01-客户产品项目盈利分析/tests/independent'){
 for(const name of ['oracle-manifest.json','fixture-manifest.json']){const manifest=JSON.parse(await readFile(p+'/'+name,'utf8'));const expected=name==='oracle-manifest.json'?17:23;if(Object.keys(manifest.files).length!==expected)throw Error('清单数量不符 '+name);for(const [file,sha] of Object.entries(manifest.files)){if(file.includes('/')||file.includes('manifest'))throw Error('清单路径非法 '+file);if(createHash('sha256').update(await readFile(p+'/'+file)).digest('hex')!==sha)throw Error('SHA不符 '+file)}}
}
