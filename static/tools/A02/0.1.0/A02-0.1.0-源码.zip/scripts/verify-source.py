"""Rebuild our own release source ZIP in an independent temporary checkout.

Usage: python3 scripts/verify-source.py release/D02/0.2.0
The evidence binds the exact source ZIP and compares both offline and website
programs. It does not claim product acceptance or run Windows/browser gates.
"""
import hashlib,json,pathlib,subprocess,sys,tempfile,zipfile
release=pathlib.Path(sys.argv[1]).resolve()
tool,version=release.parent.name,release.name
archive=release/f'{tool}-{version}-源码.zip'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
required=['package.json','package-lock.json','tsconfig.json','AGENTS.md','工具总览.md',
          'scripts/build.ts','scripts/package.py','docs/source-build.md',
          'packages/core/io.ts','packages/ui/tool-host.ts','website/base-index.html',
          'website/base-manifest.json','THIRD_PARTY_NOTICES.md']
if tool=='D02':required+=['tools/D02-账表对账/src/program.tsx','tools/D02-账表对账/src/main.tsx',
                          'tools/D02-账表对账/tests/workflow.test.ts','tests/d02-v2-input-browser.ts',
                          'tests/d02-native-site.ts','tests/d02-native-input.ts',
                          'scripts/check-d02-evidence.py','scripts/verify-source.py']
if tool!='D02' and (release/'runtime.json').is_file():
 catalog=json.loads(pathlib.Path('catalog/tools.json').read_text())
 folder='tools/'+next(x['folder'] for x in catalog if x['id']==tool)
 required+=[folder+'/src/program.tsx',folder+'/src/main.tsx',folder+'/src/release-assets.ts',
            'packages/core/release-assets.ts','packages/ui/site-download.ts']
if tool=='D03':required+=['tests/d03-v2-browser.ts','tests/d03-v2-input-browser.ts',
                          'tests/d03-native-site.ts','tests/d03-business-browser.ts',
                          'scripts/check-native-evidence.py',folder+'/src/workflow.ts',
                          folder+'/src/restore.ts',folder+'/tests/workflow.test.ts']
if tool=='D06':required+=['tests/d06-v2-browser.ts','tests/d06-v2-input-browser.ts',
                          'tests/d06-native-site.ts','tests/d06-navigation-browser.ts','tests/d06-native-downloads.ts',
                          'fixtures/D06/v2-input/独立预期.json',
                          'fixtures/D06/v2-input/虚构三十笔.csv','fixtures/D06/v2-input/虚构三十笔.xlsx',
                          folder+'/tests/navigation-candidate.ts',folder+'/src/workflow.ts',
                          folder+'/src/work-export.ts',folder+'/tests/workflow.test.ts',
                          folder+'/tests/browser-candidate.ts',folder+'/tests/build-candidate.ts']
if tool=='R03':required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/types.ts',folder+'/src/session.ts',folder+'/src/transition.ts',folder+'/src/export.ts',folder+'/src/release-assets.ts',folder+'/tests/engine.test.ts',folder+'/规格与独立预期.md','tests/r03-independent-review.ts','tests/r03-formal-browser.ts','tests/r03-native-site.ts','tests/r03-native-downloads.ts','scripts/check-native-evidence.py']
if tool=='R02':required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/session.ts',
                          folder+'/src/transition.ts',folder+'/src/export.ts',folder+'/src/types.ts',
                          folder+'/tests/engine.test.ts',folder+'/tests/fixtures.ts',
                          folder+'/规格与独立预期.md','tests/r02-formal-browser.ts',
                          'tests/r02-independent-review.ts','tests/r02-native-site.ts',
                          'tests/r02-native-downloads.ts','scripts/check-native-evidence.py']
if tool=='R01':required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/model.ts',
                          folder+'/src/work.ts',folder+'/tests/engine.test.ts',
                          folder+'/规格与独立预期.md','tests/r01-formal-browser.ts','tests/r01-native-site.ts',
                          'tests/r01-native-downloads.ts','tests/r01-native-navigation.ts','scripts/check-native-evidence.py']
if tool=='T06':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/types.ts',
            folder+'/src/work.ts',folder+'/src/export.ts',folder+'/src/documents.ts',
            folder+'/tests/engine.test.ts',folder+'/tests/reversal-policy.test.ts',
            folder+'/tests/io.test.ts',folder+'/tests/security.test.ts',
            folder+'/规格与独立预期.md','tests/t06-independent-review.ts',
            'tests/t06-formal-browser.ts','tests/t06-formal-supplement.ts',
            'tests/t06-native-site.ts','tests/t06-native-downloads.ts']
if tool in ['R04','R05']:
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/program.tsx',
            folder+'/src/types.ts',folder+'/tests/engine.test.ts',folder+'/规格与独立预期.md',
            folder+'/财务规则.md',folder+'/参考来源.md',
            'tests/'+tool.lower()+'-provisional-independent-review.ts',
            'tests/'+tool.lower()+'-formal-browser.ts','tests/r04-r05-native-site.ts',
            'tests/r04-r05-native-downloads.ts','scripts/check-native-evidence.py','scripts/run-native-regression.py',
            'scripts/verify-source.py','scripts/verify-rebuilt-assets.py']
if tool=='P03':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/types.ts',
            folder+'/src/work.ts',folder+'/src/export.ts',folder+'/tests/engine.test.ts',
            folder+'/规格与独立预期.md',folder+'/财务规则.md',folder+'/参考来源.md',
            'tests/p03-independent-review.ts','tests/p03-formal-browser.ts',
            'tests/p03-native-site.ts','tests/payables-native-navigation.ts',
            'scripts/check-p03-local-evidence.py',
            'scripts/verify-source.py','scripts/verify-rebuilt-assets.py']
if tool=='P02':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/types.ts',
            folder+'/src/work.ts',folder+'/src/export.ts',folder+'/tests/engine.test.ts',
            folder+'/规格与独立预期.md',folder+'/财务规则.md',folder+'/参考来源.md',
            'tests/p02-independent-review.ts','tests/p02-formal-browser.ts',
            'tests/p02-native-site.ts','tests/payables-native-navigation.ts',
            'scripts/check-p02-local-evidence.py',
            'scripts/verify-source.py','scripts/verify-rebuilt-assets.py']
if tool=='P04':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/types.ts',
            folder+'/src/import.ts',folder+'/src/work.ts',folder+'/src/export.ts',
            folder+'/tests/engine.test.ts',folder+'/规格与独立预期.md',
            folder+'/财务规则.md',folder+'/参考来源.md',
            'tests/p04-independent-review.ts','tests/p04-formal-browser.ts',
            'scripts/verify-source.py','scripts/verify-rebuilt-assets.py']
if tool in ['T01','T02']:
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/types.ts',
            folder+'/src/import.ts',folder+'/src/work.ts',folder+'/src/export.ts',
            folder+'/tests/engine.test.ts',folder+'/tests/io.test.ts',
            folder+'/规格与独立预期.md',folder+'/财务规则.md',folder+'/参考来源.md',
            'tests/'+tool.lower()+'-independent-review.ts',
            'tests/'+tool.lower()+'-formal-browser.ts',
            'scripts/verify-source.py','scripts/verify-rebuilt-assets.py']
 if tool=='T02':required+=['tests/t02-formal-supplement.ts']
if tool in ['P04','T01','T02']:
 required+=['tests/'+tool.lower()+'-native-site.ts','tests/new-tools-native-downloads.ts','scripts/check-new-tools-local-evidence.py']
if tool=='P01':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/types.ts',
            folder+'/src/session.ts',folder+'/src/export.ts',folder+'/tests/engine.test.ts',
            folder+'/规格与独立预期.md',folder+'/财务规则.md',folder+'/参考来源.md',
            'tests/p01-independent-review.ts','tests/p01-formal-browser.ts',
            'tests/p01-native-site.ts','tests/payables-native-navigation.ts',
            'scripts/check-p01-local-evidence.py',
            'scripts/verify-source.py','scripts/verify-rebuilt-assets.py']
if tool=='K01':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/documents.ts',
            folder+'/src/version.ts',folder+'/src/usage.ts',folder+'/tests/engine.test.ts',
            folder+'/tests/io.test.ts',folder+'/财务规则.md',folder+'/参考来源.md',
            folder+'/规格与独立预期.md',folder+'/开发说明.md',
            'tests/k01-independent-review.ts','tests/k01-formal-browser.ts',
            'tests/k01-export-oracle.ts','tests/k01-native-site.ts','tests/k01-native-downloads.ts',
            'scripts/check-k01-local-evidence.py','scripts/verify-rebuilt-assets.py']
if tool=='K03':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/export.ts',
            folder+'/src/work.ts',folder+'/src/usage.ts',folder+'/src/version.ts',
            folder+'/tests/engine.test.ts',folder+'/参考来源.md',folder+'/财务规则.md',
            folder+'/规格与独立预期.md',folder+'/references/erpnext-v15-stock_ageing.py',
            folder+'/references/erpnext-v15-license.txt','tests/k03-independent-review.ts',
            'tests/k03-formal-browser.ts','tests/k03-formal-micro-return.ts',
            'tests/k03-root-financial-browser.ts','tests/k03-native-bootstrap.ts',
            'tests/k03-native-site.ts','tests/k03-native-financial-browser.ts',
            'tests/k03-native-downloads.ts','tests/k03-native-full-pages.ts',
            'scripts/check-k03-local-evidence.py','scripts/check-k03-site-placement.py',
            'scripts/verify-rebuilt-assets.py']
if tool=='K02':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/export.ts',
            folder+'/src/work.ts',folder+'/src/usage.ts',folder+'/src/version.ts',
            folder+'/tests/engine.test.ts',folder+'/财务规则.md',folder+'/参考来源.md',
            folder+'/规格与独立预期.md',folder+'/开发说明.md',
            'tests/k02-independent-review.ts','tests/k02-formal-browser.ts',
            'tests/k02-export-oracle.ts','tests/k02-native-site.ts','tests/k02-native-downloads.ts',
            'scripts/verify-rebuilt-assets.py']
if tool=='T04':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/execution.ts',
            folder+'/src/work.ts',folder+'/src/export.ts',folder+'/tests/engine.test.ts',
            folder+'/tests/execution.test.ts',folder+'/tests/independent-fixtures.py',
            folder+'/tests/independent-history.py',folder+'/tests/independent-execution.py',
            folder+'/tests/independent-expected.json',folder+'/tests/independent-history-expected.json',
            folder+'/tests/independent-execution-expected.json','tests/t04-independent-review.ts',
            'tests/t04-root-financial-browser.ts','tests/t04-native-execution.ts',
            'tests/t04-native-financial-browser.ts','tests/t04-native-downloads.ts',
            'scripts/check-t04-local-evidence.py','scripts/verify-rebuilt-assets.py']
if tool=='A01':
 required+=['source-snapshot.json',folder+'/src/engine.ts',folder+'/src/export.ts',folder+'/src/work.ts',folder+'/tests/engine.test.ts',folder+'/规格与独立预期.md',folder+'/财务规则.md',folder+'/参考来源.md','tests/a01-independent-review.ts']
root=pathlib.Path(tempfile.mkdtemp(prefix=f'aiplus-{tool}-{version}-source-',dir='/private/tmp'))
with zipfile.ZipFile(archive) as z:
 names=z.namelist()
 for name in names:
  p=pathlib.PurePosixPath(name)
  if p.is_absolute() or '..' in p.parts:raise ValueError('unsafe source path')
  if any(x in p.parts for x in ['node_modules','.git','__pycache__']):raise ValueError('excluded directory included')
  if p.name.startswith('.env') or p.suffix in ['.pem','.key','.pyc']:raise ValueError('unexpected private/cache material')
 for name in required:
  if name not in names:raise ValueError(f'missing source component: {name}')
 if 'source-snapshot.json' in names:
  snapshot=json.loads(z.read('source-snapshot.json'))
  if snapshot['tool']!=tool or snapshot['version']!=version:raise ValueError('source snapshot version mismatch')
  for name,expected in snapshot['file_sha256'].items():
   if hashlib.sha256(z.read(name)).hexdigest()!=expected:raise ValueError('source snapshot file mismatch: '+name)
 if sum(i.file_size for i in z.infolist())>250*1024*1024:raise ValueError('source archive unexpectedly large')
 z.extractall(root)
commands=[['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund'],
          ['npm','test'],['npm','run','typecheck'],['npm','run','build','--',tool]]
logs=[]
for command in commands:
 print(' '.join(command),flush=True)
 r=subprocess.run(command,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 logs.append({'command':command,'exit_code':r.returncode,'output':r.stdout})
 if r.returncode:
  print(r.stdout);raise RuntimeError('source rebuild command failed')
files=['index.html']+(['runtime.json'] if (release/'runtime.json').exists() else [])
comparison={}
for name in files:
 expected=sha(release/name);actual=sha(root/'release'/tool/version/name)
 comparison[name]={'release_sha256':expected,'rebuilt_sha256':actual,'identical':expected==actual}
 if expected!=actual:raise RuntimeError(f'{name} differs from release')
evidence=pathlib.Path('progress/evidence')/tool/version
evidence.mkdir(parents=True,exist_ok=True)
(evidence/'source-rebuild-log.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2)+'\n')
(evidence/'source-rebuild.json').write_text(json.dumps({'tool':tool,'version':version,
 'source_zip_sha256':sha(archive),'independent_directory':str(root),'required_files_checked':required,
 'commands':[{'command':x['command'],'exit_code':x['exit_code']} for x in logs],
 'files':comparison,'product_acceptance':'separate gates required'},ensure_ascii=False,indent=2)+'\n')
print('Independent source rebuild identical:',', '.join(files),flush=True)
