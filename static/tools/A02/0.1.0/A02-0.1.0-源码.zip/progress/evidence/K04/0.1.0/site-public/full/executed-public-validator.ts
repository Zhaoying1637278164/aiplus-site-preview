assert.equal(new URL(process.env.AIPLUS_NATIVE_SITE_URL||'').href,"https://aiplus-guance.streamlit.app/~/+/");
// Capture all actual srcdoc content, including content below the iframe viewport.
import {chromium} from 'playwright';import {mkdir,readFile,writeFile} from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';import {openK04Native} from "/Users/xiaoying/Library/Mobile Documents/com~apple~CloudDocs/codex/data_labs/aiplus-finance-tools/tests/k04-native-bootstrap";
const out=path.resolve('/Users/xiaoying/Library/Mobile Documents/com~apple~CloudDocs/codex/data_labs/aiplus-finance-tools/progress/evidence/K04/0.1.0/site-public/full');await mkdir(out,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'}),errors:string[]=[],requests:string[]=[],images:any[]=[];
try{
 const native=await openK04Native(browser,out,path.resolve('release/K04/0.1.0'),errors,requests,()=>true),{frame,shell,page}=native;
 await page.getByRole('button',{name:'装入虚构样例',exact:true}).click();
 const pages=['盘点范围','账面存货','实盘清单','物料与单位','重复盘点','盘盈盘亏','财务复核','盘点底稿','使用说明与模板'];
 for(const width of [1440,390,320]){
  await shell.setViewportSize({width,height:1000});
  for(let i=0;i<pages.length;i++){
   await page.getByRole('navigation').getByRole('button',{name:String(i+1)+'. '+pages[i],exact:true}).click();
   if(i===8)await page.getByRole('button',{name:'下载模板.xlsx',exact:true}).waitFor();
   const iframe=shell.locator('iframe').first(),before=await iframe.getAttribute('style'),attr=await iframe.getAttribute('height');
   const height=await frame.evaluate(()=>Math.max(document.documentElement.scrollHeight,document.body.scrollHeight));
   try{
    await iframe.evaluate((el,h)=>{const ancestors:any[]=[];for(let parent=el.parentElement;parent;parent=parent.parentElement){ancestors.push([parent,parent.getAttribute('style')]);parent.style.setProperty('overflow','visible','important')} (el as any).__captureStyles=ancestors;el.style.setProperty('height',h+'px','important');el.setAttribute('height',String(h))},height);
    await frame.waitForFunction(h=>innerHeight>=h-2,height);
    await frame.evaluate(()=>window.scrollTo(0,0));
    const rendered=await frame.evaluate(()=>({width:innerWidth,height:innerHeight,scrollHeight:document.documentElement.scrollHeight,overflow:document.documentElement.scrollWidth>innerWidth+2}));
    assert(!rendered.overflow);assert(rendered.height>=height-2);assert(rendered.scrollHeight<=rendered.height+2);
    const file=`site-full-${width}-${i+1}.png`;await iframe.screenshot({path:out+'/'+file});const bytes=await readFile(out+'/'+file);
    images.push({file,requestedWidth:width,page:pages[i],iframeExpandedHeight:height,rendered,sha256:createHash('sha256').update(bytes).digest('hex')});
   }finally{await iframe.evaluate((el,v)=>{for(const [parent,style] of (el as any).__captureStyles||[]){if(style===null)parent.removeAttribute('style');else parent.setAttribute('style',style)}delete (el as any).__captureStyles;if(v.style===null)el.removeAttribute('style');else el.setAttribute('style',v.style);if(v.height===null)el.removeAttribute('height');else el.setAttribute('height',v.height)},{style:before,height:attr})}
  }
 }
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);await writeFile(out+'/result.json',JSON.stringify({passed:true,siteSHA:native.siteSHA,actualRuntimeSHA:native.actualRuntimeSHA,images,errors,requests,scope:'27 actual iframe content screenshots with temporary iframe height equal document content; restored after capture; internal tables remain horizontally scrollable; manual visual review separate'},null,2));console.log(JSON.stringify({passed:true,actualFullContentImages:images.length}));
}finally{await browser.close()}
