import assert from 'node:assert/strict';
import type {readFileData} from '../packages/core/io';
// Literal independent financial oracle for the wholly fictitious230 sample.
// This module deliberately imports neither the allocation engine nor its exports.
export function checkK01Workbook(book:Awaited<ReturnType<typeof readFileData>>){
 const origin=(kind:string,row:number)=>`虚构样例.xlsx / ${kind} / 第${row}行`;
 const scope=['虚构星禾制造','2026-09','CNY','元'];
 const inputs:{kind:string;headers:string[];rows:string[][]}[]=[
  {kind:'成本',headers:['成本ID','成本池','金额','方式','对象ID','排除理由','依据','主体','期间','币种','单位'],rows:[['C001','办公','120','直接','A','','虚构领用单',...scope],['C002','公共','100','分摊','','','虚构共享服务',...scope],['C003','办公','10','排除','','个人项目','虚构不纳入说明',...scope]]},
  {kind:'对象',headers:['对象ID','对象名称','启用'],rows:[['A','产品甲','是'],['B','产品乙','是']]},
  {kind:'动因',headers:['成本池','对象ID','动因值','动因单位','排除理由','依据','主体','期间','币种','单位'],rows:[['公共','A','1','工时','','虚构工时表',...scope],['公共','B','3','工时','','虚构工时表',...scope]]},
  {kind:'规则',headers:['成本池','方法','顺序','依据'],rows:[['公共','动因','1','用户确认按工时']]},
 ];
 const expected:{name:string;matrix:string[][]}[]=[
 {name:'范围参数',matrix:[['参数','值'],...Object.entries({app_version:'0.1.0',rule_version:'K01-2026-10-04.1',entity:scope[0],period:scope[1],currency:scope[2],unit:scope[3],start:'2026-01',end:'2026-12',precision:'2',tolerance:'0',negative:'block',zero:'retain',tail:'last'})]},
 {name:'对象成本',matrix:[['对象ID','对象名称','直接成本','分摊成本','合计'],['A','产品甲','120.00','25.00','145.00'],['B','产品乙','0.00','75.00','75.00']]},
 {name:'分配明细',matrix:[['成本ID','成本池','对象ID','对象名称','方法','金额','动因值','动因合计','比例','未舍入金额','舍入金额','尾差调整','成本来源','动因来源','规则来源','依据'],['C002','公共','A','产品甲','动因','25.00','1','4','0.25','25','25.00','0',origin('成本',3),origin('动因',2),origin('规则',2),'虚构共享服务；用户确认按工时；虚构工时表'],['C002','公共','B','产品乙','动因','75.00','3','4','0.75','75','75.00','0',origin('成本',3),origin('动因',3),origin('规则',2),'虚构共享服务；用户确认按工时；虚构工时表'],['C001','办公','A','产品甲','直接','120.00','1','1','1','120','120.00','0',origin('成本',2),'','','虚构领用单']]},
 {name:'成本去向',matrix:[['成本ID','成本池','金额','状态','原因','来源'],['C002','公共','100.00','分摊','',origin('成本',3)],['C001','办公','120.00','直接','',origin('成本',2)],['C003','办公','10.00','排除','个人项目',origin('成本',4)]]},
 {name:'逐池勾稽',matrix:[['成本池','来源','直接','分摊','排除','未分配','差额','检查'],['办公','130.00','120.00','0.00','10.00','0.00','0.00','通过'],['公共','100.00','0.00','100.00','0.00','0.00','0.00','通过']]},
 {name:'异常',matrix:[['资料','来源','原因']]},
 {name:'动因参与',matrix:[['来源','是否参与','说明'],[origin('动因',2),'是','参与分摊'],[origin('动因',3),'是','参与分摊']]},
 ];
 for(const input of inputs)for(const suffix of ['原始资料','有效资料'])expected.push({name:input.kind+suffix,matrix:[['来源文件','页签','原行',...input.headers],...input.rows.map((row,i)=>['虚构样例.xlsx',input.kind,String(i+2),...row])]});
 expected.push({name:'字段对应与修订',matrix:[['资料','字段对应','修订记录'],...inputs.map(x=>[x.kind,JSON.stringify(Object.fromEntries(x.headers.map(h=>[h,h]))),'{}'])]});
 assert.deepEqual(book.sheets.map(s=>s.name),expected.map(s=>s.name));let cells=0;
 for(let i=0;i<expected.length;i++){const actual=book.sheets[i].matrix.map(row=>row.map(v=>String(v??'')));assert.deepEqual(actual,expected[i].matrix,expected[i].name+' literal manual oracle');cells+=actual.reduce((n,row)=>n+row.length,0)}
 return cells;
}
