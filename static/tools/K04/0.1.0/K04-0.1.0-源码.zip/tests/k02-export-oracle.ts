import assert from 'node:assert/strict';
import type {readFileData} from '../packages/core/io';
// Independent literal oracle; never imports the cost engine or export implementation.
export function checkK02Workbook(book:Awaited<ReturnType<typeof readFileData>>){
 const scope=['虚构工厂','2026-09','CNY','元','件'];
 const input=[
 {role:'standard',name:'标准成本',headers:['记录ID','主体','期间','币种','金额单位','产出单位','标准对象','标准项目','耗用单位','标准产出','单位允许量','标准单价','标准版本','依据'],rows:[['S-A',...scope,'产品A','材料甲','kg','100','2','5','STD-虚构1','虚构标准审批A'],['S-B',...scope,'产品B','材料乙','kg','100','1','3','STD-虚构1','虚构标准审批B']]},
 {role:'output',name:'实际产出',headers:['记录ID','主体','期间','币种','金额单位','产出单位','实际对象','实际产出','依据'],rows:[['O-A',...scope,'车间A','120','虚构产出A'],['O-B',...scope,'车间B','80','虚构产出B']]},
 {role:'usage',name:'实际耗用',headers:['记录ID','主体','期间','币种','金额单位','产出单位','实际对象','实际项目','耗用单位','实际耗用','实际单价','依据','账面成本'],rows:[['U-A',...scope,'车间A','甲料','kg','250','6','虚构领料A',''],['U-B',...scope,'车间B','乙料','kg','70','2','虚构领料B','']]},
 {role:'mapping',name:'对象对应',headers:['记录ID','主体','期间','币种','金额单位','产出单位','实际对象','实际项目','耗用单位','标准对象','标准项目','依据'],rows:[['M-A',...scope,'车间A','甲料','kg','产品A','材料甲','虚构对应A'],['M-B',...scope,'车间B','乙料','kg','产品B','材料乙','虚构对应B']]}
 ];
 const rule={method:'separate',tolerance:'0.01',digits:2,from:'2026-09',to:'2026-09',reviewer:'虚构复核人',basis:'虚构标准与实际同范围，按实际产出重建允许量',overrides:[]};
 const fields=Object.fromEntries(input.map(x=>[x.role,Object.fromEntries(x.headers.map(h=>[h,h]))]));
 const expected:{name:string;matrix:string[][]}[]=[{name:'参数',matrix:[['参数','值'],['应用版本','0.1.0'],['规则版本','K02-2026-10-04.1'],...Object.entries(rule).map(([k,v])=>[k,typeof v==='object'?JSON.stringify(v):String(v)]),['字段对应',JSON.stringify(fields)]]}];
 for(const x of input)expected.push({name:x.name+'原始',matrix:[['源文件','页签','原始行',...x.headers],...x.rows.map((row,i)=>['完全虚构-'+x.role+'.csv',x.role,String(i+2),...row])]});
 const normalized:string[][]=[];for(const x of input)for(let i=0;i<2;i++){
  const row=x.rows[i],v=Object.fromEntries(x.headers.map((h,j)=>[h,row[j]])),identities=x.headers.slice(0,6).concat(x.role==='output'?['实际对象']:x.role==='standard'?['标准对象','标准项目','耗用单位']:['实际对象','实际项目','耗用单位']);
  // Reconstruct identity-first insertion order from the documented canonical schema;
  // numeric values in these input literals already have their canonical representation.
  const canonical:Record<string,string>={};for(const h of identities)canonical[h]=v[h];for(const h of x.headers)canonical[h]=v[h];
  const key=x.role==='output'?[...scope,'车间'+(i?'B':'A')]:x.role==='standard'?[...scope,'产品'+(i?'B':'A'),'材料'+(i?'乙':'甲'),'kg']:[...scope,'车间'+(i?'B':'A'),i?'乙料':'甲料','kg'];
  const source={file:'完全虚构-'+x.role+'.csv',sheet:x.role,row:i+2,cells:Object.fromEntries(x.headers.map((h,j)=>[h,x.role==='usage'&&h==='账面成本'?null:row[j]]))};
  normalized.push([x.role,row[0],JSON.stringify(key),'false',JSON.stringify(canonical),JSON.stringify(source)]);
 }
 expected.push({name:'标准化资料',matrix:[['角色','记录ID','业务键','无效','规范值','来源'],...normalized]});
 expected.push({name:'可比明细',matrix:[['标准记录ID','主体/期间/币种/金额单位/产出单位/耗用单位','标准对象','标准项目','实际产出','标准产出','单位允许量','可比允许量','标准单价','实际耗用','实际加权价格(12位)','原标准成本','可比标准成本','实际成本','产出及允许量因素','可比总差异','用量因素','价格因素','单列交叉项','交叉诊断(含入因素时勿重复加)','账面成本(缺失不适用)','账面与价量未解释差额','精度残差','因素勾稽差额','全桥勾稽差额','状态'],['S-A',JSON.stringify([...scope,'kg']),'产品A','材料甲','120','100','2','240','5','250','6','1000','1200','1500','200','300','50','240','10','10','不适用','0','0','0','0','精确桥接'],['S-B',JSON.stringify([...scope,'kg']),'产品B','材料乙','80','100','1','80','3','70','2','300','240','140','-60','-100','-30','-80','10','10','不适用','0','0','0','0','精确桥接']]});
 expected.push({name:'桥接汇总',matrix:[['主体/期间/币种/金额单位/产出单位/耗用单位','可比项目数','原标准成本','产出及允许量因素','可比标准成本','用量因素','价格因素','单列交叉项','账面与价量未解释差额','精度残差','实际成本','可比总差异','因素勾稽差额','全桥勾稽差额'],[JSON.stringify(scope.slice(0,4)),'2','1300','140','1440','20','160','20','0','0','1640','200','0','0']]});
 const steps=['原标准','产出/允许量调整','用量因素','价格因素','单列交叉项','精度残差','账面未解释差额'];const stepsRows:string[][]=[];
 for(const [id,amounts,cumulative] of [['S-A',['1000','200','50','240','10','0','0'],['1000','1200','1250','1490','1500','1500','1500']],['S-B',['300','-60','-30','-80','10','0','0'],['300','240','210','130','140','140','140']]] as const)for(let i=0;i<7;i++)stepsRows.push([id,steps[i],amounts[i],cumulative[i]]);
 expected.push({name:'桥接步骤',matrix:[['标准记录ID','步骤','变动/起点','累计成本'],...stepsRows]},{name:'例外',matrix:[['角色','原因','源文件','页签','原行','原值']]},{name:'覆盖',matrix:[['角色','源文件','页签','原行','状态','关联标准ID'],...input.flatMap(x=>x.rows.map((_,i)=>[x.name,'完全虚构-'+x.role+'.csv',x.role,String(i+2),'已比较',JSON.stringify([i?'S-B':'S-A'])]))]},{name:'复核',matrix:[['标准ID','复核说明'],['S-A','虚构审核：耗用凭据已追查']]},{name:'允许量覆盖',matrix:[['标准ID','允许量','依据']]});
 assert.deepEqual(book.sheets.map(s=>s.name),expected.map(s=>s.name));let cells=0;for(let i=0;i<expected.length;i++){const m=book.sheets[i].matrix.map(row=>row.map(v=>String(v??'')));assert.deepEqual(m,expected[i].matrix,expected[i].name+' independent literal oracle');cells+=m.reduce((n,row)=>n+row.length,0)}return cells;
}
