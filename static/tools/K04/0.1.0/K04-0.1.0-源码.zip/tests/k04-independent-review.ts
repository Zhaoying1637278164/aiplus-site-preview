import assert from 'node:assert/strict';
import {writeFileSync, mkdirSync, readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import ExcelJS from 'exceljs';
import {fresh, columns, calculate, approve, reviewed, invalidate, type Role, type State} from '../tools/K04-存货盘点差异/src/engine';
import {encodeWork,decodeWork} from '../tools/K04-存货盘点差异/src/work';
import {exportWorkbook} from '../tools/K04-存货盘点差异/src/export';

// Literal expectations are hand calculated; fixtures do not use the tool's example generator.
function table(role:Role, cells:Record<string,unknown>[]) {
 const file=`root-${role}.csv`, sheet='CSV';
 return {file,sheet,headers:columns[role],rows:cells.map((cells,i)=>({file,sheet,row:i+2,cells}))} as any;
}
function row(item:string,quantity:string,extra:Record<string,unknown>={}) {
 return {'主体':'虚构甲公司','仓库':'虚构一仓','物料':item,'批次':'无批次','库位':'虚构库位','截止日':'2026-09-30','币种':'CNY','单位':'件','数量':quantity,...extra};
}
function fixture():State {
 const s=fresh();
 s.data.book=table('book',[
 row('A','100',{'单位成本':'2.5','成本依据':'虚构采购成本'}),
 row('B','20',{'单位成本':'3','成本依据':'虚构采购成本'}),
 row('Z','0',{'单位成本':'0','成本依据':'虚构零成本依据'}),
 row('C','7',{'单位成本':'1','成本依据':'虚构采购成本'}),
 row('E','10',{'单位成本':null,'成本依据':null})]);
 s.data.count=table('count',[
 row('A','9',{'单位':'箱','盘点行ID':'a','分区':'一区'}),
 row('B','25',{'盘点行ID':'b','分区':'一区'}),
 row('Z','0',{'盘点行ID':'z','分区':'一区'}),
 row('D','4',{'盘点行ID':'d','分区':'一区'}),
 row('E','12',{'盘点行ID':'e','分区':'一区'})]);
 s.data.conversion=table('conversion',[{'物料':'A','原单位':'箱','目标单位':'件','比例':'10','依据':'虚构每箱10件'}]);
 return s;
}
const checks:string[]=[];
const s=fixture(), r=calculate(s);
const expected:Record<string,unknown[]>={A:['100','90','-10','-25.00'],B:['20','25','5','15.00'],Z:['0','0','0','0.00'],C:['7',null,null,null],D:[null,'4',null,null],E:['10','12','2',null]};
for(const i of r.items) assert.deepEqual([i.book,i.actual,i.difference,i.amount],expected[i.dims[2]]);
assert.equal(r.money.amount,'-10.00');assert.equal(r.money.unvalued,3);
assert.deepEqual(r.summary,[{unit:'件',book:'130',actual:'127',difference:'-3',residual:'0',items:4}]);
assert.equal(r.lines.length,10);assert.equal(r.items.find(i=>i.dims[2]==='A')!.lines[1].source.cells['数量'],'9');
checks.push('six literal item answers, unknowns, totals, unit conversion and raw source conservation');

const rounds=fresh();
rounds.data.book=table('book',['X','Y','Z'].map(i=>row(i,'0',{'单位成本':'0.335','成本依据':'虚构成本'})));
rounds.data.count=table('count',['X','Y','Z'].map(i=>row(i,'1',{'盘点行ID':i,'分区':'一区'})));
const money=calculate(rounds).money;
assert.deepEqual([money.exact,money.amount,money.roundedExact,money.roundingResidual],['1.005','1.02','1.01','0.01']);
checks.push('three independent 0.335 lines: 1.02 line sum, 1.005 exact, 0.01 residual');

let review=approve(s,r.items.find(i=>i.dims[2]==='A')!.key,'虚构财务','独立盘点依据');
const restored=decodeWork(encodeWork(review,true));assert(reviewed(restored,calculate(restored).items.find(i=>i.dims[2]==='A')!));
review=invalidate(review,'更换实盘',true);assert.equal(Object.keys(review.reviews).length,0);assert.equal(review.events.at(-1)!.action,'失效');
const onlyRules=decodeWork(encodeWork(restored,false));assert.equal(onlyRules.data.book,null);assert.equal(onlyRules.events.length,0);
checks.push('actual state restore recomputation and review invalidation; rules-only no data');

const bad=fixture();bad.data.count!.rows[0].cells['数量']=null;
assert.equal(calculate(bad).items.find(i=>i.dims[2]==='A')!.amount,null);
const mixed=fixture();mixed.data.count!.rows[1].cells['币种']='USD';
assert.equal(calculate(mixed).items.find(i=>i.dims[2]==='B')!.difference,null);
checks.push('missing quantity and mixed currency cannot yield usable differences');

const repeated=fixture();
const original=repeated.data.count!.rows[1];
repeated.data.count!.rows.push({...original,row:7,cells:{...original.cells,'数量':'24','盘点行ID':'b-recount'}});
const bkey=r.items.find(i=>i.dims[2]==='B')!.key;
assert.equal(calculate(repeated).items.find(i=>i.key===bkey)!.difference,null);
repeated.decisions[bkey]={mode:'recount',selected:['b-recount'],reviewer:'虚构审批人',basis:'虚构重盘'};
const ri=calculate(repeated).items.find(i=>i.key===bkey)!;
assert.equal(ri.difference,'4');assert.equal(ri.amount,'12.00');assert.equal(ri.lines.filter(l=>!l.used).length,1);
repeated.data.count!.rows[1].cells['数量']='bad';
assert.equal(calculate(repeated).items.find(i=>i.key===bkey)!.amount,null);
checks.push('approved unique recount retains original; bad rejected count row blocks');

const bytes=await exportWorkbook(s);const book=new ExcelJS.Workbook();await book.xlsx.load(bytes as any);
assert.equal(book.worksheets.length,12);
const sheet=book.getWorksheet('盘差明细')!;
for(let n=2;n<=sheet.rowCount;n++) {
 const key=JSON.parse(String(sheet.getRow(n).getCell(1).value));
 const item=expected[key[2]];
 for(const [column,value] of [[3,item[0]],[4,item[1]],[5,item[2]],[9,item[3]]] as const)
  { const actual=sheet.getRow(n).getCell(column).value; assert.equal(actual===''?null:actual??null,value); }
}
assert.equal(book.getWorksheet('原始实盘清单')!.getRow(2).getCell(12).value,'9');
checks.push('actual twelve-sheet workbook readback with 24 literal financial cells and raw count');

const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const out='progress/evidence/K04/0.1.0';mkdirSync(out,{recursive:true});
writeFileSync(`${out}/root-independent-review.json`,JSON.stringify({tool:'K04',date:'2026-10-04',expected_origin:'hand arithmetic and literal fixtures, not tool example or output',checks,passed:true,engine_sha256:hash('tools/K04-存货盘点差异/src/engine.ts'),script_sha256:hash('tests/k04-independent-review.ts'),limits:['not official package/offline/website acceptance']},null,2));
console.log(JSON.stringify({passed:true,groups:checks.length,financial_cells:24}));
