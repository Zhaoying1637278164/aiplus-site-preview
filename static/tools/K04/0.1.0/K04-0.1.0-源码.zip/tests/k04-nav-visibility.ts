import {chromium} from 'playwright';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const results=[];
try {
 const context=await browser.newContext({offline:true,viewport:{width:1440,height:1000}});
 const page=await context.newPage();
 await page.goto('file://'+path.resolve('progress/evidence/K04/0.1.0/candidate/index.html'));
 const names=['盘点范围','账面存货','实盘清单','物料与单位','重复盘点','盘盈盘亏','财务复核','盘点底稿','使用说明与模板'];
 for(const width of [1440,390,320]) {
  await page.setViewportSize({width,height:1000});
  for(let i=0;i<names.length;i++) {
  await page.getByRole('button',{name:`${i+1}. ${names[i]}`,exact:true}).click();
  await page.getByRole('heading',{name:names[i],exact:true,level:2}).waitFor();
  if(i===8)await page.getByRole('button',{name:'下载模板.xlsx',exact:true}).waitFor();
  await page.evaluate(()=>scrollTo(0,0));
  const geometry=await page.locator('.k04 nav').evaluate(nav=>{
   const active=nav.querySelector('button.active')!;
   const n=nav.getBoundingClientRect(),a=active.getBoundingClientRect();
   return {navLeft:n.left,navRight:n.right,activeLeft:a.left,activeRight:a.right,scrollLeft:nav.scrollLeft,clientWidth:nav.clientWidth,scrollWidth:nav.scrollWidth,activeText:active.textContent,fullyVisible:a.left>=n.left-1&&a.right<=n.right+1};
  });
  results.push({width,page:i+1,...geometry});
  }
 }
 await context.close();
 await writeFile('progress/evidence/K04/0.1.0/root-nav-visibility.json',JSON.stringify({scope:'candidate only; actual selected navigation geometry',results,passed:results.every(x=>x.fullyVisible)},null,2));
 console.log(JSON.stringify(results));
} finally {await browser.close()}
