// Re-run unchanged complete work validators and all version downloads on the public website.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {spawn} from 'node:child_process';import path from 'node:path';
import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
const id=process.argv[2],mode=process.argv[3]||'work';assert(['P04','T01','T02'].includes(id));assert(['work','downloads'].includes(mode));
const root=process.cwd(),out=path.resolve(`progress/evidence/${id}/0.1.0/site-public/${mode==='work'?'full-native-work':'all-version-downloads'}`);await mkdir(out,{recursive:true});
const sourcePath=mode==='work'?`tests/${id.toLowerCase()}-native-site.ts`:'tests/new-tools-native-downloads.ts';
const original=await readFile(sourcePath,'utf8'),sha=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
let source=original,executed=path.resolve(sourcePath),resultDir=out;
if(mode==='downloads'){
 const marker="assert.equal(await frame.locator('.bignum').innerText(),String(total));";assert(source.includes(marker));
 const binding=`const publicDoc=await page.locator('iframe').first().getAttribute('srcdoc');assert(publicDoc);assert.equal(sha(Buffer.from(publicDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')),'exact public document');await writeFile(out+'/public-srcdoc.html',publicDoc);`;
 source=source.replace(marker,marker+binding).replace(/from 'playwright'/g,`from '${path.join(root,'node_modules/playwright/index.mjs')}'`).replace("const pending=page.waitForEvent('download');","await page.waitForTimeout(1100);const pending=page.waitForEvent('download');");
 executed=path.join('/private/tmp',`${id.toLowerCase()}-public-downloads-${Date.now()}.mts`);await writeFile(executed,source);resultDir=path.join(out,id,'downloads');
}
await writeFile(out+'/executed-public-validator.ts',source);
const code=await new Promise<number>((resolve,reject)=>{const child=spawn(process.execPath,['--import','tsx',executed,...(mode==='downloads'?[id]:[])],{cwd:root,env:{...process.env,AIPLUS_NATIVE_SITE_URL:'https://aiplus-guance.streamlit.app/~/+'+(mode==='downloads'?'/':''),AIPLUS_EVIDENCE_DIR:out},stdio:'inherit'});child.on('error',reject);child.on('exit',x=>resolve(x??1));});
await writeFile(out+'/execution.json',JSON.stringify({tool:id,mode,exit_code:code,host:'https://aiplus-guance.streamlit.app/~/+/',source_validator:sourcePath,source_validator_sha256:sha(original),executed_validator_sha256:sha(source),finance_assertions_preserved:true,substitutions:mode==='work'?['public host via environment','public evidence path via environment']:['public host','public evidence path','absolute playwright import','additional exact public srcdoc assertion','download pacing'],result_directory:path.relative(root,resultDir)},null,2)+'\n');
if(code===0){const file=resultDir+'/result.json',result=JSON.parse(await readFile(file,'utf8'));result.official_website=true;result.public_site_verified=true;result.actual_root_exit_code=0;result.scope='actual public original website; all complete original financial and file assertions preserved';await writeFile(file,JSON.stringify(result,null,2)+'\n');}process.exitCode=code;
