// Actual deployment readiness; financial/archive acceptance remains separate.
import {chromium} from 'playwright';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const out='progress/evidence/K03/0.1.0/site-public/deploy-probe';await mkdir(out,{recursive:true});
const sha=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
const siteSHA=sha(await readFile('integration/native-site/site/index.html'));
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
try{
 const context=await browser.newContext({viewport:{width:1440,height:1000}});context.setDefaultTimeout(120000);
 const page=await context.newPage();const runtime=page.waitForResponse(r=>r.url().endsWith('/K03/0.1.0/runtime.json'));
 await page.goto('https://aiplus-guance.streamlit.app/~/+/?tool=K03');
 await page.waitForFunction(async expected=>{
  const doc=document.querySelector('iframe')?.getAttribute('srcdoc');if(!doc)return false;
  const normalized=doc.replace(/<script>window\.__AIPlusInitialRoute=[\s\S]*?<\/script>/,'');
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(normalized));
  return Array.from(new Uint8Array(digest)).map(n=>n.toString(16).padStart(2,'0')).join('')===expected;
 },siteSHA,{timeout:120000});
 const actualRuntimeSHA=sha(await (await runtime).body());assert.equal(actualRuntimeSHA,sha(await readFile('release/K03/0.1.0/runtime.json')));
 const iframe=page.locator('iframe').first(),doc=await iframe.getAttribute('srcdoc');assert(doc);await writeFile(out+'/actual-srcdoc.html',doc);
 const frame=await (await iframe.elementHandle())!.contentFrame();assert(frame);await frame.locator('.k03').waitFor();assert.equal(await frame.locator('iframe').count(),0);
 const images=[];for(const width of [1440,390]){await page.setViewportSize({width,height:1000});const file=`initial-${width}.png`;await page.screenshot({path:out+'/'+file});images.push({file,sha256:sha(await readFile(out+'/'+file))})}
 await writeFile(out+'/result.json',JSON.stringify({passed:true,siteSHA,actualRuntimeSHA,images,scope:'Actual deployed srcdoc and public program exact SHA; two original-site viewport images only; financial and archives separate'},null,2));console.log('Actual public K03 document and runtime match final stage');
}catch(e){await writeFile(out+'/failure.json',JSON.stringify({error:String(e),expectedSiteSHA:siteSHA},null,2));throw e}finally{await browser.close()}
