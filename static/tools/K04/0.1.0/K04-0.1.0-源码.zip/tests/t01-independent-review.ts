// Root re-execution of explicit independent arithmetic, unchanged financial expectations.
// All expected values here are handwritten arithmetic, never copied from calculate output.
import assert from 'node:assert/strict';
import {writeFile,mkdir} from 'node:fs/promises';
import {example} from '../tools/T01-银行对账台/src/example';
import {calculate} from '../tools/T01-银行对账台/src/engine';
import {reconciled} from '../tools/T01-银行对账台/tests/fixtures';
import {confirmAllocation,revokeAllocation,decode,encode} from '../tools/T01-银行对账台/src/work';
const checks:string[]=[];
const w=example(),a=calculate(w);
assert.equal(a.book.income,'250');assert.equal(a.book.expense,'150');assert.equal(a.book.expected,'1000');assert.equal(a.bank.income,'300');assert.equal(a.bank.expense,'150');assert.equal(a.bank.expected,'1050');checks.push('900+250-150=1000_and_900+300-150=1050');
assert.equal(a.book.unclassified,'400');assert.equal(a.bank.unclassified,'450');assert.equal(a.complete,false);checks.push('before_matching_all_flow_400_and_450_unclassified_incomplete');
const r=calculate(reconciled());assert.deepEqual(Object.values(r.totals),['150','50','200','50']);assert.equal(r.book.adjusted,'1150');assert.equal(r.bank.adjusted,'1150');assert.equal(r.difference,'0');checks.push('1000+200-50=1150_and_1050+150-50=1150');
let p=confirmAllocation(w,{id:'P1',bank:'bank-1',book:'book-1',amount:'60',date:'2026-01-31',basis:'独立虚构依据',revokeDate:'',revokeBasis:''});assert.equal(calculate(p).rows[0].remaining,'40');p=confirmAllocation(p,{...p.allocations[0],id:'P2',amount:'40'});assert.equal(calculate(p).rows[0].remaining,'0');p=revokeAllocation(p,1,'2026-01-31','撤销手算依据');assert.equal(calculate(p).rows[0].remaining,'40');checks.push('100-60-40=0_then_revoke40_restores40_on_both_ends');
w.balances.bank.closing='';assert.equal(calculate(w).bank.adjusted,null);checks.push('missing_bank_closing_unknown');
w.balances.bank.closing='1050';w.rows.bank[0].values[7]='';assert.equal(calculate(w).rows[0].remaining,null);checks.push('missing_transaction_amount_remaining_unknown');
const z=example();z.scope.precision=1;z.rows.bank[0].values[7]='0.01';assert.equal(calculate(z).rows[0].status,'无效');checks.push('precision1_cannot_silently_round_0.01');
const n=decode(encode(reconciled(),false));assert.equal(n.rows.bank.length,0);assert.equal(n.events.length,0);assert.equal(n.balances.bank.closing,'');assert.equal(n.baseline,null);checks.push('no_data_restore_clears_financial_inputs');
await mkdir('progress/evidence/T01',{recursive:true});await writeFile('progress/evidence/shared/2026-10-04-T01-independent-review.json',JSON.stringify({passed:true,expectations:'handwritten in 规格与独立预期.md before engine implementation',checks},null,2));console.log(JSON.stringify({passed:true,checks:checks.length}));
