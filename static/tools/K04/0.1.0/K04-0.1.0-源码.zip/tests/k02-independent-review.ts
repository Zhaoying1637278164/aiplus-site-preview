import assert from 'node:assert/strict';
import {writeFile,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {calculate,defaultFields,defaultRule,columns,type Data,type Role,type Rule} from '../tools/K02-成本差异分析/src/engine';
import {encodeWork,decodeWork} from '../tools/K02-成本差异分析/src/work';
import type {Table} from '../packages/core/types';

// Independent fictitious oracle: 80 × 1.5 × 12 = 1440 baseline;
// output 100 allows 150, standard 1800; 90 × 13 + 75 × 14 = 2220.
// Total variance 420 = quantity 180 + price 240. No tested result generates expectations.
const scope=['根独立虚构厂','2026-09','CNY','元','件'];
function table(role:Role,rows:unknown[][]):Table{return {file:'根独立-'+role+'.csv',sheet:role,headers:columns[role],rows:rows.map((cells,i)=>({file:'根独立-'+role+'.csv',sheet:role,row:i+2,cells:Object.fromEntries(columns[role].map((h,k)=>[h,cells[k]??null]))}))} as Table}
function data():Data{return {
 standard:table('standard',[['STD',...scope,'标准产品','原料','kg','80','1.5','12','V1','虚构批准']]),
 output:table('output',[['OUT',...scope,'生产线','100','虚构产出']]),
 usage:table('usage',[['U1',...scope,'生产线','材料','kg','90','13','虚构领料1'],['U2',...scope,'生产线','材料','kg','75','14','虚构领料2']]),
 mapping:table('mapping',[['MAP',...scope,'生产线','材料','kg','标准产品','原料','虚构对应']])
}}
const rule=():Rule=>({...defaultRule,reviewer:'虚构根复核人',basis:'本批次独立虚构手算批准',overrides:[]}),fields=defaultFields();
const checks:string[]=[],failures:{name:string;error:string}[]=[];
function check(name:string,fn:()=>void){try{fn();checks.push(name)}catch(e){failures.push({name,error:String(e)})}}
const run=(d=data(),r=rule())=>calculate(d,fields,r);
check('实际产出允许量、逐笔成本及两段桥接手算',()=>{const d=run().details[0];for(const [k,v] of Object.entries({baseline:'1440',outputEffect:'360',standard:'1800',actual:'2220',allowed:'150',actualQuantity:'165',variance:'420',quantityEffect:'180',priceEffect:'240',check:'0',bridgeCheck:'0'}))assert.equal(d[k as keyof typeof d],v,k)});
check('先价后量保留12位均价精度残差',()=>{const d=run(data(),{...rule(),method:'price-first'}).details[0];assert.equal(d.actualPrice,'13.454545454545');assert.equal(d.priceEffect,'218.18181818175');assert.equal(d.quantityEffect,'201.818181818175');assert.equal(d.residual,'0.000000000075');assert.equal(d.crossEffect,'0');assert.equal(d.bridgeCheck,'0')});
check('交叉单列且只加一次',()=>{const d=run(data(),{...rule(),method:'separate'}).details[0];assert.equal(d.quantityEffect,'180');assert.equal(d.priceEffect,'218.18181818175');assert.equal(d.crossEffect,'21.818181818175');assert.equal(d.residual,'0.000000000075');assert.equal(d.check,'0')});
check('独立账面7元未解释差额不得强归价量',()=>{const d=data();d.usage!.rows[0].cells['账面成本']='1177';d.usage!.rows[1].cells['账面成本']='1050';const v=run(d).details[0];assert.equal(v.actual,'2227');assert.equal(v.variance,'427');assert.equal(v.unexplained,'7');assert.equal(v.priceEffect,'240');assert.equal(v.bridgeCheck,'0')});
check('账面部分缺失整组阻塞',()=>{const d=data();d.usage!.rows[0].cells['账面成本']='1177';assert.equal(run(d).details.length,0)});
check('允许量覆盖保留批准依据及新的产出因素',()=>{const d=run(data(),{...rule(),overrides:[{id:'STD',quantity:'160',basis:'虚构复核依据'}]}).details[0];assert.equal(d.standard,'1920');assert.equal(d.outputEffect,'480');assert.equal(d.variance,'300');assert.equal(d.quantityEffect,'60');assert.equal(d.priceEffect,'240')});
check('零耗用价格缺失仍保留完整用量差异',()=>{const d=data();d.usage!.rows.forEach(r=>r.cells['实际耗用']='0');const v=run(d).details[0];assert.equal(v.actual,'0');assert.equal(v.actualPrice,null);assert.equal(v.quantityEffect,'-1800');assert.equal(v.priceEffect,'0');assert.equal(v.bridgeCheck,'0')});
check('一行空耗用不以其他有效行冒充全额',()=>{const d=data();d.usage!.rows[1].cells['实际耗用']='';assert.equal(run(d).details.length,0)});
check('负耗用不自动冲销',()=>{const d=data();d.usage!.rows[1].cells['实际耗用']='-75';assert.equal(run(d).details.length,0)});
check('重复耗用ID整组阻塞',()=>{const d=data();d.usage!.rows[1].cells['记录ID']='U1';assert.equal(run(d).details.length,0)});
check('跨币种及期间不得拼接成本',()=>{for(const [column,value] of [['币种','USD'],['期间','2026-08']]){const d=data();d.usage!.rows.forEach(r=>r.cells[column]=value);assert.equal(run(d).details.length,0)}});
check('显示精度和容差不改变财务结果',()=>{const a=run(data(),{...rule(),method:'separate',digits:0,tolerance:'100'}).details[0],b=run(data(),{...rule(),method:'separate',digits:6,tolerance:'0'}).details[0];for(const k of ['variance','residual','quantityEffect','priceEffect','crossEffect','check'] as const)assert.equal(a[k],b[k])});
check('全部五行来源与两笔耗用原行保留',()=>{const r=run();assert.equal(r.details[0].sources.length,5);assert.deepEqual(r.details[0].sources.filter(s=>s.role==='usage').map(s=>s.source.row),[2,3]);assert.equal(r.coverage.length,5);assert.ok(r.coverage.every(c=>c.status==='已比较'))});
check('含无数据恢复及夹带资料拒绝',()=>{const d=data(),full=decodeWork(encodeWork(d,fields,rule(),{},true));assert.deepEqual(full.data,d);assert.equal(run(full.data!).details[0].variance,'420');const plan=decodeWork(encodeWork(d,fields,rule(),{},false));assert.equal(plan.contains_data,false);assert.equal(plan.data,undefined);assert.throws(()=>decodeWork(JSON.stringify({...plan,data:d})),/不得夹带/)});
const digest=createHash('sha256').update(await readFile('tools/K02-成本差异分析/src/engine.ts')).digest('hex');
const result={tool:'K02',passed:failures.length===0,checks,failures,engine_sha256:digest,source:'根独立虚构输入与固定手算，不使用本款example或被测输出生成预期',accepted:false};
await writeFile('progress/evidence/K02/0.1.0/root-independent-review.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));if(failures.length)process.exitCode=1;
