// Re-execute complete R02/R03 native validators against the real public host.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {spawn} from 'node:child_process';import path from 'node:path';
import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
const id=process.argv[2],mode=process.argv[3]||'work';assert(['R02','R03'].includes(id));assert(['work','downloads'].includes(mode));
const root=process.cwd(),out=path.resolve(`progress/evidence/${id}/0.1.0/site-public/${mode==='work'?'full-native-work':'all-version-downloads'}`);await mkdir(out,{recursive:true});
const sourcePath=`tests/${id.toLowerCase()}-native-${mode==='work'?'site':'downloads'}.ts`;
const original=await readFile(sourcePath,'utf8'),sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const binding=`const publicDoc=await ${mode==='work'?'shell':'page'}.locator('iframe').first().getAttribute('srcdoc');assert(publicDoc);assert.equal(sha(Buffer.from(publicDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')),'exact public document');await writeFile(${mode==='work'?(id==='R02'?'out':'dir'):'evidence'}+'/public-srcdoc.html',publicDoc);`;
let source=original;
const marker=mode==='downloads'?"assert.equal(await frame.locator('.bignum').innerText(),String(catalogueTotal));":id==='R02'?'assert.ok(loaded);':'assert.ok(page);';assert(source.includes(marker));source=source.replace(marker,marker+binding);
source=source.replace(/from '\.\.\/([^']+)'/g,(_,file)=>`from '${path.join(root,file)}'`).replace(/from 'playwright'/g,`from '${path.join(root,'node_modules/playwright/index.mjs')}'`).replace(/from 'exceljs'/g,`from '${path.join(root,'node_modules/exceljs/excel.js')}'`);
if(mode==='downloads')source=source.replace("const pending=page.waitForEvent('download');","await page.waitForTimeout(1100);const pending=page.waitForEvent('download');");
const temporary=path.join('/private/tmp',`${id.toLowerCase()}-public-${mode}-${Date.now()}.mts`);await writeFile(temporary,source);await writeFile(out+'/executed-public-validator.ts',source);
const code=await new Promise<number>((resolve,reject)=>{const child=spawn(process.execPath,['--import','tsx',temporary],{cwd:root,env:{...process.env,AIPLUS_NATIVE_SITE_URL:'https://aiplus-guance.streamlit.app/~/+'+(mode==='downloads'?'/':''),AIPLUS_EVIDENCE_DIR:out},stdio:'inherit'});child.on('error',reject);child.on('exit',x=>resolve(x??1));});
await writeFile(out+'/execution.json',JSON.stringify({tool:id,mode,exit_code:code,host:'https://aiplus-guance.streamlit.app/~/+/',source_validator:sourcePath,source_validator_sha256:sha(Buffer.from(original)),executed_validator_sha256:sha(Buffer.from(source)),finance_assertions_preserved:true,substitutions:['public host','public evidence path','absolute imports','exact public srcdoc assertion','download pacing']},null,2)+'\n');
if(code===0){const file=out+'/result.json',result=JSON.parse(await readFile(file,'utf8'));result.official_website=true;result.public_site_verified=true;if('official_site_verified' in result)result.official_site_verified=true;result.scope='actual public original website; all original financial and file assertions preserved';result.file_protocol=false;await writeFile(file,JSON.stringify(result,null,2)+'\n');}process.exitCode=code;
