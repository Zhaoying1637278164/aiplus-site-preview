import assert from 'node:assert/strict';
import {writeFileSync,mkdirSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {calculate,defaultFields,defaultRule,columns,type Data,type Role,type Rule} from '../tools/K03-存货库龄与周转/src/engine';
import type {Cell,Table} from '../packages/core/types';
// Root-authored inputs and literal manual answers. No candidate examples or exports.
const base={'主体':'虚构甲','仓库':'虚构库','物料':'虚构料','币种':'CNY','数量单位':'件','金额单位':'元','物料名称':'虚构材料','批次':'B'};
function table(role:Role,rows:Record<string,Cell>[]):Table {const file=`根独立-${role}.csv`;return {file,sheet:role,headers:columns[role],rows:rows.map((cells,i)=>({file,sheet:role,row:i+2,cells:{...base,...cells}}))};}
function ordinary():Data{return {opening:table('opening',[{'记录ID':'O','原入库日':'2025-12-01','数量':'80','成本':'800'}]),moves:table('moves',[{'记录ID':'I','日期':'2026-01-02','顺序':'1','类型':'入库','数量':'40','成本':'480','原单ID':''},{'记录ID':'X','日期':'2026-01-04','顺序':'1','类型':'出库','数量':'20','成本':'200','原单ID':''}]),closing:null};}
const rule:Rule={...defaultRule,cutoff:'2026-01-05',costConfirmed:true};
const run=(d:Data,p:Partial<Rule>={})=>calculate(d,defaultFields(),{...rule,...p});
const results:{name:string;passed:boolean;error?:string;actual?:unknown}[]=[];
function check(name:string,f:()=>unknown){try{results.push({name,passed:true,actual:f()});}catch(e){results.push({name,passed:false,error:String(e)});}}
check('手算期末100件1080元、两来源层60/600与40/480',()=>{const r=run(ordinary());assert.equal(r.stocks[0].closingQty,'100');assert.equal(r.stocks[0].closingCost,'1080');assert.deepEqual(r.ages.map(x=>[x.quantity,x.cost]),[['60','600'],['40','480']]);assert.equal(r.stocks[0].residual,'0');return r.stocks;});
check('五日日末积分：数量104成本1104，周转天数26/27.6',()=>{const t=run(ordinary()).turns[0];assert.equal(t.averageQty,'104');assert.equal(t.averageCost,'1104');assert.equal(t.qtyDays,'26');assert.equal(t.costDays,'27.6');return t;});
check('两端平均：90/940，数量22.5天成本23.5天',()=>{const t=run(ordinary(),{average:'ends'}).turns[0];assert.equal(t.averageQty,'90');assert.equal(t.averageCost,'940');assert.equal(t.qtyDays,'22.5');assert.equal(t.costDays,'23.5');return t;});
check('缺成本阻塞，不补0；来源保留',()=>{const d=ordinary();d.moves!.rows[0].cells['成本']=null;const r=run(d);assert.ok(r.issues.some(x=>x.blocking&&x.source.includes('第2行')));assert.equal(r.turns[0].costDays,null);return r.issues;});
check('币种分组，不混加为一种库存',()=>{const d=ordinary();d.moves!.rows[0].cells['币种']='USD';const r=run(d);assert.equal(r.stocks.length,2);assert.ok(r.stocks.some(x=>x.dims[3]==='USD'&&x.status.includes('阻塞')));return r.stocks;});
const micro:Data={opening:table('opening',Array.from({length:4},(_,i)=>({'记录ID':`O${i+1}`,'原入库日':`2025-12-0${i+1}`,'数量':'1','成本':'1'}))),moves:table('moves',[{'记录ID':'OUT','日期':'2026-01-01','顺序':'1','类型':'出库','数量':'4','成本':'4','原单ID':''},{'记录ID':'RETURN','日期':'2026-01-02','顺序':'1','类型':'销退','数量':'0.000002','成本':'0.000002','原单ID':'OUT'}]),closing:null};
const microResult=run(micro,{returns:true,basis:'虚构四来源层原单退货'});
check('四层微量销退：库龄来源量额合计必须等于2微单位，不能掩盖负层',()=>{assert.equal(microResult.stocks[0].closingQty,'0.000002');assert.equal(microResult.stocks[0].closingCost,'0.000002');const qty=microResult.ages.reduce((s,x)=>s+Math.round(Number(x.quantity)*1e6),0);const cost=microResult.ages.reduce((s,x)=>s+Math.round(Number(x.cost)*1e6),0);assert.equal(qty,2);assert.equal(cost,2);assert.ok(microResult.ages.every(x=>Number(x.quantity)>=0&&Number(x.cost)>=0));return microResult.ages;});
const dir='progress/evidence/K03/0.1.0';mkdirSync(dir,{recursive:true});const sha=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const proof={schema_version:1,at:new Date().toISOString(),script_sha256:sha('tests/k03-independent-review.ts'),engine_sha256:sha('tools/K03-存货库龄与周转/src/engine.ts'),total:results.length,passed:results.filter(x=>x.passed).length,failed:results.filter(x=>!x.passed).length,results,micro_return_actual:{stocks:microResult.stocks,ages:microResult.ages,issues:microResult.issues},expected_source_micro_units:{quantity:2,cost:2},platform:'Mac Node; browser/offline/site not covered'};
writeFileSync(`${dir}/root-independent-review.json`,JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify({total:proof.total,passed:proof.passed,failed:proof.failed,failures:results.filter(x=>!x.passed)}));process.exitCode=proof.failed?1:0;
