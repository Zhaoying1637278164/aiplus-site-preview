// Reuse each exact executed local work validator on the actual public host.
// Host/output substitutions are recorded; no finance assertions are removed.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
const id=process.argv[2];assert(['P01','P02','P03'].includes(id));
const root=process.cwd(),out=`progress/evidence/${id}/0.1.0/site-public/full-native-work`;
await mkdir(out,{recursive:true});
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const original=await readFile(`tests/${id.toLowerCase()}-native-site.ts`,'utf8');
let source=original.replace(`progress/evidence/site-integration/payables-P01-P02-P03/${id}/site-local`,out)
 .replace('http://127.0.0.1:8515/','https://aiplus-guance.streamlit.app/~/+/');
const publicBinding=`assert(f);const publicDoc=await p.locator('iframe').first().getAttribute('srcdoc');assert(publicDoc);const normalizedPublic=publicDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,'');assert.equal(sha(Buffer.from(normalizedPublic)),site,'actual public page must equal published exact site');await writeFile(out+'/public-srcdoc.html',publicDoc);`;
assert(source.includes('assert(f);'));source=source.replace('assert(f);',publicBinding);
source=source.replace(/from '\.\.\/([^']+)'/g,(_,file)=>`from '${path.join(root,file)}'`)
 .replace(/from 'playwright'/g,`from '${path.join(root,'node_modules/playwright/index.mjs')}'`);
const generated=path.join('/private/tmp',`${id.toLowerCase()}-public-native-${Date.now()}.mts`);
await writeFile(generated,source);await writeFile(out+'/executed-public-validator.ts',source);
const started=new Date().toISOString();
const code=await new Promise<number>((resolve,reject)=>{const child=spawn(process.execPath,['--import','tsx',generated],{cwd:root,stdio:'inherit'});child.on('error',reject);child.on('exit',n=>resolve(n??1));});
await writeFile(out+'/execution.json',JSON.stringify({tool:id,started,exit_code:code,host:'https://aiplus-guance.streamlit.app/~/+/',source_validator_sha256:sha(Buffer.from(original)),executed_validator_sha256:sha(Buffer.from(source)),substitutions:['public host','distinct public evidence output','absolute module imports','exact public srcdoc version assertion'],finance_assertions_preserved:true},null,2)+'\n');
if(code===0){const p=out+'/result.json',d=JSON.parse(await readFile(p,'utf8'));d.official_website=true;d.public_url=`https://aiplus-guance.streamlit.app/~/+/?tool=${id}`;d.scope='actual public original website; full local finance/work/download assertions preserved; isolated fictitious data only';await writeFile(p,JSON.stringify(d,null,2)+'\n');}
process.exitCode=code;
