import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import ExcelJS from 'exceljs';
import {columns,calculate,defaultFields,defaultRule,type Data,type Role,type Rule} from '../tools/K05-存货跌价测算/src/engine';
import {exportWorkbook} from '../tools/K05-存货跌价测算/src/export';

// All financial expectations below are literal hand arithmetic, independent of example.ts.
const rule:Rule={...defaultRule,reviewer:'虚构财务复核',basis:'独立虚构期末测算依据',policyConfirmed:true};
const common=(id:string)=>({'存货ID':id,'主体':'虚构公司','期间起日':'2026-09-01','测算日':'2026-09-30','币种':'CNY','金额单位':'元','数量单位':'件'});
function table(role:Role, records:Record<string,unknown>[]) {
 const file=`root-${role}.csv`,sheet='CSV';
 return {file,sheet,headers:columns[role],rows:records.map((cells,i)=>({file,sheet,row:i+2,cells}))} as any;
}
function fixture():Data {
 const cost={...common('X'),'物料名称':'虚构物料','成本口径':'原始成本','成本值':'100','测算前准备':'30','期初数量':'12','增加数量':'0','发出数量':'2','其他数量变动':'0','期末数量':'10','数量变动依据':'虚构12减2','成本依据':'虚构采购底稿'};
 const movement={...common('X'),'期初准备':'40','本期已计提':'0','本期已转回':'0','处置转销':'10','其他准备变动':'0','测算前准备':'30','变动依据':'虚构处置准备10'};
 const segment=(id:string,q:string,price:string,limit:string,kind:string)=>({...common('X'),'依据ID':id,'数量':q,'估计售价':price,'单位完工成本':'0','单位销售费用':'0','单位相关税费':'0','价格基础':kind,'用途':'直接出售','材料判断':'','依据日期':'2026-09-30','净值依据':'虚构合同及一般售价','可转回上限':limit,'因素消失':'是','转回依据':'虚构因素消失，已核实上限'});
 return {cost:table('cost',[cost]),movement:table('movement',[movement]),estimate:table('estimate',[segment('合同','6','8','6','合同价格'),segment('非合同','4','12','4','一般售价')])};
}
const calc=(d:Data,r:Rule=rule)=>calculate(d,defaultFields(),r);
const checks:string[]=[];
const input=fixture(),r=calc(input),answer={cost:'100',rawNRV:'96',nrv:'96',required:'4',existing:'30',candidateReverse:'26',limit:'10',addition:'0',reversal:'10',pending:'16',final:'20',net:'80',opening:'40',disposal:'10',movementCheck:'0'};
assert.equal(r.issues.length,0);assert.equal(r.details.length,1);
for(const [key,value] of Object.entries(answer))assert.equal((r.details[0] as any)[key],value,key);
assert.equal(r.coverage.length,4);assert.equal(r.details[0].sources.length,4);
assert.equal(input.cost!.rows[0].cells['成本值'],'100');
checks.push('contract 6×8 plus general 4×12 = 96; capped reversal10 pending16 final20 net80 and four sources');

const net=fixture();net.cost!.rows[0].cells['成本口径']='已扣准备净额';net.cost!.rows[0].cells['成本值']='70';
assert.deepEqual(calc(net).summaries,r.summaries);
checks.push('net70 plus existing30 restores100 and provision deducted once');

const denied=fixture();denied.estimate!.rows[1].cells['因素消失']='否';denied.estimate!.rows[1].cells['转回依据']='';
const d=calc(denied).details[0];assert.deepEqual([d.reversal,d.pending,d.final,d.net],['0','26','30','70']);
checks.push('one segment has no reversal basis: zero reversal, pending26 retained');

const negative=fixture();for(const row of negative.estimate!.rows){row.cells['估计售价']='0';row.cells['单位完工成本']='2';}
const n=calc(negative).details[0];assert.deepEqual([n.rawNRV,n.nrv,n.required,n.addition,n.final,n.net,n.negativeNRV],['-20','0','100','70','100','0',true]);
checks.push('negative raw net value -20 retained, approved zero floor, provision100');

for(const mutation of ['bad bridge','bad amount unit','missing preparation','bad unselected duplicate']) {
 const bad=fixture();
 if(mutation==='bad bridge')bad.movement!.rows[0].cells['其他准备变动']='1';
 if(mutation==='bad amount unit')bad.estimate!.rows[0].cells['金额单位']='万元';
 if(mutation==='missing preparation')bad.movement!.rows=[];
 if(mutation==='bad unselected duplicate')bad.cost!.rows.push({...bad.cost!.rows[0],row:3,cells:{...bad.cost!.rows[0].cells,'成本值':null}});
 const result=calc(bad);assert.equal(result.details.length,0,mutation);assert(result.issues.length>0,mutation);
}
checks.push('bridge error, mixed amount units, missing preparation and invalid duplicate all block');

const decimal=fixture();const c=decimal.cost!.rows[0].cells,m=decimal.movement!.rows[0].cells,e=decimal.estimate!.rows[0].cells;
Object.assign(c,{'成本值':'1','测算前准备':'0','期初数量':'3','发出数量':'0','期末数量':'3'});
Object.assign(m,{'期初准备':'0','处置转销':'0','测算前准备':'0'});
Object.assign(e,{'数量':'3','估计售价':'0.333333','可转回上限':'0'});decimal.estimate!.rows=[decimal.estimate!.rows[0]];
const dec=calc(decimal,{...rule,digits:0}).details[0];assert.deepEqual([dec.rawNRV,dec.required,dec.final,dec.net],['0.999999','0.000001','0.000001','0.999999']);
checks.push('3×0.333333 and 0.000001 provision retained even display precision zero');

const group=fixture();
for(const role of ['cost','movement','estimate'] as Role[]) {
 const old=group[role]!.rows[0];group[role]!.rows=[0,1].map(i=>({...old,row:i+2,cells:{...old.cells,'存货ID':i?'B':'A'}}));
}
for(let i=0;i<2;i++) {
 Object.assign(group.cost!.rows[i].cells,{'测算前准备':'10','期初数量':'10','发出数量':'0'});
 Object.assign(group.movement!.rows[i].cells,{'期初准备':'10','处置转销':'0','测算前准备':'10'});
 Object.assign(group.estimate!.rows[i].cells,{'依据ID':i?'eb':'ea','数量':'10','估计售价':i?'15':'5','可转回上限':'5'});
}
assert.deepEqual(calc(group).details.map(x=>[x.required,x.final,x.net]),[['50','50','50'],['0','5','95']]);
const g=calc(group,{...rule,groups:[{id:'虚构经批准类别',members:['A','B'],condition:'数量繁多单价低',basis:'虚构明确批准类别条件'}]}).details[0];
assert.deepEqual([g.cost,g.rawNRV,g.required,g.reversal,g.pending,g.final,g.net],['200','200','0','10','10','10','190']);
assert.deepEqual(g.members,['A','B']);assert.equal(g.sources.length,6);
checks.push('group comparison differs from individual: approved group final10, no automatic item allocation');

const bytes=await exportWorkbook(r),wb=new ExcelJS.Workbook();await wb.xlsx.load(bytes as any);
assert.equal(wb.worksheets.length,15);const sheet=wb.getWorksheet('测算明细')!;
const headings=sheet.getRow(1).values as unknown[];
const workbookExpected:Record<string,string>={'还原成本':'100','原始净值':'96','要求准备':'4','测算前准备':'30','候选转回':'26','可转回上限':'10','新增计提':'0','允许转回':'10','待批准转回差额':'16','最终准备':'20','期末净额':'80','期初准备':'40','处置转销':'10','准备桥接差额':'0'};
for(const [heading,value] of Object.entries(workbookExpected)){const col=headings.indexOf(heading);assert(col>0);assert.equal(sheet.getRow(2).getCell(col).value,value,heading);}
assert.equal(wb.getWorksheet('全行覆盖')!.rowCount,5);assert.equal(wb.getWorksheet('来源索引')!.rowCount,5);
checks.push('actual fifteen-sheet export readback: fourteen literal monetary fields and all four raw sources');

const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const out='progress/evidence/K05/0.1.0';mkdirSync(out,{recursive:true});
writeFileSync(`${out}/root-independent-review.json`,JSON.stringify({tool:'K05',passed:true,expected_origin:'manual independent fixture, no example.ts or copied output',checks,exported_financial_cells:14,engine_sha256:hash('tools/K05-存货跌价测算/src/engine.ts'),script_sha256:hash('tests/k05-independent-review.ts'),not_accepted:true},null,2));
console.log(JSON.stringify({passed:true,groups:checks.length,exported_financial_cells:14}));
