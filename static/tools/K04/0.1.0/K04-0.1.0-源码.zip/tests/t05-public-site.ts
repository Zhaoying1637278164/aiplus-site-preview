// Execute reviewed T05 assertions on actual public website, preserve exact source.
import {readFile,writeFile,mkdir} from 'node:fs/promises';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {spawnSync} from 'node:child_process';
const mode=process.argv[2]||'work';assert.ok(['work','downloads'].includes(mode));const root=process.cwd(),out=path.resolve('progress/evidence/T05/0.1.0/site-public',mode);await mkdir(out,{recursive:true});
const source=path.resolve('tests/t05-native-'+(mode==='work'?'site':'downloads')+'.ts'),original=await readFile(source,'utf8');let text=original;
text=text.replace(/from '([^']+)'/g,(all,s)=>s.startsWith('.')?'from '+JSON.stringify(path.resolve('tests',s)):all);
if(mode==='downloads'){
 const target="await page.goto(host);const frame=page.frameLocator('iframe').first();";assert.ok(text.includes(target));
 text=text.replace(target,target+"await page.locator('iframe').first().waitFor({timeout:120000});const actualDoc=await page.locator('iframe').first().getAttribute('srcdoc');assert(actualDoc);assert.equal(sha(Buffer.from(actualDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')));await writeFile(out+'/actual-srcdoc.html',actualDoc);");
 text=text.replace('const pending=page.waitForEvent(\'download\');','await page.waitForTimeout(1100);const pending=page.waitForEvent(\'download\');');
}
const executed=out+'/executed-public-validator.ts';await writeFile(executed,text);const url=mode==='work'?'https://aiplus-guance.streamlit.app/~/+':'https://aiplus-guance.streamlit.app/~/+/';
const run=spawnSync(process.execPath,['--import','tsx',executed,...(mode==='downloads'?['T05']:[])],{cwd:root,env:{...process.env,AIPLUS_NATIVE_SITE_URL:url,AIPLUS_EVIDENCE_DIR:out},encoding:'utf8'});await writeFile(out+'/command.log',(run.stdout||'')+(run.stderr||''));
const sha=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');await writeFile(out+'/execution.json',JSON.stringify({mode,url,actual_root_exit_code:run.status,financial_assertions_preserved:true,source_validator_sha256:sha(original),executed_validator_sha256:sha(text),expected_site_sha256:sha(await readFile('integration/native-site/site/index.html')),public_browser:true,allowed_transformations:'relative imports absolute; downloads exact srcdoc assertion and1100ms pacing only'},null,2));console.log(run.stdout);if(run.status!==0){console.error(run.stderr);process.exit(run.status||1)}
