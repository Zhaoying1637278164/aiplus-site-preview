// Actual public R04/R05 workflow, preserving all original financial assertions.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
const id=process.argv[2];assert(['R04','R05'].includes(id));
const out=`progress/evidence/${id}/0.1.0/site-public/full-native-work`,root=process.cwd();await mkdir(out,{recursive:true});
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const original=await readFile('tests/r04-r05-native-site.ts','utf8');
let source=original.replace("path.resolve(suite+'/'+id+'/site-local')",JSON.stringify(path.resolve(out)));
const marker='assert.ok(frame);';assert(source.includes(marker));
source=source.replace(marker,marker+`const publicDoc=await shell.locator('iframe').first().getAttribute('srcdoc');assert(publicDoc);const normalized=publicDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,'');assert.equal(sha(Buffer.from(normalized)),siteSha,'actual public document must equal published version');await writeFile(out+'/public-srcdoc.html',publicDoc);`);
source=source.replace(/from '\.\.\/([^']+)'/g,(_,file)=>`from '${path.join(root,file)}'`).replace(/from 'playwright'/g,`from '${path.join(root,'node_modules/playwright/index.mjs')}'`);
source=source.replace('await link.click();','await shell.waitForTimeout(1100);await link.click();');
const temp=path.join('/private/tmp',`${id.toLowerCase()}-public-native-${Date.now()}.mts`);await writeFile(temp,source);await writeFile(out+'/executed-public-validator.ts',source);
const code=await new Promise<number>((resolve,reject)=>{const child=spawn(process.execPath,['--import','tsx',temp,id],{cwd:root,env:{...process.env,AIPLUS_NATIVE_SITE_URL:'https://aiplus-guance.streamlit.app/~/+'},stdio:'inherit'});child.on('error',reject);child.on('exit',x=>resolve(x??1));});
await writeFile(out+'/execution.json',JSON.stringify({tool:id,exit_code:code,host:'https://aiplus-guance.streamlit.app/~/+/',source_validator_sha256:sha(Buffer.from(original)),executed_validator_sha256:sha(Buffer.from(source)),finance_assertions_preserved:true,substitutions:['public host','public evidence path','absolute imports','exact public document assertion','ordinary download pacing']},null,2)+'\n');
if(code===0){const p=out+'/result.json',d=JSON.parse(await readFile(p,'utf8'));d.official_website=true;d.scope='actual public original website; original complete financial assertions preserved; fictitious data';await writeFile(p,JSON.stringify(d,null,2)+'\n');}process.exitCode=code;
