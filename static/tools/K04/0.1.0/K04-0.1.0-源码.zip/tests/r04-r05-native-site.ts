import {chromium,type Frame} from 'playwright';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
import {readFileData} from '../packages/core/io';

// Real staged Streamlit site and its original routes; no synthetic host fixture.
const suite=process.env.AIPLUS_EVIDENCE_DIR||'progress/evidence/site-integration/D02-D03-D06-R01-R02-R03-R04-R05';
const host=process.env.AIPLUS_NATIVE_SITE_URL||'http://127.0.0.1:8515';
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
const registration=JSON.parse(await readFile('integration/native-site/site/registry.json','utf8'));
const siteSha=sha(await readFile('integration/native-site/site/index.html'));
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const selected=process.argv.slice(2);assert.ok(selected.every(id=>['R04','R05'].includes(id)));
try {for(const id of (selected.length?selected:['R04','R05'])){
 const entry=registration.find((e:any)=>e.id===id);assert.ok(entry&&entry.replacesOriginal);
 const out=path.resolve(suite+'/'+id+'/site-local');await mkdir(out,{recursive:true});
 const release=path.resolve('release/'+id+'/0.1.0');const formal=path.resolve('progress/evidence/'+id+'/0.1.0/formal-browser');
 const checks:string[]=[],errors:string[]=[],requests:string[]=[],programs:string[]=[],geometry:any[]=[],downloads:Record<string,string>={};let processing=false,accept=true;
 const context=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}});
 await context.addInitScript({content:`window.__toolPersistence=[];for(const m of ['setItem','removeItem','clear']){const original=Storage.prototype[m];Storage.prototype[m]=function(...args){window.__toolPersistence.push('storage.'+m);return original.apply(this,args)}}const original=IDBFactory.prototype.open;IDBFactory.prototype.open=function(...args){window.__toolPersistence.push('indexedDB.open');return original.apply(this,args)}`});
 const shell=await context.newPage();shell.on('pageerror',e=>errors.push(e.message));shell.on('dialog',async d=>accept?d.accept():d.dismiss());
 shell.on('request',r=>{if(r.url().endsWith('runtime.json'))programs.push(r.url());if(processing&&/^https?:/.test(r.url()))requests.push(r.url())});
 await shell.goto(host+'/?tool='+id);const handle=await shell.locator('iframe').first().elementHandle();assert.ok(handle);const frame=await handle.contentFrame();assert.ok(frame);const f:Frame=frame;
 const app=f.locator('.'+id.toLowerCase());await app.waitFor();assert.equal(await f.locator('iframe').count(),0);assert.equal(programs.length,1);assert.ok(programs[0].includes('/'+id+'/0.1.0/'));checks.push('real_original_Streamlit_same_document_only_current_program_no_inner_iframe');
 await context.setOffline(true);processing=true;
 const titles=id==='R04'?['工作总览','应收资料','核销与调整','截止与账龄口径','账龄分析','逾期与客户待办','例外与来源','版本比较与底稿']:['工作总览','应收与已计提资料','分组与个别评估','损失参数与依据','计提测算','准备变动与核销转回','例外复核','版本比较与底稿'];
 const button=(i:number)=>id==='R04'?`${i+1}. ${titles[i]}`:titles[i];
 async function settle(i:number){for(let attempt=0;attempt<25;attempt++){const h=await app.getByRole('heading',{name:new RegExp('^'+titles[i])}).boundingBox(),bar=await f.locator('header.hdr').boundingBox();if(h&&bar&&h.y>=bar.y+bar.height-1&&h.y+h.height<1000)return;await shell.waitForTimeout(100);}}
 async function nav(i:number){await app.getByRole('navigation',{name:'业务页面',exact:true}).getByRole('button',{name:button(i),exact:true}).click();await app.getByRole('heading',{name:new RegExp('^'+titles[i])}).waitFor();await settle(i);}
 async function grab(label:string,name:string){const pending=shell.waitForEvent('download');await app.getByRole('button',{name:label,exact:true}).click();const d=await pending;const p=out+'/'+name;await d.saveAs(p);downloads[name]=sha(await readFile(p));return p;}
 const fullButton=id==='R04'?'下载完整工作（含数据）':'保存含数据完整工作',schemeButton=id==='R04'?'下载无数据方案':'保存不含数据方案',xlsxButton=id==='R04'?'导出完整XLSX底稿':'下载完整坏账底稿',restore=id==='R04'?'恢复工作文件':'恢复JSON工作或方案';
 async function restoreFile(file:string){if(id==='R04')await nav(7);await app.getByLabel(restore,{exact:true}).setInputFiles(file);await shell.waitForTimeout(250);}
 await app.getByRole('button',{name:id==='R04'?'载入虚构样例':'载入完全虚构样例',exact:true}).click();if(id==='R05')await app.getByRole('button',{name:'按当前资料重算',exact:true}).click();
 if(id==='R04')assert.match(await app.innerText(),/290/);else for(const value of ['50.00','10.00','90.00'])await app.getByText(value,{exact:true}).first().waitFor();checks.push('actual_fictitious_manual_totals');
 for(const width of [1440,390,320]){await shell.setViewportSize({width,height:1000});for(let i=0;i<8;i++){
  await nav(i);const n=app.getByRole('navigation',{name:id==='R04'?'当前导航':'业务页面',exact:true});const current=n.locator('[aria-current="page"]');const a=await current.boundingBox(),b=await n.boundingBox(),h=await app.getByRole('heading',{name:new RegExp('^'+titles[i])}).boundingBox(),header=await f.locator('header.hdr').boundingBox();assert.ok(a&&b&&h&&header);
  assert.ok(b.y>=header.y+header.height-1&&h.y>=header.y+header.height-1&&h.y+h.height<1000);assert.ok(a.x>=b.x-1&&a.x+a.width<=b.x+b.width+1);const allNavigation=id==='R04'?await app.getByRole('navigation',{name:'业务页面',exact:true}).boundingBox():b;assert.ok(allNavigation&&allNavigation.y>=header.y+header.height-1&&allNavigation.y+allNavigation.height<1000,'all business navigation visible below original header');geometry.push({width,title:titles[i],navigation:b,allNavigation,current:a,heading:h,header});
  if(i<7){await app.getByRole('button',{name:id==='R04'?'下一业务页':'下一个业务页',exact:true}).click();await settle(i+1);const next=await app.getByRole('heading',{name:new RegExp('^'+titles[i+1])}).boundingBox();if(!(next&&next.y>=header.y+header.height-1&&next.y+next.height<1000)){await shell.screenshot({path:out+'/bottom-navigation-failure.png'});await writeFile(out+'/bottom-navigation-failure.json',JSON.stringify({id,width,i,next,header,geometry,passed:false},null,2));}assert.ok(next&&next.y>=header.y+header.height-1&&next.y+next.height<1000,JSON.stringify({id,width,i,next,header}));}
 }await shell.screenshot({path:out+'/navigation-'+width+'.png'});}checks.push('24_original_header_navigation_geometry_and_21_normal_bottom_clicks');
 await shell.setViewportSize({width:1440,height:1000});await nav(7);
 const offlineResult=JSON.parse(await readFile(formal+'/result.json','utf8'));
 const goldenWork=id==='R04'?formal+'/work.json':formal+'/'+offlineResult.downloads.find((d:any)=>d.filename.includes('完整工作')).filename;
 const goldenXlsx=id==='R04'?formal+'/export.xlsx':formal+'/'+offlineResult.downloads.find((d:any)=>d.filename.endsWith('.xlsx')&&d.filename.includes('底稿')).filename;
 await restoreFile(goldenWork);await nav(7);const work=await grab(fullButton,'work.json'),scheme=await grab(schemeButton,'scheme.json'),xlsx=await grab(xlsxButton,'work.xlsx');
 assert.deepEqual(JSON.parse(await readFile(work,'utf8')),JSON.parse(await readFile(goldenWork,'utf8')));
 const a=await readFileData('actual.xlsx',new Uint8Array(await readFile(xlsx))),b=await readFileData('offline.xlsx',new Uint8Array(await readFile(goldenXlsx)));assert.deepEqual(a.sheets,b.sheets);checks.push('actual_offline_whole_work_and_every_XLSX_cell_equal');
 accept=false;await restoreFile(scheme);await nav(7);assert.deepEqual(JSON.parse(await readFile(await grab(fullButton,'cancel-scheme.json'),'utf8')),JSON.parse(await readFile(work,'utf8')));accept=true;await restoreFile(scheme);await nav(7);const empty=JSON.parse(await readFile(await grab(fullButton,'scheme-empty.json'),'utf8'));if(id==='R04')assert.equal(Object.keys(empty.work.inputs).length,0);else {for(const k of ['receivables','assignments','books','changes'])assert.equal(empty.data[k],null);assert.deepEqual(empty.data.parameters,JSON.parse(await readFile(scheme,'utf8')).data.parameters);}assert.deepEqual(id==='R04'?empty.work.events:empty.events,[]);checks.push('no_data_restore_cancel_exact_then_clear');
 // Actual XLSX replacement, preserving financial scope and source, followed by complete restoration.
 await restoreFile(work);await nav(1);
 await app.getByLabel(id==='R04'?'选择receivables文件':'导入应收截止余额 CSV/XLSX',{exact:true}).setInputFiles(release+'/虚构样例.xlsx');
 await app.getByRole('button',{name:id==='R04'?'取消换入':'取消导入',exact:true}).click();await nav(7);assert.deepEqual(JSON.parse(await readFile(await grab(fullButton,'cancel-import.json'),'utf8')),JSON.parse(await readFile(work,'utf8')));
 await nav(1);await app.getByLabel(id==='R04'?'选择receivables文件':'导入应收截止余额 CSV/XLSX',{exact:true}).setInputFiles(release+'/虚构样例.xlsx');await app.getByRole('button',{name:id==='R04'?'确认换入资料':'确认导入',exact:true}).click();if(id==='R05')await app.getByRole('button',{name:'按当前资料重算',exact:true}).click();await nav(7);const imported=JSON.parse(await readFile(await grab(fullButton,'imported.json'),'utf8'));assert.ok(id==='R04'?imported.work.inputs.receivables.table.rows.length===31:imported.data.receivables.rows.length===3);checks.push('actual_XLSX_cancel_exact_and_replace_source_rows');
 await restoreFile(work);await nav(7);accept=false;await app.getByRole('button',{name:'退出工具',exact:true}).click();assert.deepEqual(JSON.parse(await readFile(await grab(fullButton,'cancel-exit.json'),'utf8')),JSON.parse(await readFile(work,'utf8')));checks.push('exit_cancel_preserves_whole_work');
 assert.deepEqual(await f.evaluate(()=>(window as any).__toolPersistence),[]);assert.deepEqual(requests,[]);processing=false;await context.setOffline(false);accept=true;await app.getByRole('button',{name:'退出工具',exact:true}).click();const start=id==='R04'?'开始账龄与逾期分析':'开始坏账计提测算';await f.getByRole('link',{name:start,exact:true}).waitFor();await shell.screenshot({path:out+'/original-detail.png',fullPage:true});
 const detailLinks=f.locator('[data-program-download]');const downloaded:Record<string,string>={};const count=await detailLinks.count();assert.ok(count>=7);for(let i=0;i<count;i++){const link=detailLinks.nth(i);const filename=await link.getAttribute('download');assert.ok(filename);const pending=shell.waitForEvent('download');await link.click();const d=await pending;await mkdir(out+'/version-downloads',{recursive:true});const p=out+'/version-downloads/'+filename;await d.saveAs(p);const digest=sha(await readFile(p));assert.equal(digest,sha(await readFile(release+'/'+filename)));downloaded[filename]=digest;}
 assert.equal(programs.length,1);checks.push('all_original_detail_version_downloads_exact_and_detail_no_program_load');
 await f.getByRole('link',{name:start,exact:true}).click();await app.waitFor();await nav(7);const reentry=JSON.parse(await readFile(await grab(fullButton,'reentry-empty.json'),'utf8'));assert.ok(id==='R04'?Object.keys(reentry.work.inputs).length===0:Object.values(reentry.data).every(x=>x===null));assert.deepEqual(id==='R04'?reentry.work.events:reentry.events,[]);checks.push('exit_original_detail_dispose_reentry_empty');
 assert.deepEqual(errors,[]);await writeFile(out+'/result.json',JSON.stringify({tool:id,version:'0.1.0',site_sha256:siteSha,html_sha256:sha(await readFile(release+'/index.html')),runtime_sha256:sha(await readFile(release+'/runtime.json')),checks,geometry,downloads,version_downloads:downloaded,errors,processing_requests:requests,forced_clicks:0,scope:'real local staged eight-tool original website; public verification pending',passed:true},null,2));await context.close();console.log(id,checks.length,'native workflow groups passed; all version downloads:',count);
}}finally{await browser.close()}
