"""Pure original-site generation with K05 candidate fixtures; no staging or publication."""
from pathlib import Path
import hashlib, json, re, runpy, shutil, zipfile

root=Path(__file__).resolve().parents[1]
out=root/'progress/evidence/K05/0.1.0'
fixture=out/'site-placement-fixture'
site=runpy.run_path(str(root/'scripts/site.py'))
base=(root/'website/base-index.html').read_text()
entries=json.loads((root/'integration/native-site/site/registry.json').read_text())
assert len(entries)==21 and all(e['id']!='K05' for e in entries)
file_sets=[]
for entry in entries:
    folder=root/'release'/entry['id']/entry['version']
    files=[f"{entry['id']}-{entry['version']}-离线包.zip",f"{entry['id']}-{entry['version']}-源码.zip"]
    files+=sorted(p.name for p in folder.iterdir() if p.is_file() and p.suffix!='.zip' and p.name not in ['index.html','runtime.json','build-manifest.json'])
    entry['offlineSize']=f'{(folder/files[0]).stat().st_size/1024/1024:.1f} MB'
    file_sets.append(files)
before=site['native_documents'](base,entries,file_sets,(root/'integration/native-host.js').read_text())
release=fixture/'release';release.mkdir(parents=True,exist_ok=True)
for entry in entries:
    target=release/entry['id'];source=root/'release'/entry['id']
    if not target.exists():target.symlink_to(source,target_is_directory=True)
folder=release/'K05/0.1.0';folder.mkdir(parents=True,exist_ok=True)
candidate=root/'tools/K05-存货跌价测算/candidate/0.1.0'
for f in candidate.iterdir():
    if f.is_file() and f.name not in ['build.json','host-harness.html']:shutil.copy2(f,folder/f.name)
for name in ['财务规则.md','参考来源.md','THIRD_PARTY_NOTICES.md']:
    shutil.copy2(root/'tools/K05-存货跌价测算'/name,folder/name)
shutil.copy2(out/'source-rebuild/K05-candidate-source.zip',folder/'K05-0.1.0-源码.zip')
with zipfile.ZipFile(folder/'K05-0.1.0-离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in folder.iterdir():
        if f.is_file() and f.suffix!='.zip':z.write(f,f.name)
files=['K05-0.1.0-离线包.zip','K05-0.1.0-源码.zip']+sorted(p.name for p in folder.iterdir() if p.is_file() and p.suffix!='.zip' and p.name not in ['index.html','runtime.json','build-manifest.json'])
runtime=folder/'runtime.json'
entry={'id':'K05','name':'存货跌价测算','version':'0.1.0','detailRoute':'tool-K05','workspaceRoute':'work-K05','runtime':'app/static/tools/K05/0.1.0/runtime.json','sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'bytes':runtime.stat().st_size,'offlineSize':f'{(folder/files[0]).stat().st_size/1024/1024:.1f} MB'}
site['native_document'].__globals__['ROOT']=fixture
after=site['native_documents'](base,entries+[entry],file_sets+[files],(root/'integration/native-host.js').read_text())
assert len(re.findall(r'\bdata-tool\s',after))==88
assert len(re.findall(r'\bdata-tool\s[^>]*data-mod="cost"',after))==8
assert after.count('<template id="r-tool-K05">')==1
assert after.count('<template id="r-work-K05">')==1
added_row,_,_=site['native_document'](base,entry,files,(root/'integration/native-host.js').read_text(),fragments=True)
changed=[]
for match in re.finditer(r'<template id="([^"]+)">.*?</template>',before,re.S):
    actual=re.search(r'<template id="'+re.escape(match[1])+r'">.*?</template>',after,re.S)
    assert actual,match[1]
    expected=match.group()
    if match[1] in ['r-home','r-tools','r-course','r-course-ok','r-request']:
        expected=expected.replace('87 个工具','88 个工具')
    if match[1]=='r-home':
        expected=expected.replace('<div class="bignum num">87</div>','<div class="bignum num">88</div>')
        expected=expected.replace('>65</span><span style="font-size:15px;font-weight:500">单点工具','>66</span><span style="font-size:15px;font-weight:500">单点工具')
        expected=re.sub(r'(<a href="#tools-cost" class="idx hov">.*?class="num body" style="font-size:15px">)7(</span>)',lambda m:m[1]+'8'+m[2],expected)
    if match[1]=='r-tools':
        for old,new in [('data-count="mod:all">87','data-count="mod:all">88'),('data-count="ai:all">87','data-count="ai:all">88'),('data-count="ai:0">80','data-count="ai:0">81'),('data-count="mod:cost">7','data-count="mod:cost">8'),('data-total>87','data-total>88')]:expected=expected.replace(old,new)
        marker='<div class="trow" data-tool data-mod="asset"'
        expected=expected.replace(marker,added_row+marker,1)
    assert expected==actual.group(),match[1]
    if expected!=match.group():changed.append(match[1])
detail=re.search(r'<template id="r-tool-K05">.*?</template>',after,re.S).group()
for text in ['开始存货跌价测算','存货成本','准备变动','净值依据','十五张底稿','转回上限']:assert text in detail,text
for text in ['开始账表对账','虚构左表.csv','虚构右表.csv']:assert text not in detail,text
assert 'function go(h)' in after and 'function render(' in after
record={'passed':True,'scope':'pure generation using candidate fixture ZIPs; not formal package, source rebuild, live website or publication acceptance','registered_tools':22,'catalogue_rows':88,'cost_rows':8,'checked_previous_templates':len(re.findall(r'<template id=',before)),'exact_count_update_templates':changed,'placement':'add K05 to original cost module, preserve K03 and broader platforms','generator_sha256':hashlib.sha256((root/'scripts/site.py').read_bytes()).hexdigest(),'candidate_runtime_sha256':entry['sha256']}
(out/'root-site-placement.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False))
