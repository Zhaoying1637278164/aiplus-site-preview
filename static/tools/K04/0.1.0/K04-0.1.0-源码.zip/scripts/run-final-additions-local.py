"""Execute complete added-tool work and all original-module downloads on one stage."""
import pathlib,hashlib,json,subprocess,runpy
adapter=runpy.run_path("scripts/current-stage-download-adapter.py")["adapted_download"]
root=pathlib.Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
site=root/'integration/native-site/site/index.html'
digest=sha(site)
record=root/'progress/evidence/shared/2026-10-04-final-additions-commands.json'
result={'site_sha256':digest,'results':[],'passed':False}
for tool in ['P04','T01','T02']:
 for script,args in [(tool.lower()+'-native-site.ts',[]),('new-tools-native-downloads.ts',[tool])]:
  assert sha(site)==digest,'stage changed during actual verification'
  log=root/'progress/evidence/shared'/('2026-10-04-final-'+tool+'-'+script+'.log')
  if script=='new-tools-native-downloads.ts' and 'T05' in [e['id'] for e in json.loads((root/'integration/native-site/site/registry.json').read_text())]:
   row=adapter(script,args,log)
  else:
   with log.open('w') as handle:execution=subprocess.run(['node','--import','tsx',str(root/'tests'/script),*args],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
   row={'script':script,'exit_code':execution.returncode,'test_sha256':sha(root/'tests'/script)}
  row.update(tool=tool,args=args,log=str(log.relative_to(root)));result['results'].append(row)
  record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  print(tool,script,row['exit_code'],flush=True)
  if row['exit_code']:raise SystemExit(1)
result['passed']=True
record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
