"""Exact T05 local delivery audit; public acceptance and whole-site gates separate."""
from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();ev=root/'progress/evidence/T05/0.1.0';release=root/'release/T05/0.1.0'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
for folder,script,groups,downloads,cells,geometries in [('formal-browser','t05-formal-browser.ts',17,32,404,42),('site-local','t05-native-site.ts',19,28,404,21)]:
 d=read(ev/folder/'result.json');c=read(ev/folder/'root-command.json')
 assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(root/'tests'/script)
 assert d['passed'] and d['candidate'] is False and d['official_website'] is False and d['html_sha256']==html
 assert d['errors']==[] and d['requests']==[]
 assert len(d['checks'])==groups and len(d['downloads'])==downloads and d['cells']==cells and len(d['geometry'])==geometries
 assert {g['width'] for g in d['geometry']}=={1440,390,320}
 assert any('66行独立NPV' in x for x in d['checks'])
 if folder=='site-local':
  assert c['site_sha256']==d['site_sha256']==site
  assert d['programs'] and all('/T05/0.1.0/runtime.json' in x for x in d['programs'])
  assert any('两手机菜单' in x for x in d['checks'])
 for item in d['downloads']:
  f=ev/folder/item.get('filename',item.get('file'));assert sha(f)==item['sha256'] and f.stat().st_size==item['bytes']
directory=ev/'T05/downloads';d=read(directory/'result.json');c=read(directory/'root-command.json')
assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(root/'tests/t05-native-downloads.ts')
if c.get('executed_test'):
 import runpy
 runpy.run_path('scripts/current-stage-download-adapter.py')['verify_t05_adapter_row'](c)
assert d['passed'] and d['errors']==[] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==11 and set(d['downloads'])==expected and d['clicks']==13
for name,h in d['downloads'].items():assert sha(directory/'site-local-downloads'/name)==h==sha(release/name)
with zipfile.ZipFile(release/'T05-0.1.0-离线包.zip') as z:
 members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
 assert set(z.namelist())=={'T05/'+n for n in members}
 for n in members:assert z.read('T05/'+n)==(release/n).read_bytes()
source=release/'T05-0.1.0-源码.zip';assert source.stat().st_size<=24*1024*1024
r=read(ev/'source-rebuild.json');assert r['source_zip_sha256']==sha(source) and r['actual_root_exit_code']==0
assert len(r['commands'])==4 and all(x['exit_code']==0 for x in r['commands'])
for name in ['index.html','runtime.json']:
 v=r['files'][name];assert v['identical'] and v['release_sha256']==v['rebuilt_sha256']==sha(release/name)
a=read(ev/'source-rebuild-assets.json');assert a['source_zip_sha256']==sha(source) and a['actual_root_exit_code']==0
assert set(a['files'])==members
for name,v in a['files'].items():assert v['release_sha256']==sha(release/name) and (v['bytes_identical'] or name.endswith('.xlsx') and v['content_identical_except_created_modified'])
with zipfile.ZipFile(source) as z:
 snap=json.loads(z.read('source-snapshot.json'))
 for n,h in snap['file_sha256'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 for name in ['tests/t05-independent-review.ts','tests/t05-formal-browser.ts','tests/t05-native-site.ts','tests/t05-native-downloads.ts','tools/T05-融资成本比较/src/engine.ts','tools/T05-融资成本比较/src/App.tsx','tools/T05-融资成本比较/src/style.css']:
  assert z.read(name)==(root/name).read_bytes(),name
ind=read(root/'progress/evidence/shared/2026-10-04-T05-independent-review.json');assert ind['passed'] and ind['actual_root_exit_code']==0 and len(ind['checks'])==9
assert ind['root_engine_sha256']==sha(root/'tools/T05-融资成本比较/src/engine.ts')
visual=read(ev/'site-local/root-image-review.json');assert visual['mobile_exit_layout_issue_resolved'] and len(visual['images'])==3
for im in visual['images']:assert im['actually_viewed'] and sha(root/im['file'])==im['sha256']
result={'tool':'T05','version':'0.1.0','local_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':sha(source),'formal_groups':17,'local_work_groups':19,'version_files':11,'public_acceptance':False,'accepted':False,'errors':[]}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('T05 exact local evidence passed; public and whole-site acceptance separately required')
