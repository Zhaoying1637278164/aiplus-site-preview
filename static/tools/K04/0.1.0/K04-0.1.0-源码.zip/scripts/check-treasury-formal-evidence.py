"""Audit T01/T02 formal files and isolated source rebuild; website remains separate."""
from pathlib import Path
import hashlib,json,sys,zipfile

root=Path.cwd()
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
catalog={t['id']:t for t in read(root/'catalog/tools.json')}
for tool in sys.argv[1:] or ['T01','T02']:
    assert tool in ['T01','T02']
    release=root/'release'/tool/'0.1.0';ev=root/'progress/evidence'/tool/'0.1.0'
    formal=read(ev/'formal-browser/result.json')
    html,runtime=sha(release/'index.html'),sha(release/'runtime.json')
    assert formal['passed'] and formal['formal'] and not formal['candidate']
    assert not formal['official_website'] and formal['errors']==formal['requests']==[]
    assert formal.get('html_sha256',formal.get('candidate_sha256'))==html
    assert formal['runtime_sha256']==runtime
    assert len(formal['checks'])==({'T01':17,'T02':14}[tool])
    assert len(formal['geometry'])==({'T01':39,'T02':48}[tool])
    assert len(formal['downloads'])==({'T01':45,'T02':44}[tool])
    for item in formal['downloads']:
        name=item.get('file',item.get('filename'));p=ev/'formal-browser'/name
        assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
    if tool=='T02':
        supplement=read(ev/'formal-supplement/result.json')
        assert supplement['passed'] and supplement['formal'] and not supplement['candidate']
        assert supplement['candidate_sha256']==html and supplement['errors']==[]
        assert len(supplement['checks'])==6 and len(supplement['downloads'])==6
        for item in supplement['downloads']:
            p=ev/'formal-supplement'/('all-'+item['filename'])
            assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
    independent=read(root/'progress/evidence/shared'/('2026-10-04-'+tool+'-independent-review.json'))
    assert independent['passed'] and independent['actual_root_exit_code']==0
    assert len(independent['checks'])==8 if tool=='T01' else independent['assertions']==7
    engine='tools/'+catalog[tool]['folder']+'/src/engine.ts'
    assert independent['root_engine_sha256']==sha(root/engine)
    assert independent['root_validator_sha256']==sha(root/'tests'/ (tool.lower()+'-independent-review.ts'))
    source=release/(tool+'-0.1.0-源码.zip')
    rebuild,assets=read(ev/'source-rebuild.json'),read(ev/'source-rebuild-assets.json')
    assert sha(source)==rebuild['source_zip_sha256']==assets['source_zip_sha256']
    assert len(rebuild['commands'])==4 and all(c['exit_code']==0 for c in rebuild['commands'])
    with zipfile.ZipFile(source) as z:
        snapshot=json.loads(z.read('source-snapshot.json'))
        assert tool in snapshot['included_tools'] and 'T03' in snapshot['excluded_active_tools']
        for name,digest in snapshot['file_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
        assert snapshot['file_sha256'][engine]==sha(root/engine)
        for name in ['tests/'+tool.lower()+'-formal-browser.ts','tests/'+tool.lower()+'-independent-review.ts']+(['tests/t02-formal-supplement.ts'] if tool=='T02' else []):
            assert z.read(name)==(root/name).read_bytes(),'archive missing current formal validator '+name
    expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
    assert set(assets['files'])==expected
    for name,item in assets['files'].items():
        assert item['release_sha256']==sha(release/name)
        assert item['bytes_identical'] or name.endswith('.xlsx') and item['content_identical_except_created_modified']
    with zipfile.ZipFile(release/(tool+'-0.1.0-离线包.zip')) as z:
        assert set(z.namelist())=={tool+'/'+n for n in expected}
        for name in expected:assert hashlib.sha256(z.read(tool+'/'+name)).hexdigest()==sha(release/name)
    visual=read(ev/'formal-browser/root-visual-review.json')
    assert visual['reviewed'] and len(visual['screenshots'])==2
    for name,digest in visual['screenshots'].items():assert sha(ev/'formal-browser'/name)==digest
    result={'tool':tool,'version':'0.1.0','formal_and_source_gates_passed':True,
            'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':sha(source),
            'formal_result_sha256':sha(ev/'formal-browser/result.json'),'formal_groups':len(formal['checks']),
            'formal_downloads':len(formal['downloads']),'source_assets':len(expected),
            'official_website':False,'public_acceptance':False,'accepted':False,
            'scope':'actual formal file:// and runtime fixture, independent financial expectations, isolated lockfile install/test/typecheck/rebuild, all asset content; actual website and public still required',
            'platform':'macOS isolated Chromium; Windows actual machine unverified','errors':[]}
    (ev/'formal-source-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(tool,'formal/source gates passed; actual website/public still required')
