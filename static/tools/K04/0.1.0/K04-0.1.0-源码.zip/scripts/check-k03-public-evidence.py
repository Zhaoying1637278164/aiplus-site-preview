"""Require actual public K03 workflow, manual workbook, archives and visual proof."""
from pathlib import Path
import hashlib,json,re,zipfile
r=Path.cwd();ev=r/'progress/evidence/K03/0.1.0';release=r/'release/K03/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text());site=sha(r/'integration/native-site/site/index.html')
html=sha(release/'index.html');runtime=sha(release/'runtime.json');url='https://aiplus-guance.streamlit.app/~/+/'
for mode,script in [('work','k03-native-site.ts'),('financial','k03-native-financial-browser.ts'),('downloads','k03-native-downloads.ts')]:
 b=ev/'site-public'/mode;c=read(b/'execution.json');root=read(b/'root-command.json')
 assert c['actual_subprocess_exit_code']==root['actual_exit_code']==0 and root['actual_session_id']
 assert c['public_url']==root['endpoint']==url and c['expected_site_sha256']==root['site_sha256']==site
 assert c['source_validator_sha256']==sha(r/'tests'/script) and c['executed_validator_sha256']==sha(b/'executed-public-validator.ts')
 assert c['native_bootstrap_sha256']==sha(r/'tests/k03-native-bootstrap.ts')
 folder=b/'K03/downloads' if mode=='downloads' else b;d=read(folder/'result.json')
 assert root['result_sha256']==sha(folder/'result.json') and d['passed']
 doc=(folder/'actual-srcdoc.html').read_text()
 assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
 if mode=='work':
  assert d['officialWebsite'] and d['siteSHA']==site and d['actualRuntimeSHA']==runtime and d['htmlSHA']==html and d['runtimeSHA']==runtime
  assert len(d['checks'])==15 and len(d['downloads'])==28 and d['requests']==d['errors']==[]
  assert len(d['programs'])==3 and all(p.startswith('https://aiplus-guance.streamlit.app/') and p.endswith('/K03/0.1.0/runtime.json') for p in d['programs'])
 elif mode=='financial':
  assert d['siteSHA']==site and d['actualRuntimeSHA']==runtime and d['html_sha256']==html and d['runtime_sha256']==runtime
  assert d['cells']==162 and d['sheets']==10 and d['requests']==d['errors']==[] and len(d['programs'])==1
  for name in ['independent-input.json','independent-expected.json']:
   assert (b/name).read_bytes()==(ev/'site-financial-browser'/name).read_bytes(),name
 else:
  assert d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime and d['errors']==[] and d['clicks']==18
  expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
  assert len(expected)==16 and set(d['downloads'])==expected
  for name,h in d['downloads'].items():assert sha(folder/'site-local-downloads'/name)==sha(release/name)==h
  with zipfile.ZipFile(folder/'site-local-downloads/K03-0.1.0-离线包.zip') as z:
   expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
   assert set(z.namelist())=={'K03/'+n for n in expected}
   for n in expected:assert z.read('K03/'+n)==(release/n).read_bytes()
visual=read(ev/'site-public/root-visual-review.json');assert visual['actual_review'] and visual['site_sha256']==site and len(visual['images'])>=2
for name,h in visual['images'].items():assert sha(ev/'site-public'/name)==h
local=read(ev/'local-delivery-audit.json');assert local['local_exact_gates_passed'] and local['site_sha256']==site
result={'tool':'K03','version':'0.1.0','public_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'workflow_groups':15,'checked_workbook_cells':162,'version_download_clicks':18,'unique_version_files':16,'Windows_real_machine':'unverified'}
(ev/'site-public-final.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
