"""Exact local delivery audit for P04/T01/T02. Public acceptance remains separate."""
from pathlib import Path
import hashlib,json,sys,zipfile
root=Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
site=sha(root/'integration/native-site/site/index.html')
for tool in sys.argv[1:] or ['P04','T01','T02']:
 ev=root/'progress/evidence'/tool/'0.1.0';release=root/'release'/tool/'0.1.0'
 local=read(ev/'site-local/result.json');formal=read(ev/'formal-browser/result.json')
 html,runtime=sha(release/'index.html'),sha(release/'runtime.json')
 assert local['passed'] and local['site_sha256']==site and local['actual_root_exit_code']==0
 assert local['test_sha256']==sha(root/'tests'/(tool.lower()+'-native-site.ts'))
 assert local.get('html_sha256',local.get('candidate_sha256'))==html and local['runtime_sha256']==runtime
 assert local['errors']==[] and local.get('requests',local.get('processing_requests'))==[]
 assert len(local['checks'])=={'P04':23,'T01':17,'T02':15}[tool]
 assert len(local['geometry'])=={'P04':63,'T01':39,'T02':45}[tool]
 assert len(local['downloads'])=={'P04':63,'T01':43,'T02':41}[tool]
 for item in local['downloads']:
  p=ev/'site-local'/item.get('file',item.get('filename'));assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
 assert any('formal' in c and ('equal' in c or '相等' in c) for c in local['checks'])
 assert formal['passed'] and formal.get('html_sha256',formal.get('candidate_sha256'))==html and formal['runtime_sha256']==runtime
 visual=read(ev/'site-local/root-visual-review.json');assert visual['reviewed'] and visual['actual_website'] and len(visual['files'])==2
 for name,digest in visual['files'].items():assert sha(ev/'site-local'/name)==digest
 if tool=='P04':
  downloads=local['version_downloads'];folder=ev/'site-local/version-downloads'
 else:
  directory=root/'progress/evidence/site-integration/new-tools-P04-T01-T02'/tool/'downloads'
  d=read(directory/'result.json');assert d['passed'] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime and d['errors']==[]
  downloads=d['downloads'];folder=directory/'site-local-downloads'
 expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
 assert set(downloads)==expected
 for name,digest in downloads.items():assert sha(folder/name)==digest==sha(release/name)
 with zipfile.ZipFile(folder/(tool+'-0.1.0-离线包.zip')) as z:
  members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
  assert set(z.namelist())=={tool+'/'+n for n in members}
  for n in members:assert z.read(tool+'/'+n)==(release/n).read_bytes()
 source=release/(tool+'-0.1.0-源码.zip');assert source.stat().st_size<=24*1024*1024
 rebuild=read(ev/'source-rebuild.json');assets=read(ev/'source-rebuild-assets.json')
 assert sha(source)==rebuild['source_zip_sha256']==assets['source_zip_sha256']
 assert len(rebuild['commands'])==4 and all(x['exit_code']==0 for x in rebuild['commands'])
 with zipfile.ZipFile(source) as z:
  snap=json.loads(z.read('source-snapshot.json'))
  for name,digest in snap['file_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
  for name in ['tests/'+tool.lower()+'-native-site.ts','tests/new-tools-native-downloads.ts','scripts/check-new-tools-local-evidence.py']:
   assert z.read(name)==(root/name).read_bytes(),'source lacks current acceptance code '+name
 assert set(assets['files'])=={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
 for name,item in assets['files'].items():
  assert item['release_sha256']==sha(release/name)
  assert item['bytes_identical'] or name.endswith('.xlsx') and item['content_identical_except_created_modified']
 independent=read(root/'progress/evidence/shared'/('2026-10-04-'+tool+'-independent-review.json'))
 assert independent['passed'] and independent['actual_root_exit_code']==0
 assert len(independent.get('checks',[]))==({'P04':12,'T01':8}[tool]) if tool!='T02' else independent['assertions']==7
 catalog={t['id']:t for t in read(root/'catalog/tools.json')};engine=root/'tools'/catalog[tool]['folder']/'src/engine.ts'
 assert independent['root_engine_sha256']==sha(engine)
 result={'tool':tool,'version':'0.1.0','local_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':sha(source),'checks':len(local['checks']),'geometry':len(local['geometry']),'version_files':len(downloads),'public_acceptance':False,'accepted':False,'scope':'Actual local original website full work, exact formal equality, all downloads, isolated source rebuild; public and whole-site regression required separately','errors':[]}
 (ev/'local-delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(tool,'exact local gates passed; public still required')
