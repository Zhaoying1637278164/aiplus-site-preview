"""Execute the same reviewed T04 validators on the public original website.

Only import resolution, raw deployed document capture and download pacing change.
Financial inputs, literal expected answers and workflow assertions stay intact.
"""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path.cwd();mode=sys.argv[1];assert mode in ['work','financial','downloads']
script={'work':'t04-native-execution.ts','financial':'t04-native-financial-browser.ts','downloads':'t04-native-downloads.ts'}[mode]
base=root/'progress/evidence/T04/0.2.0/site-public'/mode;base.mkdir(parents=True,exist_ok=True)
source=root/'tests'/script;original=source.read_text()
def resolve_import(m):
 value=json.loads('"'+m[2]+'"') if m[1]=='"' else m[2]
 return 'from '+json.dumps(str((root/'tests'/value).resolve()),ensure_ascii=False) if value.startswith('.') else m[0]
expected=re.sub(r"from (['\"])([^'\"]+)\1",resolve_import,original)
if mode=='downloads':
 target="await page.goto(host);const frame=page.frameLocator('iframe').first();"
 insertion="await page.locator('iframe').first().waitFor({timeout:120000});await page.waitForFunction(()=>document.querySelector('iframe')?.getAttribute('srcdoc')?.includes('__AIPlusRegistry'),undefined,{timeout:120000});const actualDoc=await page.locator('iframe').first().getAttribute('srcdoc');assert(actualDoc);assert.equal(sha(Buffer.from(actualDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')));await writeFile(out+'/actual-srcdoc.html',actualDoc);"
 assert expected.count(target)==1;expected=expected.replace(target,target+insertion).replace("const pending=page.waitForEvent('download');","await page.waitForTimeout(1100);const pending=page.waitForEvent('download');")
executed=base/'executed-public-validator.ts';executed.write_text(expected)
env=dict(os.environ,AIPLUS_NATIVE_SITE_URL='https://aiplus-guance.streamlit.app/~/+/',AIPLUS_EVIDENCE_DIR=str(base))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'mode':mode,'public_browser':True,'public_url':env['AIPLUS_NATIVE_SITE_URL'],'source_validator_sha256':sha(source),'executed_validator_sha256':sha(executed),'expected_site_sha256':sha(root/'integration/native-site/site/index.html'),'adaptation':'absolute relative imports only; downloads additionally capture deployed srcdoc and pace clicks; financial assertions unchanged'}
with (base/'command.log').open('w') as log:r=subprocess.run(['node','--import','tsx',str(executed)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record['actual_subprocess_exit_code']=r.returncode
(base/'execution.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(mode,'actual subprocess exit',r.returncode,flush=True)
raise SystemExit(r.returncode)
