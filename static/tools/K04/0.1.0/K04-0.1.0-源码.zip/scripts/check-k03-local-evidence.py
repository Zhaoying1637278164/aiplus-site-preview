"""Exact K03 local delivery gate. Whole-site/public acceptance remains separate."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();ev=root/'progress/evidence/K03/0.1.0';release=root/'release/K03/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
html=sha(release/'index.html');runtime=sha(release/'runtime.json');site=sha(root/'integration/native-site/site/index.html')
receipt=read(ev/'root-interface-polish-formal-review.json')
assert all(c['actual_exit_code']==0 for c in receipt['commands'])
for script,digest in receipt['test_scripts'].items():assert sha(root/'tests'/script)==digest,script
ind=read(ev/'root-independent-review.json');assert ind['total']==ind['passed']==6 and ind['failed']==0
assert ind['script_sha256']==sha(root/'tests/k03-independent-review.ts')
assert ind['engine_sha256']==sha(root/'tools/K03-存货库龄与周转/src/engine.ts')
for folder,count,downloads in [('formal-browser',15,30),('formal-micro-return',7,7),('site-local',15,28)]:
 d=read(ev/folder/'result.json');assert d['passed'] and len(d['checks'])==count and len(d['downloads'])==downloads
 assert d['errors']==d['requests']==[] and d['htmlSHA']==html and d['runtimeSHA']==runtime
 if folder=='site-local':
  assert d['officialWebsite'] and d['siteSHA']==site and d['actualRuntimeSHA']==runtime
  assert len(d['programs'])==3 and all(p.endswith('/K03/0.1.0/runtime.json') for p in d['programs'])
for folder in ['root-financial-browser','site-financial-browser']:
 d=read(ev/folder/'result.json');assert d['passed'] and d['cells']==162 and d['sheets']==10
 assert d['html_sha256']==html and d['runtime_sha256']==runtime and d['requests']==d['errors']==[]
 if folder.startswith('site-'):assert d['siteSHA']==site and d['actualRuntimeSHA']==runtime and len(d['programs'])==1
src=read(ev/'source-rebuild.json');assert src['source_zip_sha256']==sha(release/'K03-0.1.0-源码.zip')
assert len(src['commands'])==4 and all(c['exit_code']==0 for c in src['commands'])
for name,digest in [('index.html',html),('runtime.json',runtime)]:
 item=src['files'][name];assert item['identical'] and item['release_sha256']==item['rebuilt_sha256']==digest
assert (release/'K03-0.1.0-源码.zip').stat().st_size<=24*1024*1024
assets=read(ev/'source-rebuild-assets.json');assert len(assets['files'])==17 and assets['source_zip_sha256']==src['source_zip_sha256']
for name,item in assets['files'].items():assert item['release_sha256']==sha(release/name)
with zipfile.ZipFile(release/'K03-0.1.0-源码.zip') as z:
 for name in ['tests/k03-native-full-pages.ts','scripts/check-k03-local-evidence.py','tests/k03-native-bootstrap.ts','tests/k03-native-financial-browser.ts']:
  assert name in z.namelist(),name
downloads=ev/'K03/downloads';d=read(downloads/'result.json')
assert d['passed'] and d['clicks']==18 and d['errors']==[] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime
assert d['test_sha256']==sha(root/'tests/k03-native-downloads.ts')
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==16 and set(d['downloads'])==expected
for name,digest in d['downloads'].items():assert sha(downloads/'site-local-downloads'/name)==sha(release/name)==digest
with zipfile.ZipFile(downloads/'site-local-downloads/K03-0.1.0-离线包.zip') as z:
 expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
 assert set(z.namelist())=={'K03/'+name for name in expected}
 for name in expected:assert z.read('K03/'+name)==(release/name).read_bytes()
visual=read(ev/'site-full-pages/result.json');review=read(ev/'site-full-pages/root-visual-review.json')
assert visual['passed'] and visual['siteSHA']==site and visual['actualRuntimeSHA']==runtime and len(visual['images'])==27
assert review['actual_review'] and review['all_27_full_content_images_viewed'] and review['site_sha256']==site
assert review['result_sha256']==sha(ev/'site-full-pages/result.json') and len(review['images'])==27
for row in visual['images']:
 assert row['sha256']==sha(ev/'site-full-pages'/row['file'])==review['images'][row['file']]
 assert not row['rendered']['overflow'] and row['rendered']['scrollHeight']<=row['rendered']['height']+2
for p in release.iterdir():
 if p.is_file():assert sha(root/'integration/native-site/static/tools/K03/0.1.0'/p.name)==sha(p)
result={'tool':'K03','version':'0.1.0','local_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'independent_groups':6,'workbook_cells':162,'native_groups':15,'full_images_reviewed':27,'version_download_clicks':18,'unique_files':16,'public_verified':False,'accepted':False,'windows_real_machine':'unverified'}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
