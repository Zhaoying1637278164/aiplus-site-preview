"""Audit R02/R03 real public workflows and complete delivered version contents."""
from pathlib import Path
import hashlib, json, re, sys, zipfile

root=Path.cwd()
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
deployed=read(root/'website/deployed-site.json')['site_sha256']
locks=read(root/'catalog/release-locks.json')['releases']
catalog={t['id']:t for t in read(root/'catalog/tools.json')}
suite=root/'progress/evidence/site-integration/D02-D03-D06-R01-R02-R03-R04-R05-P01-P02-P03'
for tool in sys.argv[1:] or ['R02','R03']:
    assert tool in ['R02','R03']
    release=root/'release'/tool/'0.1.0';ev=root/'progress/evidence'/tool/'0.1.0'
    work=ev/'site-public/full-native-work';downloads=ev/'site-public/all-version-downloads'
    lock=next(x for x in locks if x['tool']==tool and x['version']=='0.1.0')
    for name,digest in lock['files'].items(): assert sha(release/name)==digest
    html,runtime=sha(release/'index.html'),sha(release/'runtime.json')
    a,b=read(work/'result.json'),read(downloads/'result.json')
    for directory,result in [(work,a),(downloads,b)]:
        execution=read(directory/'execution.json')
        assert execution['exit_code']==0 and execution['finance_assertions_preserved']
        assert execution['host']=='https://aiplus-guance.streamlit.app/~/+/'
        assert execution['source_validator_sha256']==sha(root/execution['source_validator'])
        assert execution['executed_validator_sha256']==sha(directory/'executed-public-validator.ts')
        assert result['official_website'] and result['public_site_verified'] and result['site_sha256']==deployed
        assert result.get('html_sha256',result.get('html_sha'))==html
        assert result.get('runtime_sha256',result.get('runtime_sha'))==runtime
        normalized=re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',(directory/'public-srcdoc.html').read_text(),count=1)
        assert hashlib.sha256(normalized.encode()).hexdigest()==deployed
    local=read(suite/tool/'site-local/result.json')
    assert local['site_sha256']==deployed and a['checks']==local['checks']
    assert len(a['checks'])==({'R02':10,'R03':35}[tool])
    assert len(a['geometry'])==({'R02':30,'R03':50}[tool])
    assert a['errors']==a['processing_requests']==[] and a['forced_clicks']==0
    if tool=='R03':
        assert all('/R03/0.1.0/' in p for p in a['programs'])
        for name,digest in a['downloadHashes'].items(): assert sha(work/name)==digest
    # Standalone file-protocol evidence is distinct from the public results.
    formal=read(ev/'formal-browser/result.json')
    assert formal['errors']==formal['requests']==[]
    assert formal.get('formal_html_sha',formal.get('html_sha'))==html
    assert len(formal['results'])==({'R02':35,'R03':32}[tool])
    if tool=='R03': assert formal['offline'] and formal['file_protocol'] and formal['runtime_sha']==runtime
    direct=b['downloads'];assert len(direct)==({'R02':11,'R03':9}[tool])
    assert b['checks']==read(suite/tool/'downloads/result.json')['checks']
    for name,digest in direct.items(): assert digest==sha(release/name)==sha(downloads/'site-local-downloads'/name)
    # References and supplementary sample CSVs also ship in the actual clicked
    # offline ZIP. Audit every member, not just its index.html or top-level hash.
    offline=downloads/'site-local-downloads'/(tool+'-0.1.0-离线包.zip')
    nonzip={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
    with zipfile.ZipFile(offline) as z:
        assert set(z.namelist())=={tool+'/'+n for n in nonzip}
        for name in nonzip: assert hashlib.sha256(z.read(tool+'/'+name)).hexdigest()==sha(release/name)
    independent_path=root/'progress/evidence/shared'/('2026-10-03-'+tool+'-independent-review.json')
    independent=read(independent_path);assert independent['passed']
    engine='tools/'+catalog[tool]['folder']+'/src/engine.ts'
    assert independent.get('engine_sha256',independent.get('source_sha256'))==sha(root/engine)
    cases=independent['results'] if tool=='R02' else independent['cases']
    assert len(cases)==({'R02':10,'R03':8}[tool])
    with zipfile.ZipFile(release/(tool+'-0.1.0-源码.zip')) as z:
        snapshot=json.loads(z.read('source-snapshot.json'))
        for name,digest in snapshot['file_sha256'].items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest
        assert snapshot['file_sha256'][engine]==sha(root/engine)
    rebuild,assets=read(ev/'source-rebuild.json'),read(ev/'source-rebuild-assets.json')
    assert rebuild['source_zip_sha256']==assets['source_zip_sha256']==sha(release/(tool+'-0.1.0-源码.zip'))
    assert len(rebuild['commands'])==4 and all(c['exit_code']==0 for c in rebuild['commands'])
    assert set(assets['files'])==nonzip
    for name,item in assets['files'].items():
        assert item['release_sha256']==sha(release/name)
        assert item['bytes_identical'] or name.endswith('.xlsx') and item['content_identical_except_created_modified']
    visual=read(work/'root-visual-review.json');assert visual['reviewed']
    assert len(visual['screenshots'])==2
    for name,digest in visual['screenshots'].items(): assert sha(ev/'site-public'/name)==digest
    actual_work_files={p.name:sha(p) for p in work.iterdir() if p.is_file() and p.suffix in ['.json','.xlsx','.csv'] and p.name not in ['execution.json','result.json','root-visual-review.json']}
    result={'tool':tool,'version':'0.1.0','accepted':True,'public_acceptance':True,
            'site_sha256':deployed,'html_sha256':html,'runtime_sha256':runtime,
            'source_zip_sha256':rebuild['source_zip_sha256'],'public_groups':len(a['checks']),
            'direct_public_version_downloads':len(direct),'offline_zip_members_verified':len(nonzip),
            'independent_cases':len(cases),'actual_work_files':actual_work_files,
            'public_result_sha256':sha(work/'result.json'),'public_download_result_sha256':sha(downloads/'result.json'),
            'scope':'formal file://, isolated source rebuild/all assets, independent finance, actual original/public website complete workflows, clicked version files and every offline ZIP member',
            'platform':'macOS isolated Chromium; Windows actual machine unverified','errors':[]}
    (ev/'site-public-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(tool,'public final evidence accepted:',len(a['checks']),'groups,',len(direct),'direct downloads,',len(nonzip),'offline contents')
