"""Rebuild the actual handed-off candidate ZIP; separate from formal release acceptance."""
from pathlib import Path
import hashlib,json,subprocess,tempfile,zipfile

root=Path(__file__).resolve().parents[1]
out=root/'progress/evidence/K05/0.1.0/root-candidate-zip-rebuild';out.mkdir(parents=True,exist_ok=True)
source=root/'progress/evidence/K05/0.1.0/source-rebuild/K05-candidate-source.zip'
work=Path(tempfile.mkdtemp(prefix='root-k05-actual-zip-',dir='/private/tmp'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((source.parent.parent/'handoff-manifest.json').read_text())
assert sha(source)==manifest['groups']['evidence']['files'][str(source.relative_to(root))]['sha256']
with zipfile.ZipFile(source) as z:
    names=z.namelist();assert len(names)==len(set(names))
    assert sum(i.file_size for i in z.infolist())<=30*1024*1024
    for name in names:
        p=Path(name)
        assert not p.is_absolute() and '..' not in p.parts and 'node_modules' not in p.parts
        assert (work/p).resolve().is_relative_to(work)
    z.extractall(work)
assert (work/'package-lock.json').is_file()
commands=[['npm','ci','--offline','--ignore-scripts'],['node','--import','tsx','--test','tools/K05-存货跌价测算/tests/engine.test.ts'],['./node_modules/.bin/tsc','--noEmit','-p','tools/K05-存货跌价测算/tsconfig.json'],['node','--import','tsx','tools/K05-存货跌价测算/scripts/build-candidate.ts']]
results=[];compared={}
try:
    for i,cmd in enumerate(commands):
        with (out/f'{i+1}.log').open('w') as log:
            result=subprocess.run(cmd,cwd=work,stdout=log,stderr=subprocess.STDOUT)
        results.append({'command':cmd,'exit_code':result.returncode})
        assert result.returncode==0,cmd
    baseline=root/'tools/K05-存货跌价测算/candidate/0.1.0'
    files=sorted(p.name for p in baseline.iterdir() if p.is_file())
    assert len(files)==17
    for name in files:
        expected=sha(baseline/name);actual=sha(work/'tools/K05-存货跌价测算/candidate/0.1.0'/name)
        compared[name]={'original':expected,'rebuilt':actual}
        assert expected==actual,name
finally:
    passed=len(results)==4 and all(r['exit_code']==0 for r in results) and len(compared)==17 and all(v['original']==v['rebuilt'] for v in compared.values())
    report={'passed':passed,'scope':'actual candidate source ZIP extraction and rebuild; not formal release source acceptance','source_zip_sha256':sha(source),'temporary_workspace':str(work),'commands':results,'compared':compared,'extracted_members':len(names)}
    (out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':passed,'commands':len(results),'compared':len(compared),'extracted_members':len(names)}))
