"""Execute final-stage regressions with each subprocess exit retained.

Root must separately confirm the parent PTY's terminal status.
Frozen download validators receive exact count-only adapters.
"""
from pathlib import Path
import hashlib,json,subprocess,runpy
root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stage=root/'integration/native-site/site/index.html';digest=sha(stage)
ids=[e['id'] for e in json.loads((stage.parent/'registry.json').read_text())]
assert (len(ids)==20 and ids[-4:]==['K02','K01','T04','T06']) or (len(ids)==21 and ids[-5:]==['K02','K01','T04','T06','K03'])
suite=root/'progress/evidence/site-integration'/'-'.join(ids)
record=suite/'t06-final-stage-additional-commands.json'
result={'site_sha256':digest,'results':[],'passed':False}
adapters=runpy.run_path('scripts/current-stage-download-adapter.py')
tasks=[('T03','scripts/run-t03-current-stage.py',None),
       ('T05','tests/t05-native-site.ts',None),('T05','tests/t05-native-downloads.ts','adapted_t05_download'),
       ('K01','tests/k01-native-site.ts',None),('K01','tests/k01-native-downloads.ts','adapted_cost_download'),
       ('K02','tests/k02-native-site.ts',None),('K02','tests/k02-native-downloads.ts',None),
       ('original_modules','tests/original-financial-modules.ts',None)]
for tool,relative,adapter in tasks:
 assert sha(stage)==digest,'stage changed during exact regression'
 script=Path(relative).name;log=suite/(script+'.log')
 if adapter:
  row=adapters[adapter](script,log) if adapter=='adapted_cost_download' else adapters[adapter](log)
 else:
  command=['python3',relative] if relative.endswith('.py') else ['node','--import','tsx',relative]
  with log.open('w') as handle:r=subprocess.run(command,cwd=root,stdout=handle,stderr=subprocess.STDOUT)
  row={'script':script,'exit_code':r.returncode,'test_sha256':sha(root/relative)}
 row.update(tool=tool,script_path=relative,log=str(log.relative_to(root)))
 result['results'].append(row);record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(tool,script,row['exit_code'],flush=True)
 if row['exit_code']:raise SystemExit(1)
result['passed']=True;record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
