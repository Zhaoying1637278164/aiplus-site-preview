"""Check actual public T03 execution against exact local finance and version assets."""
from pathlib import Path
import json,hashlib,zipfile,subprocess,sys
root=Path.cwd();ev=root/'progress/evidence/T03/0.1.0';base=ev/'site-public';release=root/'release/T03/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
subprocess.run([sys.executable,'scripts/check-t03-local-evidence.py'],check=True)
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
for mode,source,local_folder,groups in [('work','t03-native-site.ts','site-local',19),('supplement','t03-native-supplement.ts','site-local-supplement',9)]:
 directory=base/mode;e=read(directory/'execution.json');d=read(directory/'result.json');local=read(ev/local_folder/'result.json')
 assert e['actual_root_exit_code']==0 and e['financial_assertions_preserved'] and e['expected_site_sha256']==site
 assert e['source_validator_sha256']==sha(root/'tests'/source)
 assert e['executed_validator_sha256']==sha(directory/'executed-public-validator.ts')
 original=(root/'tests'/source).read_text();executed=(directory/'executed-public-validator.ts').read_text()
 if mode=='work':assert executed==original
 else:
  import re
  expected=original.replace("path.resolve('progress/evidence/T03/0.1.0/site-local-supplement')",'path.resolve('+json.dumps(str(directory),ensure_ascii=False)+')')
  expected=re.sub(r"from '([^']+)'",lambda m:'from '+json.dumps(str((root/'tests'/m[1]).resolve()),ensure_ascii=False) if m[1].startswith('.') else m[0],expected)
  assert executed==expected,'Supplement financial code changed'

 assert d['passed'] and d['site_sha256']==site and d['candidate_sha256']==html and d['runtime_sha256']==runtime
 assert len(d['checks'])==groups and d['checks']==local['checks'] and d['cells']==local['cells']
 assert d['errors']==[] and d['requests']==[]
 assert d['programs'] and all(x.startswith('https://aiplus-guance.streamlit.app/') and '/T03/0.1.0/runtime.json' in x for x in d['programs'])
 doc=(directory/'actual-srcdoc.html').read_text();import re
 assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
 assert len(d['downloads'])==len(local['downloads'])
 for item in d['downloads']:
  p=directory/item.get('filename',item.get('file'));assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
 if mode=='work':assert len(d['geometry'])==36 and set(x['width'] for x in d['geometry'])=={1440,390,320}
e=read(base/'downloads/execution.json');directory=base/'downloads/T03/downloads';d=read(directory/'result.json')
assert e['actual_root_exit_code']==0 and e['financial_assertions_preserved'] and e['expected_site_sha256']==site
assert e['source_validator_sha256']==sha(root/'tests/t03-native-downloads.ts') and e['executed_validator_sha256']==sha(base/'downloads/executed-public-validator.ts')
executed=(base/'downloads/executed-public-validator.ts').read_text()
normalized=re.sub(r"const publicDoc=[\s\S]*?await writeFile\(out\+'/public-srcdoc.html',publicDoc\);",'',executed).replace('await page.waitForTimeout(1100);','')
assert normalized==(root/'tests/t03-native-downloads.ts').read_text(),'Download validator original checks changed'

assert d['passed'] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime and d['errors']==[]
doc=(directory/'public-srcdoc.html').read_text();assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']};assert set(d['downloads'])==expected
for name,h in d['downloads'].items():assert sha(directory/'site-local-downloads'/name)==h==sha(release/name)
with zipfile.ZipFile(directory/'site-local-downloads/T03-0.1.0-离线包.zip') as z:
 members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert set(z.namelist())=={'T03/'+n for n in members}
 for name in members:assert z.read('T03/'+name)==(release/name).read_bytes()
visual=read(base/'root-visual-review.json');assert visual['actual_viewed_by_root'] and visual['public'] and len(visual['images'])>=2
for image in visual['images']:assert sha(root/image['path'])==image['sha256']
result={'tool':'T03','version':'0.1.0','accepted':True,'public_acceptance':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':sha(release/'T03-0.1.0-源码.zip'),'public_work_groups':28,'public_work_downloads':59,'public_unique_version_files':len(expected),'platform':'macOS arm64 isolated Playwright Chromium; Windows real machine unverified','errors':[]}
(ev/'site-public-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('T03 actual public exact-version finance and complete downloads passed')
