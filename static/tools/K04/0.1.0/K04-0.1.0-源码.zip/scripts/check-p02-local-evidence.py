"""P02 same-version local delivery audit; no public acceptance or overall site gate."""
from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();release=root/'release/P02/0.1.0';ev=root/'progress/evidence/P02/0.1.0';suite=root/'progress/evidence/site-integration/payables-P01-P02-P03';errors=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,msg):
 if not ok:errors.append(msg)
def read(p):
 if not p.is_file():errors.append(str(p)+': missing');return {}
 return json.loads(p.read_text())
h=sha(release/'index.html');runtime=sha(release/'runtime.json');site=sha(root/'integration/native-site/site/index.html')
formal=read(ev/'formal-browser/result.json')
check(formal.get('formal') is True and formal.get('index_sha256')==h and formal.get('runtime_sha256')==runtime,'formal bytes binding')
check(len(formal.get('checks',[]))==17 and formal.get('errors')==[] and formal.get('external_requests')==[],'formal executed/safety scope')
check(len(formal.get('downloads',[]))==29,'formal actual29 downloads')
for d in formal.get('downloads',[]):
 p=ev/'formal-browser'/d['proof_file'];check(p.is_file() and p.stat().st_size==d['bytes'] and sha(p)==d['sha256'],'formal saved download '+d['proof_file'])
with zipfile.ZipFile(release/'P02-0.1.0-离线包.zip') as z:check(hashlib.sha256(z.read('P02/index.html')).hexdigest()==h,'offline ZIP index')
s=read(ev/'source-rebuild.json');check(s.get('source_zip_sha256')==sha(release/'P02-0.1.0-源码.zip'),'source ZIP binding')
check(len(s.get('commands',[]))==4 and all(c.get('exit_code')==0 for c in s.get('commands',[])),'source four commands')
for n,d in [('index.html',h),('runtime.json',runtime)]:check(s.get('files',{}).get(n)=={'release_sha256':d,'rebuilt_sha256':d,'identical':True},'rebuilt exact '+n)
a=read(ev/'source-rebuild-assets.json');check(a.get('source_zip_sha256')==s.get('source_zip_sha256'),'source asset archive binding');expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};check(set(a.get('files',{}))==expected,'all16 assets scope')
for n,d in a.get('files',{}).items():check(d.get('release_sha256')==sha(release/n) and (d.get('bytes_identical') is True or n.endswith('.xlsx') and d.get('content_identical_except_created_modified') is True and set(d.get('differing_entries',[]))<={'docProps/core.xml'}),'source asset contents '+n)
nav=read(suite/'navigation-P02-result.json');n=next((x for x in nav.get('results',[]) if x.get('tool')=='P02'),{})
check(nav.get('site_sha256')==site and n.get('passed') is True and len(n.get('geometry',[]))==24 and n.get('bottom_clicks_completed')==21,'actual original navigation binding/scope')
for row in n.get('geometry',[]):
 header=row['header'];bar=row['nav'];heading=row['heading'];check(bar['y']>=header['y']+header['height']-1 and bar['y']+bar['height']<1000 and heading['y']>=header['y']+header['height']-1 and heading['y']+heading['height']<1000,'navigation below actual header')
l=read(suite/'P02/site-local/result.json');check(l.get('passed') is True and l.get('site_sha256')==site and l.get('html_sha256')==h and l.get('runtime_sha256')==runtime,'actual site work binding')
check(len(l.get('checks',[]))==13 and l.get('errors')==[] and l.get('processing_requests')==[],'actual complete work/safety scope')
check(len(l.get('geometry',[]))==4,'actual import/restore narrow full header scope')
for row in l.get('geometry',[]):
 head=row['header']
 for key in ['tool_header','exit','nav']:
  box=row[key];check(box['y']>=head['y']+head['height']-1 and box['y']+box['height']<1000,'actual full tool head visible '+key)
for d in l.get('downloads',[]):
 p=suite/'P02/site-local'/d['filename'];check(p.is_file() and p.stat().st_size==d['bytes'] and sha(p)==d['sha256'],'actual work/download proof '+d['filename'])
downloads=l.get('version_downloads',{});expected_downloads=expected-{'index.html','runtime.json','build-manifest.json'}|{'P02-0.1.0-离线包.zip','P02-0.1.0-源码.zip'};check(set(downloads)==expected_downloads,'all15 original detail versions scope')
for name,digest in downloads.items():check(digest==sha(release/name) and digest==sha(suite/'P02/site-local/version-downloads'/name),'actual version download '+name)
with zipfile.ZipFile(release/'P02-0.1.0-源码.zip') as z:
 for name in ['tests/p02-native-site.ts','tests/payables-native-navigation.ts','scripts/check-p02-local-evidence.py']:
  check(name in z.namelist(),'final source validator missing '+name)
  if name in z.namelist():check(z.read(name)==(root/name).read_bytes(),'final source validator changed '+name)
result={'tool':'P02','version':'0.1.0','site_sha256':site,'html_sha256':h,'runtime_sha256':runtime,'local_exact_gates_passed':not errors,'public_acceptance':False,'accepted':False,'errors':errors}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(bool(errors))
