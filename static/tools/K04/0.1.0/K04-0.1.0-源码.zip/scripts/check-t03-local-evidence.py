"""Audit exact T03 delivery evidence; this does not grant public acceptance."""
import json,hashlib,zipfile
from pathlib import Path
root=Path.cwd();ev=root/'progress/evidence/T03/0.1.0';release=root/'release/T03/0.1.0'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
formal_commands=read(ev/'root-formal-commands.json');native_commands=read(ev/'root-native-commands.json')
for folder,script,commands,key,groups,downloads,cells in [
 ('formal-browser','t03-formal-browser.ts',formal_commands,'formal_browser',17,56,9414),
 ('formal-supplement','t03-formal-supplement.ts',formal_commands,'formal_supplement',8,7,264),
 ('site-local','t03-native-site.ts',native_commands,'native_work',19,52,9414),
 ('site-local-supplement','t03-native-supplement.ts',native_commands,'native_supplement',9,7,264)]:
 d=read(ev/folder/'result.json');c=commands[key]
 assert c['exit_code']==0 and c.get('script_sha256',c.get('validator_sha256'))==sha(root/'tests'/script)
 assert c['result_sha256']==sha(ev/folder/'result.json')
 assert d['passed'] and d['candidate'] is False and d['official_website'] is False
 assert d['candidate_sha256']==html and d['runtime_sha256']==runtime
 assert d['errors']==[] and d['requests']==[]
 assert len(d['checks'])==groups and len(d['downloads'])==downloads and d['cells']==cells
 if folder.startswith('site-'):
  assert d['site_sha256']==site
  assert d['programs'] and all('/T03/0.1.0/runtime.json' in x for x in d['programs'])
 for item in d['downloads']:
  file=ev/folder/item.get('filename',item.get('file'))
  assert sha(file)==item['sha256'] and file.stat().st_size==item['bytes']
local=read(ev/'site-local/result.json');assert len(local['geometry'])==36
assert set(r['width'] for r in local['geometry'])=={1440,390,320}
assert 'same_version_formal_whole_work_equal' in local['checks']
for folder,name in [('formal-browser','formal-visual-review.json'),('site-local','site-local/root-visual-review.json')]:
 d=read(ev/name)
 assert d.get('actual_viewed',d.get('actual_viewed_by_root')) is True
 images=d.get('screenshots',d.get('images'));assert len(images)==2
 for image in images:assert sha(root/image['path'])==image['sha256']
directory=ev/'all-version-downloads/T03/downloads';d=read(directory/'result.json')
assert d['passed'] and d['errors']==[] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime
c=native_commands['native_downloads'];assert c['exit_code']==0 and c['validator_sha256']==sha(root/'tests/t03-native-downloads.ts') and c['result_sha256']==sha(directory/'result.json')
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert set(d['downloads'])==expected
for name,h in d['downloads'].items():assert sha(directory/'site-local-downloads'/name)==h==sha(release/name)
with zipfile.ZipFile(release/'T03-0.1.0-离线包.zip') as z:
 members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
 assert set(z.namelist())=={'T03/'+n for n in members}
 for n in members:assert z.read('T03/'+n)==(release/n).read_bytes()
source=release/'T03-0.1.0-源码.zip';assert source.stat().st_size<=24*1024*1024
rebuild=read(ev/'source-rebuild.json');assert rebuild['source_zip_sha256']==sha(source)
assert len(rebuild['commands'])==4 and all(c['exit_code']==0 for c in rebuild['commands'])
for name in ['index.html','runtime.json']:
 item=rebuild['files'][name];assert item['identical'] and item['release_sha256']==item['rebuilt_sha256']==sha(release/name)
assets=read(ev/'source-rebuild-assets.json');assert assets['source_zip_sha256']==sha(source)
assert set(assets['files'])=={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
for name,item in assets['files'].items():
 assert item['release_sha256']==sha(release/name)
 assert item['bytes_identical'] or name.endswith('.xlsx') and item['content_identical_except_created_modified']
with zipfile.ZipFile(source) as z:
 snap=json.loads(z.read('source-snapshot.json'))
 for name,h in snap['file_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==h
 for name in ['tests/t03-independent-review.ts','tests/t03-formal-browser.ts','tests/t03-formal-supplement.ts','tests/t03-native-site.ts','tests/t03-native-supplement.ts','tests/t03-native-downloads.ts','scripts/check-t03-local-evidence.py']:
  assert z.read(name)==(root/name).read_bytes(),name
independent=read(root/'progress/evidence/shared/2026-10-04-T03-independent-review.json')
assert independent['passed'] and independent['actual_root_exit_code']==0 and len(independent['checks'])==12
assert independent['root_engine_sha256']==sha(root/'tools/T03-13周资金预测/src/engine.ts')
result={'tool':'T03','version':'0.1.0','local_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':sha(source),'local_work_groups':28,'version_files':len(expected),'public_acceptance':False,'accepted':False,'errors':[]}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('T03 exact local evidence passed; public acceptance separately required')
