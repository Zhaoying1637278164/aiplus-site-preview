"""Exact original-website workflow and version-download gate, separate from public acceptance."""
from pathlib import Path
import json,hashlib,re,zipfile
root=Path.cwd();ev=root/'progress/evidence/T04/0.2.0';release=root/'release/T04/0.2.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
for folder,script in [('site-local','t04-native-execution.ts'),('site-financial','t04-native-financial-browser.ts'),('T04/downloads','t04-native-downloads.ts')]:
 base=ev/folder;d=read(base/'result.json');c=read(base/'root-command.json');assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(root/'tests'/script) and c['site_sha256']==d['site_sha256']==site
 assert d['passed'] and not d['errors']
 if folder!='T04/downloads':
  assert d['requests']==[] and d['html_sha256']==html
  for x in d['downloads']:assert sha(base/x.get('filename',x.get('file')))==x['sha256']
  assert d['programs'] and len(set(d['programs']))==1 and d['programs'][0].endswith('/T04/0.2.0/runtime.json')
  doc=(base/'actual-srcdoc.html').read_text();assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
  if folder=='site-local':
   assert len(d['checks'])==15 and len(d['downloads'])==50 and d['runtime_sha256']==runtime and len(d['geometry'])==36
   for width in [1440,390,320]:
    rows=[g for g in d['geometry'] if g['width']==width];assert len(rows)==12 and len({g['page'] for g in rows})==12
    for g in rows:assert g['box']['y']>=76 and g['box']['y']+g['box']['height']<900
  else:assert d['groups']==4 and d['cells']==104 and len(d['downloads'])==4
 else:
  assert d['html_sha256']==html and d['runtime_sha256']==runtime and d['clicks']==22
  expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']};assert len(expected)==20 and set(d['downloads'])==expected
  for n,h in d['downloads'].items():assert sha(base/'site-local-downloads'/n)==h==sha(release/n)
  with zipfile.ZipFile(base/'site-local-downloads/T04-0.2.0-离线包.zip') as z:
   members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert set(z.namelist())=={'T04/'+n for n in members}
   for n in members:assert z.read('T04/'+n)==(release/n).read_bytes()
v=read(ev/'site-local/root-visual-review.json');assert v['actually_viewed'] and v['site_sha256']==site and len(v['images'])>=36
for x in v['images']:assert sha(root/x['path'])==x['sha256']
result={'tool':'T04','version':'0.2.0','native_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'workflow_groups':15,'work_downloads':50,'independent_workbook_cells':104,'geometry_pages':36,'version_files':20,'accepted':False,'Windows_real_machine':'unverified'}
(ev/'native-delivery-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
