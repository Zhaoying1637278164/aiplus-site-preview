"""Strict local delivery check. Original/public website remains a separate required gate."""
from pathlib import Path
import json,hashlib
root=Path.cwd();ev=root/'progress/evidence/T04/0.2.0';release=root/'release/T04/0.2.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
html=sha(release/'index.html');runtime=sha(release/'runtime.json')
commands=read(ev/'root-tests/commands.json');assert len(commands)==5 and all(x['exit_code']==0 and sha(root/x['log'])==x['log_sha256'] for x in commands)
assert '# tests 92' in (ev/'root-tests/0.log').read_text() and '# fail 0' in (ev/'root-tests/0.log').read_text()
ind=read(ev/'root-independent-review.json');assert ind['passed'] and ind['groups']==13 and ind['engine_sha256']==sha(root/'tools/T04-借款还本付息排程/src/execution.ts')
for name,n,cells in [('independent-review.json',15,558),('independent-execution-review.json',8,32)]:
 d=read(ev/name);assert d['passed'] and d['cases']==n and d['cells']==cells
base=ev/'root-formal';cmd=read(base/'root-command.json');assert cmd['actual_exit_code']==0 and cmd['actual_session_id'] and cmd['html_sha256']==html and cmd['runtime_sha256']==runtime
rows=read(base/'commands.json');assert len(rows)==4 and all(x['exit_code']==0 and sha(root/x['log'])==x['log_sha256'] for x in rows)
groups=downloads=0
for mode in ['candidate','execution','supplement','history']:
 d=read(base/mode/'result.json');assert d['passed'] and d['errors']==d['requests']==[] and d['html_sha256']==html
 if 'runtime_sha256' in d:assert d['runtime_sha256']==runtime
 groups+=len(d['checks']);downloads+=len(d.get('downloads',[]))
 ds=d.get('downloads',[]);assert len({x['filename'] for x in ds})==len(ds)
 for x in ds:assert sha(base/mode/x['filename'])==x['sha256']
assert groups==41 and downloads==108
for x in read(base/'validators.json'):
 assert sha(root/x['source'])==x['source_sha256'] and sha(root/x['executed'])==x['executed_sha256']
visual=read(base/'root-visual-review.json');assert visual['actually_viewed'] and len(visual['images'])==20
for x in visual['images']:assert sha(root/x['path'])==x['sha256']
finance=ev/'root-financial-browser';d=read(finance/'result.json');c=read(finance/'root-command.json');assert d['passed'] and c['actual_exit_code']==0 and c['script_sha256']==sha(root/'tests/t04-root-financial-browser.ts') and d['groups']==4 and d['cells']==104 and d['html_sha256']==html and d['errors']==d['requests']==[]
for x in d['downloads']:assert sha(finance/x['file'])==x['sha256']
source=read(ev/'source-rebuild.json');assert source['source_zip_sha256']==sha(release/'T04-0.2.0-源码.zip') and all(c['exit_code']==0 for c in source['commands']) and source['actual_root_exit_code']==0
for name,v in source['files'].items():assert v['identical'] and v['release_sha256']==sha(release/name)
assets=read(ev/'source-rebuild-assets.json');assert len(assets['files'])==21 and all(v['bytes_identical'] or (n.endswith('.xlsx') and v.get('content_identical_except_created_modified') and set(v.get('differing_entries',[]))<= {'docProps/core.xml'}) for n,v in assets['files'].items())
for lock in read(root/'catalog/release-locks.json')['releases']:
 for n,h in lock['files'].items():assert sha(root/'release'/lock['tool']/lock['version']/n)==h
result={'tool':'T04','version':'0.2.0','local_exact_gates_passed':True,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':source['source_zip_sha256'],'formal_groups':41,'formal_downloads':108,'root_independent_browser_cells':104,'accepted':False,'official_website':False,'Windows_real_machine':'unverified'}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
