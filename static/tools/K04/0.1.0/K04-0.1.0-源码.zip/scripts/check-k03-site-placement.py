"""Check actual original-site generation without changing staging or publishing."""
from pathlib import Path
import hashlib, json, re, runpy

root=Path(__file__).resolve().parents[1]
site=runpy.run_path(str(root/'scripts/site.py'))
base=(root/'website/base-index.html').read_text()
registry=[e for e in json.loads((root/'integration/native-site/site/registry.json').read_text()) if e['id']!='K03']
assert len(registry)==20 and not any(e['id']=='K03' for e in registry)
entries=[];file_sets=[]
for entry in registry:
    e=dict(entry);folder=root/'release'/e['id']/e['version']
    files=[f"{e['id']}-{e['version']}-离线包.zip",f"{e['id']}-{e['version']}-源码.zip"]
    files+=sorted(p.name for p in folder.iterdir() if p.is_file() and p.suffix!='.zip' and p.name not in ['index.html','runtime.json','build-manifest.json'])
    e['offlineSize']=f'{(folder/files[0]).stat().st_size/1024/1024:.1f} MB'
    entries.append(e);file_sets.append(files)
folder=root/'release/K03/0.1.0';runtime=folder/'runtime.json'
files=['K03-0.1.0-离线包.zip','K03-0.1.0-源码.zip']+sorted(p.name for p in folder.iterdir() if p.is_file() and p.suffix!='.zip' and p.name not in ['index.html','runtime.json','build-manifest.json'])
entries.append({'id':'K03','name':'存货库龄与周转','version':'0.1.0','detailRoute':'tool-cost-05','workspaceRoute':'work-K03','runtime':'app/static/tools/K03/0.1.0/runtime.json','sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'bytes':runtime.stat().st_size,'offlineSize':f'{(folder/files[0]).stat().st_size/1024/1024:.1f} MB','replacesOriginal':True})
file_sets.append(files)
generated=site['native_documents'](base,entries,file_sets,(root/'integration/native-host.js').read_text())
assert len(re.findall(r'\bdata-tool\s',generated))==87
assert len(re.findall(r'\bdata-tool\s[^>]*data-mod="cost"',generated))==7
assert generated.count('<template id="r-tool-cost-05">')==1
assert generated.count('<template id="r-work-K03">')==1
for route in ['cost-01','cost-02']:
    pattern=r'<template id="r-tool-'+route+r'">.*?</template>'
    assert re.search(pattern,base,re.S).group()==re.search(pattern,generated,re.S).group(),route
detail=re.search(r'<template id="r-tool-cost-05">.*?</template>',generated,re.S).group()
for text in ['存货库龄与周转','开始存货库龄与周转','十张底稿','期初库存层','收发台账']:
    assert text in detail,text
for text in ['开始账表对账','虚构左表.csv','虚构右表.csv']:
    assert text not in detail,text
assert 'function go(h)' in generated and 'function render(' in generated
out=root/'progress/evidence/K03/0.1.0/root-site-placement.json'
out.write_text(json.dumps({'passed':True,'scope':'pure generation of original-site catalogue/detail; no live website or publication claim','registered_tools':21,'catalogue_rows':87,'cost_rows':7,'replacement':'cost-05','preserved_templates':['cost-01','cost-02'],'download_files':files,'formal_runtime_sha256':entries[-1]['sha256'],'generator_sha256':hashlib.sha256((root/'scripts/site.py').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
print('K03 original-site placement: 21 programs, 87 rows, cost7; platform/dashboard preserved')
