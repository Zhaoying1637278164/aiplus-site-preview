"""Require actual public execution, exact current version and full archive readback."""
from pathlib import Path
import json,hashlib,zipfile,re
r=Path.cwd();ev=r/'progress/evidence/T06/0.1.0';release=r/'release/T06/0.1.0';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());site=sha(r/'integration/native-site/site/index.html')
b=ev/'site-public';d=read(b/'result.json');c=read(b/'root-command.json');assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(r/'tests/t06-public-site.ts') and c['result_sha256']==sha(b/'result.json')
assert c['endpoint']=='https://aiplus-guance.streamlit.app/~/+/' and d['official_website'] and d['public_verified'] and c['site_sha256']==d['site_sha256']==site
assert d['sha256']==sha(release/'index.html') and len(d['cases'])==17 and all(x.get('passed') is True or x.get('checked')==437 for x in d['cases']) and d['pageErrors']==d['externalRequests']==[] and d['offline']
assert len(d['programs'])==2 and all(p.startswith('https://aiplus-guance.streamlit.app/') and p.endswith('/T06/0.1.0/runtime.json') for p in d['programs'])
doc=(b/'actual-srcdoc.html').read_text();assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
b=ev/'site-public-archives/T06/downloads';d=read(b/'result.json');c=read(b/'root-command.json');assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(r/'tests/t06-native-downloads.ts') and c['result_sha256']==sha(b/'result.json')
assert c['endpoint']=='https://aiplus-guance.streamlit.app/~/+/' and c['site_sha256']==d['site_sha256']==site and d['passed'] and d['errors']==[] and d['clicks']==17
assert d['html_sha256']==sha(release/'index.html') and d['runtime_sha256']==sha(release/'runtime.json')
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']};assert len(expected)==15 and set(d['downloads'])==expected
for name,h in d['downloads'].items():assert sha(b/'site-local-downloads'/name)==sha(release/name)==h
with zipfile.ZipFile(b/'site-local-downloads/T06-0.1.0-离线包.zip') as z:
 expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert set(z.namelist())=={'T06/'+p for p in expected}
 for p in expected:assert z.read('T06/'+p)==(release/p).read_bytes()
visual=read(ev/'site-public/root-visual-review.json');assert visual['actual_review'] and visual['site_sha256']==site
for name,h in visual['images'].items():assert sha(ev/'site-public'/name)==h
assert len(visual['images'])>=2
local=read(ev/'local-delivery-audit.json');assert local['local_exact_gates_passed'] and local['site_sha256']==site
result={'tool':'T06','version':'0.1.0','public_exact_gates_passed':True,'site_sha256':site,'html_sha256':sha(release/'index.html'),'runtime_sha256':sha(release/'runtime.json'),'workflow_groups':17,'checked_workbook_cells':437,'version_download_clicks':17,'unique_version_files':15,'Windows_real_machine':'unverified'}
(ev/'site-public-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
