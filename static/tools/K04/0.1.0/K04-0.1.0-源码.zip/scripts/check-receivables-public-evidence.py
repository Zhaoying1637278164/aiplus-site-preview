"""Final R04/R05 audit: immutable release, real public work, rebuild and finance."""
from pathlib import Path
import hashlib, json, re, sys, zipfile

root = Path.cwd()
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
deployed = read(root/'website/deployed-site.json')['site_sha256']
locks = read(root/'catalog/release-locks.json')['releases']
catalog = {t['id']: t for t in read(root/'catalog/tools.json')}
suite = root/'progress/evidence/site-integration/D02-D03-D06-R01-R02-R03-R04-R05-P01-P02-P03'
for tool in sys.argv[1:] or ['R04', 'R05']:
    assert tool in ['R04', 'R05']
    release = root/'release'/tool/'0.1.0'
    ev = root/'progress/evidence'/tool/'0.1.0'
    public = ev/'site-public/full-native-work'
    frozen = next(x for x in locks if x['tool']==tool and x['version']=='0.1.0')
    for name, digest in frozen['files'].items(): assert sha(release/name)==digest, name
    html, runtime = sha(release/'index.html'), sha(release/'runtime.json')
    formal = read(ev/'formal-browser/result.json')
    assert formal['formal'] and formal['errors']==[] and formal['external']==[]
    assert formal['html_sha256']==html
    if tool=='R04':
        assert formal['offline'] and len(formal['checks'])==28
        assert formal['runtime_sha256']==hashlib.sha256(read(release/'runtime.json')['js'].encode()).hexdigest()
    else:
        assert formal['success'] and len(formal['results'])==20
        assert formal['runtime_sha256']==runtime and formal['persistence']==formal['hostPersistence']==[]
    execution, actual = read(public/'execution.json'), read(public/'result.json')
    assert execution['exit_code']==0 and execution['finance_assertions_preserved']
    assert execution['host']=='https://aiplus-guance.streamlit.app/~/+/'
    assert execution['source_validator_sha256']==sha(root/'tests/r04-r05-native-site.ts')
    assert execution['executed_validator_sha256']==sha(public/'executed-public-validator.ts')
    assert actual['passed'] and actual['official_website']
    assert actual['site_sha256']==deployed and actual['html_sha256']==html and actual['runtime_sha256']==runtime
    assert actual['errors']==actual['processing_requests']==[] and actual['forced_clicks']==0
    local = read(suite/tool/'site-local/result.json')
    assert local['passed'] and local['site_sha256']==deployed
    assert len(actual['checks'])==9 and actual['checks']==local['checks']
    assert len(actual['geometry'])==24
    for item in actual['geometry']:
        assert item['width'] in [1440,390,320]
        bar, nav, heading = item['header'], item['allNavigation'], item['heading']
        assert nav['y']>=bar['y']+bar['height']-1 and nav['y']+nav['height']<1000
        assert heading['y']>=bar['y']+bar['height']-1 and heading['y']+heading['height']<1000
    document = re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>', '', (public/'public-srcdoc.html').read_text(), count=1)
    assert hashlib.sha256(document.encode()).hexdigest()==deployed
    for name,digest in actual['downloads'].items(): assert sha(public/name)==digest, name
    expected = {p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
    assert set(actual['version_downloads'])==expected
    for name,digest in actual['version_downloads'].items():
        assert digest==sha(release/name)==sha(public/'version-downloads'/name)
    independent_path = root/'progress/evidence/shared'/('2026-10-03-'+tool+'-provisional-independent-review.json')
    independent = read(independent_path)
    assert independent['passed'] and independent['source_unchanged']
    assert len(independent['cases'])==({'R04':9,'R05':11}[tool])
    assert all(c['passed'] for c in independent['cases'])
    engine = 'tools/'+catalog[tool]['folder']+'/src/engine.ts'
    assert independent['source_sha256_before']==independent['source_sha256_after']==sha(root/engine)
    with zipfile.ZipFile(release/(tool+'-0.1.0-源码.zip')) as z:
        snapshot = json.loads(z.read('source-snapshot.json'))
        for name,digest in snapshot['file_sha256'].items():
            assert hashlib.sha256(z.read(name)).hexdigest()==digest, name
        assert snapshot['file_sha256'][engine]==sha(root/engine)
        # Public validation adds host/output parameters to the older archived root
        # validator. Product bytes and all financial assertions remain bound above.
    rebuild, assets = read(ev/'source-rebuild.json'), read(ev/'source-rebuild-assets.json')
    assert rebuild['source_zip_sha256']==assets['source_zip_sha256']==sha(release/(tool+'-0.1.0-源码.zip'))
    assert len(rebuild['commands'])==4 and all(c['exit_code']==0 for c in rebuild['commands'])
    assert set(assets['files'])=={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
    for name,item in assets['files'].items():
        assert item['release_sha256']==sha(release/name)
        assert item['bytes_identical'] or name.endswith('.xlsx') and item['content_identical_except_created_modified']
    visual = read(public/'root-visual-review.json')
    assert visual['reviewed'] and len(visual['screenshots'])==2
    for name,digest in visual['screenshots'].items(): assert sha(public/name)==digest
    result = {'tool':tool,'version':'0.1.0','accepted':True,'public_acceptance':True,
              'site_sha256':deployed,'html_sha256':html,'runtime_sha256':runtime,
              'source_zip_sha256':rebuild['source_zip_sha256'],'public_groups':9,
              'unique_public_version_files':len(expected),'independent_cases':len(independent['cases']),
              'public_result_sha256':sha(public/'result.json'),'public_execution_sha256':sha(public/'execution.json'),
              'independent_evidence_sha256':sha(independent_path),
              'scope':'formal file://, isolated source rebuild, independent finance, original/public website whole work and all version downloads',
              'platform':'macOS isolated Chromium; Windows actual machine unverified','errors':[]}
    (ev/'site-public-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(tool,'public final evidence accepted: 9 groups,',len(expected),'unique version files')
