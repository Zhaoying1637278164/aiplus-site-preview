"""Replay reviewed K03 validators on the public website; retain literal expectations.

Only output paths, relative import resolution, deployed document capture and
archive click pacing differ. Program bytes and financial assertions stay intact.
"""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path.cwd();mode=sys.argv[1];assert mode in ['work','financial','downloads']
script={'work':'k03-native-site.ts','financial':'k03-native-financial-browser.ts','downloads':'k03-native-downloads.ts'}[mode]
base=root/'progress/evidence/K03/0.1.0/site-public'/mode;base.mkdir(parents=True,exist_ok=True)
source=root/'tests'/script;original=source.read_text()
def resolve_import(m):
 return 'from '+json.dumps(str((root/'tests'/m[2]).resolve()),ensure_ascii=False) if m[2].startswith('.') else m[0]
executed=re.sub(r"from (['\"])([^'\"]+)\1",resolve_import,original)
if mode!='downloads':
 old='progress/evidence/K03/0.1.0/'+('site-local' if mode=='work' else 'site-financial-browser')
 assert executed.count(old)==1
 executed=executed.replace(old,str(base))
else:
 target="await page.goto(host);const frame=page.frameLocator('iframe').first();"
 capture="await page.locator('iframe').first().waitFor({timeout:120000});const actualDoc=await page.locator('iframe').first().getAttribute('srcdoc');assert(actualDoc);assert.equal(sha(Buffer.from(actualDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')));await writeFile(out+'/actual-srcdoc.html',actualDoc);"
 assert executed.count(target)==1
 executed=executed.replace(target,target+capture)
 executed=executed.replace("const pending=page.waitForEvent('download');","await page.waitForTimeout(1100);const pending=page.waitForEvent('download');")
url='https://aiplus-guance.streamlit.app/~/+/'
executed="assert.equal(new URL(process.env.AIPLUS_NATIVE_SITE_URL||'').href,"+json.dumps(url)+");\n"+executed
file=base/'executed-public-validator.ts';file.write_text(executed)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,AIPLUS_NATIVE_SITE_URL=url,AIPLUS_EVIDENCE_DIR=str(base))
record={'mode':mode,'public_url':url,'expected_site_sha256':sha(root/'integration/native-site/site/index.html'),'source_validator_sha256':sha(source),'executed_validator_sha256':sha(file),'native_bootstrap_sha256':sha(root/'tests/k03-native-bootstrap.ts'),'adaptation':'exact original assertions; output paths and absolute imports; downloads deployed srcdoc capture and pacing only'}
with (base/'command.log').open('w') as log:
 result=subprocess.run(['node','--import','tsx',str(file)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record['actual_subprocess_exit_code']=result.returncode
(base/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(mode,'actual subprocess exit',result.returncode,flush=True)
raise SystemExit(result.returncode)
