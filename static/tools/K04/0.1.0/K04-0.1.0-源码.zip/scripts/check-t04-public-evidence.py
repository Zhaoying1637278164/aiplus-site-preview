"""Actual public T04 workflow, independent finance and exact downloads gate."""
from pathlib import Path
import json,hashlib,re,subprocess,sys,zipfile
root=Path.cwd();ev=root/'progress/evidence/T04/0.2.0';base=ev/'site-public';release=root/'release/T04/0.2.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
subprocess.run([sys.executable,'scripts/check-native-evidence.py'],check=True)
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
for mode,script in [('work','t04-native-execution.ts'),('financial','t04-native-financial-browser.ts'),('downloads','t04-native-downloads.ts')]:
 folder=base/mode;e=read(folder/'execution.json')
 assert e['actual_subprocess_exit_code']==e['actual_root_exit_code']==e['actual_root_terminal_exit_code']==0 and e['actual_root_session_id']
 assert e['public_browser'] and e['source_validator_sha256']==sha(root/'tests'/script) and e['expected_site_sha256']==site
 original=(root/'tests'/script).read_text()
 def resolve_import(m):
  value=json.loads('"'+m[2]+'"') if m[1]=='"' else m[2]
  return 'from '+json.dumps(str((root/'tests'/value).resolve()),ensure_ascii=False) if value.startswith('.') else m[0]
 expected=re.sub(r"from (['\"])([^'\"]+)\1",resolve_import,original)
 if mode=='downloads':
  target="await page.goto(host);const frame=page.frameLocator('iframe').first();"
  insertion="await page.locator('iframe').first().waitFor({timeout:120000});await page.waitForFunction(()=>document.querySelector('iframe')?.getAttribute('srcdoc')?.includes('__AIPlusRegistry'),undefined,{timeout:120000});const actualDoc=await page.locator('iframe').first().getAttribute('srcdoc');assert(actualDoc);assert.equal(sha(Buffer.from(actualDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')));await writeFile(out+'/actual-srcdoc.html',actualDoc);"
  assert expected.count(target)==1;expected=expected.replace(target,target+insertion).replace("const pending=page.waitForEvent('download');","await page.waitForTimeout(1100);const pending=page.waitForEvent('download');")
 executed=folder/'executed-public-validator.ts';assert executed.read_text()==expected and e['executed_validator_sha256']==sha(executed)
 doc=(folder/('T04/downloads/actual-srcdoc.html' if mode=='downloads' else 'actual-srcdoc.html')).read_text()
 assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
for folder,localfolder,groups,count in [('work','site-local',15,50),('financial','site-financial',4,4)]:
 d=read(base/folder/'result.json');local=read(ev/localfolder/'result.json')
 assert d['passed'] and d['site_sha256']==site and d['html_sha256']==html and d['errors']==d['requests']==[] and d['checks']==local['checks']
 assert len(d['downloads'])==count
 assert d['programs'] and all(x.startswith('https://aiplus-guance.streamlit.app/') and x.endswith('/T04/0.2.0/runtime.json') for x in d['programs'])
 for x in d['downloads']:
  p=base/folder/x.get('filename',x.get('file'));assert sha(p)==x['sha256']
 if folder=='work':
  assert len(d['checks'])==groups and d['runtime_sha256']==runtime and len(d['geometry'])==36
  assert {g['width'] for g in d['geometry']}=={1440,390,320}
  for g in d['geometry']:assert g['box']['y']>=76 and g['box']['y']+g['box']['height']<900
 else:assert d['groups']==groups and d['cells']==104
directory=base/'downloads/T04/downloads';d=read(directory/'result.json')
assert d['passed'] and not d['errors'] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime and d['clicks']==22
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==20 and set(d['downloads'])==expected
for n,h in d['downloads'].items():assert sha(directory/'site-local-downloads'/n)==h==sha(release/n)
with zipfile.ZipFile(directory/'site-local-downloads/T04-0.2.0-离线包.zip') as z:
 members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert set(z.namelist())=={'T04/'+n for n in members}
 for n in members:assert z.read('T04/'+n)==(release/n).read_bytes()
v=read(base/'root-image-review.json');assert v['actually_viewed'] and len(v['images'])>=2
for x in v['images']:assert sha(root/x['path'])==x['sha256']
result={'tool':'T04','version':'0.2.0','site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'public_work_groups':15,'public_work_downloads':50,'independent_financial_cells':104,'public_version_files':20,'public_navigation_geometry':36,'all_exact_gates_passed':True,'accepted':True,'Windows_real_machine':'unverified','errors':[]}
(ev/'site-public-final.json').write_text(json.dumps(result,indent=2)+'\n');print('T04 exact public acceptance passed')
