"""Full R04/R05 and P01/P02/P03 regression on final original website."""
import pathlib,hashlib,json,subprocess,os
root=pathlib.Path.cwd();site=root/'integration/native-site/site/index.html';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();digest=sha(site)
ids=[e['id'] for e in json.loads((root/'integration/native-site/site/registry.json').read_text())]
suite=root/'progress/evidence/site-integration'/'-'.join(ids)
suite.mkdir(parents=True,exist_ok=True)
record=suite/'additional-existing-commands.json';result={'site_sha256':digest,'results':[],'passed':False}
for script in ['r04-r05-native-site.ts','r04-r05-native-downloads.ts','p01-native-site.ts','p02-native-site.ts','p03-native-site.ts','payables-native-navigation.ts']:
 assert sha(site)==digest,'stage changed'
 env=dict(os.environ,AIPLUS_NATIVE_SITE_URL='http://127.0.0.1:8515',AIPLUS_EVIDENCE_DIR=str(suite)) if script.startswith('r04') else dict(os.environ)
 log=suite/(script+'.log')
 with log.open('w') as handle:execution=subprocess.run(['node','--import','tsx',str(root/'tests'/script)],cwd=root,env=env,stdout=handle,stderr=subprocess.STDOUT)
 result['results'].append({'script':script,'exit_code':execution.returncode,'test_sha256':sha(root/'tests'/script),'log':str(log.relative_to(root))})
 record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(script,execution.returncode,flush=True)
 if execution.returncode:raise SystemExit(1)
result['passed']=True;record.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
