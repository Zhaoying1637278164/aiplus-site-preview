"""Exact T06 financial/offline/source/native evidence; public acceptance is separate."""
from pathlib import Path
import json,hashlib,zipfile,re
root=Path.cwd();ev=root/'progress/evidence/T06/0.1.0';release=root/'release/T06/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
html=sha(release/'index.html');runtime=sha(release/'runtime.json');site=sha(root/'integration/native-site/site/index.html')
ind=read(ev/'root-independent-review.json');cmd=read(ev/'root-independent-command.json')
assert cmd['actual_exit_code']==0 and cmd['script_sha256']==sha(root/'tests/t06-independent-review.ts') and cmd['result_sha256']==sha(ev/'root-independent-review.json')
assert ind['passed'] and ind['groups']==13 and len(ind['results'])==13 and all(x['passed'] for x in ind['results'])
assert ind['engine_sha256']==sha(root/'tools/T06-外币敞口与汇兑测算/src/engine.ts')
u=read(ev/'root-unit-command.json');assert u['actual_exit_code']==0 and u['total']==u['passed']==67
for file,digest in u['files_sha256'].items():assert sha(root/file)==digest
for folder,script,count in [('root-formal/browser','t06-formal-browser.ts',18),('root-formal/browser-supplement','t06-formal-supplement.ts',7),('site-local','t06-native-site.ts',17)]:
 b=ev/folder;c=read(b/'root-command.json');d=read(b/'result.json')
 assert c['actual_exit_code']==0 and c['script_sha256']==sha(root/'tests'/script) and c['result_sha256']==sha(b/'result.json')
 assert c['runtime_sha256']==runtime and d['sha256']==html
 if 'cases' in d:
  assert len(d['cases'])==count and all(x.get('passed') is True or x.get('checked')==437 for x in d['cases'])
  assert d['pageErrors']==[] and d['externalRequests']==[] and d['offline']
 else:assert d['passed'] and len(d['checks'])==count and d['errors']==[] and d['requests']==[] and d['offline']
 if folder=='site-local':
  assert c['site_sha256']==d['site_sha256']==site and c['actual_exit_cancel_clear_reenter'] and c['storage_writes_verified_empty']
  assert len(d['programs'])==2 and all(p.endswith('/T06/0.1.0/runtime.json') for p in d['programs'])
src=read(ev/'source-rebuild.json');assert src['source_zip_sha256']==sha(release/'T06-0.1.0-源码.zip')
assert len(src['commands'])==4 and all(c['exit_code']==0 for c in src['commands'])
for name,digest in [('index.html',html),('runtime.json',runtime)]:
 v=src['files'][name];assert v['identical'] and v['release_sha256']==v['rebuilt_sha256']==digest
assert (release/'T06-0.1.0-源码.zip').stat().st_size<=24*1024*1024
b=ev/'T06/downloads';c=read(b/'root-command.json');d=read(b/'result.json')
assert c['actual_exit_code']==0 and c['script_sha256']==sha(root/'tests/t06-native-downloads.ts') and c['result_sha256']==sha(b/'result.json')
assert c['site_sha256']==d['site_sha256']==site and d['passed'] and d['errors']==[] and d['clicks']==17
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==15 and set(d['downloads'])==expected
for name,digest in d['downloads'].items():assert sha(b/'site-local-downloads'/name)==sha(release/name)==digest
with zipfile.ZipFile(b/'site-local-downloads/T06-0.1.0-离线包.zip') as z:
 expected={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
 assert set(z.namelist())=={'T06/'+p for p in expected}
 for p in expected:assert z.read('T06/'+p)==(release/p).read_bytes()
b=ev/'site-visual';c=read(b/'root-visual-review.json');d=read(b/'result.json')
assert c['actual_exit_code']==0 and c['validator_sha256']==sha(root/'tests/t06-native-visual.ts') and c['result_sha256']==sha(b/'result.json') and c['manual_review']['all_27_full_content_images_viewed']
assert d['site_sha256']==site and len(c['screenshots'])==27
for name,digest in c['screenshots'].items():assert sha(b/name)==digest
assert d['passed'] and d['runtime_sha256']==runtime and len(d['captures'])==27
for row in d['captures']:
 assert row['visible']['bottom']<=row['visible']['innerHeight']+1 and row['visible']['scrollWidth']<=row['visible']['innerWidth']+1
for p in release.iterdir():
 if p.is_file():assert sha(root/'integration/native-site/static/tools/T06/0.1.0'/p.name)==sha(p)
result={'tool':'T06','version':'0.1.0','local_exact_gates_passed':True,'site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'independent_groups':13,'unit_tests':67,'formal_cases':18,'formal_supplement':7,'native_cases':17,'native_cells':437,'full_images_reviewed':27,'version_downloads':15,'public_verified':False,'accepted':False,'windows_real_machine':'unverified'}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
