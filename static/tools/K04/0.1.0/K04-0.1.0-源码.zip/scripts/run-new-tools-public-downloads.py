"""Click every same-version public detail download; full workflows run separately."""
from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();result={'results':[],'passed':False};out=root/'progress/evidence/shared/2026-10-04-new-tools-public-download-commands.json'
for tool in ['P04','T01','T02']:
 log=root/'progress/evidence/shared'/('2026-10-04-'+tool+'-public-downloads.log')
 with log.open('w') as handle:run=subprocess.run(['node','--import','tsx','tests/new-tools-public-site.ts',tool,'downloads'],cwd=root,stdout=handle,stderr=subprocess.STDOUT)
 result['results'].append({'tool':tool,'exit_code':run.returncode,'script':'tests/new-tools-public-site.ts','test_sha256':hashlib.sha256((root/'tests/new-tools-public-site.ts').read_bytes()).hexdigest(),'log':str(log.relative_to(root))});out.write_text(json.dumps(result,indent=2)+'\n');print(tool,run.returncode,flush=True)
 if run.returncode:raise SystemExit(run.returncode)
result['passed']=True;out.write_text(json.dumps(result,indent=2)+'\n')
