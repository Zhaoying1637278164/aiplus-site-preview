"""Bind complete actual public financial work/downloads to exact formal releases."""
from pathlib import Path
import hashlib,json,re,sys,zipfile,subprocess
root=Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
deployed=read(root/'website/deployed-site.json')['site_sha256']
assert deployed==sha(root/'integration/native-site/site/index.html')
catalog={t['id']:t for t in read(root/'catalog/tools.json')}
for tool in sys.argv[1:] or ['P04','T01','T02']:
 assert tool in ['P04','T01','T02']
 run=subprocess.run([sys.executable,'scripts/check-new-tools-local-evidence.py',tool],check=True)
 ev=root/'progress/evidence'/tool/'0.1.0';release=root/'release'/tool/'0.1.0';public=ev/'site-public';work=public/'full-native-work';direct=public/'all-version-downloads'
 html,runtime=sha(release/'index.html'),sha(release/'runtime.json');local=read(ev/'site-local/result.json');actual=read(work/'result.json');execution=read(work/'execution.json')
 assert actual['passed'] and actual['official_website'] and actual['public_site_verified'] and actual['actual_root_exit_code']==0
 assert execution['exit_code']==0 and execution['finance_assertions_preserved'] and execution['host']=='https://aiplus-guance.streamlit.app/~/+/'
 native='tests/'+tool.lower()+'-native-site.ts'
 assert execution['source_validator_sha256']==execution['executed_validator_sha256']==sha(root/native)==sha(work/'executed-public-validator.ts')
 assert execution['substitutions']==['public host via environment','public evidence path via environment']
 assert actual['site_sha256']==deployed and actual.get('html_sha256',actual.get('candidate_sha256'))==html and actual['runtime_sha256']==runtime
 assert actual['checks']==local['checks'] and len(actual['checks'])=={'P04':23,'T01':17,'T02':15}[tool]
 assert len(actual['geometry'])=={'P04':63,'T01':39,'T02':45}[tool] and len(actual['downloads'])=={'P04':63,'T01':43,'T02':41}[tool]
 assert actual['errors']==[] and actual.get('requests',actual.get('processing_requests'))==[]
 assert actual['programs'] and all('/'+tool+'/0.1.0/' in u for u in actual['programs'])
 doc=(work/'actual-srcdoc.html').read_text();normalized=re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc,count=1);assert hashlib.sha256(normalized.encode()).hexdigest()==deployed
 for d in actual['downloads']:
  p=work/d.get('file',d.get('filename'));assert sha(p)==d['sha256'] and p.stat().st_size==d['bytes']
 with zipfile.ZipFile(release/(tool+'-0.1.0-源码.zip')) as z:
  assert z.read(native)==(root/native).read_bytes()
  snap=json.loads(z.read('source-snapshot.json'));engine='tools/'+catalog[tool]['folder']+'/src/engine.ts';assert snap['file_sha256'][engine]==sha(root/engine)
 detail_execution=read(direct/'execution.json');assert detail_execution['exit_code']==0 and detail_execution['finance_assertions_preserved'] and detail_execution['host']==execution['host']
 assert detail_execution['source_validator_sha256']==sha(root/'tests/new-tools-native-downloads.ts')
 assert detail_execution['executed_validator_sha256']==sha(direct/'executed-public-validator.ts')
 details=root/detail_execution['result_directory'];download=read(details/'result.json');assert download['passed'] and download['official_website'] and download['public_site_verified']
 assert download['site_sha256']==deployed and download['html_sha256']==html and download['runtime_sha256']==runtime and download['errors']==[]
 doc=(details/'public-srcdoc.html').read_text();normalized=re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc,count=1);assert hashlib.sha256(normalized.encode()).hexdigest()==deployed
 expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']};assert set(download['downloads'])==expected
 for name,digest in download['downloads'].items():assert sha(details/'site-local-downloads'/name)==digest==sha(release/name)
 with zipfile.ZipFile(details/'site-local-downloads'/(tool+'-0.1.0-离线包.zip')) as z:
  nonzip={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert set(z.namelist())=={tool+'/'+n for n in nonzip}
  for name in nonzip:assert z.read(tool+'/'+name)==(release/name).read_bytes()
 if tool=='P04':
  assert set(actual['version_downloads'])==expected
  for name,digest in actual['version_downloads'].items():assert sha(work/'version-downloads'/name)==digest==sha(release/name)
 visual=read(public/'root-visual-review.json');assert visual['reviewed'] and visual['site_sha256']==deployed and len(visual['screenshots'])==2
 for name,digest in visual['screenshots'].items():assert sha(public/name)==digest
 result={'tool':tool,'version':'0.1.0','accepted':True,'public_acceptance':True,'site_sha256':deployed,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':sha(release/(tool+'-0.1.0-源码.zip')),'public_work_groups':len(actual['checks']),'public_work_downloads':len(actual['downloads']),'public_navigation_geometry':len(actual['geometry']),'unique_public_version_files':len(expected),'public_work_result_sha256':sha(work/'result.json'),'public_work_execution_sha256':sha(work/'execution.json'),'public_download_result_sha256':sha(details/'result.json'),'public_download_execution_sha256':sha(direct/'execution.json'),'independent_cases':{'P04':12,'T01':8,'T02':7}[tool],'platform':'macOS isolated Chromium; Windows actual machine unverified','scope':'Independent finance, formal file://, source rebuild/all assets, original and public same-version complete workflows and all clicked downloads/offline contents','errors':[]}
 (ev/'site-public-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(tool,'all final gates passed',len(actual['checks']),'work groups',len(expected),'public version files')
