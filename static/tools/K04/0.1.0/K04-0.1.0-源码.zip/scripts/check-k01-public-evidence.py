"""Verify public K01 assertions, exact deployed site and complete download bytes."""
from pathlib import Path
import json,hashlib,re,subprocess,sys,zipfile
root=Path.cwd();ev=root/'progress/evidence/K01/0.1.0';base=ev/'site-public';release=root/'release/K01/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
subprocess.run([sys.executable,'scripts/check-k01-local-evidence.py'],check=True)
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
for mode,script in [('work','k01-native-site.ts'),('downloads','k01-native-downloads.ts')]:
 folder=base/mode;e=read(folder/'execution.json');assert e['actual_root_exit_code']==0 and e['actual_root_terminal_exit_code']==0
 assert e['source_validator_sha256']==sha(root/'tests'/script) and e['expected_site_sha256']==site and e['public_browser']
 actual=folder/'executed-public-validator.ts';assert e['executed_validator_sha256']==sha(actual)
 original=(root/'tests'/script).read_text();expected=re.sub(r"from '([^']+)'",lambda m:'from '+json.dumps(str((root/'tests'/m[1]).resolve()),ensure_ascii=False) if m[1].startswith('.') else m[0],original)
 if mode=='downloads':
  target="await page.goto(host);const frame=page.frameLocator('iframe').first();"
  insertion="await page.locator('iframe').first().waitFor({timeout:120000});const actualDoc=await page.locator('iframe').first().getAttribute('srcdoc');assert(actualDoc);assert.equal(sha(Buffer.from(actualDoc.replace(/<script>window\\.__AIPlusInitialRoute=[\\s\\S]*?<\\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')));await writeFile(out+'/actual-srcdoc.html',actualDoc);"
  assert expected.count(target)==1;expected=expected.replace(target,target+insertion).replace("const pending=page.waitForEvent('download');","await page.waitForTimeout(1100);const pending=page.waitForEvent('download');")
 assert actual.read_text()==expected,'unreviewed public financial validator changes'
 doc=(folder/('K01/downloads/actual-srcdoc.html' if mode=='downloads' else 'actual-srcdoc.html')).read_text();assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
local=read(ev/'site-local/result.json');d=read(base/'work/result.json')
assert d['passed'] and d['site_sha256']==site and d['html_sha256']==html
assert d['checks']==local['checks'] and len(d['checks'])==22 and d['cells']==local['cells']==436 and len(d['geometry'])==24
assert d['errors']==d['requests']==[] and {g['width'] for g in d['geometry']}=={1440,390,320}
assert d['programs'] and all(x.startswith('https://aiplus-guance.streamlit.app/') and '/K01/0.1.0/runtime.json' in x for x in d['programs'])
assert len(d['downloads'])==len(local['downloads'])==31
for x in d['downloads']:
 p=base/'work'/x.get('filename',x.get('file'));assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes']
directory=base/'downloads/K01/downloads';d=read(directory/'result.json')
assert d['passed'] and d['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime and d['errors']==[] and d['clicks']==20
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==18 and set(d['downloads'])==expected
for name,h in d['downloads'].items():assert sha(directory/'site-local-downloads'/name)==h==sha(release/name)
with zipfile.ZipFile(directory/'site-local-downloads/K01-0.1.0-离线包.zip') as z:
 members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert set(z.namelist())=={'K01/'+n for n in members}
 for n in members:assert z.read('K01/'+n)==(release/n).read_bytes()
visual=read(base/'root-image-review.json');assert visual['actually_viewed'] and len(visual['images'])>=2
for im in visual['images']:assert sha(root/im['path'])==im['sha256']
result={'tool':'K01','version':'0.1.0','site_sha256':site,'html_sha256':html,'runtime_sha256':runtime,'public_work_groups':22,'public_work_downloads':31,'public_version_files':18,'public_navigation_geometry':24,'all_exact_gates_passed':True,'accepted':True,'Windows_real_machine':'unverified','errors':[]}
(ev/'site-public-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('K01 exact public acceptance passed')
