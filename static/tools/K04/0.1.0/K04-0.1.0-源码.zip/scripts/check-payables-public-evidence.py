"""Bind actual public work/download evidence to immutable formal releases."""
from pathlib import Path
import hashlib, json, sys, zipfile

root=Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
deployed=read(root/'website/deployed-site.json')['site_sha256']
locks=read(root/'catalog/release-locks.json')['releases']
catalog={t['id']:t for t in read(root/'catalog/tools.json')}
for tool in sys.argv[1:] or ['P01','P02','P03']:
 assert tool in ['P01','P02','P03']
 release=root/'release'/tool/'0.1.0'
 ev=root/'progress/evidence'/tool/'0.1.0'
 public=ev/'site-public/full-native-work'
 html,runtime=sha(release/'index.html'),sha(release/'runtime.json')
 frozen=next(x for x in locks if x['tool']==tool and x['version']=='0.1.0')
 for name,digest in frozen['files'].items():assert sha(release/name)==digest,name
 local=read(ev/'local-delivery-audit.json')
 assert local['local_exact_gates_passed'] and local['errors']==[]
 assert local['site_sha256']==deployed and local['html_sha256']==html and local['runtime_sha256']==runtime
 execution=read(public/'execution.json');actual=read(public/'result.json')
 native='tests/'+tool.lower()+'-native-site.ts'
 assert execution['exit_code']==0 and execution['finance_assertions_preserved'] is True
 assert execution['host']=='https://aiplus-guance.streamlit.app/~/+/'
 assert execution['source_validator_sha256']==sha(root/native)
 assert execution['executed_validator_sha256']==sha(public/'executed-public-validator.ts')
 with zipfile.ZipFile(release/(tool+'-0.1.0-源码.zip')) as z:
  assert z.read(native)==(root/native).read_bytes()
  source_snapshot=json.loads(z.read('source-snapshot.json'))
  engine='tools/'+catalog[tool]['folder']+'/src/engine.ts'
  assert source_snapshot['file_sha256'][engine]==sha(root/engine)
 assert actual['official_website'] and actual['passed'] and actual['site_sha256']==deployed
 assert actual['html_sha256']==html and actual['runtime_sha256']==runtime
 assert actual['errors']==[] and actual['processing_requests']==[]
 expected_groups={'P01':13,'P02':13,'P03':10}[tool]
 assert len(actual['checks'])==expected_groups
 local_work=read(root/'progress/evidence/site-integration/payables-P01-P02-P03'/tool/'site-local/result.json')
 assert actual['checks']==local_work['checks'],'public must preserve every executed local work check'
 document=(public/'public-srcdoc.html').read_text()
 import re
 normalized=re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',document,count=1)
 assert hashlib.sha256(normalized.encode()).hexdigest()==deployed,'actual public document changed'
 assert all('/'+tool+'/0.1.0/' in u for u in actual['programs'])
 for download in actual['downloads']:
  p=public/download['filename'];assert p.stat().st_size==download['bytes'] and sha(p)==download['sha256']
 expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
 assert set(actual['version_downloads'])==expected
 for name,digest in actual['version_downloads'].items():
  assert digest==sha(release/name)==sha(public/'version-downloads'/name)
 independent_path=root/'progress/evidence/shared'/('2026-10-03-'+tool+'-independent-review.json')
 independent=read(independent_path);cases=independent.get('cases',independent.get('checks'))
 assert independent['passed'] and len(cases)==10
 assert all(x.get('passed') is True for x in cases if isinstance(x,dict))
 rebuild=read(ev/'source-rebuild.json')
 assert rebuild['source_zip_sha256']==sha(release/(tool+'-0.1.0-源码.zip'))
 assert len(rebuild['commands'])==4 and all(x['exit_code']==0 for x in rebuild['commands'])
 assets=read(ev/'source-rebuild-assets.json')
 assert assets['source_zip_sha256']==rebuild['source_zip_sha256']
 assert set(assets['files'])=={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
 for name,x in assets['files'].items():
  assert x['release_sha256']==sha(release/name)
  assert x['bytes_identical'] or name.endswith('.xlsx') and x['content_identical_except_created_modified']
 visual=read(public/'root-visual-review.json');assert visual['reviewed'] is True
 assert len(visual['screenshots'])==2
 for name,digest in visual['screenshots'].items():assert sha(public/name)==digest
 result={'tool':tool,'version':'0.1.0','accepted':True,'public_acceptance':True,
         'site_sha256':deployed,'html_sha256':html,'runtime_sha256':runtime,
         'source_zip_sha256':rebuild['source_zip_sha256'],'public_groups':expected_groups,
         'unique_public_version_files':len(expected),'independent_cases':10,
         'public_result_sha256':sha(public/'result.json'),'public_execution_sha256':sha(public/'execution.json'),
         'independent_evidence_sha256':sha(independent_path),'platform':'macOS isolated Chromium; Windows actual machine unverified',
         'scope':'formal file://, source rebuild, independent finance, exact original/public website and all version downloads; business scope remains in financial rules',
         'errors':[]}
 (ev/'site-public-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(tool,'public final evidence accepted:',expected_groups,'groups',len(expected),'unique version files')
