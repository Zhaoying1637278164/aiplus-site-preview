"""Exercise packaging boundaries in a fictitious temporary repository, not product acceptance."""
import tempfile,pathlib,subprocess,json,hashlib,zipfile
ROOT=pathlib.Path.cwd();script=ROOT/'scripts/package.py';checks=[]
with tempfile.TemporaryDirectory(prefix='aiplus-source-boundary-',dir='/private/tmp') as directory:
 r=pathlib.Path(directory)
 def put(name,text='fixture'):
  p=r/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 catalog=[{'id':i,'folder':i+'-fixture','status':'accepted' if i=='D02' else 'packaged' if i=='R01' else 'tested','version':'0.1.0'} for i in ['D02','R01','R02']]
 put('catalog/tools.json',json.dumps(catalog));put('catalog/release-locks.json',json.dumps({'releases':[]}))
 threads=[{'tool_id':i,'thread_status':'accepted_maintenance' if i=='D02' else 'active_navigation_revision' if i=='R01' else 'handed_off_formal_integration'} for i in ['D02','R01','R02']]
 put('catalog/threads.json',json.dumps({'tools':threads}))
 for name in ['package.json','package-lock.json','tsconfig.json','README.md','工具总览.md','AGENTS.md','CLAUDE.md']:put(name)
 for i in ['D02','R01','R02']:
  put(f'tools/{i}-fixture/src/main.tsx');put(f'progress/evidence/{i}/result.json','{}');put(f'fixtures/{i}/expected.json','{}')
  for name in ['index.html','runtime.json','THIRD_PARTY_NOTICES.md']:put(f'release/{i}/0.1.0/'+name)
 put('tools/R02-fixture/candidate/0.1.0/runtime.json','generated duplicate')
 put('tools/R02-fixture/scripts/build-candidate.ts','reproducible source script')
 put('integration/native-site/site/registry.json',json.dumps([{'id':'D02'},{'id':'R02'}]))
 put('progress/evidence/site-integration/D02/result.json','superseded replay')
 put('progress/evidence/site-integration/D02-R02/result.json','current replay')
 put('tests/active-import.ts',"import {x} from '../tools/R01-fixture/src/engine';")
 put('tests/stable-import.ts',"import {x} from '../tools/D02-fixture/src/engine';")
 def run(i):return subprocess.run(['python3',str(script),f'release/{i}/0.1.0'],cwd=r,text=True,capture_output=True)
 before={str(p.relative_to(r)):p.read_bytes() for p in (r/'release/R01').rglob('*') if p.is_file()}
 result=run('R01');assert result.returncode!=0 and '交接' in result.stderr+result.stdout
 after={str(p.relative_to(r)):p.read_bytes() for p in (r/'release/R01').rglob('*') if p.is_file()};assert before==after;checks.append('active_target_refused_before_write')
 result=run('R02');assert result.returncode==0,result.stderr
 with zipfile.ZipFile(r/'release/R02/0.1.0/R02-0.1.0-源码.zip') as z:
  names=z.namelist();snapshot=json.loads(z.read('source-snapshot.json'));assert snapshot['included_tools']==['D02','R02'] and snapshot['excluded_active_tools']==['R01']
  assert 'tests/active-import.ts' not in names and 'tests/stable-import.ts' in names
  assert not any(n.startswith(('tools/R01-','fixtures/R01/','progress/evidence/R01/')) for n in names)
  assert 'tools/R02-fixture/candidate/0.1.0/runtime.json' not in names
  assert 'tools/R02-fixture/scripts/build-candidate.ts' in names
  assert 'progress/evidence/site-integration/D02/result.json' not in names
  assert 'progress/evidence/site-integration/D02-R02/result.json' in names
  for name,value in snapshot['file_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==value
 checks.extend(['superseded_stage_outputs_excluded_current_replay_retained','generated_candidate_excluded_build_source_retained','locked_target_and_accepted_dependency_included','active_tool_source_fixture_evidence_imports_excluded','snapshot_all_included_hashes_exact'])
 put('catalog/release-locks.json',json.dumps({'releases':[{'tool':'R02','version':'0.1.0'}]}));p=r/'release/R02/0.1.0/R02-0.1.0-源码.zip';before=p.read_bytes();result=run('R02');assert result.returncode!=0 and p.read_bytes()==before;checks.append('frozen_target_refused_without_archive_mutation')
result={'passed':True,'scope':'fictitious packaging boundary fixture only; no tool/business/offline/website acceptance','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'checks':checks}
p=ROOT/'progress/evidence/shared/2026-10-03-source-boundaries.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
