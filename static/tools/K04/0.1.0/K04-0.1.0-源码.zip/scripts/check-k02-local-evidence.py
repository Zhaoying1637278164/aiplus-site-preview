"""K02 exact formal and local website evidence. Public acceptance is separate."""
from pathlib import Path
import json,hashlib,zipfile,re
root=Path.cwd();ev=root/'progress/evidence/K02/0.1.0';release=root/'release/K02/0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
site=sha(root/'integration/native-site/site/index.html');html=sha(release/'index.html');runtime=sha(release/'runtime.json')
for folder,script,groups,count in [('formal-browser','k02-formal-browser.ts',18,26),('site-local','k02-native-site.ts',20,32)]:
 d=read(ev/folder/'result.json');c=read(ev/folder/'root-command.json')
 assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(root/'tests'/script)
 assert d['status']=='passed' and d['candidate_sha']==html and d['runtime_sha']==runtime and d['cells']==491
 assert d['errors']==d['requests']==[] and len(d['checks'])==groups and len(d['downloads'])==count and len(d['geometry'])==27
 assert {g['width'] for g in d['geometry']}=={1440,390,320}
 assert len({x['file'] for x in d['downloads']})==count
 for x in d['downloads']:
  p=ev/folder/x['file'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
 visual=read(ev/folder/'root-visual-review.json');assert visual['actual_review'] and visual['reviewer']=='Codex actual image inspection'
 assert len(visual['screenshots'])==27 and len(visual['contacts_actually_viewed'])==3
 for p,h in {**visual['screenshots'],**visual['contacts_actually_viewed']}.items():assert sha(root/p)==h
 if folder=='site-local':
  assert c['site_sha256']==d['site_sha256']==visual['site_sha256']==site
  assert d['programs'] and all('/K02/0.1.0/runtime.json' in p for p in d['programs'])
  doc=(ev/folder/'actual-srcdoc.html').read_text();assert hashlib.sha256(re.sub(r'<script>window\.__AIPlusInitialRoute=[\s\S]*?</script>','',doc).encode()).hexdigest()==site
 else:assert c['oracle_sha256']==sha(root/'tests/k02-export-oracle.ts')
directory=ev/'K02/downloads';d=read(directory/'result.json');c=read(directory/'root-command.json')
assert c['actual_exit_code']==0 and c['actual_session_id'] and c['script_sha256']==sha(root/'tests/k02-native-downloads.ts')
assert d['passed'] and not d['errors'] and d['site_sha256']==c['site_sha256']==site and d['html_sha256']==html and d['runtime_sha256']==runtime and d['test_sha256']==c['script_sha256']
expected={p.name for p in release.iterdir() if p.is_file() and p.name not in ['index.html','runtime.json','build-manifest.json']}
assert len(expected)==18 and set(d['downloads'])==expected and d['clicks']==20
for name,h in d['downloads'].items():assert sha(directory/'site-local-downloads'/name)==h==sha(release/name)
with zipfile.ZipFile(release/'K02-0.1.0-离线包.zip') as z:
 members={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'};assert len(members)==19 and set(z.namelist())=={'K02/'+n for n in members}
 for n in members:assert z.read('K02/'+n)==(release/n).read_bytes()
source=release/'K02-0.1.0-源码.zip';assert source.stat().st_size<=24*1024*1024
r=read(ev/'source-rebuild.json');assert r['source_zip_sha256']==sha(source) and r['actual_root_exit_code']==0 and len(r['commands'])==4 and all(c['exit_code']==0 for c in r['commands'])
for name in ['index.html','runtime.json']:assert r['files'][name]['identical'] and r['files'][name]['release_sha256']==sha(release/name)
a=read(ev/'source-rebuild-assets.json');assert a['source_zip_sha256']==sha(source) and set(a['files'])=={p.name for p in release.iterdir() if p.is_file() and p.suffix!='.zip'}
for name,x in a['files'].items():assert x['release_sha256']==sha(release/name) and (x['bytes_identical'] or x.get('content_identical_except_created_modified'))
i=read(ev/'root-independent-review.json');assert i['passed'] and len(i['checks'])==14 and i['failures']==[] and i['engine_sha256']==sha(root/'tools/K02-成本差异分析/src/engine.ts')
g=read(ev/'root-formal-guide-change.json');assert g['unit_root_actual_exit_code']==g['independent_root_actual_exit_code']==0
for p in release.iterdir():
 if p.is_file():assert sha(root/'integration/native-site/static/tools/K02/0.1.0'/p.name)==sha(p)
result={'tool':'K02','version':'0.1.0','local_exact_gates_passed':True,'html_sha256':html,'runtime_sha256':runtime,'source_zip_sha256':sha(source),'site_sha256':site,'independent_workbook_cells':491,'accepted':False,'windows_verified':False}
(ev/'local-delivery-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
