import {chromium} from '/Users/xiaoying/Library/Mobile Documents/com~apple~CloudDocs/codex/data_labs/aiplus-finance-tools/node_modules/playwright/index.mjs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const host=process.env.AIPLUS_NATIVE_SITE_URL||'http://127.0.0.1:8514';
const release=path.resolve('release/R03/0.1.0'),evidence=path.resolve(process.env.AIPLUS_EVIDENCE_DIR||'progress/evidence/R03/0.1.0/downloads');await mkdir(evidence,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.AIPLUS_CHROME||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',headless:true});
const registered=JSON.parse(await readFile('integration/native-site/site/registry.json','utf8')) as {id:string;replacesOriginal?:boolean}[];
const catalogueTotal=76+registered.filter(e=>!e.replacesOriginal).length,arTotal=8+registered.filter(e=>e.id==='R01'&&!e.replacesOriginal).length;
const sha=(b:Buffer)=>createHash('sha256').update(b).digest('hex');
try{
 const context=await browser.newContext({acceptDownloads:true,viewport:{width:1440,height:1000}}),page=await context.newPage();
 const programs:string[]=[];page.on('request',r=>{if(r.url().endsWith('runtime.json'))programs.push(r.url())});
 await page.goto(host,{waitUntil:'domcontentloaded'});const frame=page.frameLocator('iframe').first();
 assert.equal(await frame.locator('.bignum').innerText(),String(catalogueTotal));const publicDoc=await page.locator('iframe').first().getAttribute('srcdoc');assert(publicDoc);assert.equal(sha(Buffer.from(publicDoc.replace(/<script>window\.__AIPlusInitialRoute=[\s\S]*?<\/script>/,''))),sha(await readFile('integration/native-site/site/index.html')),'exact public document');await writeFile(evidence+'/public-srcdoc.html',publicDoc);
 assert.equal(await frame.getByRole('link',{name:`01 应收 ${arTotal}`,exact:true}).count(),1);
 await frame.locator('.nav a[href="#tools"]').click();assert.equal(await frame.locator('[data-total]').innerText(),String(catalogueTotal));
 await frame.locator('[data-f="mod"][data-v="ar"]').click();assert.equal(await frame.locator('[data-total]').innerText(),String(arTotal));
 const row=frame.locator('[data-tool]').filter({has:frame.getByRole('link',{name:'回款对账',exact:true})});assert.equal(await row.count(),1);
 await row.getByRole('link',{name:'详情',exact:true}).click();await frame.getByRole('heading',{name:'回款对账',exact:true}).waitFor();
 assert.equal(await frame.locator('template#r-tool-ar-05').count(),1);assert.equal(await frame.locator('[data-tool]').filter({has:frame.getByRole('link',{name:'回款对账',exact:true})}).count(),0);assert.equal(programs.length,0);assert.equal(await frame.getByText('工具信息',{exact:true}).count(),1);
 await page.screenshot({path:evidence+'/site-detail-local.png',fullPage:true});
 const labels=['离线工具包','同版本源码','虚构样例（Excel）','空白模板（CSV）','使用说明','财务口径','第三方声明','银行回款模板（CSV）','核销记录模板（CSV）'];
 const names=['R03-0.1.0-离线包.zip','R03-0.1.0-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md','银行回款模板.csv','核销记录模板.csv'];
 const downloads:Record<string,string>={};
 for(let i=0;i<names.length;i++){
  await page.waitForTimeout(1100);const pending=page.waitForEvent('download');await frame.getByRole('link',{name:labels[i],exact:true}).click();const file=await pending;
  assert.equal(await file.failure(),null);const target=path.join(evidence,'site-local-downloads',names[i]);await mkdir(path.dirname(target),{recursive:true});await file.saveAs(target);
  downloads[names[i]]=sha(await readFile(target));assert.equal(downloads[names[i]],sha(await readFile(path.join(release,names[i]))));
 }
 execFileSync('python3',['-c','import sys,zipfile,hashlib; archive=zipfile.ZipFile(sys.argv[1]); assert hashlib.sha256(archive.read("R03/index.html")).hexdigest()==sys.argv[2]',path.join(evidence,'site-local-downloads',names[0]),sha(await readFile(release+'/index.html'))]);

 assert.equal(programs.length,0);await writeFile(evidence+'/result.json',JSON.stringify({tool:'R03',version:'0.1.0',html_sha256:sha(await readFile(release+'/index.html')),runtime_sha256:sha(await readFile(release+'/runtime.json')),site_sha256:sha(await readFile('integration/native-site/site/index.html')),downloads,checks:['original_financial_module_and_detail','nine_actual_first_party_downloads_exact_hash','offline_zip_inner_html_same','detail_does_not_load_program'],browser:await browser.version(),scope:'真实本地六款官网；复用原回款对账条目，公开官网另验'},null,2));console.log('R03九项实际下载及原详情通过');
}finally{await browser.close()}
