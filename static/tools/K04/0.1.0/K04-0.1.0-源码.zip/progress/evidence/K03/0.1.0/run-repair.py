from pathlib import Path
import subprocess,json,time,hashlib
out=Path('progress/evidence/K03/0.1.0')
commands=[('unit',['node','--import','tsx','--test','tools/K03-存货库龄与周转/tests/engine.test.ts']),('root-repair',['node','--import','tsx','tests/k03-independent-review.ts']),('typecheck',['./node_modules/.bin/tsc','--noEmit','-p','tools/K03-存货库龄与周转/tsconfig.json']),('build',['node','--import','tsx','tools/K03-存货库龄与周转/scripts/build-candidate.ts']),('browser',['node','--import','tsx','tools/K03-存货库龄与周转/tests/browser.ts']),('micro-browser',['node','--import','tsx','tools/K03-存货库龄与周转/tests/micro-return-browser.ts']),('native-site',['node','--import','tsx','tools/K03-存货库龄与周转/tests/native-site.ts'])]
results=[]
for label,cmd in commands:
 start=time.time()
 with (out/(label+'.log')).open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 r={'label':label,'command':cmd,'exit_code':p.returncode,'seconds':round(time.time()-start,2),'log':str(out/(label+'.log'))};results.append(r)
 (out/'repair-commands.json').write_text(json.dumps({'commands':results,'passed':all(x['exit_code']==0 for x in results),'complete':len(results)==len(commands)},ensure_ascii=False,indent=2))
 print(json.dumps(r,ensure_ascii=False),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
