from pathlib import Path
import hashlib,json,zipfile,shutil
folder=Path('tools/K03-存货库龄与周转')
base=Path('progress/evidence/K03/0.1.0')
out=base/'interface-polish'
candidate=folder/'candidate/0.1.0'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
commands=read(out/'commands.json');guide=read(out/'result.json');browser=read(base/'browser/result.json');rebuild=read(base/'source-rebuild/result.json')
old=read(base/'history/before-interface-polish/handoff-manifest.json')
assert commands['complete'] and commands['passed'] and len(commands['commands'])==7
assert all(c['exit_code']==0 for c in commands['commands'])
assert guide['passed'] and len(guide['downloads'])==4 and not guide['requests'] and not guide['errors']
micro=read(base/'micro-return-browser/result.json');native=read(base/'original-site/result.json')
assert micro['passed'] and len(micro['checks'])==7 and len(micro['downloads'])==7
assert not micro['requests'] and not micro['errors']
assert native['passed'] and len(native['checks'])==8 and len(native['geometry'])==27 and not native['errors']
assert native['originalSHA']==sha(Path(native['officialSource']))
assert micro['htmlSHA']==guide['htmlSHA'] and micro['runtimeSHA']==native['entry']['sha256']==guide['runtimeSHA']
assert guide['guideSHA']==old['guideSHA']
assert len(guide['labels'])==8 and len(guide['groupChecks'])==4 and guide['workbookSheetsUnchanged']==10 and guide['internalGroupKeyUnchanged']
assert browser['passed'] and len(browser['checks'])==15 and len(browser['downloads'])==30 and len(browser['geometry'])==54
assert not browser['requests'] and not browser['errors']
assert guide['htmlSHA']==browser['htmlSHA']==sha(candidate/'index.html')
assert guide['runtimeSHA']==browser['runtimeSHA']==sha(candidate/'runtime.json')
assert guide['guideSHA']==sha(folder/'README.md')==sha(candidate/'使用说明.md')
assert rebuild['passed'] and len(rebuild['compared'])==17 and len(rebuild['commands'])==4
assert all(c['exit_code']==0 for c in rebuild['commands'])
assert all(v['original']==v['rebuilt'] for v in rebuild['compared'].values())
assert '# tests 56' in (base/'source-rebuild/2.log').read_text() and '# fail 0' in (base/'source-rebuild/2.log').read_text()
for p,h in rebuild['sourceFiles'].items():assert sha(Path(p))==h,p
files={str(p):sha(p) for p in sorted(folder.rglob('*')) if p.is_file() and '/candidate/' not in str(p)}
changed=[p for p,h in files.items() if old['sourceFiles'].get(p)!=h]
allowed=[str(folder/p) for p in ['src/App.tsx','src/style.css','实现交接.md','任务与接续.md','验收证据.md']]
assert set(changed)==set(allowed),changed
engine=folder/'src/engine.ts';assert sha(engine)==old['sourceFiles'][str(engine)]
root=read(base/'root-independent-review.json');assert root['engine_sha256']==sha(engine) and root['passed']==6 and root['failed']==0
assert root['script_sha256']==sha(Path('tests/k03-independent-review.ts'))==old['unchangedFinanceEvidence']['rootScriptSHA']
sourcezip=base/'source-rebuild/K03-candidate-source.zip'
with zipfile.ZipFile(sourcezip) as z:
 assert all('node_modules' not in name and '/candidate/' not in name and '.env' not in name for name in z.namelist())
 assert 'package-lock.json' in z.namelist() and str(folder/'THIRD_PARTY_NOTICES.md') in z.namelist()
 for p,h in rebuild['sourceFiles'].items():assert hashlib.sha256(z.read(p)).hexdigest()==h
archive=out/'K03-0.1.0-候选离线包.zip'
candidatefiles={p.name:sha(p) for p in sorted(candidate.iterdir()) if p.is_file()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(candidate.iterdir()):z.write(p,p.name)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==17
 for p,h in candidatefiles.items():assert hashlib.sha256(z.read(p)).hexdigest()==h
reviewed=[base/'browser'/f'offline-{width}-{page}.png' for width in [1440,320] for page in range(1,10)]+[base/'original-site'/f'site-{width}-{page}.png' for width in [1440,320] for page in [4,9]]
visual={'method':'实际逐页打开桌面1440和手机320的离线九页共18张，另打开原官网候选的两宽度库存/底稿4张，共22张；其他截图仅自动几何检查；长图显示时被缩小', 'reviewed':[{'file':str(p),'sha256':sha(p)} for p in reviewed], 'result':'查询同一行；分组六个中文字段；说明标题/七步骤/段落完整，无井号；宽表横向滚动，页面无横向越界'}
(out/'visual-review.json').write_text(json.dumps(visual,ensure_ascii=False,indent=2))
canonical='\n'.join(f'{p}\t{h}' for p,h in sorted(files.items()))
manifest={
 'date':'2026-10-04','tool':'K03','name':'存货库龄与周转','version':'0.1.0','ruleVersion':'K03-2026-10-04.2',
 'status':'tested_candidate_interface_polish_handoff_frozen','accepted':False,'published':False,
 'scope':'查询标签、截止核对分组、说明排版呈现；财务计算/规则/导入导出/恢复流程和下载说明字节未改',
 'changedSourceFiles':changed,'sourceFiles':files,'sourceBaselineSHA':hashlib.sha256(canonical.encode()).hexdigest(),
 'candidateFiles':candidatefiles,'candidateHTMLSHA':sha(candidate/'index.html'),'candidateRuntimeSHA':sha(candidate/'runtime.json'),'guideSHA':guide['guideSHA'],
 'sourceZIP':{'file':str(sourcezip),'sha256':sha(sourcezip),'bytes':sourcezip.stat().st_size},
 'offlineZIP':{'file':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'membersVerified':17},
 'sharedBuildSnapshot':{p:h for p,h in rebuild['sourceFiles'].items() if not p.startswith(str(folder))},
 'validation':{'actualCommandsPassed':7,'guideDownloadByteChecks':4,'mainBrowserGroups':15,'mainBrowserDownloads':30,'mainBrowserPageGeometryChecks':54,'sourceRebuildCommandsPassed':4,'sourceRebuildUnitTests':56,'rebuiltCandidateSHAEqual':17,'visuallyReviewed':22,'microBrowserGroups':7,'microBrowserDownloads':7,'originalSiteGroups':8,'originalSitePageGeometryChecks':27,'queryLabelSingleLineChecks':8,'renderedGroupRows':4,'workbookSheetsContentUnchanged':10},
 'unchangedFinanceEvidence':{'engineSHA':sha(engine),'rootOriginal6Passed':True,'rootScriptSHA':root['script_sha256'],'scope':'沿用未变更计算的原6组证据；本轮未重跑根脚本；主/微量/原官网候选浏览器均重新实际运行，十张新旧下载底稿逐格不变'},
 'previousBaseline':{'file':str(base/'history/before-interface-polish/handoff-manifest.json'),'sha256':sha(base/'history/before-interface-polish/handoff-manifest.json'),'retainedFailure':old['previousBaseline']['retainedFailure']},
 'remaining':['总控重新正式构建与财务/微量正式回归','正式官网公开运行与下载验收','Windows实机未验证'],
 'writeFreeze':'清单封存后停止写入本款与证据',
 'retainedVerifierFailure':{'file':str(out/'history/empty-sheet-verifier-failure/interface.log'),'reason':'原验证器asTable拒绝空异常底稿；改为读取原始矩阵比对，未改产品'},
 'evidenceFiles':{str(p):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='handoff-manifest.json'}
}
for subtree in [base/'browser',base/'source-rebuild',base/'micro-return-browser',base/'original-site']:
 manifest['evidenceFiles'].update({str(p):sha(p) for p in sorted(subtree.rglob('*')) if p.is_file()})
encoded=json.dumps(manifest,ensure_ascii=False,indent=2)
(out/'handoff-manifest.json').write_text(encoded)
(base/'handoff-manifest.json').write_text(encoded)
print(json.dumps({'htmlSHA':manifest['candidateHTMLSHA'],'runtimeSHA':manifest['candidateRuntimeSHA'],'guideSHA':manifest['guideSHA'],'sourceBaselineSHA':manifest['sourceBaselineSHA'],'sourceZIP':manifest['sourceZIP'],'offlineZIP':manifest['offlineZIP'],'validation':manifest['validation']},ensure_ascii=False))
