import { chromium } from 'playwright';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve('.'),folder=root+'/tools/K03-存货库龄与周转',out=root+'/progress/evidence/K03/0.1.0/user-guide-refresh';
const hash=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
const expected=await readFile(folder+'/README.md');
const source=await readFile(folder+'/src/usage.ts','utf8');
assert.equal(source,'export const USAGE=`'+expected.toString()+'`;\n');
assert.deepEqual(await readFile(folder+'/candidate/0.1.0/使用说明.md'),expected);
assert.doesNotMatch(expected.toString(),/待总控验收候选|尚未发布|Mac Chromium候选/);
assert.match(expected.toString(),/Windows实机未验证/);
const browser=await chromium.launch({headless:true,executablePath:process.env.K03_CHROMIUM||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const downloads:any[]=[],errors:string[]=[],requests:string[]=[];
try {
 for(const [tag,file] of [['offline',folder+'/candidate/0.1.0/index.html'],['native',root+'/progress/evidence/K03/0.1.0/browser/host.html']]) {
  const context=await browser.newContext({offline:true,acceptDownloads:true,viewport:{width:320,height:1000}});
  const page=await context.newPage();
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});
  await page.goto('file://'+file);await page.getByRole('heading',{name:'存货库龄与周转',exact:true}).waitFor();
  assert.doesNotMatch(await page.locator('.k03-meta').innerText(),/候选|待验收|尚未发布/);
  for(const [section,button] of [['import','01 资料导入'],['restore','09 底稿与恢复']]) {
   await page.getByRole('navigation').getByRole('button',{name:button,exact:true}).click();
   if(section==='restore')assert.equal(await page.locator('pre').textContent(),expected.toString());
   const pending=page.waitForEvent('download');await page.getByRole('button',{name:'下载使用说明',exact:true}).click();
   const download=await pending;assert.equal(download.suggestedFilename(),'使用说明.md');
   const file=out+'/'+tag+'-'+section+'-使用说明.md';await download.saveAs(file);
   const actual=await readFile(file);assert.deepEqual(actual,expected);
   downloads.push({mode:tag,section,file:path.relative(root,file),sha256:hash(actual),bytes:actual.length});
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2),false);
   await page.screenshot({path:out+'/'+tag+'-'+section+'-320.png',fullPage:true});
  }
  await context.close();
 }
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 await writeFile(out+'/result.json',JSON.stringify({passed:true,scope:'本地file://离线HTML及同runtime原生ShadowDOM宿主；非公开官网',downloads,errors,requests,guideSHA:hash(expected),htmlSHA:hash(await readFile(folder+'/candidate/0.1.0/index.html')),runtimeSHA:hash(await readFile(folder+'/candidate/0.1.0/runtime.json')),windows:'未实测'},null,2));
 console.log(JSON.stringify({passed:true,downloadByteChecks:downloads.length,guideSHA:hash(expected)}));
} finally {await browser.close()}
