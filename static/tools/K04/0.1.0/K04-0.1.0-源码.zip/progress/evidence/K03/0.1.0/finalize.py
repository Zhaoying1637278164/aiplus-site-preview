from pathlib import Path
import zipfile, hashlib, json

folder = Path('tools/K03-存货库龄与周转')
out = Path('progress/evidence/K03/0.1.0')
candidate = folder / 'candidate/0.1.0'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
r = json.loads((out / 'source-rebuild/result.json').read_text())
b = json.loads((out / 'browser/result.json').read_text())
n = json.loads((out / 'original-site/result.json').read_text())
m = json.loads((out / 'micro-return-browser/result.json').read_text())
root = json.loads((out / 'root-independent-review.json').read_text())
oldroot = json.loads((out / 'history/root-before-micro-return-repair/result.json').read_text())
actual = json.loads((out / 'repair-commands.json').read_text())
assert r['passed'] and b['passed'] and n['passed'] and m['passed']
assert actual['passed'] and actual['complete'] and len(actual['commands']) == 8
assert all(c['exit_code'] == 0 for c in actual['commands'])
assert root['total'] == root['passed'] == 6 and root['failed'] == 0
assert root['script_sha256'] == oldroot['script_sha256'] == sha(Path('tests/k03-independent-review.ts'))
assert oldroot['failed'] > 0
assert '# tests 56' in (out / 'unit.log').read_text()
assert '# fail 0' in (out / 'unit.log').read_text()
assert len(m['checks']) == 7 and len(m['downloads']) == 7 and not m['errors'] and not m['requests']
assert m['ruleVersion'] == 'K03-2026-10-04.2'
assert m['htmlSHA'] == sha(candidate / 'index.html') and m['runtimeSHA'] == sha(candidate / 'runtime.json')
assert b['htmlSHA'] == sha(candidate / 'index.html')
assert b['runtimeSHA'] == n['entry']['sha256'] == sha(candidate / 'runtime.json')
assert n['originalSHA'] == sha(Path(n['officialSource']))
assert len(b['checks']) == 15 and len(b['downloads']) == 30 and len(b['geometry']) == 54
assert len(n['checks']) == 8 and len(n['geometry']) == 27
assert not b['errors'] and not b['requests'] and not n['errors']
assert len(r['commands']) == 4 and all(c['exit_code'] == 0 for c in r['commands'])
assert len(r['compared']) == 17
for f, v in r['sourceFiles'].items():
    assert sha(Path(f)) == v, (f, 'source drift')
source_zip = out / 'source-rebuild/K03-candidate-source.zip'
with zipfile.ZipFile(source_zip) as z:
    assert all('node_modules' not in name and '/candidate/' not in name and '.env' not in name for name in z.namelist())
    assert 'package-lock.json' in z.namelist()
    assert str(folder / 'THIRD_PARTY_NOTICES.md') in z.namelist()
    for f, h in r['sourceFiles'].items():
        assert hashlib.sha256(z.read(f)).hexdigest() == h
archive = out / 'K03-0.1.0-候选离线包.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(candidate.iterdir()):
        z.write(p, p.name)
with zipfile.ZipFile(archive) as z:
    for p in sorted(candidate.iterdir()):
        assert hashlib.sha256(z.read(p.name)).hexdigest() == sha(p)
commands = {'date': '2026-10-04', 'passed': actual['passed'], 'commands': actual['commands'], 'sourceRebuildNested': r['commands']}
(out / 'commands.json').write_text(json.dumps(commands, ensure_ascii=False, indent=2))
visual = {'date': '2026-10-04', 'ruleVersion': m['ruleVersion'], 'candidateHTMLSHA': sha(candidate / 'index.html'), 'candidateRuntimeSHA': sha(candidate / 'runtime.json'), 'method': '实际打开以下三张最终回归截图；其余81张主浏览器/原生页面仅自动几何检查，未逐张人工目视', 'reviewed': [{ 'file': str(out / f), 'sha256': sha(out / f)} for f in ['micro-return-browser/micro-320-source.png', 'original-site/site-1440-5.png', 'browser/offline-390-5.png']], 'result': '320来源追溯、390离线页面、1440原生官网宿主布局可读；宽表保留横向滚动，无页级越界'}
(out / 'visual-review.json').write_text(json.dumps(visual, ensure_ascii=False, indent=2))
tool_files = {str(p): sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
evidence_files = {str(p): sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'handoff-manifest.json'}
candidate_files = {p.name: sha(p) for p in sorted(candidate.iterdir())}
source_files = {f: h for f, h in tool_files.items() if '/candidate/' not in f}
shared = {f: v for f, v in r['sourceFiles'].items() if not f.startswith(str(folder))}
canonical = '\n'.join(f'{p}\t{h}' for p, h in sorted(source_files.items()))
manifest = {
    'date': '2026-10-04', 'tool': 'K03', 'name': '存货库龄与周转', 'version': '0.1.0', 'ruleVersion': 'K03-2026-10-04.2',
    'status': 'tested_candidate_handoff_frozen', 'accepted': False, 'published': False,
    'ownerScope': [str(folder), 'progress/evidence/K03'],
    'sourceBaselineSHA': hashlib.sha256(canonical.encode()).hexdigest(),
    'sourceFiles': source_files, 'sharedBuildSnapshot': shared, 'candidateFiles': candidate_files, 'evidenceFiles': evidence_files,
    'candidateHTMLSHA': sha(candidate / 'index.html'), 'candidateRuntimeSHA': sha(candidate / 'runtime.json'),
    'sourceZIP': {'file': str(source_zip), 'sha256': sha(source_zip)},
    'offlineZIP': {'file': str(archive), 'sha256': sha(archive), 'membersVerified': len(candidate_files)},
    'validation': {'tests': 56, 'rootIndependentPassed': 6, 'rootIndependentScriptSHA': root['script_sha256'], 'repairCommandsPassed': 8, 'browserGroups': 15, 'browserDownloads': 30, 'browserScreenshots': 54, 'microReturnBrowserGroups': 7, 'microReturnBrowserDownloads': 7, 'originalSiteCandidateGroups': 8, 'originalSiteScreenshots': 27, 'sourceRebuildCommandsPassed': 4, 'rebuiltCandidatesSHAEqual': len(r['compared']), 'visuallyReviewedScreenshots': 3},
    'retainedFailure': {'file': str(out / 'history/root-before-micro-return-repair/result.json'), 'failed': oldroot['failed'], 'sha256': sha(out / 'history/root-before-micro-return-repair/result.json')},
    'remaining': ['总控独立正式财务及发布门禁', '正式公开官网及下载验证', 'Windows实机未验证'],
    'writeFreeze': '交接清单完成后停止写入工具源码和候选；缺陷回唯一原线程'
}
(out / 'handoff-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
print(json.dumps({'sourceFiles': len(source_files), 'sharedFiles': len(shared), 'candidateFiles': len(candidate_files), 'evidenceFiles': len(evidence_files), 'sourceBaselineSHA': manifest['sourceBaselineSHA'], 'sourceZIP': manifest['sourceZIP'], 'offlineZIP': manifest['offlineZIP']}, ensure_ascii=False))
