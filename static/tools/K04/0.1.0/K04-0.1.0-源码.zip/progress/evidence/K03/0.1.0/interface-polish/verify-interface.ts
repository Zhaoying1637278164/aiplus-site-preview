import { chromium } from 'playwright';
import { readFile,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
import { readFileData,asTable } from '../../../../../packages/core/io';
const root=path.resolve('.'),folder=root+'/tools/K03-存货库龄与周转',out=root+'/progress/evidence/K03/0.1.0/interface-polish';
const hash=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex');
const expected=await readFile(folder+'/README.md');
assert.equal(await readFile(folder+'/src/usage.ts','utf8'),'export const USAGE=`'+expected.toString()+'`;\n');
assert.deepEqual(await readFile(folder+'/candidate/0.1.0/使用说明.md'),expected);
const browser=await chromium.launch({headless:true,executablePath:process.env.K03_CHROMIUM||'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
const downloads:any[]=[],errors:string[]=[],requests:string[]=[],labels:any[]=[],groupChecks:any[]=[],guideChecks:any[]=[];
try {
 for(const [tag,file] of [['offline',folder+'/candidate/0.1.0/index.html'],['native',root+'/progress/evidence/K03/0.1.0/browser/host.html']]) {
  const context=await browser.newContext({offline:true,acceptDownloads:true,viewport:{width:1440,height:1000}});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});
  await page.goto('file://'+file);await page.getByRole('heading',{name:'存货库龄与周转',exact:true}).waitFor();
  for(const [section,button] of [['import','01 资料导入'],['restore','09 底稿与恢复']]) {
   await page.getByRole('navigation').getByRole('button',{name:button,exact:true}).click();
   if(section==='restore'){
    const guide=page.getByLabel('使用说明正文');assert.equal(await guide.locator('h4').textContent(),'存货库龄与周转使用说明');
    const steps=expected.toString().split('\n').filter(line=>/^\d+\. /.test(line)).map(line=>line.replace(/^\d+\. /,''));
    assert.deepEqual(await guide.locator('ol > li').allTextContents(),steps);
    assert.equal(await guide.locator('pre').count(),0);assert.equal(await guide.locator('script,img,iframe').count(),0);
    assert.doesNotMatch(await guide.innerText(),/^# /m);guideChecks.push({mode:tag,heading:true,completeSteps:steps.length,plainReactText:true});
   }
   const pending=page.waitForEvent('download');await page.getByRole('button',{name:'下载使用说明',exact:true}).click();
   const download=await pending;const file=out+'/'+tag+'-'+section+'-使用说明.md';await download.saveAs(file);
   const actual=await readFile(file);assert.deepEqual(actual,expected);downloads.push({mode:tag,section,file:path.relative(root,file),sha256:hash(actual),bytes:actual.length});
  }
  await page.getByRole('navigation').getByRole('button',{name:'01 资料导入',exact:true}).click();await page.getByRole('button',{name:'载入虚构样例',exact:true}).click();await page.getByRole('button',{name:'计算并复核',exact:true}).click();await page.getByRole('status').filter({hasText:'计算完成'}).waitFor();
  const groups=page.getByLabel('库存分组');assert.equal(await groups.count(),2);
  for(let i=0;i<2;i++){
   const g=groups.nth(i);assert.deepEqual(await g.locator('dt').allTextContents(),['主体','仓库','物料','币种','数量单位','金额单位']);
   assert.deepEqual(await g.locator('dd').allTextContents(),['虚构甲公司','甲仓','A','CNY','件','元']);assert.doesNotMatch(await g.innerText(),/\[|\]/);groupChecks.push({mode:tag,row:i,labels:6,values:6});
  }
  for(const width of [1440,320]){
   await page.setViewportSize({width,height:1000});
   for(const span of await page.locator('.k03-query-label').all()){
    const geometry=await span.evaluate(el=>{const r=document.createRange();r.selectNodeContents(el);return {rects:r.getClientRects().length,text:el.textContent,nowrap:getComputedStyle(el).whiteSpace}});
    assert.equal(geometry.rects,1);assert.equal(geometry.text,'查询');assert.equal(geometry.nowrap,'nowrap');labels.push({mode:tag,width,...geometry});
   }
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2),false);
   await page.screenshot({path:out+'/'+tag+'-closing-'+width+'.png',fullPage:true});
   await page.getByRole('navigation').getByRole('button',{name:'09 底稿与恢复',exact:true}).click();
   await page.screenshot({path:out+'/'+tag+'-guide-'+width+'.png',fullPage:true});
   await page.getByRole('navigation').getByRole('button',{name:'04 截止库存',exact:true}).click();
  }
  await context.close();
 }
 // Actual full-workbook comparison includes all ten sheets and the raw internal group key.
 const previous=await readFileData('old.xlsx',await readFile(root+'/progress/evidence/K03/0.1.0/history/before-interface-polish/browser/full.xlsx'));
 const current=await readFileData('new.xlsx',await readFile(root+'/progress/evidence/K03/0.1.0/browser/full.xlsx'));
 assert.deepEqual(current.sheets.map(s=>s.name),previous.sheets.map(s=>s.name));
 for(const sheet of previous.sheets)assert.deepEqual(current.sheets.find(s=>s.name===sheet.name)!.matrix,sheet.matrix,sheet.name);
 assert.match(String(asTable(current,'截止核对').rows[0].cells['分组']),/^\[/);
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 await writeFile(out+'/result.json',JSON.stringify({passed:true,scope:'离线HTML及同runtime原生ShadowDOM宿主；非公开官网',downloads,labels,groupChecks,guideChecks,workbookSheetsUnchanged:10,internalGroupKeyUnchanged:true,errors,requests,guideSHA:hash(expected),htmlSHA:hash(await readFile(folder+'/candidate/0.1.0/index.html')),runtimeSHA:hash(await readFile(folder+'/candidate/0.1.0/runtime.json')),windows:'未实测'},null,2));
 console.log(JSON.stringify({passed:true,downloadByteChecks:downloads.length,labelGeometryChecks:labels.length,groupRows:groupChecks.length,completeSteps:7,workbookSheetsUnchanged:10}));
} finally {await browser.close()}
