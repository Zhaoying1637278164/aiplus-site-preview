# 第三方声明

本款复用工程锁定依赖：React/react-dom19.1.1、Decimal.js10.6.0、ExcelJS4.4.0、PapaParse5.5.3、pako1.0.11及浏览器构建中传递依赖。MIT、ISC（saxes）、BSD-3-Clause（ieee754）、MIT AND Zlib（pako），JSZip选择MIT分支；各依赖版权/许可原文保留licenses目录；依赖及许可列表见licenses/manifest.json和package-lock.json。ESBuild/TypeScript/tsx/Playwright仅开发测试依赖，不打入成品。成品禁止外部下载/CDN。

ERPNext v15.0.0参考快照为GPLv3（references/erpnext-GPL-3.txt）；仅阅读粒度、重复和盘差方法，无移植或复制源码，上游未运行。该快照用于来源核验，未打入运行程序，保留原版权/许可。DataComPy未采用。

公共packages/core和packages/ui由本项目集成方维护，本款只通过已有接口复用，源码包保留原文件和锁文件。所有样例完全虚构。许可原文及版权通知随程序和源码一并保留。
