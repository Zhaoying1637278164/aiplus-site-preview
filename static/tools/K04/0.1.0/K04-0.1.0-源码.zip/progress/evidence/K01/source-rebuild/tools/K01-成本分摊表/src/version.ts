export const VERSION='0.1.0';
export const RULE_VERSION='K01-2026-10-04.1';
