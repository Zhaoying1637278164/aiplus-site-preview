import Decimal from 'decimal.js';
import {amount,text} from '../../../packages/core/value';
import type {Table,SourceRow,Cell} from '../../../packages/core/types';
import {VERSION,RULE_VERSION} from './version';
const D=Decimal.clone({precision:80,rounding:Decimal.ROUND_HALF_UP});
export const schemas={成本:['成本ID','成本池','金额','方式','对象ID','排除理由','依据','主体','期间','币种','单位'],对象:['对象ID','对象名称','启用'],动因:['成本池','对象ID','动因值','动因单位','排除理由','依据','主体','期间','币种','单位'],规则:['成本池','方法','顺序','依据']} as const;
export type Kind=keyof typeof schemas;
export interface DataSet {table:Table;mapping:Record<string,string>;edits:Record<string,Record<string,string>>}
export type Data=Partial<Record<Kind,DataSet>>;
export interface Params {entity:string;period:string;currency:string;unit:string;start:string;end:string;precision:number;tolerance:string;negative:'block'|'allow';zero:'block'|'retain';tail:'last'|'largest'}
export const defaults:Params={entity:'虚构星禾制造',period:'2026-09',currency:'CNY',unit:'元',start:'2026-01',end:'2026-12',precision:2,tolerance:'0',negative:'block',zero:'retain',tail:'last'};
export interface Issue {kind:Kind|'参数';source?:SourceRow;message:string}
export interface Allocation {costId:string;pool:string;objectId:string;objectName:string;method:string;amount:string;weight:string;denominator:string;ratio:string;raw:string;rounded:string;adjustment:string;source:SourceRow;driver?:SourceRow;rule?:SourceRow;evidence:string}
export interface Disposition {costId:string;pool:string;amount:string;status:'直接'|'分摊'|'排除'|'未分配';reason:string;source:SourceRow}
export interface Check {pool:string;source:string;direct:string;allocated:string;excluded:string;unallocated:string;difference:string;passed:boolean}
export interface Result {app_version:string;rule_version:string;params:Params;issues:Issue[];ready:boolean;lines:Allocation[];costs:Disposition[];checks:Check[];objects:{id:string;name:string;direct:string;allocated:string;total:string}[];driverReview:{source:SourceRow;eligible:boolean;reason:string}[]}
export function dataset(table:Table):DataSet{return {table,mapping:Object.fromEntries(table.headers.map(h=>[h,h])),edits:{}}}
export function value(ds:DataSet,row:SourceRow,field:string):Cell {return ds.edits[String(row.row)]?.[field]??row.cells[ds.mapping[field]]??null}
const optional=(v:Cell)=>v===null||v===undefined||v===''?'':text(v,true);
const num=(v:Cell)=>new D(amount(v).toString());
export function validateParams(p:Params){
 for(const f of ['entity','currency','unit','period','start','end','tolerance'] as const){if(typeof p[f]!=='string')throw Error('参数类型无效');text(p[f],true)}
 for(const f of ['period','start','end'] as const)if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(p[f]))throw Error('期间及生效期须为YYYY-MM');
 if(p.start>p.end||p.period<p.start||p.period>p.end)throw Error('当前期间不在规则生效期内');
 if(!Number.isInteger(p.precision)||p.precision<0||p.precision>6)throw Error('金额精度须为0至6');
 if(num(p.tolerance).isNegative())throw Error('容差不能负数');
 if(!['block','allow'].includes(p.negative)||!['block','retain'].includes(p.zero)||!['last','largest'].includes(p.tail))throw Error('处理策略无效');
}
export function calculate(data:Data,p:Params):Result{
 const r:Result={app_version:VERSION,rule_version:RULE_VERSION,params:{...p},issues:[],ready:false,lines:[],costs:[],checks:[],objects:[],driverReview:[]};
 try{validateParams(p)}catch(e){r.issues.push({kind:'参数',message:(e as Error).message});return r}
 const objs=new Map<string,{id:string;name:string;active:boolean;source:SourceRow}>();
 const costs:{id:string;pool:string;amount:Decimal;mode:string;obj:string;reason:string;basis:string;source:SourceRow}[]=[];
 const drivers=new Map<string,{pool:string;obj:string;n:Decimal;unit:string;reason:string;basis:string;source:SourceRow}>();
 const rules=new Map<string,{method:string;order:number;basis:string;source:SourceRow}>();
 const seen=new Set<string>();
 for(const kind of Object.keys(schemas) as Kind[]){const ds=data[kind];if(!ds){r.issues.push({kind,message:'尚未提供'+kind+'资料'});continue}
 if(ds.table.rows.length>20000||ds.table.headers.length>200){r.issues.push({kind,message:'表格超过行列上限'});continue}
 for(const field of schemas[kind])if(!ds.mapping[field]||!ds.table.headers.includes(ds.mapping[field]))r.issues.push({kind,message:'未映射字段：'+field});
 const refs=new Set<number>();
 for(const row of ds.table.rows){try{
 if(refs.has(row.row))throw Error('来源行号重复');refs.add(row.row);
 const get=(f:string)=>value(ds,row,f),req=(f:string)=>text(get(f),true),opt=(f:string)=>optional(get(f));
 // Reject formulas anywhere, including unmapped cells; never trust cached results.
 if(Object.values(row.cells).some(v=>v!==null&&typeof v==='object'))throw Error('含公式或Excel错误，请提供静态值');
 const unique=(key:string)=>{const full=JSON.stringify([kind,key]);if(seen.has(full))throw Error('重复键：'+key);seen.add(full)};
 if(kind==='对象'){const id=req('对象ID');unique(id);const active=req('启用');if(!['是','否'].includes(active))throw Error('启用只能是/否');objs.set(id,{id,name:req('对象名称'),active:active==='是',source:row});}
 else if(kind==='规则'){const pool=req('成本池');unique(pool);const method=req('方法'),order=req('顺序');if(!['动因','等权'].includes(method))throw Error('方法只能动因/等权');if(!/^\d{1,6}$/.test(order))throw Error('顺序须为非负整数');rules.set(pool,{method,order:Number(order),basis:opt('依据'),source:row});}
 else {
 for(const [field,target] of [['主体',p.entity],['期间',p.period],['币种',p.currency],['单位',p.unit]])if(req(field)!==target)throw Error(field+'与当前范围不一致');
 const pool=req('成本池');
 if(kind==='成本'){const id=req('成本ID');unique(id);const a=num(get('金额'));if(a.decimalPlaces()>p.precision)throw Error('源金额超过当前输出精度，不可静默舍入');if(a.isNegative()&&p.negative==='block')throw Error('负成本须明确确认红冲策略');const mode=req('方式');if(!['直接','分摊','排除'].includes(mode))throw Error('方式只能直接/分摊/排除');const reason=opt('排除理由'),obj=opt('对象ID'),basis=opt('依据');if(mode==='排除'&&!reason)throw Error('排除成本必须填写理由');if(mode==='直接'&&(!obj||!basis))throw Error('直接归属须对象及依据');if(mode!=='排除'&&reason)throw Error('只有排除成本可填排除理由');if(mode==='分摊'&&obj)throw Error('分摊成本不能同时指定直接对象');costs.push({id,pool,amount:a,mode,obj,reason,basis,source:row});}
 else {const obj=req('对象ID');unique(JSON.stringify([pool,obj]));const n=num(get('动因值'));if(n.isNegative())throw Error('动因不得为负');drivers.set(JSON.stringify([pool,obj]),{pool,obj,n,unit:req('动因单位'),reason:opt('排除理由'),basis:opt('依据'),source:row});}
 }
 }catch(e){r.issues.push({kind,source:row,message:(e as Error).message})}}
 }
 for(const c of costs)if(c.mode==='直接'&&!objs.get(c.obj)?.active)r.issues.push({kind:'成本',source:c.source,message:'直接对象不存在或未启用'});
 const units=new Map<string,string>();
 for(const d of drivers.values()){
 if(!objs.has(d.obj))r.issues.push({kind:'动因',source:d.source,message:'动因对象不存在'});
 if(!d.reason){const old=units.get(d.pool);if(old&&old!==d.unit)r.issues.push({kind:'动因',source:d.source,message:'同池动因计量单位不一致'});units.set(d.pool,d.unit)}
 const eligible=!!objs.get(d.obj)?.active&&!d.reason&&!!d.basis;r.driverReview.push({source:d.source,eligible,reason:d.reason||(!objs.get(d.obj)?.active?'对象未启用':!d.basis?'缺动因依据':'参与分摊')});
 }
 if(r.issues.length)return r;
 const active=[...objs.values()].filter(o=>o.active).sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);
 const ordered=[...costs].sort((a,b)=>(rules.get(a.pool)?.order??999999)-(rules.get(b.pool)?.order??999999)||a.id.localeCompare(b.id));
 for(const c of ordered){const rule=rules.get(c.pool);let status=c.mode as Disposition['status'],reason=c.reason;
 if(c.mode==='直接'){r.lines.push({costId:c.id,pool:c.pool,objectId:c.obj,objectName:objs.get(c.obj)!.name,method:'直接',amount:c.amount.toFixed(p.precision),weight:'1',denominator:'1',ratio:'1',raw:c.amount.toString(),rounded:c.amount.toFixed(p.precision),adjustment:'0',source:c.source,evidence:c.basis});}
 if(c.mode==='分摊'){
 let candidates=active.map(o=>({o,d:drivers.get(JSON.stringify([c.pool,o.id]))}));
 if(!c.basis)reason='缺成本归集依据';else if(!rule||!rule.basis)reason='缺分配规则或规则依据';
 else if(rule.method==='动因'){
 // Missing evidence is never silently dropped from an otherwise valid pool.
 const missing=candidates.filter(x=>!x.d||(!x.d.reason&&!x.d.basis));
 if(missing.length)reason='缺对象动因或动因依据：'+missing.map(x=>x.o.id).join('、');
 candidates=candidates.filter(x=>x.d&&!x.d.reason);
 }
 const weighted=candidates.map(x=>({...x,n:rule?.method==='等权'?new D(1):x.d?.n??new D(0)}));
 const den=weighted.reduce((s,x)=>s.plus(x.n),new D(0));
 if(!reason&&den.isZero()){reason='有效动因合计为零';if(p.zero==='block')r.issues.push({kind:'成本',source:c.source,message:reason})}
 if(reason){status='未分配'}else{
 if(r.lines.length+weighted.length>100000){r.issues.push({kind:'成本',source:c.source,message:'分配明细超过100000行，请缩小批次'});break}
 const amounts=weighted.map(x=>c.amount.times(x.n).div(den).toDecimalPlaces(p.precision));
 const delta=c.amount.minus(amounts.reduce((s,a)=>s.plus(a),new D(0)));
 
 const adjustments=weighted.map(()=>new D(0));let pending=delta;
 const priority=weighted.map((x,i)=>i).filter(i=>weighted[i].n.gt(0)).sort((a,b)=>p.tail==='last'?b-a:weighted[b].n.comparedTo(weighted[a].n)||a-b);
 for(const i of priority){if(pending.isZero())break;const next=amounts[i].plus(pending);const flips=c.amount.gt(0)?next.lt(0):c.amount.lt(0)?next.gt(0):false;const adj=flips?amounts[i].negated():pending;adjustments[i]=adj;pending=pending.minus(adj)}
 if(!pending.isZero()){r.issues.push({kind:'成本',source:c.source,message:'尾差无法守恒，请提高精度'});break}
 weighted.forEach((x,i)=>{const raw=c.amount.times(x.n).div(den),adjust=adjustments[i];r.lines.push({costId:c.id,pool:c.pool,objectId:x.o.id,objectName:x.o.name,method:rule!.method,amount:amounts[i].plus(adjust).toFixed(p.precision),weight:x.n.toString(),denominator:den.toString(),ratio:x.n.div(den).toString(),raw:raw.toString(),rounded:amounts[i].toFixed(p.precision),adjustment:adjust.toString(),source:c.source,driver:rule!.method==='动因'?x.d?.source:undefined,rule:rule!.source,evidence:[c.basis,rule!.basis,x.d?.basis].filter(Boolean).join('；')})});
 }
 }
 r.costs.push({costId:c.id,pool:c.pool,amount:c.amount.toFixed(p.precision),status,reason,source:c.source});
 }
 if(r.issues.length){r.lines=[];r.costs=[];return r}
 for(const pool of new Set(costs.map(c=>c.pool))){const cs=r.costs.filter(c=>c.pool===pool);const sum=(mode?:string)=>cs.filter(c=>!mode||c.status===mode).reduce((s,c)=>s.plus(c.amount),new D(0));const source=sum(),direct=sum('直接'),allocated=sum('分摊'),excluded=sum('排除'),unallocated=sum('未分配');const lineTotal=r.lines.filter(l=>l.pool===pool).reduce((s,l)=>s.plus(l.amount),new D(0));const diff=source.minus(lineTotal).minus(excluded).minus(unallocated);r.checks.push({pool,source:source.toFixed(p.precision),direct:direct.toFixed(p.precision),allocated:allocated.toFixed(p.precision),excluded:excluded.toFixed(p.precision),unallocated:unallocated.toFixed(p.precision),difference:diff.toFixed(p.precision),passed:diff.abs().lte(num(p.tolerance))})}
 r.objects=[...objs.values()].map(o=>{const lines=r.lines.filter(l=>l.objectId===o.id);const sum=(mode:string)=>lines.filter(l=>mode==='全部'||l.method===mode).reduce((s,l)=>s.plus(l.amount),new D(0));const direct=sum('直接'),total=sum('全部');return {id:o.id,name:o.name,direct:direct.toFixed(p.precision),allocated:total.minus(direct).toFixed(p.precision),total:total.toFixed(p.precision)}});
 r.ready=true;return r;
}
