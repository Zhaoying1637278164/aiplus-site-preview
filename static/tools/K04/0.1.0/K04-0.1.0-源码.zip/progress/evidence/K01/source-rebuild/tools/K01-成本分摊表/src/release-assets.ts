import {USAGE} from './usage';
import {workbookBytes} from '../../../packages/core/io';import type {ReleaseAsset} from '../../../packages/core/release-assets';import {schemas,defaults,type Kind} from './engine';import {example,csv,encodeWork} from './documents';
export async function releaseAssets():Promise<ReleaseAsset[]>{const enc=new TextEncoder(),data=example(),sheets=(Object.keys(schemas) as Kind[]).map(kind=>({name:kind,headers:[...schemas[kind]],rows:data[kind]!.table.rows.map(r=>schemas[kind].map(h=>r.cells[h]))}));return [
 {filename:'使用说明.md',data:enc.encode(USAGE)},
 {filename:'空白模板.csv',data:enc.encode(csv([...schemas.成本],[]))},
 ...(['对象','动因','规则'] as Kind[]).map(k=>({filename:k+'模板.csv',data:enc.encode(csv([...schemas[k]],[]))})),
 ...sheets.map(s=>({filename:'虚构'+s.name+'.csv',data:enc.encode(csv(s.headers,s.rows))})),
 {filename:'虚构样例.xlsx',data:await workbookBytes(sheets)},
 {filename:'四表空白模板.xlsx',data:await workbookBytes(sheets.map(s=>({...s,rows:[]})))},
 {filename:'无数据方案.json',data:enc.encode(encodeWork({},defaults,false))},
 {filename:'虚构含数据工作.json',data:enc.encode(encodeWork(data,defaults,true))},
 ];}
