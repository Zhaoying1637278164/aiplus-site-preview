import Papa from 'papaparse';
import {workbookBytes,readFileData,asTable} from '../../../packages/core/io';
import type {Table,SourceRow} from '../../../packages/core/types';
import {LIMITS} from '../../../packages/core/types';
import {schemas,defaults,dataset,validateParams,calculate,value,type Data,type Params,type Kind,type Result} from './engine';
import {VERSION,RULE_VERSION} from './version';
export function table(kind:Kind,rows:string[][],file='虚构样例.xlsx'):Table{const headers=[...schemas[kind]];return {file,sheet:kind,headers,rows:rows.map((cells,i)=>({file,sheet:kind,row:i+2,cells:Object.fromEntries(headers.map((h,k)=>[h,cells[k]??null]))}))}}
export function example():Data{const scope=[defaults.entity,defaults.period,defaults.currency,defaults.unit];return {
 成本:dataset(table('成本',[['C001','办公','120','直接','A','','虚构领用单',...scope],['C002','公共','100','分摊','','','虚构共享服务',...scope],['C003','办公','10','排除','','个人项目','虚构不纳入说明',...scope]])),
 对象:dataset(table('对象',[['A','产品甲','是'],['B','产品乙','是']])),
 动因:dataset(table('动因',[['公共','A','1','工时','','虚构工时表',...scope],['公共','B','3','工时','','虚构工时表',...scope]])),
 规则:dataset(table('规则',[['公共','动因','1','用户确认按工时']])),
}}
export function csv(headers:string[],rows:unknown[][]){return '\uFEFF'+Papa.unparse({fields:headers,data:rows.map(r=>r.map(x=>x===null||x===undefined?'':String(x)))},{escapeFormulae:true})}
export function encodeWork(data:Data,p:Params,include:boolean){validateParams(p);const raw=JSON.stringify({schema_version:1,tool:'K01',app_version:VERSION,rule_version:RULE_VERSION,contains_data:include,params:p,...(include?{data}:{})},null,2);if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MB，请分批处理或下载XLSX底稿');return raw}
export function decodeWork(raw:string):{data:Data;params:Params}{
 if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MB');const w=JSON.parse(raw);
 if(w?.schema_version!==1||w?.tool!=='K01'||w?.app_version!==VERSION||w?.rule_version!==RULE_VERSION||typeof w.contains_data!=='boolean')throw Error('方案版本或标识不兼容');
 const p=w.params;if(!p||typeof p!=='object')throw Error('方案参数缺失');validateParams(p);
 const params:Params={...defaults,...Object.fromEntries(Object.keys(defaults).map(k=>[k,p[k]]))};const data:Data={};
 if(!w.contains_data){if(w.data!==undefined)throw Error('无数据方案却含资料');return {data,params}}
 if(!w.data||typeof w.data!=='object'||Object.keys(w.data).some(k=>!(k in schemas)))throw Error('方案资料格式无效');
 for(const kind of Object.keys(schemas) as Kind[]){const ds=w.data[kind];if(!ds)continue;const t=ds.table;
 if(!t||typeof t.file!=='string'||typeof t.sheet!=='string'||!Array.isArray(t.headers)||t.headers.length>200||!t.headers.length||t.headers.some((h:unknown)=>typeof h!=='string'||!h)||new Set(t.headers).size!==t.headers.length||!Array.isArray(t.rows)||t.rows.length>20000)throw Error('方案表格格式或上限无效');
 const rows:SourceRow[]=t.rows.map((row:any)=>{if(!row||typeof row.file!=='string'||typeof row.sheet!=='string'||!Number.isInteger(row.row)||row.row<1||!row.cells||typeof row.cells!=='object'||Array.isArray(row.cells))throw Error('方案来源行无效');const cells=Object.fromEntries(t.headers.map((h:string)=>{const v=row.cells[h];if(!(v===null||typeof v==='string'||typeof v==='number')||(typeof v==='string'&&v.length>10000)||(typeof v==='number'&&!Number.isFinite(v)))throw Error('方案单元格无效或含公式');return [h,v]}));return {file:row.file,sheet:row.sheet,row:row.row,cells}});
 if(!ds.mapping||!ds.edits||typeof ds.mapping!=='object'||typeof ds.edits!=='object'||Array.isArray(ds.edits))throw Error('方案字段或修订无效');
 const mapping:Record<string,string>={};for(const f of schemas[kind]){const m=ds.mapping[f];if(typeof m!=='string'||(!t.headers.includes(m)&&m!==''))throw Error('方案字段映射无效');mapping[f]=m}
 const edits:Record<string,Record<string,string>>={};for(const [key,vals] of Object.entries(ds.edits)){if(!rows.some(r=>String(r.row)===key)||!vals||typeof vals!=='object'||Array.isArray(vals))throw Error('修订来源不存在');const entry:Record<string,string>={};for(const [f,v] of Object.entries(vals)){if(!(schemas[kind] as readonly string[]).includes(f)||typeof v!=='string'||v.length>10000)throw Error('修订字段无效');entry[f]=v}edits[key]=entry}
 data[kind]={table:{file:t.file,sheet:t.sheet,headers:[...t.headers],rows},mapping,edits};
 }return {data,params};
}
export const allocationHeaders=['成本ID','成本池','对象ID','对象名称','方法','金额','动因值','动因合计','比例','未舍入金额','舍入金额','尾差调整','成本来源','动因来源','规则来源','依据'];
export const source=(s?:SourceRow)=>s?`${s.file} / ${s.sheet} / 第${s.row}行`:'';
export const allocationRows=(r:Result)=>r.lines.map(l=>[l.costId,l.pool,l.objectId,l.objectName,l.method,l.amount,l.weight,l.denominator,l.ratio,l.raw,l.rounded,l.adjustment,source(l.source),source(l.driver),source(l.rule),l.evidence]);
export function reportSheets(data:Data,r:Result){return [
 {name:'范围参数',headers:['参数','值'],rows:Object.entries({app_version:VERSION,rule_version:RULE_VERSION,...r.params}).map(([k,v])=>[k,String(v)])},
 {name:'对象成本',headers:['对象ID','对象名称','直接成本','分摊成本','合计'],rows:r.objects.map(o=>[o.id,o.name,o.direct,o.allocated,o.total])},
 {name:'分配明细',headers:allocationHeaders,rows:allocationRows(r)},
 {name:'成本去向',headers:['成本ID','成本池','金额','状态','原因','来源'],rows:r.costs.map(c=>[c.costId,c.pool,c.amount,c.status,c.reason,source(c.source)])},
 {name:'逐池勾稽',headers:['成本池','来源','直接','分摊','排除','未分配','差额','检查'],rows:r.checks.map(c=>[c.pool,c.source,c.direct,c.allocated,c.excluded,c.unallocated,c.difference,c.passed?'通过':'异常'])},
 {name:'异常',headers:['资料','来源','原因'],rows:r.issues.map(i=>[i.kind,source(i.source),i.message])},
 {name:'动因参与',headers:['来源','是否参与','说明'],rows:r.driverReview.map(d=>[source(d.source),d.eligible?'是':'否',d.reason])},
 ...Object.entries(data).flatMap(([k,ds])=>ds?[{name:k+'原始资料',headers:['来源文件','页签','原行',...ds.table.headers],rows:ds.table.rows.map(row=>[row.file,row.sheet,row.row,...ds.table.headers.map(h=>row.cells[h])])},{name:k+'有效资料',headers:['来源文件','页签','原行',...schemas[k as Kind]],rows:ds.table.rows.map(row=>[row.file,row.sheet,row.row,...schemas[k as Kind].map(f=>value(ds,row,f))])}]:[]),
 {name:'字段对应与修订',headers:['资料','字段对应','修订记录'],rows:Object.entries(data).map(([k,ds])=>[k,JSON.stringify(ds?.mapping),JSON.stringify(ds?.edits)])}];}
export async function exportReport(data:Data,r:Result){if(!r.ready)throw Error('运行被阻断，请先处理异常');return workbookBytes(reportSheets(data,r))}
export async function imported(file:string,bytes:Uint8Array,sheet?:string,header=1){const loaded=await readFileData(file,bytes);return {loaded,ds:dataset(asTable(loaded,sheet??loaded.sheets[0].name,header))}}
