from pathlib import Path
import zipfile
root=Path('tools/F04-集团往来与合并抵销/tests/fixtures');root.mkdir(exist_ok=True)
for name,extras in [('macro.xlsx',{'xl/vbaProject.bin':b'FAKE MACRO DO NOT EXECUTE'}),('inflated.xlsx',{'xl/worksheets/sheet1.xml':b' '* (30*1024*1024+1)}),('external-name.xlsx',{'xl/externalLinks/externalLink1.xml':b'<externalLink/>'})]:
 with zipfile.ZipFile(root/name,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('[Content_Types].xml','<Types/>')
  for entry,data in extras.items():z.writestr(entry,data)
