from pathlib import Path
import json,zipfile,shutil,hashlib,subprocess,tempfile,os
ROOT=Path.cwd();E=ROOT/'progress/evidence/F04/0.1.2';tool=Path('tools/F04-集团往来与合并抵销'); staging=E/'source-staging'
if staging.exists():shutil.rmtree(staging)
staging.mkdir(parents=True)
shutil.copytree(ROOT/tool,staging/tool,ignore=shutil.ignore_patterns('任务与接续.md','实现交接.md','验收证据.md','node_modules'))
shutil.copytree(ROOT/'packages',staging/'packages')
for name in ['package-lock.json','tsconfig.json']:shutil.copy2(ROOT/name,staging/name)
p=json.loads((ROOT/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/F04-集团往来与合并抵销/tests/*.test.ts','typecheck':'tsc --noEmit -p tools/F04-集团往来与合并抵销/tsconfig.json','build':'node --import tsx tools/F04-集团往来与合并抵销/tests/build-candidate.ts'}
(staging/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
(staging/'references').mkdir();shutil.copy2(ROOT/'references/saxes-5.0.1-LICENSE',staging/'references/saxes-5.0.1-LICENSE')
(staging/'构建说明.md').write_text('Node.js22以上。依次npm ci；npm test；npm run typecheck；npm run build -- F04。输出progress/evidence/F04/0.1.2/candidate。只含本款与共享包；package.json仅修改scripts作独立重建，不改变依赖与锁文件。源码不含候选交接状态三份文档，避免哈希循环；产品、规格、财务规则、参考、README和测试完整包含。运行不需要网络，开发安装需要可用npm依赖源或已有缓存。Windows实机未验证。\n')
shutil.copy2(E/'candidate/THIRD_PARTY_NOTICES.md',staging/'THIRD_PARTY_NOTICES.md')
def zipdir(base,out):
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(base.rglob('*')):
   if f.is_file():
    info=zipfile.ZipInfo(str(f.relative_to(base)),date_time=(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,f.read_bytes())
source_zip=E/'F04-0.1.2-候选源码.zip';offline_zip=E/'F04-0.1.2-候选离线包.zip';zipdir(staging,source_zip);zipdir(E/'candidate',offline_zip)
results=[];matches={}
with tempfile.TemporaryDirectory(prefix='F04-isolated-') as tmp:
 rebuild=Path(tmp)
 with zipfile.ZipFile(source_zip) as z:z.extractall(rebuild)
 for name,cmd in [('install',['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund']),('test',['npm','test']),('typecheck',['npm','run','typecheck']),('build',['npm','run','build','--','F04'])]:
  proc=subprocess.run(cmd,cwd=rebuild,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (E/('source-rebuild-'+name+'.log')).write_text(proc.stdout)
  results.append({'command':cmd,'exit_code':proc.returncode})
  if proc.returncode:break
 rebuilt=rebuild/'progress/evidence/F04/0.1.2/candidate'
 if rebuilt.exists():
  for f in sorted((E/'candidate').iterdir()):
   if f.is_file():matches[f.name]=f.read_bytes()==(rebuilt/f.name).read_bytes()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source_files={str(f.relative_to(staging)):sha(f) for f in sorted(staging.rglob('*')) if f.is_file()}
manifest={'commands':results,'matches':matches,'status':'passed' if len(results)==4 and all(r['exit_code']==0 for r in results) and matches and all(matches.values()) else 'failed','isolation':'actual extracted source ZIP in fresh /private/tmp directory; no root node_modules or source symlink','packages':{f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in [source_zip,offline_zip]},'source_files':source_files,'source_baseline_sha256':hashlib.sha256(json.dumps(source_files,sort_keys=True).encode()).hexdigest()}
(E/'source-rebuild.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='source_files'},ensure_ascii=False))
if manifest['status']!='passed':raise SystemExit(1)
