# -*- coding: utf-8 -*-
"""Independent Python Decimal oracle. No engine import, no expected values copied from engine output."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,sys,hashlib,zipfile,xml.etree.ElementTree as ET
getcontext().prec=60
base=Path(sys.argv[1]);paths=json.loads((base/'all-cell-input.json').read_text());w=json.loads(Path(paths['work']).read_text());d=w['data'];labels={'entities':'主体关系','balances':'内部往来','mapping':'对方映射','templates':'抵销模板'}
J=lambda v:json.dumps(v,ensure_ascii=False,separators=(',',':'));H=lambda v:hashlib.sha256(J(v).encode()).hexdigest();S=lambda x:format(x,'f').rstrip('0').rstrip('.') if '.' in format(x,'f') else format(x,'f')
# Independently generated input expectations; the received work file is only the raw input/provenance.
entities=[['G','虚构示范集团',None,'是','是','2026-09','CNY','元','虚构已批准控制范围G-09']]+[['E'+str(i),'虚构主体'+str(i),'G','是','是','2026-09','CNY','元','虚构已批准控制范围G-09'] for i in range(1,27)]
balances=[];templates=[];groups=[]
for i in range(1,303):
 a='E'+str(((i-1)//2%13)*2+1);b='E'+str(((i-1)//2%13)*2+2)
 if i%2==0:a,b=b,a
 item='虚构事项'+str(i).zfill(3);amt='0' if i==1 else str(i*100)+'.123456'
 balances.extend([['R'+str(2*i-1),a,'虚构别名'+b,item,'借',amt,'其他应收款','0','2026-09','CNY','元','虚构期末独立清单'+str(i)+'借'],['R'+str(2*i),b,'虚构别名'+a,item,'贷',amt,'其他应付款','0','2026-09','CNY','元','虚构期末独立清单'+str(i)+'贷']])
 templates.append(['T'+str(i),item,'其他应收款','其他应付款','2026-01','2026-12','虚构指定科目模板证据'+str(i)])
 groups.append((J([a,b,item,'2026-09','CNY','元']),a,b,item,Decimal(amt),'T'+str(i)))
mapping=[['E'+str(i),'虚构别名E'+str(i+1 if i%2 else i-1),'E'+str(i+1 if i%2 else i-1),'虚构双方客商确认'+str(i)] for i in range(1,27)]
for side,rows in [('entities',entities),('balances',balances),('mapping',mapping),('templates',templates)]:
 assert len(d[side]['rows'])==len(rows)
 for n,(actual,expected) in enumerate(zip(d[side]['rows'],rows)):
  assert list(actual['cells'].values())==expected,(side,n)
  assert actual['row']==n+2 and actual['file']=='完全虚构'+side+'.csv' and actual['sheet']=='CSV'
assert w['rule']['scopeConfirmed'] and w['rule']['completeConfirmed'];scope=H({'data':d,'rule':w['rule']});reviews=[];entries=[];ap=[];total=Decimal(0)
for i,(key,a,b,item,amt,template) in enumerate(groups):
 rev={'preparer':'虚构编制甲','reviewer':'虚构复核乙','date':'2026-09-30','note':'虚构独立核对'+str(i+1),'category':'已核对','binding':H([scope,key])};assert w['reviews'][key]==rev
 approve={'person':'虚构批准丙','date':'2026-09-30','note':'虚构模板人工批准'+str(i+1),'binding':H([scope,d['templates']['rows'][i]])};assert w['approvals'][template]==approve
 reviews.append([key,'已核对',rev['note'],rev['preparer'],rev['reviewer'],rev['date'],'当前']);ap.append([template,approve['person'],approve['date'],approve['note'],approve['binding']])
 if amt:
  sources=J([[r['file'],r['sheet'],r['row']] for r in d['balances']['rows'][i*2:i*2+2]])
  for entity,account,debit,credit in [(b,'其他应付款',S(amt),'0'),(a,'其他应收款','0',S(amt))]:entries.append([key,template,entity,account,debit,credit,rev['preparer'],rev['reviewer'],rev['date'],rev['note'],approve['person'],approve['date'],approve['note'],sources])
  total+=amt
assert total==Decimal('4575237.160256');assert len(entries)==602
specs=[('范围规则版本',['参数','值'],[['工具','F04'],['应用版本','0.1.2'],['规则版本','F04-CN-2026-10-04.1'],['范围',J(w['rule'])],['全局阻塞','false'],['范围边界','简单零减值债权债务；非完整合并报表']]),('双方核对',['核对键','债权方','债务方','事项','债权余额','债务余额','差额','结论','模板','抵销条件'],[[k,a,b,item,S(amt),S(amt),'0','同额反向',t,'可生成指定抵销底稿' if amt else '核对为零，不生成零额分录'] for k,a,b,item,amt,t in groups]),('差异与异常',['资料','类别','问题','源文件','页签','行'],[]),('逐组复核',['核对键','类别','说明','编制人','复核人','日期','当前绑定'],reviews),('模板审批',['模板ID','批准人','日期','依据','绑定'],ap),('抵销分录底稿',['核对键','模板','来源主体','科目','借方','贷方','编制人','复核人','复核日期','复核依据','批准人','批准日期','批准依据','原行来源'],entries),('覆盖与守恒',['资料','输入行','有效行','异常行','守恒金额'],[[labels[s],len(d[s]['rows']),len(d[s]['rows']),0,''] for s in labels]+[['借方合计','','','',S(total)],['贷方合计','','','',S(total)],['借贷残差','','','','0']])]
for side in labels:
 t=d[side];specs.append((labels[side]+'原始来源',['文件','页签','原行']+t['headers'],[[r['file'],r['sheet'],r['row']]+list(r['cells'].values()) for r in t['rows']]))
ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};cells=0;sheet_results=[]
with zipfile.ZipFile(paths['report']) as z:
 assert z.testzip() is None
 strings=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('x:si',ns)]
 actual_names=[e.attrib['name'] for e in ET.fromstring(z.read('xl/workbook.xml')).findall('x:sheets/x:sheet',ns)];assert actual_names==[s[0] for s in specs]
 for i,(name,headers,rows) in enumerate(specs,1):
  actual=[]
  for row in ET.fromstring(z.read('xl/worksheets/sheet'+str(i)+'.xml')).findall('x:sheetData/x:row',ns):
   line=['']*len(headers)
   for cell in row.findall('x:c',ns):
    col=0
    for c in cell.attrib['r'].rstrip('0123456789'):col=col*26+ord(c)-64
    assert col<=len(headers)
    value=cell.find('x:v',ns);v=value.text if value is not None else ''
    if cell.attrib.get('t')=='s':v=strings[int(v)]
    line[col-1]=v
   actual.append(line)
  expected=[[str(v) if v is not None else '' for v in row] for row in [headers]+rows];assert len(actual)==len(expected),(name,len(actual),len(expected))
  for rownum,(a,e) in enumerate(zip(actual,expected),1):
   for colnum,(av,ev) in enumerate(zip(a,e),1):assert av==ev,(name,rownum,colnum,av,ev);cells+=1
  sheet_results.append({'sheet':name,'rows_including_header':len(expected),'columns':len(headers),'cells':len(expected)*len(headers),'status':'passed'})
result={'status':'passed','method':'Independent Python Decimal 60 precision, independent fixture generation, direct ZIP XML reading, every row/cell including headers/empty sheets/source/bindings; no TS engine output used for expected values','sheets':sheet_results,'total_cells':cells,'debit':S(total),'credit':S(total),'residual':'0','xlsx_sha256':hashlib.sha256(Path(paths['report']).read_bytes()).hexdigest()};(base/'all-cell-oracle.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
