"""Independent Decimal oracle: fixed fictitious ledger below, no TS engine imports."""
from decimal import Decimal, getcontext
from pathlib import Path
import json
getcontext().prec=50
rows=[('A','B','货款','借','1000.10'),('A','B','货款','借','200.20'),('B','A','货款','贷','1200.30'),('B','A','借款','借','500'),('A','B','借款','贷','500'),('A','B','费用差异','借','100'),('B','A','费用差异','贷','90')]
groups={}
for owner,other,item,direction,value in rows:
 key=(owner,other,item) if direction=='借' else (other,owner,item)
 sides=groups.setdefault(key,[[],[]]);sides[0 if direction=='借' else 1].append(Decimal(value))
expected=[]
for key,values in groups.items():
 left=sum(values[0],Decimal(0)) if values[0] else None;right=sum(values[1],Decimal(0)) if values[1] else None
 expected.append({'creditor':key[0],'debtor':key[1],'item':key[2],'debit':str(left),'credit':str(right),'delta':str(left-right) if left is not None and right is not None else None,'exact_match':left==right})
assert expected[0]['debit']=='1200.30';assert expected[1]['debit']=='500';assert expected[2]['delta']=='10'
eligible=[r for r in expected if r['exact_match']]
total=sum((Decimal(r['debit']) for r in eligible),Decimal(0));assert total==Decimal('1700.30')
result={'method':'Python Decimal independently specified fictitious ledger; no tested program imports','groups':expected,'approved_nonzero_groups':2,'entries':4,'total_debit':str(total),'total_credit':str(total),'residual':'0.00','no_auto_review_approval':True,'within_tolerance_delta':'-0.001','within_tolerance_elimination_allowed':False,'large_exact_total':'999999999999999999.000003'}
Path('tools/F04-集团往来与合并抵销/examples/独立预期.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
