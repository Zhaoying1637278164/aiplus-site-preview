import {LIMITS} from '../../../packages/core/types';
import {emptyData,sides,validateTable,validateRule,type Work,type Attestation,type Approval} from './engine';
import {VERSION,RULE_VERSION} from './version';
export function encodeWork(w:Work,contains_data:boolean){const raw=JSON.stringify({schema_version:1,tool:'F04',app_version:VERSION,rule_version:RULE_VERSION,contains_data,rule:contains_data?w.rule:{...w.rule,scopeConfirmed:false,completeConfirmed:false},...(contains_data?{data:w.data,reviews:w.reviews,approvals:w.approvals}:{})},null,2);if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MiB，请减少资料');return raw}
function fields(v:unknown,names:string[]){return !!v&&typeof v==='object'&&!Array.isArray(v)&&names.every(k=>typeof (v as any)[k]==='string'&&(v as any)[k].length<=10000)}
export function decodeWork(raw:string):Work{
 if(new TextEncoder().encode(raw).length>LIMITS.bytes)throw Error('方案超过10MiB');const p=JSON.parse(raw);if(p?.schema_version!==1||p?.tool!=='F04'||p?.app_version!==VERSION||p?.rule_version!==RULE_VERSION||typeof p.contains_data!=='boolean')throw Error('方案版本不兼容');validateRule(p.rule);const data=emptyData(),reviews:Record<string,Attestation>={},approvals:Record<string,Approval>={};
 if(p.contains_data){if(!p.data||sides.some(s=>!(s in p.data))||!p.reviews||typeof p.reviews!=='object'||Array.isArray(p.reviews)||!p.approvals||typeof p.approvals!=='object'||Array.isArray(p.approvals)||Object.keys(p.reviews).length>20000||Object.keys(p.approvals).length>20000)throw Error('方案资料/复核/审批结构无效');for(const s of sides){if(p.data[s]!==null){validateTable(p.data[s]);data[s]=p.data[s]}}
 for(const [k,v] of Object.entries(p.reviews)){if(k.length>40000||!fields(v,['preparer','reviewer','date','note','category','binding']))throw Error('复核记录无效');reviews[k]=v as Attestation}for(const [k,v] of Object.entries(p.approvals)){if(k.length>10000||!fields(v,['person','date','note','binding']))throw Error('审批记录无效');approvals[k]=v as Approval}
 }else if('data' in p||'reviews' in p||'approvals' in p||p.rule.scopeConfirmed||p.rule.completeConfirmed)throw Error('无数据方案不能夹带资料或确认');return {data,rule:p.rule,reviews,approvals};
}
