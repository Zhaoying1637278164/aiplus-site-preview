export const VERSION='0.1.2';
export const RULE_VERSION='F04-CN-2026-10-04.1';
