import {columns,defaultRule,emptyWork,type Side,type Work} from './engine';import type {Table} from '../../../packages/core/types';
export function table(s:Side,rows:unknown[][]):Table{return {file:'完全虚构'+s+'.csv',sheet:'CSV',headers:columns[s],rows:rows.map((r,i)=>({file:'完全虚构'+s+'.csv',sheet:'CSV',row:i+2,cells:Object.fromEntries(columns[s].map((h,j)=>[h,r[j] as string|null]))}))}}
export function example():Work {const w=emptyWork();w.data.entities=table('entities',[
 ['G','虚构星河集团',null,'是','是','2026-09','CNY','元','虚构范围决定G-09'],['A','虚构晨光公司','G','是','是','2026-09','CNY','元','虚构范围决定G-09'],['B','虚构海岚公司','G','是','是','2026-09','CNY','元','虚构范围决定G-09']]);
 w.data.mapping=table('mapping',[['A','海岚客商','B','虚构客商确认1'],['B','晨光客商','A','虚构客商确认2']]);
 w.data.balances=table('balances',[
 ['A1','A','海岚客商','货款','借','1000.10','应收账款','0','2026-09','CNY','元','虚构发票1'],['A2','A','海岚客商','货款','借','200.20','应收账款','0','2026-09','CNY','元','虚构发票2'],['B1','B','晨光客商','货款','贷','1200.30','应付账款','0','2026-09','CNY','元','虚构应付清单'],
 ['B2','B','晨光客商','借款','借','500','其他应收款','0','2026-09','CNY','元','虚构借款B-A'],['A3','A','海岚客商','借款','贷','500','其他应付款','0','2026-09','CNY','元','虚构借款B-A'],
 ['A4','A','海岚客商','费用差异','借','100','其他应收款','0','2026-09','CNY','元','虚构差异甲'],['B3','B','晨光客商','费用差异','贷','90','其他应付款','0','2026-09','CNY','元','虚构差异乙']]);
 w.data.templates=table('templates',[['T1','货款','应收账款','应付账款','2026-01','2026-12','虚构批准模板草案1'],['T2','借款','其他应收款','其他应付款','2026-01','2026-12','虚构批准模板草案2'],['T3','费用差异','其他应收款','其他应付款','2026-01','2026-12','虚构批准模板草案3']]);
 w.rule=defaultRule();return w;
}
