import pako from 'pako';import {LIMITS} from '../../../packages/core/types';
function inflate(bytes:Uint8Array){const parts:string[]=[];const decoder=new TextDecoder();const x=new pako.Inflate({raw:true,chunkSize:16384});x.onData=c=>parts.push(decoder.decode(c,{stream:true}));x.push(bytes,true);if(x.err||!x.ended)throw Error('关系文件压缩无效');parts.push(decoder.decode());return parts.join('')}
import {guardZip} from '../../../packages/core/zip';import {readFileData} from '../../../packages/core/io';
export async function readSafeFile(file:string,bytes:Uint8Array){
 if(bytes.length>LIMITS.bytes)throw Error('文件超过10MiB');
 if(/\.xlsx$/i.test(file)){
 guardZip(bytes);const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let end=-1;for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(view.getUint32(i,true)===0x06054b50){end=i;break}let pos=view.getUint32(end+16,true);const count=view.getUint16(end+10,true);for(let i=0;i<count;i++){const length=view.getUint16(pos+28,true),name=new TextDecoder().decode(bytes.subarray(pos+46,pos+46+length));if(/\.rels$/i.test(name)){const local=view.getUint32(pos+42,true),start=local+30+view.getUint16(local+26,true)+view.getUint16(local+28,true),raw=bytes.subarray(start,start+view.getUint32(pos+20,true)),content=view.getUint16(pos+10,true)===0?new TextDecoder().decode(raw):inflate(raw);if(/TargetMode\s*=\s*["']External["']/i.test(content))throw Error('工作簿含外部链接，不支持导入')}pos+=46+length+view.getUint16(pos+30,true)+view.getUint16(pos+32,true)}
 }
 return readFileData(file,bytes);
}
