# 当前进度

2026-10-03。完整64款目标持续有效，accepted **4/64**。一个稳定ID一个长期工具线程，已建12个、52个待建；最多两款同时实现。P03原线程completed/idle，已交接；P04唯一线程已创建；P02原线程实际inProgress返修；P01原官网导航返修排队。Windows实机未验证。

| 工具 | 登记阶段 | 当前证据与剩余工作 |
|---|---|---|
| D02 / D03 / D06 / R01 | accepted | 0.2.0 / 0.2.0 / 0.2.0 / 0.1.0；维护复用原线程，已发布版本冻结 |
| R02 收入确认排程表 | packaged 0.1.0 | 已发布；公开导入、恢复、退出和版本下载待续验 |
| R03 回款对账 | packaged 0.1.0 | 已发布；公开三类XLSX/CSV、含数据恢复、无数据清空、退出取消/确认、人工核销/撤销与9项版本下载已有证据；剩无数据恢复取消保留工作及最终逐项审计 |
| R04 应收账龄与逾期分析 | packaged 0.1.0 | 修复最终16源码SHA、55测试/9独立断言通过；重新正式断网28组、独立源码四命令通过，HTML/runtime一致、12资产内容核验；真实八款暂存官网9组、24导航几何、13次版本下载点击通过（11唯一文件精确字节相等）；原官网320图和详情图已实际审查；已发布，公开操作验收待补齐 |
| R05 坏账计提表 | packaged 0.1.0 | 总控17源码SHA、55测试/11独立断言通过；正式离线20组、16表670格及15导出回读；最终源码四命令及19资产内容核验；真实八款暂存官网9组、24导航几何、20版本下载点击通过（18唯一文件精确字节相等）；当前320图和原详情图已实际审查；已发布，公开操作验收待补齐 |
| P01 采购三单核对 | packaged 0.1.0 | 最终16源码SHA、56测试、10独立财务预期、类型检查通过；正式离线28组、31表8952格/11资产回读；独立源码四命令及18资产内容核验，HTML/runtime精确一致；真实官网与公开验收待做 |
| P02 付款计划表 | implementing，原官网返修 | 总控实际27工具文件及15构建上下文SHA核对一致；45测试与10个独立财务算例通过，候选两张实图已审查；正式构建和断网17项通过，29次真实下载独立文件SHA已核验，18表与对应CSV回读；源码四命令重建及16资产通过，HTML/runtime精确一致；官网验收待做 |
| P03 预付款核销 | packaged 0.1.0 | 36文件SHA、51测试、10手算；正式断网17组/39下载/16表190格、独立源码四命令与19资产通过；原官网24导航几何和21普通底部标题点击通过，完整工作/下载及公开待验 |
| P04 供应商对账 | specified，唯一线程已创建 | 原应付tool-ap-06；双方期初/增加/付款/期末、关联差异与本地对账单 |
| 其余52款 | planned | 按财务模块分批创建独立线程，名称与工作链见分线程计划 |

## 官网与版本

公开官网八款已发布，commit `6556eadfa1c1d8796a72d0d3f928af2db21268c1` 已实际push；回退标记 `codex/before-R04-R05-native-0.1.0`。原80目录条目和应收模块保留，R04/R05复用原tool-ar-06/tool-ar-08。最终site SHA `223dea35d9c447d8eb575d9c950da04063e6e294c3712b462f109877e1858754`。冻结12版本166文件，已冻结版本禁止重写。

最终归档含本次发布门禁、回归runner、原详情下载核验器；R04/R05独立源码四命令与12/19资产内容核验通过。最终全部版本下载、两款真实本地官网9组/24几何及前六款16项回归均退出0。实际16张图逐一审查；最终归档改变的两图重新观察，其余14图像字节一致。发布门禁ready_for_local_publication=true、errors=[]，不替代公开验收。

实际公开Chrome标签1503154已显示R04八页工作区，虚构31行正余额290、负数-20、零值1，已分档280+未知10=290。完整公开srcdoc去掉精确初始路由注入后SHA与最终site一致，已保存公开截图和完整HTML。公开工作下载等待曾超时导致CUA内核重置；重新读取真实状态确认原R04/R03/R02标签仍在，getTab报告Debugger unattached；原生Chrome返回Mac锁定且自动解锁失败。已请求手动解锁，当前无法继续实际公开操作，不算工具已验失败，也不增加accepted。其余不依赖桌面的工作继续。

Streamlit1.50本地服务session67235，http://127.0.0.1:8515；既有授权健康读取ok，本轮未重启。实际正式离线、本地官网、公开官网分别记录，Windows实机未验证。

## 证据入口

- 当前八款官网：progress/evidence/site-integration/D02-D03-D06-R01-R02-R03-R04-R05/checkpoint.json、gate-checkpoint.json；逐款site-local/result.json及root-visual-review.json。
- 修复R04：progress/evidence/shared/2026-10-03-R04-repaired-handoff-audit.json；旧正式证据保留progress/evidence/R04/history/pre-repaired-formal-browser。
- P02：progress/evidence/shared/2026-10-03-P02-handoff-audit.json、2026-10-03-P02-independent-review.json。
- P01：progress/evidence/shared/2026-10-03-P01-handoff-audit.json、2026-10-03-P01-independent-review.json；正式浏览器result.json。
- R04/R05/P01各款0.1.0/source-rebuild.json及source-rebuild-assets.json。XLSX独立重建仅created/modified时间及ZIP容器元信息可不同，其他每个条目精确一致；不能宣称XLSX字节相等。
- R03公开：progress/evidence/R03/0.1.0/site-public/checkpoint.json；CSV计算302格和来源39格分别核验。
- 唯一线程、turn和cursor：catalog/threads.json；完整业务分线程规划见[分线程开发计划](分线程开发计划.md)，操作入口见[线程调度与接续](线程调度与接续.md)。

R04真实官网验证首次读JSON错误：根验证器错读envelope.inputs，已按实际下载的envelope.work修正，错误与修正SHA保留initial-envelope-access-verifier-failure.json；正式程序无此schema问题。普通点击、无force、文件/整工作比较均已真实重新通过。只有成品、离线、源码及公开官网完整证据通过才accepted。

## 当前十一款暂存与返修

十一款原官网已暂存未发布，P02替换原ap-05，P01/P03位于原应付模块；原管理台/合同台账仍未实现。旧八款页面和门禁保存progress/history/eight-site-before-payables，当前acceptance.json已全部false，不能沿用旧门禁发布。公开八款commit6556ead保持不变。

真实加强导航会话24585退出1：P01采购订单全导航y45.56被77px固定页头部分遮挡，返修排队；P02导航24几何/21底部标题点击通过，但真实320退出按钮部分遮挡，原线程实际inProgress返修（40710004-72f5-401f-b7cd-2e036a3af2f0:6）。P04原线程实际inProgress（64dce1a4-5793-4f12-93f7-75424f041b15:3）；最多两款活动实现，P01待槽位释放后回原线程。P02旧源码证据不覆盖返修新SHA。本地服务器67235本轮实际仍live，未重启。完成数4/64。
