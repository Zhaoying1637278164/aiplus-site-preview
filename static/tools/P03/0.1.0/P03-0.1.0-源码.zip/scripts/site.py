"""Generate the native website workspace from trusted program artifacts."""
from pathlib import Path
import base64, hashlib, html, json, re, shutil, subprocess, sys
from urllib.parse import quote

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT.parent/'aiplus-streamlit'
STAGE=ROOT/'integration/native-site'

# Presentation belongs to the original financial catalogue. Product names and
# versions continue to come exclusively from catalog/tools.json.
PRESENTATION={
    'D02': {'module':'close','label':'结账','template':'close-11','original':'对外报送数据核对',
            'description':'会计明细与业务台账按单据和口径核对，逐项追查差异并留存复核底稿'},
    'D03': {'module':'meta','label':'主数据','template':'meta-02','original':'科目主数据维护',
            'description':'分别核对科目、客商和部门的对应关系，处理冲突并追查原始资料'},
    'D06': {'module':'close','label':'结账','template':'close-11','original':'对外报送数据核对',
            'description':'核查本期财务明细的缺失、重复与金额勾稽，逐项追查异常并留存复核底稿'},
    'R01': {'module':'ar','label':'应收','template':'ar-04','original':'开票登记',
            'description':'合同、开票与回款分别维护，明确部分分配，追查未关联记录与余额并导出底稿'},
    'R02': {'module':'ar','label':'应收','template':'ar-03','original':'收入确认排程表',
            'replace_original':True,
            'description':'按已批准的履约口径排程，核对独立账面收入，保留变更、未完成事项和完整底稿'},
    'R03': {'module':'ar','label':'应收','template':'ar-05','original':'回款对账',
            'replace_original':True,
            'description':'核对应收与银行回款，逐项确认部分分配、撤销与退款，追查未核销余额和完整底稿'},
    'R04': {'module':'ar','label':'应收','template':'ar-06','original':'应收账龄分析表',
            'replace_original':True,
            'description':'分别分析应收账龄与逾期，核对截止余额、客户待办和原始来源，导出完整底稿'},
    'R05': {'module':'ar','label':'应收','template':'ar-08','original':'坏账计提表',
            'replace_original':True,
            'description':'按已批准的组合参数或个别评估测算坏账准备，核对账面变动与计提差异'},
    'P01': {'module':'ap','label':'应付','template':'ap-03','original':'采购合同台账',
            'description':'核对采购订单、收货退货与发票红字，追查数量金额差异、明确分配和来源底稿'},
    'P02': {'module':'ap','label':'应付','template':'ap-05','original':'付款计划表',
            'replace_original':True,
            'description':'按未付余额安排部分付款，核对原到期日、13周排程、账户资金限额和来源底稿'},
    'P03': {'module':'ap','label':'应付','template':'ap-03','original':'采购合同台账',
            'description':'明确预付与结算双端额度，确认部分核销与撤销，追查未核销余额、账龄和来源底稿'},

}

def clean_legacy(source):
    source=re.sub(r'<template id="r-tool-D(?:02|03|06)">.*?</template>', '', source, flags=re.S)
    source=re.sub(r'^\s*var d(?:02|03|06)=document\.createElement\([^\n]+\n', '', source, flags=re.M)
    return source

def native_document(source, entry, files, host_js, fragments=False):
    source=clean_legacy(source)
    assert len(re.findall(r'\bdata-tool\s',source))==76, 'Unexpected original catalogue; inspect before editing'
    identifier=entry['id'];name=html.escape(entry['name']);version=html.escape(entry['version'])
    prefix='app/static/tools/'+identifier+'/'+entry['version']+'/'
    def download(filename,label,classes='btn btn-s btn-sm'):
        asset=ROOT/'release'/entry['id']/entry['version']/filename
        digest=hashlib.sha256(asset.read_bytes()).hexdigest()
        transport=prefix+f'download-{files.index(filename)}.json'
        return f'<a class="{classes}" href="{transport}" data-program-download data-download-sha="{digest}" data-download-bytes="{asset.stat().st_size}" download="{html.escape(filename)}">{html.escape(label)}</a>'
    presentation=PRESENTATION[identifier];module=presentation['module'];label=presentation['label']
    description=presentation['description']
    row=f'''<div class="trow" data-tool data-mod="{module}" data-type="T" data-ai="0" data-q="{name} {description} {label}">
<div class="stack gap8" style="min-width:0"><div class="row gap8" style="flex-wrap:wrap"><a href="#{entry['detailRoute']}" class="rt ink" style="font-size:16px;font-weight:600;margin-right:4px">{name}</a><span class="pill">{label}</span><span class="pill">单点工具</span></div><div style="font-size:14px;color:#3D4250;line-height:1.6">{description}</div></div>
<div class="row gap8"><a href="#{entry['detailRoute']}" class="btn btn-s btn-sm">详情</a><a href="#{entry['workspaceRoute']}" class="btn btn-p btn-sm">在线使用</a></div></div>'''
    marker='<div class="trow" data-tool data-mod="tax"'
    assert marker in source;source=source.replace(marker,row+marker,1)
    source=source.replace('76 个开源工具','77 个工具').replace('76 个工具','77 个工具')
    source=source.replace('data-count="mod:all">76','data-count="mod:all">77').replace('data-total>76','data-total>77')
    source=source.replace('<div class="bignum num">76</div>','<div class="bignum num">77</div>')
    source=re.sub(r'(>)(54)(</span><span style="font-size:15px;font-weight:500">单点工具)',r'\g<1>55\g<3>',source)
    source=re.sub(r'(<a href="#tools-close" class="idx hov">.*?class="num body" style="font-size:15px">)12(</span>)',r'\g<1>13\g<2>',source)
    source=source.replace('data-count="ai:all">76','data-count="ai:all">77').replace('data-count="ai:0">69','data-count="ai:0">70')
    template='r-tool-'+presentation['template']
    original=re.search(r'<template id="'+template+r'">.*?</template>',source,re.S)
    assert original
    detail=original.group().replace(template,'r-'+entry['detailRoute']).replace(presentation['original'],name)
    detail=re.sub(r'<p class="lead">.*?</p>',f'<p class="lead">{description}</p>',detail,flags=re.S)
    detail=detail.replace('<span class="btn is-off" aria-disabled="true">工具包即将上线</span>',f'<a href="#{entry["workspaceRoute"]}" class="btn btn-p">开始账表对账</a>'+download(files[0],'下载离线包','btn btn-s'),1)
    detail=re.sub(r'<a href="https://github\.com/".*?</a>',download(files[1],'下载源码','btn btn-s'),detail,flags=re.S)
    for info_label,value in [('版本',version),('更新日期','2026-10-03'),('文件大小',entry['offlineSize'])]:
        pattern=r'('+info_label+r'</span><span style="text-align:right">)[^<]+(</span>)'
        detail=re.sub(pattern,lambda m:m.group(1)+value+m.group(2),detail)
    detail=re.sub(r'<div class="row"(?:(?!</div>).)*?下载次数.*?</div>','',detail,flags=re.S)
    detail=detail.replace('编辑口径说明和规则配置，重新运行即可生效。','在范围与口径页面设置核对字段和金额容差，再生成差异。').replace('口径说明.md','财务规则.md')
    detail=detail.replace('得到「'+name+'」文件夹，放在任意位置。','得到工具文件夹，打开其中的 index.html。')
    detail=detail.replace('导入「示例数据」文件夹中的文件，查看运行结果。','导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。')
    detail=detail.replace('完整的使用说明、口径说明与示例数据随工具包一并提供。','两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。')
    if identifier=='D03':
        detail=detail.replace('开始账表对账','开始核对对应关系').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资料与字典、对应规则、待办处理、来源追查、版本比较、结果底稿分开操作。科目、客商、部门分别核对，冲突与人工确认保留来源。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','在对应规则页面设置类别、范围与生效期，再核对对应关系。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先在工具内体验虚构示例，再导入资料与字典。')
    if identifier=='D06':
        detail=detail.replace('开始账表对账','开始核查明细').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','资料及核查范围、核查项目维护、异常待办、来源追查、核查结果与底稿分开操作。复核保留经办依据，异常与未执行项目仍保留。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','按本期期间、币种和单位设置核查范围，再维护检查项目及业务依据。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先在工具内体验虚构样例，再导入本机财务明细。')
    if identifier=='R01':
        detail=detail.replace('开始账表对账','开始维护票款台账').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','合同、开票、回款和关联分配分别维护；查看待处理、客户余额、原始来源与独立收入，保存工作并导出完整底稿。预收款单列，未分配记录保留，不自动判断收入。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','在工作总览设置截止日、本期起点、币种、单位和含税口径，再维护票款及显式分配。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构资料，再分别导入合同、开票、回款、关联分配与独立收入资料。')
    if identifier=='R02':
        detail=detail.replace('开始账表对账','开始收入排程').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','合同与履约事项、排程口径、里程碑、已确认收入、月度排程、变更与调整、异常与底稿分开维护。已确认收入取独立账面资料；履约判断与变更由用户批准，不从开票或回款推导。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','设置收入截止日、已批准排程方法、金额精度和差异容差，再生成排程；冻结历史和变更依据保留。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验虚构合同，再分别导入合同、履约事项、里程碑、独立已确认收入及变更资料。')
    if identifier=='R03':
        detail=detail.replace('开始账表对账','开始回款对账').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。','应收单据、银行回款、候选规则、候选与确认、核销与撤销、截止余额与待办、来源与底稿分开维护。只有人工确认且有效的分配影响余额；退款、红字与撤销保留来源和依据。').replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','明确工作起止日、金额精度和候选规则；容差只产生候选，不调平余额。币种、单位和含税口径分别核对，不自动判断收入。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再分别导入应收单据、银行回款和核销记录。')
    if identifier in ['R04','R05']:
        business = ('截止日未结快照与期初推导分别选择；发生账龄、到期逾期、客户待办、例外来源与版本底稿分别操作。负余额和未知项目单列，不自动计提坏账。' if identifier=='R04' else '应收与账面资料、组合与个别评估、批准参数、计提、准备变动、例外复核与版本底稿分别操作。整个存续期损失参数由用户外部评估批准，不按账龄默认计提。')
        detail=detail.replace('开始账表对账','开始账龄与逾期分析' if identifier=='R04' else '开始坏账计提测算').replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。',business).replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','在业务口径页明确截止日、资料范围与已批准参数，再重算；原始资料和版本依据保留。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再按本款模板分别导入本机资料。')
    if identifier in ['P01','P02','P03']:
        starts={'P01':'开始采购三单核对','P02':'开始安排付款计划','P03':'开始预付款核销'}
        business={'P01':'采购订单、收货退货、发票红字、关联分配、核对口径、差异复核与完整底稿分别操作。数量单位换算和价格版本需明确批准，不自动记账或付款。','P02':'应付资料、付款安排、到期排程、账户资金限额、差异复核、版本比较与来源底稿分别操作。原到期日保留，实际已付不再次扣减未付余额，不发起银行付款。','P03':'预付台账、结算资料、人工分配、确认撤销、余额账龄、异常复核与来源底稿分别操作。核销受双端批准额度约束，快照历史不重复扣减，不自动处理退款红字。'}
        detail=detail.replace('开始账表对账',starts[identifier]).replace('两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。',business[identifier]).replace('在范围与口径页面设置核对字段和金额容差，再生成差异。','明确本款业务范围、批准资料和计算口径；金额精度与勾稽容差分别设置，币种单位不转换。').replace('导入虚构左表.csv和虚构右表.csv，或先在工具内体验虚构示例。','先体验完全虚构样例，再按本款模板分别导入本机资料。')
    package_block=r'<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:8px">工具包内容</div>.*?</div>\s*(?=<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:4px">相关工具)'
    labels=['离线工具包','同版本源码','虚构样例（Excel）','空白模板（CSV）','使用说明','财务口径','第三方声明']
    labels.extend(filename.removesuffix('.csv')+'（CSV）' if filename.endswith('.csv') else filename for filename in files[len(labels):])
    links=''.join('<div style="padding:6px 0">'+download(f,label,'tl')+'</div>' for f,label in zip(files,labels))
    replacement='<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:8px">下载与说明</div>'+links+'</div>\n'
    detail,matched=re.subn(package_block,lambda _:replacement,detail,flags=re.S);assert matched==1
    workspace=f'''<template id="r-{entry['workspaceRoute']}"><section class="sec" style="padding:28px 0 72px"><div class="wrap stack gap20"><nav aria-label="面包屑" class="row gap8 small"><a href="#tools">工具库</a><span>/</span><a href="#tools-{module}">{label}</a><span>/</span><a href="#{entry['detailRoute']}">{name}</a></nav><div id="tool-workspace"></div></div></section></template>'''
    registry={k:entry[k] for k in ['id','name','version','detailRoute','workspaceRoute','runtime','sha256','bytes']}
    if fragments:return row,detail+workspace,registry
    registration=json.dumps([registry],ensure_ascii=False).replace('<','\\u003c')
    injection=detail+workspace+'<script>window.__AIPlusRegistry='+registration+';</script><script>'+host_js.replace('</script','<\\/script')+'</script>\n'
    marker='<script>\nwindow.__initTools';assert marker in source;source=source.replace(marker,injection+marker,1)
    old="function go(h){PREV=CUR||'home';CUR=h;render()}"
    new="function go(h){if(h===CUR)return;if(window.__AIPlusHost&&!window.__AIPlusHost.requestExit())return;PREV=CUR||'home';CUR=h;render()}"
    assert old in source;source=source.replace(old,new,1)
    marker="  app.innerHTML='';app.appendChild(t.content.cloneNode(true));"
    assert marker in source;source=source.replace(marker,"  if(window.__AIPlusHost)window.__AIPlusHost.dispose();\n"+marker,1)
    marker='  wireForms();'
    replacement=marker+"\n  if(window.__AIPlusHost&&window.__AIPlusHost.hasRoute(rid)){window.__AIPlusHost.open(rid,document.getElementById('tool-workspace'),function(){go('"+entry['detailRoute']+"')})}"
    assert marker in source;source=source.replace(marker,replacement,1)
    source=source.replace("tool:'tools',course:","tool:'tools',work:'tools',course:",1)
    marker='  hdr.hidden=admin;ftr.hidden=admin;'
    assert marker in source;source=source.replace(marker,marker+"\n  if(bar)bar.hidden=window.__AIPlusHost.hasRoute(rid);",1)
    source=source.replace("var CUR='',PREV='home';","var CUR=window.__AIPlusInitialRoute||'',PREV='home';",1)
    source=source.replace('data-count="mod:close">12','data-count="mod:close">13')
    source=source.replace('window.scrollTo(0,0)',"window.scrollTo({top:0,behavior:'instant'})")
    assert len(re.findall(r'\bdata-tool\s',source))==77
    assert 'link03' not in source and 'link06' not in source and 'link.textContent=\'D02' not in source
    return source

def native_documents(source, entries, file_sets, host_js):
    assert entries and entries[0]['id']=='D02', 'Keep the accepted D02 delivery'
    assert len({e['id'] for e in entries})==len(entries), 'Duplicate program registration'
    result=native_document(source,entries[0],file_sets[0],host_js)
    if len(entries)==1:return result
    registry=[{k:entries[0][k] for k in ['id','name','version','detailRoute','workspaceRoute','runtime','sha256','bytes']}]
    for entry,files in zip(entries[1:],file_sets[1:]):
        row,templates,registration=native_document(source,entry,files,host_js,fragments=True)
        module=PRESENTATION[entry['id']]['module']
        # Add the financial product within its original module; preserve the
        # existing broader platform entries and their implementation status.
        markers={'meta':'<div data-empty hidden','close':'<div class="trow" data-tool data-mod="tax"','ar':'<div class="trow" data-tool data-mod="ap"','ap':'<div class="trow" data-tool data-mod="exp"'}
        assert module in markers, 'Module placement needs review'
        marker=markers[module]
        assert marker in result
        if PRESENTATION[entry['id']].get('replace_original'):
            route='#tool-'+PRESENTATION[entry['id']]['template']
            anchor=result.index('href="'+route+'"')
            start=result.rfind('<div class="trow" data-tool',0,anchor)
            assert start>=0
            depth=0;end=None
            for match in re.finditer(r'<div\b[^>]*>|</div>',result[start:]):
                depth+=-1 if match.group()=='</div>' else 1
                if depth==0:end=start+match.end();break
            assert end is not None
            result=result[:start]+row+result[end:]
            original='r-tool-'+PRESENTATION[entry['id']]['template']
            result,removed=re.subn(r'<template id="'+original+r'">.*?</template>','',result,count=1,flags=re.S)
            assert removed==1
        else:
            result=result.replace(marker,row+marker,1)
        result=result.replace('<script>window.__AIPlusRegistry=',templates+'<script>window.__AIPlusRegistry=',1)
        registry.append(registration)
        if not PRESENTATION[entry['id']].get('replace_original'):
            result=re.sub(r'(data-count="mod:'+module+r'">)(\d+)',lambda m:m[1]+str(int(m[2])+1),result)
            result=re.sub(r'(<a href="#tools-'+module+r'" class="idx hov">.*?class="num body" style="font-size:15px">)(\d+)(</span>)',lambda m:m[1]+str(int(m[2])+1)+m[3],result)
    registration=json.dumps(registry,ensure_ascii=False).replace('<','\\u003c')
    result=re.sub(r'window\.__AIPlusRegistry=\[.*?\];',lambda _: 'window.__AIPlusRegistry='+registration+';',result,count=1)
    extra=sum(not PRESENTATION[e['id']].get('replace_original') for e in entries)-1;total=77+extra
    result=result.replace('77 个工具',str(total)+' 个工具').replace('data-total>77','data-total>'+str(total)).replace('data-count="mod:all">77','data-count="mod:all">'+str(total)).replace('data-count="ai:all">77','data-count="ai:all">'+str(total)).replace('data-count="ai:0">70','data-count="ai:0">'+str(70+extra)).replace('<div class="bignum num">77</div>','<div class="bignum num">'+str(total)+'</div>')
    result=re.sub(r'(>)(55)(</span><span style="font-size:15px;font-weight:500">单点工具)',lambda m:m[1]+str(55+extra)+m[3],result)
    result=result.replace("function(){go('tool-D02')}","function(){var entry=window.__AIPlusRegistry.find(function(e){return e.workspaceRoute===rid});if(entry)go(entry.detailRoute)}",1)
    assert len(re.findall(r'\bdata-tool\s',result))==total
    return result

def stage_selection(tools, include=()):
    assert len(set(include))==len(include), 'Duplicate tool selection'
    accepted=[t['id'] for t in tools if t['status']=='accepted']
    identifiers=list(dict.fromkeys(['D02',*accepted,*include]))
    assert all(i in PRESENTATION for i in identifiers), 'No reviewed website placement for this tool'
    return sorted(identifiers,key=list(PRESENTATION).index)

def stage(include=()):
    tools=json.loads((ROOT/'catalog/tools.json').read_text())
    # Publishing the next tool must preserve every accepted website entry.
    identifiers=stage_selection(tools,include)
    entries=[];file_sets=[];folders=[]
    for identifier in identifiers:
        tool=next(t for t in tools if t['id']==identifier)
        if identifier=='D02':assert tool['name']=='账表对账'
        if identifier=='D03':assert tool['name']=='科目与客商对应关系', 'Formal product registration must precede staging'
        if identifier=='D06':assert tool['name']=='财务明细核查', 'Formal financial name must precede staging'
        if identifier=='R01':assert tool['name']=='合同开票回款台账', 'Formal financial name must precede staging'
        if identifier=='R02':assert tool['name']=='收入确认排程表', 'Use original financial name'
        if identifier=='R03':assert tool['name']=='回款对账', 'Use original financial name'
        version=tool['version'];folder=ROOT/'release'/identifier/str(version)
        runtime=folder/'runtime.json'
        if not runtime.is_file():raise SystemExit(identifier+' 原生版本runtime.json尚未生成；不使用旧独立页面替代，不修改官网。')
        payload=json.loads(runtime.read_text())
        assert payload['id']==identifier and payload['version']==version and payload['name']==tool['name'] and payload['schema_version']==1
        files=[f'{identifier}-{version}-离线包.zip',f'{identifier}-{version}-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md']
        if identifier=='R01':files+=['开票记录模板.csv','回款记录模板.csv','关联与分配模板.csv','独立收入资料模板.csv']
        if identifier=='R02':files+=['履约事项模板.csv','里程碑模板.csv','已确认收入模板.csv','变更与调整模板.csv']
        if identifier=='R03':files+=['银行回款模板.csv','核销记录模板.csv']
        if identifier in ['R04','R05','P01','P02','P03']:
            files += [p.name for p in sorted(folder.iterdir()) if p.is_file() and p.suffix!='.zip' and p.name not in files and p.name not in ['index.html','runtime.json','build-manifest.json']]
        for filename in files:assert (folder/filename).is_file(),filename
        entries.append({'id':identifier,'name':tool['name'],'version':version,'detailRoute':'tool-'+identifier,'workspaceRoute':'work-'+identifier,'runtime':f'app/static/tools/{identifier}/{version}/runtime.json','sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'bytes':runtime.stat().st_size,'offlineSize':f'{(folder/files[0]).stat().st_size/1024/1024:.1f} MB'})
        if PRESENTATION[identifier].get('replace_original'):
            entries[-1]['detailRoute']='tool-'+PRESENTATION[identifier]['template']
            entries[-1]['replacesOriginal']=True
        file_sets.append(files);folders.append(folder)
    subprocess.run(['node','--import','tsx','scripts/build-site-host.ts'],cwd=ROOT,check=True)
    base=(ROOT/'website/base-index.html').read_bytes()
    baseline=json.loads((ROOT/'website/base-manifest.json').read_text())
    assert hashlib.sha256(base).hexdigest()==baseline['sha256'],'Original website base changed without review'
    expected=[baseline['known_external_index_sha256']]
    deployed=ROOT/'website/deployed-site.json'
    if deployed.is_file():expected.append(json.loads(deployed.read_text())['site_sha256'])
    assert hashlib.sha256((SITE/'site/index.html').read_bytes()).hexdigest() in expected,'Website has unrelated changes; merge them before regeneration'
    source=native_documents(base.decode(),entries,file_sets,(ROOT/'integration/native-host.js').read_text())
    (STAGE/'site').mkdir(parents=True,exist_ok=True);(STAGE/'site/index.html').write_text(source)
    (STAGE/'site/registry.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n')
    app=native_streamlit_app((SITE/'app.py').read_text())
    (STAGE/'app.py').write_text(app);(STAGE/'requirements.txt').write_text('streamlit==1.50.0\n')
    (STAGE/'.streamlit').mkdir(exist_ok=True)
    config=(SITE/'.streamlit/config.toml').read_text()
    if '[server]' not in config:config+='\n[server]\nenableStaticServing = true\n'
    elif not re.search(r'\[server\]\s*enableStaticServing\s*=\s*true',config):raise SystemExit('现有server配置需要核验，不能自动覆盖')
    (STAGE/'.streamlit/config.toml').write_text(config)
    for entry,folder,files in zip(entries,folders,file_sets):
        target=STAGE/'static/tools'/entry['id']/entry['version'];target.mkdir(parents=True,exist_ok=True)
        for file in folder.iterdir():
            if file.is_file():shutil.copy2(file,target/file.name)
        for number,filename in enumerate(files):
            payload={'schema_version':1,'filename':filename,'base64':base64.b64encode((folder/filename).read_bytes()).decode('ascii')}
            (target/f'download-{number}.json').write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':'))+'\n')
    print('原生官网已暂存；尚未发布：',STAGE)

def native_streamlit_app(app,index='site/index.html',registry='site/registry.json'):
    anchor='ROOT = Path(__file__).parent';assert anchor in app
    generated=app[:app.index(anchor)]+'''ROOT = Path(__file__).parent
import json
REGISTRY = json.loads((ROOT / "REGISTRY_PATH").read_text(encoding="utf-8"))
TOOLS = {r["id"]: r for r in REGISTRY}
selected = st.query_params.get("tool", "")
entry = TOOLS.get(selected)
document = (ROOT / "INDEX_PATH").read_text(encoding="utf-8")
if entry:
    initial = json.dumps(entry["workspaceRoute"]).replace("<", "\\\\u003c")
    document = document.replace("<script>window.__AIPlusRegistry", "<script>window.__AIPlusInitialRoute=" + initial + ";</script><script>window.__AIPlusRegistry", 1)
elif selected:
    st.info("该工具尚未开放，请从工具库选择已交付的工具。")
components.html(document, height=900, scrolling=True)
'''
    return generated.replace('REGISTRY_PATH',registry).replace('INDEX_PATH',index)

def apply():
    registry=json.loads((STAGE/'site/registry.json').read_text())
    checker='check-d02-evidence.py' if [e['id'] for e in registry]==['D02'] else 'check-native-evidence.py'
    subprocess.run([sys.executable,str(ROOT/'scripts'/checker)],cwd=ROOT,check=True)
    gate=STAGE/'acceptance.json'
    if not gate.is_file():raise SystemExit('缺少原生官网暂存验收证据，不发布。')
    evidence=json.loads(gate.read_text())
    required=['local_site_navigation','finance_same_results','downloads_hashes','offline','source_rebuild','rendered_product_ui']
    assert all(evidence.get(k) is True for k in required),'Incomplete delivery evidence'
    assert evidence['site_sha256']==hashlib.sha256((STAGE/'site/index.html').read_bytes()).hexdigest(),'Stale website evidence'
    for relative in ['app.py','requirements.txt','site/index.html','site/registry.json','.streamlit/config.toml']:
        target=SITE/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(STAGE/relative,target)
    shutil.copytree(STAGE/'static/tools',SITE/'static/tools',dirs_exist_ok=True)
    (ROOT/'website/deployed-site.json').write_text(json.dumps({'site_sha256':evidence['site_sha256'],'registry_sha256':hashlib.sha256((STAGE/'site/registry.json').read_bytes()).hexdigest()},indent=2)+'\n')
    print('已同步原生官网；须实际公开浏览器验证后才能accepted。')

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'stage'
    if mode=='stage':stage(sys.argv[2:])
    elif mode=='apply':apply()
    else:raise SystemExit('仅支持stage/apply')
