import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';
import type {SourceRow} from '../../../packages/core/types';
import {ids,scope,type Work,type Kind,type Issue,type Balance,type Allocation,type Result} from './types';
export const source=(r:SourceRow)=>`${r.file} / ${r.sheet} / 第${r.row}行`;
export function calculate(w:Work):Result {
 const out:Result={prepayments:[],settlements:[],allocations:[],issues:[],groups:[]};
 const issue=(kind:Kind|'config',r:SourceRow|undefined,id:string,message:string,blocking=true)=>{const s=r?source(r):'参数';out.issues.push({key:JSON.stringify([kind,s,id,message]),kind,source:s,id,message,blocking})};
 let configOK=true;
 try{date(w.config.asof);if(!['history','snapshot'].includes(w.config.mode))throw Error('基线模式无效');if(!Number.isInteger(w.config.precision)||w.config.precision<0||w.config.precision>6)throw Error('精度必须0至6');if(amount(w.config.tolerance).lt(0))throw Error('容差不得负数');if(w.config.mode==='snapshot'&&date(w.config.snapshotDate)>w.config.asof)throw Error('截止日不能早于快照日');}catch(e){configOK=false;issue('config',undefined,'',String((e as Error).message))}
 const blocked=new Set<string>(),adj=new Map<string,Set<string>>(),node=(k:Kind,id:string)=>k+':'+id;
 const link=(p:string,s:string)=>{if(!adj.has(p))adj.set(p,new Set());if(!adj.has(s))adj.set(s,new Set());adj.get(p)!.add(s);adj.get(s)!.add(p)};
 const counts:Record<Kind,Map<string,number>>={prepayments:new Map(),settlements:new Map(),allocations:new Map(),refunds:new Map()};
 const get=(r:SourceRow,h:string)=>text(r.cells[h]??null);
 const cash=(r:SourceRow,h='金额')=>{const d=amount(r.cells[h]??null);if(d.decimalPlaces()>w.config.precision)throw Error('金额超过所选精度');if(d.isZero())throw Error('零金额不可占额度');if(d.isNegative())throw Error('负金额隔离，不净入正金额');return d};
 for(const k of Object.keys(w.data) as Kind[])for(const r of w.data[k]){const id=typeof r.cells[ids[k]]==='string'||typeof r.cells[ids[k]]==='number'?String(r.cells[ids[k]]):'';counts[k].set(id,(counts[k].get(id)||0)+1)}
 type Parsed={r:SourceRow;b:Balance;d:Decimal|null;dt:string|null};
 const maps={prepayments:new Map<string,Parsed>(),settlements:new Map<string,Parsed>()};
 for(const k of ['prepayments','settlements'] as const)for(const r of w.data[k]){
  let id='',sc='',d:Decimal|null=null,dt:string|null=null,age:number|null=null,overdue:number|null=null,state='可用';
  const errors:string[]=[];const check=(fn:()=>void)=>{try{fn()}catch(e){errors.push((e as Error).message)}};const parse=<T,>(fn:()=>T):T|null=>{try{return fn()}catch(e){errors.push((e as Error).message);return null}};
  check(()=>{id=get(r,ids[k])});const values:string[]=[];for(const h of scope)check(()=>{values.push(get(r,h))});sc=values.length===scope.length?JSON.stringify(values):'';
  check(()=>{get(r,'批准依据')});d=parse(()=>cash(r));dt=parse(()=>date(r.cells['业务日']));
  if(k==='prepayments'&&dt&&configOK){age=dt<=w.config.asof?Math.round((Date.parse(w.config.asof)-Date.parse(dt))/86400000):null;}
  if(k==='prepayments'&&r.cells['预计结算日']!==null&&r.cells['预计结算日']!==undefined&&r.cells['预计结算日']!=='')check(()=>{const due=date(r.cells['预计结算日']);overdue=configOK?Math.max(0,Math.round((Date.parse(w.config.asof)-Date.parse(due))/86400000)):null});
  if(dt&&dt>w.config.asof)state='未来来源';if(w.config.mode==='snapshot'&&dt&&dt>w.config.snapshotDate)errors.push('快照资料业务日须不晚于基线日；新增预付请改完整历史模式');
  if(errors.length){state='阻塞';for(const message of [...new Set(errors)])issue(k,r,id,message)}
  if((counts[k].get(id)||0)>1){state='阻塞';issue(k,r,id,'重复ID全组阻塞（含无效行）')}
  if(state==='阻塞'||!configOK)blocked.add(node(k,id));
  const b:Balance={id,scope:sc,source:source(r),original:d?.toFixed()??null,used:null,remaining:null,age,overdue,state};out[k].push(b);if(id&&!maps[k].has(id))maps[k].set(id,{r,b,d,dt});
 }
 const candidates:{a:Allocation;r:SourceRow;d:Decimal;p:string;s:string}[]=[];
 for(const r of w.data.allocations){let id='',p='',s='',d:Decimal|null=null,state='阻塞',active=false;
  try{id=get(r,'分配ID');p=get(r,'预付ID');s=get(r,'结算ID');d=cash(r);const dt=date(r.cells['业务日']);const status=get(r,'状态');get(r,'批准依据');if(!['草稿','已确认','撤销'].includes(status))throw Error('状态须草稿、已确认或撤销');const rev=status==='撤销'?date(r.cells['撤销日']):null;if(rev){get(r,'撤销依据');if(rev<dt)throw Error('撤销日不能早于确认日')}else if(r.cells['撤销日']||r.cells['撤销依据'])throw Error('非撤销状态不得带撤销字段');
   const pr=maps.prepayments.get(p),sr=maps.settlements.get(s);if(!pr||!sr)throw Error('缺少两端来源ID');if(pr.b.scope!==sr.b.scope)throw Error('主体供应商合同币种单位税口径不同，禁止关联');if(!pr.dt||!sr.dt||dt<pr.dt||dt<sr.dt)throw Error('核销日期早于来源或来源日期未知');
   if((counts.allocations.get(id)||0)>1)throw Error('重复分配ID全组阻塞');
   if(dt>w.config.asof){state='未来核销';}else if(w.config.mode==='snapshot'&&dt<=w.config.snapshotDate){if(rev&&rev>w.config.snapshotDate&&rev<=w.config.asof)throw Error('快照前核销在快照后撤销，须修订批准快照余额');state='快照前历史（不再扣）'}else if(status==='草稿'){state='草稿（未占用）'}else if(rev&&rev<=w.config.asof){state='已撤销'}else {state=rev?'截止时有效（后期撤销）':'有效确认';active=true;}
  }catch(e){issue('allocations',r,id,(e as Error).message);blocked.add(node('prepayments',p));blocked.add(node('settlements',s));}
  // Invalid connected rows must not leave an apparently valid partial balance.
  if(p&&s)link(node('prepayments',p),node('settlements',s));
  const a:Allocation={id,prepayment:p,settlement:s,amount:d?.toFixed()??null,state,source:source(r),effective:false};out.allocations.push(a);if(active&&d)candidates.push({a,r,d,p,s});
 }
 for(const c of w.conflicts){issue(c.kind,c.candidates[0],c.id,'同ID版本冲突，必须明确选取');if(c.kind==='prepayments'||c.kind==='settlements')blocked.add(node(c.kind,c.id));else for(const r of c.candidates){if(c.kind==='allocations'){const p=String(r.cells['预付ID']??''),s=String(r.cells['结算ID']??'');blocked.add(node('prepayments',p));blocked.add(node('settlements',s));link(node('prepayments',p),node('settlements',s))}else blocked.add(node('prepayments',String(r.cells['预付ID']??'')))}}
 for(const r of w.data.refunds){const id=String(r.cells['退款ID']??'');issue('refunds',r,id,'退款/红字自动处理未实现，隔离并阻塞关联预付；需批准修订资料');blocked.add(node('prepayments',String(r.cells['预付ID']??'')))}
 const sums=new Map<string,Decimal>();for(const c of candidates)for(const n of [node('prepayments',c.p),node('settlements',c.s)])sums.set(n,(sums.get(n)||new Decimal(0)).add(c.d));
 for(const k of ['prepayments','settlements'] as const)for(const [id,r] of maps[k]){const n=node(k,id);if(r.d&&(sums.get(n)||new Decimal(0)).gt(r.d)){blocked.add(n);issue(k,r.r,id,'累计确认超双端额度，整个关联组阻塞') }}
 const queue=[...blocked];for(let i=0;i<queue.length;i++)for(const n of adj.get(queue[i])||[])if(!blocked.has(n)){blocked.add(n);queue.push(n)}
 for(const c of candidates){c.a.effective=configOK&&!blocked.has(node('prepayments',c.p))&&!blocked.has(node('settlements',c.s));if(!c.a.effective)c.a.state='关联组阻塞（不输出合法余额）'}
 for(const k of ['prepayments','settlements'] as const)for(const b of out[k]){const n=node(k,b.id);if(blocked.has(n)){b.state='阻塞';}else if(b.state==='未来来源'){b.used='0';b.remaining=null;}else if(b.original!==null){b.used=(sums.get(n)||new Decimal(0)).toFixed();b.remaining=new Decimal(b.original).sub(b.used).toFixed()}}
 const groups=new Map<string,typeof out.prepayments>();for(const b of out.prepayments)if(b.state!=='未来来源'){const a=groups.get(b.scope)||[];a.push(b);groups.set(b.scope,a)}
 for(const [sc,bs] of groups){const valid=bs.every(b=>b.remaining!==null),sum=(f:'original'|'used'|'remaining')=>bs.reduce((n,b)=>n.add(b[f]||0),new Decimal(0));const principal=sum('original'),used=sum('used'),remaining=sum('remaining'),residual=principal.sub(used).sub(remaining);out.groups.push({scope:sc,principal:valid?principal.toFixed():'未知',used:valid?used.toFixed():'未知',remaining:valid?remaining.toFixed():'未知',residual:valid?residual.toFixed():'未知',status:valid?(residual.abs().lte(amount(w.config.tolerance))?'守恒':'差异'):'阻塞（不能汇总）'})}
 return out;
}
