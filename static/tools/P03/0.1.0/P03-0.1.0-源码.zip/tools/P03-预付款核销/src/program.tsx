import React from 'react';
import {createRoot} from 'react-dom/client';
import type {ToolProgram} from '../../../packages/ui/tool-host';
import {App,type Bridge} from './App';
import {VERSION} from './version';
export const program:ToolProgram={id:'P03',name:'预付款核销',version:VERSION,mount({container,onExit}){const root=createRoot(container),bridge:Bridge={dirty:false,clear:()=>{}};let disposed=false;root.render(<App bridge={bridge} onExit={onExit}/>);return {requestExit(){if(disposed)return true;const ok=!bridge.dirty||window.confirm('退出将清空所有未下载资料，是否确认？');if(ok)bridge.clear();return ok},dispose(){if(disposed)return;bridge.clear();root.unmount();container.replaceChildren();bridge.clear=()=>{};bridge.dirty=false;disposed=true}}}};
