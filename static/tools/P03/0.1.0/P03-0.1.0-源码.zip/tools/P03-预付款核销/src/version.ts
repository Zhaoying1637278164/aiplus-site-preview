export const VERSION='0.1.0';
export const RULE_VERSION='P03-2026-10-03.1';
