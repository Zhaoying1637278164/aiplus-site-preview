import {emptyWork} from './work';
import {headers,type Kind,type Work} from './types';
import type {SourceRow,Table} from '../../../packages/core/types';
const sc={主体ID:'001',供应商ID:'0001',合同ID:'001',币种:'CNY',金额单位:'元',含税口径:'含税',供应商名称:'虚构供应商甲',批准依据:'虚构批准单001'};
export function example():Work{const w=emptyWork();w.data.prepayments=[row('prepayments',{...sc,预付ID:'P001',业务日:'2026-01-01',金额:'100',预计结算日:'2026-06-30'})];w.data.settlements=[row('settlements',{...sc,结算ID:'S001',业务日:'2026-02-01',金额:'80',票面金额:'88'})];w.data.allocations=[row('allocations',{分配ID:'A001',预付ID:'P001',结算ID:'S001',金额:'60',业务日:'2026-03-01',状态:'已确认',批准依据:'虚构核销批准001'})];return w}
export function row(k:Kind,c:Record<string,string>,n=2):SourceRow{return {file:'完全虚构样例.xlsx',sheet:k,row:n,cells:Object.fromEntries(headers[k].map(h=>[h,c[h]??null]))}}
export function table(k:Kind,rows:SourceRow[]):Table{return {file:rows[0]?.file||'模板.csv',sheet:rows[0]?.sheet||k,headers:headers[k],rows}}
export function longExample(){const w=emptyWork();for(let i=1;i<=35;i++){w.data.prepayments.push(row('prepayments',{...sc,预付ID:`P${String(i).padStart(3,'0')}`,业务日:'2026-01-01',金额:'100',预计结算日:'2026-06-30'},i+1));w.data.settlements.push(row('settlements',{...sc,结算ID:`S${String(i).padStart(3,'0')}`,业务日:'2026-02-01',金额:'80'},i+1))}return w}
