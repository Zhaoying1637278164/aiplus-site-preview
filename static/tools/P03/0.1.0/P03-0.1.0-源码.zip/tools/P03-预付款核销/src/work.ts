import type {Cell,SourceRow,Table} from '../../../packages/core/types';
import {LIMITS} from '../../../packages/core/types';
import {calculate} from './engine';
import {defaultConfig,headers,ids,labels,type Kind,type Work,type Config} from './types';
import {VERSION,RULE_VERSION} from './version';
export const emptyWork=(config:Config={...defaultConfig}):Work=>({config:{...config},data:{prepayments:[],settlements:[],allocations:[],refunds:[]},conflicts:[],events:[],reviews:{},version:0,baseline:null});
const copy=<T,>(x:T):T=>JSON.parse(JSON.stringify(x));
export function guardWork(w:Work){
 if(!Object.values(w.data).every(a=>a.every(validRow)))throw Error('原行结构、列数或单元格超限，公式/对象禁止导入');
 if(Object.values(w.data).reduce((n,a)=>n+a.length,0)>LIMITS.rows)throw Error('工作总行数超过20000');
 if(w.events.length>2000||w.conflicts.length>2000)throw Error('事件或冲突超过2000，请分批处理');
 if(new TextEncoder().encode(JSON.stringify(w)).length>LIMITS.bytes)throw Error('工作超过10MB限制，请分批处理');
}
export function change(w:Work,action:string,basis:string,fn:(n:Work)=>void):Work{
 if(!basis.trim())throw Error('必须填写操作依据');const n=copy(w);n.baseline=calculate(w);n.reviews={};n.version++;fn(n);n.events.push({id:`E${n.version}-${n.events.length+1}`,at:new Date().toISOString(),action,basis,before:{version:w.version,config:w.config,data:w.data,conflicts:w.conflicts},after:{version:n.version,config:n.config}});guardWork(n);return n;
}
const signature=(r:SourceRow)=>JSON.stringify([Object.entries(r.cells).sort(([a],[b])=>a.localeCompare(b)),Object.entries((r as any).originalCells??r.cells).sort(([a],[b])=>a.localeCompare(b))]);
export function mappedTable(t:Table,kind:Kind,mapping:Record<string,string>):Table{const used=Object.values(mapping).filter(Boolean);if(new Set(used).size!==used.length)throw Error('一个来源列不能映射多个字段');const rows=t.rows.map(r=>({...r,originalCells:copy(r.cells),cells:{...r.cells,...Object.fromEntries(headers[kind].map(h=>[h,mapping[h]?r.cells[mapping[h]]??null:null]))}}));if(!rows.every(validRow))throw Error('公式/对象禁止导入或列/单元格超限');return {...t,headers:headers[kind],rows}}
export function importTable(w:Work,kind:Kind,t:Table,basis:string,replace=false):Work{
 if(!t.rows.every(validRow))throw Error('导入原行无效、列/文本超限或含公式对象');
 const required=headers[kind].filter(h=>!['供应商名称','预计结算日','票面金额','撤销日','撤销依据'].includes(h));
 if(required.some(h=>!t.headers.includes(h)))throw Error('缺少模板必需字段：'+required.filter(h=>!t.headers.includes(h)).join('、'));
 return change(w,`导入${labels[kind]}${replace?'替换':'合并'}`,basis,n=>{
  if(replace){n.data[kind]=copy(t.rows);n.conflicts=n.conflicts.filter(c=>c.kind!==kind);return}
  const incomingGroups=new Map<string,SourceRow[]>(),existingGroups=new Map<string,SourceRow[]>();for(const r of t.rows){const id=String(r.cells[ids[kind]]??'');const a=incomingGroups.get(id)||[];a.push(r);incomingGroups.set(id,a)}for(const r of n.data[kind]){const id=String(r.cells[ids[kind]]??'');const a=existingGroups.get(id)||[];a.push(r);existingGroups.set(id,a)}
  for(const [id,rows] of incomingGroups){const count=rows.length,old=existingGroups.get(id)||[];
   if(count>1){n.data[kind].push(...copy(rows));continue}
   const incoming=rows[0],conf=n.conflicts.find(c=>c.kind===kind&&c.id===id);
   if(conf){if(!conf.candidates.some(r=>signature(r)===signature(incoming)))conf.candidates.push(copy(incoming));continue}
   if(!old.length){n.data[kind].push(copy(incoming));continue}
   if(old.length===1&&signature(old[0])===signature(incoming))continue;
   n.conflicts.push({key:JSON.stringify([kind,id]),kind,id,candidates:copy([...old,incoming])});
  }
 });
}
export function selectConflict(w:Work,key:string,index:number,basis:string){return change(w,'选择冲突版本',basis,n=>{const c=n.conflicts.find(c=>c.key===key);if(!c||!c.candidates[index])throw Error('冲突版本不存在');n.data[c.kind]=n.data[c.kind].filter(r=>String(r.cells[ids[c.kind]]??'')!==c.id);n.data[c.kind].push(copy(c.candidates[index]));n.conflicts=n.conflicts.filter(x=>x.key!==key)})}
export function revise(w:Work,kind:Kind,index:number,cells:Record<string,Cell>,basis:string){return change(w,'修订原行',basis,n=>{const r=n.data[kind][index];if(!r)throw Error('原行不存在');if(kind==='allocations'&&r.cells['状态']!=='草稿')throw Error('历史确认只允许撤销；变更请通过冲突版本明确处理');n.data[kind][index]={...r,cells:{...cells}}})}
export function addDraft(w:Work,cells:Record<string,Cell>,basis:string){return change(w,'新增草稿',basis,n=>{n.data.allocations.push({file:'人工分配',sheet:'核销记录',row:n.version+1,cells:{...cells,状态:'草稿',批准依据:basis,撤销日:null,撤销依据:null}})})}
export function confirmAllocation(w:Work,index:number,basis:string){
 const n=change(w,'确认核销（非入账）',basis,n=>{const r=n.data.allocations[index];if(!r||r.cells['状态']!=='草稿')throw Error('只能确认草稿');r.cells['状态']='已确认';r.cells['批准依据']=basis});
 const r=calculate(n),a=r.allocations[index];if(!a||!a.effective)throw Error('确认阻塞：'+(r.issues.find(i=>i.kind==='allocations'&&i.id===a?.id)?.message||a?.state||'两端来源异常'));return n;
}
export function revoke(w:Work,index:number,day:string,basis:string){return change(w,'撤销核销（保留历史）',basis,n=>{const r=n.data.allocations[index];if(!r||r.cells['状态']!=='已确认')throw Error('只能撤销已确认记录');r.cells['状态']='撤销';r.cells['撤销日']=day;r.cells['撤销依据']=basis;const result=calculate(n);if(result.issues.some(i=>i.kind==='allocations'&&i.id===String(r.cells['分配ID'])))throw Error('撤销日期或关联无效，请先修订资料')})}
export function review(w:Work,key:string,basis:string):Work{if(!basis.trim())throw Error('复核依据不能为空');const n=copy(w);n.reviews[key]={basis,version:w.version};guardWork(n);return n}
export function encode(w:Work,includeData:boolean){guardWork(w);const x={schema_version:1,tool:'P03',app_version:VERSION,rule_version:RULE_VERSION,includes_data:includeData,config:w.config,...(includeData?{work:w}:{})};const json=JSON.stringify(x,null,2);if(new TextEncoder().encode(json).length>LIMITS.bytes)throw Error('下载超过10MB');return json}
function validCells(c:any){return c&&typeof c==='object'&&!Array.isArray(c)&&Object.keys(c).length<=200&&Object.entries(c).every(([k,v])=>k.length<=10000&&(v===null||typeof v==='number'&&Number.isFinite(v)||typeof v==='string'&&v.length<=10000))}
function validRow(r:any):r is SourceRow{return r&&typeof r.file==='string'&&typeof r.sheet==='string'&&Number.isInteger(r.row)&&r.row>0&&validCells(r.cells)&&(!('originalCells'in r)||validCells(r.originalCells))}
export function decode(json:string):Work{
 if(new TextEncoder().encode(json).length>LIMITS.bytes)throw Error('方案超过10MB');const x=JSON.parse(json);if(x.schema_version!==1||x.tool!=='P03'||x.app_version!==VERSION||x.rule_version!==RULE_VERSION||typeof x.includes_data!=='boolean')throw Error('方案版本不兼容');
 const c=x.config;if(!c||Object.keys(c).sort().join(',')!=='asof,mode,precision,snapshotDate,tolerance'||calculate(emptyWork(c)).issues.length)throw Error('方案配置无效');
 if(!x.includes_data){if(Object.keys(x).some(k=>!['schema_version','tool','app_version','rule_version','includes_data','config'].includes(k)))throw Error('无数据配置包含额外业务资料');return emptyWork(c)}
 const w=x.work;if(!w||JSON.stringify(w.config)!==JSON.stringify(c)||!Number.isInteger(w.version)||w.version<0||!w.data||Object.keys(w.data).sort().join(',')!=='allocations,prepayments,refunds,settlements'||!Object.values(w.data).every(a=>Array.isArray(a)&&a.every(validRow))||!Array.isArray(w.events)||!w.events.every((e:any)=>e&&typeof e.id==='string'&&typeof e.action==='string'&&typeof e.basis==='string'&&typeof e.at==='string')||!Array.isArray(w.conflicts)||!w.conflicts.every((f:any)=>f&&['prepayments','settlements','allocations','refunds'].includes(f.kind)&&typeof f.key==='string'&&typeof f.id==='string'&&Array.isArray(f.candidates)&&f.candidates.every(validRow))||!w.reviews||typeof w.reviews!=='object'||!Object.values(w.reviews).every((r:any)=>r&&typeof r.basis==='string'&&Number.isInteger(r.version)))throw Error('工作资料结构无效（公式或对象单元格不允许）');
 if(w.baseline!==null&&(!w.baseline||!['prepayments','settlements','allocations','issues','groups'].every(k=>Array.isArray(w.baseline[k])&&w.baseline[k].every((b:any)=>b&&typeof b==='object'))))throw Error('比较基线结构无效');
 guardWork(w);calculate(w);return copy(w);
}
