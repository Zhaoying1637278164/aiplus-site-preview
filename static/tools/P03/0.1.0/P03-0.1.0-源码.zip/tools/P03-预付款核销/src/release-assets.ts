import {workbookBytes} from '../../../packages/core/io';
import {headers,labels,type Kind} from './types';
import {example,longExample} from './example';
import {encode} from './work';
import {csv} from './export';
export async function releaseAssets(){const w=example();const assets=(Object.keys(headers) as Kind[]).flatMap(k=>[{filename:k==='prepayments'?'空白模板.csv':labels[k]+'模板.csv',data:csv(headers[k],[])},{filename:'虚构'+labels[k]+'.csv',data:csv(headers[k],w.data[k].map(r=>headers[k].map(h=>r.cells[h])))}]);return [...assets,{filename:'虚构样例.xlsx',data:await workbookBytes((['prepayments','settlements','allocations'] as const).map(k=>({name:labels[k],headers:headers[k],rows:w.data[k].map(r=>headers[k].map(h=>r.cells[h]))})))},{filename:'虚构35行.xlsx',data:await workbookBytes((['prepayments','settlements'] as const).map(k=>({name:labels[k],headers:headers[k],rows:longExample().data[k].map(r=>headers[k].map(h=>r.cells[h]))})))},{filename:'虚构含数据工作.json',data:encode(w,true)},{filename:'无数据方案.json',data:encode(w,false)}]}
