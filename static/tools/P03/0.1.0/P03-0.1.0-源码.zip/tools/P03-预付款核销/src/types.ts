import type {SourceRow} from '../../../packages/core/types';
export type Kind='prepayments'|'settlements'|'allocations'|'refunds';
export const labels:Record<Kind,string>={prepayments:'预付台账',settlements:'结算资料',allocations:'核销记录',refunds:'退款红字'};
export const scope=['主体ID','供应商ID','合同ID','币种','金额单位','含税口径'];
export const headers:Record<Kind,string[]>={prepayments:['预付ID',...scope,'供应商名称','业务日','金额','预计结算日','批准依据'],settlements:['结算ID',...scope,'供应商名称','业务日','金额','票面金额','批准依据'],allocations:['分配ID','预付ID','结算ID','金额','业务日','状态','批准依据','撤销日','撤销依据'],refunds:['退款ID','预付ID','金额','业务日','批准依据']};
export const ids:Record<Kind,string>={prepayments:'预付ID',settlements:'结算ID',allocations:'分配ID',refunds:'退款ID'};
export interface Config {asof:string;mode:'history'|'snapshot';snapshotDate:string;precision:number;tolerance:string}
export interface Issue {key:string;kind:Kind|'config';source:string;id:string;message:string;blocking:boolean}
export interface Balance {id:string;scope:string;source:string;original:string|null;used:string|null;remaining:string|null;age:number|null;overdue:number|null;state:string}
export interface Allocation {id:string;prepayment:string;settlement:string;amount:string|null;state:string;source:string;effective:boolean}
export interface Result {prepayments:Balance[];settlements:Balance[];allocations:Allocation[];issues:Issue[];groups:{scope:string;principal:string;used:string;remaining:string;residual:string;status:string}[]}
export interface Conflict {key:string;kind:Kind;id:string;candidates:SourceRow[]}
export interface Event {id:string;at:string;action:string;basis:string;before:unknown;after:unknown}
export interface Work {config:Config;data:Record<Kind,SourceRow[]>;conflicts:Conflict[];events:Event[];reviews:Record<string,{basis:string;version:number}>;version:number;baseline:Result|null}
export const defaultConfig:Config={asof:'2026-09-30',mode:'history',snapshotDate:'2026-09-01',precision:2,tolerance:'0.00'};
