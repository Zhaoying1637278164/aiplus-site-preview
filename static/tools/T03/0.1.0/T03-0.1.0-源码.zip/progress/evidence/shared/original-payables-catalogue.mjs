// Root actual catalogue readback. Physical buttons may repeat the same file.
import {chromium} from 'playwright';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const suite='progress/evidence/site-integration/D02-D03-D06-R01-R02-R03-R04-R05-P01-P02-P03';
const sha=createHash('sha256').update(await readFile('integration/native-site/site/index.html')).digest('hex');
const browser=await chromium.launch({headless:true,executablePath:'/Users/xiaoying/Library/Caches/ms-playwright/chromium-1234/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'});
try {
 const ctx=await browser.newContext({viewport:{width:1440,height:1000}}),p=await ctx.newPage(),programs=[];
 p.on('request',r=>{if(r.url().endsWith('runtime.json'))programs.push(r.url())});
 await p.goto('http://127.0.0.1:8515/');const f=p.frameLocator('iframe').first();
 await f.locator('.bignum').waitFor();assert.equal(await f.locator('.bignum').innerText(),'82');
 await f.locator('.nav a[href="#tools"]').click();await f.locator('[data-f="mod"][data-v="ap"]').click();
 assert.equal(await f.locator('[data-total]').innerText(),'9');const rows=f.locator('[data-tool][data-mod="ap"]');assert.equal(await rows.count(),9);
 for(const name of ['应付管理台','应付分析看板','采购合同台账','应付账龄表','供应商对账','合同到期提醒']){
  const r=rows.filter({has:f.getByRole('link',{name,exact:true})});assert.equal(await r.count(),1);assert.equal(await r.getByText('即将上线',{exact:true}).count(),1);
 }
 await p.screenshot({path:suite+'/original-ap-module.png'});
 const downloads={};
 for(const [id,name] of [['P01','采购三单核对'],['P02','付款计划表'],['P03','预付款核销']]){
  const r=f.locator('[data-tool][data-mod="ap"]').filter({has:f.getByRole('link',{name,exact:true})});
  assert.equal(await r.count(),1);assert.equal(await r.locator('a[href="#work-'+id+'"]').count(),1);
  await r.getByRole('link',{name:'详情',exact:true}).click();await f.getByRole('heading',{name,exact:true}).waitFor();
  downloads[id]=await f.locator('[data-program-download]').evaluateAll(nodes=>[...new Set(nodes.map(n=>n.getAttribute('download')))]);
  assert.equal(downloads[id].length,{P01:17,P02:15,P03:18}[id]);
  assert.equal(await f.locator('a[href="#work-'+id+'"]').count(),1);
  await f.locator('.nav a[href="#tools"]').click();await f.locator('[data-f="mod"][data-v="ap"]').click();
 }
 assert.deepEqual(programs,[]);
 await writeFile(suite+'/original-ap-module.json',JSON.stringify({site_sha256:sha,passed:true,total:82,ap_total:9,original_unimplemented:6,current_tools:['P01','P02','P03'],downloads,checks:['original82 catalogue','original AP9 includes6 preserved unimplemented rows and3 delivered finance tools','P02 reuses tool-ap-05','same-site financial detail and17/15/18 unique downloads','module/detail never loads program'],programs},null,2)+'\n');
 console.log('actual original AP module/detail five groups passed');await ctx.close();
} finally {await browser.close()}
