import {schemas,empty,type Data,type Side,defaultRule} from './engine';
import type {Table} from '../../../packages/core/types';
export function table(side:Side,rows:unknown[][]):Table{return {file:'完全虚构资料.xlsx',sheet:side,headers:schemas[side],rows:rows.map((r,i)=>({file:'完全虚构资料.xlsx',sheet:side,row:i+2,cells:Object.fromEntries(schemas[side].map((h,k)=>[h,(r[k]??null) as any]))}))}}
export function example():Data{const dims=['虚构甲公司','2026-09','CNY','元'];return {...empty(),accounts:table('accounts',[
 [...dims,'BANK-A','现金','是','可随时支付的虚构银行账户','1000','1550','0'],[...dims,'BANK-B','现金','是','可随时支付的虚构银行账户','200','650','0'],[...dims,'LOCKED','排除','否','虚构冻结保证金，不随时支付','300','300','0']
 ]),tx:table('tx',[
 [...dims,'T01','2026-09-01','BANK-A','流入','1200','销售回款','O01','虚构回款凭据',null,null,'客户回款'],[...dims,'T02','2026-09-02','BANK-A','流出','500','采购','O04','虚构采购付款凭据',null,null,'采购'],[...dims,'T03','2026-09-03','BANK-A','流出','150','工资','O05','虚构工资凭据',null,null,'工资'],[...dims,'T04','2026-09-04','BANK-A','流出','200','设备','I06','虚构购置凭据',null,null,'设备'],[...dims,'T05','2026-09-05','BANK-A','流入','400','借款','F02','虚构借款凭据',null,null,'借款'],[...dims,'T06','2026-09-06','BANK-A','流出','200','还本','F04','虚构还本凭据',null,null,'还本'],
 [...dims,'T07','2026-09-07','BANK-B','流入','250','内部划转',null,'虚构划转回单','TR01','BANK-A','划转入'],[...dims,'T08','2026-09-07','BANK-A','流出','250','内部划转',null,'虚构划转回单','TR01','BANK-B','划转出'],[...dims,'T09','2026-09-08','BANK-B','流入','200','销售回款','O01','虚构回款凭据',null,null,'回款']
 ]),adjustments:table('adjustments',[[...dims,'A01','重分类','BANK-A','流出','20','O04','O07','T02','虚构复核：采购含管理服务费'],[...dims,'A02','补录','BANK-A','流入','250',null,'O03',null,'虚构漏列银行退款回单']]),noncash:table('noncash',[[...dims,'N01','虚构租赁取得设备','800','虚构租赁协议，未发生现金收支']])}}
// Explicit fixture completion; the T06 debt repayment is static, no inference.
export function completedExample(){const d=example();Object.assign(d.tx!.rows[5].cells,{'业务类型':'还本','项目':'F04','依据':'虚构还本凭据','摘要':'还本'});return d}
export function exampleRule(){return {...defaultRule(),policy:true,accountsComplete:true,txComplete:true}}
