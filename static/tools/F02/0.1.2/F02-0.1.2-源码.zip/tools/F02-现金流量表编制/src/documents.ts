import {fixedFixtureZip} from './static-zip';
import ExcelJS from 'exceljs';
import {workbookBytes} from '../../../packages/core/io';import type {Table} from '../../../packages/core/types';import type {ReleaseAsset} from '../../../packages/core/release-assets';import {example,exampleRule} from './example';import {sides,schemas,labels,type Data,type Rule,type Result} from './engine';import {VERSION,RULE_VERSION} from './version';import {encodeWork} from './work';
export function csv(t:Table){return '\uFEFF'+[t.headers,...t.rows.map(r=>t.headers.map(h=>r.cells[h]))].map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n')}
export function sourceSheets(data:Data){return sides.map(s=>({name:labels[s]+'原始资料',headers:['文件','页签','原行',...(data[s]?.headers||schemas[s])],rows:(data[s]?.rows||[]).map(r=>[r.file,r.sheet,r.row,...data[s]!.headers.map(h=>r.cells[h])])}))}
function monthlySheets(data:Data,rule:Rule,r:Result,review:string){return [
 {name:'编制范围与版本',headers:['项目','内容'],rows:[['应用',VERSION],['规则',RULE_VERSION],['结论',r.status],['完整报告边界','间接法调节附注、特殊净额、合并、自动换汇未实现'],['复核说明',review],...Object.entries(rule).map(([k,v])=>[k,JSON.stringify(v)])]},
 {name:'直接法辅助报表',headers:['项目ID','项目','活动','方向','金额'],rows:r.projects.map(p=>[p.id,p.name,p.activity,p.direction,p.amount])},
 {name:'净额与余额勾稽',headers:['项目','金额'],rows:Object.entries(r.summary)},
 {name:'逐账户核对',headers:['账户','纳入','期初','期末','汇率影响','流水含补录净额','残差','文件','页签','原行'],rows:r.accounts.map(a=>[a.id,a.included,a.opening,a.closing,a.fx,a.net,a.residual,a.source.file,a.source.sheet,a.source.row])},
 {name:'分类及来源',headers:['行ID','账户','方向','金额','项目','分类依据','状态','文件','页签','原行'],rows:r.tx.map(t=>[t.id,t.account,t.direction,t.value,t.project,t.basis,t.state,t.source.file,t.source.sheet,t.source.row])},
 {name:'项目全部组成',headers:['项目','方向','带符号金额','依据','来源类型','文件','页签','原行'],rows:r.contributions.map(c=>[c.project,c.direction,c.value,c.basis,c.side,c.origin.file,c.origin.sheet,c.origin.row])},
 {name:'划转核验',headers:['划转ID','状态','行ID','账户','对方账户','方向','金额','文件','页签','原行'],rows:r.transfers.flatMap(g=>g.rows.map(t=>[g.id,g.state,t.id,t.account,t.other,t.direction,t.value,t.source.file,t.source.sheet,t.source.row]))},
 {name:'异常与阻塞',headers:['资料侧','问题','文件','页签','原行'],rows:r.issues.map(i=>[i.side,i.message,i.source?.file,i.source?.sheet,i.source?.row])},
 {name:'输入覆盖',headers:['资料','原行','范围内有效','范围外','无效'],rows:sides.map(s=>[labels[s],r.coverage[s].input,r.coverage[s].included,r.coverage[s].excluded,r.coverage[s].invalid])},...sourceSheets(data)]}
async function sampleBytes(data:Data){const wb=new ExcelJS.Workbook();wb.created=new Date('2026-10-04T00:00:00Z');wb.modified=new Date('2026-10-04T00:00:00Z');for(const s of sides){const ws=wb.addWorksheet(labels[s]);ws.addRow(schemas[s]);for(const r of data[s]!.rows)ws.addRow(schemas[s].map(h=>r.cells[h]===null?'':String(r.cells[h])));ws.getRow(1).font={bold:true};ws.views=[{state:'frozen',ySplit:1}];ws.columns.forEach(c=>c.width=24)}return fixedFixtureZip(new Uint8Array(await wb.xlsx.writeBuffer()))}
export async function releaseAssets():Promise<ReleaseAsset[]>{const d=example(),enc=(s:string)=>new TextEncoder().encode(s),a:ReleaseAsset[]=[];for(const s of sides){a.push({filename:labels[s]+'空白模板.csv',data:enc('\uFEFF'+schemas[s].join(',')+'\r\n')},{filename:'虚构'+labels[s]+'.csv',data:enc(csv(d[s]!))})}a.push({filename:'空白模板.csv',data:enc('\uFEFF'+schemas.tx.join(',')+'\r\n')},{filename:'虚构样例.xlsx',data:await sampleBytes(d)},{filename:'虚构含数据方案.json',data:enc(encodeWork({data:d,rule:exampleRule(),review:'完全虚构资料，仅用于验证'},true))});return a}

export function reportSheets(data:Data,rule:Rule,r:Result,review:string){
 const interval=monthlySheets(data,rule,r,review);if(!r.months)return interval;
 const months=r.months.map(m=>({period:m.period,sheets:monthlySheets(data,{...rule,period:m.period,endPeriod:m.period},m.result,review)}));
 return interval.map((sheet,i)=>i>=9?sheet:i===0?{...sheet,rows:[...sheet.rows,['逐月确认',JSON.stringify(rule.monthConfirmations||[])],['区间范围',(rule.period)+'至'+(rule.endPeriod||rule.period)]]}:{...sheet,headers:['编制层级','期间',...sheet.headers],rows:[...sheet.rows.map(row=>['区间',rule.period+'至'+(rule.endPeriod||rule.period),...row]),...months.flatMap(m=>m.sheets[i].rows.map(row=>['月度',m.period,...row]))]});
}
