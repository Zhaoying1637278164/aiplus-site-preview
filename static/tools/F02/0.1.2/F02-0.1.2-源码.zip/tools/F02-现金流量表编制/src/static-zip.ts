/** Our generated public fixture only: ZIP entry metadata is fixed for byte-rebuilds.
 * Workbook created/modified XML dates are fixed separately. No user files pass here. */
export function fixedFixtureZip(input:Uint8Array):Uint8Array{
 const b=input.slice(),d=new DataView(b.buffer,b.byteOffset,b.byteLength);let end=-1;
 for(let i=b.length-22;i>=Math.max(0,b.length-65557);i--)if(d.getUint32(i,true)===0x06054b50){end=i;break}
 if(end<0)throw Error('生成样例ZIP目录无效');let p=d.getUint32(end+16,true);const count=d.getUint16(end+10,true),day=((2026-1980)<<9)|(10<<5)|4;
 for(let i=0;i<count;i++){if(d.getUint32(p,true)!==0x02014b50)throw Error('样例ZIP中央目录无效');const local=d.getUint32(p+42,true);if(d.getUint32(local,true)!==0x04034b50)throw Error('样例ZIP本地目录无效');d.setUint16(p+12,0,true);d.setUint16(p+14,day,true);d.setUint16(local+10,0,true);d.setUint16(local+12,day,true);p+=46+d.getUint16(p+28,true)+d.getUint16(p+30,true)+d.getUint16(p+32,true)}return b;
}
