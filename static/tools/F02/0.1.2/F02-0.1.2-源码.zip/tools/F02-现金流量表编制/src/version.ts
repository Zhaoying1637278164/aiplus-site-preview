export const VERSION='0.1.2';
export const RULE_VERSION='F02-CAS31-2026-10-04.2';
