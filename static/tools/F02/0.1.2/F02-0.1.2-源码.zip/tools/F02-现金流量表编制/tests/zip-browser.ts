import { chromium } from 'playwright';
import { writeFile, mkdir } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const e=process.env.F02_EVIDENCE||path.resolve('progress/evidence/F02/0.1.2');
const out=e+'/zip-download';await mkdir(out,{recursive:true});
await writeFile(out+'/index.html','<!doctype html><meta charset="utf-8"><a download href="../F02-0.1.2-候选离线包.zip">下载F02候选离线包</a><a download href="../F02-0.1.2-候选源码.zip">下载F02候选源码</a>');
const browser=await chromium.launch({channel:'chrome',headless:true});
try{const ctx=await browser.newContext({acceptDownloads:true});await ctx.setOffline(true);const page=await ctx.newPage();await page.goto(pathToFileURL(out+'/index.html').href);const files:string[]=[];for(const name of ['下载F02候选离线包','下载F02候选源码']){const event=page.waitForEvent('download');await page.getByRole('link',{name,exact:true}).click();const d=await event;await d.saveAs(out+'/'+d.suggestedFilename());files.push(d.suggestedFilename())}await writeFile(out+'/result.json',JSON.stringify({status:'passed',files,entry:'本地候选下载页；未代表官网发布'},null,2));}finally{await browser.close()}
