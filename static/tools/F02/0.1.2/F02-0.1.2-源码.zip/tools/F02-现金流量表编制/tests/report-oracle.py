# -*- coding: utf-8 -*-
from pathlib import Path
from decimal import Decimal as D
import json
E=Path('progress/evidence/F02/0.1.2');data=json.loads((E/'fixture/data.json').read_text());rule=json.loads((E/'fixture/rule.json').read_text());oracle=json.loads((E/'fixture/oracle.json').read_text());actual=json.loads((E/'browser/report-cells.json').read_text());sides=['accounts','tx','adjustments','noncash'];labels=['账户与余额','现金收支','人工调整','非现金事项'];periods=['2026-07','2026-08','2026-09'];review='独立虚构编制甲/复核乙';j=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'));f=lambda n:format(D(n).normalize(),'f') if D(n)!=0 else '0'
projects=[('O01','销售商品、提供劳务收到的现金','经营','流入'),('O02','收到的税费返还','经营','流入'),('O03','收到其他与经营活动有关的现金','经营','流入'),('O04','购买商品、接受劳务支付的现金','经营','流出'),('O05','支付给职工以及为职工支付的现金','经营','流出'),('O06','支付的各项税费','经营','流出'),('O07','支付其他与经营活动有关的现金','经营','流出'),('I01','收回投资收到的现金','投资','流入'),('I02','取得投资收益收到的现金','投资','流入'),('I03','处置固定资产、无形资产和其他长期资产收回的现金净额','投资','流入'),('I04','处置子公司及其他营业单位收到的现金净额','投资','流入'),('I05','收到其他与投资活动有关的现金','投资','流入'),('I06','购建固定资产、无形资产和其他长期资产支付的现金','投资','流出'),('I07','投资支付的现金','投资','流出'),('I08','取得子公司及其他营业单位支付的现金净额','投资','流出'),('I09','支付其他与投资活动有关的现金','投资','流出'),('F01','吸收投资收到的现金','筹资','流入'),('F02','取得借款收到的现金','筹资','流入'),('F03','收到其他与筹资活动有关的现金','筹资','流入'),('F04','偿还债务支付的现金','筹资','流出'),('F05','分配股利、利润或偿付利息支付的现金','筹资','流出'),('F06','支付其他与筹资活动有关的现金','筹资','流出')]
status='直接法辅助底稿已勾稽（附注另编）';headers=[['参数','内容'],['项目ID','项目','活动','方向','金额'],['项目','金额'],['账户','纳入','期初','期末','汇率影响','流水含补录净额','残差','文件','页签','原行'],['行ID','账户','方向','金额','项目','分类依据','状态','文件','页签','原行'],['项目','方向','带符号金额','依据','来源类型','文件','页签','原行'],['划转ID','状态','行ID','账户','对方账户','方向','金额','文件','页签','原行'],['资料侧','问题','文件','页签','原行'],['资料','原行','范围内有效','范围外','无效']]
# Match public schema label: first header is 项目 rather than internal parameter naming.
headers[0]=['项目','内容']
def source(row):return [row['file'],row['sheet'],row['row']]
def month_rows(p):
 o=next(m for m in oracle['months'] if m['period']==p);rs={s:[r for r in data[s]['rows'] if r['cells']['期间']==p] for s in sides};tx=[];contrib=[];groups={}
 for row in rs['tx']:
  c=row['cells'];proj=c['项目'] or ('O01' if c['业务类型']=='虚构销售规则' else '');basis=c['依据'] or ('虚构明确业务类型分类规则' if c['业务类型']=='虚构销售规则' else '');state='内部划转已排除' if c['划转ID'] else '已分类'
  tx.append([c['行ID'],c['账户ID'],c['方向'],f(c['金额']),proj,basis,state]+source(row))
  if not c['划转ID']:contrib.append([proj,c['方向'],f(c['金额']),basis,'tx']+source(row))
  else:groups.setdefault(c['划转ID'],[]).append(row)
 for row in rs['adjustments']:
  c=row['cells']
  if c['类型']=='重分类':contrib.append([c['原项目'],c['方向'],f(-D(c['金额'])),c['关联行ID']+'：'+c['依据'],'adjustments']+source(row))
  contrib.append([c['目标项目'],c['方向'],f(c['金额']),c['依据'],'adjustments']+source(row))
 acc=[]
 for row in rs['accounts']:
  c=row['cells'];a=next(a for a in o['accounts'] if a['id']==c['账户ID']);acc.append([a['id'],True,f(a['opening']),f(a['closing']),f(a['fx']),f(a['net']),'0']+source(row))
 tr=[]
 for k,rows in groups.items():
  for row in rows:
   c=row['cells'];tr.append([k,'内部划转已排除',c['行ID'],c['账户ID'],c['对方账户ID'],c['方向'],f(c['金额'])]+source(row))
 return [[],[list(proj)+[f(o['projects'].get(proj[0],0))] for proj in projects],[[k,f(v)] for k,v in o['summary'].items()],acc,tx,contrib,tr,[],[[labels[i],len(rs[s]),len(rs[s]),0,0] for i,s in enumerate(sides)]]
mr=[month_rows(p) for p in periods];interval=[[],[list(proj)+[f(oracle['projects'].get(proj[0],0))] for proj in projects],[[k,f(v)] for k,v in oracle['summary'].items()]]
for i in range(3,8):interval.append([row for m in mr for row in m[i]])
for mi,p in enumerate(periods):
 # interval transfers IDs have month namespace
 for row in interval[6][mi*8:mi*8+8]:row[0]=p+'/'+row[0]
 # Above shallow rows mutate monthly list; restore monthly IDs independently.
 mr[mi]=month_rows(p)
interval.append([[labels[i],len(data[s]['rows']),len(data[s]['rows'])-(1 if s=='tx' else 0),1 if s=='tx' else 0,0] for i,s in enumerate(sides)])
meta=[['应用','0.1.2'],['规则','F02-CAS31-2026-10-04.2'],['结论',status],['完整报告边界','间接法调节附注、特殊净额、合并、自动换汇未实现'],['复核说明',review]]+[[k,j(v)] for k,v in rule.items()]+[['逐月确认',j(rule['monthConfirmations'])],['区间范围','2026-07至2026-09']]
expected=[meta]
for i in range(1,9):expected.append([['区间','2026-07至2026-09']+row for row in interval[i]]+[['月度',p]+row for p,m in zip(periods,mr) for row in m[i]])
for s in sides:expected.append([source(r)+[r['cells'].get(h) for h in data[s]['headers']] for r in data[s]['rows']])
# Headers checked independently against contract; sources explicit.
expected_headers=[headers[0]]+[['编制层级','期间']+h for h in headers[1:]]+[['文件','页签','原行']+data[s]['headers'] for s in sides]
errors=[];count=0
for i,(sheet,rows,h) in enumerate(zip(actual,expected,expected_headers)):
 matrix=[h]+rows;actual_matrix=sheet['matrix'];width=max(len(r) for r in matrix)
 def canonical(v):return '' if v is None else 'true' if v is True else 'false' if v is False else str(v)
 normalized=[[canonical(v) for v in r]+['']*(width-len(r)) for r in matrix]
 if actual_matrix!=normalized:
  for ri in range(max(len(actual_matrix),len(normalized))):
   a=actual_matrix[ri] if ri<len(actual_matrix) else [];x=normalized[ri] if ri<len(normalized) else []
   if a!=x:errors.append({'sheet':sheet['name'],'row':ri+1,'expected':x,'actual':a})
 count+=sum(len(r) for r in normalized)
(E/'report-oracle-result.json').write_text(json.dumps({'status':'failed' if errors else 'passed','sheets':len(actual),'cells':count,'errors':errors[:20],'error_rows':len(errors),'method':'Independent Python Decimal fixture and full explicit schema/row construction; no engine outputs used as expected'},ensure_ascii=False,indent=2))
print(json.dumps({'status':'failed' if errors else 'passed','cells':count,'error_rows':len(errors)},ensure_ascii=False))
ui=json.loads((E/'browser/all-table-cells.json').read_text());ui_errors=[];ui_cells=0
null='缺值 / 未核对'
def display(v):return null if v is None else j(v) if isinstance(v,dict) else 'true' if v is True else 'false' if v is False else str(v)
def source_ui(s):
 priority={'accounts':['期间','账户ID','期初','期末','汇率影响'],'tx':['日期','账户ID','方向','金额','项目'],'adjustments':['期间','账户ID','方向','金额','目标项目'],'noncash':['期间','事项','金额','依据']}
 hs=list(dict.fromkeys([rule['columns'][s][h] for h in priority[s] if rule['columns'][s][h] in data[s]['headers']]+data[s]['headers']))
 return [[r['cells'].get(h) for h in hs]+[r['file'],r['sheet'],r['row']] for r in data[s]['rows']]
source_contrib=[]
for m,p in zip(mr,periods):
 for c in m[5]:
  if c[0]!='O01':continue
  row=next(r for r in data[c[4]]['rows'] if r['row']==c[7])
  source_contrib.append([c[1],c[2],c[3],c[4],c[5],c[6],c[7],row['cells']])
interval_ui=[]
for a in oracle['months'][0]['accounts']:
 id=a['id'];all_a=[next(x for x in m['accounts'] if x['id']==id) for m in oracle['months']]
 interval_ui.append([id,f(a['opening']),f(all_a[-1]['closing']),f(sum(D(x['net']) for x in all_a)),f(sum(D(x['fx']) for x in all_a)),'0','连续完整'])
summary_names={'opening':'期初现金及现金等价物','closing':'期末现金及现金等价物','fx':'汇率变动影响','net':'原始流水含补录净额'}
account_ui=[]
for m,p in zip(mr,periods):
 for a in m[3]:account_ui.append([p,a[0],'是']+a[2:7])
expected_ui={(1,0):source_ui('accounts'),(2,0):source_ui('tx'),(3,0):[list(p) for p in projects],(4,0):[[r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[9]] for r in interval[6]],(5,0):source_ui('adjustments'),(5,1):source_ui('noncash'),(6,0):interval[1],(6,1):[[m['period'],status]+[f(m['summary'][k]) for k in ['opening','closing','经营净额','投资净额','筹资净额','fx','净增加','报表残差','流水残差']] for m in oracle['months']],(6,2):interval_ui,(6,3):[[summary_names.get(k,k),f(v)] for k,v in oracle['summary'].items()],(6,4):account_ui,(7,0):[],(7,1):source_contrib,(7,2):interval[4],(7,3):interval[8]}
for table in ui:
 rows=[[display(v) for v in r] for r in expected_ui[(table['page'],table['grid'])]]
 if rows!=table['rows']:ui_errors.append({'width':table['width'],'page':table['page'],'grid':table['grid'],'expected_rows':len(rows),'actual_rows':len(table['rows'])})
 ui_cells+=sum(len(r) for r in rows)
(E/'ui-oracle-result.json').write_text(json.dumps({'status':'failed' if ui_errors else 'passed','tables':len(ui),'cells':ui_cells,'errors':ui_errors,'method':'All UI pages/pagination raw cells vs independent Python fixtures/Decimal'},ensure_ascii=False,indent=2));print(json.dumps({'ui_cells':ui_cells,'errors':ui_errors},ensure_ascii=False))
