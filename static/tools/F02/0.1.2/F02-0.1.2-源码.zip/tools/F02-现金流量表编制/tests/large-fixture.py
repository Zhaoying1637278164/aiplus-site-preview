# -*- coding: utf-8 -*-
from pathlib import Path
from decimal import Decimal as D
import json,csv,io
E=Path('progress/evidence/F02/0.1.2/fixture');E.mkdir(parents=True,exist_ok=True)
schemas={'accounts':['主体','期间','币种','单位','账户ID','性质','纳入','确认依据','期初','期末','汇率影响'],'tx':['主体','期间','币种','单位','行ID','日期','账户ID','方向','金额','业务类型','项目','依据','划转ID','对方账户ID','摘要'],'adjustments':['主体','期间','币种','单位','调整ID','类型','账户ID','方向','金额','原项目','目标项目','关联行ID','依据'],'noncash':['主体','期间','币种','单位','事项ID','事项','金额','依据']}
labels={'accounts':'账户与余额','tx':'现金收支','adjustments':'人工调整','noncash':'非现金事项'}
periods=['2026-07','2026-08','2026-09'];rows={s:[] for s in schemas};project_sums={};months=[];balances={f'AC{i:02}':D(10000) for i in range(20)}
f=lambda n:format(n,'f')
for mi,p in enumerate(periods):
 dims=['虚构甲公司',p,'CNY','元'];net={a:D(0) for a in balances};sums={};flows=[]
 def flow(id,a,d,v,proj,business='',transfer='',other=''):
  row=dims+[id,p+'-15',a,d,f(v),business,proj,'虚构凭据 '+id if proj or transfer else '',transfer or None,other or None,'虚构流水 '+id];flows.append(row);net[a]+=v if d=='流入' else -v
  if proj:sums[proj]=sums.get(proj,D(0))+v
 for i in range(200):
  direction='流入' if i%2==0 else '流出';v=D(i%13+1)/D(100);v=D(0) if i==198 else v
  proj='O01' if direction=='流入' else 'O04'
  flow(f'{p}-T{i:03}',f'AC{i%20:02}',direction,v,proj)
  if i%10==0:flows[-1][10]=None;flows[-1][11]=None;flows[-1][9]='虚构销售规则' # independently known O01 mapping
 for j in range(4):
  a,b=f'AC{j:02}',f'AC{j+4:02}';v=D(10+j);group=f'{p}-TR{j}'
  flow(group+'-O',a,'流出',v,'','',group,b);flow(group+'-I',b,'流入',v,'','',group,a)
 flow(p+'-LAST-IN','AC00','流入',D('7.123456'),'O03');flow(p+'-LAST-OUT','AC01','流出',D('7.123456'),'O07')
 rows['tx']+=flows
 adjustments=[]
 for i in range(18):
  if i<9:
   a=f'AC{(2*i+1)%20:02}';value=D('0.001');target='O07';old='O04';link=f'{p}-T{2*i+1:03}';kind='重分类';direction='流出';sums[old]-=value
  else:
   a=f'AC{i%20:02}';value=D('0.01');target='O03';old=None;link=None;kind='补录';direction='流入';net[a]+=value
  sums[target]=sums.get(target,D(0))+value
  adjustments.append(dims+[p+f'-A{i:02}',kind,a,direction,f(value),old,target,link,'虚构调整凭据'])
 rows['adjustments']+=adjustments
 for i in range(18):rows['noncash'].append(dims+[p+f'-N{i:02}','虚构非现金租赁',str(100+i),'虚构租赁协议'])
 opening=sum(balances.values());fx=D('0.01')*(mi+1)
 account_results=[]
 for i,(a,o) in enumerate(balances.items()):
  afx=fx if i==0 else D(0);close=o+net[a]+afx
  rows['accounts'].append(dims+[a,'现金','是','虚构可随时支付账户',f(o),f(close),f(afx)])
  account_results.append({'id':a,'opening':f(o),'closing':f(close),'net':f(net[a]),'fx':f(afx),'residual':'0'});balances[a]=close
 summary={'经营流入':f(sums.get('O01',D(0))+sums.get('O03',D(0))),'经营流出':f(sums.get('O04',D(0))+sums.get('O07',D(0)))}
 summary.update({'经营净额':f(D(summary['经营流入'])-D(summary['经营流出'])),'投资流入':'0','投资流出':'0','投资净额':'0','筹资流入':'0','筹资流出':'0','筹资净额':'0','未分类流入':'0','未分类流出':'0','opening':f(opening),'closing':f(sum(balances.values())),'fx':f(fx),'net':f(sum(net.values())),'三类净额':f(sum(net.values())),'净增加':f(sum(net.values())+fx),'报表残差':'0','流水残差':'0'})
 months.append({'period':p,'projects':{k:f(v) for k,v in sums.items()},'summary':summary,'accounts':account_results})
 for k,v in sums.items():project_sums[k]=project_sums.get(k,D(0))+v
# Scope-excluded valid record with different period.
rows['tx'].append(['虚构甲公司','2026-06','USD','元','OUTSIDE','2026-06-15','AC00','流入','999','范围外','O01','虚构凭据',None,None,'范围外不可混加'])
data={s:{'file':'虚构三月资料.xlsx','sheet':labels[s],'headers':h,'rows':[{'file':'虚构三月资料.xlsx','sheet':labels[s],'row':i+3,'cells':dict(zip(h,r))} for i,r in enumerate(rows[s])]} for s,h in schemas.items()}
summary={k:f(sum(D(m['summary'][k]) for m in months)) for k in months[0]['summary']};summary['opening']=months[0]['summary']['opening'];summary['closing']=months[-1]['summary']['closing']
oracle={'months':months,'projects':{k:f(v) for k,v in project_sums.items()},'summary':summary,'tx_count':len(rows['tx']),'scope_tx_count':630,'source':'Independent Python Decimal, specified fixed amounts; no JS engine import'}
(E/'data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));(E/'oracle.json').write_text(json.dumps(oracle,ensure_ascii=False,indent=2))
for s,h in schemas.items():
 out=io.StringIO();w=csv.writer(out);w.writerow(['完全虚构资料标题']);w.writerow(['原'+c for c in h]);w.writerows(rows[s]);(E/(labels[s]+'.csv')).write_text('\ufeff'+out.getvalue())
print(json.dumps({'rows':{s:len(r) for s,r in rows.items()},'summary':summary},ensure_ascii=False))
