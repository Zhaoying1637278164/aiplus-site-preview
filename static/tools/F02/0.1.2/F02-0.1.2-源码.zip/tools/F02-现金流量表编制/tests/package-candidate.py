# -*- coding: utf-8 -*-
from pathlib import Path
import json, zipfile, shutil, hashlib, subprocess, os
ROOT=Path.cwd(); E=ROOT/'progress/evidence/F02/0.1.2'; tool=Path('tools/F02-现金流量表编制')
staging=E/'source-staging'
if staging.exists(): shutil.rmtree(staging)
staging.mkdir()
for rel in [tool,Path('packages')]: shutil.copytree(ROOT/rel,staging/rel)
for name in ['package-lock.json','tsconfig.json']: shutil.copy2(ROOT/name,staging/name)
p=json.loads((ROOT/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/*/tests/*.test.ts','typecheck':'tsc --noEmit','build':'node --import tsx tools/F02-现金流量表编制/tests/build-candidate.ts'}
(staging/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
(staging/'references').mkdir();shutil.copy2(ROOT/'references/saxes-5.0.1-LICENSE',staging/'references/saxes-5.0.1-LICENSE')
(staging/'构建说明.md').write_text('Node22以上。npm ci；npm test；npm run typecheck；npm run build -- F02。输出progress/evidence/F02/0.1.2/candidate。仅本款及共享包。源码包package.json只改scripts以独立构建F02，dependencies与原锁文件一致；未修改项目公共配置。\n')
shutil.copy2(E/'candidate/THIRD_PARTY_NOTICES.md',staging/'THIRD_PARTY_NOTICES.md')
def zipdir(base,out):
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(base.rglob('*')):
   if f.is_file(): z.write(f,f.relative_to(base))
zipdir(staging,E/'F02-0.1.2-候选源码.zip');zipdir(E/'candidate',E/'F02-0.1.2-候选离线包.zip')
rebuild=E/'source-rebuild'
if rebuild.exists(): shutil.rmtree(rebuild)
rebuild.mkdir()
with zipfile.ZipFile(E/'F02-0.1.2-候选源码.zip') as z:z.extractall(rebuild)
results=[]
for name,cmd in [('install',['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund']),('test',['npm','test']),('typecheck',['npm','run','typecheck']),('build',['npm','run','build','--','F02'])]:
 proc=subprocess.run(cmd,cwd=rebuild,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (E/('source-rebuild-'+name+'.log')).write_text(proc.stdout)
 results.append({'command':cmd,'exit_code':proc.returncode})
 if proc.returncode: break
rebuilt=rebuild/'progress/evidence/F02/0.1.2/candidate';matches={}
if rebuilt.exists():
 for f in sorted((E/'candidate').iterdir()):
  if f.is_file():matches[f.name]=f.read_bytes()==(rebuilt/f.name).read_bytes()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest={'commands':results,'matches':matches,'status':'passed' if len(results)==4 and all(r['exit_code']==0 for r in results) and matches and all(matches.values()) else 'failed','packages':{f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in [E/'F02-0.1.2-候选源码.zip',E/'F02-0.1.2-候选离线包.zip']},'source_files':{str(f.relative_to(ROOT)):sha(f) for f in sorted((ROOT/tool).rglob('*')) if f.is_file()}}
(E/'source-rebuild.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in manifest.items() if k!='source_files'},ensure_ascii=False))
