import type {Table,SourceRow} from '../../../packages/core/types';
export type Kind='应付资料'|'付款计划'|'资金限额'|'实际付款';
export const KINDS:Kind[]=['应付资料','付款计划','资金限额','实际付款'];
export const HEADERS:Record<Kind,string[]>={
 应付资料:['来源行ID','主体ID','供应商ID','供应商名称','单据ID','币种','单位','含税口径','截止时点','未付余额','原到期日','来源依据','负数用途','关联单据ID','批准依据'],
 付款计划:['计划ID','来源行ID','主体ID','供应商ID','单据ID','付款批次','账户ID','拟付日期','拟付金额','确认状态','批准依据'],
 资金限额:['限额ID','主体ID','币种','单位','含税口径','账户ID','资金池ID','周期起日','可用限额','批准依据'],
 实际付款:['付款记录ID','来源行ID','主体ID','供应商ID','单据ID','币种','单位','含税口径','已付日期','已付金额','批准依据']};
export interface Config {cutoff:string;weekStart:number;precision:number;tolerance:string}
export const DEFAULT:Config={cutoff:'2026-09-30',weekStart:1,precision:2,tolerance:'0.00'};
export type Tables=Record<Kind,Table|null>;
export interface Snapshot {config:Config;tables:Tables;revision:number}
export interface Event {id:string;revision:number;action:string;kind:string;source:string;basis:string;before:unknown;after:unknown}
export interface Review {issue:string;basis:string;revision:number}
export interface Work extends Snapshot {events:Event[];reviews:Review[];baseline:Snapshot|null}
export function emptyWork(config:Config={...DEFAULT}):Work{return {config,tables:{应付资料:null,付款计划:null,资金限额:null,实际付款:null},revision:0,events:[],reviews:[],baseline:null}}
export interface Issue {id:string;kind:Kind;row:number;source:string;key:string;message:string;severity:'阻塞'|'提示'}
export interface Invoice {source:string;row:SourceRow;sourceId:string;entity:string;vendor:string;name:string;doc:string;scope:string;balance:string|null;confirmed:string;draft:string;remaining:string|null;due:string|null;overdue:number|null;bucket:string;valid:boolean;complete:boolean}
export interface Plan {source:string;row:SourceRow;id:string;sourceId:string;docKey:string;scope:string;account:string;date:string|null;value:string|null;status:string;delay:number|null;early:number|null;week:string|null;valid:boolean}
export interface Week {scope:string;start:string;end:string;opening:string;confirmed:string;closing:string;planIds:string;complete:boolean}
export interface Fund {scope:string;account:string;week:string;limit:string|null;used:string;remaining:string|null;excess:string|null;status:string;source:string;planIds:string}
export interface Group {scope:string;balance:string;confirmed:string;remaining:string;draft:string;invalid:number;complete:boolean}
export interface Result {revision:number;invoices:Invoice[];plans:Plan[];weeks:Week[];funds:Fund[];groups:Group[];issues:Issue[];actual:Record<string,string>[]}
