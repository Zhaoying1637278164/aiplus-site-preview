import type {ReleaseAsset} from '../../../packages/core/release-assets';
import {workbookBytes} from '../../../packages/core/io';
import {HEADERS,KINDS} from './types';
import {example} from './example';
import {csv} from './export';
export async function releaseAssets():Promise<ReleaseAsset[]>{const w=example();return [{filename:'空白模板.csv',data:csv({name:'应付资料',headers:HEADERS.应付资料,rows:[]})},...KINDS.filter(k=>k!=='应付资料').map(k=>({filename:k+'模板.csv',data:csv({name:k,headers:HEADERS[k],rows:[]})})),...KINDS.map(k=>({filename:'虚构'+k+'.csv',data:csv({name:k,headers:HEADERS[k],rows:w.tables[k]!.rows.map(r=>HEADERS[k].map(h=>r.cells[h]))})})),{filename:'虚构样例.xlsx',data:await workbookBytes(KINDS.map(k=>({name:k,headers:HEADERS[k],rows:w.tables[k]!.rows.map(r=>HEADERS[k].map(h=>r.cells[h]))})))}]}
