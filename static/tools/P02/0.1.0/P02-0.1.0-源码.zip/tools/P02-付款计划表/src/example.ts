import {HEADERS,type Kind,type Work,emptyWork} from './types';
import type {Table} from '../../../packages/core/types';
export function table(k:Kind,rows:unknown[][],file='完全虚构样例.xlsx'):Table{return {file,sheet:k,headers:HEADERS[k],rows:rows.map((r,i)=>({file,sheet:k,row:i+2,cells:Object.fromEntries(HEADERS[k].map((h,j)=>[h,(r[j]??null) as string|null]))}))}}
export function example():Work{const w=emptyWork();w.tables.应付资料=table('应付资料',[
 ['S001','001','0001','虚构供应商甲','A','CNY','元','含税','2026-09-30','1000','2026-09-20','虚构合同A',null,null,null],
 ['S002','001','0002','虚构供应商甲','B','CNY','元','含税','2026-09-30','200','2026-10-03','虚构合同B',null,null,null],
 ['S003','001','0003','虚构供应商乙','C','USD','元','未税','2026-09-30','50',null,'虚构合同C',null,null,null],
 ['S004','001','0004','虚构供应商丁','D','CNY','元','含税','2026-09-30','0','2026-10-31','虚构合同D',null,null,null]
 ]);w.tables.付款计划=table('付款计划',[
 ['P001','S001','001','0001','A','批次01','AC01','2026-10-02','400','已确认','虚构批准1'],
 ['P002','S001','001','0001','A','批次02','AC01','2026-10-09','300','已确认','虚构批准2'],
 ['P003','S002','001','0002','B','批次01','AC01','2026-10-01','200','草稿','虚构拟安排']
 ]);w.tables.资金限额=table('资金限额',[
 ['F001','001','CNY','元','含税','AC01','POOL01','2026-09-28','500','虚构批准资金1'],
 ['F002','001','CNY','元','含税','AC01','POOL01','2026-10-05','500','虚构批准资金2']
 ]);w.tables.实际付款=table('实际付款',[
 ['H001','S001','001','0001','A','CNY','元','含税','2026-09-28','100','虚构历史已付，快照已包含影响']
 ]);return w}
