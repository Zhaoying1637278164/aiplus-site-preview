from pathlib import Path
import csv,json,datetime
f=Path('tools/M04-投资回报测算/examples/bulk');headers=['项目','现金流ID','类别','金额','币种','单位','期次','日期','说明'];rows=[];expected=[]
c=json.loads((f/'无数据独立方案.json').read_text());cfg=c['work']['config'];cfg.update(mode='date',rate='0',hurdle='0',scenarios=[],rates=['0'],factors=['1'])
for name,n,nontrad,limit in [('传统601',601,False,False),('传统602',602,False,True),('非传统128',128,True,False),('非传统129',129,True,True)]:
 vals=[-(n-1)]+[1]*(n-2)+([-1] if nontrad else [1]);expected.append({'name':name,'npv':str(sum(vals)),'points':n,'status':'未执行' if limit else '单解' if not nontrad else '已执行'})
 for i,v in enumerate(vals):rows.append([name,name+'-'+str(i),'初始投资' if i==0 else '经营现金流',str(v),'CNY','元',str(i),(datetime.date(2026,1,1)+datetime.timedelta(days=i)).isoformat(),'完全虚构时间点边界'])
for name,vals,status,roots in [('多个IRR',[-100,230,-132],'多解',['10','20']),('切点IRR',[-100,200,-100],'单解',['0']),('真无解',[-100,100,-100],'搜索范围内无解',[]),('任意利率',[-100,100],'不唯一',[])]:
 expected.append({'name':name,'npv':str(sum(vals)),'points':1 if name=='任意利率' else len(vals),'status':status,'roots':roots})
 for i,v in enumerate(vals):rows.append([name,name+'-'+str(i),'初始投资' if i==0 else '经营现金流',str(v),'CNY','元',str(i),(datetime.date(2026,1,1)+datetime.timedelta(days=0 if name=='任意利率' else i*365)).isoformat(),'完全虚构解析预期'])
with (f/'IRR边界虚构.csv').open('w',encoding='utf-8-sig',newline='')as file:
 w=csv.writer(file);w.writerow(headers);w.writerows(rows)
(f/'IRR边界方案.json').write_text(json.dumps(c,ensure_ascii=False,indent=2));(f/'IRR边界独立预期.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2))
