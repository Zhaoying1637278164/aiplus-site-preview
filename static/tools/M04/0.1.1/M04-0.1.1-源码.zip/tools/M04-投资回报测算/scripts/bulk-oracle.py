# Independent fixture/oracle: Python Decimal and elementary algebra, never imports M04 engine.
from decimal import Decimal as D,getcontext
from pathlib import Path
import json,csv,sys,datetime,hashlib
getcontext().prec=80
folder=Path('tools/M04-投资回报测算');out=folder/'examples/bulk';out.mkdir(parents=True,exist_ok=True)
headers=['项目','现金流ID','类别','金额','币种','单位','期次','日期','说明']
rows=[]
for project in range(70):
 for i in range(9):
  rows.append([f'虚构投资{project:02d}',f'P{project:02d}-{i}', '初始投资' if i==0 else '经营现金流',str(-100*(project+1)) if i==0 else str(D('13.75')*(project+1)),'CNY','元',str(0 if i==0 else 1),'2026-01-01' if i==0 else '2027-01-01',f'完全虚构-{len(rows)+2}'])
with (out/'604以上虚构现金流.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.writer(f);w.writerow(headers);w.writerows(rows)
config={'mode':'period','frequency':'year','timing':'end','baseDate':'2026-01-01','dayBasis':'365','rate':'10','hurdle':'10','basis':'完全虚构；年有效率10%；不自动投资决策','currency':'CNY','unit':'元','horizon':'3','decimals':2,'tolerance':'0.000001','payback':'discrete','irrMin':'-99.9','irrMax':'1000','scenarios':[{'name':'同现金折现零','rate':'0','inflow':'1','outflow':'1','initial':'1','terminal':'1'},{'name':'基准复核','rate':'10','inflow':'1','outflow':'1','initial':'1','terminal':'1'}],'rates':['0','10'],'factors':['1','2'],'mapping':{h:h for h in headers}}
(out/'无数据独立方案.json').write_text(json.dumps({'schema_version':1,'tool':'M04','app_version':'0.1.1','rule_version':'M04-2026-10-04.1','contains_data':False,'work':{'config':config,'table':None,'original':None}},ensure_ascii=False,indent=2))
# output complete expected cells for each independent run specification supplied by browser evidence.
if len(sys.argv)>1:
 spec=json.load(open(sys.argv[1]));c=spec['config'];file=spec['file'];sheet=spec['sheet'];h=spec.get('headers',headers);original=rows;current=[list(r) for r in rows]
 if spec.get('revised'):
  assert D('1925')==D(current[-1][3])*2
  current[-1][3]='1925' # exact independently specified manual-entry text, original stays 962.50
 def label(i):return f'{file} / {sheet} / 行{i+2}'
 def numeric(v):return format(v,'f')
 names=['项目回报','现金流与折现','IRR风险与根','回收期','情景比较','敏感性','逐行检查','原始资料','导入原始资料','口径与版本']
 hs=[['项目','状态','净现值','要求回报净现值','累计净现金','流入合计','流出绝对值','简单现金ROI百分比','现值勾稽残差','错误'],['项目','时间年','净现金流','现值','累计现金','累计现值','全部来源'],['项目','状态','符号变化','完成范围搜索','年有效IRR百分比','净现值残差','说明'],['项目','口径','首次回收年','持续回收年','期末余额','说明'],['项目','情景','净现值','净现金','IRR状态','IRR百分比','首次静态回收年','首次折现回收年'],['项目','年折现率百分比','经营正现金倍数','净现值'],['项目','现金流ID','类别','金额','时间年','纳入状态','检查','来源'],['文件','页签','原始行']+h,['文件','页签','原始行']+h,['参数','值']]
 result={n:{'name':n,'headers':head,'rows':[]} for n,head in zip(names,hs)}
 def add(n,r):result[n]['rows'].append([str(v).lower() if isinstance(v,bool) else '' if v is None else str(v) for v in r])
 begin=c['mode']=='period' and c['timing']=='begin';t=D(0) if begin else D(1)
 for p in range(70):
  rr=current[p*9:p*9+9];initial=D(rr[0][3]);cash=sum(D(x[3])for x in rr[1:]);net=initial+cash;rate=D(c['rate'])/100;hr=D(c['hurdle'])/100;pv=cash/(1+rate)**t;npv=initial+pv;hurdle=initial+cash/(1+hr)**t;irr=(cash/(-initial)-1)*100;roi=net/(-initial)*100
  add('项目回报',[rr[0][0],'已计算',npv,hurdle,net,cash,-initial,roi,0,''])
  if begin:add('现金流与折现',[rr[0][0],0,net,net,net,net,'；'.join(label(p*9+i)for i in range(9))])
  else:
   add('现金流与折现',[rr[0][0],0,initial,initial,initial,initial,label(p*9)])
   add('现金流与折现',[rr[0][0],1,cash,pv,net,npv,'；'.join(label(p*9+i)for i in range(1,9))])
  msg=f"年有效IRR，搜索 {c['irrMin']}% 至 {c['irrMax']}%。 搜索范围外未检查。" if not begin else '净现金流无符号变化，r>-100%无IRR'
  add('IRR风险与根',[rr[0][0],'无解' if begin else '单解',0 if begin else 1,True,None if begin else irr,None if begin else 0,msg])
  for k,balance in [('静态',net),('折现',npv)]:
   pb=None if begin or balance<0 else '1';message='起点无负净投入，回收期不适用' if begin else ('持续回收到期限结束' if pb else '期限内未回收')+'；按实际现金流时间点'
   add('回收期',[rr[0][0],k,pb,pb,balance,message])
  for s in c['scenarios']:
   ci=initial*D(s['initial']);cf=cash*D(s['inflow']);sn=ci+cf/(1+D(s['rate'])/100)**t
   add('情景比较',[rr[0][0],s['name'],sn,ci+cf,'无解' if begin else '单解','' if begin else (cf/(-ci)-1)*100,None if begin or ci+cf<0 else '1',None if begin or sn<0 else '1'])
  for rate in c['rates']:
   for factor in c['factors']:add('敏感性',[rr[0][0],rate,factor,initial+cash*D(factor)/(1+D(rate)/100)**t])
 for i,r in enumerate(current):
  add('逐行检查',[r[0],r[1],r[2],r[3],0 if i%9==0 else t,'纳入','',label(i)])
  add('原始资料',[file,sheet,i+2]+r)
  add('导入原始资料',[file,sheet,i+2]+original[i])
 meta=[['应用版本','0.1.1'],['规则版本','M04-2026-10-04.1'],['金额单位',c['unit']],['币种',c['currency']],['NPV公式','ΣCF/(1+年有效率)^时间年；初始投资时点0'],['ROI定义','累计净现金/现金流出绝对值×100；不是会计ROIC'],['非现金','排除非现金项目；用户确认税后增量现金口径'],['敏感性','正经营现金流倍数；初始/残值/营运资金回收不变']]
 keys=['时间口径','期次频率','现金流时点','估值日','实际天数基准','年有效折现率百分比','年有效要求回报百分比','折现依据','币种','金额单位','期限','显示小数位','IRR金额残差容差','回收期方法','IRR搜索下限百分比','IRR搜索上限百分比','情景输入','敏感性年折现率百分比','敏感性现金倍数','字段对应']
 mapping={'period':'规则期次','date':'实际日期','year':'年','quarter':'季','month':'月','end':'期末','begin':'期初','discrete':'现金流时间点','linear':'均匀流入插值'}
 for key,value in zip(keys,c.values()):meta.append([key,mapping.get(value,value) if isinstance(value,str) else json.dumps(value,ensure_ascii=False,separators=(',',':'))])
 for row in meta:add('口径与版本',row)
 dest=Path(spec['expected_path']);dest.write_text(json.dumps({'generator':'Python Decimal80; independently specified 630 flows, known one-period algebra; never uses M04 result','sheets':list(result.values())},ensure_ascii=False,indent=2))
 print(dest)
