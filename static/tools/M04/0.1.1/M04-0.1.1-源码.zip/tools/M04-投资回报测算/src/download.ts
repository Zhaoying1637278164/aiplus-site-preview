// Local downloads only. Dispose releases every URL immediately, including pending clicks.
const urls=new Map<string,ReturnType<typeof setTimeout>>();
export function save(name:string,data:BlobPart,type='application/json'){const url=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();urls.set(url,setTimeout(()=>{URL.revokeObjectURL(url);urls.delete(url)},1000))}
export function clearDownloads(){for(const [url,t]of urls){clearTimeout(t);URL.revokeObjectURL(url)}urls.clear()}
