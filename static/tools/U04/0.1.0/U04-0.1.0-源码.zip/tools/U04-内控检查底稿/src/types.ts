export const VERSION='0.1.0',RULE_VERSION='U04-local-1';
export const FIELDS=['检查ID','检查事项','业务流程','风险与目标','检查程序','证据要求','责任备注','检查周期'] as const;
export const ASSESSMENTS=['未评价','待补证','未发现例外','发现问题','不适用'] as const;
export type Assessment=typeof ASSESSMENTS[number];
export interface Source{file:string;sheet:string;row:number;cells:Record<string,string|null>}
export interface Item{id:string;title:string;process:string;risk:string;procedure:string;requirement:string;owner:string;period:string;source:Source;fact:string;factDate:string;tester:string;assessment:Assessment;basis:string;reviewer:string;reviewDate:string;evidenceIds:string[]}
export interface Evidence{id:string;itemId:string;name:string;size:number;sha256:string;type:string;date:string;note:string;data:string|null}
export interface Issue{id:string;itemId:string;description:string;action:string;owner:string;due:string;status:'待整改'|'整改中'|'待复核'|'已关闭';result:string;reviewer:string;reviewDate:string;evidenceIds:string[]}
export interface Work{scope:{entity:string;period:string;start:string;end:string;purpose:string;preparer:string;policy:string;policyDate:string;conditions:string};items:Item[];evidence:Evidence[];issues:Issue[]}
export const LIMIT={rows:500,evidence:100,file:2*1024*1024,total:10*1024*1024,plan:20*1024*1024};
export function empty():Work{return {scope:{entity:'',period:'',start:'',end:'',purpose:'',preparer:'',policy:'',policyDate:'',conditions:''},items:[],evidence:[],issues:[]}}
export function newItem(id:string,period:string):Item{return {id,title:'',process:'',risk:'',procedure:'',requirement:'',owner:'',period,source:{file:'人工新增',sheet:'个人清单',row:1,cells:{}},fact:'',factDate:'',tester:'',assessment:'未评价',basis:'',reviewer:'',reviewDate:'',evidenceIds:[]}}
