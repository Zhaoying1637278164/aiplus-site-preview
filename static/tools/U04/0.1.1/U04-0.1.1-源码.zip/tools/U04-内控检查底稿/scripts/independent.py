# Independent expectations were fixed in 规格与独立预期.md before executing the app.
import pathlib,json,csv,zipfile,xml.etree.ElementTree as ET,hashlib,os
p=pathlib.Path('progress/evidence/U04/0.1.1/'+os.environ.get('U04_BROWSER_EVIDENCE','browser'));checks=[]
plan=json.loads((p/'downloaded-full.json').read_text());assert plan['schema_version']==1 and plan['includes_evidence'] is True
w=plan['work'];assert len(w['items'])==3 and len(w['issues'])==1 and len(w['evidence'])==1
assert w['items'][0]['fact']=='选定付款记录未见复核日期';assert w['items'][0]['assessment']=='发现问题';checks.append('手工期望：3事项/1问题/1证据，事实与评价分字段')
import base64
b=base64.b64decode(w['evidence'][0]['data']);assert b==(p/'downloaded-evidence.txt').read_bytes();assert hashlib.sha256(b).hexdigest()==w['evidence'][0]['sha256'];checks.append('Python SHA交叉核对真实下载原始证据')
rows=list(csv.reader((p/'500-checklist.csv').open(encoding='utf-8-sig',newline='')));assert len(rows)==501;assert rows[1][0]=='I0' and rows[-1][0]=='I499';checks.append('真实下载CSV独立行数501、首尾ID')
tpl=json.loads((p/'500-template.json').read_text());assert not tpl['includes_data'] and not tpl['includes_evidence'];assert len(tpl['work']['items'])==500;assert not tpl['work']['evidence'] and not tpl['work']['issues'];assert all(not i['fact'] and i['assessment']=='未评价' and not i['source']['cells'] for i in tpl['work']['items']);checks.append('真实下载清单方案500项、无事实评价整改证据及原始值')
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(p/'500-workbook.xlsx') as z:
 book=ET.fromstring(z.read('xl/workbook.xml'));names=[x.attrib['name'] for x in book.findall('m:sheets/m:sheet',ns)];assert names==['范围与版本','检查清单','事实与人工评价','问题整改','证据索引','原始来源','未完成事项']
 strings=[]
 if 'xl/sharedStrings.xml' in z.namelist():
  strings=[''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)]
 sheet=ET.fromstring(z.read('xl/worksheets/sheet2.xml'));xmlrows=sheet.findall('m:sheetData/m:row',ns);assert len(xmlrows)==501
 def cell(c):
  val=c.find('m:v',ns);return strings[int(val.text)] if c.attrib.get('t')=='s' else (val.text if val is not None else '')
 assert cell(xmlrows[1][0])=='I0' and cell(xmlrows[-1][0])=='I499'
 fact=ET.fromstring(z.read('xl/worksheets/sheet3.xml')).findall('m:sheetData/m:row',ns)[0];assert cell(fact[1])=='事实记录' and cell(fact[4])=='人工评价'
 source=ET.fromstring(z.read('xl/worksheets/sheet6.xml')).findall('m:sheetData/m:row',ns);assert len(source)==501 and cell(source[1][1])=='500.csv' and cell(source[1][3])=='2'
checks.append('Python标准库读实际XLSX：七表、501行、事实评价列、原始CSV第2行')
result={'status':'passed','checks':checks,'expected_origin':'hand fixed before app run; Python stdlib does not import app code'}
(p.parent/('independent-host.json' if os.environ.get('U04_BROWSER_EVIDENCE') else 'independent.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
