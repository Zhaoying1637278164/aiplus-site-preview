import pathlib,zipfile,tempfile,shutil,json,hashlib,subprocess
root=pathlib.Path.cwd();folder=pathlib.Path('tools/U04-内控检查底稿');out=folder/'candidate/0.1.1';e=root/'progress/evidence/U04/0.1.1'
def pack(base,dest):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(base.rglob('*')):
   if p.is_file():
    i=zipfile.ZipInfo(p.relative_to(base).as_posix(),(2026,10,4,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,p.read_bytes())
with tempfile.TemporaryDirectory(dir='/private/tmp',prefix='u04-source-') as d:
 src=pathlib.Path(d);shutil.copy2(root/'package-lock.json',src/'package-lock.json');p=json.loads((root/'package.json').read_text());p['scripts']={'test':'node --import tsx --test tools/U04-内控检查底稿/tests/*.test.ts','typecheck':'tsc --noEmit','build':'node --import tsx tools/U04-内控检查底稿/scripts/build-candidate.ts'};(src/'package.json').write_text(json.dumps(p,ensure_ascii=False,indent=2));(src/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','jsx':'react-jsx','strict':True,'esModuleInterop':True,'skipLibCheck':True,'lib':['ES2022','DOM'],'types':['node'],'noEmit':True},'include':['packages/core','packages/ui/tool-host.ts','tools/U04-内控检查底稿/src','tools/U04-内控检查底稿/tests','tools/U04-内控检查底稿/scripts/build-candidate.ts']},indent=2))
 shutil.copytree(root/'packages/core',src/'packages/core');(src/'packages/ui').mkdir(parents=True);shutil.copy2(root/'packages/ui/tool-host.ts',src/'packages/ui/tool-host.ts');shutil.copytree(root/folder,src/folder,ignore=shutil.ignore_patterns('candidate','__pycache__'))
 (src/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',src/'references/saxes-5.0.1-LICENSE');shutil.copytree(e/'references',src/'reference-review');shutil.copy2(root/folder/'README.md',src/'README.md');shutil.copy2(root/out/'THIRD_PARTY_NOTICES.md',src/'THIRD_PARTY_NOTICES.md')
 manifest={str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(src.rglob('*')) if p.is_file()};(src/'SOURCE-SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));pack(src,out/'U04-0.1.1-源码.zip');(e/'source-snapshot.json').write_text(json.dumps({'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':manifest,'standalone_scripts':'root package scripts scoped to U04 candidate; shared root unchanged'},ensure_ascii=False,indent=2))
with tempfile.TemporaryDirectory(dir='/private/tmp',prefix='u04-offline-') as d:
 dst=pathlib.Path(d)
 for p in out.iterdir():
  if p.is_file() and p.suffix!='.zip':shutil.copy2(p,dst/p.name)
 pack(dst,out/'U04-0.1.1-离线包.zip')
checks={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.zip')};(e/'candidate-packages.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print(json.dumps(checks,ensure_ascii=False))
