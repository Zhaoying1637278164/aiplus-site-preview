import {createSiteToolHost,type SiteToolRegistration} from '../../packages/ui/site-tool-host';
declare global {
 interface Window {
  __AIPlusRegistry:SiteToolRegistration[];
  __AIPlusHost:ReturnType<typeof createSiteToolHost>;
 }
}
window.__AIPlusHost=createSiteToolHost(window.__AIPlusRegistry||[]);
