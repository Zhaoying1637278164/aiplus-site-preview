/** First-party distributable files only. No user data enters this handler. */
export function wireProgramDownloads(){
 document.addEventListener('click',event=>{
  const link=event.target instanceof Element?event.target.closest<HTMLAnchorElement>('a[data-program-download]'):null;
  if(!link)return;
  event.preventDefault();
  if(link.getAttribute('aria-busy')==='true')return;
  const label=link.textContent||'下载';link.setAttribute('aria-busy','true');link.textContent='正在准备下载…';
  void (async()=>{
   const expected=link.dataset.downloadSha,filename=link.download,size=Number(link.dataset.downloadBytes);
   if(!expected||! /^[a-f0-9]{64}$/.test(expected)||!filename||filename.includes('/')||size<=0||size>24*1024*1024)throw Error('下载登记无效');
   const url=new URL(link.getAttribute('href')||'',document.baseURI);
   if(url.origin!==new URL(document.baseURI).origin||! /\/app\/static\/tools\/[A-Z]\d{2}\/\d+\.\d+\.\d+\/download-\d\.json$/.test(url.pathname))throw Error('下载来源无效');
   const response=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',cache:'no-store'});
   if(!response.ok||!response.body)throw Error('下载暂时不可用');
   const reader=response.body.getReader(),chunks:Uint8Array[]=[];let length=0;
   for(;;){const part=await reader.read();if(part.done)break;length+=part.value.length;if(length>size*1.4+2048){await reader.cancel();throw Error('下载体积超过登记上限')}chunks.push(part.value)}
   const encoded=new Uint8Array(length);let offset=0;for(const part of chunks){encoded.set(part,offset);offset+=part.length}
   const payload=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(encoded));
   if(payload.schema_version!==1||payload.filename!==filename||typeof payload.base64!=='string'||payload.base64.length!==4*Math.ceil(size/3)||! /^[A-Za-z0-9+/]*={0,2}$/.test(payload.base64))throw Error('下载版本不匹配');
   const raw=atob(payload.base64),bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));if(bytes.length!==size)throw Error('下载体积不匹配');
   const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(n=>n.toString(16).padStart(2,'0')).join('');
   if(hash!==expected)throw Error('下载校验失败');
   const object=URL.createObjectURL(new Blob([bytes],{type:'application/octet-stream'}));
   const save=document.createElement('a');save.href=object;save.download=filename;save.click();setTimeout(()=>URL.revokeObjectURL(object),1000);
  })().catch(error=>{const message=document.createElement('p');message.setAttribute('role','alert');message.textContent=(error as Error).message+'，请重试';link.parentElement?.append(message)}).finally(()=>{link.removeAttribute('aria-busy');link.textContent=label});
 });
}
