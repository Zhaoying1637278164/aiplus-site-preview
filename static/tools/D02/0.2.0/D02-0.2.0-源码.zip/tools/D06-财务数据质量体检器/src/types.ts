import type {SourceRow} from '../../../packages/core/types';
export const VERSION='0.1.1';
export const RULE_VERSION='D06-2026-10-03.1';
export type Severity='error'|'warning';
export type Kind='required'|'unique'|'type'|'allowed'|'range'|'equation';
export interface Check {
 id:string;name:string;kind:Kind;severity:Severity;columns:string[];
 value_type?:'text'|'amount'|'date';allowed?:string[];min?:string;max?:string;
 terms?:{column:string;sign:1|-1}[];target?:string;tolerance?:string;
}
export interface Plan {schema_version:1;tool:'D06';trim:boolean;ignoreCase:boolean;checks:Check[]}
export interface Issue {rule_id:string;rule_name:string;severity:Severity;kind:'violation'|'unassessed';source:SourceRow;columns:string[];actual:string;expected:string;difference:string;message:string}
export interface Summary {id:string;name:string;severity:Severity;state:'executed'|'blocked';examined_rows:number;violation_rows:number;unassessed_rows:number;reason:string}
export interface Report {tool:'D06';app_version:string;rule_version:string;plan:Plan;file:string;sheet:string;issues:Issue[];rules:Summary[];row_status:{source:SourceRow;error:boolean;warning:boolean;unassessed:boolean}[];stats:{input_rows:number;issue_rows:number;no_issue_rows:number;error_rows:number;warning_rows:number;issue_count:number;blocked_rules:number};conclusion:'发现问题'|'有规则未执行'|'已启用规则未发现问题'}
