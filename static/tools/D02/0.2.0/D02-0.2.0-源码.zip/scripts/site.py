"""Generate the native website workspace from trusted program artifacts."""
from pathlib import Path
import hashlib, html, json, re, shutil, subprocess, sys
from urllib.parse import quote

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT.parent/'aiplus-streamlit'
STAGE=ROOT/'integration/native-site'

def clean_legacy(source):
    source=re.sub(r'<template id="r-tool-D(?:02|03|06)">.*?</template>', '', source, flags=re.S)
    source=re.sub(r'^\s*var d(?:02|03|06)=document\.createElement\([^\n]+\n', '', source, flags=re.M)
    return source

def native_document(source, entry, files, host_js):
    source=clean_legacy(source)
    assert len(re.findall(r'\bdata-tool\s',source))==76, 'Unexpected original catalogue; inspect before editing'
    identifier=entry['id'];name=html.escape(entry['name']);version=html.escape(entry['version'])
    prefix='app/static/tools/'+identifier+'/'+entry['version']+'/'
    def download(filename,label,classes='btn btn-s btn-sm'):
        return f'<a class="{classes}" href="{prefix+quote(filename)}" download="{html.escape(filename)}">{html.escape(label)}</a>'
    description='会计明细与业务台账按单据和口径核对，逐项追查差异并留存复核底稿'
    row=f'''<div class="trow" data-tool data-mod="close" data-type="T" data-ai="0" data-q="{name} {description} 结账">
<div class="stack gap8" style="min-width:0"><div class="row gap8" style="flex-wrap:wrap"><a href="#{entry['detailRoute']}" class="rt ink" style="font-size:16px;font-weight:600;margin-right:4px">{name}</a><span class="pill">结账</span><span class="pill">单点工具</span></div><div style="font-size:14px;color:#3D4250;line-height:1.6">{description}</div></div>
<div class="row gap8"><a href="#{entry['detailRoute']}" class="btn btn-s btn-sm">详情</a><a href="#{entry['workspaceRoute']}" class="btn btn-p btn-sm">在线使用</a></div></div>'''
    marker='<div class="trow" data-tool data-mod="tax"'
    assert marker in source;source=source.replace(marker,row+marker,1)
    source=source.replace('76 个开源工具','77 个工具').replace('76 个工具','77 个工具')
    source=source.replace('data-count="mod:all">76','data-count="mod:all">77').replace('data-total>76','data-total>77')
    original=re.search(r'<template id="r-tool-close-11">.*?</template>',source,re.S)
    assert original
    detail=original.group().replace('r-tool-close-11','r-'+entry['detailRoute']).replace('对外报送数据核对',name)
    detail=re.sub(r'<p class="lead">.*?</p>',f'<p class="lead">{description}</p>',detail,flags=re.S)
    detail=detail.replace('<span class="btn is-off" aria-disabled="true">工具包即将上线</span>',f'<a href="#{entry["workspaceRoute"]}" class="btn btn-p">开始账表对账</a>'+download(files[0],'下载离线包','btn btn-s'),1)
    detail=re.sub(r'<a href="https://github\.com/".*?</a>',download(files[1],'下载源码','btn btn-s'),detail,flags=re.S)
    for label,value in [('版本',version),('更新日期','2026-10-03'),('文件大小',entry['offlineSize'])]:
        pattern=r'('+label+r'</span><span style="text-align:right">)[^<]+(</span>)'
        detail=re.sub(pattern,lambda m:m.group(1)+value+m.group(2),detail)
    detail=re.sub(r'<div class="row"(?:(?!</div>).)*?下载次数.*?</div>','',detail,flags=re.S)
    detail=detail.replace('编辑口径说明和规则配置，重新运行即可生效。','在范围与口径页面设置核对字段和金额容差，再生成差异。').replace('口径说明.md','财务规则.md')
    detail=detail.replace('完整的使用说明、口径说明与示例数据随工具包一并提供。','两方资料、范围与口径、差异总览、逐项复核、结果底稿分开操作。差异说明与复核记录保留原始来源；不可比较的资料单独列出。')
    package_block=r'<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:8px">工具包内容</div>.*?</div>\s*(?=<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:4px">相关工具)'
    labels=['离线工具包','同版本源码','虚构样例（Excel）','空白模板（CSV）','使用说明','财务口径','第三方声明']
    links=''.join('<div style="padding:6px 0">'+download(f,label,'tl')+'</div>' for f,label in zip(files,labels))
    replacement='<div class="card" style="padding:20px 22px"><div style="font-size:14px;font-weight:600;margin-bottom:8px">下载与说明</div>'+links+'</div>\n'
    detail,matched=re.subn(package_block,lambda _:replacement,detail,flags=re.S);assert matched==1
    workspace=f'''<template id="r-{entry['workspaceRoute']}"><section class="sec" style="padding:28px 0 72px"><div class="wrap stack gap20"><nav aria-label="面包屑" class="row gap8 small"><a href="#tools">工具库</a><span>/</span><a href="#tools-close">结账</a><span>/</span><a href="#{entry['detailRoute']}">{name}</a></nav><div id="tool-workspace"></div></div></section></template>'''
    registry={k:entry[k] for k in ['id','name','version','detailRoute','workspaceRoute','runtime','sha256','bytes']}
    registration=json.dumps([registry],ensure_ascii=False).replace('<','\\u003c')
    injection=detail+workspace+'<script>window.__AIPlusRegistry='+registration+';</script><script>'+host_js.replace('</script','<\\/script')+'</script>\n'
    marker='<script>\nwindow.__initTools';assert marker in source;source=source.replace(marker,injection+marker,1)
    old="function go(h){PREV=CUR||'home';CUR=h;render()}"
    new="function go(h){if(h===CUR)return;if(window.__AIPlusHost&&!window.__AIPlusHost.requestExit())return;PREV=CUR||'home';CUR=h;render()}"
    assert old in source;source=source.replace(old,new,1)
    marker="  app.innerHTML='';app.appendChild(t.content.cloneNode(true));"
    assert marker in source;source=source.replace(marker,"  if(window.__AIPlusHost)window.__AIPlusHost.dispose();\n"+marker,1)
    marker='  wireForms();'
    replacement=marker+"\n  if(window.__AIPlusHost&&window.__AIPlusHost.hasRoute(rid)){window.__AIPlusHost.open(rid,document.getElementById('tool-workspace'),function(){go('"+entry['detailRoute']+"')})}"
    assert marker in source;source=source.replace(marker,replacement,1)
    source=source.replace("tool:'tools',course:","tool:'tools',work:'tools',course:",1)
    marker='  hdr.hidden=admin;ftr.hidden=admin;'
    assert marker in source;source=source.replace(marker,marker+"\n  if(bar)bar.hidden=window.__AIPlusHost.hasRoute(rid);",1)
    source=source.replace("var CUR='',PREV='home';","var CUR=window.__AIPlusInitialRoute||'',PREV='home';",1)
    source=source.replace('data-count="mod:close">12','data-count="mod:close">13')
    source=source.replace('window.scrollTo(0,0)',"window.scrollTo({top:0,behavior:'instant'})")
    assert len(re.findall(r'\bdata-tool\s',source))==77
    assert 'link03' not in source and 'link06' not in source and 'link.textContent=\'D02' not in source
    return source

def stage():
    tool=next(t for t in json.loads((ROOT/'catalog/tools.json').read_text()) if t['id']=='D02')
    assert tool['name']=='账表对账'
    version=tool['version'];folder=ROOT/'release/D02'/version
    runtime=folder/'runtime.json'
    if not runtime.is_file():raise SystemExit('原生版本runtime.json尚未生成；不使用旧独立页面替代，不修改官网。')
    payload=json.loads(runtime.read_text());assert payload['id']=='D02' and payload['version']==version and payload['name']==tool['name'] and payload['schema_version']==1
    files=[f'D02-{version}-离线包.zip',f'D02-{version}-源码.zip','虚构样例.xlsx','空白模板.csv','使用说明.md','财务规则.md','THIRD_PARTY_NOTICES.md']
    for filename in files:assert (folder/filename).is_file(),filename
    entry={'id':'D02','name':tool['name'],'version':version,'detailRoute':'tool-D02','workspaceRoute':'work-D02','runtime':f'app/static/tools/D02/{version}/runtime.json','sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'bytes':runtime.stat().st_size,'offlineSize':f'{(folder/files[0]).stat().st_size/1024/1024:.1f} MB'}
    subprocess.run(['node','--import','tsx','scripts/build-site-host.ts'],cwd=ROOT,check=True)
    base=(ROOT/'website/base-index.html').read_bytes()
    baseline=json.loads((ROOT/'website/base-manifest.json').read_text())
    assert hashlib.sha256(base).hexdigest()==baseline['sha256'],'Original website base changed without review'
    expected=[baseline['known_external_index_sha256']]
    deployed=ROOT/'website/deployed-site.json'
    if deployed.is_file():expected.append(json.loads(deployed.read_text())['site_sha256'])
    assert hashlib.sha256((SITE/'site/index.html').read_bytes()).hexdigest() in expected,'Website has unrelated changes; merge them before regeneration'
    source=native_document(base.decode(),entry,files,(ROOT/'integration/native-host.js').read_text())
    (STAGE/'site').mkdir(parents=True,exist_ok=True);(STAGE/'site/index.html').write_text(source)
    (STAGE/'site/registry.json').write_text(json.dumps([entry],ensure_ascii=False,indent=2)+'\n')
    app=native_streamlit_app((SITE/'app.py').read_text())
    (STAGE/'app.py').write_text(app);(STAGE/'requirements.txt').write_text('streamlit==1.50.0\n')
    (STAGE/'.streamlit').mkdir(exist_ok=True)
    config=(SITE/'.streamlit/config.toml').read_text()
    if '[server]' not in config:config+='\n[server]\nenableStaticServing = true\n'
    elif not re.search(r'\[server\]\s*enableStaticServing\s*=\s*true',config):raise SystemExit('现有server配置需要核验，不能自动覆盖')
    (STAGE/'.streamlit/config.toml').write_text(config)
    target=STAGE/'static/tools/D02'/version;target.mkdir(parents=True,exist_ok=True)
    for file in folder.iterdir():
        if file.is_file():shutil.copy2(file,target/file.name)
    print('原生官网已暂存；尚未发布：',STAGE)

def native_streamlit_app(app,index='site/index.html',registry='site/registry.json'):
    anchor='ROOT = Path(__file__).parent';assert anchor in app
    generated=app[:app.index(anchor)]+'''ROOT = Path(__file__).parent
import json
REGISTRY = json.loads((ROOT / "REGISTRY_PATH").read_text(encoding="utf-8"))
TOOLS = {r["id"]: r for r in REGISTRY}
selected = st.query_params.get("tool", "")
entry = TOOLS.get(selected)
document = (ROOT / "INDEX_PATH").read_text(encoding="utf-8")
if entry:
    initial = json.dumps(entry["workspaceRoute"]).replace("<", "\\\\u003c")
    document = document.replace("<script>window.__AIPlusRegistry", "<script>window.__AIPlusInitialRoute=" + initial + ";</script><script>window.__AIPlusRegistry", 1)
elif selected:
    st.info("该工具尚未开放，请从工具库选择已交付的工具。")
components.html(document, height=900, scrolling=True)
'''
    return generated.replace('REGISTRY_PATH',registry).replace('INDEX_PATH',index)

def apply():
    subprocess.run([sys.executable,str(ROOT/'scripts/check-d02-evidence.py')],cwd=ROOT,check=True)
    gate=STAGE/'acceptance.json'
    if not gate.is_file():raise SystemExit('缺少原生官网暂存验收证据，不发布。')
    evidence=json.loads(gate.read_text())
    required=['local_site_navigation','finance_same_results','downloads_hashes','offline','source_rebuild','rendered_product_ui']
    assert all(evidence.get(k) is True for k in required),'Incomplete delivery evidence'
    assert evidence['site_sha256']==hashlib.sha256((STAGE/'site/index.html').read_bytes()).hexdigest(),'Stale website evidence'
    for relative in ['app.py','requirements.txt','site/index.html','site/registry.json','.streamlit/config.toml']:
        target=SITE/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(STAGE/relative,target)
    shutil.copytree(STAGE/'static/tools',SITE/'static/tools',dirs_exist_ok=True)
    (ROOT/'website/deployed-site.json').write_text(json.dumps({'site_sha256':evidence['site_sha256'],'registry_sha256':hashlib.sha256((STAGE/'site/registry.json').read_bytes()).hexdigest()},indent=2)+'\n')
    print('已同步原生官网；须实际公开浏览器验证后才能accepted。')

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'stage'
    if mode=='stage':stage()
    elif mode=='apply':apply()
    else:raise SystemExit('仅支持stage/apply')
