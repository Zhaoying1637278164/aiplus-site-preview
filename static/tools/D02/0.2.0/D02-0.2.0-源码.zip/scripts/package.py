import sys,pathlib,zipfile
root=pathlib.Path.cwd();out=pathlib.Path(sys.argv[1]);version=out.name;tool=out.parent.name
def source_file(f):
 return (f.is_file() and f.suffix not in ['.zip','.pyc','.pyo']
         and not any(p in ['node_modules','__pycache__','.git'] for p in f.parts)
         and f.name not in ['.DS_Store','finance-reconciliation.md','upstream-tree.json'])
with zipfile.ZipFile(out/f'{tool}-{version}-离线包.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(out.iterdir()):
  if f.is_file() and f.suffix!='.zip':z.write(f,tool+'/'+f.name)
with zipfile.ZipFile(out/f'{tool}-{version}-源码.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['package.json','package-lock.json','tsconfig.json','README.md','工具总览.md','AGENTS.md','CLAUDE.md']:
  z.write(root/name,name)
 for folder in ['apps','packages','scripts','tests','docs','catalog','references','progress','website','tools/D02-账表对账','tools/D06-财务数据质量体检器','tools/D03-科目往来部门映射管理器']:
  for f in sorted((root/folder).rglob('*')):
   if source_file(f):z.write(f,str(f.relative_to(root)))
 z.write(out/'THIRD_PARTY_NOTICES.md','THIRD_PARTY_NOTICES.md')
