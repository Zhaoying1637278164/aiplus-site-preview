import {build} from 'esbuild';
import {mkdir,readFile,writeFile,copyFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync} from 'node:fs';
import {VERSION as D02_VERSION} from '../tools/D02-账表对账/src/version';
import {VERSION as D06_VERSION} from '../tools/D06-财务数据质量体检器/src/types';
import {example as qualityExample} from '../tools/D06-财务数据质量体检器/src/example';
import {sampleBytes} from '../tools/D06-财务数据质量体检器/src/sample-file';
import {VERSION as D03_VERSION} from '../tools/D03-科目往来部门映射管理器/src/types';
import {input as mappingInput,dictionary as mappingDictionary,mapping as mappingExample} from '../tools/D03-科目往来部门映射管理器/src/example';
import {sampleBytes as mappingSampleBytes} from '../tools/D03-科目往来部门映射管理器/src/sample-file';
import {encodeMapping} from '../tools/D03-科目往来部门映射管理器/src/plan';
import {workbookBytes} from '../packages/core/io';
import {leftExample,rightExample} from '../tools/D02-账表对账/src/example';
const id=process.argv[2]||'D02';if(!['D02','D03','D06'].includes(id))throw Error('尚未实现该工具，不能生成占位成品');
const VERSION=id==='D02'?D02_VERSION:id==='D03'?D03_VERSION:D06_VERSION;
const folder=id==='D02'?'tools/D02-账表对账':id==='D03'?'tools/D03-科目往来部门映射管理器':'tools/D06-财务数据质量体检器';
const name=id==='D02'?'账表对账':id==='D03'?'科目往来部门映射管理器':'财务数据质量体检器';
const out=path.resolve('release',id,VERSION);await mkdir(out,{recursive:true});
const options={outfile:'bundle.js',bundle:true,write:false,platform:'browser' as const,format:'iife' as const,target:['es2022'],minify:true,define:{'process.env.NODE_ENV':'"production"'},metafile:true,alias:{exceljs:'exceljs/lib/exceljs.bare.js'},inject:['packages/core/browser-globals.ts'],plugins:[{name:'browser-io-boundary',setup(b:import('esbuild').PluginBuild){b.onResolve({filter:/^(fs|crypto)$/},()=>({path:path.resolve('packages/core/browser-disabled.cjs')}));b.onResolve({filter:/^\.\.\/csv\/csv$/},()=>({path:path.resolve('packages/core/browser-csv-disabled.cjs')}))}}]};
const bundled=await build({...options,entryPoints:[folder+'/src/main.tsx']});
const js=bundled.outputFiles!.find(f=>f.path.endsWith('.js'))!.text;
const css=(id==='D02'?'body{margin:0;background:#fff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;}':'')+(bundled.outputFiles!.find(f=>f.path.endsWith('.css'))?.text||'');
const html=`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'; font-src 'none'; base-uri 'none'; form-action 'none'"><title>${id} ${name} · ${VERSION}</title><style>${css}</style></head><body><div id="root"></div><script>${js.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
let nativeManifest:{sha256:string;bytes:number}|undefined,nativePayload:string|undefined;
if(id==='D02'){
 const native=await build({...options,entryPoints:[folder+'/src/program.tsx'],globalName:'__AIPlusProgram'});
 const nativeJS=native.outputFiles!.find(f=>f.path.endsWith('.js'))!.text;
 nativePayload=JSON.stringify({schema_version:1,id,version:VERSION,name,css:native.outputFiles!.find(f=>f.path.endsWith('.css'))?.text||'',js:`(()=>{${nativeJS};window.__aiPlusLoadedProgram=__AIPlusProgram.program;})();`});
 const bytes=Buffer.byteLength(nativePayload);if(bytes>8*1024*1024)throw Error('原生工具程序超过8MB上限');
 nativeManifest={sha256:createHash('sha256').update(nativePayload).digest('hex'),bytes};
 Object.assign(bundled.metafile!.inputs,native.metafile!.inputs);
}
const registry=JSON.parse(await readFile('catalog/tools.json','utf8')) as {id:string;status:string;version:string}[];
const locks=JSON.parse(await readFile('catalog/release-locks.json','utf8')) as {releases:{tool:string;version:string;files:Record<string,string>}[]};
const locked=locks.releases.find(r=>r.tool===id&&r.version===VERSION);
if(locked){
 for(const [file,expected] of Object.entries(locked.files)){
  const bytes=await readFile(path.join(out,file));
  if(createHash('sha256').update(bytes).digest('hex')!==expected)throw Error(`冻结版本文件已变化：${id}/${VERSION}/${file}；不得覆盖历史交付包`);
 }
}
if((locked||registry.some(t=>t.id===id&&t.status==='accepted'&&t.version===VERSION))&&existsSync(path.join(out,'index.html'))){
 const existing=await readFile(path.join(out,'index.html'),'utf8');
 if(createHash('sha256').update(existing).digest('hex')!==createHash('sha256').update(html).digest('hex'))throw Error('该版本已验收；程序变化必须发布新版本，不能覆盖既有交付包');
 if(nativePayload&&existsSync(path.join(out,'runtime.json'))&&createHash('sha256').update(await readFile(path.join(out,'runtime.json'))).digest('hex')!==nativeManifest!.sha256)throw Error('原生程序已变化；必须发布新版本，不能覆盖既有交付包');
 console.log(`已重建并核对 ${id} ${VERSION}；已发布版本包保持不变（不受产品复审状态影响）`);process.exit(0);
}
await writeFile(path.join(out,'index.html'),html);
if(nativePayload)await writeFile(path.join(out,'runtime.json'),nativePayload);
if(id==='D02'){
await copyFile(folder+'/README.md',path.join(out,'使用说明.md'));
await copyFile(folder+'/财务规则.md',path.join(out,'财务规则.md'));
await copyFile(folder+'/参考来源.md',path.join(out,'参考来源.md'));
for(const [label,t] of [['左',leftExample],['右',rightExample]] as const){
 const csv='\uFEFF'+[t.headers,...t.rows.map(r=>t.headers.map(h=>r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
 await writeFile(path.join(out,`虚构${label}表.csv`),csv);
}
await writeFile(path.join(out,'空白模板.csv'),'\uFEFF单据号,金额,日期,币种\r\n');
await writeFile(path.join(out,'虚构样例.xlsx'),await workbookBytes([leftExample,rightExample].map((t,i)=>({name:i?'右表':'左表',headers:t.headers,rows:t.rows.map(r=>t.headers.map(h=>r.cells[h]))}))));
}else if(id==='D06'){
 await copyFile(folder+'/README.md',path.join(out,'使用说明.md'));
 for(const f of ['财务规则.md','参考来源.md'])await copyFile(folder+'/'+f,path.join(out,f));
 await writeFile(path.join(out,'空白模板.csv'),'\uFEFF'+qualityExample.headers.join(',')+'\r\n');
 const csv='\uFEFF'+[qualityExample.headers,...qualityExample.rows.map(r=>qualityExample.headers.map(h=>typeof r.cells[h]==='object'&&r.cells[h]!==null?'FORMULA_NOT_SUPPORTED':r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
 await writeFile(path.join(out,'虚构样例.csv'),csv);
 await writeFile(path.join(out,'虚构样例.xlsx'),await sampleBytes());
}
if(id==='D03'){
 for(const [f,destination] of [['README.md','使用说明.md'],['财务规则.md','财务规则.md'],['参考来源.md','参考来源.md']])await copyFile(folder+'/'+f,path.join(out,destination));
 for(const [t,label] of [[mappingInput,'原表'],[mappingDictionary,'字典']] as const){
  const csv='\uFEFF'+[t.headers,...t.rows.map(r=>t.headers.map(h=>typeof r.cells[h]==='object'&&r.cells[h]!==null?'FORMULA_NOT_SUPPORTED':r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
  await writeFile(path.join(out,`虚构${label}.csv`),csv);
  await writeFile(path.join(out,label==='原表'?'空白模板.csv':'字典模板.csv'),'\uFEFF'+t.headers.join(',')+'\r\n');
 }
 await writeFile(path.join(out,'虚构样例.xlsx'),await mappingSampleBytes());
 await writeFile(path.join(out,'虚构映射版本.json'),encodeMapping(mappingExample));
}
// Preserve notices from every runtime package actually included in the browser bundle.
const roots=new Set<string>();
for(const input of Object.keys(bundled.metafile!.inputs)){
 if(!input.startsWith('node_modules/'))continue;
 const parts=input.split('/');roots.add(parts.slice(0,parts[1].startsWith('@')?3:2).join('/'));
}
let notices='# 第三方声明\n\n本产品自主实现；以下从锁定源码构建的实际浏览器依赖。未使用ExcelJS预打包dist，故版本与打包输入逐项对应。\n';
for(const root of [...roots].sort()){
 const p=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));const files=(await readdir(root)).filter(n=>/^(licen[cs]e|copying|notice)(\.|$|-)/i.test(n));
 if(!files.length&&p.name!=='saxes')throw Error(`缺少依赖许可文本 ${root}`);
 notices+=`\n## ${p.name} ${p.version} (${p.license||'见文本'})\n`;
 if(p.name==='saxes')notices+=await readFile('references/saxes-5.0.1-LICENSE','utf8');
 for(const file of files)notices+=`\n### ${file}\n\n${await readFile(path.join(root,file),'utf8')}\n`;
}
notices+='\n## pako zlib port notice\n\n'+await readFile('node_modules/pako/lib/zlib/README','utf8');
await writeFile(path.join(out,'THIRD_PARTY_NOTICES.md'),notices);
await writeFile(path.join(out,'build-manifest.json'),JSON.stringify({tool:id,version:VERSION,native:nativeManifest,inputs:Object.keys(bundled.metafile!.inputs),runtime_packages:[...roots].sort()},null,2));
execFileSync('python3',['scripts/package.py',out]);
console.log(`已构建 ${out}`);
