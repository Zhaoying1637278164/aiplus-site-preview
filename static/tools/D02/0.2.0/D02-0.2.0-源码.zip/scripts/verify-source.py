"""Rebuild our own release source ZIP in an independent temporary checkout.

Usage: python3 scripts/verify-source.py release/D02/0.2.0
The evidence binds the exact source ZIP and compares both offline and website
programs. It does not claim product acceptance or run Windows/browser gates.
"""
import hashlib,json,pathlib,subprocess,sys,tempfile,zipfile
release=pathlib.Path(sys.argv[1]).resolve()
tool,version=release.parent.name,release.name
archive=release/f'{tool}-{version}-源码.zip'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
required=['package.json','package-lock.json','tsconfig.json','AGENTS.md','工具总览.md',
          'scripts/build.ts','scripts/package.py','docs/source-build.md',
          'packages/core/io.ts','packages/ui/tool-host.ts','website/base-index.html',
          'website/base-manifest.json','THIRD_PARTY_NOTICES.md']
if tool=='D02':required+=['tools/D02-账表对账/src/program.tsx','tools/D02-账表对账/src/main.tsx',
                          'tools/D02-账表对账/tests/workflow.test.ts','tests/d02-v2-input-browser.ts',
                          'tests/d02-native-site.ts','tests/d02-native-input.ts',
                          'scripts/check-d02-evidence.py','scripts/verify-source.py']
root=pathlib.Path(tempfile.mkdtemp(prefix=f'aiplus-{tool}-{version}-source-',dir='/private/tmp'))
with zipfile.ZipFile(archive) as z:
 names=z.namelist()
 for name in names:
  p=pathlib.PurePosixPath(name)
  if p.is_absolute() or '..' in p.parts:raise ValueError('unsafe source path')
  if any(x in p.parts for x in ['node_modules','.git','__pycache__']):raise ValueError('excluded directory included')
  if p.name.startswith('.env') or p.suffix in ['.pem','.key','.pyc']:raise ValueError('unexpected private/cache material')
 for name in required:
  if name not in names:raise ValueError(f'missing source component: {name}')
 if sum(i.file_size for i in z.infolist())>250*1024*1024:raise ValueError('source archive unexpectedly large')
 z.extractall(root)
commands=[['npm','ci','--offline','--ignore-scripts','--no-audit','--no-fund'],
          ['npm','test'],['npm','run','typecheck'],['npm','run','build','--',tool]]
logs=[]
for command in commands:
 print(' '.join(command),flush=True)
 r=subprocess.run(command,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 logs.append({'command':command,'exit_code':r.returncode,'output':r.stdout})
 if r.returncode:
  print(r.stdout);raise RuntimeError('source rebuild command failed')
files=['index.html']+(['runtime.json'] if (release/'runtime.json').exists() else [])
comparison={}
for name in files:
 expected=sha(release/name);actual=sha(root/'release'/tool/version/name)
 comparison[name]={'release_sha256':expected,'rebuilt_sha256':actual,'identical':expected==actual}
 if expected!=actual:raise RuntimeError(f'{name} differs from release')
evidence=pathlib.Path('progress/evidence')/tool/version
evidence.mkdir(parents=True,exist_ok=True)
(evidence/'source-rebuild-log.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2)+'\n')
(evidence/'source-rebuild.json').write_text(json.dumps({'tool':tool,'version':version,
 'source_zip_sha256':sha(archive),'independent_directory':str(root),'required_files_checked':required,
 'commands':[{'command':x['command'],'exit_code':x['exit_code']} for x in logs],
 'files':comparison,'product_acceptance':'separate gates required'},ensure_ascii=False,indent=2)+'\n')
print('Independent source rebuild identical:',', '.join(files),flush=True)
