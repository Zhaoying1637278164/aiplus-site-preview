import type {Table,SourceRow} from '../../../packages/core/types';
export const kinds=['invoices','payments','allocations'] as const;
export type Kind=typeof kinds[number];
export const labels:Record<Kind,string>={invoices:'应收单据',payments:'银行回款',allocations:'核销记录'};
export const headers:Record<Kind,string[]>={invoices:['应收ID','客户ID','客户名称','日期','到期日','币种','单位','含税口径','未结额','类型','原应收ID','依据'],payments:['收款ID','客户ID','客户名称','日期','币种','单位','含税口径','金额','类型','明确应收ID','原收款ID','依据'],allocations:['核销ID','收款ID','应收ID','金额','生效日','状态','原核销ID','依据']};
export type Data=Record<Kind,Table|null>;
export const emptyData=():Data=>({invoices:null,payments:null,allocations:null});
export interface Config{start:string;cutoff:string;precision:number;tolerance:string;window:number;mode:'明确关联'|'同客户ID';priority:'关联优先'|'日期优先'}
export const defaultConfig:Config={start:'2026-09-01',cutoff:'2026-09-30',precision:2,tolerance:'0.01',window:90,mode:'明确关联',priority:'关联优先'};
export interface Entry{id:string;customer:string;name:string;date:string;due:string;currency:string;unit:string;tax:string;amount:string|null;type:string;ref:string;explicit:string;source:SourceRow;status:'有效'|'异常隔离'|'未来'|'范围外';errors:string[];applied:string;remaining:string;adjustment:string}
export interface Allocation{id:string;payment:string;invoice:string;amount:string|null;date:string;state:string;reverse:string;basis:string;source:SourceRow;status:string;errors:string[];sources:SourceRow[]}
export interface Candidate{payment:string;invoice:string;reason:string;difference:string;days:number;ambiguous:boolean;sources:SourceRow[]}
export interface Group{key:string;customer:string;currency:string;unit:string;tax:string;receivable:string;invoiceApplied:string;open:string;invoiceIsolated:string;cash:string;cashApplied:string;unallocated:string;cashIsolated:string;futureInvoice:string;futureCash:string;invoiceResidual:string;cashResidual:string}
export interface Issue{kind:Kind;message:string;source:SourceRow}
export interface Run{app_version:string;rule_version:string;config:Config;invoices:Entry[];payments:Entry[];allocations:Allocation[];candidates:Candidate[];candidateTruncated:boolean;groups:Group[];issues:Issue[];unquantified:number}
export interface Event{id:string;time:string;action:string;detail:string}
export interface Session{schema_version:1;tool:'R03';app_version:string;rule_version:string;includes_data:boolean;config:Config;data:Data;events:Event[]}
