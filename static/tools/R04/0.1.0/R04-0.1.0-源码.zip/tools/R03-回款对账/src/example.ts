import {headers,labels,emptyData,type Kind,type Data} from './types';
import type {Table,Cell} from '../../../packages/core/types';
export function table(kind:Kind,rows:Cell[][],file='完全虚构样例.xlsx'):Table{return {file,sheet:labels[kind],headers:headers[kind],rows:rows.map((cells,i)=>({file,sheet:labels[kind],row:i+2,cells:Object.fromEntries(headers[kind].map((h,j)=>[h,cells[j]??null]))}))}}
export function example():Data{return {invoices:table('invoices',[
 ['A','C01','虚构晨光','2026-09-01','2026-09-15','CNY','元','含税','40','应收',null,'虚构应收余额'],
 ['B','C01','虚构晨光','2026-09-02','2026-09-20','CNY','元','含税','60','应收',null,'虚构应收余额'],
 ['C','C02','虚构山川','2026-09-05','2026-09-25','CNY','元','含税','100','应收',null,'虚构应收余额'],
 ['D','C03','同名客户','2026-09-05','2026-09-25','USD','元','不含税','50','应收',null,'虚构外币'],
 ['E','C04','同名客户','2026-09-05','2026-09-25','USD','元','不含税','50','应收',null,'不同客户ID']]),payments:table('payments',[
 ['P','C01','虚构晨光','2026-09-10','CNY','元','含税','100','收款',null,null,'虚构银行流水'],
 ['Q','C02','虚构山川','2026-09-12','CNY','元','含税','80','收款','C',null,'虚构部分回款'],
 ['F','C02','虚构山川','2026-09-20','CNY','元','含税','-20','退款',null,'Q','虚构退款批准'],
 ['NEXT','C02','虚构山川','2026-10-01','CNY','元','含税','20','收款','C',null,'虚构未来款']]),allocations:table('allocations',[
 ['X1','P','A','40','2026-09-10','确认',null,'人工分配第一票'],
 ['X2','P','B','60','2026-09-10','确认',null,'人工分配第二票'],
 ['X3','Q','C','50','2026-09-12','确认',null,'部分核销'],
 ['X4','F','C','-20','2026-09-20','确认','X3','退款逆转X3']])}}
export {emptyData};
