import type {Data,Kind,Config,Event} from './types';
export function invalidate(data:Data,reason:string):Data{const next=structuredClone(data);if(next.allocations)for(const r of next.allocations.rows)if(r.cells['状态']==='确认'){r.cells['状态']='失效';r.cells['依据']=String(r.cells['依据']??'')+'；失效原因：'+reason}return next}
export function replaceData(data:Data,kind:Kind,table:Data[Kind]):Data{const next={...data,[kind]:structuredClone(table)};return kind==='allocations'?next:invalidate(next,'替换'+kind+'资料')}
export function updateConfig(data:Data,previous:Config,next:Config):Data{return JSON.stringify(previous)===JSON.stringify(next)?data:invalidate(data,'参数/候选规则变化')}
export function event(action:string,detail:string):Event{return {id:crypto.randomUUID(),time:new Date().toISOString(),action,detail}}
