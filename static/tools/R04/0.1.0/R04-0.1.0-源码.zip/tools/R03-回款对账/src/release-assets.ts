import ExcelJS from 'exceljs';
import type {ReleaseAsset} from '../../../packages/core/release-assets';
import {kinds,headers,labels} from './types';
import {example} from './example';
import {stableZip} from './stable-zip';
export async function releaseAssets():Promise<ReleaseAsset[]>{const wb=new ExcelJS.Workbook();wb.created=wb.modified=new Date('2026-10-03T00:00:00Z');const data=example();for(const k of kinds){const ws=wb.addWorksheet(labels[k]);ws.addRow(headers[k]);for(const r of data[k]!.rows)ws.addRow(headers[k].map(h=>r.cells[h]))}return [{filename:'空白模板.csv',data:'\uFEFF'+headers.invoices.join(',')+'\r\n'},...kinds.filter(k=>k!=='invoices').map(k=>({filename:labels[k]+'模板.csv',data:'\uFEFF'+headers[k].join(',')+'\r\n'})),{filename:'虚构样例.xlsx',data:stableZip(new Uint8Array(await wb.xlsx.writeBuffer()))},...kinds.map(k=>({filename:'虚构'+labels[k]+'.csv',data:'\uFEFF'+[headers[k],...data[k]!.rows.map(r=>headers[k].map(h=>r.cells[h]??''))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n')}))]}
