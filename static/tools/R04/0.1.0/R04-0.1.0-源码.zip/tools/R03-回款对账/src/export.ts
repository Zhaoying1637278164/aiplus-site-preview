import {workbookBytes} from '../../../packages/core/io';
import {LIMITS} from '../../../packages/core/types';
import {kinds,labels,type Run,type Data,type Event} from './types';
export async function exportWorkbook(r:Run,data:Data,events:Event[]){const sheets=[
 {name:'参数与版本',headers:['项目','值'],rows:[['应用版本',r.app_version],['规则版本',r.rule_version],...Object.entries(r.config),['口径','人工核销底稿，不自动记账或判断收入；金额为十进制文本'],['不可量化行',r.unquantified],['候选截断',r.candidateTruncated]]},
 {name:'分组勾稽',headers:['客户ID','币种','单位','含税口径','应收净额','净核销','未核销','应收隔离','应收残差','收款全额','款核销','未分配','回款隔离','款残差','未来应收','未来款'],rows:r.groups.map(g=>[g.customer,g.currency,g.unit,g.tax,g.receivable,g.invoiceApplied,g.open,g.invoiceIsolated,g.invoiceResidual,g.cash,g.cashApplied,g.unallocated,g.cashIsolated,g.cashResidual,g.futureInvoice,g.futureCash])},
 ...(['invoices','payments'] as const).map(k=>({name:k==='invoices'?'逐票余额':'逐款余额',headers:['ID','客户ID','币种','单位','含税口径','日期','金额','状态','净核销','余额','红字调整','异常','来源文件','页签','原行'],rows:r[k].map(e=>[e.id,e.customer,e.currency,e.unit,e.tax,e.date,e.amount,e.status,e.applied,e.remaining,e.adjustment,e.errors.join('；'),e.source.file,e.source.sheet,e.source.row])})),
 {name:'候选解释',headers:['收款ID','应收ID','解释','余额差','日期差','歧义'],rows:r.candidates.map(c=>[c.payment,c.invoice,c.reason,c.difference,c.days,c.ambiguous?'多候选待确认':'单候选仍待确认'])},
 {name:'核销全记录',headers:['核销ID','收款ID','应收ID','金额','生效日','人工状态','计算状态','原核销ID','依据','异常','来源文件','页签','原行'],rows:r.allocations.map(a=>[a.id,a.payment,a.invoice,a.amount,a.date,a.state,a.status,a.reverse,a.basis,a.errors.join('；'),a.source.file,a.source.sheet,a.source.row])},
 {name:'核销来源索引',headers:['核销ID','来源文件','页签','原行'],rows:r.allocations.flatMap(a=>a.sources.map(s=>[a.id,s.file,s.sheet,s.row]))},
 {name:'异常待办',headers:['资料','问题','来源文件','页签','原行'],rows:r.issues.map(i=>[labels[i.kind],i.message,i.source.file,i.source.sheet,i.source.row])},
 ...kinds.filter(k=>data[k]).map(k=>({name:labels[k]+'原始资料',headers:['来源文件','页签','原行',...data[k]!.headers],rows:data[k]!.rows.map(s=>[s.file,s.sheet,s.row,...data[k]!.headers.map(h=>s.cells[h])])})),
 {name:'变更事件',headers:['事件ID','时间','操作','说明片段序号','说明'],rows:events.flatMap(e=>{const chunks=[];for(let n=0;n<Math.max(1,e.detail.length);n+=10000)chunks.push([e.id,e.time,e.action,n/10000+1,e.detail.slice(n,n+10000)]);return chunks})}];
 if(sheets.reduce((n,s)=>n+s.rows.length*s.headers.length,0)>1000000)throw Error('底稿超过100万单元格，请减少资料量');const split=sheets.flatMap(s=>{const out=[];for(let n=0;n<Math.max(1,s.rows.length);n+=LIMITS.rows)out.push({...s,name:s.name+(s.rows.length>LIMITS.rows?'-'+(n/LIMITS.rows+1):''),rows:s.rows.slice(n,n+LIMITS.rows)});return out});const bytes=await workbookBytes(split);if(bytes.length>LIMITS.bytes)throw Error('底稿超过10MB');return bytes}
