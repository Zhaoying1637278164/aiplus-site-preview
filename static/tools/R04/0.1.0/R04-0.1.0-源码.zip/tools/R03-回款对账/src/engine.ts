import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';
import {LIMITS,type SourceRow} from '../../../packages/core/types';
import {kinds,headers,type Config,type Data,type Entry,type Allocation,type Run,type Group} from './types';
import {VERSION,RULE_VERSION} from './version';
const D=Decimal.clone({precision:60});
const zero=()=>new D(0);
const get=(r:SourceRow,h:string,optional=false)=>optional&&(r.cells[h]===null||r.cells[h]==='')?'':text(r.cells[h]);
export function validateConfig(c:Config){date(c.start);date(c.cutoff);if(c.start>c.cutoff)throw Error('开始日不得晚于截止日');if(!Number.isInteger(c.precision)||c.precision<0||c.precision>6)throw Error('精度须为0–6');if(amount(c.tolerance).isNegative())throw Error('容差不得为负');if(!Number.isInteger(c.window)||c.window<0||c.window>3660)throw Error('日期窗口须为0–3660天');if(!['明确关联','同客户ID'].includes(c.mode)||!['关联优先','日期优先'].includes(c.priority))throw Error('候选规则无效')}
function money(r:SourceRow,h:string,c:Config){const v=amount(r.cells[h]);if(v.decimalPlaces()>c.precision)throw Error('金额超过指定精度，不静默舍入');return v.toString()}
const same=(a:Entry,b:Entry)=>a.customer===b.customer&&a.currency===b.currency&&a.unit===b.unit&&a.tax===b.tax;
const groupKey=(e:Entry)=>JSON.stringify([e.customer,e.currency,e.unit,e.tax]);
function index<T extends {id:string}>(xs:T[]){const map=new Map<string,T[]>();for(const x of xs){const list=map.get(x.id)||[];list.push(x);map.set(x.id,list)}return map}
const unique=<T>(map:Map<string,T[]>,id:string)=>{const rs=map.get(id);return rs?.length===1?rs[0]:undefined};
export function calculate(data:Data,config:Config):Run{
 validateConfig(config);
 for(const k of kinds){const t=data[k];if(t&&(t.rows.length>LIMITS.rows||t.headers.length>LIMITS.columns||headers[k].some(h=>!t.headers.includes(h))))throw Error('资料上限或必需字段无效：'+k)}
 const issues:Run['issues']=[];
 function parse(kind:'invoices'|'payments'):Entry[]{return (data[kind]?.rows||[]).map(source=>{
  const e:Entry={id:'',customer:'',name:'',date:'',due:'',currency:'',unit:'',tax:'',amount:null,type:'',ref:'',explicit:'',source,status:'有效',errors:[],applied:'0',remaining:'0',adjustment:'0'};
  const read=(fn:()=>void)=>{try{fn()}catch(x){e.errors.push((x as Error).message)}};
  for(const [field,h] of [['id',kind==='invoices'?'应收ID':'收款ID'],['customer','客户ID'],['name','客户名称'],['currency','币种'],['unit','单位'],['tax','含税口径'],['type','类型']] as const)read(()=>e[field]=get(source,h,field==='name'));
  read(()=>e.date=date(source.cells['日期']));if(kind==='invoices')read(()=>e.due=date(source.cells['到期日']));
  // Retain parseable raw amounts even when precision is invalid, for isolation totals.
  read(()=>e.amount=amount(source.cells[kind==='invoices'?'未结额':'金额']).toString());read(()=>{money(source,kind==='invoices'?'未结额':'金额',config)});
  read(()=>e.ref=get(source,kind==='invoices'?'原应收ID':'原收款ID',true));if(kind==='payments')read(()=>e.explicit=get(source,'明确应收ID',true));
  if(!/^[A-Z]{3}$/.test(e.currency))e.errors.push('币种须为大写三字母代码');if(!['元','分','万元'].includes(e.unit))e.errors.push('单位须为元/分/万元');if(!['含税','不含税'].includes(e.tax))e.errors.push('含税口径须明确');
  const positive=kind==='invoices'?'应收':'收款',negative=kind==='invoices'?'红字':'退款';
  if(![positive,negative].includes(e.type))e.errors.push('类型无效');
  if(e.amount!==null){if(e.type===positive&&new D(e.amount).lt(0)||e.type===negative&&!new D(e.amount).lt(0))e.errors.push('金额符号与类型不符')}
  if(e.type===negative){if(!e.ref)e.errors.push('红字/退款必须明确关联原记录');read(()=>{get(source,'依据')})}else if(e.ref)e.errors.push('普通应收/收款不可填原红字/退款关联');
  if(e.date>config.cutoff)e.status='未来';else if(kind==='payments'&&e.date&&e.date<config.start)e.status='范围外';return e;
 })}
 const invoices=parse('invoices'),payments=parse('payments');
 const allocations:Allocation[]=(data.allocations?.rows||[]).map(source=>{const a:Allocation={id:'',payment:'',invoice:'',amount:null,date:'',state:'',reverse:'',basis:'',source,status:'',errors:[],sources:[source]};const read=(fn:()=>void)=>{try{fn()}catch(e){a.errors.push((e as Error).message)}};
 for(const [f,h] of [['id','核销ID'],['payment','收款ID'],['invoice','应收ID'],['state','状态'],['reverse','原核销ID'],['basis','依据']] as const)read(()=>a[f]=get(source,h,f==='reverse'));
 read(()=>a.amount=money(source,'金额',config));read(()=>a.date=date(source.cells['生效日']));if(!['草稿','确认','撤销','失效'].includes(a.state))a.errors.push('核销状态无效');a.status=a.state;return a});
 const ii=index(invoices),pi=index(payments),ai=index(allocations);
 // Union raw references before validation. An error blocks the entire connected group.
 const parent=new Map<string,string>(),rank=new Map<string,number>();const find=(x:string):string=>{if(!parent.has(x))parent.set(x,x);let r=x;while(parent.get(r)!==r)r=parent.get(r)!;while(parent.get(x)!==x){const p=parent.get(x)!;parent.set(x,r);x=p}return r};const union=(a:string,b:string)=>{a=find(a);b=find(b);if(a===b)return;if((rank.get(a)||0)<(rank.get(b)||0))[a,b]=[b,a];parent.set(b,a);if((rank.get(a)||0)===(rank.get(b)||0))rank.set(a,(rank.get(a)||0)+1)};const node=(k:'i'|'p',e:Entry)=>k+':'+(e.id||'missing:'+e.source.row+':'+e.source.file+':'+e.source.sheet);
 invoices.forEach(e=>find(node('i',e)));payments.forEach(e=>find(node('p',e)));
 for(const [k,xs] of [['i',invoices],['p',payments]] as const){for(const e of xs){if(e.status==='有效'&&e.ref)union(node(k,e),k+':'+e.ref);if(e.id&&(k==='i'?ii:pi).get(e.id)!.length>1)e.errors.push('重复ID整组阻塞：'+e.id)}}
 for(const p of payments)if(p.status==='有效'&&p.explicit){union(node('p',p),'i:'+p.explicit);const i=unique(ii,p.explicit);if(!i||i.status!=='有效'||i.type!=='应收'||!same(p,i))p.errors.push('明确应收关联ID无效/重复或口径不同')}
 for(const a of allocations){if(a.state!=='确认'||a.date>config.cutoff)continue;union('p:'+a.payment,'i:'+a.invoice);if(a.reverse){const b=unique(ai,a.reverse);if(b){union('p:'+a.payment,'p:'+b.payment);union('i:'+a.invoice,'i:'+b.invoice)}}}
 const blocked=new Set<string>();const block=(k:'i'|'p',id:string)=>blocked.add(find(k+':'+id));
 // Validate negative entries, compute invoice adjusted capacities and refund gross limits.
 for(const [k,xs] of [['i',invoices],['p',payments]] as const){for(const e of xs){if(e.status!=='有效')continue;if(e.errors.length)blocked.add(find(node(k,e)));if(e.type===(k==='i'?'红字':'退款')){const orig=unique(k==='i'?ii:pi,e.ref);if(!orig||orig.type!==(k==='i'?'应收':'收款')||orig.status!=='有效'||orig.errors.length||!same(e,orig)||e.date<orig.date)e.errors.push('负数关联原记录无效/口径或日期不一致');if(e.errors.length)blocked.add(find(node(k,e)))}}
  const reductions=new Map<string,Decimal>();for(const e of xs)if(e.ref&&e.type===(k==='i'?'红字':'退款')&&e.status==='有效'&&e.amount!==null)reductions.set(e.ref,(reductions.get(e.ref)||zero()).plus(e.amount));
  for(const orig of xs.filter(e=>e.type===(k==='i'?'应收':'收款')&&e.status==='有效'&&e.amount!==null)){const reduction=reductions.get(orig.id)||zero();if(reduction.abs().gt(orig.amount!)){orig.errors.push('红字/退款累计超过原金额');block(k,orig.id)}if(k==='i')orig.adjustment=reduction.toString()}
 }
 const pairCounts=new Map<string,number>();for(const a of allocations)if(a.state==='确认'&&a.date<=config.cutoff){const key=JSON.stringify([a.payment,a.invoice]);pairCounts.set(key,(pairCounts.get(key)||0)+1)}
 const redSources=new Map<string,SourceRow[]>();for(const i of invoices)if(i.type==='红字'&&i.status==='有效'){const rs=redSources.get(i.ref)||[];rs.push(i.source);redSources.set(i.ref,rs)}
 for(const a of allocations){const p=unique(pi,a.payment),i=unique(ii,a.invoice);if(p)a.sources.push(p.source);if(i){a.sources.push(i.source);a.sources.push(...(redSources.get(i.id)||[]))}if(a.reverse){const original=unique(ai,a.reverse);if(original){a.sources.push(original.source);const op=unique(pi,original.payment);if(op)a.sources.push(op.source)}}if(a.state!=='确认'){if(a.errors.length)a.status='记录错误';continue}if(a.date>config.cutoff){a.status='未来';continue}
  if(!p||!i||p.status!=='有效'||i.status!=='有效'||p.errors.length||i.errors.length||i.type!=='应收')a.errors.push('票款关联无效、重复、未来或范围外');
  if(p&&i&&!same(p,i))a.errors.push('客户/币种/单位/含税口径不一致');
  if(a.date<config.start||p&&a.date<p.date||i&&a.date<i.date)a.errors.push('核销日期早于范围或票款日期');
  if(a.id&&ai.get(a.id)!.length>1)a.errors.push('重复核销ID');
  if((pairCounts.get(JSON.stringify([a.payment,a.invoice]))||0)>1)a.errors.push('重复票款分配关系');
  if(a.amount!==null){if(p?.type==='收款'){if(new D(a.amount).lte(0)||a.reverse)a.errors.push('普通核销须正数且不可填逆转ID')}else if(p?.type==='退款'){
    const orig=unique(ai,a.reverse);if(!new D(a.amount).lt(0)||!orig||orig.state!=='确认'||orig.date>config.cutoff||orig.date>a.date||orig.invoice!==a.invoice||orig.payment!==p.ref||orig.amount===null||!new D(orig.amount).gt(0))a.errors.push('退款必须负数且关联有效原核销');
   }}else a.errors.push('缺失/非法核销金额');
  if(a.errors.length)block('p',a.payment);
 }
 const current=allocations.filter(a=>a.state==='确认'&&a.date<=config.cutoff);
 const psums=new Map<string,Decimal>(),isums=new Map<string,Decimal>(),rsums=new Map<string,Decimal>();for(const a of current)if(a.amount!==null){psums.set(a.payment,(psums.get(a.payment)||zero()).plus(a.amount));isums.set(a.invoice,(isums.get(a.invoice)||zero()).plus(a.amount));if(a.reverse)rsums.set(a.reverse,(rsums.get(a.reverse)||zero()).plus(a.amount))}
 // Capacity checks use all confirmed members so no input-order partial success is possible.
 for(const p of payments.filter(x=>x.status==='有效'&&x.amount!==null)){const sum=psums.get(p.id)||zero();if(p.type==='收款'&&(sum.gt(p.amount!)||sum.lt(0))||p.type==='退款'&&(sum.lt(p.amount!)||sum.gt(0))){p.errors.push('核销超额或方向错误');block('p',p.id)}}
 const timelines=new Map<string,Map<string,{allocated:Decimal;adjusted:Decimal}>>();const tick=(id:string,day:string,allocated:string,adjusted:string)=>{const days=timelines.get(id)||new Map<string,{allocated:Decimal;adjusted:Decimal}>();const t=days.get(day)||{allocated:zero(),adjusted:zero()};t.allocated=t.allocated.plus(allocated);t.adjusted=t.adjusted.plus(adjusted);days.set(day,t);timelines.set(id,days)};for(const a of current)if(a.amount!==null)tick(a.invoice,a.date,a.amount,'0');for(const i of invoices)if(i.status==='有效'&&i.type==='红字'&&i.amount!==null)tick(i.ref,i.date,'0',i.amount);
 for(const i of invoices.filter(x=>x.status==='有效'&&x.type==='应收'&&x.amount!==null)){let cumulative=zero(),capacity=new D(i.amount!);for(const [day,values] of [...(timelines.get(i.id)||new Map())].sort((a,b)=>a[0].localeCompare(b[0]))){cumulative=cumulative.plus(values.allocated);capacity=capacity.plus(values.adjusted);if(cumulative.gt(capacity)||cumulative.lt(0)){i.errors.push('按生效日累计核销超额/逆转超额：'+day);block('i',i.id);break}}const sum=isums.get(i.id)||zero();if(sum.gt(new D(i.amount!).plus(i.adjustment))||sum.lt(0)){i.errors.push('应收核销超额或逆转超额');block('i',i.id)}}
 for(const orig of current.filter(a=>a.amount!==null&&new D(a.amount).gt(0))){const reverse=rsums.get(orig.id)||zero();if(reverse.abs().gt(orig.amount!)){orig.errors.push('累计逆转超过原核销额');block('p',orig.payment)}}
 for(const [k,xs] of [['i',invoices],['p',payments]] as const){for(const e of xs){if(e.status==='有效'&&blocked.has(find(node(k,e)))){e.status='异常隔离';if(!e.errors.length)e.errors.push('同一关联组存在异常，整组隔离')}for(const message of e.errors)issues.push({kind:k==='i'?'invoices':'payments',message,source:e.source})}}
 for(const a of allocations){if(a.state==='确认'&&a.date<=config.cutoff){a.status=blocked.has(find('p:'+a.payment))?'阻塞':'有效';if(a.status==='阻塞'&&!a.errors.length)a.errors.push('同一关联组存在异常，未采用此核销')}for(const message of a.errors)issues.push({kind:'allocations',message,source:a.source})}
 const valid=allocations.filter(a=>a.status==='有效'),vps=new Map<string,Decimal>(),vis=new Map<string,Decimal>();for(const a of valid){vps.set(a.payment,(vps.get(a.payment)||zero()).plus(a.amount!));vis.set(a.invoice,(vis.get(a.invoice)||zero()).plus(a.amount!))}
 for(const p of payments){if(p.status==='有效'&&p.amount!==null){p.applied=(vps.get(p.id)||zero()).toString();p.remaining=new D(p.amount).minus(p.applied).toString()}}
 for(const i of invoices){if(i.status==='有效'&&i.amount!==null){if(i.type==='应收'){i.applied=(vis.get(i.id)||zero()).toString();i.remaining=new D(i.amount).plus(i.adjustment).minus(i.applied).toString()}else i.remaining='0'}}
 const groups=new Map<string,Group>();const g=(e:Entry)=>{const key=groupKey(e);if(!groups.has(key))groups.set(key,{key,customer:e.customer||'缺失客户ID',currency:e.currency||'缺失币种',unit:e.unit||'缺失单位',tax:e.tax||'缺失含税口径',receivable:'0',invoiceApplied:'0',open:'0',invoiceIsolated:'0',cash:'0',cashApplied:'0',unallocated:'0',cashIsolated:'0',futureInvoice:'0',futureCash:'0',invoiceResidual:'0',cashResidual:'0'});return groups.get(key)!};
 const add=(x:Group,k:keyof Group,v:string)=>x[k]=new D(x[k]).plus(v).toString();
 for(const i of invoices){if(i.amount===null)continue;const x=g(i);if(i.status==='未来'){add(x,'futureInvoice',i.amount);continue}add(x,'receivable',i.amount);if(i.status==='异常隔离')add(x,'invoiceIsolated',i.amount);else{add(x,'invoiceApplied',i.applied);add(x,'open',i.remaining)}}
 for(const p of payments){if(p.amount===null||p.status==='范围外')continue;const x=g(p);if(p.status==='未来'){add(x,'futureCash',p.amount);continue}add(x,'cash',p.amount);if(p.status==='异常隔离')add(x,'cashIsolated',p.amount);else{add(x,'cashApplied',p.applied);add(x,'unallocated',p.remaining)}}
 for(const x of groups.values()){x.invoiceResidual=new D(x.receivable).minus(x.invoiceApplied).minus(x.open).minus(x.invoiceIsolated).toString();x.cashResidual=new D(x.cash).minus(x.cashApplied).minus(x.unallocated).minus(x.cashIsolated).toString()}
 const candidates:Run['candidates']=[];let candidateTruncated=false;
 const grouped=new Map<string,Entry[]>();for(const i of invoices.filter(i=>i.status==='有效'&&i.type==='应收'&&new D(i.remaining).gt(0))){const key=groupKey(i);const list=grouped.get(key)||[];list.push(i);grouped.set(key,list)}
 let comparisons=0;outer:for(const p of payments.filter(p=>p.status==='有效'&&p.type==='收款'&&new D(p.remaining).gt(0))){for(const i of config.mode==='明确关联'?(ii.get(p.explicit)||[]).filter(i=>i.status==='有效'&&i.type==='应收'&&same(p,i)&&new D(i.remaining).gt(0)):(grouped.get(groupKey(p))||[])){if(++comparisons>100000){candidateTruncated=true;break outer}const days=Math.round(Math.abs(Date.parse(p.date)-Date.parse(i.date))/86400000);if(days>config.window)continue;const difference=new D(p.remaining).minus(i.remaining);const linked=p.explicit===i.id;if(config.mode==='明确关联'&&!linked)continue;if(candidates.length>=5000){candidateTruncated=true;break outer}candidates.push({payment:p.id,invoice:i.id,reason:(linked?'明确应收ID相等':'同客户ID与口径一致')+'；日期差'+days+'天；'+(difference.abs().lte(config.tolerance)?'金额在候选容差内':'允许人工部分分配')+'；仅候选，未核销',difference:difference.toString(),days,ambiguous:false,sources:[p.source,i.source]})}}
 const candidateCounts=new Map<string,number>();for(const c of candidates)candidateCounts.set(c.payment,(candidateCounts.get(c.payment)||0)+1);candidates.forEach(c=>c.ambiguous=(candidateCounts.get(c.payment)||0)>1);
 candidates.sort((a,b)=>config.priority==='日期优先'?a.days-b.days:Number(!a.reason.startsWith('明确'))-Number(!b.reason.startsWith('明确'))||a.days-b.days);
 return {app_version:VERSION,rule_version:RULE_VERSION,config:{...config},invoices,payments,allocations,candidates,candidateTruncated,groups:[...groups.values()],issues,unquantified:[...invoices,...payments].filter(e=>e.amount===null).length};
}
