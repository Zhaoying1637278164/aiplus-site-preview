import {workbookBytes} from '../../../packages/core/io';
import type {ReleaseAsset} from '../../../packages/core/release-assets';
import {headers,labels,kinds} from './types';
import {example} from './example';
const csv=(rows:unknown[][])=>'\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
export async function releaseAssets():Promise<ReleaseAsset[]>{const d=example();return [
{filename:'空白模板.csv',data:csv([headers.receivables])},
...kinds.filter(k=>k!=='receivables').map(k=>({filename:labels[k]+'模板.csv',data:csv([headers[k]])})),
{filename:'中文多资料模板.xlsx',data:await workbookBytes(kinds.map(k=>({name:labels[k],headers:headers[k],rows:[]})))},
{filename:'虚构样例.xlsx',data:await workbookBytes(kinds.map(k=>({name:labels[k],headers:headers[k],rows:d[k]!.rows.map(r=>headers[k].map(h=>r.cells[h]))})))},
...kinds.map(k=>({filename:'虚构'+labels[k]+'.csv',data:csv([headers[k],...d[k]!.rows.map(r=>headers[k].map(h=>r.cells[h]))])}))];}
