import {labels,kinds,type Event} from './types';
import type {Table} from '../../../packages/core/types';
export function eventSummary(e:Event):string{
 let v:any;try{v=JSON.parse(e.detail)}catch{return e.detail.length>100?e.action+'；完整内容见详情':e.detail;}
 if(!v||typeof v!=='object')return e.action+'；完整内容见详情';
 if(e.action==='修改工作口径')return '截止 '+v.before?.cutoff+' → '+v.after?.cutoff+'；精度 '+v.before?.precision+' → '+v.after?.precision+'；容差 '+v.before?.tolerance+' → '+v.after?.tolerance;
 if(e.action==='记录复核')return '复核人 '+String(v.person??'')+'；修订 '+String(v.revision??'')+'；依据见详情';
 const tableSummary=(before:Table|null,after:Table|null)=>{const b=before?.rows?.length??0,a=after?.rows?.length??0;return `${b} → ${a} 行；来源 ${after?.file||before?.file||'未提供'}`;};
 if(e.action.startsWith('替换'))return tableSummary(v.before,v.after);
 if(e.action==='载入虚构样例')return kinds.map(k=>labels[k]+' '+(v.after?.[k]?.rows?.length??0)+' 行').join('；');
 if(e.action==='移除比较版本')return '移除 '+String(v.name??'')+'；原始版本仍保留在事件详情与底稿';
 return e.action+'；完整依据见详情';
}
