import type {Table,SourceRow} from '../../../packages/core/types';
export const kinds=['receivables','assignments','parameters','books','changes'] as const;
export type Kind=typeof kinds[number];
export const labels:Record<Kind,string>={receivables:'应收截止余额',assignments:'评估分配',parameters:'损失参数',books:'独立账面准备',changes:'准备变动'};
export const headers:Record<Kind,string[]>={
receivables:['主体','客户ID','客户名称','单据ID','截止日','币种','单位','含税口径','余额','时点确认','来源依据'],
assignments:['主体','客户ID','单据ID','评估方式','参数ID','参数版本','个别损失金额','评估依据','确认状态'],
parameters:['参数ID','参数版本','分组名称','评估方式','主体','币种','单位','含税口径','损失率格式','损失率','生效起日','生效止日','审批状态','批准日','批准依据','企业适用资格','资格依据','适用条件','条件依据','减值口径','外部评估提供','评估依据'],
books:['主体','币种','单位','含税口径','期初日','期末日','期初准备','期末准备','期初来源','期末来源','变动声明'],
changes:['变动ID','主体','币种','单位','含税口径','类型','有符号金额','生效日','审批状态','批准日','依据']};
export type Data=Record<Kind,Table|null>;
export const emptyData=():Data=>({receivables:null,assignments:null,parameters:null,books:null,changes:null});
export interface Config {start:string;cutoff:string;precision:number;tolerance:string}
export const defaultConfig:Config={start:'2026-09-01',cutoff:'2026-09-30',precision:2,tolerance:'0.01'};
export interface Scope {entity:string;currency:string;unit:string;tax:string}
export interface Issue {kind:Kind;index:number;message:string;source:SourceRow}
export interface Detail extends Scope {key:string;customer:string;name:string;document:string;balance:string|null;method:string;parameter:string;group:string;exact:string|null;provision:string|null;rounding:string|null;status:string;errors:string[];sources:SourceRow[]}
export interface Group extends Scope {key:string;group:string;parameter:string;base:string;exact:string;provision:string;residual:string;count:number}
export interface Movement extends Scope {id:string;type:string;amount:string|null;status:string;errors:string[];source:SourceRow}
export interface Summary extends Scope {key:string;positive:string;negative:string;blocked:string;unknown:number;computed:string;target:string|null;opening:string|null;closing:string|null;validMovement:string;bridge:string|null;bridgeDifference:string|null;targetDifference:string|null;status:string;book:SourceRow|null}
export interface Run {config:Config;details:Detail[];groups:Group[];movements:Movement[];summaries:Summary[];issues:Issue[]}
export interface Event {id:string;time:string;action:string;detail:string;revision?:number}
export interface Review {revision:number;time:string;person:string;basis:string}
export interface Snapshot {name:string;time:string;data:Data;config:Config}
export interface Session {schema_version:1;tool:'R05';app_version:string;rule_version:string;contains_data:boolean;config:Config;data:Data;events:Event[];reviews:Review[];snapshots:Snapshot[];revision:number}
export const scopeKey=(s:Scope)=>JSON.stringify([s.entity,s.currency,s.unit,s.tax]);
export const documentKey=(entity:string,customer:string,document:string)=>JSON.stringify([entity,customer,document]);
