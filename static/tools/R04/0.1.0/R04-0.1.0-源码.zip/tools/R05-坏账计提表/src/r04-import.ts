import type {Table,Cell} from '../../../packages/core/types';
import {date,text} from '../../../packages/core/value';
import {headers} from './types';
import {validateTable} from './validate';
/** Explicit file adapter only. No dependency on R04 runtime/state. */
export function fromR04(t:Table,entity:string,cutoff:string,confirmed:boolean):Table{
 if(!confirmed)throw Error('请明确确认R04输出的截止时点、主体、客户/单据ID与币种单位含税口径');text(entity);date(cutoff);if(!['id','customer','name','currency','unit','tax','balance','status'].every(h=>t.headers.includes(h)))throw Error('不是本版支持的R04逐票勾稽静态表，请使用本款中文模板');
 if(t.rows.some(r=>Object.values(r.cells).some(v=>v!==null&&typeof v==='object')))throw Error('R04资料含公式或缓存，不接受');
 const rawHeaders=t.headers.map(h=>'R04原列_'+h);const out:Table={file:t.file,sheet:t.sheet,headers:[...headers.receivables,...rawHeaders],rows:t.rows.map(r=>{const get=(h:string)=>r.cells[h]??null;const original=Object.fromEntries(t.headers.map(h=>['R04原列_'+h,get(h)]));const valid=['正应收','零余额','负余额'].includes(String(get('status')));return {...r,cells:{...original,'主体':entity,'客户ID':get('customer'),'客户名称':get('name'),'单据ID':get('id'),'截止日':cutoff,'币种':get('currency'),'单位':get('unit'),'含税口径':get('tax'),'余额':get('balance'),'时点确认':valid?'已确认':'未确认','来源依据':`用户明确确认R04截止输出；原状态=${String(get('status')??'空')}；${r.file}/${r.sheet}/原行${r.row}`}}})};validateTable(out,'receivables');return out;
}
