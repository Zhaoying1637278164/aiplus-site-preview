import type {Table,Cell} from '../../../packages/core/types';
export const kinds=['orders','receipts','invoices','links'] as const;
export type Kind=typeof kinds[number];
export const common=['行ID','主体','供应商ID','供应商名称','物料ID','币种','数量单位','金额单位','含税口径','业务日期','数量','单价','金额'] as const;
export const fields:Record<Kind,readonly string[]>={orders:common,receipts:[...common,'角色','原行ID','批准依据'],invoices:[...common,'角色','原行ID','批准依据'],links:['关联ID','订单行ID','收货行ID','收货数量','收货金额','发票行ID','发票数量','发票金额','批准依据']};
export interface Input {table:Table;mapping:Record<string,string>}
export interface Conversion {id:string;material:string;from:string;to:string;factor:string;start:string;end:string;approved:boolean;basis:string}
export interface Price {id:string;order:string;price:string;date:string;approved:boolean;basis:string}
export interface Rule {cutoff:string;scope:string;confirmed:boolean;precision:number;qtyPrecision:number;amountTolerance:string;qtyTolerance:string;conversions:Conversion[];prices:Price[]}
export interface Correction {kind:Kind;index:number;field:string;before:Cell;after:string;reason:string}
export interface Snapshot {rule:Rule;inputs:Partial<Record<Kind,Input>>;corrections:Correction[];revision:number}
export interface Work extends Snapshot {manual:Record<string,string>[];baseline:(Snapshot&{manual:Record<string,string>[]})|null;reviews:Record<string,{note:string;revision:number}>;events:{revision:number;action:string;time:string;before?:unknown;after?:unknown}[]}
export const emptyWork=():Work=>({rule:{cutoff:'2026-09-30',scope:'',confirmed:false,precision:2,qtyPrecision:3,amountTolerance:'0.01',qtyTolerance:'0',conversions:[],prices:[]},inputs:{},manual:[],corrections:[],revision:0,baseline:null,reviews:{},events:[]});
export interface Parsed {kind:Kind;index:number;id:string;node:string;cells:Record<string,Cell>;source:string;valid:boolean;future:boolean;entity:string;supplier:string;material:string;currency:string;unit:string;moneyUnit:string;tax:string;day:string;qty:string|null;price:string|null;amount:string|null;role:string;original:string}
export interface Issue {kind:Kind|'rule';index:number;id:string;message:string;source:string;blocking:boolean}
export interface Allocation {id:string;index:number;order:string;receipt:string;invoice:string;receiptQty:string|null;receiptAmount:string|null;invoiceQty:string|null;invoiceAmount:string|null;receiptFactor:string|null;invoiceFactor:string|null;receiptConverted:string|null;invoiceConverted:string|null;status:string;source:string}
export interface OrderResult {id:string;source:string;group:string;orderQty:string|null;originalAmount:string|null;price:string|null;priceVersion:string;expectedAmount:string|null;receiptQty:string|null;invoiceQty:string|null;receiptAmount:string|null;invoiceAmount:string|null;undelivered:string|null;invoicedUnreceived:string|null;receiptQtyDelta:string|null;invoiceQtyDelta:string|null;receiptAmountDelta:string|null;invoiceAmountDelta:string|null;invoiceReceiptAmountDelta:string|null;receiptUnitPrice:string|null;invoiceUnitPrice:string|null;receiptUnitPriceDelta:string|null;invoiceUnitPriceDelta:string|null;receiptPriceDelta:string|null;invoicePriceDelta:string|null;status:string}
export interface Remainder {kind:Kind;id:string;index:number;source:string;group:string;role:string;qty:string|null;amount:string|null;allocatedQty:string|null;allocatedAmount:string|null;remainingQty:string|null;remainingAmount:string|null;status:string}
export interface Result {rows:Parsed[];issues:Issue[];allocations:Allocation[];orders:OrderResult[];remainders:Remainder[];groups:Record<string,unknown>[]}
