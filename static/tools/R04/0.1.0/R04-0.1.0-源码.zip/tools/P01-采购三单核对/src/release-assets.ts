import Papa from 'papaparse';
import {workbookBytes} from '../../../packages/core/io';
import {example} from './example';
import {fields,kinds} from './types';
import {encode} from './session';
export async function releaseAssets(){const w=example();const labels={orders:'采购订单',receipts:'收货退货',invoices:'发票红字',links:'关联分配'};return [{filename:'空白模板.csv',data:'\uFEFF'+Papa.unparse({fields:[...fields.orders],data:[]})},...kinds.map(k=>({filename:`${labels[k]}-空白模板.csv`,data:'\uFEFF'+Papa.unparse({fields:[...fields[k]],data:[]})})),...kinds.map(k=>({filename:`虚构-${labels[k]}.csv`,data:'\uFEFF'+Papa.unparse({fields:[...fields[k]],data:w.inputs[k]!.table.rows.map(r=>fields[k].map(f=>r.cells[f]))})})),{filename:'虚构样例.xlsx',data:await workbookBytes(kinds.map(k=>({name:labels[k],headers:[...fields[k]],rows:w.inputs[k]!.table.rows.map(r=>fields[k].map(f=>r.cells[f]))})))},{filename:'虚构完整工作.json',data:encode(w,true)}]}
