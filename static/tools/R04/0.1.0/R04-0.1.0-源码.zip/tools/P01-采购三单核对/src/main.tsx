import {program} from './program';
program.mount({container:document.getElementById('root')!,mode:'offline'});
