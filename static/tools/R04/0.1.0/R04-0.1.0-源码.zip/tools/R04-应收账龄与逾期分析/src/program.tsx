import React from 'react';
import {createRoot} from 'react-dom/client';
import type {ToolProgram} from '../../../packages/ui/tool-host';
import {emptyWork,type Work} from './types';
import {App} from './app';
import {VERSION} from './version';
export const program:ToolProgram={id:'R04',name:'应收账龄与逾期分析',version:VERSION,mount(context){const root=createRoot(context.container);let work:Work=emptyWork(),disposed=false;const onWork=(w:Work)=>{work=w};const requestExit=()=>!Object.keys(work.inputs).length&&!work.events.length||window.confirm('当前内存工作关闭后清除，请确认已下载需要的工作。退出？');const dispose=()=>{if(disposed)return;disposed=true;root.unmount();work=emptyWork();context.container.replaceChildren();window.removeEventListener('beforeunload',beforeUnload);window.removeEventListener('pagehide',pagehide)};const beforeUnload=(e:BeforeUnloadEvent)=>{if(Object.keys(work.inputs).length){e.preventDefault();e.returnValue=''}};const pagehide=()=>dispose();window.addEventListener('beforeunload',beforeUnload);window.addEventListener('pagehide',pagehide);root.render(<App onWork={onWork} onExit={()=>{if(!requestExit())return;dispose();context.onExit?.()}}/>);return {requestExit,dispose}}};
