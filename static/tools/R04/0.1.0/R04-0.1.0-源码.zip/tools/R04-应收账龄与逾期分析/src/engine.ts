import Decimal from 'decimal.js';
import {amount,date,text} from '../../../packages/core/value';
import type {Cell,SourceRow} from '../../../packages/core/types';
import type {Rule,Snapshot,Kind,Issue,Ticket,Result,Group} from './types';
export function days(end:string,start:string){date(end);date(start);return Math.round((Date.parse(end+'T00:00:00Z')-Date.parse(start+'T00:00:00Z'))/86400000)}
export function validateRule(r:Rule){
 if(!r||!['snapshot','movement'].includes(r.mode)||!['occurrence','due'].includes(r.basis))throw Error('来源模式/分档起点无效');
 date(r.cutoff);date(r.snapshotDate);date(r.openingDate);
 if(typeof r.confirmed!=='boolean'||typeof r.scope!=='string'||r.scope.length>10000)throw Error('范围确认无效');
 if(!Number.isInteger(r.precision)||r.precision<0||r.precision>6||amount(r.tolerance).lt(0))throw Error('精度/容差无效');
 if(!Array.isArray(r.bands)||r.bands.length<1||r.bands.length>20)throw Error('区间须1–20档');let next=0;const labels=new Set<string>();
 r.bands.forEach((b,i)=>{if(!b||typeof b.label!=='string'||!b.label.trim()||labels.has(b.label)||b.label.length>100||b.min!==next||!Number.isSafeInteger(b.min)||b.min<0)throw Error('区间名称重复或边界有空洞/重叠');labels.add(b.label);if(i===r.bands.length-1){if(b.max!==null)throw Error('末档须无上限')}else{if(b.max===null||!Number.isSafeInteger(b.max)||b.max<b.min)throw Error('区间上限无效');next=b.max+1}});
}
export function canonical(s:Snapshot,kind:Kind):{source:SourceRow;cells:Record<string,Cell>}[]{const input=s.inputs[kind];if(!input)return [];return input.table.rows.map((source,index)=>{const cells:Record<string,Cell>={};for(const [field,col] of Object.entries(input.mapping))cells[field]=source.cells[col]??null;for(const c of s.corrections)if(c.kind===kind&&c.index===index)cells[c.field]=c.after;return {source,cells}})}
function append<T>(map:Map<string,T[]>,key:string,v:T){const items=map.get(key);if(items)items.push(v);else map.set(key,[v])}
const optionalDate=(v:Cell):string|null=>v===null||v===''?null:date(v);
interface Rec {index:number;source:SourceRow;id:string;ticket:string;customer:string;name:string;type:string;effective:string;occurrence:string|null;due:string|null;currency:string;unit:string;tax:string;money:Decimal;reason:string;valid:boolean}
interface Ev {index:number;source:SourceRow;id:string;ticket:string;type:string;effective:string;money:Decimal;currency:string;unit:string;tax:string;link:string;reason:string;valid:boolean}
export function calculate(s:Snapshot):Result {
 const issues:Issue[]=[],tickets:Ticket[]=[],eventAudit:Result['eventAudit']=[];
 const issue=(kind:Issue['kind'],index:number|null,id:string,message:string,severity:Issue['severity']='blocking',source:SourceRow|null=null)=>issues.push({kind,index,id,message,severity,source});
 try{validateRule(s.rule)}catch(e){issue('rule',null,'',String((e as Error).message));return {tickets,issues,groups:[],eventAudit}}
 const r=s.rule;let global=false;
 if(!s.inputs.receivables?.table.rows.length)issue('rule',null,'','尚未导入应收资料，不能确认工作完整');
 if(!r.confirmed||!r.scope.trim()){issue('rule',null,'','须确认来源完整性并填写本次工作范围/依据');global=true}
 if(r.mode==='snapshot'&&r.snapshotDate!==r.cutoff){issue('rule',null,'','未结快照日期必须等于截止日');global=true}
 if(r.mode==='movement'&&r.openingDate>=r.cutoff){issue('rule',null,'','期初日期必须早于截止日');global=true}
 const records:Rec[]=[],events:Ev[]=[],badTickets=new Set<string>();
 // Duplicate relationships come from all readable IDs, including rows invalid in other fields.
 for(const kind of ['receivables','events'] as Kind[]){const identities=new Map<string,{index:number;ticket:string;source:SourceRow}[]>();canonical(s,kind).forEach(({source,cells},index)=>{try{const id=text(cells[kind==='receivables'?'记录ID':'事件ID']),ticket=text(cells['应收ID']);append(identities,id,{index,ticket,source})}catch{/* unreadable identity cannot be guessed */}});for(const [id,rows] of identities)if(rows.length>1)for(const row of rows){badTickets.add(row.ticket);issue(kind,row.index,row.ticket,'重复明确ID '+id+'；含无效行的所有关联票阻塞','blocking',row.source)}}

 canonical(s,'receivables').forEach(({source,cells:c},index)=>{
 let ticket='';try{ticket=text(c['应收ID']);const rec:Rec={index,source,ticket,id:text(c['记录ID']),customer:text(c['客户ID']),name:text(c['客户名称']),type:text(c['行类型']),effective:date(c['有效日']),occurrence:optionalDate(c['发生日']),due:optionalDate(c['到期日']),currency:text(c['币种']),unit:text(c['单位']),tax:text(c['含税口径']),money:amount(c['金额']),reason:text(c['依据']),valid:true};
 if(!['快照','期初','新增'].includes(rec.type))throw Error('行类型须快照/期初/新增');
 if(r.mode==='snapshot'&&(rec.type!=='快照'||rec.effective!==r.cutoff))throw Error('快照行类型/有效日与截止日不符');
 if(r.mode==='movement'&&(rec.type==='快照'||rec.type==='期初'&&rec.effective!==r.openingDate||rec.type==='新增'&&rec.effective<=r.openingDate))throw Error('期初/新增类型及有效日期与本期范围不符');
 if(rec.occurrence&&rec.occurrence>rec.effective&&!(rec.type==='期初'&&rec.money.isZero()))throw Error('发生日不得晚于该余额/发生有效日');
 if(rec.type==='新增'&&rec.money.lt(0))throw Error('负新增须通过关联红字/批准调整');records.push(rec);
 }catch(e){if(ticket)badTickets.add(ticket);issue('receivables',index,ticket,(e as Error).message,'blocking',source)}});
 canonical(s,'events').forEach(({source,cells:c},index)=>{let ticket='';try{ticket=text(c['应收ID']);const ev:Ev={index,source,ticket,id:text(c['事件ID']),type:text(c['类型']),effective:date(c['生效日']),money:amount(c['金额']),currency:text(c['币种']),unit:text(c['单位']),tax:text(c['含税口径']),link:c['原关联ID']===null?'':text(c['原关联ID']),reason:text(c['依据']),valid:true};
 if(!['核销','退款','撤销','红字','调整'].includes(ev.type))throw Error('类型须核销/退款/撤销/红字/调整');if(ev.type!=='调整'&&ev.money.lte(0))throw Error('非调整事件须正金额');events.push(ev)
 }catch(e){if(ticket)badTickets.add(ticket);issue('events',index,ticket,(e as Error).message,'blocking',source);eventAudit.push({index,id:ticket,status:'输入无效',delta:null})}});

 const byTicket=new Map<string,Rec[]>();records.forEach(x=>append(byTicket,x.ticket,x));
 for(const e of events)if(!byTicket.has(e.ticket)){issue('events',e.index,e.ticket,'找不到显式应收ID，事件不应用','blocking',e.source);eventAudit.push({index:e.index,id:e.id,status:'无关联应收',delta:null})}
 const eventsByTicket=new Map<string,Ev[]>();for(const e of events)append(eventsByTicket,e.ticket,e);
 for(const [id,recs] of byTicket){const base=recs[0],es=eventsByTicket.get(id)||[],dim=(x:Rec|Ev)=>JSON.stringify([x.currency,x.unit,x.tax]);
 const block=(msg:string,e?:Ev)=>{badTickets.add(id);issue(e?'events':'receivables',e?.index??base.index,id,msg,'blocking',e?.source??base.source)};
 if(recs.some(x=>x.customer!==base.customer||x.name!==base.name||dim(x)!==dim(base)||x.occurrence!==base.occurrence||x.due!==base.due))block('同票客户/口径/日期不一致');
 if(r.mode==='movement'&&!recs.some(x=>x.type==='期初'))block('缺显式期初余额；新票也须提供期初零余额，不猜起始余额');
 if(recs.filter(x=>x.type==='期初'||x.type==='快照').length>1)block('同票只能有一条期初或截止快照');
 for(const e of es)if(dim(e)!==dim(base))block('事件与应收币种/单位/含税不一致',e);
 const eventIDs=new Map(es.map(e=>[e.id,e])),recordIDs=new Map(recs.map(x=>[x.id,x]));
 const within=es.filter(e=>e.effective<=r.cutoff&&(r.mode==='snapshot'||e.effective>r.openingDate));
 const credits=new Map<string,Decimal>(),returned=new Map<string,Decimal>();
 for(const e of within){
 if(e.type==='退款'||e.type==='撤销'){const original=eventIDs.get(e.link);if(!original||original.type!=='核销'||original.effective>e.effective||r.mode==='movement'&&original.effective<=r.openingDate){block('退款/撤销须关联本期同票原核销且日期有效',e);continue}returned.set(e.link,(returned.get(e.link)||new Decimal(0)).plus(e.money));if(returned.get(e.link)!.gt(original.money))block('关联核销退款/撤销累计超额，整票阻塞',e)}
 if(e.type==='红字'){const original=recordIDs.get(e.link);if(!original||original.effective>e.effective||original.money.lte(0)){block('红字须关联有效同票正发生/期初记录',e);continue}credits.set(e.link,(credits.get(e.link)||new Decimal(0)).plus(e.money));if(credits.get(e.link)!.gt(original.money))block('关联发生红字累计超额，整票阻塞',e)}
 }
 const active=recs.filter(x=>x.effective<=r.cutoff);let opening=new Decimal(0),added=new Decimal(0),settled=new Decimal(0),refund=new Decimal(0),credit=new Decimal(0),adjustment=new Decimal(0);
 active.forEach(x=>{if(x.type==='新增')added=added.plus(x.money);else opening=opening.plus(x.money)});
 if(r.mode==='movement'){
 const recDates=new Map<string,Rec[]>(),evDates=new Map<string,Ev[]>();for(const x of active)append(recDates,x.effective,x);for(const e of within)append(evDates,e.effective,e);
 const dates=[...new Set([...recDates.keys(),...evDates.keys()])].sort();let running=new Decimal(0);
 for(const day of dates){for(const x of recDates.get(day)||[])running=running.plus(x.money);
 const current=evDates.get(day)||[];let plus=new Decimal(0),minus=new Decimal(0);
 for(const e of current){if(e.type==='核销'){settled=settled.plus(e.money);minus=minus.plus(e.money)}else if(e.type==='退款'||e.type==='撤销'){refund=refund.plus(e.money);plus=plus.plus(e.money)}else if(e.type==='红字'){credit=credit.plus(e.money);minus=minus.plus(e.money)}else{adjustment=adjustment.plus(e.money);plus=plus.plus(e.money)}}
 const sameDayRefund=current.filter(e=>(e.type==='退款'||e.type==='撤销')&&eventIDs.get(e.link)?.effective===day).reduce((a,e)=>a.plus(e.money),new Decimal(0));
 if(minus.gt(Decimal.max(running.plus(plus).minus(sameDayRefund),0)))block('有效日 '+day+' 核销/红字超可用余额，整票阻塞');running=running.plus(plus).minus(minus)
 }
 }
 const balance=opening.plus(added).minus(settled).plus(refund).minus(credit).plus(adjustment);const future=recs.filter(x=>x.effective>r.cutoff);future.forEach(x=>issue('receivables',x.index,id,'截止后发生，不进历史余额','notice',x.source));
 for(const e of es){const status=e.effective>r.cutoff?'截止后事件':r.mode==='movement'&&e.effective<=r.openingDate?'期初已含事件':r.mode==='snapshot'?'快照来源核对，不扣余额':badTickets.has(id)||global?'整票阻塞':'已应用';eventAudit.push({index:e.index,id:e.id,status,delta:status==='已应用'?(e.type==='核销'||e.type==='红字'?e.money.negated():e.money).toFixed():status.includes('不扣')?'0':null});if(status==='截止后事件'||status==='期初已含事件')issue('events',e.index,id,status+'，不应用','notice',e.source)}
 const blocked=global||badTickets.has(id);let age=base.occurrence?days(r.cutoff,base.occurrence):null,overdue=base.due?Math.max(0,days(r.cutoff,base.due)):null;
 if(!base.occurrence)issue('receivables',base.index,id,'缺发生日；发生账龄不可计算','notice',base.source);if(!base.due)issue('receivables',base.index,id,'缺到期日；逾期不可计算','notice',base.source);
 const bucketDays=r.basis==='occurrence'?age:base.due?days(r.cutoff,base.due):null;
 const bucket=bucketDays===null?'无法分档':bucketDays<0?'未到起算日':r.bands.find(b=>bucketDays>=b.min&&(b.max===null||bucketDays<=b.max))!.label;
 tickets.push({id,customer:base.customer,name:base.name,currency:base.currency,unit:base.unit,tax:base.tax,occurrence:base.occurrence,due:base.due,original:opening.toFixed(),additions:added.toFixed(),settlements:settled.toFixed(),returns:refund.toFixed(),credits:credit.toFixed(),adjustments:adjustment.toFixed(),balance:blocked||!active.length?null:balance.toFixed(),status:blocked?'整票阻塞':!active.length?'未来发生':balance.lt(0)?'负余额':balance.isZero()?'零余额':'正应收',age,overdue,bucket,group:dim(base),sources:recs.map(x=>x.index),eventSources:es.map(x=>x.index)});
 }
 const groupedTickets=new Map<string,Ticket[]>();for(const t of tickets)if(t.balance!==null)append(groupedTickets,t.group,t);
 const groups:Group[]=[];for(const [key,groupTickets] of groupedTickets){const g:Group={key,positive:'0',negative:'0',zero:0,unaged:'0',notDue:'0',buckets:Object.fromEntries(r.bands.map(b=>[b.label,'0'])),residual:'0',overdue:'0',unknownDue:'0'};
 const add=(a:string,b:string)=>new Decimal(a).plus(b).toFixed();for(const t of groupTickets){const b=t.balance!;if(new Decimal(b).lt(0))g.negative=add(g.negative,b);else if(new Decimal(b).isZero())g.zero++;else{g.positive=add(g.positive,b);if(t.bucket==='无法分档')g.unaged=add(g.unaged,b);else if(t.bucket==='未到起算日')g.notDue=add(g.notDue,b);else g.buckets[t.bucket]=add(g.buckets[t.bucket],b);if(t.overdue===null)g.unknownDue=add(g.unknownDue,b);else if(t.overdue>0)g.overdue=add(g.overdue,b)}}g.residual=new Decimal(g.positive).minus(Object.values(g.buckets).reduce((a,b)=>a.plus(b),new Decimal(0))).minus(g.unaged).minus(g.notDue).toFixed();groups.push(g)}
 return {tickets,issues,groups,eventAudit};
}
