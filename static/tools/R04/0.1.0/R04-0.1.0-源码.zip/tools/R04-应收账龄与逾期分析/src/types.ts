import type {Table,Cell,SourceRow} from '../../../packages/core/types';
export type Kind='receivables'|'events';
export const receivableFields=['记录ID','应收ID','客户ID','客户名称','行类型','有效日','发生日','到期日','币种','单位','含税口径','金额','依据'] as const;
export const eventFields=['事件ID','应收ID','类型','生效日','金额','币种','单位','含税口径','原关联ID','依据'] as const;
export interface Input {table:Table; mapping:Record<string,string>}
export interface Correction {kind:Kind;index:number;field:string;before:Cell;after:string;reason:string}
export interface Band {label:string;min:number;max:number|null}
export interface Rule {mode:'snapshot'|'movement';cutoff:string;snapshotDate:string;openingDate:string;confirmed:boolean;basis:'occurrence'|'due';bands:Band[];precision:number;tolerance:string;scope:string}
export interface Issue {kind:Kind|'rule';index:number|null;id:string;message:string;severity:'blocking'|'notice';source:SourceRow|null}
export interface Ticket {id:string;customer:string;name:string;currency:string;unit:string;tax:string;occurrence:string|null;due:string|null;original:string;additions:string;settlements:string;returns:string;credits:string;adjustments:string;balance:string|null;status:string;age:number|null;overdue:number|null;bucket:string;group:string;sources:number[];eventSources:number[]}
export interface Group {key:string;positive:string;negative:string;zero:number;unaged:string;notDue:string;buckets:Record<string,string>;residual:string;overdue:string;unknownDue:string}
export interface Result {tickets:Ticket[];issues:Issue[];groups:Group[];eventAudit:{index:number;id:string;status:string;delta:string|null}[]}
export interface Snapshot {rule:Rule;inputs:Partial<Record<Kind,Input>>;corrections:Correction[];revision:number}
export interface Work extends Snapshot {events:{revision:number;action:string;time:string}[];reviews:Record<string,{note:string;revision:number}>;baseline:Snapshot|null}
export const defaultRule=():Rule=>({mode:'snapshot',cutoff:'2026-09-30',snapshotDate:'2026-09-30',openingDate:'2026-08-31',confirmed:false,basis:'occurrence',bands:[{label:'0–30天',min:0,max:30},{label:'31–60天',min:31,max:60},{label:'61–90天',min:61,max:90},{label:'91天以上',min:91,max:null}],precision:2,tolerance:'0.00',scope:''});
export const emptyWork=():Work=>({rule:defaultRule(),inputs:{},corrections:[],revision:0,events:[],reviews:{},baseline:null});
