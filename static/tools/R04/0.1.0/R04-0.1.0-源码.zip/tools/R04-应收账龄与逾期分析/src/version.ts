export const VERSION='0.1.0';
export const RULE_VERSION='R04-2026-10-03.1';
