import {workbookBytes} from '../../../packages/core/io';
import {example} from './example';
import {receivableFields,eventFields} from './types';
import {encode} from './session';
export async function releaseAssets(){const w=example();return [{filename:'空白模板.csv',data:'\uFEFF'+receivableFields.join(',')+'\r\n'},{filename:'核销调整模板.csv',data:'\uFEFF'+eventFields.join(',')+'\r\n'},{filename:'虚构样例.xlsx',data:await workbookBytes(Object.values(w.inputs).map(i=>({name:i!.table.sheet,headers:i!.table.headers,rows:i!.table.rows.map(r=>i!.table.headers.map(h=>r.cells[h]))})))},{filename:'虚构工作.json',data:encode(w,true)},{filename:'无数据方案.json',data:encode(w,false)}]}
