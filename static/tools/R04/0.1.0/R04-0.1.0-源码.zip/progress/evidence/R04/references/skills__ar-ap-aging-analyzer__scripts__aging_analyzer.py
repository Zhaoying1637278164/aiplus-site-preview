#!/usr/bin/env python3
"""
AR/AP aging analyzer: buckets receivables and payables by age, computes
DSO/DPO, and ranks which specific overdue items to chase or pay first by
dollar impact.

Usage:
    python3 aging_analyzer.py --config aging.json

aging.json shape:
{
  "period_days": 30,
  "annual_revenue": 12000000,
  "annual_cogs": 4000000,
  "receivables": [
    {"customer": "Acme Corp", "amount": 45000, "days_outstanding": 12},
    {"customer": "Beta LLC", "amount": 28000, "days_outstanding": 65}
  ],
  "payables": [
    {"vendor": "Supplier X", "amount": 30000, "days_outstanding": 20},
    {"vendor": "Supplier Y", "amount": 15000, "days_outstanding": 75}
  ]
}
"""
import argparse
import json


def money(x):
    return f"${x:,.0f}"


def bucket(days):
    if days <= 30:
        return "0-30"
    elif days <= 60:
        return "31-60"
    elif days <= 90:
        return "61-90"
    else:
        return "90+"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = json.load(f)

    receivables = cfg["receivables"]
    payables = cfg["payables"]

    print("=== Accounts Receivable Aging ===\n")
    ar_buckets = {"0-30": 0, "31-60": 0, "61-90": 0, "90+": 0}
    for r in sorted(receivables, key=lambda x: -x["days_outstanding"]):
        b = bucket(r["days_outstanding"])
        ar_buckets[b] += r["amount"]
    total_ar = sum(r["amount"] for r in receivables)
    for b, amt in ar_buckets.items():
        pct = amt / total_ar * 100 if total_ar else 0
        print(f"  {b:<8} days: {money(amt):>14}  ({pct:.0f}%)")
    print(f"  {'Total AR':<13}: {money(total_ar):>14}")

    print("\n  Top collection priorities (largest overdue, 60+ days):")
    overdue = sorted([r for r in receivables if r["days_outstanding"] > 60],
                      key=lambda x: -x["amount"])
    for r in overdue[:5]:
        print(f"    {r['customer']:<20} {money(r['amount']):>12}  ({r['days_outstanding']} days)")

    dso = (total_ar / cfg["annual_revenue"]) * 365 if cfg.get("annual_revenue") else None

    print("\n=== Accounts Payable Aging ===\n")
    ap_buckets = {"0-30": 0, "31-60": 0, "61-90": 0, "90+": 0}
    for p in payables:
        b = bucket(p["days_outstanding"])
        ap_buckets[b] += p["amount"]
    total_ap = sum(p["amount"] for p in payables)
    for b, amt in ap_buckets.items():
        pct = amt / total_ap * 100 if total_ap else 0
        print(f"  {b:<8} days: {money(amt):>14}  ({pct:.0f}%)")
    print(f"  {'Total AP':<13}: {money(total_ap):>14}")

    dpo = (total_ap / cfg["annual_cogs"]) * 365 if cfg.get("annual_cogs") else None

    print("\n=== DSO / DPO ===\n")
    if dso is not None:
        print(f"DSO (Days Sales Outstanding): {dso:.0f} days")
    if dpo is not None:
        print(f"DPO (Days Payable Outstanding): {dpo:.0f} days")
    if dso is not None and dpo is not None:
        gap = dso - dpo
        print(f"\nCash conversion gap (DSO - DPO): {gap:.0f} days")
        if gap > 30:
            print(">>> FLAG: you're paying suppliers well before you collect from customers.")
            print("    This gap is funded by your own working capital. Consider negotiating")
            print("    longer supplier terms or tightening collection on the aged accounts above.")


if __name__ == "__main__":
    main()
