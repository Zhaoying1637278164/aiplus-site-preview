---
name: ar-ap-aging-analyzer
description: Buckets receivables and payables by age via a bundled calculator, computes DSO and DPO, ranks the specific overdue accounts worth chasing first by dollar impact, and flags when the business is paying suppliers well before it collects from customers. Use whenever the user wants to see what's overdue and who to chase first, needs DSO/DPO for a cash or working capital review, or has an AR/AP process with no ranked priority on which specific accounts to act on first.
---

# AR/AP Aging Analyzer

## When to use
Use whenever cash collection or payment timing needs attention — collections are slipping, payment terms need review, or a working capital or cash flow analysis needs real DSO/DPO numbers instead of an estimate. Especially useful when the current AR/AP process has a full list of open items but no ranking of which ones actually matter most.

## What it does
Buckets every receivable and payable into standard aging buckets (0-30, 31-60, 61-90, 90+ days) via a bundled calculator, computes DSO and DPO from the totals, ranks the largest overdue receivables as explicit collection priorities, and flags when the gap between DSO and DPO shows the business is funding its own working capital by paying suppliers faster than it collects from customers.

## Method
1. **Pull every open receivable and payable** with amount and days outstanding — not a summary total, since the aging distribution and the specific accounts matter more than the aggregate number.
2. **Run the bundled calculator** (`scripts/aging_analyzer.py`) to bucket both AR and AP into standard aging bands and compute the dollar amount and percentage in each.
3. **Read the 90+ day bucket first.** Accounts this old are the ones most at risk of never being collected, and the ones most worth understanding individually rather than as a percentage.
4. **Use the calculator's ranked collection priority list** (largest overdue receivables, 60+ days) to focus collection effort on dollar impact, not just whichever account happens to come up first alphabetically or whichever customer called first.
5. **Compute DSO and DPO** from annual revenue and COGS respectively, giving a standardized measure of how fast the business collects versus how fast it pays, comparable period to period and against benchmarks.
6. **Read the DSO-DPO gap explicitly.** A large positive gap (DSO well above DPO) means the business pays suppliers faster than it collects from customers, funding that gap out of its own working capital — worth naming as a specific, actionable finding, not just background context.
7. **Turn the findings into two concrete actions**: a prioritized collection call list for the largest aged receivables, and a review of whether supplier payment terms can be extended to close some of the DSO-DPO gap without damaging the relationship.

## Inputs
- List of open receivables with customer, amount, and days outstanding
- List of open payables with vendor, amount, and days outstanding
- Annual revenue (for DSO) and annual COGS (for DPO)
- Config saved as JSON matching the format documented at the top of `scripts/aging_analyzer.py`

## Output format
AR aging buckets with dollar amounts and percentages; ranked collection priority list for the largest 60+ day receivables; AP aging buckets; DSO and DPO; explicit flag and commentary if the DSO-DPO gap is large.

## Example
An aging review shows 46% of receivables sitting in the 90+ day bucket, with two accounts, Gamma Inc at $62,000 and Beta LLC at $28,000, making up the bulk of it. Rather than a generic "follow up on overdue accounts" task, the ranked list gives the collections team two specific names and dollar amounts to prioritize this week, with everything else genuinely lower priority by comparison.

## Common pitfalls
- Reviewing the aggregate AR balance without breaking it into buckets, missing that a small percentage of accounts represents most of the real collection risk.
- Chasing whichever overdue account is most recently mentioned instead of ranking by actual dollar impact.
- Computing DSO or DPO without checking the gap between them, missing a concrete, actionable working-capital finding.
