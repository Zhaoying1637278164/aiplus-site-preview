# 当前进度

2026-10-03。完整64款目标持续有效，accepted **4/64**。一个稳定ID一个长期工具线程，已建11个、53个待建；最多两款同时实现。P03原线程实际inProgress；P02已completed/idle，候选待总控核验。Windows实机未验证。

| 工具 | 登记阶段 | 当前证据与剩余工作 |
|---|---|---|
| D02 / D03 / D06 / R01 | accepted | 0.2.0 / 0.2.0 / 0.2.0 / 0.1.0；维护复用原线程，已发布版本冻结 |
| R02 收入确认排程表 | packaged 0.1.0 | 已发布；公开导入、恢复、退出和版本下载待续验 |
| R03 回款对账 | packaged 0.1.0 | 已发布；公开三类XLSX/CSV、含数据恢复、无数据清空、退出取消/确认、人工核销/撤销与9项版本下载已有证据；剩无数据恢复取消保留工作及最终逐项审计 |
| R04 应收账龄与逾期分析 | packaged 0.1.0 | 修复最终16源码SHA、55测试/9独立断言通过；重新正式断网28组、独立源码四命令通过，HTML/runtime一致、12资产内容核验；真实八款暂存官网9组、24导航几何、13次版本下载点击通过（11唯一文件精确字节相等）；原官网320图和详情图已实际审查；尚未公开 |
| R05 坏账计提表 | packaged 0.1.0 | 总控17源码SHA、55测试/11独立断言通过；正式离线20组、16表670格及15导出回读；最终源码四命令及19资产内容核验；真实八款暂存官网9组、24导航几何、20版本下载点击通过（18唯一文件精确字节相等）；当前320图和原详情图已实际审查；尚未公开 |
| P01 采购三单核对 | packaged 0.1.0 | 最终16源码SHA、56测试、10独立财务预期、类型检查通过；正式离线28组、31表8952格/11资产回读；独立源码四命令及18资产内容核验，HTML/runtime精确一致；真实官网与公开验收待做 |
| P02 付款计划表 | implementing，候选已交接 | 原线程实际completed/idle，作者报告45测试/19浏览器检查/26真实下载/18表回读；最终源码SHA与独立预期待总控核验，不据声明升级阶段 |
| P03 预付款核销 | specified，原线程实现中 | 唯一线程已创建，3298字完整任务已回读并记录SHA；双端额度、部分核销、重复导入、确认撤销与来源底稿 |
| 其余53款 | planned | 按财务模块分批创建独立线程，名称与工作链见分线程计划 |

## 官网与版本

公开官网六款基线commit 9b0607bad7fd7d4b680deabf312e7fac10b3866c，回退codex/before-R03-native-0.1.0。本轮未修改或发布官网工程。冻结10版本131文件本轮逐文件重验未变。

八款官网重新暂存，R04/R05复用原tool-ar-06/tool-ar-08，原80目录条目保持。stage SHA 5804b88b11c33b3387af215d314471fce99c8ebba93b47a492a80e4ff2c3a963。Streamlit1.50服务session67235，127.0.0.1:8515健康读取ok；沙箱内curl失败后在授权本地访问下核验成功，未重启现有进程。真实官网CLI使用独立临时配置。

八款门禁已扩展到R04/R05，要求正式包、源码、全部原详情下载、原导航/标题几何和业务工作同结果；当前门禁仍不通过，因为全套实图审查及最终版本归档尚未齐，不发布。16项前六款回归实际session57052已全部退出0，当前日志/逐步退出码见regression-commands.json；本轮16项结果已固定，未新增变化前无需重复执行。

最终源码ZIP已包含root独立财务/正式浏览器/真实R04-R05官网验证与资产核验器，并通过独立四命令；新改八款发布门禁和回归runner在本次源码ZIP之后产生，最终冻结前需纳入、重新独立重建并重验全部版本下载。冻结包不可重写。

## 证据入口

- 当前八款官网：progress/evidence/site-integration/D02-D03-D06-R01-R02-R03-R04-R05/checkpoint.json、gate-checkpoint.json；逐款site-local/result.json及root-visual-review.json。
- 修复R04：progress/evidence/shared/2026-10-03-R04-repaired-handoff-audit.json；旧正式证据保留progress/evidence/R04/history/pre-repaired-formal-browser。
- P01：progress/evidence/shared/2026-10-03-P01-handoff-audit.json、2026-10-03-P01-independent-review.json；正式浏览器result.json。
- R04/R05/P01各款0.1.0/source-rebuild.json及source-rebuild-assets.json。XLSX独立重建仅created/modified时间及ZIP容器元信息可不同，其他每个条目精确一致；不能宣称XLSX字节相等。
- R03公开：progress/evidence/R03/0.1.0/site-public/checkpoint.json；CSV计算302格和来源39格分别核验。
- 唯一线程、turn和cursor：catalog/threads.json；完整业务分线程规划见[分线程开发计划](分线程开发计划.md)，操作入口见[线程调度与接续](线程调度与接续.md)。

R04真实官网验证首次读JSON错误：根验证器错读envelope.inputs，已按实际下载的envelope.work修正，错误与修正SHA保留initial-envelope-access-verifier-failure.json；正式程序无此schema问题。普通点击、无force、文件/整工作比较均已真实重新通过。只有成品、离线、源码及公开官网完整证据通过才accepted。
