"""Compare every formal asset with its isolated source rebuild, including all XLSX entries.

Only XLSX created/modified timestamps and ZIP container metadata may differ.
No worksheet values, formulas, styles, relationships or other XML are normalized.
"""
import hashlib, json, pathlib, re, sys, zipfile

release = pathlib.Path(sys.argv[1]).resolve()
tool, version = release.parent.name, release.name
evidence = pathlib.Path('progress/evidence') / tool / version
rebuild = json.loads((evidence / 'source-rebuild.json').read_text())
assert rebuild['tool'] == tool and rebuild['version'] == version
assert all(command['exit_code'] == 0 for command in rebuild['commands'])
rebuilt = pathlib.Path(rebuild['independent_directory']) / 'release' / tool / version
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(release / f'{tool}-{version}-源码.zip') == rebuild['source_zip_sha256']
files = [path for path in sorted(release.iterdir()) if path.is_file() and path.suffix != '.zip']
assert {p.name for p in files} == {p.name for p in rebuilt.iterdir() if p.is_file() and p.suffix != '.zip'}
comparisons = {}
for formal in files:
    other = rebuilt / formal.name
    row = {'release_sha256': sha(formal), 'rebuilt_sha256': sha(other)}
    if formal.suffix == '.xlsx':
        with zipfile.ZipFile(formal) as a, zipfile.ZipFile(other) as b:
            assert sorted(a.namelist()) == sorted(b.namelist()), formal.name
            differences = []
            for entry in sorted(a.namelist()):
                left, right = a.read(entry), b.read(entry)
                if left != right:
                    assert entry == 'docProps/core.xml', (formal.name, entry)
                    pattern = rb'<dcterms:(created|modified)\b[^>]*>[^<]*</dcterms:\1>'
                    assert re.sub(pattern, b'', left) == re.sub(pattern, b'', right), formal.name
                    differences.append(entry)
            row.update(entries_checked=len(a.namelist()), differing_entries=differences,
                       content_identical_except_created_modified=True)
    else:
        assert formal.read_bytes() == other.read_bytes(), formal.name
    row['bytes_identical'] = row['release_sha256'] == row['rebuilt_sha256']
    comparisons[formal.name] = row
result = {'tool': tool, 'version': version, 'source_zip_sha256': rebuild['source_zip_sha256'],
          'files': comparisons, 'scope': 'all non-ZIP release assets; XLSX ZIP metadata and core created/modified timestamps may differ; all other entries exact',
          'accepted': False}
(evidence / 'source-rebuild-assets.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(f'{tool}: {len(comparisons)} formal assets verified')
