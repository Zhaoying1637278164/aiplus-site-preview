import pathlib,json,shutil,zipfile,hashlib,subprocess,tempfile
root=pathlib.Path.cwd();folder=pathlib.Path('tools/U02-审计抽样');out=folder/'candidate/0.1.0';e=root/'progress/evidence/U02/0.1.0'
def zipdir(source,dest):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(source.rglob('*')):
   if p.is_file():
    i=zipfile.ZipInfo(p.relative_to(source).as_posix(),(2026,10,4,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,p.read_bytes())
with tempfile.TemporaryDirectory(prefix='u02-source-',dir='/private/tmp') as tmp:
 src=pathlib.Path(tmp)
 for f in ['package.json','package-lock.json']:
  shutil.copy2(root/f,src/f)
 package=json.loads((src/'package.json').read_text());package['scripts']={'test':'node --import tsx --test tools/U02-审计抽样/tests/*.test.ts','typecheck':'tsc --noEmit','build':'node --import tsx tools/U02-审计抽样/scripts/build-candidate.ts'};(src/'package.json').write_text(json.dumps(package,ensure_ascii=False,indent=2))
 (src/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','jsx':'react-jsx','strict':True,'esModuleInterop':True,'skipLibCheck':True,'lib':['ES2022','DOM'],'types':['node'],'noEmit':True},'include':['packages/core','packages/ui/tool-host.ts','tools/U02-审计抽样/src','tools/U02-审计抽样/tests','tools/U02-审计抽样/scripts/build-candidate.ts']},indent=2))
 shutil.copytree(root/'packages/core',src/'packages/core');(src/'packages/ui').mkdir(parents=True);shutil.copy2(root/'packages/ui/tool-host.ts',src/'packages/ui/tool-host.ts')
 shutil.copytree(root/folder,src/folder,ignore=shutil.ignore_patterns('candidate','__pycache__'))
 (src/'references').mkdir();shutil.copy2(root/'references/saxes-5.0.1-LICENSE',src/'references/saxes-5.0.1-LICENSE')
 shutil.copytree(root/'progress/evidence/U02/references',src/'reference-review')
 shutil.copy2(root/folder/'README.md',src/'README.md')
 shutil.copy2(root/out/'THIRD_PARTY_NOTICES.md',src/'THIRD_PARTY_NOTICES.md')
 files={str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(src.rglob('*')) if p.is_file()};(src/'SOURCE-SHA256.json').write_text(json.dumps(files,ensure_ascii=False,indent=2))
 zipdir(src,out/'U02-0.1.0-源码.zip');(e/'source-snapshot.json').write_text(json.dumps({'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':files},ensure_ascii=False,indent=2))
with tempfile.TemporaryDirectory(prefix='u02-offline-',dir='/private/tmp') as tmp:
 d=pathlib.Path(tmp)
 for p in out.iterdir():
  if p.is_file() and not p.name.endswith('.zip'):shutil.copy2(p,d/p.name)
 zipdir(d,out/'U02-0.1.0-离线包.zip')
print(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.zip')},ensure_ascii=False))
