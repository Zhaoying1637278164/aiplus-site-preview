# Independent integer algorithm, written separately from TS implementation.
import json,pathlib
MASK=(1<<32)-1
def choose(ids,n,seed):
 state=2166136261
 raw=seed.encode('utf-16-le')
 for i in range(0,len(raw),2):state=((state^(raw[i]+raw[i+1]*256))*16777619)&MASK
 if state==0:state=0x9e3779b9
 pool=sorted(ids)
 for end in range(len(pool)-1,0,-1):
  m=end+1
  while True:
   state^=(state<<13)&MASK;state^=state>>17;state^=(state<<5)&MASK;state&=MASK
   if state-1<((2**32-1)//m)*m:break
  index=(state-1)%m;pool[end],pool[index]=pool[index],pool[end]
 return pool[:n]
a=[f'S{i:03}' for i in range(1,9)]
r={'algorithm':'independent Python uint32 implementation','random':choose(a,3,'20261004'),'stratified':sum((choose(a[:4] if group=='甲组' else a[4:],2 if group=='甲组' else 1,json.dumps(['20261004',group],ensure_ascii=False,separators=(',',':'))) for group in sorted(['甲组','乙组'])),[]),'hand_total':'760.01','specified':['S003','S004'],'specified_amount':'-40','remaining':'800.01'}
pathlib.Path('tools/U02-审计抽样/examples/独立预期.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False))
