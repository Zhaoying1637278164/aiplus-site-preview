import Decimal from 'decimal.js';
import {amount,text} from '../../../packages/core/value';
import type {Table,SourceRow,Cell} from '../../../packages/core/types';
export const VERSION='0.1.0',RULE_VERSION='U02-2026-10-04.1',ALGORITHM='fnv1a-xorshift32-fisher-yates-rejection-v1';
export const HEADERS=['总体ID','记录ID','金额','币种','单位','期间','分层','摘要'];
export type Method='random'|'stratified'|'specified';
export interface Settings {population:string;currency:string;unit:string;period:string;purpose:string;basis:string;method:Method;seed:string;count:number;strata:Record<string,number>;specified:string[];specifiedReason:string;expectedCount:string;expectedAmount:string;tolerance:string;exclusions:Record<string,string>}
export interface Work {table:Table|null;settings:Settings}
export const blankWork=():Work=>({table:null,settings:{population:'POP-2026',currency:'CNY',unit:'元',period:'2026-09',purpose:'',basis:'',method:'random',seed:'20261004',count:3,strata:{},specified:[],specifiedReason:'',expectedCount:'',expectedAmount:'',tolerance:'0.00',exclusions:{}}});
export function key(r:SourceRow){return JSON.stringify([r.file,r.sheet,r.row])}
export interface Checked {source:SourceRow;key:string;id:string;stratum:string;amount:string|null;excluded:string;issues:string[];warnings:string[]}
export interface Result {rows:Checked[];eligible:Checked[];sample:Checked[];errors:string[];warnings:string[];knownTotal:string;eligibleTotal:string;excludedKnownTotal:string;unknownAmounts:number;sampleTotal:string;remainingTotal:string;strata:{name:string;population:number;requested:number;selected:number;total:string}[]}
export function validateSettings(s:Settings){
 for(const k of ['population','currency','unit','period','purpose','basis','seed','specifiedReason','expectedCount','expectedAmount','tolerance'] as const)if(typeof s[k]!=='string'||s[k].length>10000)throw Error('参数文本无效 '+k);
 if(!['random','stratified','specified'].includes(s.method)||!Number.isInteger(s.count)||s.count<0||s.count>20000)throw Error('方法或样本数无效');
 if(!s.strata||Array.isArray(s.strata)||typeof s.strata!=='object'||!s.exclusions||Array.isArray(s.exclusions)||typeof s.exclusions!=='object'||!Array.isArray(s.specified)||s.specified.length>20000||s.specified.some(x=>typeof x!=='string'||x.length>10000))throw Error('参数结构无效');
 if(Object.keys(s.strata).length>20000||Object.keys(s.exclusions).length>20000)throw Error('参数超过行数限制');
 for(const n of Object.values(s.strata))if(!Number.isInteger(n)||n<0||n>20000)throw Error('分层样本数无效');
 for(const [k,v] of Object.entries(s.exclusions))if(k.length>30000||typeof v!=='string'||!v.trim()||v.length>10000)throw Error('每项剔除必须有原因');
}
function sum(rows:Checked[]){return rows.reduce((a,r)=>r.amount===null?a:a.plus(r.amount),new Decimal(0)).toFixed()}
/** UTF-16 seed hash; unsigned 32-bit xorshift; bounded draws reject modulo bias. Sorted IDs precede shuffle. */
export function draw(ids:Checked[],n:number,seed:string){let x=2166136261;for(let i=0;i<seed.length;i++)x=Math.imul(x^seed.charCodeAt(i),16777619)>>>0;if(!x)x=0x9e3779b9;const next=()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return x>>>0};const bounded=(m:number)=>{const limit=Math.floor(4294967295/m)*m;let v;do{v=next()-1}while(v>=limit);return v%m};const a=[...ids].sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);for(let i=a.length-1;i>0;i--){const j=bounded(i+1);[a[i],a[j]]=[a[j],a[i]]}return a.slice(0,n)}
export function calculate(work:Work):Result{
 validateSettings(work.settings);const s=work.settings,errors:string[]=[],warnings:string[]=[],table=work.table;
 const rows:Checked[]=(table?.rows??[]).map(source=>{const issues:string[]=[],warn:string[]=[],c=source.cells;const get=(h:string)=>{try{return text(c[h]??null).trim()}catch{issues.push(h+'缺失或公式');return ''}};const id=get('记录ID'),stratum=s.method==='stratified'?get('分层'):(typeof c['分层']==='string'?c['分层']:'');let value:string|null=null;try{value=amount(c['金额']??null).toFixed();if(new Decimal(value).isNegative())warn.push('负金额，保留其符号');if(new Decimal(value).isZero())warn.push('零金额，仍可被抽取')}catch(e){issues.push((e as Error).message)}
 for(const [h,v] of [['总体ID',s.population],['币种',s.currency],['单位',s.unit],['期间',s.period]])if(get(h)!==v)issues.push(h+'与抽样范围不一致');
 return {source,key:key(source),id,stratum,amount:value,excluded:s.exclusions[key(source)]??'',issues,warnings:warn}});
 if(!table||!rows.length)errors.push('请导入总体');else for(const h of HEADERS.slice(0,6))if(!table.headers.includes(h))errors.push('缺少字段 '+h);
 if(rows.length>20000)errors.push('总体超过20000行');if(new Set(rows.map(r=>r.key)).size!==rows.length)errors.push('原始来源行重复');
 for(const k of Object.keys(s.exclusions))if(!rows.some(r=>r.key===k))errors.push('剔除来源已不存在，请重新设置');
 const eligible=rows.filter(r=>!r.excluded);const ids=new Set<string>();for(const r of eligible){if(ids.has(r.id)){r.issues.push('记录ID重复');errors.push('待抽总体记录ID重复 '+r.id)}ids.add(r.id);if(r.issues.length)errors.push(`来源第${r.source.row}行：${r.issues.join('；')}`)}
 if(!eligible.length)errors.push('待抽总体为空');
 if(!s.population.trim()||!s.currency.trim()||!s.unit.trim()||!s.period.trim()||!s.purpose.trim()||!s.basis.trim())errors.push('请填写总体范围、抽样目的和样本量依据');
 if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(s.period))errors.push('期间须为YYYY-MM');if(!s.seed.trim())errors.push('随机种子不能为空');
 let tolerance=new Decimal(0);try{tolerance=amount(s.tolerance);if(tolerance.isNegative())throw Error();}catch{errors.push('容差须为非负金额')}
 if(s.expectedCount==='')warnings.push('未提供外部总体条数，完整性尚未核验');else if(!/^\d+$/.test(s.expectedCount)||Number(s.expectedCount)!==rows.length)errors.push('总体条数与外部控制数不符');
 const unknownAmounts=rows.filter(r=>r.amount===null).length,knownTotal=sum(rows),eligibleTotal=sum(eligible),excludedKnownTotal=sum(rows.filter(r=>r.excluded));
 if(s.expectedAmount==='')warnings.push('未提供外部金额控制数，完整性尚未核验');else {try{if(unknownAmounts||new Decimal(knownTotal).minus(amount(s.expectedAmount)).abs().gt(tolerance))errors.push('总体金额与外部控制数不符或存在未知金额')}catch{errors.push('金额控制数格式无效')}}
 if(unknownAmounts)warnings.push(`${unknownAmounts}行金额未知，已知金额汇总不等于完整总体金额`);
 if(rows.some(r=>r.warnings.length))warnings.push('总体含负数或零值，未自动剔除');
 const groups=[...new Set(eligible.map(r=>r.stratum))].sort();const strata=groups.map(name=>({name,population:eligible.filter(r=>r.stratum===name).length,requested:Object.hasOwn(s.strata,name)?s.strata[name]:0,selected:0,total:sum(eligible.filter(r=>r.stratum===name))}));
 if(s.method==='stratified'){for(const g of strata)if(!Object.hasOwn(s.strata,g.name)||g.requested>g.population)errors.push('分层样本数缺失或超总体 '+g.name);for(const name of Object.keys(s.strata))if(!groups.includes(name))errors.push('分层不存在 '+name);if(!strata.reduce((a,g)=>a+g.requested,0))errors.push('分层总样本数须大于零')}
 else if(s.method==='random'&&(s.count<1||s.count>eligible.length))errors.push('样本数须为1至待抽总体条数');
 else if(s.method==='specified'){if(!s.specified.length||new Set(s.specified).size!==s.specified.length||s.specified.some(id=>!ids.has(id)))errors.push('指定项目为空、重复或不在待抽总体');if(!s.specifiedReason.trim())errors.push('指定项目须填写选择依据');warnings.push('指定项目为非统计选择，不能向总体推断')}
 let sample:Checked[]=[];if(!errors.length){if(s.method==='random')sample=draw(eligible,s.count,s.seed);if(s.method==='specified')sample=s.specified.map(id=>eligible.find(r=>r.id===id)!);if(s.method==='stratified')sample=strata.flatMap(g=>draw(eligible.filter(r=>r.stratum===g.name),g.requested,JSON.stringify([s.seed,g.name])))}
 for(const g of strata)g.selected=sample.filter(r=>r.stratum===g.name).length;
 const sampleTotal=sum(sample),remainingTotal=sum(eligible.filter(r=>!sample.includes(r)));
 return {rows,eligible,sample,errors:[...new Set(errors)],warnings,knownTotal,eligibleTotal,excludedKnownTotal,unknownAmounts,sampleTotal,remainingTotal,strata};
}
export function validateTable(t:Table){if(!t||typeof t.file!=='string'||typeof t.sheet!=='string'||t.file.length>10000||t.sheet.length>10000||!Array.isArray(t.headers)||!Array.isArray(t.rows)||t.rows.length>20000||t.headers.length>200||new Set(t.headers).size!==t.headers.length||t.headers.some(h=>typeof h!=='string'||!h||h.length>10000))throw Error('总体结构或上限无效');for(const r of t.rows){if(r.file!==t.file||r.sheet!==t.sheet||!Number.isInteger(r.row)||r.row<1||!r.cells||Array.isArray(r.cells)||typeof r.cells!=='object'||Object.keys(r.cells).some(h=>!t.headers.includes(h)))throw Error('来源结构无效');for(const v of Object.values(r.cells))if(v!==null&&!(typeof v==='string'&&v.length<=10000)&&!(typeof v==='number'&&Number.isFinite(v))&&!(typeof v==='object'&&typeof v.formula==='string'&&v.formula.length<=10000))throw Error('单元格结构无效')}}
export function encodePlan(w:Work,data:boolean){return JSON.stringify({schema_version:1,tool:'U02',app_version:VERSION,rule_version:RULE_VERSION,algorithm:ALGORITHM,contains_data:data,settings:w.settings,table:data?w.table:null},null,2)}
export function decodePlan(raw:string):Work{if(new TextEncoder().encode(raw).length>10*1024*1024)throw Error('方案超过10MB');const p=JSON.parse(raw);if(p?.schema_version!==1||p.tool!=='U02'||p.app_version!==VERSION||p.rule_version!==RULE_VERSION||p.algorithm!==ALGORITHM||typeof p.contains_data!=='boolean'||(!p.contains_data&&p.table!==null))throw Error('方案版本或数据标识无效');validateSettings(p.settings);if(p.table!==null)validateTable(p.table);return {settings:p.settings,table:p.table}}
export function replaceTable(w:Work,table:Table):Work{validateTable(table);return {table,settings:{...w.settings,exclusions:{},specified:[],strata:{}}}}
export function example():Work{const w=blankWork();w.settings={...w.settings,purpose:'虚构采购支出发生性检查',basis:'演示自行确定3条，无保证水平推断',expectedCount:'8',expectedAmount:'760.01'};const amounts=['100.00','200.00','-40.00','0.00','300.00','100.01','50.00','50.00'];w.table={file:'虚构总体.csv',sheet:'CSV',headers:HEADERS,rows:amounts.map((v,i)=>({file:'虚构总体.csv',sheet:'CSV',row:i+2,cells:{'总体ID':'POP-2026','记录ID':'S'+String(i+1).padStart(3,'0'),'金额':v,'币种':'CNY','单位':'元','期间':'2026-09','分层':i<4?'甲组':'乙组','摘要':'完全虚构采购 '+(i+1)}}))};return w}
