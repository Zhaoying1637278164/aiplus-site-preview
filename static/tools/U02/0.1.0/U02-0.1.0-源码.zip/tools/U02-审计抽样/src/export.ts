import {workbookBytes} from '../../../packages/core/io';
import {calculate,VERSION,RULE_VERSION,ALGORITHM,type Work,HEADERS,encodePlan,blankWork,example} from './model';
import type {ReleaseAsset} from '../../../packages/core/release-assets';
export function csv(headers:string[],rows:unknown[][]){const safe=(v:unknown)=>{let s=v==null?'':typeof v==='object'?JSON.stringify(v):String(v);if(/^[\s]*[=+@-]/.test(s)&&!/^[-+]\d+(\.\d+)?$/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};return '\uFEFF'+[headers,...rows].map(r=>r.map(safe).join(',')).join('\r\n')}
export function sheets(w:Work){const r=calculate(w),s=w.settings,t=w.table;return [
{name:'抽样记录',headers:['项目','值'],rows:Object.entries({工具:'U02',版本:VERSION,规则版本:RULE_VERSION,算法:ALGORITHM,方法:s.method,种子:s.seed,总体ID:s.population,币种:s.currency,单位:s.unit,期间:s.period,目的:s.purpose,样本量依据:s.basis,随机样本数:s.count,分层参数:JSON.stringify(s.strata),指定项目:JSON.stringify(s.specified),指定依据:s.specifiedReason,外部条数:s.expectedCount,外部金额:s.expectedAmount,容差:s.tolerance,边界:'不自动给保证水平，不宣称样本充分适当'})},
{name:'总体勾稽',headers:['项目','值'],rows:Object.entries({原始条数:r.rows.length,待抽条数:r.eligible.length,剔除条数:r.rows.filter(x=>x.excluded).length,未知金额行:r.unknownAmounts,已知金额:r.knownTotal,待抽已知金额:r.eligibleTotal,剔除已知金额:r.excludedKnownTotal,样本条数:r.sample.length,样本金额:r.sampleTotal,剩余金额:r.remainingTotal,条数守恒:r.rows.length===r.eligible.length+r.rows.filter(x=>x.excluded).length?'通过':'不通过'})},
{name:'样本清单',headers:['序号','记录ID','金额','分层','文件','页签','原行','选择方式'],rows:r.sample.map((x,i)=>[i+1,x.id,x.amount,x.stratum,x.source.file,x.source.sheet,x.source.row,s.method])},
{name:'总体校验',headers:['记录ID','金额','分层','状态','问题','提示','文件','页签','原行'],rows:r.rows.map(x=>[x.id,x.amount,x.stratum,x.excluded?'已剔除':x.issues.length?'阻塞':'待抽',x.issues.join('；'),x.warnings.join('；'),x.source.file,x.source.sheet,x.source.row])},
{name:'剔除记录',headers:['记录ID','原因','金额','文件','页签','原行','原始问题'],rows:r.rows.filter(x=>x.excluded).map(x=>[x.id,x.excluded,x.amount,x.source.file,x.source.sheet,x.source.row,x.issues.join('；')])},
{name:'分层汇总',headers:['分层','总体数','设置样本数','实际样本数','总体金额'],rows:r.strata.map(g=>[g.name,g.population,g.requested,g.selected,g.total])},
{name:'异常与限制',headers:['类别','说明'],rows:[...r.errors.map(x=>['阻塞',x]),...r.warnings.map(x=>['提示',x]),['限制','外部控制数一致仍不能证明总体完整；随机选择本身不构成统计推断方案']]},
{name:'原始总体',headers:['来源文件','来源页签','原行',...(t?.headers??HEADERS)],rows:(t?.rows??[]).map(x=>[x.file,x.sheet,x.row,...(t?.headers??HEADERS).map(h=>x.cells[h])])}
]}
export async function exportWork(w:Work){return workbookBytes(sheets(w))}
export async function releaseAssets():Promise<ReleaseAsset[]>{const w=example(),t=w.table!,enc=new TextEncoder();return [{filename:'空白模板.csv',data:enc.encode(csv(HEADERS,[]))},{filename:'虚构样例.csv',data:enc.encode(csv(HEADERS,t.rows.map(r=>HEADERS.map(h=>r.cells[h]))))},{filename:'虚构样例.xlsx',data:await workbookBytes([{name:'总体',headers:HEADERS,rows:t.rows.map(r=>HEADERS.map(h=>r.cells[h]))}])},{filename:'虚构工作.json',data:enc.encode(encodePlan(w,true))},{filename:'无数据方案.json',data:enc.encode(encodePlan(blankWork(),false))}]}
